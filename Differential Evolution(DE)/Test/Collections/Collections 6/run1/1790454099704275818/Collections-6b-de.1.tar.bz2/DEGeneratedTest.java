import java.lang.reflect.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Deterministic test-program decoder. Used unchanged during search and JUnit replay. */
final class DEReplay {
    public static final int DIMENSIONS = 64;
    /** Local generic bean used to create stable reflection Type and Field values. */
    public static final class GenericInput {
        public String text;
        public java.util.List<String> names;
        public java.util.Map<String, Integer> counts;
        public java.util.List<java.util.Map<String, Long>> nested;
        public int[] numbers;
        public String[] words;
    }
    static final class Genes {
        final int[] values; int at; Field lastField;
        Object jacksonBean, jacksonProvider, jacksonGenerator;
        StringWriter jacksonOutput;
        Genes(int[] values) { this.values = values; }
        int next() { return values[(at++) % values.length]; }
        int pick(int n) { return Math.floorMod(next(), n); }
    }
    public static final class Observation {
        public String token, error, generatedSource;
        public boolean reachedTarget;
        public int setupCalls, setupFailures, nullFallbacks;
    }
    public static String signature(Method m) {
        StringJoiner params = new StringJoiner(",");
        for (Class<?> t : m.getParameterTypes()) params.add(t.getTypeName());
        return m.getName() + "(" + params + "):" + m.getReturnType().getTypeName();
    }
    static Class<?> load(String name) throws ClassNotFoundException {
        return Class.forName(name, true, Thread.currentThread().getContextClassLoader());
    }
    static Method method(String target, String signature) throws Exception {
        for (Method m : load(target).getDeclaredMethods())
            if (signature(m).equals(signature)) {
                // Public methods on package-private Defects4J classes (for
                // example Gson's TypeInfoFactory) are not reflectively
                // accessible until opened on the unnamed application module.
                if (!m.isAccessible()) m.setAccessible(true);
                return m;
            }
        throw new NoSuchMethodException(signature);
    }
    static List<Constructor<?>> constructors(Class<?> type) {
        List<Constructor<?>> out = new ArrayList();
        if (!Modifier.isAbstract(type.getModifiers()) && Modifier.isPublic(type.getModifiers()))
            for (Constructor<?> c : type.getConstructors())
                if (c.getParameterTypes().length <= 6) out.add(c);
        Collections.sort(out, new Comparator<Constructor<?>>() {
            public int compare(Constructor<?> a, Constructor<?> b) {
                int byArity = a.getParameterTypes().length - b.getParameterTypes().length;
                return byArity != 0 ? byArity : a.toString().compareTo(b.toString());
            }
        });
        return out;
    }
    private static Object[] arguments(Class<?>[] types, Genes g, int depth,
                                      Observation report) throws Exception {
        Object[] args = new Object[types.length];
        for (int i = 0; i < types.length; i++) args[i] = value(types[i], g, depth, report);
        return args;
    }
    private static Object[] arguments(Method method, Genes g, int depth,
                                      Observation report) throws Exception {
        Class<?>[] types = method.getParameterTypes();
        Object[] args = new Object[types.length];
        boolean closureCompile = method.getDeclaringClass().getName().equals("com.google.javascript.jscomp.Compiler")
            && method.getName().equals("compile");
        Type[] generic = method.getGenericParameterTypes();
        boolean jacksonSerialization = method.getDeclaringClass().getName().equals(
            "com.fasterxml.jackson.databind.ser.BeanPropertyWriter")
            && method.getName().startsWith("serializeAs")
            && types.length == 3 && types[0] == Object.class;
        for (int i = 0; i < types.length; i++) {
            if (jacksonSerialization && g.jacksonBean != null) {
                if (i == 0) args[i] = g.jacksonBean;
                else if (i == 1) args[i] = g.jacksonGenerator;
                else args[i] = g.jacksonProvider;
                continue;
            }
            if (closureCompile && (List.class.isAssignableFrom(types[i])
                    || (types[i].isArray() && load("com.google.javascript.jscomp.SourceFile")
                        .isAssignableFrom(types[i].getComponentType())))) {
                // Compiler.compile takes externs and inputs in either Lists or
                // arrays depending on Closure version. Keep externs empty and
                // supply a nonempty, gene-selected input program.
                if (i == 0) args[i] = types[i].isArray()
                    ? Array.newInstance(types[i].getComponentType(), 0) : new ArrayList();
                else {
                    Object sourceFile = value(load("com.google.javascript.jscomp.SourceFile"),
                        g, depth + 1, report);
                    if (types[i].isArray()) {
                        Object files = Array.newInstance(types[i].getComponentType(), 1);
                        Array.set(files, 0, sourceFile); args[i] = files;
                    } else args[i] = new ArrayList(Collections.singletonList(sourceFile));
                }
            } else args[i] = value(types[i], g, depth, report);
        }
        return args;
    }
    private static Number number(Genes g) {
        int n = g.next();
        switch (g.pick(12)) {
            case 0: return 0; case 1: return 1; case 2: return -1;
            case 3: return Integer.MAX_VALUE; case 4: return Integer.MIN_VALUE;
            case 5: return Long.MAX_VALUE; case 6: return Long.MIN_VALUE;
            case 7: return Double.NaN; case 8: return Double.POSITIVE_INFINITY;
            case 9: return Double.NEGATIVE_INFINITY; case 10: return n / 10.0;
            default: return n;
        }
    }
    private static String string(Genes g) {
        int mode = g.pick(16), n = g.next();
        String digits = Long.toString(Math.abs((long)n));
        String sign = new String[]{"", "-", "+", "--"}[g.pick(4)];
        switch (mode) {
            case 0: return null; case 1: return ""; case 2: return " ";
            case 3: return Integer.toString(n);
            case 4: return sign + digits;
            case 5: return sign + digits + "." + g.pick(1000);
            case 6: return sign + digits + "e" + g.next();
            case 7: return sign + "0x" + Long.toHexString(Math.abs((long)n));
            case 8: return sign + "0x8" + "0".repeat(g.pick(20));
            case 9: return sign + digits + "fFdDlL".charAt(g.pick(6));
            case 10: return " " + sign + digits + " ";
            case 11: return new String[]{"true", "false", "null", "NaN", "Infinity"}[g.pick(5)];
            case 12: return "a".repeat(g.pick(25));
            default:
                String alphabet = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ+-._ /\\\t\n";
                StringBuilder s = new StringBuilder();
                int length = g.pick(25);
                for (int i = 0; i < length; i++) s.append(alphabet.charAt(g.pick(alphabet.length())));
                return s.toString();
        }
    }
    private static Object value(Class<?> t, Genes g, int depth, Observation report) throws Exception {
        if (t == String.class || t == CharSequence.class) return string(g);
        if (t == Comparable.class) return "key" + g.pick(5);
        if (t == boolean.class || t == Boolean.class) return g.pick(2) == 0;
        if (t == char.class || t == Character.class) return (char)g.pick(128);
        if (t == byte.class || t == Byte.class) return number(g).byteValue();
        if (t == short.class || t == Short.class) return number(g).shortValue();
        if (t == int.class || t == Integer.class) return number(g).intValue();
        if (t == long.class || t == Long.class) return number(g).longValue();
        if (t == float.class || t == Float.class) return number(g).floatValue();
        if (t == double.class || t == Double.class || t == Number.class) return number(g).doubleValue();
        if (t.isEnum()) {
            Object[] constants = t.getEnumConstants();
            return constants.length == 0 ? null : constants[g.pick(constants.length)];
        }
        if (t == Object.class) return g.pick(3) == 0 ? null : "object" + g.pick(5);
        if (depth >= 3) { report.nullFallbacks++; return null; }
        if (t.isArray()) {
            int length = g.pick(6);
            Object array = Array.newInstance(t.getComponentType(), length);
            for (int i = 0; i < length; i++) Array.set(array, i, value(t.getComponentType(), g, depth + 1, report));
            return array;
        }
        if (t == List.class || t == Collection.class || t == Iterable.class || t == Set.class) {
            Collection<Object> items = t == Set.class ? new LinkedHashSet() : new ArrayList();
            int size = g.pick(5);
            for (int i = 0; i < size; i++) items.add("item" + g.pick(5));
            return items;
        }
        if (t == Map.class) {
            Map<Object, Object> items = new LinkedHashMap();
            int size = g.pick(5);
            for (int i = 0; i < size; i++) items.put("key" + g.pick(5), number(g));
            return items;
        }
        if (t == java.util.Date.class) return new java.util.Date(g.next() * 86400000L);
        if (t == Class.class) return String.class;
        if (t == java.lang.reflect.Field.class) {
            Field[] fields = GenericInput.class.getFields();
            g.lastField = fields[g.pick(fields.length)];
            return g.lastField;
        }
        if (t == java.lang.reflect.Type.class) {
            if (g.lastField != null && g.pick(3) == 0)
                return g.lastField.getDeclaringClass();
            Field[] fields = GenericInput.class.getFields();
            return fields[g.pick(fields.length)].getGenericType();
        }
        if (t == java.io.Reader.class || t == java.io.BufferedReader.class
                || t == java.io.StringReader.class) {
            String content = "header,value\n" + string(g) + "," + number(g) + "\n"
                + "alpha,beta\n";
            StringReader reader = new StringReader(content);
            return t == java.io.BufferedReader.class ? new BufferedReader(reader) : reader;
        }
        if (t.getName().equals("org.apache.commons.csv.CSVFormat")) {
            Class<?> format = load("org.apache.commons.csv.CSVFormat");
            for (String fieldName : new String[]{"DEFAULT", "RFC4180", "EXCEL"}) try {
                Object result = format.getField(fieldName).get(null);
                if (t.isInstance(result)) return result;
            } catch (ReflectiveOperationException ignored) { }
            for (Method factory : format.getMethods())
                if (Modifier.isStatic(factory.getModifiers()) && factory.getParameterTypes().length == 0
                        && t.isAssignableFrom(factory.getReturnType())) try {
                    return factory.invoke(null);
                } catch (ReflectiveOperationException ignored) { }
        }
        if (t.getName().equals("com.google.javascript.jscomp.SourceFile")) {
            Class<?> source = load("com.google.javascript.jscomp.SourceFile");
            for (Method factory : source.getMethods())
                if (Modifier.isStatic(factory.getModifiers()) && factory.getName().equals("fromCode")
                        && factory.getParameterTypes().length == 2 && factory.getParameterTypes()[0] == String.class
                        && factory.getParameterTypes()[1] == String.class) {
                    String replaySource = System.getProperty("de.generated.source");
                    if (replaySource != null) {
                        try {
                            report.generatedSource = replaySource;
                            return factory.invoke(null, "de-input.js", replaySource);
                        } catch (ReflectiveOperationException ignored) { }
                    }
                    String[] unusedParameterScripts = {
                        "window.f = function(a) {};",
                        "window.f = function(a, b) { return b; };",
                        "window.f = function(a, b) { var used = b; return used; };",
                        "window['f'] = function(unused) {};",
                        "window.f = function(unused, value) { return value; };",
                        "window['f'] = function(unused, value) { return value; };",
                        "window.f = function(first, unused, last) { return last; };",
                        "window.f = function(unused) { var local = 1; return local; };",
                        "window.f = function(unused, value) { var alias = value; return alias; };",
                        "window.f = function(unused, value) { if (value) { return 1; } return 2; };",
                        "window.f = function(unused, value) { value = value + 1; return value; };",
                        "window.f = function(unused, value) { return function() { return value; }; };",
                        "window.f = function(unused) { function inner() { return 1; } return inner(); };",
                        "window.f = function(a, b, unused) { return a + b; };",
                        "window.f = function(a, unused, b, c) { return a + c; };"
                    };
                    String[] catchDependencyScripts = {
                        "window.f = function() { var saved; try { throw Error('x'); } catch (caught) { saved = caught; } return saved.stack; };",
                        "window.f = function(flag) { var saved; try { if (flag) throw Error('x'); } catch (caught) { saved = caught; } return saved.message; };",
                        "window.f = function() { var saved; try { throw Error('x'); } catch (caught) { saved = caught; } return saved.name; };",
                        "window.f = function() { var saved; try { throw Error('x'); } catch (caught) { saved = caught; } return String(saved); };",
                        "window.f = function(flag) { var saved; try { if (flag) throw Error('x'); } catch (problem) { saved = problem; } return saved.stack; };",
                        "window.f = function() { var saved; try { throw Error('x'); } catch (problem) { saved = problem; } return saved.message; };"
                    };
                    String[] genericScripts = {
                        "function f(unused, used) { var local = 1; return used; } f(1, 2);",
                        "function f() { var unused = 1; var used = 2; return used; } f();",
                        "function f(x) { var first = x; first = 3; return x; } f(2);",
                        "function f() { var unused = 1; } f();",
                        "function keep() { var dead = 1; return 7; } keep();"
                    };
                    String modified = System.getProperty("de.modified.classes", "");
                    String[] scripts;
                    if (modified.contains("RemoveUnusedVars") && modified.contains("FlowSensitiveInlineVariables")) {
                        scripts = new String[unusedParameterScripts.length + catchDependencyScripts.length];
                        System.arraycopy(unusedParameterScripts, 0, scripts, 0, unusedParameterScripts.length);
                        System.arraycopy(catchDependencyScripts, 0, scripts, unusedParameterScripts.length,
                            catchDependencyScripts.length);
                    }
                    else if (modified.contains("FlowSensitiveInlineVariables")) scripts = catchDependencyScripts;
                    else if (modified.contains("RemoveUnusedVars")) scripts = unusedParameterScripts;
                    else scripts = genericScripts;
                    try {
                        String code = scripts[g.pick(scripts.length)];
                        report.generatedSource = code;
                        return factory.invoke(null, "de-input.js", code);
                    }
                    catch (ReflectiveOperationException ignored) { }
                }
        }
        if (t.getName().equals("com.google.javascript.jscomp.CompilerOptions")) {
            try {
                Object options = t.getConstructor().newInstance();
                // In Closure Compiler, unused-variable passes are enabled by
                // CompilationLevel, rather than by a CompilerOptions enum
                // setter. Apply the real public configuration when available.
                try {
                    Class<?> levelType = load("com.google.javascript.jscomp.CompilationLevel");
                    Object advanced = levelType.getField("ADVANCED_OPTIMIZATIONS").get(null);
                    for (Method configure : levelType.getMethods())
                        if (configure.getName().equals("setOptionsForCompilationLevel")
                                && configure.getParameterTypes().length == 1
                                && configure.getParameterTypes()[0].isInstance(options)) {
                            configure.invoke(advanced, options); break;
                        }
                } catch (ReflectiveOperationException ignored) { }
                // Also set the relevant options directly for Closure releases
                // whose compilation-level helper no longer enables this pass.
                for (Class<?> current = t; current != null; current = current.getSuperclass())
                    for (Field field : current.getDeclaredFields()) {
                        String name = field.getName().toLowerCase(Locale.ROOT);
                        if (field.getType() == boolean.class && name.equals("removeglobals")) try {
                            // Closure-1 specifically guards argument removal
                            // when globals are preserved. Keep the optimization
                            // pass enabled while exercising that configuration.
                            field.setAccessible(true); field.setBoolean(options, false);
                        } catch (Exception ignored) { }
                        if (field.getType() == boolean.class
                                && (name.contains("removeunusedvar") || name.contains("removeunusedlocal"))) try {
                            field.setAccessible(true); field.setBoolean(options, true);
                        } catch (Exception ignored) { }
                    }
                for (Method setter : t.getMethods()) {
                    if (!Modifier.isPublic(setter.getModifiers()) || !setter.getName().startsWith("set")
                            || setter.getParameterTypes().length != 1) continue;
                    String name = setter.getName().toLowerCase(Locale.ROOT);
                    if (setter.getParameterTypes()[0] == boolean.class && name.contains("removeglobals")) {
                        try { setter.invoke(options, false); } catch (ReflectiveOperationException ignored) { }
                    } else if (setter.getParameterTypes()[0] == boolean.class
                            && (name.contains("removeunusedvar") || name.contains("removeunusedlocal"))) {
                        try { setter.invoke(options, true); } catch (ReflectiveOperationException ignored) { }
                    } else if (name.contains("optimizationlevel")
                            && setter.getParameterTypes()[0].isEnum()) {
                        Object[] values = setter.getParameterTypes()[0].getEnumConstants();
                        for (Object value : values) if (String.valueOf(value).contains("ADVANCED"))
                            try { setter.invoke(options, value); } catch (ReflectiveOperationException ignored) { }
                    }
                }
                return options;
            } catch (ReflectiveOperationException ignored) { }
        }
        if (t.getName().equals("com.google.javascript.rhino.Node")) {
            try {
                Class<?> ir = load("com.google.javascript.rhino.IR");
                for (String factoryName : new String[]{"script", "root", "name", "string"})
                    for (Method factory : ir.getMethods())
                        if (Modifier.isStatic(factory.getModifiers()) && factory.getName().equals(factoryName)
                                && factory.getParameterTypes().length == 0 && t.isAssignableFrom(factory.getReturnType()))
                            return factory.invoke(null);
            } catch (ReflectiveOperationException ignored) { }
        }
        if (t.getName().equals("com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser")) {
            Object parser = xmlParser(g, report);
            if (parser != null && t.isInstance(parser)) return parser;
        }
        if (t.getName().equals("com.fasterxml.jackson.databind.ser.BeanPropertyWriter")
                || t.getName().equals("com.fasterxml.jackson.databind.ser.impl.UnwrappingBeanPropertyWriter")) {
            Object writer = jacksonWriter(t, g, report);
            if (writer != null && t.isInstance(writer)) return writer;
        }
        if (t == java.awt.Graphics2D.class || t == java.awt.Graphics.class)
            return new java.awt.image.BufferedImage(80, 80, java.awt.image.BufferedImage.TYPE_INT_ARGB).createGraphics();
        if (java.awt.Paint.class.isAssignableFrom(t)) {
            java.awt.Color c = new java.awt.Color(g.pick(256), g.pick(256), g.pick(256));
            if (t.isInstance(c)) return c;
        }
        if (java.awt.Stroke.class.isAssignableFrom(t)) {
            java.awt.BasicStroke s = new java.awt.BasicStroke(g.pick(10) / 2.0f);
            if (t.isInstance(s)) return s;
        }
        if (java.awt.Shape.class.isAssignableFrom(t)) {
            java.awt.Shape s = new java.awt.geom.Rectangle2D.Double(g.next(), g.next(), g.pick(80), g.pick(80));
            if (t.isInstance(s)) return s;
        }
        if (t == java.awt.geom.Point2D.class) return new java.awt.geom.Point2D.Double(g.next(), g.next());
        if (t.getName().equals("org.apache.commons.cli.CommandLine"))
            return commandLine(g, report);
        Object domain = chart(t, g, report);
        if (domain != null) return domain;
        Object language = language(t, g, report);
        if (language != null) return language;
        List<Constructor<?>> ctors = constructors(t);
        // Older Java libraries often use public singleton constants in place of enums.
        if (ctors.isEmpty()) {
            List<Field> constants = new ArrayList();
            for (Field field : t.getFields())
                if (Modifier.isStatic(field.getModifiers()) && Modifier.isFinal(field.getModifiers())
                        && t.isAssignableFrom(field.getType())) constants.add(field);
            Collections.sort(constants, new Comparator<Field>() {
                public int compare(Field a, Field b) { return a.getName().compareTo(b.getName()); }
            });
            if (!constants.isEmpty()) {
                Object constant = constants.get(g.pick(constants.size())).get(null);
                if (constant != null) return constant;
            }
        }
        if (!ctors.isEmpty()) {
            Constructor<?> ctor = ctors.get(g.pick(ctors.size()));
            try { return ctor.newInstance(arguments(ctor.getParameterTypes(), g, depth + 1, report)); }
            catch (Exception ignored) { }
        }
        report.nullFallbacks++;
        return null;
    }
    private static Object language(Class<?> t, Genes g, Observation report) {
        if (!t.getName().equals("org.apache.commons.lang3.time.FastDateFormat")) return null;
        try {
            Method factory = t.getMethod("getInstance", String.class, java.util.TimeZone.class,
                java.util.Locale.class);
            String[] patterns = {"yyyy-MM-dd", "MM/dd/yy HH:mm:ss", "EEE, d MMM yyyy HH:mm:ss Z"};
            return factory.invoke(null, patterns[g.pick(patterns.length)],
                java.util.TimeZone.getTimeZone("UTC"), java.util.Locale.US);
        } catch (ReflectiveOperationException ignored) { }
        try { return t.getMethod("getInstance", String.class).invoke(null, "yyyy-MM-dd"); }
        catch (ReflectiveOperationException ignored) { return null; }
    }
    private static Object xmlParser(Genes g, Observation report) {
        try {
            Class<?> factoryType = load("com.fasterxml.jackson.dataformat.xml.XmlFactory");
            Object factory = factoryType.getConstructor().newInstance();
            String[] docs = {"<root><value>1</value><name>x</name></root>",
                "<root value=\"42\"><item>a</item><item>b</item></root>",
                "<root/>"};
            String xml = docs[g.pick(docs.length)];
            for (Method method : factoryType.getMethods()) {
                if (!method.getName().equals("createParser") || method.getParameterTypes().length != 1) continue;
                Class<?> p = method.getParameterTypes()[0];
                Object input = p == String.class ? xml : p == Reader.class ? new StringReader(xml)
                    : p == InputStream.class ? new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8)) : null;
                if (input == null) continue;
                try {
                    Object parser = method.invoke(factory, input);
                    if (parser != null) {
                        int advance = g.pick(4);
                        Method next = parser.getClass().getMethod("nextToken");
                        for (int i = 0; i < advance; i++) if (next.invoke(parser) == null) break;
                        return parser;
                    }
                } catch (ReflectiveOperationException ignored) { }
            }
        } catch (Throwable ignored) { }
        return null;
    }
    private static Object jacksonWriter(Class<?> requested, Genes g, Observation report) {
        try {
            Class<?> mapperType = load("com.fasterxml.jackson.databind.ObjectMapper");
            Object mapper = mapperType.getConstructor().newInstance();
            Object bean = new GenericInput();
            Class<?> javaTypeType = load("com.fasterxml.jackson.databind.JavaType");
            Object javaType = mapperType.getMethod("constructType", Type.class).invoke(mapper, bean.getClass());
            // Jackson 2.6 (used by this Defects4J project) exposes a provider
            // blueprint from ObjectMapper. Create a configured provider via
            // DefaultSerializerProvider, the supported API used by ObjectMapper.
            Object providerBlueprint = mapperType.getMethod("getSerializerProvider").invoke(mapper);
            Class<?> serializationConfigType = load("com.fasterxml.jackson.databind.SerializationConfig");
            Class<?> serializerFactoryType = load("com.fasterxml.jackson.databind.ser.SerializerFactory");
            Object config = mapperType.getMethod("getSerializationConfig").invoke(mapper);
            Object factory = mapperType.getMethod("getSerializerFactory").invoke(mapper);
            Class<?> defaultProviderType = load("com.fasterxml.jackson.databind.ser.DefaultSerializerProvider");
            Method createProvider = defaultProviderType.getMethod("createInstance",
                serializationConfigType, serializerFactoryType);
            Object provider = createProvider.invoke(providerBlueprint, config, factory);
            g.jacksonBean = bean;
            g.jacksonProvider = provider;
            g.jacksonOutput = new StringWriter();
            Object jsonFactory = mapperType.getMethod("getFactory").invoke(mapper);
            for (String factoryMethod : new String[]{"createGenerator", "createJsonGenerator"}) {
                try {
                    Method createGenerator = jsonFactory.getClass().getMethod(factoryMethod, Writer.class);
                    g.jacksonGenerator = createGenerator.invoke(jsonFactory, g.jacksonOutput);
                    break;
                } catch (NoSuchMethodException ignored) { }
            }
            if (g.jacksonGenerator == null)
                throw new NoSuchMethodException("JsonFactory.createGenerator(Writer) or createJsonGenerator(Writer)");
            Class<?> providerType = load("com.fasterxml.jackson.databind.SerializerProvider");
            Class<?> beanPropertyType = load("com.fasterxml.jackson.databind.BeanProperty");
            Method find = providerType.getMethod("findValueSerializer", javaTypeType, beanPropertyType);
            Object serializer = find.invoke(provider, new Object[]{javaType, null});
            List<Object> writers = new ArrayList();
            try {
                // Available on Jackson 2.6 and newer.
                Class<?> serializerType = load("com.fasterxml.jackson.databind.JsonSerializer");
                Method properties = serializerType.getMethod("properties");
                Iterator<?> it = (Iterator<?>)properties.invoke(serializer);
                while (it.hasNext()) {
                    Object item = it.next();
                    if (item != null && item.getClass().getName().endsWith("BeanPropertyWriter"))
                        writers.add(item);
                }
            } catch (NoSuchMethodException oldJackson) {
                // JacksonDatabind-1 predates JsonSerializer.properties(). Its
                // BeanSerializerBase stores writers in the protected _props
                // array; read that array only for these old releases.
                Class<?> base = load("com.fasterxml.jackson.databind.ser.std.BeanSerializerBase");
                if (!base.isInstance(serializer))
                    throw new IllegalStateException("Expected BeanSerializerBase, got "
                        + serializer.getClass().getName(), oldJackson);
                Field props = base.getDeclaredField("_props");
                props.setAccessible(true);
                Object array = props.get(serializer);
                for (int i = 0; i < Array.getLength(array); i++) {
                    Object item = Array.get(array, i);
                    if (item != null && item.getClass().getName().endsWith("BeanPropertyWriter"))
                        writers.add(item);
                }
            }
            if (writers.isEmpty())
                throw new IllegalStateException("ObjectMapper produced no bean property writers for DEReplay.GenericInput");
            Object writer = writers.get(g.pick(writers.size()));
            boolean requireUnwrapping = requested.getName().equals(
                "com.fasterxml.jackson.databind.ser.impl.UnwrappingBeanPropertyWriter");
            if (!requireUnwrapping && g.pick(2) == 0 && requested.isInstance(writer)) return writer;
            Class<?> transformerType = load("com.fasterxml.jackson.databind.util.NameTransformer");
            Object nop = transformerType.getField("NOP").get(null);
            for (Method m : writer.getClass().getMethods())
                if (m.getName().equals("unwrappingWriter") && m.getParameterTypes().length == 1
                        && m.getParameterTypes()[0].isInstance(nop)) {
                    Object unwrapped = m.invoke(writer, nop);
                    if (requested.isInstance(unwrapped)) return unwrapped;
                }
            if (requested.isInstance(writer)) return writer;
            throw new IllegalStateException("Generated Jackson property writer is not " + requested.getName());
        } catch (Throwable failure) {
            throw new IllegalStateException("Cannot construct Jackson BeanPropertyWriter: " + failure, failure);
        }
    }
    /** Build the non-constructible Commons CLI result through its public Parser API. */
    private static Object commandLine(Genes g, Observation report) throws Exception {
        Class<?> optionsClass = load("org.apache.commons.cli.Options");
        Class<?> optionClass = load("org.apache.commons.cli.Option");
        Class<?> parserClass = load("org.apache.commons.cli.PosixParser");
        Object options = optionsClass.getConstructor().newInstance();
        Method addOption = optionsClass.getMethod("addOption", optionClass);
        int numberOfOptions = 1 + g.pick(3);
        List<String> spellings = new ArrayList();
        for (int i = 0; i < numberOfOptions; i++) {
            String shortName = String.valueOf((char)('a' + i));
            String longName = "de-option-" + i;
            boolean hasArgument = g.pick(2) == 0;
            Object option = null;
            try {
                option = optionClass.getConstructor(String.class, String.class, boolean.class, String.class)
                    .newInstance(shortName, longName, hasArgument, "DE-generated option");
            } catch (NoSuchMethodException ignored) { }
            if (option == null) try {
                option = optionClass.getConstructor(String.class, boolean.class, String.class)
                    .newInstance(shortName, hasArgument, "DE-generated option");
            } catch (NoSuchMethodException ignored) { }
            if (option == null) throw new NoSuchMethodException("No supported Commons CLI Option constructor");
            addOption.invoke(options, option);
            spellings.add("-" + shortName);
            if (hasArgument) spellings.add("value-" + Math.abs((long)g.next()));
        }
        String[] argv = spellings.toArray(new String[0]);
        Object parser = parserClass.getConstructor().newInstance();
        List<Method> parseMethods = new ArrayList();
        for (Method candidate : parserClass.getMethods()) {
            Class<?>[] p = candidate.getParameterTypes();
            if (candidate.getName().equals("parse") && p.length >= 2 && p[0] == optionsClass
                    && p[1] == String[].class && candidate.getReturnType() == load("org.apache.commons.cli.CommandLine"))
                parseMethods.add(candidate);
        }
        Collections.sort(parseMethods, new Comparator<Method>() {
            public int compare(Method a, Method b) {
                return a.getParameterTypes().length - b.getParameterTypes().length;
            }
        });
        for (Method parse : parseMethods) {
            Object[] args = new Object[parse.getParameterTypes().length];
            Class<?>[] p = parse.getParameterTypes();
            args[0] = options; args[1] = argv;
            for (int i = 2; i < p.length; i++) {
                if (p[i] == boolean.class || p[i] == Boolean.class) args[i] = g.pick(2) == 0;
                else if (p[i] == java.util.Properties.class) args[i] = new java.util.Properties();
                else args[i] = value(p[i], g, 1, report);
            }
            try { return parse.invoke(parser, args); }
            catch (InvocationTargetException ignored) { }
        }
        throw new NoSuchMethodException("No successful public PosixParser.parse(Options,String[])");
    }
    /** Optional type recipes, shared across bugs; none contains a bug-specific expected answer. */
    private static Object chart(Class<?> t, Genes g, Observation report) throws Exception {
        String n = t.getName();
        if (!n.startsWith("org.jfree.")) return null;
        if (n.equals("org.jfree.data.Range")) {
            double a = g.next(), b = g.next();
            return t.getConstructor(double.class, double.class).newInstance(Math.min(a, b), Math.max(a, b));
        }
        if (n.equals("org.jfree.data.time.RegularTimePeriod"))
            return load("org.jfree.data.time.Day").getConstructor(int.class, int.class, int.class)
                .newInstance(1 + g.pick(28), 1 + g.pick(12), 1990 + g.pick(40));
        if (n.equals("org.jfree.data.time.TimeSeries")) {
            Object series = t.getConstructor(Comparable.class).newInstance("DE");
            Class<?> period = load("org.jfree.data.time.RegularTimePeriod");
            Constructor<?> day = load("org.jfree.data.time.Day")
                .getConstructor(int.class, int.class, int.class);
            Method add = t.getMethod("add", period, double.class);
            int count = 2 + g.pick(4), year = 1990 + g.pick(40);
            for (int i = 0; i < count; i++)
                add.invoke(series, day.newInstance(i + 1, 1, year), g.next() / 10.0);
            return series;
        }
        if (n.equals("org.jfree.data.category.CategoryDataset")
                || n.equals("org.jfree.data.category.DefaultCategoryDataset")) {
            Class<?> c = load("org.jfree.data.category.DefaultCategoryDataset");
            Object data = c.getConstructor().newInstance();
            Method add = c.getMethod("addValue", Number.class, Comparable.class, Comparable.class);
            int rows = 1 + g.pick(3), columns = 1 + g.pick(3);
            for (int r = 0; r < rows; r++) for (int col = 0; col < columns; col++)
                add.invoke(data, Double.valueOf(g.next() / 10.0), "R" + r, "C" + col);
            return data;
        }
        if (n.equals("org.jfree.data.xy.XYDataset") || n.equals("org.jfree.data.xy.XYSeriesCollection")) {
            Class<?> seriesClass = load("org.jfree.data.xy.XYSeries");
            Object series = seriesClass.getConstructor(Comparable.class).newInstance("DE");
            int count = 1 + g.pick(5);
            for (int i = 0; i < count; i++) seriesClass.getMethod("add", double.class, double.class)
                .invoke(series, (double)i, g.next() / 10.0);
            Class<?> c = load("org.jfree.data.xy.XYSeriesCollection");
            Object data = c.getConstructor().newInstance();
            c.getMethod("addSeries", seriesClass).invoke(data, series);
            return data;
        }
        if (n.equals("org.jfree.data.general.PieDataset") || n.equals("org.jfree.data.general.DefaultPieDataset")) {
            Class<?> c = load("org.jfree.data.general.DefaultPieDataset");
            Object data = c.getConstructor().newInstance();
            int count = 1 + g.pick(5);
            for (int i = 0; i < count; i++) c.getMethod("setValue", Comparable.class, Number.class)
                .invoke(data, "K" + i, Double.valueOf(g.next() / 10.0));
            return data;
        }
        return null;
    }
    static List<Method> setupMethods(Class<?> receiver) {
        List<Method> methods = new ArrayList();
        for (Method m : receiver.getMethods()) {
            String n = m.getName();
            if (!Modifier.isStatic(m.getModifiers()) && !m.isSynthetic()
                    && m.getParameterTypes().length <= 3 && !n.contains("Listener")
                    && (n.startsWith("set") || n.startsWith("add") || n.startsWith("update")
                        || n.startsWith("remove") || n.equals("clear"))) methods.add(m);
        }
        Collections.sort(methods, new Comparator<Method>() {
            public int compare(Method a, Method b) {
                return signature(a).compareTo(signature(b));
            }
        });
        return methods;
    }
    public static Observation execute(String target, String receivers, String signature, int[] genes) {
        Observation out = new Observation();
        try {
            Genes g = new Genes(genes);
            Method m = method(target, signature);
            Object receiver = null;
            if (!Modifier.isStatic(m.getModifiers())) {
                String[] choices = receivers.split(",");
                Class<?> receiverType = load(choices[g.pick(choices.length)]);
                receiver = value(receiverType, g, 0, out);
                if (receiver == null) throw new IllegalArgumentException("Receiver construction failed");
                // Compiler.compile owns a strict initialization sequence.
                // Random calls to its mutators before compilation can corrupt
                // state or spend the search budget on irrelevant setup.
                if (!receiverType.getName().equals("com.google.javascript.jscomp.Compiler")) {
                    List<Method> setup = setupMethods(receiverType);
                    int count = g.pick(5);
                    for (int i = 0; i < count && !setup.isEmpty(); i++) {
                        Method s = setup.get(g.pick(setup.size()));
                        try { s.invoke(receiver, arguments(s.getParameterTypes(), g, 0, out)); out.setupCalls++; }
                        catch (Exception e) { out.setupFailures++; }
                    }
                }
            }
            Object[] args = arguments(m, g, 0, out);
            out.reachedTarget = true;
            try {
                boolean jacksonSerialization = m.getDeclaringClass().getName().equals(
                    "com.fasterxml.jackson.databind.ser.BeanPropertyWriter")
                    && m.getName().startsWith("serializeAs") && g.jacksonGenerator != null;
                boolean arrayShape = m.getName().contains("Column")
                    || m.getName().contains("Element") || m.getName().contains("Placeholder");
                if (jacksonSerialization)
                    g.jacksonGenerator.getClass().getMethod(arrayShape
                        ? "writeStartArray" : "writeStartObject").invoke(g.jacksonGenerator);
                Object result = m.invoke(receiver, args);
                boolean closureCompile = m.getDeclaringClass().getName().equals(
                    "com.google.javascript.jscomp.Compiler") && m.getName().equals("compile");
                if (closureCompile) {
                    // Result is only a status object; the compiled JavaScript is
                    // the behavioral output that reveals whether an argument
                    // was removed from a globally exposed function.
                    Object js = receiver.getClass().getMethod("toSource").invoke(receiver);
                    out.token = "CLOSURE_SOURCE:" + stable(js, 0);
                } else if (jacksonSerialization) {
                    g.jacksonGenerator.getClass().getMethod(arrayShape
                        ? "writeEndArray" : "writeEndObject").invoke(g.jacksonGenerator);
                    g.jacksonGenerator.getClass().getMethod("flush").invoke(g.jacksonGenerator);
                    out.token = "JSON:" + Base64.getEncoder().encodeToString(
                        g.jacksonOutput.toString().getBytes(StandardCharsets.UTF_8));
                } else out.token = m.getReturnType() == void.class
                    ? state(receiver, m.getName()) : stable(result, 0);
            } catch (InvocationTargetException e) {
                if (e.getCause() instanceof VirtualMachineError || e.getCause() instanceof LinkageError
                        || e.getCause() instanceof ThreadDeath) throw e;
                out.token = "THROW:" + e.getCause().getClass().getName();
            }
        } catch (Throwable e) {
            out.token = "HARNESS_ERROR";
            out.error = e.getClass().getName() + ":" + String.valueOf(e.getMessage());
        }
        return out;
    }
    public static String run(String target, String receivers, String signature, int[] genes) {
        Observation o = execute(target, receivers, signature, genes);
        if (!o.reachedTarget || o.token.equals("HARNESS_ERROR"))
            throw new AssertionError("Cannot replay test: " + o.error);
        return o.token;
    }
    private static String state(Object receiver, String method) {
        if (receiver == null) return "VOID";
        List<String> getters = new ArrayList();
        if (method.startsWith("set") && method.length() > 3) {
            getters.add("get" + method.substring(3)); getters.add("is" + method.substring(3));
        }
        getters.addAll(Arrays.asList("getItemCount", "getRowCount", "getColumnCount", "getSeriesCount"));
        StringBuilder s = new StringBuilder("VOID");
        for (String name : getters) {
            try {
                Method getter = receiver.getClass().getMethod(name);
                if (getter.getReturnType().isPrimitive() || getter.getReturnType() == String.class)
                    s.append('|').append(name).append('=').append(stable(getter.invoke(receiver), 0));
            } catch (ReflectiveOperationException ignored) { }
        }
        return s.toString();
    }
    /** Only whitelisted value types are rendered. Never use arbitrary object toString(). */
    static String stable(Object value, int depth) {
        if (value == null) return "NULL";
        Class<?> t = value.getClass();
        if (value instanceof String || value instanceof Boolean || value instanceof Character
                || value instanceof Byte || value instanceof Short || value instanceof Integer
                || value instanceof Long || value instanceof Float || value instanceof Double
                || value instanceof java.math.BigInteger || value instanceof java.math.BigDecimal)
            return t.getName() + ":" + Base64.getEncoder().encodeToString(value.toString().getBytes(StandardCharsets.UTF_8));
        if (value instanceof Enum) return "ENUM:" + t.getName() + ":" + ((Enum<?>)value).name();
        if (t.isArray() && depth < 3) {
            StringBuilder s = new StringBuilder("ARRAY:" + t.getName() + ":" + Array.getLength(value));
            for (int i = 0; i < Math.min(64, Array.getLength(value)); i++) {
                String item = stable(Array.get(value, i), depth + 1);
                s.append(':').append(item.length()).append(':').append(item);
            }
            return s.toString();
        }
        if (value instanceof java.awt.Color) return "COLOR:" + ((java.awt.Color)value).getRGB();
        // Observe safe scalar properties of returned objects. This catches
        // changes to value caches and state while avoiding identity-based toString().
        StringBuilder observed = new StringBuilder("STATE:" + t.getName());
        int properties = 0;
        for (String name : Arrays.asList("getItemCount", "getMinY", "getMaxY",
                "getRowCount", "getColumnCount", "getSeriesCount")) {
            try {
                Method getter = t.getMethod(name);
                Class<?> r = getter.getReturnType();
                if (!r.isPrimitive() && r != String.class && !Number.class.isAssignableFrom(r))
                    continue;
                if (r == void.class) continue;
                Object result = getter.invoke(value);
                String token = stable(result, depth + 1);
                observed.append('|').append(name).append('=').append(token.length())
                    .append(':').append(token);
                properties++;
            } catch (Exception ignored) { }
        }
        return properties == 0 ? "TYPE:" + t.getName() : observed.toString();
    }
    public static void main(String[] args) {
        if (args.length > 4) {
            String source = new String(Base64.getDecoder().decode(args[4]), StandardCharsets.UTF_8);
            System.setProperty("de.generated.source", source);
        }
        String[] encodedGenes = args[3].split(",");
        int[] genes = new int[encodedGenes.length];
        for (int i = 0; i < encodedGenes.length; i++) genes[i] = Integer.parseInt(encodedGenes[i]);
        boolean closureCompile = args[0].equals("com.google.javascript.jscomp.Compiler")
            && args[2].startsWith("compile(");
        // Compiler.compile is an expensive whole-program operation. Fixed-side
        // suites are still executed twice by the runner, so capture its oracle
        // once here instead of launching three compilations just to check the
        // same deterministic source output.
        int repetitions = closureCompile ? 1 : 3;
        for (int i = 0; i < repetitions; i++) {
            Observation out = execute(args[0], args[1], args[2], genes);
            System.out.println("DE_TOKEN:" + Base64.getEncoder().encodeToString(out.token.getBytes(StandardCharsets.UTF_8)));
        }
    }
}

public class DEGeneratedTest {
    @org.junit.Test(timeout=60000L)
    public void testDE00000() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "clear():void",
            new int[]{754,-951,-266,791,-500,-558,845,1000,-328,377,-1000,-1000,-1000,-829,-133,74,1000,904,1000,-1000,-683,658,1000,-828,-516,-400,708,-687,-639,-480,-269,-1000,-243,-41,-500,-160,308,1000,-187,588,-1000,1000,1000,26,842,-579,-995,-1000,-556,48,347,-1000,503,296,-1000,45,-995,812,289,-267,449,-120,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00001() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "clear():void",
            new int[]{-45,453,619,-238,-192,864,-1000,-23,1000,-919,733,-437,-356,242,3,624,-1000,505,128,750,-804,-1000,-1000,-275,1000,643,382,-319,259,-599,723,1000,2,937,577,1000,877,-411,981,-1000,640,117,712,177,-1000,655,275,675,429,-1000,-854,-538,1000,-831,1000,931,196,-459,-19,-1000,-796,-133,-91,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00002() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "clear():void",
            new int[]{-532,527,527,698,-69,-240,169,314,-349,152,8,199,743,549,-376,762,741,663,-1000,263,1000,729,968,-749,-872,-62,-1000,502,658,273,-1000,877,432,-506,-1000,641,579,137,-928,763,-956,-276,-889,-105,-601,-1000,-215,-622,-87,-186,-1000,-156,491,-446,734,419,780,-11,-1000,220,-437,-1000,77,-151}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00003() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "clear():void",
            new int[]{859,-369,156,-33,-859,394,84,-436,-485,377,90,-1000,-826,-492,-391,74,-878,-48,709,-1000,-683,-519,444,-903,-635,1000,-679,289,586,-480,-542,528,177,632,-736,194,-660,-865,142,796,-412,-444,-784,-62,842,-696,445,-1000,-179,-483,81,306,-105,579,-51,172,313,-1000,289,1000,373,-167,1000,-401}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00004() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "clear():void",
            new int[]{17,265,-508,1000,1000,-1000,342,1000,729,-712,190,1000,125,94,330,230,1000,1000,-36,-1000,-997,748,919,-1000,-1000,-1000,894,115,1000,161,-542,655,-1000,-1000,-736,-343,963,1000,-502,122,-903,350,1000,510,-1000,-802,-764,1000,-940,-533,-101,-1000,-429,-840,426,839,-1000,1000,755,-566,310,779,-944,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00005() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "clear():void",
            new int[]{-190,331,-266,-483,1000,-427,-772,743,106,-4,465,-1000,-704,-829,195,724,-1000,-1000,-58,-24,-1000,-1000,145,-213,-1000,-96,-685,-947,-639,-480,825,-178,-243,-41,-1000,-160,-469,-707,-899,-405,111,1000,1000,26,842,-1000,-614,-1000,327,1000,-764,679,1000,296,-1000,1000,242,-1000,-693,778,-1000,-1000,314,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00006() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "clear():void",
            new int[]{-13,55,457,1000,-798,900,370,-356,-658,462,593,207,-264,1000,-585,-885,1000,801,872,-30,1000,158,525,-6,-635,1000,-534,1000,1000,-583,-1000,1000,1000,41,-1000,410,97,-467,478,888,-658,66,-514,-135,111,-888,552,220,690,-277,-528,45,457,-504,217,127,584,125,-1000,557,1000,-1000,-348,-184}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00007() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "clear():void",
            new int[]{748,-530,-247,133,103,-119,308,207,882,-1000,790,-584,837,695,1000,57,-387,885,-1000,-1000,445,651,300,-20,-1000,1000,1000,54,1000,-839,-862,49,309,-3,-1000,525,327,-775,748,1000,-1000,815,-132,-121,-459,-960,-1000,767,540,-985,-814,329,365,-720,-225,273,1000,-171,-918,-566,-86,-207,258,-819}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00008() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "clear():void",
            new int[]{-887,-13,244,724,640,1000,-74,168,957,350,789,276,232,1000,-210,469,-965,571,-823,1000,844,-733,651,22,-817,147,-607,405,45,-510,-1000,683,783,-48,-1000,1000,-369,-1000,-122,613,-456,-560,-994,100,-431,-682,304,-633,899,1000,-1000,-524,-479,-75,1000,-258,699,63,-951,-566,-157,-1000,368,193}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00009() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "clear():void",
            new int[]{-24,-197,-597,1000,1000,-352,472,549,656,-641,-326,1000,8,1000,65,783,605,1000,-674,-262,-534,640,780,12,-872,-1000,-626,838,742,-599,-1000,1000,1000,36,-623,-87,456,627,139,-2,-753,-932,584,-346,-463,-639,-482,-334,-156,540,-1000,-1000,126,-1000,1000,-697,-791,1000,-213,-1000,-1000,-1000,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00010() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "clear():void",
            new int[]{1000,569,-1000,-766,-1000,261,690,-1000,255,904,-1000,-499,-65,-1000,-613,35,460,298,-191,361,-1000,752,-662,-1000,422,-344,577,-1000,128,-1000,203,-240,-852,269,-431,-1000,-617,-918,-134,688,-557,897,342,-31,-194,224,-504,-161,-383,-239,415,-1000,-633,-958,-587,-589,447,-965,-480,909,354,-258,1000,561}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00011() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.map.Flat3Map", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "clone():java.lang.Object",
            new int[]{43,377,868,192,-75,419,-245,161,923,-107,835,669,-153,226,20,-511,575,-313,190,543,-154,317,-12,-556,631,175,698,-825,-311,76,-137,244,827,687,-991,-615,307,-847,560,194,-90,259,-179,-25,176,-450,-203,-501,-435,787,-498,389,411,-325,420,396,-135,-134,833,-21,-677,-77,-174,277}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00012() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.map.Flat3Map", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "clone():java.lang.Object",
            new int[]{332,-57,194,413,-727,694,254,335,-101,72,-137,429,-1000,-1000,20,74,1000,-313,-368,543,83,-826,801,-556,-258,187,-716,259,-563,-584,-137,840,-850,27,-1000,887,-1000,-794,183,-1000,-589,259,-1000,-28,-663,-897,1000,199,732,-1000,-1000,804,1000,1000,420,-435,-883,494,-1000,858,967,274,536,-90}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00013() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.map.Flat3Map", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "clone():java.lang.Object",
            new int[]{-460,817,144,330,249,252,1000,-530,674,363,-876,-226,-573,-594,696,-518,1000,412,-161,17,105,957,1000,559,573,61,1000,-346,666,106,-421,-956,162,1000,-321,622,-1000,694,0,7,686,395,-559,1000,1000,830,-1000,1000,705,-52,-473,1000,873,1000,877,1000,-1000,428,1000,-1000,-71,-963,521,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00014() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.map.Flat3Map", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "clone():java.lang.Object",
            new int[]{-484,147,72,-267,-52,-53,-31,72,1000,-446,1000,-406,-251,-41,215,921,416,490,-1000,-786,358,811,-133,173,-284,1000,108,-606,751,-56,-451,-437,-663,780,-875,661,-100,-714,57,-169,198,1000,-124,213,-530,375,-622,-575,-1000,1000,-606,516,812,151,851,103,824,341,474,-224,-520,-487,336,-585}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00015() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.map.Flat3Map", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "clone():java.lang.Object",
            new int[]{-504,-325,417,-326,283,228,-691,72,969,-316,1000,-1000,-251,293,666,-218,931,899,881,-786,303,1000,71,1000,-215,963,905,-493,1000,-391,-538,-1000,-1000,1000,-1000,677,-605,686,-329,-559,290,831,-124,755,870,774,-1000,396,-1000,1000,-456,783,1000,-536,1000,254,415,542,207,-1000,-520,-676,530,-937}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00016() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.map.Flat3Map", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "clone():java.lang.Object",
            new int[]{-1000,967,-1000,624,-205,437,906,590,-1000,1000,240,234,-1000,12,-648,-546,128,-337,673,-1000,286,-553,-354,379,-148,159,-411,-81,414,-174,600,450,1000,-324,372,860,-623,-63,620,-524,985,-494,-598,-1000,-39,-200,715,-670,590,-981,-1000,1000,-320,1000,-140,764,-499,514,829,1000,546,653,-536,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00017() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.map.Flat3Map", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "clone():java.lang.Object",
            new int[]{1000,45,72,1000,1000,68,-1000,772,-1000,824,-1000,-950,395,220,1000,1000,-645,288,977,-1000,1000,-1000,-1000,-35,1000,172,14,752,643,-649,727,-768,-1000,1000,-420,55,1000,-183,1000,660,-496,-5,1000,-293,606,-1000,139,-1000,-743,-730,-1000,369,-259,-334,-1000,1000,-487,1000,-1000,-580,-328,237,-1000,561}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00018() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.map.Flat3Map", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "clone():java.lang.Object",
            new int[]{516,854,-681,998,346,-402,-456,1000,1000,976,689,-597,-981,461,-1000,1000,-1000,-447,784,-181,-1000,132,-993,75,1000,328,-547,-507,1000,-1000,1000,-380,617,939,-972,471,1000,488,108,-727,-535,-622,1000,1000,-27,-206,530,480,-1000,62,235,-407,603,-596,1000,-271,657,919,1000,-907,-512,1000,222,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00019() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.map.Flat3Map", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "clone():java.lang.Object",
            new int[]{382,587,719,845,242,65,-866,560,85,712,884,1000,-407,-142,-359,-3,-574,-780,-1000,80,-882,-101,291,-131,142,-405,744,-1000,-37,-247,495,-136,1000,-188,-259,-587,538,-313,-432,-557,95,448,370,-440,122,-755,158,1000,-724,251,479,125,103,991,-531,489,-909,592,999,403,-308,579,178,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00020() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.map.Flat3Map", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "clone():java.lang.Object",
            new int[]{-958,-485,394,384,104,441,-710,589,-634,798,-587,-546,221,703,241,-684,262,-271,637,788,-238,943,76,729,485,-562,-241,-923,571,623,-589,-996,108,293,263,587,-988,-236,397,-481,-220,-805,-504,-756,830,665,-147,-640,-753,-514,-550,-885,959,-168,874,394,-348,794,914,-264,-945,-311,-213,-417}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00021() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.map.Flat3Map", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "clone():java.lang.Object",
            new int[]{-504,-991,-811,-606,337,-382,-1000,-534,1000,1000,-797,-1000,-487,-661,933,314,1000,493,881,13,87,1000,505,1000,-406,521,407,-493,1000,-997,-1000,-1000,-1000,1000,-912,815,-648,1000,-1000,-559,490,-993,-139,1000,661,1000,-1000,1000,1000,979,464,43,1000,-117,1000,-628,346,542,-1000,-1000,153,-1000,1000,-956}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00022() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.map.Flat3Map", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "clone():java.lang.Object",
            new int[]{-460,817,663,-219,-627,252,1000,1000,674,-309,811,642,-846,70,-526,334,244,-726,953,-559,105,563,1000,-373,-1000,812,-1000,-346,-863,505,1000,894,-227,-1000,-610,1000,96,-1000,844,626,-512,408,-1000,-805,-606,-206,996,-460,307,-585,-287,-443,686,-78,63,-692,-27,2,-811,1000,627,419,50,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00023() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.map.Flat3Map", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "clone():java.lang.Object",
            new int[]{20,-139,68,255,-13,-179,-1000,-133,117,163,1000,24,-932,-998,-41,185,-20,-295,-77,-1000,-129,854,1000,-803,-1000,-275,831,-657,-750,-659,865,-445,-80,-582,-512,1000,20,1000,-970,-1000,-253,1000,-992,-20,761,795,589,718,-1000,-938,224,773,357,1000,1000,239,-781,1000,466,-42,790,-741,1000,-579}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00024() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.map.Flat3Map", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "clone():java.lang.Object",
            new int[]{925,-33,-774,577,-755,-537,-56,98,74,53,-391,177,-1000,-1000,-865,921,-34,-579,507,-1000,-167,56,632,-774,-856,68,-372,-560,-1000,-521,686,499,26,-199,-821,947,967,-1000,278,-443,-1000,107,-1000,-826,-1000,364,1000,-668,-579,-1000,33,-633,731,878,787,-1000,100,259,-618,773,1000,-730,723,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00025() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "containsKey(java.lang.Object):boolean",
            new int[]{829,-887,-146,190,-895,-706,-71,-209,290,902,-361,-285,-21,-199,312,294,944,-843,-147,205,106,148,-733,-413,-775,-409,791,835,32,487,261,124,982,-570,-611,-397,-952,-880,-417,362,66,793,-366,-216,-985,297,-829,-304,-682,736,121,-164,-242,148,-434,622,930,510,-612,-91,270,519,883,512}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00026() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "containsKey(java.lang.Object):boolean",
            new int[]{482,43,769,-123,-29,-88,303,123,964,-974,219,866,-490,414,-412,-76,-21,-76,-621,39,209,-269,111,915,724,1000,77,35,258,-957,-802,-212,-946,-532,-800,-923,1000,-545,-98,887,227,642,1000,-379,-54,-902,-247,-872,-576,-1000,764,-1,-735,1000,-772,270,376,835,-104,-486,124,-918,-574,456}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00027() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "containsKey(java.lang.Object):boolean",
            new int[]{786,-267,632,464,-877,118,471,-723,467,347,13,572,-658,-130,-121,-446,-60,-918,-1000,247,283,50,-420,239,374,871,1000,763,980,-322,50,-383,97,-1000,-1000,-1000,407,-1000,-553,863,789,891,880,-1000,-331,-353,-1000,-733,-599,-781,1000,-25,-278,1000,-748,386,328,1000,458,-964,-35,145,-656,264}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00028() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "containsKey(java.lang.Object):boolean",
            new int[]{-1000,-645,-274,338,-322,-49,-471,647,-288,384,1000,-800,403,1000,315,6,497,791,-927,469,-854,758,398,-1000,85,321,-287,513,-1000,1000,-798,710,-515,998,756,-176,-881,97,114,557,-974,34,616,684,1000,200,1000,727,1000,-586,-245,-405,160,819,63,779,1000,1000,-1000,1000,-358,-559,-307,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00029() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "containsKey(java.lang.Object):boolean",
            new int[]{-1000,-151,379,1000,251,641,-252,483,1000,719,880,-144,926,1000,-486,-838,631,1000,-913,434,-691,279,1000,-979,-16,-1000,1000,179,-768,1000,513,-655,-1000,909,-421,-828,269,-1000,199,167,-99,105,1000,115,1000,-1000,432,-389,-469,-457,-1000,1000,-1000,1000,-1000,390,-649,-894,-731,-793,-444,1000,-102,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00030() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "containsKey(java.lang.Object):boolean",
            new int[]{-691,-559,133,-635,328,-940,-144,-85,-860,-282,-121,86,658,-458,-929,974,706,-267,-989,653,-749,-404,597,-26,-676,35,-124,216,-378,744,954,870,-810,312,918,761,890,711,-349,-134,378,249,124,664,-739,-48,296,712,740,-448,129,198,-404,807,344,-292,-311,-324,-420,148,-733,-934,-645,841}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00031() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "containsKey(java.lang.Object):boolean",
            new int[]{-799,421,-494,-379,-927,179,704,-898,-644,124,543,-893,219,513,754,-915,-288,369,-679,182,-931,1000,-328,-1000,34,201,387,1000,-996,1000,373,222,-1000,1000,826,-35,1000,253,-618,16,-460,48,1000,-121,632,21,929,109,1000,362,526,1000,42,698,-410,181,-1000,362,-511,-170,-158,483,196,640}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00032() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "containsKey(java.lang.Object):boolean",
            new int[]{-401,563,-141,560,-859,944,973,-606,357,183,783,-950,678,99,744,-986,-572,39,-539,406,-385,756,-413,-976,-309,18,707,365,-44,688,249,-86,-238,932,611,-148,914,-488,-426,502,-273,701,824,-649,-887,-738,-76,265,732,138,456,661,-208,31,-806,808,-631,886,167,-809,-739,450,-744,909}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00033() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "containsKey(java.lang.Object):boolean",
            new int[]{944,135,488,1000,-1000,1000,-51,-1000,-13,-1000,1000,100,-192,-788,437,-1000,-1000,-399,-17,533,315,-446,-654,-180,179,1000,1000,480,1000,-560,478,-1000,-825,82,209,-298,6,-1000,-963,713,831,1000,1000,-1000,-793,-1000,-1000,-945,-959,361,1000,1000,-824,-455,-1000,153,-1000,1000,1000,-1000,-1000,527,-839,-654}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00034() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "containsKey(java.lang.Object):boolean",
            new int[]{295,742,969,117,-725,-758,-62,599,-152,68,944,465,-799,330,-591,271,549,577,305,907,-770,-552,446,232,780,-713,-38,-393,-947,-162,374,-6,-110,43,839,-872,-882,-720,-1000,491,734,964,646,-744,-14,-700,895,235,797,244,-999,-51,-538,196,-993,-641,879,842,-498,-410,-287,-339,-533,-20}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00035() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "containsKey(java.lang.Object):boolean",
            new int[]{944,279,-1000,-462,-1000,255,-16,-1000,87,-404,131,-1000,961,-471,966,-157,-68,-940,-949,533,-621,1000,-1000,-1000,-1000,1000,1000,1000,-44,1000,1000,794,-245,1000,925,701,1000,911,-660,-16,-379,557,280,-47,-133,662,-683,288,962,-342,-693,-494,624,-455,-353,931,-294,-514,98,-237,-45,527,-432,642}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00036() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "containsValue(java.lang.Object):boolean",
            new int[]{-663,-405,-282,275,181,195,872,-143,-693,-544,1000,-613,-282,-1000,606,886,-1000,-190,970,412,87,901,-424,-1000,-1000,-200,-206,-632,724,334,-99,-1000,-521,702,1000,-454,1000,-398,-97,-79,-400,1000,1000,516,400,305,-495,734,1000,1000,-17,-1000,-303,-212,696,682,678,140,-400,-539,427,-1000,-997,-24}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00037() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "containsValue(java.lang.Object):boolean",
            new int[]{-646,-901,-151,-796,853,1000,843,761,1000,1000,886,-225,-494,-411,882,-316,-1000,408,938,-9,203,1000,438,1000,-740,-1000,-1000,-218,-354,1000,1000,-749,-805,-1000,105,-272,944,-24,1000,800,486,905,-102,-749,88,1000,961,-255,491,1000,133,-1000,-36,-222,-260,-731,-276,-1000,1000,955,633,-393,-587,302}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00038() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "containsValue(java.lang.Object):boolean",
            new int[]{-155,441,-117,-1000,802,475,987,-483,-578,-745,157,-43,499,-227,1000,1000,-645,830,-779,439,-822,-1000,51,-1000,-1000,-567,385,-1000,1000,-755,138,196,-515,969,1000,-751,784,-97,-1000,164,723,-298,1000,308,-790,388,-165,-1000,1000,712,-456,-266,519,1000,1000,-81,-1000,-425,1000,-1000,96,-973,-313,-392}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00039() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "containsValue(java.lang.Object):boolean",
            new int[]{1000,891,-192,-1000,200,-98,1000,-167,149,1000,240,-374,-646,431,684,-265,-508,1000,-133,270,-1000,51,183,1000,-420,-1000,-1000,-1000,0,-348,792,1000,-954,-1000,488,-1000,221,678,1000,1000,1000,415,-75,-1000,-725,668,-1000,-239,-166,735,-60,-1000,-154,-18,-743,-1000,-1000,-1000,1000,-912,-1000,736,-87,-403}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00040() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "containsValue(java.lang.Object):boolean",
            new int[]{395,-315,-83,-544,915,965,864,371,749,727,458,-1000,665,-417,1000,49,-814,465,-1000,103,-1000,723,446,807,-841,-381,600,-646,241,-990,1000,-1000,-1000,-152,925,-989,909,-224,-790,1000,1000,969,210,133,-634,-113,561,-1000,333,-687,-1000,-1000,-814,954,796,-1000,-1000,-130,1000,-50,-356,-309,-478,-167}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00041() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "containsValue(java.lang.Object):boolean",
            new int[]{-497,-309,-250,-396,743,-12,738,-1000,250,575,381,148,-772,902,-882,713,-837,-682,813,-820,166,1000,-858,682,166,968,467,947,-389,-101,231,-592,307,-469,-838,676,-692,-671,111,335,111,243,-759,734,-189,46,-468,738,-849,-559,489,40,-700,-117,-480,-36,1000,178,-395,-640,250,176,-529,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00042() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "containsValue(java.lang.Object):boolean",
            new int[]{-133,-875,-733,81,565,-216,782,1000,1000,139,1000,-595,-244,-1000,725,319,-1000,-485,700,560,-364,1000,-579,-418,-1000,-743,-409,-742,440,-238,834,-1000,-1000,140,1000,-373,1000,-648,-368,830,214,724,1000,863,415,-396,-288,214,985,351,-327,787,-1000,151,505,589,679,-605,20,-644,-182,-867,-1000,-652}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00043() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "containsValue(java.lang.Object):boolean",
            new int[]{563,777,-397,-1000,951,402,1000,-167,-420,480,1000,1000,-496,431,1000,-286,-1000,1000,-731,741,-1000,-1000,-959,333,522,490,42,-1000,1000,-1000,-516,-871,-1000,-1000,528,-730,377,-388,-862,1000,1000,-320,-2,-614,-1000,-606,-865,-191,439,858,-510,-1000,-179,1000,996,-1000,-34,142,1000,-912,-1000,143,549,238}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00044() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "containsValue(java.lang.Object):boolean",
            new int[]{-1000,941,59,132,1000,-76,-656,-1000,1000,936,951,1000,1000,898,33,-393,-456,-723,-222,249,182,628,685,-15,669,190,349,714,421,-1000,95,-236,-1000,-930,-1000,581,-1000,424,367,-425,207,-719,-744,1000,-1000,-1000,1000,-542,-71,380,777,216,-570,-288,-727,826,-948,-513,-1000,1000,-76,30,-408,757}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00045() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "containsValue(java.lang.Object):boolean",
            new int[]{981,321,474,-464,1000,-366,906,1000,-1000,-97,1000,70,552,469,1000,338,-1000,629,-367,870,-440,561,-29,-591,-194,-365,-368,-856,239,132,305,713,-504,-452,662,652,1000,87,773,400,312,1000,1000,-1000,-668,411,-525,-101,487,859,581,-400,-150,1000,-839,-378,-111,-400,337,-1000,-433,-863,339,-136}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00046() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "containsValue(java.lang.Object):boolean",
            new int[]{989,591,2,460,-467,-1000,654,568,-416,14,1000,760,-650,722,-1000,-1000,-445,322,845,-204,251,228,-1000,-390,-179,1000,22,-174,730,79,-492,1000,60,-868,-112,854,-599,-937,-232,-68,-894,249,517,-260,50,494,-1000,1000,-1000,873,1000,486,1000,-347,-599,228,-127,597,-425,888,-190,-315,519,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00047() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "containsValue(java.lang.Object):boolean",
            new int[]{-595,453,-631,-708,43,-381,875,-850,-2,490,498,717,-451,-208,683,1000,-963,-183,1000,92,842,418,-1000,-189,416,382,-677,1000,-191,528,-737,692,375,507,-342,514,-692,-332,754,-365,-617,1000,383,526,886,351,-1000,1000,-479,-833,1000,743,639,-1000,-1000,943,1000,-697,-571,-172,1000,601,-167,732}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00048() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "containsValue(java.lang.Object):boolean",
            new int[]{-52,-901,-214,-197,-430,-975,-868,98,711,788,886,-923,767,571,408,697,699,832,-140,-9,-420,-184,-88,-456,-577,615,426,-203,-924,467,-40,-749,737,-988,232,-630,944,175,515,800,-222,468,354,358,-544,629,961,194,491,-277,182,-505,166,-899,-994,-847,183,-64,-712,955,57,462,521,974}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00049() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "containsValue(java.lang.Object):boolean",
            new int[]{192,116,264,-1000,-619,1000,1000,455,1000,953,263,92,-786,177,903,1000,-438,808,341,1000,82,-1000,468,1000,201,-550,-551,181,531,640,565,981,183,-411,1000,-1000,77,-594,-1000,745,377,138,1000,-1000,806,1000,-595,103,304,-61,571,-39,868,-1000,682,-414,-734,-74,490,-161,896,349,351,-701}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00050() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.map.Flat3Map$EntrySet", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "entrySet():java.util.Set",
            new int[]{37,961,658,-117,348,-989,146,-778,357,-1000,-1000,588,-741,-1000,115,544,492,-329,-680,540,-115,1000,159,684,-127,-79,-564,-205,135,369,175,218,185,-966,92,1000,-1000,697,787,16,-378,192,-140,215,565,-300,-1000,-289,860,909,1000,-891,122,-490,-394,81,-727,-557,17,-470,66,-177,-8,882}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00051() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.map.Flat3Map$EntrySet", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "entrySet():java.util.Set",
            new int[]{25,-77,519,856,820,296,-397,-788,915,-420,408,597,-998,-1000,339,374,112,117,-126,664,-221,237,114,-406,368,615,-838,154,-168,419,184,400,266,-1000,-212,684,-840,403,-419,264,323,973,784,141,-186,-377,65,-281,292,842,-342,1000,113,-217,-462,281,-1000,-789,338,-370,1000,29,-48,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00052() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.map.Flat3Map$EntrySet", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "entrySet():java.util.Set",
            new int[]{-905,401,383,1000,777,152,120,237,-47,-857,565,759,93,-988,-655,-429,3,-10,299,939,-48,224,-45,3,438,-571,-19,480,850,882,-755,-318,-952,275,54,-19,-620,-264,-203,47,50,475,-252,-260,875,-101,-900,-656,-503,833,444,-993,-143,-497,835,-303,-629,-678,380,763,665,-793,-192,-716}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00053() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.map.Flat3Map$EntrySet", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "entrySet():java.util.Set",
            new int[]{-942,-45,-259,-574,-291,-87,134,68,22,-285,615,1000,141,715,-175,-478,256,136,321,-90,364,-46,611,-137,-986,-68,38,526,-265,-304,-360,-406,-458,454,629,-250,35,154,1000,80,-96,-249,269,-456,583,-248,400,476,90,185,956,800,-339,-346,-128,198,149,-155,343,728,-150,-471,112,146}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00054() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.map.Flat3Map$EntrySet", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "entrySet():java.util.Set",
            new int[]{1000,659,-62,-572,1000,-410,483,559,-311,-863,212,1000,44,-554,-616,-393,66,-87,-1000,1000,-700,837,-287,17,-271,-686,417,-495,1000,901,-616,827,808,66,478,-466,-1000,-219,1000,-589,556,-809,-1000,500,32,97,-1000,476,-1000,185,961,1000,-529,108,1000,-1000,-1000,294,-640,221,422,-1000,173,118}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00055() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.map.Flat3Map$EntrySet", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "entrySet():java.util.Set",
            new int[]{-905,-393,1000,-476,-1000,-258,120,-1000,1000,-127,-838,648,-343,305,100,-300,-632,563,181,-1000,1000,-721,1000,3,-1000,995,-1000,1000,-546,-1000,-450,-1000,-1000,275,-48,1000,916,1000,898,680,-1000,40,1000,-1000,413,-116,853,-1000,1000,1000,-1000,-1000,-990,-191,835,1000,-629,-1000,380,-763,-1000,1000,-192,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00056() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.map.Flat3Map$EntrySet", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "entrySet():java.util.Set",
            new int[]{-178,897,53,1000,1000,1000,-118,868,-416,-914,-367,1000,-876,-1000,-899,523,409,86,470,-696,-1000,1000,-1000,252,1000,-118,434,-480,360,855,-585,-17,881,-53,-1000,25,74,-1000,762,-66,1000,314,-616,1000,-718,-823,696,-185,-1000,1,1000,-252,1000,-70,-1000,-1000,-1000,1000,875,930,1000,-1000,343,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00057() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.map.AbstractHashedMap$EntrySet", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "entrySet():java.util.Set",
            new int[]{-99,-323,254,670,-1000,-538,523,-229,1000,-699,-362,488,-676,644,691,-1000,-1000,8,-19,-1000,1000,230,1000,-668,-1000,795,298,323,-505,-1000,-500,-910,147,-861,-750,-340,35,1000,869,237,701,772,1000,-894,-788,-1000,30,774,1000,214,903,58,-936,-163,-779,1000,669,-378,-81,-172,-1000,-378,-440,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00058() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.map.Flat3Map$EntrySet", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "entrySet():java.util.Set",
            new int[]{-942,-855,857,-983,-588,846,134,353,336,208,-994,-284,622,715,-730,-881,-856,136,-293,363,105,834,-61,987,609,986,-837,509,39,-304,-842,648,-532,490,809,110,863,484,-876,-233,186,607,-800,-456,-319,-242,945,196,597,436,-537,-709,405,-486,990,-812,149,-849,-980,-436,9,-471,-198,146}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00059() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.map.Flat3Map$EntrySet", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "entrySet():java.util.Set",
            new int[]{-324,931,783,848,1000,-223,-496,-298,524,-1000,-628,1000,-593,-782,-540,763,-227,-201,-924,1000,-1000,619,-591,-251,565,117,-458,-501,920,784,-342,1000,808,-1000,-383,595,-1000,161,-559,44,111,137,-1000,629,-239,-251,-1000,-999,-557,1000,-292,-715,186,-10,612,-711,-1000,-154,-404,-455,964,-835,-306,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00060() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.map.Flat3Map$EntrySet", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "entrySet():java.util.Set",
            new int[]{-724,-127,-197,-75,948,-37,-40,-779,780,-700,212,137,44,-871,-168,848,679,-499,1000,469,-375,-652,243,103,-271,565,-835,864,-647,1000,469,-311,-1000,459,1000,625,217,131,1000,921,556,740,-91,427,968,-679,503,23,123,605,79,-1000,492,-1000,-536,577,-640,-652,1000,846,422,547,-59,-805}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00061() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.map.Flat3Map$EntrySet", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "entrySet():java.util.Set",
            new int[]{395,780,684,-291,1000,276,-348,59,213,-366,-241,-145,-1000,-208,40,117,-253,404,-374,1000,-1000,1000,362,460,449,16,-133,-853,262,1000,-309,1000,-251,-593,159,-131,-1000,-926,-190,-409,1000,439,117,1000,-1000,-340,-216,-22,-927,331,1000,143,158,524,741,-730,-1000,260,-246,-302,284,-1000,322,-685}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00062() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "equals(java.lang.Object):boolean",
            new int[]{-766,801,617,-403,-430,-503,179,-525,-1000,594,863,933,126,946,941,107,-1000,-1000,220,-199,1000,-633,1000,-972,1000,325,1000,-371,-957,874,-549,-18,-460,659,-1000,826,-955,-243,644,1000,-266,-645,1000,231,-704,750,1000,-554,-333,-1000,-920,-31,-472,-295,-860,-1000,98,-1000,1000,-503,1000,-1000,171,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00063() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "equals(java.lang.Object):boolean",
            new int[]{-1000,-231,569,399,620,-1000,-827,-1000,-945,447,1000,1000,1000,580,1000,-948,-1000,-1000,1000,-686,846,-1000,1000,-1000,543,-435,1000,-1000,399,467,-549,-1000,-1000,1000,-614,1000,-1000,602,1000,287,605,236,1000,-991,-1000,1000,1000,-1000,-333,-1000,-33,-31,-1000,665,-911,-791,-1000,-1000,1000,-460,164,-840,171,-946}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00064() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "equals(java.lang.Object):boolean",
            new int[]{1000,285,323,182,142,-561,-400,-1000,400,226,-538,-686,-776,391,-1000,483,599,1000,-631,1000,-362,630,281,1000,-571,-209,-1000,-676,1000,-682,345,-119,689,-1000,930,-1000,-27,-264,-1000,-181,-65,-262,-1000,-317,912,-961,-1000,841,21,601,-830,838,352,-217,1000,908,-81,-622,-407,-1000,582,47,172,883}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00065() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "equals(java.lang.Object):boolean",
            new int[]{-304,-153,332,970,897,-93,445,-1000,-925,229,-133,-237,1000,-997,-347,-178,670,140,959,387,-240,196,-896,77,208,-295,-400,935,-769,-45,-849,-383,329,-52,-306,-1000,6,429,-256,-363,319,50,-200,-275,-185,1000,466,-69,-775,297,200,449,-1000,242,294,625,334,-986,-60,-1000,107,-134,-358,703}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00066() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "equals(java.lang.Object):boolean",
            new int[]{-114,-694,444,58,-843,125,-531,-162,-541,100,548,570,854,502,758,-701,565,62,-694,-791,-4,-599,-344,-321,-266,414,136,513,793,509,818,-327,-961,144,-424,-951,-265,501,-378,867,436,345,521,170,-897,-892,737,473,226,-928,70,194,986,-852,-986,720,53,220,-970,-899,-520,-760,983,-740}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00067() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "equals(java.lang.Object):boolean",
            new int[]{-763,113,526,525,694,-642,-178,-1000,-480,438,1000,489,1000,150,1000,136,-1000,-1000,836,-50,1000,-1000,551,-1000,311,-480,1000,-1000,379,386,-1000,-1000,-1000,1000,-967,1000,-1000,1000,1000,1000,254,-201,1000,-950,-1000,1000,742,-1000,-843,-1000,-266,-67,-975,-363,-303,-1000,85,-1000,458,-269,328,-1000,-322,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00068() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "equals(java.lang.Object):boolean",
            new int[]{-1000,-201,594,-212,70,-1000,558,-794,659,786,715,-363,249,1000,1000,991,-1000,-935,-565,633,1000,-758,589,-1000,226,1000,1000,-514,-177,248,968,-929,-607,1000,81,1000,-142,422,1000,29,-619,29,1000,766,-555,191,675,-1000,727,-1000,-326,675,-1000,546,306,-524,80,-527,-423,-1000,-1000,-1000,-539,-793}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00069() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "equals(java.lang.Object):boolean",
            new int[]{-293,81,-131,-122,519,451,111,-426,1000,229,954,-1000,257,1000,1000,559,-427,-867,-569,1000,873,-427,1000,-114,40,457,935,-1000,831,290,204,-1000,-257,652,238,1000,-1000,1000,20,170,-703,84,679,735,-292,-362,-348,-1000,576,-700,-1000,758,-867,-885,682,-299,579,-85,-268,-622,-1000,-897,-635,-177}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00070() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "equals(java.lang.Object):boolean",
            new int[]{-685,-665,339,1000,1000,933,1000,-1000,63,870,576,-674,823,143,1000,918,-1000,-1000,-136,760,964,-1000,186,-876,430,330,867,-1000,738,862,331,-1000,-1000,730,503,1000,-695,1000,1000,-276,-459,749,815,-236,-413,184,-414,-1000,565,-1000,-152,555,-976,-1000,598,-89,45,-1000,-757,-991,-1000,-933,-958,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00071() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "equals(java.lang.Object):boolean",
            new int[]{-685,349,-952,154,1000,692,617,440,-1000,1000,957,-1000,68,637,47,711,131,864,964,780,315,-1000,-430,741,-1000,330,912,-1000,1000,53,90,-1000,1000,827,321,763,264,-261,495,-1000,596,280,505,-1000,-438,-916,-1000,-1000,-542,307,-152,972,-157,22,598,1000,692,352,82,139,-1000,-470,-134,25}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00072() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "equals(java.lang.Object):boolean",
            new int[]{-709,281,658,-32,-63,-902,-381,-461,-1000,938,620,867,388,761,958,-686,-427,-935,239,-355,415,-501,492,-836,708,478,732,-560,65,589,-684,-312,-523,761,93,878,-946,-448,751,-987,636,492,953,-161,-793,806,231,-688,-237,-640,87,82,-648,593,-833,601,-866,-665,738,-1000,-530,-561,428,-793}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00073() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "equals(java.lang.Object):boolean",
            new int[]{-94,759,610,-736,-930,-690,-508,613,-411,282,1000,984,-321,367,510,-918,-99,290,-143,-760,-1000,1000,658,-923,1000,826,834,530,24,430,-247,1000,1000,678,-1000,286,-1000,600,-762,665,549,147,-655,306,-1000,-596,278,532,-884,1000,172,1000,-827,771,-851,603,606,-1000,734,724,836,938,972,291}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00074() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "get(java.lang.Object):java.lang.Object",
            new int[]{-984,-481,-421,638,-911,-302,541,-824,430,795,-37,328,-829,960,-139,-811,-1000,-1000,964,-510,-179,406,-182,-106,1000,135,627,-1000,977,484,111,366,-942,366,-1000,-1000,-342,40,-236,271,-393,378,426,-192,-261,-717,-204,-319,511,-498,134,1000,-160,-546,-184,443,1000,-300,1000,342,-676,-294,640,289}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00075() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "get(java.lang.Object):java.lang.Object",
            new int[]{-818,833,144,-311,-826,-78,532,44,303,1000,556,398,908,149,684,-371,248,-759,871,540,-900,-42,413,-269,544,-402,-1000,-800,1000,403,693,-510,1000,1000,-142,-62,287,-377,1000,-439,800,48,436,-162,866,316,-440,-438,1000,-473,-143,98,-399,559,-244,-866,413,918,390,-741,-1000,536,-192,964}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00076() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "get(java.lang.Object):java.lang.Object",
            new int[]{-875,-131,-416,-316,583,670,-1000,23,1000,-150,1000,-1000,-1000,45,-996,-276,869,78,903,-1000,1000,-1000,582,522,-137,-643,1000,1000,-1000,1000,-460,837,359,-242,1000,985,-154,493,-955,1000,385,-145,831,278,-532,-841,-579,1000,-751,935,771,908,1000,-1000,-888,-205,-1000,-1000,-29,-1000,1000,-1000,1000,448}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00077() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "get(java.lang.Object):java.lang.Object",
            new int[]{-828,897,792,-1000,23,483,1000,-1000,339,499,-158,411,14,643,341,1000,-836,71,633,-1000,-289,-672,386,1000,-1000,-519,-523,930,1000,411,-420,-1000,1000,-44,-1000,271,513,1000,429,-405,665,-611,-1000,25,-1000,46,-822,1000,-1000,-1000,-1000,-713,1000,-129,-749,-297,641,20,-1000,661,-1000,-574,-957,110}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00078() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "get(java.lang.Object):java.lang.Object",
            new int[]{-939,-89,-652,-893,-1000,-101,575,-310,-138,-200,-621,-113,-786,778,467,429,-1000,449,492,-637,-290,-728,56,577,-887,90,-147,379,484,484,-671,-38,298,-692,-1000,620,185,802,-1000,-166,212,-693,-332,385,-1000,33,-835,710,-1000,-649,267,174,371,-988,-1000,1000,-1000,-161,-88,100,-588,-1000,351,-441}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00079() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "get(java.lang.Object):java.lang.Object",
            new int[]{-987,389,360,918,1000,-1000,834,-1000,732,-558,687,383,-290,805,-706,-119,372,-21,861,-584,-878,140,75,618,348,-693,-500,-678,-520,587,794,-183,-1000,1000,-604,-1000,-135,412,-371,181,692,274,-676,-1000,-3,-1000,-539,-959,584,-1000,-137,-205,863,-436,221,-282,1000,-246,1000,1000,96,-638,-927,59}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00080() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "get(java.lang.Object):java.lang.Object",
            new int[]{-52,-313,371,-398,-1000,337,579,-436,-850,-153,-864,1000,428,285,502,-790,-625,545,416,-661,-424,-775,-521,918,-671,-45,202,961,-46,96,-246,-96,-273,1000,-445,-813,153,-421,1000,-799,-20,-346,-29,-244,-71,-427,-196,-68,291,-795,-193,-307,80,408,386,54,787,-276,-476,106,-1000,-314,-503,137}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00081() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "get(java.lang.Object):java.lang.Object",
            new int[]{-1000,-323,-616,-331,-1000,-512,460,-698,-966,971,445,-171,-363,-31,320,-419,-17,-295,966,-441,218,-259,-231,398,283,-492,470,128,399,338,127,699,-1000,123,-942,388,-133,325,839,96,299,-63,175,78,-495,-796,-377,102,87,-609,-156,456,105,-563,-536,468,437,-74,283,-293,325,-1000,868,43}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00082() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "get(java.lang.Object):java.lang.Object",
            new int[]{-821,-207,-136,-900,-854,1000,-843,22,665,-214,256,-1000,-1000,80,-658,199,-34,367,825,-1000,809,-1000,453,399,-624,-124,1000,847,-222,1000,-820,133,1000,-500,165,579,16,782,-1000,724,-90,-251,392,330,-748,-489,-493,1000,-1000,568,107,868,756,-724,-1000,32,-1000,-1000,-72,-1000,769,-1000,944,165}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00083() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "get(java.lang.Object):java.lang.Object",
            new int[]{-989,-323,-616,760,543,-242,-883,-569,1000,556,1000,-1000,-1000,-36,-632,-983,193,-879,1000,-1000,369,-226,137,203,1000,-462,861,-127,-165,1000,192,1000,-1000,365,730,-120,-404,-26,-420,1000,173,296,854,-88,-215,-1000,-377,392,307,189,790,1000,560,-913,-316,82,-117,-1000,803,-505,325,-1000,939,52}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00084() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "get(java.lang.Object):java.lang.Object",
            new int[]{-1000,250,209,-87,168,-1000,-819,-765,1000,451,1000,551,-552,744,-10,376,48,400,392,-166,-75,-226,-428,433,150,-274,124,-492,1000,587,-1000,1000,-1000,299,-607,-120,110,455,-192,749,-102,710,83,-154,-605,-166,-217,365,-374,377,-567,412,1000,-1000,-251,441,900,277,-253,-744,351,-689,217,52}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00085() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "isEmpty():boolean",
            new int[]{389,-885,819,-177,-1000,-39,-1000,459,4,1000,217,128,-86,500,-953,263,2,3,243,71,-565,761,252,-176,1000,-749,-346,602,212,-580,-899,-443,-417,218,678,-572,29,733,-91,718,429,-881,-974,-412,377,-1000,1000,267,591,660,-168,-158,-211,182,789,1000,591,173,1000,-1000,591,1000,-845,-303}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00086() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "isEmpty():boolean",
            new int[]{642,-797,919,-59,-1000,501,-1000,-195,-372,238,217,-400,-498,895,132,-507,881,-867,885,-985,-1000,-95,987,-909,1000,651,-1000,254,824,194,-514,-40,-481,-894,-162,-51,134,-591,-401,1000,688,-296,-1000,-691,141,-1000,1000,517,1000,1000,-901,-267,90,325,1000,1000,597,810,1000,-1000,469,-762,-607,122}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00087() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "isEmpty():boolean",
            new int[]{864,-445,-642,-616,69,861,-138,-195,-372,-113,830,-400,174,-194,-981,886,-331,-651,336,-985,929,351,987,711,1000,-1000,1000,254,260,194,-514,-560,-470,-96,-162,290,943,-391,-1000,278,-1000,-296,93,-1000,279,-256,151,776,-143,308,897,-267,-118,-347,175,593,-373,521,1000,-389,455,-762,1000,-228}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00088() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "isEmpty():boolean",
            new int[]{-429,433,917,-766,776,738,-276,-572,1000,-376,604,-831,-692,398,1000,-1000,1000,-729,705,522,-256,-1000,-862,-264,-1000,1000,-1000,312,-3,1000,1000,128,-1000,-1000,-476,69,392,951,-774,142,682,-766,-72,-742,-1000,734,-1000,-261,-130,-583,-39,-1000,-273,-397,205,786,-148,1000,1000,84,-764,-743,802,94}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00089() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "isEmpty():boolean",
            new int[]{693,-388,-351,915,-1000,783,189,-535,356,-144,963,904,547,427,-659,289,603,175,867,560,205,690,201,391,1000,64,-1000,897,380,-297,-595,620,-138,44,702,-1000,-828,-1000,1000,1000,-174,-579,-219,-443,-605,573,-1000,143,1000,-70,360,-963,735,-130,277,576,-139,1000,-82,-987,-86,-1000,-273,828}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00090() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "isEmpty():boolean",
            new int[]{-19,-127,707,-6,727,1000,-93,-1000,-877,-113,881,204,271,291,-1000,388,-1000,387,673,-1000,1000,738,1000,365,1000,-1000,1000,254,472,-1000,-76,-229,-898,-96,-1000,-2,579,24,-911,-679,-1000,-383,514,-1000,-1000,-1000,-30,666,-200,895,496,-429,-545,-822,818,441,-412,-115,662,99,526,-393,1000,28}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00091() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "isEmpty():boolean",
            new int[]{-1000,705,-279,-882,-367,-1000,634,-355,150,-120,-1000,-471,508,-269,-411,658,516,1000,-1000,1000,-150,144,-1000,-254,-1000,-192,-187,-1000,-769,1000,-399,245,132,-265,361,256,591,1000,-558,-1000,372,877,1000,1000,627,70,1000,-808,318,399,-24,416,-392,-1000,-1000,-1000,-394,-1000,905,1000,-54,1000,-869,641}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00092() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "isEmpty():boolean",
            new int[]{542,-35,284,-369,-925,847,-215,244,184,-288,67,55,468,-489,-33,837,755,-458,827,-737,-583,791,711,-287,842,989,156,-820,-711,-312,-306,780,-919,-102,717,-517,539,-675,-561,139,-549,-899,678,-420,-57,-943,-21,-325,615,28,-805,551,-462,-527,62,889,-723,790,544,-787,517,-932,-260,359}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00093() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "isEmpty():boolean",
            new int[]{-233,-699,-312,-44,851,746,192,-621,1000,-1000,68,-372,-692,1000,134,942,-713,-27,-964,-854,617,330,710,953,-414,1000,1000,312,-406,599,124,147,-630,533,527,1000,-361,517,-774,-391,-1000,463,1000,-742,-528,1000,-783,346,-237,-988,-175,245,-273,-796,1000,-1000,-1000,494,48,-200,-714,-1000,1000,-167}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00094() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "isEmpty():boolean",
            new int[]{-511,461,-366,-341,293,215,-1000,389,233,-1000,-1000,-650,615,-24,543,57,755,-213,36,433,-906,-90,-87,-115,-421,876,-211,-1000,-254,701,90,877,-642,-924,-661,905,381,-843,-558,173,514,-26,403,-63,-411,-608,1000,212,-231,162,-444,172,-505,-251,-189,411,-1000,-222,366,471,452,-552,961,668}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00095() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "isEmpty():boolean",
            new int[]{-885,569,1000,-177,878,-219,606,-1000,1000,-128,-917,-75,-14,649,1000,-265,2,-152,363,33,-360,-913,-1000,-1000,1000,675,-964,-238,686,-125,487,87,-417,-1000,-215,-572,29,-856,-292,718,913,4,1000,-412,-1000,-930,-764,-358,-339,459,-443,201,-1000,617,438,384,11,-915,41,1000,-573,1000,36,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00096() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.map.Flat3Map$KeySet", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "keySet():java.util.Set",
            new int[]{192,-815,-522,170,349,-358,851,-250,14,-101,111,778,-106,-782,-1000,-848,-1000,-311,209,495,-1000,105,-1000,918,-187,506,-476,157,-335,-510,-1000,1000,955,183,-802,108,-4,-691,-715,204,-930,1000,-27,1000,-536,491,957,-696,748,-366,-1000,383,-540,498,861,399,385,120,753,-312,-1000,757,930,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00097() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.map.Flat3Map$KeySet", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "keySet():java.util.Set",
            new int[]{-629,465,-206,-288,-502,56,-481,-334,232,606,-1000,255,-1000,285,130,173,-495,242,-84,-102,-1000,-532,-578,672,-67,-651,-1000,128,-368,-363,212,404,490,223,386,942,-303,-1000,-267,-122,335,-139,-668,1000,257,411,-1000,-1000,9,-110,454,405,-631,765,545,125,710,1000,55,-395,-583,298,168,202}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00098() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.map.Flat3Map$KeySet", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "keySet():java.util.Set",
            new int[]{1000,53,-108,-330,-1000,-697,41,-77,1000,508,998,-273,852,1000,551,-1000,-991,1000,-1000,-947,909,-978,-469,1000,911,1000,-1000,684,-931,1000,25,250,-565,-1000,1000,1000,-1000,-1000,-688,-72,1000,-371,-1000,856,-456,-140,-963,-936,254,1000,-729,1000,-636,-724,1000,1000,-912,-143,324,1000,-796,893,1000,-467}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00099() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.map.AbstractHashedMap$KeySet", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "keySet():java.util.Set",
            new int[]{-1000,-631,394,-594,278,1000,-311,-317,-64,1000,-572,-646,-587,919,460,474,-68,172,-1000,-79,-1000,-907,-118,358,604,1000,-1000,-682,442,543,359,-383,-82,45,635,1000,-838,-686,-333,-411,1000,-147,-550,124,-55,553,-886,-1000,-461,89,1000,569,-1000,393,-88,-383,-679,1000,-156,-797,-15,503,217,-512}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00100() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.map.Flat3Map$KeySet", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "keySet():java.util.Set",
            new int[]{24,585,-84,-1000,308,386,-566,946,-5,1000,-1000,-526,-689,123,1000,1000,-38,99,-714,206,-631,-881,531,597,-303,-137,-1000,-847,1000,811,736,-269,-80,215,1000,1000,-1000,-923,586,-70,1000,-1000,-342,-295,597,-188,-521,862,-1000,-673,1000,700,-1000,1000,32,-1000,-1000,1000,-58,412,-154,-92,-1000,-565}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00101() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.map.Flat3Map$KeySet", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "keySet():java.util.Set",
            new int[]{-436,-113,-517,-109,-760,939,-792,-77,-438,790,-751,-762,-901,541,12,968,15,90,235,132,-671,405,-454,-113,239,-127,-628,-172,211,-498,99,50,-40,269,94,721,-75,-34,-22,-483,409,530,-656,416,157,3,-976,-921,-202,74,-28,321,-636,407,-181,32,831,896,265,-698,-442,372,603,493}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00102() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.map.Flat3Map$KeySet", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "keySet():java.util.Set",
            new int[]{693,-407,488,-646,-727,502,-679,-127,65,329,-103,-306,134,359,-86,421,-366,726,166,-537,675,286,21,192,-342,300,293,-441,55,982,-20,373,185,-888,1000,283,-472,137,53,-715,568,-46,-881,479,-107,-535,-151,925,690,470,-363,606,61,600,262,-351,-124,1000,-1000,372,144,-931,230,-30}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00103() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.map.Flat3Map$KeySet", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "keySet():java.util.Set",
            new int[]{435,-235,61,-176,-191,-666,-631,-1000,678,273,569,451,-831,-131,-604,-673,-156,-211,-801,218,-554,-643,-220,456,241,785,-28,-142,-686,183,999,430,-42,394,-198,196,-670,-413,-395,-1000,-502,446,-29,227,-753,463,741,23,622,102,-1000,-85,-864,348,433,736,-293,-137,219,469,-85,536,739,-253}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00104() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.map.Flat3Map$KeySet", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "keySet():java.util.Set",
            new int[]{-1000,-681,296,66,-412,905,-78,334,-705,721,-1000,-1000,-103,1000,-1000,389,-888,784,996,243,-1000,1000,-648,88,-549,1000,-889,-1000,431,-771,-762,538,496,182,-401,972,-1000,1000,-914,-836,-825,973,-520,657,245,-1000,-921,-106,-12,-239,-320,1000,-1000,14,-193,783,-1000,327,-616,-594,-1000,1000,76,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00105() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.map.Flat3Map$KeySet", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "keySet():java.util.Set",
            new int[]{1000,-591,-193,-740,1000,542,162,-1000,529,99,286,1000,-234,-1000,-328,812,1000,-1000,1000,-430,675,1000,795,-1000,142,-1000,1000,-867,-1000,-288,-455,956,1000,1000,-163,-1000,257,1000,-302,867,-1000,-497,-344,888,587,-1000,106,611,-971,237,-878,-1000,1000,1000,-1000,-451,199,-1000,-1000,-372,1000,-1000,-985,-457}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00106() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.map.Flat3Map$KeySet", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "keySet():java.util.Set",
            new int[]{807,-905,220,-292,-578,-158,-102,-622,517,343,234,-751,333,-525,-753,-903,-496,490,-399,-497,-47,363,483,420,-292,479,-3,-1000,-721,51,-166,775,344,-454,-262,-36,-361,492,-364,-146,-832,379,-439,1000,-469,-128,1000,1000,902,368,-359,392,-187,-570,-186,-1000,-214,-678,-913,693,57,734,260,135}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00107() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.map.Flat3Map$KeySet", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "keySet():java.util.Set",
            new int[]{-902,400,144,-422,625,281,680,1000,329,667,-1000,-436,-960,144,-714,499,117,-386,-401,1000,-1000,-944,-1000,-225,537,25,-370,-416,1000,-1000,-539,-90,-337,157,693,1000,-433,-708,-601,-160,1000,-349,536,-1000,-188,-101,284,-82,-878,284,1000,155,132,950,-246,-889,-978,1000,646,464,-968,550,131,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00108() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.map.Flat3Map$FlatMapIterator", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "mapIterator():org.apache.commons.collections.MapIterator",
            new int[]{644,-1,-341,-196,-145,-224,287,697,-1000,-396,936,-300,856,-542,-883,553,-1000,-549,-870,-1000,135,-1000,-483,241,-1000,-43,337,-1000,-517,-495,-725,1000,-1000,158,-173,1000,-584,-682,452,462,364,64,937,557,368,-45,168,-958,789,576,-833,-528,221,128,-1000,938,-686,-1000,-93,-560,-777,212,-7,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00109() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.iterators.EmptyMapIterator", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "mapIterator():org.apache.commons.collections.MapIterator",
            new int[]{-330,-223,-548,-250,-75,774,13,-224,1000,-421,-1000,1000,-130,-396,319,-218,347,633,-455,503,603,-580,499,-751,188,-1000,-979,1000,-193,831,-181,-1000,1000,1000,696,-1000,-185,139,-1000,-445,887,-183,855,844,456,133,-1000,1000,-842,413,199,1000,439,1000,1000,-1000,434,1000,1000,-1000,1000,-53,-684,-340}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00110() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.map.AbstractHashedMap$HashMapIterator", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "mapIterator():org.apache.commons.collections.MapIterator",
            new int[]{255,-921,-421,-5,-818,1000,454,-1000,-421,161,-1000,1000,-903,715,-306,484,593,-236,595,-1000,-136,-1000,-97,-98,446,27,-1000,1000,0,1000,864,-1000,-781,247,339,873,1000,1000,-1000,1000,596,-455,1000,-14,11,253,-494,1000,-575,971,255,929,173,544,-367,-1000,-423,581,728,-1000,564,1000,1000,37}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00111() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.map.Flat3Map$FlatMapIterator", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "mapIterator():org.apache.commons.collections.MapIterator",
            new int[]{-303,47,-89,530,-48,-1000,-86,757,-1000,173,751,-1000,531,137,155,1000,-870,-299,-591,174,432,1000,24,411,-589,715,-237,-1000,109,-1000,-620,882,-1000,-1000,139,820,-143,236,-14,-499,-587,287,365,-1000,-515,-1000,717,-305,652,976,145,-877,587,-1000,-1000,-767,-100,-955,272,769,-1000,1000,-525,-893}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00112() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.iterators.EmptyMapIterator", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "mapIterator():org.apache.commons.collections.MapIterator",
            new int[]{-215,-190,-457,-343,-27,561,-35,14,-1000,-1000,-358,178,198,633,-873,-750,879,-191,-595,-1000,274,571,419,53,-535,-229,105,-478,-405,-555,-155,-604,-678,713,-591,297,-1000,673,-1000,-1000,-974,994,1000,-1000,-783,-1000,-1000,502,1000,-1000,-384,543,893,-657,-1000,-400,1000,1000,519,395,1000,-1000,-1000,31}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00113() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.iterators.EmptyMapIterator", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "mapIterator():org.apache.commons.collections.MapIterator",
            new int[]{-965,-593,379,644,-69,202,1000,-189,1000,-692,-1000,1000,-734,-113,441,498,1000,961,595,-885,1000,722,97,85,-366,-841,515,1000,-331,59,793,-660,945,-810,365,-818,-648,462,-1000,82,-1000,507,995,-1000,-1000,158,-129,1000,-844,-242,-39,1000,248,-47,478,-1000,1000,614,-524,-1000,1000,576,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00114() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.iterators.EmptyMapIterator", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "mapIterator():org.apache.commons.collections.MapIterator",
            new int[]{-889,-377,923,725,84,1000,-501,391,-490,-10,-1000,1000,99,1000,816,-956,1000,1000,728,204,-351,-279,665,-731,-676,-721,-1000,1000,267,1000,1000,-1000,654,764,351,-1000,497,270,-1000,1000,3,-73,1000,-830,-1000,1000,-626,1000,-1000,-1000,-218,1000,-1000,895,1000,-1000,-697,314,-342,-917,653,1000,-548,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00115() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.map.Flat3Map$FlatMapIterator", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "mapIterator():org.apache.commons.collections.MapIterator",
            new int[]{-854,47,-982,-98,12,-1000,-1000,71,1000,694,-399,653,289,-688,173,31,269,-369,-452,-897,490,-881,1000,-1000,-106,-1000,-1000,-400,864,786,-1000,-641,986,1000,745,-1000,-143,-996,-14,518,1000,-531,1000,1000,1000,343,-1000,-182,-1000,943,779,356,842,1000,1000,242,-257,-955,1000,-721,-177,-53,392,-726}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00116() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.iterators.EmptyMapIterator", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "mapIterator():org.apache.commons.collections.MapIterator",
            new int[]{1000,-107,-124,-437,-474,735,407,479,-753,207,294,948,473,-582,-764,884,-1000,-659,-346,-931,-393,-1000,373,296,-366,806,-299,83,-524,905,-400,722,58,-1000,104,189,343,-1000,846,1000,1000,-693,1000,863,1000,1000,146,-845,-611,798,-1000,-71,-483,1000,-149,459,-1000,-1000,62,-1000,1000,1000,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00117() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.map.Flat3Map$FlatMapIterator", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "mapIterator():org.apache.commons.collections.MapIterator",
            new int[]{-1000,-895,-237,1000,-360,-1000,-832,939,-203,-936,101,-1000,418,-1000,1000,-446,-268,1000,-271,948,955,554,59,-335,-398,-732,1000,-299,563,-1000,-1000,917,-237,-60,-86,-865,-583,-769,-241,711,-22,302,118,-834,-586,-711,263,20,467,295,1000,-517,343,-793,303,-238,175,-353,-891,123,238,-1000,-723,530}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00118() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.iterators.EmptyMapIterator", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "mapIterator():org.apache.commons.collections.MapIterator",
            new int[]{683,-295,635,-357,385,321,-4,764,65,486,456,398,815,161,-1000,900,62,-282,1000,966,357,304,524,9,714,-254,724,-1000,1000,1000,-539,697,-152,-1000,-144,-1000,625,-757,640,1000,702,960,121,-994,1000,1000,717,-1000,762,1000,-77,-88,126,1000,-712,195,41,-910,-260,727,-376,-842,310,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00119() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "put(java.lang.Object,java.lang.Object):java.lang.Object",
            new int[]{774,-427,288,718,-1000,-1000,-293,102,-79,-326,-827,778,617,1000,245,-725,-148,513,264,-122,-1000,-724,1000,848,-187,-41,1000,-25,168,-1000,-1000,-948,998,-1000,116,-1000,740,1000,-421,-912,-695,-1000,633,-1000,948,897,436,-1000,-758,-363,-833,422,-657,106,1000,-339,1000,1000,995,-126,162,515,446,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00120() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "put(java.lang.Object,java.lang.Object):java.lang.Object",
            new int[]{-393,-427,933,256,212,-784,-74,-575,-599,627,-746,212,862,557,245,999,-423,-998,264,27,-493,-911,593,-142,118,-359,886,994,-661,-536,-153,-292,919,-234,-140,453,340,845,143,-163,-545,-789,633,-927,-131,-359,-657,-925,653,-689,-833,909,-488,130,259,184,-294,651,995,-838,162,537,266,835}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00121() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "put(java.lang.Object,java.lang.Object):java.lang.Object",
            new int[]{275,887,-281,-869,-1000,-1000,688,81,1000,157,308,312,-1000,1000,-203,-248,-1000,-902,-351,408,231,-1000,661,1000,-1000,25,25,853,-1000,-1000,-1000,1000,602,-1000,1000,420,-703,-420,-430,1000,-413,-773,1000,-886,-135,231,-351,562,-769,-310,-1000,-1000,-1000,519,773,968,564,-632,-809,360,963,214,758,-602}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00122() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "put(java.lang.Object,java.lang.Object):java.lang.Object",
            new int[]{698,-199,463,225,-311,629,1000,972,1000,1000,-111,606,-87,691,-1000,311,-998,-387,140,1000,904,96,-432,-531,-203,-707,877,1000,-1000,86,207,1000,1000,-975,-400,1000,-1000,145,-1000,923,-648,-1000,1000,-665,-1000,-1000,-1000,-498,-748,371,-990,-348,-925,-855,1000,1000,-539,30,-1000,1000,1000,-105,-69,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00123() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "put(java.lang.Object,java.lang.Object):java.lang.Object",
            new int[]{-794,-973,173,-844,368,-639,353,818,558,-996,1000,155,-931,911,1000,-165,-226,-247,-447,718,-340,354,-292,1000,-1000,258,-372,624,146,-665,-747,-455,-700,-168,1000,-426,156,-187,1000,441,808,-311,812,-704,462,187,-880,1000,-277,824,-146,-1000,-1000,-78,128,517,1000,-644,184,-924,-1000,-29,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00124() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "put(java.lang.Object,java.lang.Object):java.lang.Object",
            new int[]{1000,143,244,964,-1000,-785,-1000,-490,541,1000,-653,918,140,611,-406,789,1000,1000,996,194,912,-633,1000,-549,1000,658,389,-61,-311,-16,0,-1000,-46,779,-435,-294,-562,-837,-374,-1000,-82,-684,1000,567,1000,1000,1000,-758,-7,-1000,-615,-96,-634,-75,42,636,630,1000,441,543,-1000,-223,69,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00125() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "put(java.lang.Object,java.lang.Object):java.lang.Object",
            new int[]{635,721,-276,-1000,60,187,196,1000,411,638,504,495,724,-59,619,-178,1000,217,-802,739,-1000,200,870,-1000,218,801,-301,443,-177,192,-683,83,-1000,-43,-1000,-37,-741,-1000,126,-241,156,-975,1000,-206,347,-705,-584,-264,-164,280,389,-839,-892,-1000,604,405,-1000,695,68,-1000,-400,-369,-370,260}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00126() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "put(java.lang.Object,java.lang.Object):java.lang.Object",
            new int[]{885,651,49,-1000,-221,451,407,945,435,1000,-129,754,741,3,-405,-152,958,-81,-631,739,-639,-546,572,-1000,139,195,234,491,-555,266,544,1000,200,-544,-1000,212,-1000,-277,-1000,244,-557,-1000,1000,-58,-933,-1000,-382,-333,-362,149,-467,-516,-892,-988,819,1000,-445,684,-767,-159,1000,113,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00127() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "put(java.lang.Object,java.lang.Object):java.lang.Object",
            new int[]{-1000,-664,288,505,-17,-1000,89,102,795,966,-210,557,-989,630,457,506,-92,441,349,173,-83,149,458,-228,-963,-701,8,-317,556,-274,-677,-1000,183,554,284,-66,692,-139,1000,-912,941,-623,123,-1000,559,1000,-834,-53,-166,514,188,-421,-24,-175,254,405,187,286,-359,-186,-1000,515,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00128() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "put(java.lang.Object,java.lang.Object):java.lang.Object",
            new int[]{722,-19,628,1000,-1000,-971,-1000,892,653,1000,-271,542,-616,1000,1000,151,899,673,-480,585,-790,-117,381,299,278,1000,-456,353,-452,-965,-1000,-991,-283,-1000,1000,596,-688,268,458,-548,-37,-1000,1000,-1000,748,969,-965,339,-382,201,9,-1000,-1000,-443,1000,491,1000,275,1000,-51,-1000,-339,-330,946}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00129() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "put(java.lang.Object,java.lang.Object):java.lang.Object",
            new int[]{1000,191,-140,714,-639,-1000,-916,-228,177,96,1000,678,-474,243,861,-462,329,1000,55,569,-309,438,279,1000,1000,705,372,573,-894,-951,503,-545,-129,-1000,926,578,-1000,-474,364,-426,892,-711,532,-444,1000,1000,-1000,535,-11,-345,-768,-1000,-809,-560,944,-755,315,960,932,-114,-1000,-379,-873,750}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00130() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "putAll(java.util.Map):void",
            new int[]{1000,-879,308,1000,612,-84,267,-284,206,673,928,-315,264,715,455,-456,-187,429,1000,-34,-709,-158,-895,-497,-1000,-701,-274,596,396,976,1000,-92,551,-1000,-838,1000,-587,205,-498,-441,-44,524,-993,-963,1000,1000,640,1000,54,-616,-781,-772,58,1000,724,144,-714,905,-3,285,1000,138,987,-368}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00131() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "putAll(java.util.Map):void",
            new int[]{717,-437,-172,1000,627,-387,-541,-235,1000,1000,223,787,24,44,1000,207,-27,-1000,756,-603,600,-3,-1000,1000,-271,658,160,-241,-975,-217,-1000,343,336,-590,-699,495,-126,-1000,468,1000,688,360,211,-130,1000,1000,-152,-1000,-1000,-327,553,1000,-749,560,236,-1000,1000,150,-524,304,1000,-1000,-396,721}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00132() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "putAll(java.util.Map):void",
            new int[]{-1000,589,-339,1000,-331,-1000,259,-128,46,-886,-652,-653,1000,-687,570,578,-1000,429,-827,-547,-196,-176,1000,-470,487,-1000,230,606,-60,-201,1000,568,479,-642,1000,294,-83,837,-645,-1000,576,795,-540,699,-1000,-1000,304,1000,469,44,-250,-772,11,-772,-87,490,42,-784,1000,-465,-1000,1000,1000,-716}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00133() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "putAll(java.util.Map):void",
            new int[]{150,393,252,-1000,606,850,-861,-1000,635,643,-322,428,459,1000,861,-332,1000,124,191,1000,-131,113,-1000,203,530,-87,35,-831,1000,549,1000,133,1000,398,1000,1000,789,-297,-610,670,537,-390,24,-436,1000,275,1000,-864,-407,-668,-1000,822,130,1000,-997,-1000,539,765,-781,1000,1000,-704,-844,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00134() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "putAll(java.util.Map):void",
            new int[]{-1000,346,729,-1000,-1000,660,261,244,397,-1000,-1000,477,-153,1000,-1000,-1000,319,135,191,-453,84,-723,48,-585,747,-182,63,-831,1000,-107,129,-1000,-238,713,1000,-591,1000,298,-1000,1,618,-390,95,1000,-1000,-1000,-191,218,-1,-1000,-303,-308,1000,-1000,1000,1000,-204,-638,-635,69,-1000,-581,-78,528}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00135() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "putAll(java.util.Map):void",
            new int[]{-961,-235,-196,-103,-15,-873,-103,450,-543,-602,-778,39,974,1000,482,-261,-1000,-881,-400,-516,-709,-974,497,-266,-632,-566,-237,-107,4,-303,1000,579,96,-1000,1000,124,235,33,-1000,-427,740,938,-314,649,-802,-1000,1000,740,427,-616,139,-772,872,-817,-949,495,-714,212,-3,287,-869,-402,921,46}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00136() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "putAll(java.util.Map):void",
            new int[]{-1000,397,-379,-875,-415,-232,199,-149,177,-602,-1000,39,-732,2,-630,668,-328,-628,-400,913,-374,-974,-87,-266,967,-656,1000,-236,-680,-303,1000,134,486,149,1000,-128,866,1000,-1000,-197,367,-228,314,649,-858,-348,1000,-283,-798,-301,-267,1000,-537,-817,-949,378,166,-739,262,-1000,-834,776,921,-144}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00137() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "putAll(java.util.Map):void",
            new int[]{-268,257,66,1000,-599,-659,562,932,-208,96,895,322,-1000,-984,-333,-254,-281,785,-685,-242,-159,-49,-282,739,-129,235,133,-246,-1000,-736,-1000,-327,-426,-540,-1000,-572,-557,651,143,-240,-9,-1000,248,193,173,519,-1000,-158,-752,-4,638,290,-272,-864,1000,339,-71,-188,-43,-352,-484,546,784,-431}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00138() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "putAll(java.util.Map):void",
            new int[]{995,-147,27,220,-301,1000,271,-1000,320,1000,578,322,-832,655,-87,-1000,-281,1000,842,1000,161,-155,-282,18,388,269,133,29,-446,853,-184,-1000,-355,797,-621,340,157,71,-498,1000,87,-603,-22,-161,1000,886,-320,-158,-752,-391,-353,82,613,882,485,461,7,-188,-1000,566,532,-1000,-494,454}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00139() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "putAll(java.util.Map):void",
            new int[]{-1000,601,-561,-997,-1000,-212,-399,1000,-832,-880,-1000,966,-261,379,-8,-329,-183,-761,-823,-822,990,-980,1000,1000,1000,842,502,-1000,-73,-1000,-1000,1000,-1000,344,1000,-1000,989,-628,-807,358,1000,-195,1000,1000,-1000,-1000,656,-660,-415,-520,1000,1000,690,-1000,-1000,307,484,-712,559,69,-1000,-1000,-75,-211}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00140() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "putAll(java.util.Map):void",
            new int[]{-961,-437,173,-103,-15,-1000,439,766,-326,-1000,-778,-328,24,1000,-172,-701,-1000,-704,-722,-1000,600,-1000,-1000,-1000,-809,-1000,-893,-182,145,-51,1000,-106,212,-1000,1000,178,235,942,-1000,-1000,506,1000,-948,667,-1000,1000,715,1000,1000,-766,-693,-1000,1000,-817,451,1000,-807,245,63,402,1000,-1000,1000,717}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00141() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "putAll(java.util.Map):void",
            new int[]{-605,965,967,289,547,-937,33,23,-128,-437,494,-430,963,-73,851,346,-763,-683,-650,-174,26,-380,-589,951,530,-54,179,481,-561,132,-291,542,935,-607,547,745,-93,341,-185,-110,274,326,279,493,507,-727,-643,157,-327,20,-474,-834,-377,-467,171,-432,298,-681,-434,-502,-429,850,377,-476}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00142() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "putAll(java.util.Map):void",
            new int[]{-1000,21,322,-1000,-1000,1000,426,-224,-205,-1000,-796,898,-818,464,-985,-615,1000,52,1000,1000,806,-72,-886,-421,1000,97,1000,-397,-400,-253,1000,-919,547,1000,1000,19,1000,341,-971,1000,238,-811,1000,260,273,-717,1000,30,-1000,-824,-785,1000,1000,-738,-1000,710,658,-1000,-1000,-162,-1000,-720,-1000,295}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00143() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "remove(java.lang.Object):java.lang.Object",
            new int[]{-282,135,-882,-96,30,514,168,629,863,97,28,353,-537,182,-429,461,566,-280,800,-114,456,-385,192,-1000,838,47,97,453,-282,-1000,295,-762,595,769,484,975,-822,1000,-47,1000,651,-528,72,234,770,822,-1000,538,-785,-661,-618,-685,-953,-353,-416,47,-1000,-323,-989,970,-442,32,120,-844}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00144() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "remove(java.lang.Object):java.lang.Object",
            new int[]{499,-311,-191,585,46,157,-658,-324,1000,56,-1000,-690,-256,1000,1000,-731,1000,714,27,-1000,-896,171,-544,1000,-419,-1000,-401,-890,-630,-248,68,-322,-1000,-899,619,319,1,-326,228,730,-1000,951,-212,980,1000,-835,-614,-358,-913,-315,330,-461,350,-151,-814,674,-1000,-629,882,-487,1000,906,1000,875}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00145() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "remove(java.lang.Object):java.lang.Object",
            new int[]{-432,709,217,-1000,1000,-260,-116,1000,-793,-617,962,782,110,-84,-1000,-72,-549,283,546,121,316,19,-340,-647,586,1000,659,-31,-473,535,339,830,1000,305,355,202,-449,-1000,751,-876,1000,-917,259,-165,-937,115,938,-650,433,395,-1000,210,1000,1000,-102,-1000,747,805,-1000,690,-256,-653,-299,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00146() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "remove(java.lang.Object):java.lang.Object",
            new int[]{837,-179,72,-1000,638,-506,-990,507,1000,764,-217,-1000,-376,951,527,-561,555,-240,834,-66,30,-526,-113,1000,-586,-419,354,1000,-590,222,1000,-453,-565,520,230,477,1000,816,-542,-15,55,892,1000,1000,-1000,651,-1000,-478,-470,127,1000,-1000,366,-149,-167,220,-213,239,-989,2,-400,415,354,868}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00147() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "remove(java.lang.Object):java.lang.Object",
            new int[]{-622,709,-383,-285,704,-260,595,-946,705,-391,-695,-777,803,565,-122,-226,-436,893,-601,276,-668,123,-536,508,163,-884,341,672,609,207,-49,179,-165,-360,252,-543,-49,-304,624,136,-545,-904,-663,954,250,-443,337,-216,-169,-323,-814,279,910,749,-738,824,-991,532,-939,-291,374,544,-154,-270}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00148() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "remove(java.lang.Object):java.lang.Object",
            new int[]{683,1000,-291,-7,114,366,-1000,158,476,945,-433,-838,-956,201,552,-820,673,719,1000,-703,76,-632,401,1000,435,-275,1000,276,-318,878,-381,-275,877,178,-368,989,-123,984,907,668,23,507,-1000,-109,802,-728,406,2,-233,-94,-349,363,159,85,128,-1000,-1000,-395,-1000,-1000,554,-625,549,609}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00149() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "remove(java.lang.Object):java.lang.Object",
            new int[]{-1000,-313,778,-786,1000,-903,1000,535,-1000,706,29,-311,599,-899,-82,1000,866,-279,-672,1000,-183,1000,-207,-1000,106,298,28,-288,280,-838,439,631,20,30,-609,381,300,-1000,-197,-1000,1000,-686,1000,-1000,-290,-8,-464,-416,718,330,474,-625,12,289,86,-262,620,344,-836,704,783,35,74,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00150() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "remove(java.lang.Object):java.lang.Object",
            new int[]{343,-667,-386,-924,1000,-566,158,2,242,1000,432,687,-371,-725,-769,-513,890,769,702,1000,102,283,-886,184,-83,1000,451,1000,-678,-488,-640,1000,721,-34,-908,-856,110,-1000,310,-931,1000,540,867,-970,-1000,-1000,949,-1000,131,-73,1000,1000,720,998,342,-1000,-323,793,-1000,846,-383,-180,-436,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00151() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "remove(java.lang.Object):java.lang.Object",
            new int[]{-1000,259,1000,-616,373,211,685,45,-1000,-250,-684,185,1000,557,309,-240,-170,139,-501,-793,-297,528,-90,-130,-448,-174,880,-1000,-225,-174,-57,921,951,-119,404,-58,801,-1000,-188,-730,-50,213,857,-67,-273,-940,1000,1000,1000,1000,-31,-1000,440,-486,223,795,503,917,95,-1000,1000,-511,817,52}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00152() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "size():int",
            new int[]{-316,127,693,-563,168,1000,-1000,1000,-1000,-337,5,618,-731,986,-324,-384,-463,-821,951,-1000,168,-857,-1000,-984,633,783,188,785,1000,1000,-464,-689,-1000,352,393,1000,1000,326,728,1000,-660,-70,-1000,-1000,131,-1000,47,1000,900,1000,-796,-112,196,939,375,-1000,-343,242,1000,810,-221,418,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00153() {
        org.junit.Assert.assertEquals("java.lang.Integer:NA==", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "size():int",
            new int[]{-626,527,-111,719,-566,620,-1000,644,-774,463,304,-688,-474,1000,-62,-46,-167,-1000,971,896,892,347,105,367,-1000,-74,-1000,133,932,461,615,-1000,764,1000,-366,866,499,-168,-1000,516,14,-222,-194,400,593,-1000,385,1000,280,-83,756,-1000,111,230,622,-916,-535,-79,379,1000,-609,900,-476,-307}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00154() {
        org.junit.Assert.assertEquals("java.lang.Integer:Mg==", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "size():int",
            new int[]{-300,71,229,-337,-1000,-1000,-132,-1000,988,-710,606,223,1000,834,904,518,-1000,262,1000,-84,1000,132,373,-1000,-629,-284,-411,549,1000,435,1000,-1000,1000,1000,634,624,1000,1000,-1000,1000,356,-589,-1000,-382,366,-907,-1000,932,1000,-871,434,-1000,615,-214,1000,1000,-941,1000,-1000,-1000,-1000,-715,-395,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00155() {
        org.junit.Assert.assertEquals("java.lang.Integer:MQ==", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "size():int",
            new int[]{324,-147,606,-1000,-9,396,-941,1000,-1000,-235,385,-321,-1000,527,171,-79,-582,-682,662,-784,-60,-857,-898,-984,633,573,316,607,665,1000,653,-479,-1000,22,203,1000,1000,442,812,1000,384,-157,-743,-1000,-383,-1000,-223,1000,638,1000,-796,-290,-313,655,375,-556,-384,-911,585,864,75,1000,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00156() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "size():int",
            new int[]{1000,-446,-441,-958,114,-447,928,-368,856,-4,107,308,474,-380,-885,65,-297,-634,-60,755,1000,-85,1000,-856,-51,1000,-592,980,-1000,1000,-798,-135,1000,-555,-299,861,-768,1000,-625,-274,-119,-613,767,890,-1000,225,-24,-72,-1000,44,-1000,1000,1000,628,1000,-510,-1000,676,-77,-215,292,-1000,-124,-452}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00157() {
        org.junit.Assert.assertEquals("java.lang.Integer:Mg==", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "size():int",
            new int[]{1000,-129,-87,-1000,-645,-858,928,-368,-279,-680,-34,781,-363,-79,531,-255,-1000,-625,-7,864,1000,-670,999,-906,-439,815,-153,699,-862,-801,-47,270,102,83,12,214,-30,1000,559,125,535,-211,-633,-438,-1000,-157,93,1000,-794,-161,-287,1000,428,1000,71,221,-360,1000,-78,-460,639,-289,-239,797}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00158() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "size():int",
            new int[]{-76,407,-886,-488,-456,-909,48,432,261,-120,-765,181,379,157,763,-642,-87,479,-473,-270,666,-472,421,-713,-537,807,-233,795,-71,-909,-597,724,530,256,962,-904,-994,355,58,72,-252,602,-676,-94,-770,239,-445,-738,-850,-800,-452,843,-409,945,-312,764,-765,861,-216,-806,389,-762,235,391}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00159() {
        org.junit.Assert.assertEquals("java.lang.Integer:Mw==", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "size():int",
            new int[]{-1000,1,484,358,1000,-533,-182,-1000,1000,-914,1000,135,1000,1000,1000,904,-1000,359,1000,-233,1000,1000,355,-1000,-1000,-209,-1000,225,1000,1000,1000,-906,1000,-769,1000,496,1000,500,-1000,1000,554,-1000,-1000,455,1000,-749,-1000,-140,1000,-1000,1000,-1000,949,-93,328,1000,23,64,-1000,-1000,-1000,-1000,97,703}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00160() {
        org.junit.Assert.assertEquals("java.lang.Integer:Mw==", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "size():int",
            new int[]{209,1,484,329,1000,1000,-1000,1000,1000,928,79,-1000,1000,62,-705,294,1000,-1000,634,-1000,1000,530,-608,-929,1000,495,-154,926,-505,-1000,-73,-906,1000,-769,31,888,-54,985,-711,431,-363,-285,1000,898,1000,-454,557,-532,-277,1000,-495,-344,526,-93,1000,-1000,23,-1000,1000,962,-1000,-1000,-470,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00161() {
        org.junit.Assert.assertEquals("java.lang.Integer:MQ==", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "size():int",
            new int[]{755,-969,-267,-1000,-913,-1000,1000,-1000,1000,-1000,731,-36,-436,-1000,-293,296,-431,1000,-1000,-500,1000,-311,251,-883,-627,-494,1000,166,-499,-1000,-884,938,-1000,1000,-47,-1000,-285,-509,1000,-731,616,-1000,-1000,-183,34,746,-633,-414,-778,-1000,-980,-335,-1000,-61,-789,1000,-943,1000,-1000,-1000,365,-1000,1000,993}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00162() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "size():int",
            new int[]{610,301,-1000,683,-720,-634,1000,-601,924,-845,-39,-39,191,-1000,409,323,-614,1000,189,-205,467,839,-605,-1000,115,953,1000,490,20,326,-1000,174,1000,1000,328,-832,371,821,-554,359,-81,-246,239,-1000,-861,1000,-448,-687,-1000,-617,-197,1000,105,257,1000,302,145,131,-1000,-1000,579,-1000,199,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00163() {
        org.junit.Assert.assertEquals("java.lang.String:e2tleTI9LTcuNyxrZXk0PS05MjIzMzcyMDM2ODU0Nzc1ODA4LGtleTM9OTIyMzM3MjAzNjg1NDc3NTgwN30=", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "toString():java.lang.String",
            new int[]{-432,121,784,-872,566,-67,219,649,-812,32,-77,634,-186,-604,-246,509,751,-305,558,1000,353,129,266,166,51,-954,-1000,486,-46,-581,-1000,104,-941,664,1000,35,-714,-473,113,207,188,234,-101,390,0,579,17,89,540,-941,1000,106,-832,765,1000,-152,-1000,-384,-1000,137,679,-454,103,622}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00164() {
        org.junit.Assert.assertEquals("java.lang.String:e30=", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "toString():java.lang.String",
            new int[]{417,341,-756,469,1000,401,858,49,-642,-1000,975,1000,-259,-221,-784,-521,-467,1000,938,-1000,-818,1000,-466,-871,1000,-1000,-60,-621,-13,-1000,904,358,-535,-136,-879,1000,-725,-337,-1000,-457,-52,-72,-1000,-699,1000,-507,807,-720,-344,1000,636,-104,73,418,204,1000,531,341,628,-1000,-288,-987,819,250}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00165() {
        org.junit.Assert.assertEquals("java.lang.String:e2tleTA9MjE0NzQ4MzY0N30=", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "toString():java.lang.String",
            new int[]{1000,109,422,250,-530,-38,-1000,1000,15,674,286,-876,-449,-401,-696,146,1000,-597,312,197,285,210,-1000,-385,305,-387,-1000,-36,521,887,35,307,-1000,749,689,1000,-166,121,-352,324,-1000,-599,-605,302,815,-726,857,1000,-851,803,500,-837,-731,1000,572,-997,-1000,842,-1000,-411,1000,194,592,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00166() {
        org.junit.Assert.assertEquals("java.lang.String:e2tleTM9LTIxNDc0ODM2NDgsa2V5MD0tOTIyMzM3MjAzNjg1NDc3NTgwOH0=", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "toString():java.lang.String",
            new int[]{1000,293,307,1000,890,-78,8,1000,400,-796,830,548,-768,-1000,-455,1000,1000,1000,428,-852,-387,1000,-1000,-652,1000,-1000,-1000,825,-189,-474,1000,401,506,735,-60,1000,134,-321,-900,-375,-1000,-344,-1000,119,1000,-684,1000,38,-667,1000,808,-424,-177,1000,688,-309,-1000,658,-860,-1000,1000,856,689,318}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00167() {
        org.junit.Assert.assertEquals("java.lang.String:e30=", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "toString():java.lang.String",
            new int[]{-614,370,784,-1000,-6,25,130,293,-812,-73,801,-165,-785,-603,-454,509,466,224,170,1000,167,872,1000,856,712,-320,-1000,238,-1000,-793,144,1000,-1000,-898,601,1,-1000,-1000,19,207,1000,-484,2,390,766,-123,752,-535,696,117,-783,-475,-691,765,-260,216,-240,569,-541,-766,-1000,766,698,408}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00168() {
        org.junit.Assert.assertEquals("java.lang.String:e2tleTE9MSwga2V5MD0tMjE0NzQ4MzY0OCwga2V5Mj0wLCBrZXk0PS0yMTQ3NDgzNjQ4fQ==", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "toString():java.lang.String",
            new int[]{1000,-431,-826,1000,1000,1000,496,-881,109,-336,971,700,567,469,576,271,-637,-51,621,406,-1000,-256,904,-1000,-1000,-1000,-651,-1000,854,-553,120,-898,-1000,928,-484,1000,-852,-216,-744,-292,296,1000,625,-331,-255,1000,-537,-426,-768,32,82,1000,-747,297,-228,-129,-286,30,-845,-646,-1000,-1000,-352,236}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00169() {
        org.junit.Assert.assertEquals("java.lang.String:e2tleTE9MCxrZXkzPUluZmluaXR5LGtleTA9SW5maW5pdHl9", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "toString():java.lang.String",
            new int[]{-216,-471,279,-1000,1000,962,223,568,-1000,-149,1000,492,-1000,-1000,-1000,113,919,945,-175,207,281,1000,548,-186,924,-216,-1000,185,-857,-1000,1000,1000,-505,15,182,196,-1000,-1000,-1000,-198,1000,-1000,-1000,471,-279,-476,1000,-830,383,690,1000,-748,-416,319,-544,176,175,307,-69,-1000,-1000,-992,1000,421}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00170() {
        org.junit.Assert.assertEquals("java.lang.String:e2tleTI9LUluZmluaXR5LGtleTA9LTIxNDc0ODM2NDh9", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "toString():java.lang.String",
            new int[]{899,-591,-587,-165,-988,736,-818,697,896,577,-203,-615,707,341,-632,-145,768,-737,-244,981,-119,-870,-272,-495,-248,-244,-690,-602,806,360,-523,-339,-704,760,888,547,464,-163,105,-176,-232,-937,-81,264,-308,54,-213,805,-513,-893,-839,-966,-629,451,538,-478,-864,-462,414,-641,-63,161,-963,757}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00171() {
        org.junit.Assert.assertEquals("java.lang.String:e2tleTA9MSxrZXkxPU5hTn0=", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "toString():java.lang.String",
            new int[]{-983,-273,-427,-349,550,235,1000,-545,-642,-1000,183,613,-212,-326,-784,-835,-829,685,271,-410,-496,1000,57,-177,1000,-1000,711,-1000,-133,-431,809,319,323,-346,-1000,614,-795,-684,-586,-619,297,-170,-350,-796,1000,-277,447,-1000,-304,1000,-538,437,-410,561,-104,910,640,17,-95,-404,-1000,-1000,486,502}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00172() {
        org.junit.Assert.assertEquals("java.lang.String:e30=", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "toString():java.lang.String",
            new int[]{-1000,-481,599,-1000,729,637,1000,-154,-826,-923,-282,949,711,317,-314,-7,-650,707,230,369,-1000,-102,528,722,-230,-1000,-424,-781,273,-319,671,-643,625,232,1000,263,145,-1000,735,-1000,622,522,1000,-32,-21,440,8,-1000,-103,-1,-1000,31,-315,-487,114,1000,1000,828,-513,-283,-1000,-422,117,-847}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00173() {
        org.junit.Assert.assertEquals("java.lang.String:e30=", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "toString():java.lang.String",
            new int[]{1000,43,1000,-913,538,1000,626,158,-1000,-1000,-432,1000,346,107,-926,-262,674,1000,921,-675,-707,1000,-621,221,1000,-372,-94,421,-291,-979,154,-419,637,-485,1000,424,1000,-1000,550,-1000,-176,-914,-1000,-48,1000,711,384,59,443,989,3,-1000,1000,-610,1000,1000,-660,1000,792,-894,1000,1000,985,-930}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00174() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.map.Flat3Map$Values", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "values():java.util.Collection",
            new int[]{-489,163,93,1000,1000,1000,-418,1000,186,554,240,1000,-752,1000,-1000,1000,-1000,573,-753,609,1000,909,598,704,-1000,-930,1000,-732,-317,-1000,345,596,-595,1000,-218,491,179,-1000,1000,252,303,918,-250,1000,-313,-137,1000,-1000,732,1000,449,52,349,-1000,-878,399,1000,1000,-1000,-4,113,-100,194,-46}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00175() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.map.Flat3Map$Values", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "values():java.util.Collection",
            new int[]{-710,-629,982,462,1000,1000,339,1000,-780,-831,-1000,1000,-220,722,-1000,1000,-943,1000,-1000,-284,1000,909,736,-312,-1000,-1000,-1000,-1000,1000,-1000,345,-5,-1000,1000,-159,1000,-917,-1000,931,936,-721,-224,-867,1000,-231,730,1000,-1000,14,1000,-922,1000,1000,873,-230,220,734,261,-740,-1000,113,-317,-135,528}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00176() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.map.AbstractHashedMap$Values", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "values():java.util.Collection",
            new int[]{-906,359,589,1000,80,276,19,982,-1000,-8,-985,497,368,141,-998,879,863,-973,-453,-707,60,50,-681,-152,-412,-1000,-462,-1000,773,85,1000,-433,-937,-186,1000,-366,-505,398,-141,1000,48,-986,-1000,394,-665,766,1000,246,79,-546,-187,1000,933,870,98,-297,-752,522,687,-849,609,1000,-961,-267}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00177() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.map.Flat3Map$Values", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "values():java.util.Collection",
            new int[]{647,-29,101,579,691,666,99,-617,200,753,257,719,-595,-252,-256,662,-665,850,878,841,-453,-135,457,228,218,-26,245,882,578,-334,317,407,94,656,-369,895,300,-338,-987,-256,-298,568,525,-131,-173,-346,103,-423,-864,359,-694,-369,-744,-669,-973,901,804,429,-899,382,-72,-278,888,350}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00178() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.map.Flat3Map$Values", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "values():java.util.Collection",
            new int[]{-1000,1000,234,1000,290,-324,167,1000,-956,554,-198,38,582,813,-800,135,-230,-1000,348,-1000,164,-1000,-1000,144,-320,190,811,-810,-74,190,-440,-258,-355,515,967,-1000,383,-147,-153,943,596,-587,-524,-352,-749,-1000,319,926,683,-838,1000,21,-1000,362,-364,-628,-148,-715,407,-142,-248,208,379,190}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00179() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.map.Flat3Map$Values", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "values():java.util.Collection",
            new int[]{-1000,267,-91,929,67,-206,723,763,-942,-740,-1000,-33,-600,-162,-904,334,124,-324,-1000,-922,853,501,1000,-1000,-490,-464,-261,-654,194,-200,-190,-751,-1000,288,253,1000,-596,87,433,123,514,884,-1000,227,-105,430,-406,155,1000,-587,-393,342,-97,736,613,360,-628,103,449,-302,-974,-362,76,408}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00180() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.map.Flat3Map$Values", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "values():java.util.Collection",
            new int[]{-116,993,386,-86,1000,698,-12,-295,645,297,76,469,-983,691,-803,271,-708,678,1000,6,662,-497,894,-307,-63,-138,982,269,-602,237,713,1000,-355,501,-407,491,481,-718,285,1000,347,596,243,-61,-315,-957,-166,-477,664,864,161,-200,-874,-714,248,399,897,165,-578,-91,-71,-641,665,63}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00181() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.map.Flat3Map$Values", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "values():java.util.Collection",
            new int[]{94,93,1000,449,1000,-430,-128,222,-370,1000,-358,-65,1000,863,-1000,1000,759,49,-408,1000,-806,-972,-441,290,-476,-205,-922,-602,1000,1000,814,-727,-16,76,-643,-539,-1000,1000,-1000,600,-168,179,-608,1000,-689,208,1000,699,-840,-7,-1000,-1000,281,153,-509,1000,-810,-87,-1000,-801,1000,33,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00182() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.map.Flat3Map$Values", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "values():java.util.Collection",
            new int[]{-569,351,524,725,984,-183,304,1000,808,-579,302,657,-683,923,-784,334,-138,1000,-1000,130,1000,59,-313,243,-398,733,-267,-664,285,-1000,-1000,-623,59,1000,-207,-575,-512,254,695,231,-130,-99,-23,854,-25,-571,999,-1000,1000,360,364,-591,-64,-1000,201,129,997,808,-869,-944,129,48,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00183() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.map.AbstractHashedMap$Values", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "values():java.util.Collection",
            new int[]{-452,891,-116,88,195,-344,996,116,-126,927,-544,427,1000,1000,-261,-792,-310,915,-864,188,875,221,-154,-484,-226,97,812,58,458,283,-473,-759,287,-38,431,654,-202,349,-764,518,-234,355,-594,-1000,-522,-591,530,-261,-27,390,-255,-272,-1000,-153,-241,597,-1000,-1000,646,612,-724,252,-202,217}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00184() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.collections.map.Flat3Map$Values", DEReplay.run(
            "org.apache.commons.collections.map.Flat3Map", "org.apache.commons.collections.map.Flat3Map", "values():java.util.Collection",
            new int[]{-80,197,448,-86,1000,1000,-275,-295,247,554,80,1000,-206,710,-803,296,-1000,678,1000,555,164,-345,554,-190,-320,16,1000,28,-645,190,496,1000,-355,515,13,491,383,-560,34,-488,303,918,122,-153,-797,-1000,-166,-1000,-1000,1000,-186,-547,-1000,-714,-364,399,966,-251,-955,-4,-71,-221,1000,190}));
    }
}
