import java.lang.reflect.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Deterministic test-program decoder. Used unchanged during search and JUnit replay. */
final class DEReplay {
    public static final int DIMENSIONS = 64;
    /** Local generic bean used to create stable reflection Type and Field values. */
    public static final class GenericInput {
        public String text;
        public java.util.List<String> names;
        public java.util.Map<String, Integer> counts;
        public java.util.List<java.util.Map<String, Long>> nested;
        public int[] numbers;
        public String[] words;
    }
    static final class Genes {
        final int[] values; int at; Field lastField;
        Object jacksonBean, jacksonProvider, jacksonGenerator;
        StringWriter jacksonOutput;
        Genes(int[] values) { this.values = values; }
        int next() { return values[(at++) % values.length]; }
        int pick(int n) { return Math.floorMod(next(), n); }
    }
    public static final class Observation {
        public String token, error, generatedSource;
        public boolean reachedTarget;
        public int setupCalls, setupFailures, nullFallbacks;
    }
    public static String signature(Method m) {
        StringJoiner params = new StringJoiner(",");
        for (Class<?> t : m.getParameterTypes()) params.add(t.getTypeName());
        return m.getName() + "(" + params + "):" + m.getReturnType().getTypeName();
    }
    static Class<?> load(String name) throws ClassNotFoundException {
        return Class.forName(name, true, Thread.currentThread().getContextClassLoader());
    }
    static Method method(String target, String signature) throws Exception {
        for (Method m : load(target).getDeclaredMethods())
            if (signature(m).equals(signature)) {
                // Public methods on package-private Defects4J classes (for
                // example Gson's TypeInfoFactory) are not reflectively
                // accessible until opened on the unnamed application module.
                if (!m.isAccessible()) m.setAccessible(true);
                return m;
            }
        throw new NoSuchMethodException(signature);
    }
    static List<Constructor<?>> constructors(Class<?> type) {
        List<Constructor<?>> out = new ArrayList();
        if (!Modifier.isAbstract(type.getModifiers()) && Modifier.isPublic(type.getModifiers()))
            for (Constructor<?> c : type.getConstructors())
                if (c.getParameterTypes().length <= 6) out.add(c);
        Collections.sort(out, new Comparator<Constructor<?>>() {
            public int compare(Constructor<?> a, Constructor<?> b) {
                int byArity = a.getParameterTypes().length - b.getParameterTypes().length;
                return byArity != 0 ? byArity : a.toString().compareTo(b.toString());
            }
        });
        return out;
    }
    private static Object[] arguments(Class<?>[] types, Genes g, int depth,
                                      Observation report) throws Exception {
        Object[] args = new Object[types.length];
        for (int i = 0; i < types.length; i++) args[i] = value(types[i], g, depth, report);
        return args;
    }
    private static Object[] arguments(Method method, Genes g, int depth,
                                      Observation report) throws Exception {
        Class<?>[] types = method.getParameterTypes();
        Object[] args = new Object[types.length];
        boolean closureCompile = method.getDeclaringClass().getName().equals("com.google.javascript.jscomp.Compiler")
            && method.getName().equals("compile");
        Type[] generic = method.getGenericParameterTypes();
        boolean jacksonSerialization = method.getDeclaringClass().getName().equals(
            "com.fasterxml.jackson.databind.ser.BeanPropertyWriter")
            && method.getName().startsWith("serializeAs")
            && types.length == 3 && types[0] == Object.class;
        for (int i = 0; i < types.length; i++) {
            if (jacksonSerialization && g.jacksonBean != null) {
                if (i == 0) args[i] = g.jacksonBean;
                else if (i == 1) args[i] = g.jacksonGenerator;
                else args[i] = g.jacksonProvider;
                continue;
            }
            if (closureCompile && (List.class.isAssignableFrom(types[i])
                    || (types[i].isArray() && load("com.google.javascript.jscomp.SourceFile")
                        .isAssignableFrom(types[i].getComponentType())))) {
                // Compiler.compile takes externs and inputs in either Lists or
                // arrays depending on Closure version. Keep externs empty and
                // supply a nonempty, gene-selected input program.
                if (i == 0) args[i] = types[i].isArray()
                    ? Array.newInstance(types[i].getComponentType(), 0) : new ArrayList();
                else {
                    Object sourceFile = value(load("com.google.javascript.jscomp.SourceFile"),
                        g, depth + 1, report);
                    if (types[i].isArray()) {
                        Object files = Array.newInstance(types[i].getComponentType(), 1);
                        Array.set(files, 0, sourceFile); args[i] = files;
                    } else args[i] = new ArrayList(Collections.singletonList(sourceFile));
                }
            } else args[i] = value(types[i], g, depth, report);
        }
        return args;
    }
    private static Number number(Genes g) {
        int n = g.next();
        switch (g.pick(12)) {
            case 0: return 0; case 1: return 1; case 2: return -1;
            case 3: return Integer.MAX_VALUE; case 4: return Integer.MIN_VALUE;
            case 5: return Long.MAX_VALUE; case 6: return Long.MIN_VALUE;
            case 7: return Double.NaN; case 8: return Double.POSITIVE_INFINITY;
            case 9: return Double.NEGATIVE_INFINITY; case 10: return n / 10.0;
            default: return n;
        }
    }
    private static String string(Genes g) {
        int mode = g.pick(16), n = g.next();
        String digits = Long.toString(Math.abs((long)n));
        String sign = new String[]{"", "-", "+", "--"}[g.pick(4)];
        switch (mode) {
            case 0: return null; case 1: return ""; case 2: return " ";
            case 3: return Integer.toString(n);
            case 4: return sign + digits;
            case 5: return sign + digits + "." + g.pick(1000);
            case 6: return sign + digits + "e" + g.next();
            case 7: return sign + "0x" + Long.toHexString(Math.abs((long)n));
            case 8: return sign + "0x8" + "0".repeat(g.pick(20));
            case 9: return sign + digits + "fFdDlL".charAt(g.pick(6));
            case 10: return " " + sign + digits + " ";
            case 11: return new String[]{"true", "false", "null", "NaN", "Infinity"}[g.pick(5)];
            case 12: return "a".repeat(g.pick(25));
            default:
                String alphabet = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ+-._ /\\\t\n";
                StringBuilder s = new StringBuilder();
                int length = g.pick(25);
                for (int i = 0; i < length; i++) s.append(alphabet.charAt(g.pick(alphabet.length())));
                return s.toString();
        }
    }
    private static Object value(Class<?> t, Genes g, int depth, Observation report) throws Exception {
        if (t == String.class || t == CharSequence.class) return string(g);
        if (t == Comparable.class) return "key" + g.pick(5);
        if (t == boolean.class || t == Boolean.class) return g.pick(2) == 0;
        if (t == char.class || t == Character.class) return (char)g.pick(128);
        if (t == byte.class || t == Byte.class) return number(g).byteValue();
        if (t == short.class || t == Short.class) return number(g).shortValue();
        if (t == int.class || t == Integer.class) return number(g).intValue();
        if (t == long.class || t == Long.class) return number(g).longValue();
        if (t == float.class || t == Float.class) return number(g).floatValue();
        if (t == double.class || t == Double.class || t == Number.class) return number(g).doubleValue();
        if (t.isEnum()) {
            Object[] constants = t.getEnumConstants();
            return constants.length == 0 ? null : constants[g.pick(constants.length)];
        }
        if (t == Object.class) return g.pick(3) == 0 ? null : "object" + g.pick(5);
        if (depth >= 3) { report.nullFallbacks++; return null; }
        if (t.isArray()) {
            int length = g.pick(6);
            Object array = Array.newInstance(t.getComponentType(), length);
            for (int i = 0; i < length; i++) Array.set(array, i, value(t.getComponentType(), g, depth + 1, report));
            return array;
        }
        if (t == List.class || t == Collection.class || t == Iterable.class || t == Set.class) {
            Collection<Object> items = t == Set.class ? new LinkedHashSet() : new ArrayList();
            int size = g.pick(5);
            for (int i = 0; i < size; i++) items.add("item" + g.pick(5));
            return items;
        }
        if (t == Map.class) {
            Map<Object, Object> items = new LinkedHashMap();
            int size = g.pick(5);
            for (int i = 0; i < size; i++) items.put("key" + g.pick(5), number(g));
            return items;
        }
        if (t == java.util.Date.class) return new java.util.Date(g.next() * 86400000L);
        if (t == Class.class) return String.class;
        if (t == java.lang.reflect.Field.class) {
            Field[] fields = GenericInput.class.getFields();
            g.lastField = fields[g.pick(fields.length)];
            return g.lastField;
        }
        if (t == java.lang.reflect.Type.class) {
            if (g.lastField != null && g.pick(3) == 0)
                return g.lastField.getDeclaringClass();
            Field[] fields = GenericInput.class.getFields();
            return fields[g.pick(fields.length)].getGenericType();
        }
        if (t == java.io.Reader.class || t == java.io.BufferedReader.class
                || t == java.io.StringReader.class) {
            String content = "header,value\n" + string(g) + "," + number(g) + "\n"
                + "alpha,beta\n";
            StringReader reader = new StringReader(content);
            return t == java.io.BufferedReader.class ? new BufferedReader(reader) : reader;
        }
        if (t.getName().equals("org.apache.commons.csv.CSVFormat")) {
            Class<?> format = load("org.apache.commons.csv.CSVFormat");
            for (String fieldName : new String[]{"DEFAULT", "RFC4180", "EXCEL"}) try {
                Object result = format.getField(fieldName).get(null);
                if (t.isInstance(result)) return result;
            } catch (ReflectiveOperationException ignored) { }
            for (Method factory : format.getMethods())
                if (Modifier.isStatic(factory.getModifiers()) && factory.getParameterTypes().length == 0
                        && t.isAssignableFrom(factory.getReturnType())) try {
                    return factory.invoke(null);
                } catch (ReflectiveOperationException ignored) { }
        }
        if (t.getName().equals("com.google.javascript.jscomp.SourceFile")) {
            Class<?> source = load("com.google.javascript.jscomp.SourceFile");
            for (Method factory : source.getMethods())
                if (Modifier.isStatic(factory.getModifiers()) && factory.getName().equals("fromCode")
                        && factory.getParameterTypes().length == 2 && factory.getParameterTypes()[0] == String.class
                        && factory.getParameterTypes()[1] == String.class) {
                    String replaySource = System.getProperty("de.generated.source");
                    if (replaySource != null) {
                        try {
                            report.generatedSource = replaySource;
                            return factory.invoke(null, "de-input.js", replaySource);
                        } catch (ReflectiveOperationException ignored) { }
                    }
                    String[] unusedParameterScripts = {
                        "window.f = function(a) {};",
                        "window.f = function(a, b) { return b; };",
                        "window.f = function(a, b) { var used = b; return used; };",
                        "window['f'] = function(unused) {};",
                        "window.f = function(unused, value) { return value; };",
                        "window['f'] = function(unused, value) { return value; };",
                        "window.f = function(first, unused, last) { return last; };",
                        "window.f = function(unused) { var local = 1; return local; };",
                        "window.f = function(unused, value) { var alias = value; return alias; };",
                        "window.f = function(unused, value) { if (value) { return 1; } return 2; };",
                        "window.f = function(unused, value) { value = value + 1; return value; };",
                        "window.f = function(unused, value) { return function() { return value; }; };",
                        "window.f = function(unused) { function inner() { return 1; } return inner(); };",
                        "window.f = function(a, b, unused) { return a + b; };",
                        "window.f = function(a, unused, b, c) { return a + c; };"
                    };
                    String[] catchDependencyScripts = {
                        "window.f = function() { var saved; try { throw Error('x'); } catch (caught) { saved = caught; } return saved.stack; };",
                        "window.f = function(flag) { var saved; try { if (flag) throw Error('x'); } catch (caught) { saved = caught; } return saved.message; };",
                        "window.f = function() { var saved; try { throw Error('x'); } catch (caught) { saved = caught; } return saved.name; };",
                        "window.f = function() { var saved; try { throw Error('x'); } catch (caught) { saved = caught; } return String(saved); };",
                        "window.f = function(flag) { var saved; try { if (flag) throw Error('x'); } catch (problem) { saved = problem; } return saved.stack; };",
                        "window.f = function() { var saved; try { throw Error('x'); } catch (problem) { saved = problem; } return saved.message; };"
                    };
                    String[] genericScripts = {
                        "function f(unused, used) { var local = 1; return used; } f(1, 2);",
                        "function f() { var unused = 1; var used = 2; return used; } f();",
                        "function f(x) { var first = x; first = 3; return x; } f(2);",
                        "function f() { var unused = 1; } f();",
                        "function keep() { var dead = 1; return 7; } keep();"
                    };
                    String modified = System.getProperty("de.modified.classes", "");
                    String[] scripts;
                    if (modified.contains("RemoveUnusedVars") && modified.contains("FlowSensitiveInlineVariables")) {
                        scripts = new String[unusedParameterScripts.length + catchDependencyScripts.length];
                        System.arraycopy(unusedParameterScripts, 0, scripts, 0, unusedParameterScripts.length);
                        System.arraycopy(catchDependencyScripts, 0, scripts, unusedParameterScripts.length,
                            catchDependencyScripts.length);
                    }
                    else if (modified.contains("FlowSensitiveInlineVariables")) scripts = catchDependencyScripts;
                    else if (modified.contains("RemoveUnusedVars")) scripts = unusedParameterScripts;
                    else scripts = genericScripts;
                    try {
                        String code = scripts[g.pick(scripts.length)];
                        report.generatedSource = code;
                        return factory.invoke(null, "de-input.js", code);
                    }
                    catch (ReflectiveOperationException ignored) { }
                }
        }
        if (t.getName().equals("com.google.javascript.jscomp.CompilerOptions")) {
            try {
                Object options = t.getConstructor().newInstance();
                // In Closure Compiler, unused-variable passes are enabled by
                // CompilationLevel, rather than by a CompilerOptions enum
                // setter. Apply the real public configuration when available.
                try {
                    Class<?> levelType = load("com.google.javascript.jscomp.CompilationLevel");
                    Object advanced = levelType.getField("ADVANCED_OPTIMIZATIONS").get(null);
                    for (Method configure : levelType.getMethods())
                        if (configure.getName().equals("setOptionsForCompilationLevel")
                                && configure.getParameterTypes().length == 1
                                && configure.getParameterTypes()[0].isInstance(options)) {
                            configure.invoke(advanced, options); break;
                        }
                } catch (ReflectiveOperationException ignored) { }
                // Also set the relevant options directly for Closure releases
                // whose compilation-level helper no longer enables this pass.
                for (Class<?> current = t; current != null; current = current.getSuperclass())
                    for (Field field : current.getDeclaredFields()) {
                        String name = field.getName().toLowerCase(Locale.ROOT);
                        if (field.getType() == boolean.class && name.equals("removeglobals")) try {
                            // Closure-1 specifically guards argument removal
                            // when globals are preserved. Keep the optimization
                            // pass enabled while exercising that configuration.
                            field.setAccessible(true); field.setBoolean(options, false);
                        } catch (Exception ignored) { }
                        if (field.getType() == boolean.class
                                && (name.contains("removeunusedvar") || name.contains("removeunusedlocal"))) try {
                            field.setAccessible(true); field.setBoolean(options, true);
                        } catch (Exception ignored) { }
                    }
                for (Method setter : t.getMethods()) {
                    if (!Modifier.isPublic(setter.getModifiers()) || !setter.getName().startsWith("set")
                            || setter.getParameterTypes().length != 1) continue;
                    String name = setter.getName().toLowerCase(Locale.ROOT);
                    if (setter.getParameterTypes()[0] == boolean.class && name.contains("removeglobals")) {
                        try { setter.invoke(options, false); } catch (ReflectiveOperationException ignored) { }
                    } else if (setter.getParameterTypes()[0] == boolean.class
                            && (name.contains("removeunusedvar") || name.contains("removeunusedlocal"))) {
                        try { setter.invoke(options, true); } catch (ReflectiveOperationException ignored) { }
                    } else if (name.contains("optimizationlevel")
                            && setter.getParameterTypes()[0].isEnum()) {
                        Object[] values = setter.getParameterTypes()[0].getEnumConstants();
                        for (Object value : values) if (String.valueOf(value).contains("ADVANCED"))
                            try { setter.invoke(options, value); } catch (ReflectiveOperationException ignored) { }
                    }
                }
                return options;
            } catch (ReflectiveOperationException ignored) { }
        }
        if (t.getName().equals("com.google.javascript.rhino.Node")) {
            try {
                Class<?> ir = load("com.google.javascript.rhino.IR");
                for (String factoryName : new String[]{"script", "root", "name", "string"})
                    for (Method factory : ir.getMethods())
                        if (Modifier.isStatic(factory.getModifiers()) && factory.getName().equals(factoryName)
                                && factory.getParameterTypes().length == 0 && t.isAssignableFrom(factory.getReturnType()))
                            return factory.invoke(null);
            } catch (ReflectiveOperationException ignored) { }
        }
        if (t.getName().equals("com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser")) {
            Object parser = xmlParser(g, report);
            if (parser != null && t.isInstance(parser)) return parser;
        }
        if (t.getName().equals("com.fasterxml.jackson.databind.ser.BeanPropertyWriter")
                || t.getName().equals("com.fasterxml.jackson.databind.ser.impl.UnwrappingBeanPropertyWriter")) {
            Object writer = jacksonWriter(t, g, report);
            if (writer != null && t.isInstance(writer)) return writer;
        }
        if (t == java.awt.Graphics2D.class || t == java.awt.Graphics.class)
            return new java.awt.image.BufferedImage(80, 80, java.awt.image.BufferedImage.TYPE_INT_ARGB).createGraphics();
        if (java.awt.Paint.class.isAssignableFrom(t)) {
            java.awt.Color c = new java.awt.Color(g.pick(256), g.pick(256), g.pick(256));
            if (t.isInstance(c)) return c;
        }
        if (java.awt.Stroke.class.isAssignableFrom(t)) {
            java.awt.BasicStroke s = new java.awt.BasicStroke(g.pick(10) / 2.0f);
            if (t.isInstance(s)) return s;
        }
        if (java.awt.Shape.class.isAssignableFrom(t)) {
            java.awt.Shape s = new java.awt.geom.Rectangle2D.Double(g.next(), g.next(), g.pick(80), g.pick(80));
            if (t.isInstance(s)) return s;
        }
        if (t == java.awt.geom.Point2D.class) return new java.awt.geom.Point2D.Double(g.next(), g.next());
        if (t.getName().equals("org.apache.commons.cli.CommandLine"))
            return commandLine(g, report);
        Object domain = chart(t, g, report);
        if (domain != null) return domain;
        Object language = language(t, g, report);
        if (language != null) return language;
        List<Constructor<?>> ctors = constructors(t);
        // Older Java libraries often use public singleton constants in place of enums.
        if (ctors.isEmpty()) {
            List<Field> constants = new ArrayList();
            for (Field field : t.getFields())
                if (Modifier.isStatic(field.getModifiers()) && Modifier.isFinal(field.getModifiers())
                        && t.isAssignableFrom(field.getType())) constants.add(field);
            Collections.sort(constants, new Comparator<Field>() {
                public int compare(Field a, Field b) { return a.getName().compareTo(b.getName()); }
            });
            if (!constants.isEmpty()) {
                Object constant = constants.get(g.pick(constants.size())).get(null);
                if (constant != null) return constant;
            }
        }
        if (!ctors.isEmpty()) {
            Constructor<?> ctor = ctors.get(g.pick(ctors.size()));
            try { return ctor.newInstance(arguments(ctor.getParameterTypes(), g, depth + 1, report)); }
            catch (Exception ignored) { }
        }
        report.nullFallbacks++;
        return null;
    }
    private static Object language(Class<?> t, Genes g, Observation report) {
        if (!t.getName().equals("org.apache.commons.lang3.time.FastDateFormat")) return null;
        try {
            Method factory = t.getMethod("getInstance", String.class, java.util.TimeZone.class,
                java.util.Locale.class);
            String[] patterns = {"yyyy-MM-dd", "MM/dd/yy HH:mm:ss", "EEE, d MMM yyyy HH:mm:ss Z"};
            return factory.invoke(null, patterns[g.pick(patterns.length)],
                java.util.TimeZone.getTimeZone("UTC"), java.util.Locale.US);
        } catch (ReflectiveOperationException ignored) { }
        try { return t.getMethod("getInstance", String.class).invoke(null, "yyyy-MM-dd"); }
        catch (ReflectiveOperationException ignored) { return null; }
    }
    private static Object xmlParser(Genes g, Observation report) {
        try {
            Class<?> factoryType = load("com.fasterxml.jackson.dataformat.xml.XmlFactory");
            Object factory = factoryType.getConstructor().newInstance();
            String[] docs = {"<root><value>1</value><name>x</name></root>",
                "<root value=\"42\"><item>a</item><item>b</item></root>",
                "<root/>"};
            String xml = docs[g.pick(docs.length)];
            for (Method method : factoryType.getMethods()) {
                if (!method.getName().equals("createParser") || method.getParameterTypes().length != 1) continue;
                Class<?> p = method.getParameterTypes()[0];
                Object input = p == String.class ? xml : p == Reader.class ? new StringReader(xml)
                    : p == InputStream.class ? new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8)) : null;
                if (input == null) continue;
                try {
                    Object parser = method.invoke(factory, input);
                    if (parser != null) {
                        int advance = g.pick(4);
                        Method next = parser.getClass().getMethod("nextToken");
                        for (int i = 0; i < advance; i++) if (next.invoke(parser) == null) break;
                        return parser;
                    }
                } catch (ReflectiveOperationException ignored) { }
            }
        } catch (Throwable ignored) { }
        return null;
    }
    private static Object jacksonWriter(Class<?> requested, Genes g, Observation report) {
        try {
            Class<?> mapperType = load("com.fasterxml.jackson.databind.ObjectMapper");
            Object mapper = mapperType.getConstructor().newInstance();
            Object bean = new GenericInput();
            Class<?> javaTypeType = load("com.fasterxml.jackson.databind.JavaType");
            Object javaType = mapperType.getMethod("constructType", Type.class).invoke(mapper, bean.getClass());
            // Jackson 2.6 (used by this Defects4J project) exposes a provider
            // blueprint from ObjectMapper. Create a configured provider via
            // DefaultSerializerProvider, the supported API used by ObjectMapper.
            Object providerBlueprint = mapperType.getMethod("getSerializerProvider").invoke(mapper);
            Class<?> serializationConfigType = load("com.fasterxml.jackson.databind.SerializationConfig");
            Class<?> serializerFactoryType = load("com.fasterxml.jackson.databind.ser.SerializerFactory");
            Object config = mapperType.getMethod("getSerializationConfig").invoke(mapper);
            Object factory = mapperType.getMethod("getSerializerFactory").invoke(mapper);
            Class<?> defaultProviderType = load("com.fasterxml.jackson.databind.ser.DefaultSerializerProvider");
            Method createProvider = defaultProviderType.getMethod("createInstance",
                serializationConfigType, serializerFactoryType);
            Object provider = createProvider.invoke(providerBlueprint, config, factory);
            g.jacksonBean = bean;
            g.jacksonProvider = provider;
            g.jacksonOutput = new StringWriter();
            Object jsonFactory = mapperType.getMethod("getFactory").invoke(mapper);
            for (String factoryMethod : new String[]{"createGenerator", "createJsonGenerator"}) {
                try {
                    Method createGenerator = jsonFactory.getClass().getMethod(factoryMethod, Writer.class);
                    g.jacksonGenerator = createGenerator.invoke(jsonFactory, g.jacksonOutput);
                    break;
                } catch (NoSuchMethodException ignored) { }
            }
            if (g.jacksonGenerator == null)
                throw new NoSuchMethodException("JsonFactory.createGenerator(Writer) or createJsonGenerator(Writer)");
            Class<?> providerType = load("com.fasterxml.jackson.databind.SerializerProvider");
            Class<?> beanPropertyType = load("com.fasterxml.jackson.databind.BeanProperty");
            Method find = providerType.getMethod("findValueSerializer", javaTypeType, beanPropertyType);
            Object serializer = find.invoke(provider, new Object[]{javaType, null});
            List<Object> writers = new ArrayList();
            try {
                // Available on Jackson 2.6 and newer.
                Class<?> serializerType = load("com.fasterxml.jackson.databind.JsonSerializer");
                Method properties = serializerType.getMethod("properties");
                Iterator<?> it = (Iterator<?>)properties.invoke(serializer);
                while (it.hasNext()) {
                    Object item = it.next();
                    if (item != null && item.getClass().getName().endsWith("BeanPropertyWriter"))
                        writers.add(item);
                }
            } catch (NoSuchMethodException oldJackson) {
                // JacksonDatabind-1 predates JsonSerializer.properties(). Its
                // BeanSerializerBase stores writers in the protected _props
                // array; read that array only for these old releases.
                Class<?> base = load("com.fasterxml.jackson.databind.ser.std.BeanSerializerBase");
                if (!base.isInstance(serializer))
                    throw new IllegalStateException("Expected BeanSerializerBase, got "
                        + serializer.getClass().getName(), oldJackson);
                Field props = base.getDeclaredField("_props");
                props.setAccessible(true);
                Object array = props.get(serializer);
                for (int i = 0; i < Array.getLength(array); i++) {
                    Object item = Array.get(array, i);
                    if (item != null && item.getClass().getName().endsWith("BeanPropertyWriter"))
                        writers.add(item);
                }
            }
            if (writers.isEmpty())
                throw new IllegalStateException("ObjectMapper produced no bean property writers for DEReplay.GenericInput");
            Object writer = writers.get(g.pick(writers.size()));
            boolean requireUnwrapping = requested.getName().equals(
                "com.fasterxml.jackson.databind.ser.impl.UnwrappingBeanPropertyWriter");
            if (!requireUnwrapping && g.pick(2) == 0 && requested.isInstance(writer)) return writer;
            Class<?> transformerType = load("com.fasterxml.jackson.databind.util.NameTransformer");
            Object nop = transformerType.getField("NOP").get(null);
            for (Method m : writer.getClass().getMethods())
                if (m.getName().equals("unwrappingWriter") && m.getParameterTypes().length == 1
                        && m.getParameterTypes()[0].isInstance(nop)) {
                    Object unwrapped = m.invoke(writer, nop);
                    if (requested.isInstance(unwrapped)) return unwrapped;
                }
            if (requested.isInstance(writer)) return writer;
            throw new IllegalStateException("Generated Jackson property writer is not " + requested.getName());
        } catch (Throwable failure) {
            throw new IllegalStateException("Cannot construct Jackson BeanPropertyWriter: " + failure, failure);
        }
    }
    /** Build the non-constructible Commons CLI result through its public Parser API. */
    private static Object commandLine(Genes g, Observation report) throws Exception {
        Class<?> optionsClass = load("org.apache.commons.cli.Options");
        Class<?> optionClass = load("org.apache.commons.cli.Option");
        Class<?> parserClass = load("org.apache.commons.cli.PosixParser");
        Object options = optionsClass.getConstructor().newInstance();
        Method addOption = optionsClass.getMethod("addOption", optionClass);
        int numberOfOptions = 1 + g.pick(3);
        List<String> spellings = new ArrayList();
        for (int i = 0; i < numberOfOptions; i++) {
            String shortName = String.valueOf((char)('a' + i));
            String longName = "de-option-" + i;
            boolean hasArgument = g.pick(2) == 0;
            Object option = null;
            try {
                option = optionClass.getConstructor(String.class, String.class, boolean.class, String.class)
                    .newInstance(shortName, longName, hasArgument, "DE-generated option");
            } catch (NoSuchMethodException ignored) { }
            if (option == null) try {
                option = optionClass.getConstructor(String.class, boolean.class, String.class)
                    .newInstance(shortName, hasArgument, "DE-generated option");
            } catch (NoSuchMethodException ignored) { }
            if (option == null) throw new NoSuchMethodException("No supported Commons CLI Option constructor");
            addOption.invoke(options, option);
            spellings.add("-" + shortName);
            if (hasArgument) spellings.add("value-" + Math.abs((long)g.next()));
        }
        String[] argv = spellings.toArray(new String[0]);
        Object parser = parserClass.getConstructor().newInstance();
        List<Method> parseMethods = new ArrayList();
        for (Method candidate : parserClass.getMethods()) {
            Class<?>[] p = candidate.getParameterTypes();
            if (candidate.getName().equals("parse") && p.length >= 2 && p[0] == optionsClass
                    && p[1] == String[].class && candidate.getReturnType() == load("org.apache.commons.cli.CommandLine"))
                parseMethods.add(candidate);
        }
        Collections.sort(parseMethods, new Comparator<Method>() {
            public int compare(Method a, Method b) {
                return a.getParameterTypes().length - b.getParameterTypes().length;
            }
        });
        for (Method parse : parseMethods) {
            Object[] args = new Object[parse.getParameterTypes().length];
            Class<?>[] p = parse.getParameterTypes();
            args[0] = options; args[1] = argv;
            for (int i = 2; i < p.length; i++) {
                if (p[i] == boolean.class || p[i] == Boolean.class) args[i] = g.pick(2) == 0;
                else if (p[i] == java.util.Properties.class) args[i] = new java.util.Properties();
                else args[i] = value(p[i], g, 1, report);
            }
            try { return parse.invoke(parser, args); }
            catch (InvocationTargetException ignored) { }
        }
        throw new NoSuchMethodException("No successful public PosixParser.parse(Options,String[])");
    }
    /** Optional type recipes, shared across bugs; none contains a bug-specific expected answer. */
    private static Object chart(Class<?> t, Genes g, Observation report) throws Exception {
        String n = t.getName();
        if (!n.startsWith("org.jfree.")) return null;
        if (n.equals("org.jfree.data.Range")) {
            double a = g.next(), b = g.next();
            return t.getConstructor(double.class, double.class).newInstance(Math.min(a, b), Math.max(a, b));
        }
        if (n.equals("org.jfree.data.time.RegularTimePeriod"))
            return load("org.jfree.data.time.Day").getConstructor(int.class, int.class, int.class)
                .newInstance(1 + g.pick(28), 1 + g.pick(12), 1990 + g.pick(40));
        if (n.equals("org.jfree.data.time.TimeSeries")) {
            Object series = t.getConstructor(Comparable.class).newInstance("DE");
            Class<?> period = load("org.jfree.data.time.RegularTimePeriod");
            Constructor<?> day = load("org.jfree.data.time.Day")
                .getConstructor(int.class, int.class, int.class);
            Method add = t.getMethod("add", period, double.class);
            int count = 2 + g.pick(4), year = 1990 + g.pick(40);
            for (int i = 0; i < count; i++)
                add.invoke(series, day.newInstance(i + 1, 1, year), g.next() / 10.0);
            return series;
        }
        if (n.equals("org.jfree.data.category.CategoryDataset")
                || n.equals("org.jfree.data.category.DefaultCategoryDataset")) {
            Class<?> c = load("org.jfree.data.category.DefaultCategoryDataset");
            Object data = c.getConstructor().newInstance();
            Method add = c.getMethod("addValue", Number.class, Comparable.class, Comparable.class);
            int rows = 1 + g.pick(3), columns = 1 + g.pick(3);
            for (int r = 0; r < rows; r++) for (int col = 0; col < columns; col++)
                add.invoke(data, Double.valueOf(g.next() / 10.0), "R" + r, "C" + col);
            return data;
        }
        if (n.equals("org.jfree.data.xy.XYDataset") || n.equals("org.jfree.data.xy.XYSeriesCollection")) {
            Class<?> seriesClass = load("org.jfree.data.xy.XYSeries");
            Object series = seriesClass.getConstructor(Comparable.class).newInstance("DE");
            int count = 1 + g.pick(5);
            for (int i = 0; i < count; i++) seriesClass.getMethod("add", double.class, double.class)
                .invoke(series, (double)i, g.next() / 10.0);
            Class<?> c = load("org.jfree.data.xy.XYSeriesCollection");
            Object data = c.getConstructor().newInstance();
            c.getMethod("addSeries", seriesClass).invoke(data, series);
            return data;
        }
        if (n.equals("org.jfree.data.general.PieDataset") || n.equals("org.jfree.data.general.DefaultPieDataset")) {
            Class<?> c = load("org.jfree.data.general.DefaultPieDataset");
            Object data = c.getConstructor().newInstance();
            int count = 1 + g.pick(5);
            for (int i = 0; i < count; i++) c.getMethod("setValue", Comparable.class, Number.class)
                .invoke(data, "K" + i, Double.valueOf(g.next() / 10.0));
            return data;
        }
        return null;
    }
    static List<Method> setupMethods(Class<?> receiver) {
        List<Method> methods = new ArrayList();
        for (Method m : receiver.getMethods()) {
            String n = m.getName();
            if (!Modifier.isStatic(m.getModifiers()) && !m.isSynthetic()
                    && m.getParameterTypes().length <= 3 && !n.contains("Listener")
                    && (n.startsWith("set") || n.startsWith("add") || n.startsWith("update")
                        || n.startsWith("remove") || n.equals("clear"))) methods.add(m);
        }
        Collections.sort(methods, new Comparator<Method>() {
            public int compare(Method a, Method b) {
                return signature(a).compareTo(signature(b));
            }
        });
        return methods;
    }
    public static Observation execute(String target, String receivers, String signature, int[] genes) {
        Observation out = new Observation();
        try {
            Genes g = new Genes(genes);
            Method m = method(target, signature);
            Object receiver = null;
            if (!Modifier.isStatic(m.getModifiers())) {
                String[] choices = receivers.split(",");
                Class<?> receiverType = load(choices[g.pick(choices.length)]);
                receiver = value(receiverType, g, 0, out);
                if (receiver == null) throw new IllegalArgumentException("Receiver construction failed");
                // Compiler.compile owns a strict initialization sequence.
                // Random calls to its mutators before compilation can corrupt
                // state or spend the search budget on irrelevant setup.
                if (!receiverType.getName().equals("com.google.javascript.jscomp.Compiler")) {
                    List<Method> setup = setupMethods(receiverType);
                    int count = g.pick(5);
                    for (int i = 0; i < count && !setup.isEmpty(); i++) {
                        Method s = setup.get(g.pick(setup.size()));
                        try { s.invoke(receiver, arguments(s.getParameterTypes(), g, 0, out)); out.setupCalls++; }
                        catch (Exception e) { out.setupFailures++; }
                    }
                }
            }
            Object[] args = arguments(m, g, 0, out);
            out.reachedTarget = true;
            try {
                boolean jacksonSerialization = m.getDeclaringClass().getName().equals(
                    "com.fasterxml.jackson.databind.ser.BeanPropertyWriter")
                    && m.getName().startsWith("serializeAs") && g.jacksonGenerator != null;
                boolean arrayShape = m.getName().contains("Column")
                    || m.getName().contains("Element") || m.getName().contains("Placeholder");
                if (jacksonSerialization)
                    g.jacksonGenerator.getClass().getMethod(arrayShape
                        ? "writeStartArray" : "writeStartObject").invoke(g.jacksonGenerator);
                Object result = m.invoke(receiver, args);
                boolean closureCompile = m.getDeclaringClass().getName().equals(
                    "com.google.javascript.jscomp.Compiler") && m.getName().equals("compile");
                if (closureCompile) {
                    // Result is only a status object; the compiled JavaScript is
                    // the behavioral output that reveals whether an argument
                    // was removed from a globally exposed function.
                    Object js = receiver.getClass().getMethod("toSource").invoke(receiver);
                    out.token = "CLOSURE_SOURCE:" + stable(js, 0);
                } else if (jacksonSerialization) {
                    g.jacksonGenerator.getClass().getMethod(arrayShape
                        ? "writeEndArray" : "writeEndObject").invoke(g.jacksonGenerator);
                    g.jacksonGenerator.getClass().getMethod("flush").invoke(g.jacksonGenerator);
                    out.token = "JSON:" + Base64.getEncoder().encodeToString(
                        g.jacksonOutput.toString().getBytes(StandardCharsets.UTF_8));
                } else out.token = m.getReturnType() == void.class
                    ? state(receiver, m.getName()) : stable(result, 0);
            } catch (InvocationTargetException e) {
                if (e.getCause() instanceof VirtualMachineError || e.getCause() instanceof LinkageError
                        || e.getCause() instanceof ThreadDeath) throw e;
                out.token = "THROW:" + e.getCause().getClass().getName();
            }
        } catch (Throwable e) {
            out.token = "HARNESS_ERROR";
            out.error = e.getClass().getName() + ":" + String.valueOf(e.getMessage());
        }
        return out;
    }
    public static String run(String target, String receivers, String signature, int[] genes) {
        Observation o = execute(target, receivers, signature, genes);
        if (!o.reachedTarget || o.token.equals("HARNESS_ERROR"))
            throw new AssertionError("Cannot replay test: " + o.error);
        return o.token;
    }
    private static String state(Object receiver, String method) {
        if (receiver == null) return "VOID";
        List<String> getters = new ArrayList();
        if (method.startsWith("set") && method.length() > 3) {
            getters.add("get" + method.substring(3)); getters.add("is" + method.substring(3));
        }
        getters.addAll(Arrays.asList("getItemCount", "getRowCount", "getColumnCount", "getSeriesCount"));
        StringBuilder s = new StringBuilder("VOID");
        for (String name : getters) {
            try {
                Method getter = receiver.getClass().getMethod(name);
                if (getter.getReturnType().isPrimitive() || getter.getReturnType() == String.class)
                    s.append('|').append(name).append('=').append(stable(getter.invoke(receiver), 0));
            } catch (ReflectiveOperationException ignored) { }
        }
        return s.toString();
    }
    /** Only whitelisted value types are rendered. Never use arbitrary object toString(). */
    static String stable(Object value, int depth) {
        if (value == null) return "NULL";
        Class<?> t = value.getClass();
        if (value instanceof String || value instanceof Boolean || value instanceof Character
                || value instanceof Byte || value instanceof Short || value instanceof Integer
                || value instanceof Long || value instanceof Float || value instanceof Double
                || value instanceof java.math.BigInteger || value instanceof java.math.BigDecimal)
            return t.getName() + ":" + Base64.getEncoder().encodeToString(value.toString().getBytes(StandardCharsets.UTF_8));
        if (value instanceof Enum) return "ENUM:" + t.getName() + ":" + ((Enum<?>)value).name();
        if (t.isArray() && depth < 3) {
            StringBuilder s = new StringBuilder("ARRAY:" + t.getName() + ":" + Array.getLength(value));
            for (int i = 0; i < Math.min(64, Array.getLength(value)); i++) {
                String item = stable(Array.get(value, i), depth + 1);
                s.append(':').append(item.length()).append(':').append(item);
            }
            return s.toString();
        }
        if (value instanceof java.awt.Color) return "COLOR:" + ((java.awt.Color)value).getRGB();
        // Observe safe scalar properties of returned objects. This catches
        // changes to value caches and state while avoiding identity-based toString().
        StringBuilder observed = new StringBuilder("STATE:" + t.getName());
        int properties = 0;
        for (String name : Arrays.asList("getItemCount", "getMinY", "getMaxY",
                "getRowCount", "getColumnCount", "getSeriesCount")) {
            try {
                Method getter = t.getMethod(name);
                Class<?> r = getter.getReturnType();
                if (!r.isPrimitive() && r != String.class && !Number.class.isAssignableFrom(r))
                    continue;
                if (r == void.class) continue;
                Object result = getter.invoke(value);
                String token = stable(result, depth + 1);
                observed.append('|').append(name).append('=').append(token.length())
                    .append(':').append(token);
                properties++;
            } catch (Exception ignored) { }
        }
        return properties == 0 ? "TYPE:" + t.getName() : observed.toString();
    }
    public static void main(String[] args) {
        if (args.length > 4) {
            String source = new String(Base64.getDecoder().decode(args[4]), StandardCharsets.UTF_8);
            System.setProperty("de.generated.source", source);
        }
        String[] encodedGenes = args[3].split(",");
        int[] genes = new int[encodedGenes.length];
        for (int i = 0; i < encodedGenes.length; i++) genes[i] = Integer.parseInt(encodedGenes[i]);
        boolean closureCompile = args[0].equals("com.google.javascript.jscomp.Compiler")
            && args[2].startsWith("compile(");
        // Compiler.compile is an expensive whole-program operation. Fixed-side
        // suites are still executed twice by the runner, so capture its oracle
        // once here instead of launching three compilations just to check the
        // same deterministic source output.
        int repetitions = closureCompile ? 1 : 3;
        for (int i = 0; i < repetitions; i++) {
            Observation out = execute(args[0], args[1], args[2], genes);
            System.out.println("DE_TOKEN:" + Base64.getEncoder().encodeToString(out.token.getBytes(StandardCharsets.UTF_8)));
        }
    }
}

public class DEGeneratedTest {
    @org.junit.Test(timeout=60000L)
    public void testDE00000() {
        org.junit.Assert.assertEquals("TYPE:com.fasterxml.jackson.databind.JsonMappingException", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "from(com.fasterxml.jackson.core.JsonGenerator,java.lang.String):com.fasterxml.jackson.databind.JsonMappingException",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00001() {
        org.junit.Assert.assertEquals("TYPE:com.fasterxml.jackson.databind.JsonMappingException", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "from(com.fasterxml.jackson.core.JsonGenerator,java.lang.String,java.lang.Throwable):com.fasterxml.jackson.databind.JsonMappingException",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00002() {
        org.junit.Assert.assertEquals("TYPE:com.fasterxml.jackson.databind.JsonMappingException", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "from(com.fasterxml.jackson.core.JsonParser,java.lang.String):com.fasterxml.jackson.databind.JsonMappingException",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00003() {
        org.junit.Assert.assertEquals("TYPE:com.fasterxml.jackson.databind.JsonMappingException", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "from(com.fasterxml.jackson.core.JsonParser,java.lang.String,java.lang.Throwable):com.fasterxml.jackson.databind.JsonMappingException",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00004() {
        org.junit.Assert.assertEquals("TYPE:com.fasterxml.jackson.databind.JsonMappingException", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "fromUnexpectedIOE(java.io.IOException):com.fasterxml.jackson.databind.JsonMappingException",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00005() {
        org.junit.Assert.assertEquals("java.lang.String:LTB4OWM=", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "getLocalizedMessage():java.lang.String",
            new int[]{-364,705,-121,156,-735,195,97,-93,171,136,-518,-761,112,460,50,57,-729,896,854,-192,-405,-942,893,-215,-446,698,-344,840,33,-746,95,212,368,754,641,-29,424,-703,-670,-520,-965,-589,41,-861,-835,841,385,717,-347,554,902,592,611,89,-144,354,149,-207,-844,372,424,895,697,193}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00006() {
        org.junit.Assert.assertEquals("java.lang.String:S3JUbyBTWWktY09WZi40CTRoNjF1QQ==", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "getLocalizedMessage():java.lang.String",
            new int[]{80,-657,-962,-79,461,-28,-167,-896,55,521,137,-869,628,515,-718,864,-447,-14,654,135,217,69,-280,372,-491,285,-396,-958,874,-362,296,126,-259,662,406,691,-24,-369,-230,451,-497,285,-768,-845,184,658,402,-397,-348,804,-666,170,904,-386,-310,-203,-863,-741,-797,608,597,280,20,532}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00007() {
        org.junit.Assert.assertEquals("java.lang.String:MHg4MDAwMDAwMDAwMDAwMAogYXQgW1NvdXJjZTogb2JqZWN0NDsgbGluZTogLTEsIGNvbHVtbjogMF0=", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "getLocalizedMessage():java.lang.String",
            new int[]{-63,886,-536,259,116,-27,524,-5,-861,544,-976,-516,-970,-751,-545,403,-24,-366,-391,593,-167,-165,-522,-792,183,-50,-510,-539,-973,830,-241,-147,565,73,898,526,335,-976,340,300,-529,805,95,-180,807,-470,384,-723,140,-815,705,-836,80,943,-466,-300,-388,105,97,660,-263,286,415,648}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00008() {
        org.junit.Assert.assertEquals("java.lang.String:Ti9B", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "getLocalizedMessage():java.lang.String",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00009() {
        org.junit.Assert.assertEquals("java.lang.String:KzB4ODAKIGF0IFtTb3VyY2U6IG9iamVjdDM7IGxpbmU6IDAsIGNvbHVtbjogLTFd", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "getLocalizedMessage():java.lang.String",
            new int[]{-849,-197,-920,-138,470,361,-591,818,-987,894,-456,-994,583,-683,-276,-724,413,-748,-260,-490,-588,-141,-522,-883,280,-635,-215,-45,225,914,540,-23,377,431,597,654,859,-768,735,-883,891,-721,-337,887,-654,167,705,-974,706,207,870,606,505,-694,660,-486,-949,712,211,-249,443,185,-879,-336}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00010() {
        org.junit.Assert.assertEquals("java.lang.String:YWFhYWFhYWE=", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "getLocalizedMessage():java.lang.String",
            new int[]{604,-431,-420,394,119,508,29,769,303,-232,-612,-901,-736,19,27,-338,-514,24,-434,600,214,117,-342,-666,974,-133,-770,-467,152,-728,-793,-440,-74,-165,-380,-805,-323,972,381,-767,463,295,-7,-487,-846,-403,-17,909,354,-455,964,-133,-591,-501,862,186,452,197,-910,-105,-293,560,218,-654}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00011() {
        org.junit.Assert.assertEquals("java.lang.String:LS04NjdlMzI5CiBhdCBbU291cmNlOiBvYmplY3Q0OyBsaW5lOiAtMTAwMCwgY29sdW1uOiAtMV0=", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "getLocalizedMessage():java.lang.String",
            new int[]{-308,352,166,-867,-389,329,-202,259,-221,-1000,-1000,-1000,-73,-95,-931,426,-562,1000,880,812,-920,345,1000,87,-937,562,755,907,-309,-878,1000,409,-247,725,-47,983,226,-1000,68,-106,-879,-1000,572,-731,-556,246,-10,-598,348,690,1000,327,1000,-609,83,1000,-370,-287,0,113,610,938,1000,-446}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00012() {
        org.junit.Assert.assertEquals("java.lang.String:MzU1", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "getMessage():java.lang.String",
            new int[]{556,-580,372,355,340,-111,177,-396,-576,-48,233,-413,-562,-748,-125,-663,367,91,-383,-4,-127,-878,-452,844,-619,847,174,13,149,702,542,-61,709,709,874,396,334,-486,-495,-719,-557,-996,481,-750,-739,-383,812,757,-566,2,-921,-903,-190,-295,-123,635,-847,204,-604,-428,-872,-181,319,-683}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00013() {
        org.junit.Assert.assertEquals("java.lang.String:LTB4YmE=", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "getMessage():java.lang.String",
            new int[]{628,-247,-793,-186,-811,-164,524,17,-907,-559,552,-872,-430,-546,-408,-836,-516,-786,35,972,824,-148,-821,-121,412,662,966,-136,-669,-268,248,316,742,413,596,-746,-978,930,233,-782,424,-114,210,951,-155,-702,622,-525,-306,-654,330,-839,-643,-954,-532,-959,-718,711,-211,718,338,-758,-155,993}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00014() {
        org.junit.Assert.assertEquals("java.lang.String:CiBhdCBbU291cmNlOiBvYmplY3Q0OyBsaW5lOiAtMjE0NzQ4MzY0OCwgY29sdW1uOiAtMjE0NzQ4MzY0OF0=", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "getMessage():java.lang.String",
            new int[]{594,-115,177,-976,706,929,854,259,97,189,-1000,-549,-260,1000,-756,-356,521,-284,-802,1000,-465,390,-351,-108,587,280,-1000,-268,-351,1000,-657,-272,163,-812,49,-767,130,364,532,704,356,-633,-398,-1000,-912,299,399,1000,-386,-627,932,633,67,788,-182,140,253,755,-286,-853,-410,237,635,646}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00015() {
        org.junit.Assert.assertEquals("java.lang.String:Ti9B", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "getMessage():java.lang.String",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00016() {
        org.junit.Assert.assertEquals("java.lang.String:YWFhYWFhYWFhYWFhYWFhYWFhYWFhYQogYXQgW1NvdXJjZTogVU5LTk9XTjsgbGluZTogMCwgY29sdW1uOiAtNjI3XQ==", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "getMessage():java.lang.String",
            new int[]{768,44,-68,-429,-208,-328,-267,-912,711,-802,-294,96,-764,-264,-627,-397,679,528,-108,314,635,607,566,812,-173,-853,-765,569,902,-692,952,-103,-854,-355,-262,-249,304,-58,760,-383,-987,741,871,-369,693,-257,39,-428,187,-213,960,364,-81,154,881,-647,871,-408,494,756,-672,-374,-346,-572}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00017() {
        org.junit.Assert.assertEquals("java.lang.String:LTB4ZDI=", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "getMessage():java.lang.String",
            new int[]{-124,-165,-857,-210,61,144,-898,554,-723,-432,-577,-299,613,-375,-886,-246,-223,29,828,148,-808,885,537,-874,-337,452,551,606,-28,310,-203,200,919,-916,-239,-656,-435,646,977,-152,-257,-886,-448,-928,260,904,-147,424,613,-409,182,891,-415,401,-962,920,558,-223,384,119,-931,-338,-742,975}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00018() {
        org.junit.Assert.assertEquals("java.lang.String:bnVsbAogYXQgW1NvdXJjZTogVU5LTk9XTjsgbGluZTogMCwgY29sdW1uOiAyMTQ3NDgzNjQ3XQ==", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "getMessage():java.lang.String",
            new int[]{-744,-792,-133,-603,359,572,-593,576,152,-586,-909,308,-274,-593,18,740,-56,303,597,-791,843,-298,306,-991,892,-720,142,-754,-160,994,-405,101,101,-951,-571,-379,-167,-782,-908,508,172,493,-867,269,-538,968,657,-433,718,370,-443,-341,-941,-275,-980,377,-597,244,-350,-715,-678,741,421,374}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00019() {
        org.junit.Assert.assertEquals("TYPE:java.util.Collections$EmptyList", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "getPath():java.util.List",
            new int[]{486,257,245,-49,-428,215,514,-925,-430,909,-814,-555,-77,266,-167,675,257,-911,22,-93,219,-302,-185,272,71,-781,736,286,-578,926,368,-363,390,584,567,520,674,-919,-626,-848,-425,-160,156,-527,-188,-572,252,136,141,627,-564,837,264,779,-90,831,253,678,188,998,-152,495,-741,-735}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00020() {
        org.junit.Assert.assertEquals("TYPE:java.util.Collections$EmptyList", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "getPath():java.util.List",
            new int[]{-211,624,635,127,-1000,-364,54,614,260,766,-1000,-88,493,908,-227,1000,158,-1000,581,-477,295,-565,273,275,-584,-1000,1000,761,-172,476,-175,-886,15,1000,-5,1000,1000,-673,-251,503,-151,-159,190,-1000,296,-831,514,-235,572,1000,-431,982,373,134,717,500,-88,1000,-11,40,-524,659,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00021() {
        org.junit.Assert.assertEquals("TYPE:java.util.Collections$EmptyList", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "getPath():java.util.List",
            new int[]{449,-990,-161,74,-864,296,-688,720,-986,590,-170,727,-230,-927,926,152,-36,68,-217,479,-244,369,-153,20,-625,-24,856,-628,429,105,712,358,-935,890,-651,550,180,553,-62,14,437,-32,-834,-776,653,-469,67,-782,-707,-939,-32,-957,256,10,448,-742,-79,735,-80,-129,511,-239,414,464}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00022() {
        org.junit.Assert.assertEquals("TYPE:java.util.Collections$EmptyList", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "getPath():java.util.List",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00023() {
        org.junit.Assert.assertEquals("TYPE:java.util.Collections$EmptyList", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "getPath():java.util.List",
            new int[]{-323,559,775,127,906,-113,418,614,-759,-68,736,110,336,908,262,-745,984,26,-806,-706,-687,816,350,962,-921,-826,594,931,-473,-612,-490,624,210,-72,-123,887,341,148,-354,503,799,-788,-478,899,-253,-469,38,-523,-46,784,-986,-8,-608,-773,717,131,449,360,-328,40,-811,-694,-902,910}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00024() {
        org.junit.Assert.assertEquals("TYPE:java.util.Collections$EmptyList", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "getPath():java.util.List",
            new int[]{100,-649,-257,749,-805,-120,265,468,-321,564,-962,83,-843,-598,658,876,38,-914,457,821,632,655,-166,297,-162,-877,-476,994,595,814,793,762,214,-339,-653,868,887,71,862,-368,-796,-842,467,-270,-641,-930,-723,-408,856,992,-908,273,8,-49,-207,-78,-719,6,614,565,-356,614,469,281}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00025() {
        org.junit.Assert.assertEquals("TYPE:java.util.Collections$EmptyList", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "getPath():java.util.List",
            new int[]{-777,-46,-791,-845,-472,-376,-82,298,-909,104,-992,-947,437,-708,399,-247,175,-592,749,641,-493,-417,971,-956,120,531,123,-913,197,-201,-283,5,-832,626,236,-224,30,833,823,-658,621,269,-508,980,30,378,981,538,-487,-789,423,-811,717,-194,-635,110,-187,-701,363,-909,206,334,-635,-576}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00026() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "getPathReference():java.lang.String",
            new int[]{-48,-954,-903,196,27,810,721,605,-621,425,-733,917,963,-495,-492,-234,854,-194,-776,209,805,338,44,-348,-686,-91,559,-174,-344,517,-334,733,-815,964,836,-382,349,864,90,951,318,838,-193,200,931,-936,-832,705,-292,-371,71,-621,130,125,602,-851,-960,825,825,57,-889,-605,-469,766}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00027() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "getPathReference():java.lang.String",
            new int[]{598,-363,-120,-146,-702,-22,390,-286,571,-405,-394,-838,554,917,-20,-104,-690,-976,964,859,515,978,-864,-751,552,-519,301,-584,349,-592,930,-771,177,782,57,-380,760,-510,-196,952,-490,-305,-938,-362,485,-721,567,-14,731,-88,573,-349,115,342,646,258,415,-596,730,-221,499,-130,-467,60}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00028() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "getPathReference():java.lang.String",
            new int[]{545,-465,-127,420,-838,-855,258,-121,915,798,-146,771,-127,520,-827,-496,1000,-984,-500,656,681,-583,908,343,-821,-106,95,-161,-24,338,-989,-342,-154,-728,-981,416,639,931,401,772,-798,-907,-657,464,-335,-383,283,73,398,-103,421,505,333,480,-419,375,72,-61,145,518,233,771,803,-370}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00029() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "getPathReference():java.lang.String",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00030() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "getPathReference():java.lang.String",
            new int[]{43,-193,-686,148,286,-570,652,-486,-523,899,682,340,946,-250,-155,742,526,290,-622,-241,-687,-868,-162,-285,673,-124,-31,464,152,62,-921,105,763,-567,801,-88,289,-606,205,168,-302,-888,-426,340,540,157,845,-373,289,773,719,269,-6,944,-262,234,303,257,-750,-126,-32,224,113,-998}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00031() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "getPathReference():java.lang.String",
            new int[]{-741,-785,254,437,-610,-554,707,-442,-14,-438,-314,608,-70,-735,-628,-377,508,195,631,706,-355,-236,658,-933,284,53,-313,785,439,2,-702,-464,-669,123,657,691,-875,760,10,-877,-704,-495,-810,831,379,820,523,49,-11,-879,546,897,367,-364,-752,-153,-569,-810,-849,248,348,-248,-494,-987}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00032() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "getPathReference():java.lang.String",
            new int[]{-251,-243,586,-462,-471,14,-188,-371,467,585,-626,-466,-397,783,710,272,30,633,-818,643,548,-628,-439,-478,109,-333,-310,384,-716,-740,-891,-707,893,-258,147,723,37,935,-928,513,268,972,239,37,-623,595,857,221,-591,-622,14,452,867,-319,865,-415,819,938,-455,295,626,587,287,-166}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00033() {
        org.junit.Assert.assertEquals("TYPE:java.lang.StringBuilder", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "getPathReference(java.lang.StringBuilder):java.lang.StringBuilder",
            new int[]{964,-912,495,681,998,347,139,-68,411,783,-326,-951,-85,-970,-960,411,-461,-815,279,-93,653,-852,325,819,-685,-281,950,-808,151,331,572,-525,-497,-186,572,329,-534,769,-986,389,615,280,-695,522,717,-492,179,651,-477,459,644,-431,-140,-302,-979,-666,675,121,-926,-180,431,-983,350,-220}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00034() {
        org.junit.Assert.assertEquals("TYPE:java.lang.StringBuilder", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "getPathReference(java.lang.StringBuilder):java.lang.StringBuilder",
            new int[]{972,-279,-119,-283,-845,605,-826,764,338,-706,-745,828,717,-357,-543,-693,974,374,102,472,456,960,80,351,923,-760,979,-519,-150,-5,284,665,864,156,75,-100,-270,571,-33,612,514,341,-385,33,6,-395,997,105,-659,355,-86,-351,-167,399,-343,-290,-516,849,-349,-52,-609,731,2,756}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00035() {
        org.junit.Assert.assertEquals("TYPE:java.lang.StringBuilder", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "getPathReference(java.lang.StringBuilder):java.lang.StringBuilder",
            new int[]{-704,-395,339,380,-49,5,825,-391,-480,146,-128,-862,-877,-477,332,-690,839,901,-577,750,521,-923,-2,760,804,-373,424,-837,-95,220,669,-477,379,492,-860,-217,-158,-229,108,-710,872,999,-880,886,-204,67,-277,-707,-153,507,-982,383,-654,-21,104,66,-63,-699,298,536,-303,928,-834,-613}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00036() {
        org.junit.Assert.assertEquals("TYPE:java.lang.StringBuilder", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "getPathReference(java.lang.StringBuilder):java.lang.StringBuilder",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00037() {
        org.junit.Assert.assertEquals("TYPE:java.lang.StringBuilder", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "getPathReference(java.lang.StringBuilder):java.lang.StringBuilder",
            new int[]{-855,804,24,894,898,982,225,708,656,201,-234,207,-832,-897,253,-250,362,613,261,-614,457,-739,-368,891,818,500,-394,458,516,-30,772,-678,-860,97,-247,-225,241,671,821,871,-996,-869,239,-92,210,-843,-979,277,383,879,1,-362,-896,509,-357,552,941,-461,-141,653,-836,-228,254,-720}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00038() {
        org.junit.Assert.assertEquals("TYPE:java.lang.StringBuilder", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "getPathReference(java.lang.StringBuilder):java.lang.StringBuilder",
            new int[]{-704,-824,-619,-609,927,477,411,788,435,-167,-165,-997,-759,-10,144,-768,-93,-791,-958,-770,265,961,-832,609,974,-385,816,975,907,-12,-939,-838,-651,79,-356,-97,-176,-411,-732,-765,-411,-130,-487,-391,-713,-136,-486,268,-905,-753,723,-228,795,562,-357,-253,-363,386,-789,-125,-383,-248,696,-24}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00039() {
        org.junit.Assert.assertEquals("TYPE:java.lang.StringBuilder", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "getPathReference(java.lang.StringBuilder):java.lang.StringBuilder",
            new int[]{-161,-60,-816,836,-337,204,-454,-197,-443,575,43,805,267,92,-319,-415,932,-23,-493,468,532,-976,-279,651,-657,706,127,-808,51,-143,17,401,-311,-775,-403,474,466,446,-710,99,-278,79,-122,507,738,-808,-690,-26,934,736,-746,149,123,406,-46,716,898,43,-163,917,-7,-259,422,-771}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00040() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "getProcessor():java.lang.Object",
            new int[]{-100,547,486,172,-134,566,-869,-24,-140,-514,209,986,788,-716,376,-308,53,-532,-176,-442,-446,-674,298,-947,-26,401,-123,766,719,-750,476,202,251,945,-937,-860,764,467,-562,91,152,213,92,-719,-950,-881,-871,-133,-645,600,-460,627,-909,436,-783,242,725,37,6,-525,137,-916,829,-973}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00041() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "getProcessor():java.lang.Object",
            new int[]{795,971,-777,494,89,-391,-143,952,-818,823,166,683,299,796,85,-713,104,202,209,875,9,887,-23,164,-355,-568,292,-396,-541,-735,-832,-232,-171,-598,18,-476,-744,623,53,119,-792,876,931,263,35,-908,-719,-486,967,192,997,856,-305,76,326,195,-721,-377,666,702,180,-657,745,-566}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00042() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "getProcessor():java.lang.Object",
            new int[]{596,-934,-387,-118,963,90,500,601,165,519,-753,-200,10,-461,-567,617,876,-592,664,-825,-507,-427,157,-742,-308,217,-387,-785,408,447,734,-646,-408,-270,795,-624,858,905,509,17,-239,-885,124,998,353,-649,127,646,361,-58,270,-921,739,294,689,725,615,445,-163,-856,-257,-385,-336,-410}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00043() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "getProcessor():java.lang.Object",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00044() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "getProcessor():java.lang.Object",
            new int[]{-435,769,886,741,-554,-814,-540,-543,107,366,5,216,110,-971,-724,-994,-563,973,500,-79,232,882,-437,-935,278,687,809,520,-143,345,708,-219,66,-693,700,364,-154,-357,379,921,-15,845,840,-881,-815,-365,-503,783,-82,-213,-40,372,242,905,-319,-282,6,-597,-30,120,-54,-512,-257,437}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00045() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "getProcessor():java.lang.Object",
            new int[]{64,891,-135,551,-631,-746,-653,-241,576,649,-216,-953,685,-488,428,958,-515,-544,-932,807,983,848,-518,395,-478,-140,675,13,910,752,308,573,-714,557,788,952,625,-927,-668,303,-190,-953,991,-1000,27,-172,90,-884,834,364,842,-97,760,423,-16,-375,-487,167,-789,238,-63,-193,910,-44}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00046() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "getProcessor():java.lang.Object",
            new int[]{41,-907,189,56,151,491,618,-486,398,45,-810,-252,-693,-120,-880,-678,945,359,-439,-555,-897,40,666,667,-980,-252,97,-151,-375,143,44,818,-394,-398,-187,-542,879,902,-49,598,975,-737,-493,-20,-266,615,497,-146,-701,-389,986,-720,-127,-121,229,109,939,273,293,777,734,478,279,555}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00047() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "prependPath(com.fasterxml.jackson.databind.JsonMappingException$Reference):void",
            new int[]{154,-1000,36,-1000,1000,95,-1000,1000,1000,272,-1000,1000,837,-794,-141,103,676,1000,1000,1000,77,-25,261,33,402,-726,1000,847,-1000,-1000,-178,-114,-1000,1000,-538,800,16,-369,-1000,1000,-345,568,-1000,173,906,-826,-211,-550,-1000,-1000,-1000,1000,449,177,-42,-1000,-615,-13,-659,157,-611,600,554,-558}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00048() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "prependPath(com.fasterxml.jackson.databind.JsonMappingException$Reference):void",
            new int[]{506,-527,-882,-639,118,-836,564,912,982,244,-4,958,669,-964,655,-977,558,937,370,-92,846,-507,200,-250,-355,-259,573,-225,-827,-316,-804,323,472,-350,-558,826,-976,217,-80,660,-805,-652,-491,-957,-472,452,-749,-519,-455,-805,-808,-336,-25,32,526,-844,70,-288,-820,763,43,277,387,-984}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00049() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "prependPath(com.fasterxml.jackson.databind.JsonMappingException$Reference):void",
            new int[]{-19,-528,681,-24,-447,235,-418,-879,-221,-304,331,158,120,700,-726,-76,467,671,990,-539,190,-706,102,-93,731,787,-727,33,933,-386,-649,455,-225,-639,-895,-314,-904,406,973,-589,-536,-977,-188,634,-588,581,-220,645,-50,641,145,-788,452,-102,99,782,830,175,-564,59,232,959,359,854}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00050() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "prependPath(com.fasterxml.jackson.databind.JsonMappingException$Reference):void",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00051() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "prependPath(com.fasterxml.jackson.databind.JsonMappingException$Reference):void",
            new int[]{171,671,-438,-752,-102,-16,61,206,-790,97,236,-880,-691,760,525,-828,-117,-960,909,-496,495,-429,71,-525,-16,196,-364,-705,941,738,-671,962,-195,-515,388,-458,-962,-86,-492,-965,406,-855,192,-648,-520,-313,515,-745,-893,-874,-36,496,-133,606,-695,848,267,157,230,254,807,-739,-107,876}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00052() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "prependPath(com.fasterxml.jackson.databind.JsonMappingException$Reference):void",
            new int[]{-158,-130,-909,165,416,232,801,-263,754,508,504,-467,239,-16,-560,718,476,788,365,636,96,-58,490,145,-42,452,-424,532,-65,-987,621,-747,899,-238,-946,900,475,442,322,968,675,-685,-671,-683,-384,228,327,-519,182,-667,523,-552,-277,140,945,924,645,-178,-101,-353,112,983,-249,899}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00053() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "prependPath(com.fasterxml.jackson.databind.JsonMappingException$Reference):void",
            new int[]{-298,-544,-1000,-1000,89,-584,564,216,989,172,23,871,341,-74,803,165,1000,1000,-935,24,1000,-309,642,144,-1000,-369,804,-276,-724,-602,-224,-788,341,-261,-1000,1000,-247,838,-821,1000,-232,-107,-653,-546,-277,391,-481,-82,-1000,-829,237,-556,1000,-4,772,-582,-55,-1000,-73,623,-227,1000,-176,-688}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00054() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "prependPath(java.lang.Object,int):void",
            new int[]{-351,614,928,-402,-790,-383,-647,-434,525,391,-10,-692,725,245,-725,-908,-550,394,863,-34,143,-65,-934,-94,-806,-764,164,-720,-153,581,-449,161,-279,714,533,-68,932,-631,-576,-972,-88,-168,-490,-310,249,97,-531,-831,118,313,-173,918,225,-164,206,-967,557,-564,246,441,711,-985,333,145}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00055() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "prependPath(java.lang.Object,int):void",
            new int[]{918,120,-1000,537,-956,-419,-570,870,71,456,491,-327,-585,347,-510,-561,-91,69,-930,409,365,18,881,-656,524,-311,-874,100,803,180,561,-394,-701,459,-706,732,579,-516,-400,983,922,328,-95,934,889,906,44,910,371,-926,-10,526,-421,-525,-672,-609,-145,-244,944,546,609,545,-385,-990}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00056() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "prependPath(java.lang.Object,int):void",
            new int[]{-964,284,-991,-902,392,-910,-748,-506,-953,614,-857,-911,432,493,-494,-731,550,-312,531,42,654,-920,692,677,817,-81,413,599,-717,-781,-988,858,-485,-956,260,-625,-63,-950,-278,-373,522,594,4,398,-456,283,-2,-183,-859,911,-741,28,-401,398,787,-502,-284,560,638,278,19,-666,-985,-731}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00057() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "prependPath(java.lang.Object,int):void",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00058() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "prependPath(java.lang.Object,int):void",
            new int[]{-761,941,506,181,-565,-833,-64,788,-53,502,-830,585,565,-346,-461,55,860,327,-328,-10,47,883,-704,-954,-787,-257,680,-921,150,-576,581,-585,-6,-10,319,67,-6,-937,-520,359,-134,556,-329,-583,379,-222,733,546,104,694,872,654,-414,-248,275,550,-432,-58,948,220,-602,487,-231,980}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00059() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "prependPath(java.lang.Object,int):void",
            new int[]{-791,-26,-985,-201,-902,-415,-984,3,126,589,989,-911,-294,283,611,454,-326,-834,418,-574,-788,-715,-254,-768,634,-590,593,-758,60,992,526,170,953,-308,-454,781,645,672,693,86,59,-171,92,26,-921,-335,-866,193,268,-401,-473,273,-21,172,-938,-417,274,828,131,319,-453,-281,241,-33}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00060() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "prependPath(java.lang.Object,int):void",
            new int[]{247,-638,97,679,684,-159,157,-628,537,-251,-975,-191,407,89,493,984,493,-56,615,750,331,893,-183,-159,411,-138,-316,-836,-550,-614,-155,569,106,107,-853,188,-989,735,-826,-155,134,-323,-899,71,-298,61,859,-194,151,-10,619,-989,-59,514,730,-928,-566,-972,-577,174,504,-421,-187,598}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00061() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "prependPath(java.lang.Object,java.lang.String):void",
            new int[]{-938,-244,549,-126,715,-595,378,-457,603,312,720,24,-414,581,-753,443,763,-385,384,-757,389,707,652,-163,-619,786,57,-132,203,-768,-264,776,744,334,104,385,500,-161,-442,-411,822,-653,-571,835,292,803,320,-914,413,-750,232,-788,-333,-824,-51,-657,-217,265,40,-368,553,202,523,75}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00062() {
        org.junit.Assert.assertEquals("THROW:java.lang.NullPointerException", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "prependPath(java.lang.Object,java.lang.String):void",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00063() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "prependPath(java.lang.Object,java.lang.String):void",
            new int[]{897,-737,767,-442,74,-112,-492,-835,-143,154,-997,-115,344,-868,-709,375,636,485,281,159,-956,334,980,-227,-278,419,529,-271,-349,-99,945,926,-240,741,446,115,647,555,-916,-602,802,-932,-973,385,-413,-143,287,-427,265,-73,958,-174,348,-124,-926,-625,-801,858,-884,708,437,-601,-122,890}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00064() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "prependPath(java.lang.Object,java.lang.String):void",
            new int[]{-197,-262,-425,-947,4,192,473,23,773,-463,-685,38,23,-819,863,840,-437,372,-295,-562,907,366,328,-322,-1,-675,-657,-691,218,-492,715,881,-53,921,848,808,609,-470,221,-703,-427,-618,-118,469,-380,552,570,980,757,672,-515,712,-899,-994,807,704,-753,522,943,-626,-872,-781,179,331}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00065() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "prependPath(java.lang.Object,java.lang.String):void",
            new int[]{-994,762,-492,725,435,-88,-824,-293,461,777,-411,290,112,577,-712,929,-709,-350,-593,-578,43,-291,-458,-98,98,-321,-456,-468,880,-605,840,-6,953,112,886,850,-407,650,194,238,-373,-705,984,964,-24,101,-5,-941,457,116,-782,-888,284,-756,-609,308,-531,928,9,975,854,-314,252,-341}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00066() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "prependPath(java.lang.Object,java.lang.String):void",
            new int[]{-161,591,-212,-697,-930,287,705,-107,311,813,-40,129,-495,616,-293,118,-335,-545,581,873,-389,-366,636,467,837,944,-17,-863,-202,-975,381,295,792,492,68,-545,-747,-929,894,437,758,-750,-500,-191,-641,-487,702,555,-88,83,-482,185,-948,284,334,-896,126,128,-397,-28,987,-455,154,-23}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00067() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "prependPath(java.lang.Object,java.lang.String):void",
            new int[]{-333,-929,926,-450,-251,-585,-921,577,-32,-686,-885,-463,423,520,-460,-793,440,-999,-960,-827,-506,697,-765,-795,865,159,-623,-655,560,-976,-521,955,-64,908,-603,-25,-918,230,203,974,-476,716,826,259,-908,897,-626,226,906,780,826,-548,340,53,838,-420,554,-318,-684,991,743,-444,-935,419}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00068() {
        org.junit.Assert.assertEquals("java.lang.String:Y29tLmZhc3RlcnhtbC5qYWNrc29uLmRhdGFiaW5kLkpzb25NYXBwaW5nRXhjZXB0aW9uOiAgLS04MzUg", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "toString():java.lang.String",
            new int[]{-936,467,794,835,-933,-532,871,301,-326,321,271,-409,-642,705,434,237,790,-676,501,-664,234,986,-221,138,-488,-18,191,989,-931,-43,104,37,958,-347,-364,-989,214,903,578,6,-2,115,-611,704,129,-935,-606,-231,208,-678,260,-787,-624,837,-892,502,948,-658,203,-158,-350,-941,-927,-316}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00069() {
        org.junit.Assert.assertEquals("java.lang.String:Y29tLmZhc3RlcnhtbC5qYWNrc29uLmRhdGFiaW5kLkpzb25NYXBwaW5nRXhjZXB0aW9uOiA=", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "toString():java.lang.String",
            new int[]{86,-993,657,184,103,27,314,-420,28,-986,-463,-137,817,733,-960,-102,-971,-546,-83,-557,899,-245,-144,-364,-124,345,-4,-432,204,-339,912,-48,-546,-820,865,726,524,-602,535,107,536,261,-243,93,352,442,-566,-317,-74,348,-218,216,-370,-57,326,-877,-146,611,-354,-876,651,102,-217,-556}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00070() {
        org.junit.Assert.assertEquals("java.lang.String:Y29tLmZhc3RlcnhtbC5qYWNrc29uLmRhdGFiaW5kLkpzb25NYXBwaW5nRXhjZXB0aW9uOiA3VlxIRHpvcjZJYTA3MWUKIGF0IFtTb3VyY2U6IG9iamVjdDA7IGxpbmU6IC0xLCBjb2x1bW46IC0xXQ==", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "toString():java.lang.String",
            new int[]{238,844,399,-975,-182,740,-64,767,-3,-667,39,532,521,524,-917,470,152,639,-632,498,937,-903,322,605,-672,-484,216,-456,-544,-514,-897,-166,-817,-615,-667,-72,160,709,82,3,-936,115,626,333,416,-905,-230,522,-46,572,-207,-86,-602,-958,543,490,612,-111,909,-777,-299,436,802,-557}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00071() {
        org.junit.Assert.assertEquals("java.lang.String:Y29tLmZhc3RlcnhtbC5qYWNrc29uLmRhdGFiaW5kLkpzb25NYXBwaW5nRXhjZXB0aW9uOiBOL0E=", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "toString():java.lang.String",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00072() {
        org.junit.Assert.assertEquals("java.lang.String:Y29tLmZhc3RlcnhtbC5qYWNrc29uLmRhdGFiaW5kLkpzb25NYXBwaW5nRXhjZXB0aW9uOiAtMzg3bAogYXQgW1NvdXJjZTogVU5LTk9XTjsgbGluZTogMCwgY29sdW1uOiAtMjE0NzQ4MzY0OF0=", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "toString():java.lang.String",
            new int[]{334,-57,649,-387,-467,688,-54,-93,437,-683,952,-450,-910,417,290,968,-135,-939,857,272,-833,-988,-389,-198,693,962,-520,169,-433,328,599,-465,-981,-725,775,-276,851,694,150,-561,-90,639,316,316,992,399,-164,-145,186,-188,46,361,-478,-325,-684,948,-29,-787,530,387,-660,409,-562,125}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00073() {
        org.junit.Assert.assertEquals("java.lang.String:Y29tLmZhc3RlcnhtbC5qYWNrc29uLmRhdGFiaW5kLkpzb25NYXBwaW5nRXhjZXB0aW9uOiAtLTk3TA==", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "toString():java.lang.String",
            new int[]{-355,-487,-359,97,647,227,-339,452,237,-59,555,-795,-919,689,651,-549,-422,-625,307,-841,192,-97,331,-507,303,-904,667,-240,-254,-778,336,-930,-525,-879,395,602,-549,963,636,-934,748,469,146,-608,-859,-939,-550,-979,988,883,-41,-778,-927,-155,698,817,290,-31,880,401,505,159,-197,682}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00074() {
        org.junit.Assert.assertEquals("java.lang.String:Y29tLmZhc3RlcnhtbC5qYWNrc29uLmRhdGFiaW5kLkpzb25NYXBwaW5nRXhjZXB0aW9uOiA2OTJlMTk1CiBhdCBbU291cmNlOiBvYmplY3QwOyBsaW5lOiAwLCBjb2x1bW46IC0yMTQ3NDgzNjQ4XQ==", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "toString():java.lang.String",
            new int[]{-118,415,198,-692,-784,195,-516,1000,755,-983,747,1000,475,299,-255,184,531,750,-790,-1000,-272,94,1000,-531,-1000,-576,-350,-12,581,-341,-606,1000,-146,1000,-1000,-991,59,564,490,-772,-532,-406,43,278,-215,42,380,-817,891,-795,394,-1000,-508,-379,-244,1000,657,-554,877,-1000,1000,-345,44,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00075() {
        org.junit.Assert.assertEquals("TYPE:com.fasterxml.jackson.databind.JsonMappingException", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "wrapWithPath(java.lang.Throwable,com.fasterxml.jackson.databind.JsonMappingException$Reference):com.fasterxml.jackson.databind.JsonMappingException",
            new int[]{-565,400,-764,-1000,-806,-1000,-1000,211,-1000,-960,-1000,-1000,1000,956,719,-45,924,-688,1000,-418,-21,229,-193,-664,1000,-796,-285,1000,-3,-433,-96,-348,-312,405,-573,110,-755,223,-254,-1000,588,-544,1000,-1000,-1000,-1000,751,-789,1000,701,263,645,130,-748,-1000,-296,-1000,372,357,155,265,744,789,642}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00076() {
        org.junit.Assert.assertEquals("TYPE:com.fasterxml.jackson.databind.JsonMappingException", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "wrapWithPath(java.lang.Throwable,com.fasterxml.jackson.databind.JsonMappingException$Reference):com.fasterxml.jackson.databind.JsonMappingException",
            new int[]{-201,-292,-762,-562,200,-181,-1000,-118,-696,-1000,-733,-466,369,53,415,-233,1000,-841,969,-369,445,32,-1000,-754,1000,393,-385,1000,167,1000,-106,163,-218,271,522,-444,-1000,326,307,-763,1000,-207,-330,-977,-689,-104,1000,414,-153,58,1000,976,-601,-412,492,1000,402,771,238,145,-12,-962,312,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00077() {
        org.junit.Assert.assertEquals("TYPE:com.fasterxml.jackson.databind.JsonMappingException", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "wrapWithPath(java.lang.Throwable,com.fasterxml.jackson.databind.JsonMappingException$Reference):com.fasterxml.jackson.databind.JsonMappingException",
            new int[]{-839,-941,-638,-88,895,-24,168,-51,963,-353,364,-522,-92,344,-400,846,699,-152,621,-608,666,-60,-728,-90,604,706,-381,-966,442,500,595,-527,-961,335,-706,698,-548,407,-666,426,295,-512,550,29,729,989,672,863,-980,654,644,-546,641,31,739,-566,-562,-837,749,-806,500,-764,169,315}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00078() {
        org.junit.Assert.assertEquals("TYPE:com.fasterxml.jackson.databind.JsonMappingException", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "wrapWithPath(java.lang.Throwable,com.fasterxml.jackson.databind.JsonMappingException$Reference):com.fasterxml.jackson.databind.JsonMappingException",
            new int[]{-97,-177,-918,77,1000,-118,-1000,-354,-787,647,-837,-626,559,542,924,-345,1000,-1000,978,-1000,538,1000,-1000,-977,-703,749,-265,461,524,1000,-374,-843,-1000,689,665,-303,-1000,349,-445,-219,1000,-282,466,-1000,-996,-373,1000,-14,-572,-51,1000,1000,-773,-534,583,821,1000,839,-33,-1,251,-1000,582,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00079() {
        org.junit.Assert.assertEquals("TYPE:com.fasterxml.jackson.databind.JsonMappingException", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "wrapWithPath(java.lang.Throwable,java.lang.Object,int):com.fasterxml.jackson.databind.JsonMappingException",
            new int[]{305,865,-61,-89,-618,-343,-74,1000,-477,-121,-219,1000,-677,-1000,-60,533,-529,589,-609,-1000,658,441,104,-234,-430,569,1000,-779,1000,963,-546,572,-48,569,336,1000,767,-775,105,-722,264,72,-433,1000,1000,-989,-544,253,-371,-746,-840,-444,111,328,348,73,1000,808,-745,418,-594,913,410,479}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00080() {
        org.junit.Assert.assertEquals("TYPE:com.fasterxml.jackson.databind.JsonMappingException", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "wrapWithPath(java.lang.Throwable,java.lang.Object,int):com.fasterxml.jackson.databind.JsonMappingException",
            new int[]{-670,473,874,239,434,453,496,859,-618,-85,97,-824,-736,-849,581,5,-459,-118,-917,-948,-911,839,-509,-462,-817,-606,-460,201,426,-886,71,-365,620,-778,-81,-829,-159,852,-929,-401,570,740,-769,-123,623,-503,734,715,861,998,-123,399,149,-434,-846,547,907,617,642,-351,-274,218,-178,148}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00081() {
        org.junit.Assert.assertEquals("TYPE:com.fasterxml.jackson.databind.JsonMappingException", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "wrapWithPath(java.lang.Throwable,java.lang.Object,int):com.fasterxml.jackson.databind.JsonMappingException",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00082() {
        org.junit.Assert.assertEquals("TYPE:com.fasterxml.jackson.databind.JsonMappingException", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "wrapWithPath(java.lang.Throwable,java.lang.Object,java.lang.String):com.fasterxml.jackson.databind.JsonMappingException",
            new int[]{481,588,-817,-1000,-1000,-1000,-1000,-281,589,-1000,752,782,-354,903,-982,805,-1000,-4,-1000,577,-1000,-327,1000,88,501,-1000,-880,-400,-77,-100,-491,1000,778,842,79,-1000,392,-548,-793,-1000,-736,-1000,-393,-704,515,742,1000,1000,-1000,-474,1000,147,762,670,-349,76,249,387,-853,-183,-785,-821,-741,645}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00083() {
        org.junit.Assert.assertEquals("THROW:java.lang.NullPointerException", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "wrapWithPath(java.lang.Throwable,java.lang.Object,java.lang.String):com.fasterxml.jackson.databind.JsonMappingException",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00084() {
        org.junit.Assert.assertEquals("TYPE:com.fasterxml.jackson.databind.JsonMappingException", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "wrapWithPath(java.lang.Throwable,java.lang.Object,java.lang.String):com.fasterxml.jackson.databind.JsonMappingException",
            new int[]{-677,-782,-635,-543,795,-695,-396,-478,504,613,-985,-750,-890,-129,335,291,627,-282,891,-826,-549,-830,-144,-847,-692,211,1,241,-526,888,-906,-449,153,306,714,330,5,923,334,429,465,705,239,-699,-278,-158,89,-883,-8,-30,749,82,-897,149,-604,619,-726,-790,-166,-264,459,486,-526,-413}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00085() {
        org.junit.Assert.assertEquals("TYPE:com.fasterxml.jackson.databind.JsonMappingException", DEReplay.run(
            "com.fasterxml.jackson.databind.JsonMappingException", "com.fasterxml.jackson.databind.JsonMappingException", "wrapWithPath(java.lang.Throwable,java.lang.Object,java.lang.String):com.fasterxml.jackson.databind.JsonMappingException",
            new int[]{-228,133,800,421,-162,-683,-768,-759,-154,-233,-848,790,893,648,985,-400,-597,225,902,-400,761,-974,810,995,654,566,173,821,-420,-849,972,446,572,-745,-340,-481,-789,-963,123,222,730,-359,-690,69,-824,133,493,-59,419,-873,-117,583,110,498,750,-662,-365,-116,-902,-420,-456,-838,475,-41}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00086() {
        org.junit.Assert.assertEquals("java.lang.String:Ti9BLg==", DEReplay.run(
            "com.fasterxml.jackson.databind.deser.UnresolvedForwardReference", "com.fasterxml.jackson.databind.deser.UnresolvedForwardReference", "getMessage():java.lang.String",
            new int[]{-992,197,256,373,-279,984,-174,522,-316,312,-833,410,150,378,-485,-635,645,491,-527,-961,119,-597,-958,759,-72,-519,519,-273,-98,323,-298,-33,-125,396,-259,-78,280,802,4,152,673,-621,-668,-271,368,-4,-790,605,786,-864,-489,-516,536,-386,-254,541,-193,-329,34,-296,192,530,352,173}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00087() {
        org.junit.Assert.assertEquals("java.lang.String:NjM1CiBhdCBbU291cmNlOiBVTktOT1dOOyBsaW5lOiAtMjE0NzQ4MzY0OCwgY29sdW1uOiAyMTQ3NDgzNjQ3XQ==", DEReplay.run(
            "com.fasterxml.jackson.databind.deser.UnresolvedForwardReference", "com.fasterxml.jackson.databind.deser.UnresolvedForwardReference", "getMessage():java.lang.String",
            new int[]{852,731,67,635,-947,289,549,-116,-757,959,926,-35,-824,-55,-33,823,-461,185,940,-651,-691,-308,-514,-529,-619,61,20,35,-69,735,-172,855,-881,-441,-69,286,953,702,770,252,385,132,851,791,57,452,-452,-138,-496,-818,-523,-588,59,-710,-925,-494,-743,174,311,738,-927,-823,-169,-986}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00088() {
        org.junit.Assert.assertEquals("java.lang.String:Ti9BLg==", DEReplay.run(
            "com.fasterxml.jackson.databind.deser.UnresolvedForwardReference", "com.fasterxml.jackson.databind.deser.UnresolvedForwardReference", "getMessage():java.lang.String",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00089() {
        org.junit.Assert.assertEquals("java.lang.String:Ti9BCiBhdCBbU291cmNlOiBvYmplY3QzOyBsaW5lOiAtMSwgY29sdW1uOiAtMV0=", DEReplay.run(
            "com.fasterxml.jackson.databind.deser.UnresolvedForwardReference", "com.fasterxml.jackson.databind.deser.UnresolvedForwardReference", "getMessage():java.lang.String",
            new int[]{-652,478,672,-777,2,-130,697,-122,-332,-519,202,794,226,-331,853,102,218,50,656,-275,694,775,-679,839,59,-696,-143,-101,298,-838,394,-518,-983,-932,228,-813,29,-604,988,390,-589,32,-60,791,338,-692,-483,379,363,-35,-647,-323,-720,837,320,-31,220,322,397,-440,-792,-396,-483,87}));
    }
}
