import java.lang.reflect.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Deterministic test-program decoder. Used unchanged during search and JUnit replay. */
final class DEReplay {
    public static final int DIMENSIONS = 64;
    /** Local generic bean used to create stable reflection Type and Field values. */
    public static final class GenericInput {
        public String text;
        public java.util.List<String> names;
        public java.util.Map<String, Integer> counts;
        public java.util.List<java.util.Map<String, Long>> nested;
        public int[] numbers;
        public String[] words;
    }
    static final class Genes {
        final int[] values; int at; Field lastField;
        Object jacksonBean, jacksonProvider, jacksonGenerator;
        StringWriter jacksonOutput;
        Genes(int[] values) { this.values = values; }
        int next() { return values[(at++) % values.length]; }
        int pick(int n) { return Math.floorMod(next(), n); }
    }
    public static final class Observation {
        public String token, error, generatedSource;
        public boolean reachedTarget;
        public int setupCalls, setupFailures, nullFallbacks;
    }
    public static String signature(Method m) {
        StringJoiner params = new StringJoiner(",");
        for (Class<?> t : m.getParameterTypes()) params.add(t.getTypeName());
        return m.getName() + "(" + params + "):" + m.getReturnType().getTypeName();
    }
    static Class<?> load(String name) throws ClassNotFoundException {
        return Class.forName(name, true, Thread.currentThread().getContextClassLoader());
    }
    static Method method(String target, String signature) throws Exception {
        for (Method m : load(target).getDeclaredMethods())
            if (signature(m).equals(signature)) {
                // Public methods on package-private Defects4J classes (for
                // example Gson's TypeInfoFactory) are not reflectively
                // accessible until opened on the unnamed application module.
                if (!m.isAccessible()) m.setAccessible(true);
                return m;
            }
        throw new NoSuchMethodException(signature);
    }
    static List<Constructor<?>> constructors(Class<?> type) {
        List<Constructor<?>> out = new ArrayList();
        if (!Modifier.isAbstract(type.getModifiers()) && Modifier.isPublic(type.getModifiers()))
            for (Constructor<?> c : type.getConstructors())
                if (c.getParameterTypes().length <= 6) out.add(c);
        Collections.sort(out, new Comparator<Constructor<?>>() {
            public int compare(Constructor<?> a, Constructor<?> b) {
                int byArity = a.getParameterTypes().length - b.getParameterTypes().length;
                return byArity != 0 ? byArity : a.toString().compareTo(b.toString());
            }
        });
        return out;
    }
    private static Object[] arguments(Class<?>[] types, Genes g, int depth,
                                      Observation report) throws Exception {
        Object[] args = new Object[types.length];
        for (int i = 0; i < types.length; i++) args[i] = value(types[i], g, depth, report);
        return args;
    }
    private static Object[] arguments(Method method, Genes g, int depth,
                                      Observation report) throws Exception {
        Class<?>[] types = method.getParameterTypes();
        Object[] args = new Object[types.length];
        boolean closureCompile = method.getDeclaringClass().getName().equals("com.google.javascript.jscomp.Compiler")
            && method.getName().equals("compile");
        Type[] generic = method.getGenericParameterTypes();
        boolean jacksonSerialization = method.getDeclaringClass().getName().equals(
            "com.fasterxml.jackson.databind.ser.BeanPropertyWriter")
            && method.getName().startsWith("serializeAs")
            && types.length == 3 && types[0] == Object.class;
        for (int i = 0; i < types.length; i++) {
            if (jacksonSerialization && g.jacksonBean != null) {
                if (i == 0) args[i] = g.jacksonBean;
                else if (i == 1) args[i] = g.jacksonGenerator;
                else args[i] = g.jacksonProvider;
                continue;
            }
            if (closureCompile && (List.class.isAssignableFrom(types[i])
                    || (types[i].isArray() && load("com.google.javascript.jscomp.SourceFile")
                        .isAssignableFrom(types[i].getComponentType())))) {
                // Compiler.compile takes externs and inputs in either Lists or
                // arrays depending on Closure version. Keep externs empty and
                // supply a nonempty, gene-selected input program.
                if (i == 0) args[i] = types[i].isArray()
                    ? Array.newInstance(types[i].getComponentType(), 0) : new ArrayList();
                else {
                    Object sourceFile = value(load("com.google.javascript.jscomp.SourceFile"),
                        g, depth + 1, report);
                    if (types[i].isArray()) {
                        Object files = Array.newInstance(types[i].getComponentType(), 1);
                        Array.set(files, 0, sourceFile); args[i] = files;
                    } else args[i] = new ArrayList(Collections.singletonList(sourceFile));
                }
            } else args[i] = value(types[i], g, depth, report);
        }
        return args;
    }
    private static Number number(Genes g) {
        int n = g.next();
        switch (g.pick(12)) {
            case 0: return 0; case 1: return 1; case 2: return -1;
            case 3: return Integer.MAX_VALUE; case 4: return Integer.MIN_VALUE;
            case 5: return Long.MAX_VALUE; case 6: return Long.MIN_VALUE;
            case 7: return Double.NaN; case 8: return Double.POSITIVE_INFINITY;
            case 9: return Double.NEGATIVE_INFINITY; case 10: return n / 10.0;
            default: return n;
        }
    }
    private static String string(Genes g) {
        int mode = g.pick(16), n = g.next();
        String digits = Long.toString(Math.abs((long)n));
        String sign = new String[]{"", "-", "+", "--"}[g.pick(4)];
        switch (mode) {
            case 0: return null; case 1: return ""; case 2: return " ";
            case 3: return Integer.toString(n);
            case 4: return sign + digits;
            case 5: return sign + digits + "." + g.pick(1000);
            case 6: return sign + digits + "e" + g.next();
            case 7: return sign + "0x" + Long.toHexString(Math.abs((long)n));
            case 8: return sign + "0x8" + "0".repeat(g.pick(20));
            case 9: return sign + digits + "fFdDlL".charAt(g.pick(6));
            case 10: return " " + sign + digits + " ";
            case 11: return new String[]{"true", "false", "null", "NaN", "Infinity"}[g.pick(5)];
            case 12: return "a".repeat(g.pick(25));
            default:
                String alphabet = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ+-._ /\\\t\n";
                StringBuilder s = new StringBuilder();
                int length = g.pick(25);
                for (int i = 0; i < length; i++) s.append(alphabet.charAt(g.pick(alphabet.length())));
                return s.toString();
        }
    }
    private static Object value(Class<?> t, Genes g, int depth, Observation report) throws Exception {
        if (t == String.class || t == CharSequence.class) return string(g);
        if (t == Comparable.class) return "key" + g.pick(5);
        if (t == boolean.class || t == Boolean.class) return g.pick(2) == 0;
        if (t == char.class || t == Character.class) return (char)g.pick(128);
        if (t == byte.class || t == Byte.class) return number(g).byteValue();
        if (t == short.class || t == Short.class) return number(g).shortValue();
        if (t == int.class || t == Integer.class) return number(g).intValue();
        if (t == long.class || t == Long.class) return number(g).longValue();
        if (t == float.class || t == Float.class) return number(g).floatValue();
        if (t == double.class || t == Double.class || t == Number.class) return number(g).doubleValue();
        if (t.isEnum()) {
            Object[] constants = t.getEnumConstants();
            return constants.length == 0 ? null : constants[g.pick(constants.length)];
        }
        if (t == Object.class) return g.pick(3) == 0 ? null : "object" + g.pick(5);
        if (depth >= 3) { report.nullFallbacks++; return null; }
        if (t.isArray()) {
            int length = g.pick(6);
            Object array = Array.newInstance(t.getComponentType(), length);
            for (int i = 0; i < length; i++) Array.set(array, i, value(t.getComponentType(), g, depth + 1, report));
            return array;
        }
        if (t == List.class || t == Collection.class || t == Iterable.class || t == Set.class) {
            Collection<Object> items = t == Set.class ? new LinkedHashSet() : new ArrayList();
            int size = g.pick(5);
            for (int i = 0; i < size; i++) items.add("item" + g.pick(5));
            return items;
        }
        if (t == Map.class) {
            Map<Object, Object> items = new LinkedHashMap();
            int size = g.pick(5);
            for (int i = 0; i < size; i++) items.put("key" + g.pick(5), number(g));
            return items;
        }
        if (t == java.util.Date.class) return new java.util.Date(g.next() * 86400000L);
        if (t == Class.class) return String.class;
        if (t == java.lang.reflect.Field.class) {
            Field[] fields = GenericInput.class.getFields();
            g.lastField = fields[g.pick(fields.length)];
            return g.lastField;
        }
        if (t == java.lang.reflect.Type.class) {
            if (g.lastField != null && g.pick(3) == 0)
                return g.lastField.getDeclaringClass();
            Field[] fields = GenericInput.class.getFields();
            return fields[g.pick(fields.length)].getGenericType();
        }
        if (t == java.io.Reader.class || t == java.io.BufferedReader.class
                || t == java.io.StringReader.class) {
            String content = "header,value\n" + string(g) + "," + number(g) + "\n"
                + "alpha,beta\n";
            StringReader reader = new StringReader(content);
            return t == java.io.BufferedReader.class ? new BufferedReader(reader) : reader;
        }
        if (t.getName().equals("org.apache.commons.csv.CSVFormat")) {
            Class<?> format = load("org.apache.commons.csv.CSVFormat");
            for (String fieldName : new String[]{"DEFAULT", "RFC4180", "EXCEL"}) try {
                Object result = format.getField(fieldName).get(null);
                if (t.isInstance(result)) return result;
            } catch (ReflectiveOperationException ignored) { }
            for (Method factory : format.getMethods())
                if (Modifier.isStatic(factory.getModifiers()) && factory.getParameterTypes().length == 0
                        && t.isAssignableFrom(factory.getReturnType())) try {
                    return factory.invoke(null);
                } catch (ReflectiveOperationException ignored) { }
        }
        if (t.getName().equals("com.google.javascript.jscomp.SourceFile")) {
            Class<?> source = load("com.google.javascript.jscomp.SourceFile");
            for (Method factory : source.getMethods())
                if (Modifier.isStatic(factory.getModifiers()) && factory.getName().equals("fromCode")
                        && factory.getParameterTypes().length == 2 && factory.getParameterTypes()[0] == String.class
                        && factory.getParameterTypes()[1] == String.class) {
                    String replaySource = System.getProperty("de.generated.source");
                    if (replaySource != null) {
                        try {
                            report.generatedSource = replaySource;
                            return factory.invoke(null, "de-input.js", replaySource);
                        } catch (ReflectiveOperationException ignored) { }
                    }
                    String[] unusedParameterScripts = {
                        "window.f = function(a) {};",
                        "window.f = function(a, b) { return b; };",
                        "window.f = function(a, b) { var used = b; return used; };",
                        "window['f'] = function(unused) {};",
                        "window.f = function(unused, value) { return value; };",
                        "window['f'] = function(unused, value) { return value; };",
                        "window.f = function(first, unused, last) { return last; };",
                        "window.f = function(unused) { var local = 1; return local; };",
                        "window.f = function(unused, value) { var alias = value; return alias; };",
                        "window.f = function(unused, value) { if (value) { return 1; } return 2; };",
                        "window.f = function(unused, value) { value = value + 1; return value; };",
                        "window.f = function(unused, value) { return function() { return value; }; };",
                        "window.f = function(unused) { function inner() { return 1; } return inner(); };",
                        "window.f = function(a, b, unused) { return a + b; };",
                        "window.f = function(a, unused, b, c) { return a + c; };"
                    };
                    String[] catchDependencyScripts = {
                        "window.f = function() { var saved; try { throw Error('x'); } catch (caught) { saved = caught; } return saved.stack; };",
                        "window.f = function(flag) { var saved; try { if (flag) throw Error('x'); } catch (caught) { saved = caught; } return saved.message; };",
                        "window.f = function() { var saved; try { throw Error('x'); } catch (caught) { saved = caught; } return saved.name; };",
                        "window.f = function() { var saved; try { throw Error('x'); } catch (caught) { saved = caught; } return String(saved); };",
                        "window.f = function(flag) { var saved; try { if (flag) throw Error('x'); } catch (problem) { saved = problem; } return saved.stack; };",
                        "window.f = function() { var saved; try { throw Error('x'); } catch (problem) { saved = problem; } return saved.message; };"
                    };
                    String[] genericScripts = {
                        "function f(unused, used) { var local = 1; return used; } f(1, 2);",
                        "function f() { var unused = 1; var used = 2; return used; } f();",
                        "function f(x) { var first = x; first = 3; return x; } f(2);",
                        "function f() { var unused = 1; } f();",
                        "function keep() { var dead = 1; return 7; } keep();"
                    };
                    String modified = System.getProperty("de.modified.classes", "");
                    String[] scripts;
                    if (modified.contains("RemoveUnusedVars") && modified.contains("FlowSensitiveInlineVariables")) {
                        scripts = new String[unusedParameterScripts.length + catchDependencyScripts.length];
                        System.arraycopy(unusedParameterScripts, 0, scripts, 0, unusedParameterScripts.length);
                        System.arraycopy(catchDependencyScripts, 0, scripts, unusedParameterScripts.length,
                            catchDependencyScripts.length);
                    }
                    else if (modified.contains("FlowSensitiveInlineVariables")) scripts = catchDependencyScripts;
                    else if (modified.contains("RemoveUnusedVars")) scripts = unusedParameterScripts;
                    else scripts = genericScripts;
                    try {
                        String code = scripts[g.pick(scripts.length)];
                        report.generatedSource = code;
                        return factory.invoke(null, "de-input.js", code);
                    }
                    catch (ReflectiveOperationException ignored) { }
                }
        }
        if (t.getName().equals("com.google.javascript.jscomp.CompilerOptions")) {
            try {
                Object options = t.getConstructor().newInstance();
                // In Closure Compiler, unused-variable passes are enabled by
                // CompilationLevel, rather than by a CompilerOptions enum
                // setter. Apply the real public configuration when available.
                try {
                    Class<?> levelType = load("com.google.javascript.jscomp.CompilationLevel");
                    Object advanced = levelType.getField("ADVANCED_OPTIMIZATIONS").get(null);
                    for (Method configure : levelType.getMethods())
                        if (configure.getName().equals("setOptionsForCompilationLevel")
                                && configure.getParameterTypes().length == 1
                                && configure.getParameterTypes()[0].isInstance(options)) {
                            configure.invoke(advanced, options); break;
                        }
                } catch (ReflectiveOperationException ignored) { }
                // Also set the relevant options directly for Closure releases
                // whose compilation-level helper no longer enables this pass.
                for (Class<?> current = t; current != null; current = current.getSuperclass())
                    for (Field field : current.getDeclaredFields()) {
                        String name = field.getName().toLowerCase(Locale.ROOT);
                        if (field.getType() == boolean.class && name.equals("removeglobals")) try {
                            // Closure-1 specifically guards argument removal
                            // when globals are preserved. Keep the optimization
                            // pass enabled while exercising that configuration.
                            field.setAccessible(true); field.setBoolean(options, false);
                        } catch (Exception ignored) { }
                        if (field.getType() == boolean.class
                                && (name.contains("removeunusedvar") || name.contains("removeunusedlocal"))) try {
                            field.setAccessible(true); field.setBoolean(options, true);
                        } catch (Exception ignored) { }
                    }
                for (Method setter : t.getMethods()) {
                    if (!Modifier.isPublic(setter.getModifiers()) || !setter.getName().startsWith("set")
                            || setter.getParameterTypes().length != 1) continue;
                    String name = setter.getName().toLowerCase(Locale.ROOT);
                    if (setter.getParameterTypes()[0] == boolean.class && name.contains("removeglobals")) {
                        try { setter.invoke(options, false); } catch (ReflectiveOperationException ignored) { }
                    } else if (setter.getParameterTypes()[0] == boolean.class
                            && (name.contains("removeunusedvar") || name.contains("removeunusedlocal"))) {
                        try { setter.invoke(options, true); } catch (ReflectiveOperationException ignored) { }
                    } else if (name.contains("optimizationlevel")
                            && setter.getParameterTypes()[0].isEnum()) {
                        Object[] values = setter.getParameterTypes()[0].getEnumConstants();
                        for (Object value : values) if (String.valueOf(value).contains("ADVANCED"))
                            try { setter.invoke(options, value); } catch (ReflectiveOperationException ignored) { }
                    }
                }
                return options;
            } catch (ReflectiveOperationException ignored) { }
        }
        if (t.getName().equals("com.google.javascript.rhino.Node")) {
            try {
                Class<?> ir = load("com.google.javascript.rhino.IR");
                for (String factoryName : new String[]{"script", "root", "name", "string"})
                    for (Method factory : ir.getMethods())
                        if (Modifier.isStatic(factory.getModifiers()) && factory.getName().equals(factoryName)
                                && factory.getParameterTypes().length == 0 && t.isAssignableFrom(factory.getReturnType()))
                            return factory.invoke(null);
            } catch (ReflectiveOperationException ignored) { }
        }
        if (t.getName().equals("com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser")) {
            Object parser = xmlParser(g, report);
            if (parser != null && t.isInstance(parser)) return parser;
        }
        if (t.getName().equals("com.fasterxml.jackson.databind.ser.BeanPropertyWriter")
                || t.getName().equals("com.fasterxml.jackson.databind.ser.impl.UnwrappingBeanPropertyWriter")) {
            Object writer = jacksonWriter(t, g, report);
            if (writer != null && t.isInstance(writer)) return writer;
        }
        if (t == java.awt.Graphics2D.class || t == java.awt.Graphics.class)
            return new java.awt.image.BufferedImage(80, 80, java.awt.image.BufferedImage.TYPE_INT_ARGB).createGraphics();
        if (java.awt.Paint.class.isAssignableFrom(t)) {
            java.awt.Color c = new java.awt.Color(g.pick(256), g.pick(256), g.pick(256));
            if (t.isInstance(c)) return c;
        }
        if (java.awt.Stroke.class.isAssignableFrom(t)) {
            java.awt.BasicStroke s = new java.awt.BasicStroke(g.pick(10) / 2.0f);
            if (t.isInstance(s)) return s;
        }
        if (java.awt.Shape.class.isAssignableFrom(t)) {
            java.awt.Shape s = new java.awt.geom.Rectangle2D.Double(g.next(), g.next(), g.pick(80), g.pick(80));
            if (t.isInstance(s)) return s;
        }
        if (t == java.awt.geom.Point2D.class) return new java.awt.geom.Point2D.Double(g.next(), g.next());
        if (t.getName().equals("org.apache.commons.cli.CommandLine"))
            return commandLine(g, report);
        Object domain = chart(t, g, report);
        if (domain != null) return domain;
        Object language = language(t, g, report);
        if (language != null) return language;
        List<Constructor<?>> ctors = constructors(t);
        // Older Java libraries often use public singleton constants in place of enums.
        if (ctors.isEmpty()) {
            List<Field> constants = new ArrayList();
            for (Field field : t.getFields())
                if (Modifier.isStatic(field.getModifiers()) && Modifier.isFinal(field.getModifiers())
                        && t.isAssignableFrom(field.getType())) constants.add(field);
            Collections.sort(constants, new Comparator<Field>() {
                public int compare(Field a, Field b) { return a.getName().compareTo(b.getName()); }
            });
            if (!constants.isEmpty()) {
                Object constant = constants.get(g.pick(constants.size())).get(null);
                if (constant != null) return constant;
            }
        }
        if (!ctors.isEmpty()) {
            Constructor<?> ctor = ctors.get(g.pick(ctors.size()));
            try { return ctor.newInstance(arguments(ctor.getParameterTypes(), g, depth + 1, report)); }
            catch (Exception ignored) { }
        }
        report.nullFallbacks++;
        return null;
    }
    private static Object language(Class<?> t, Genes g, Observation report) {
        if (!t.getName().equals("org.apache.commons.lang3.time.FastDateFormat")) return null;
        try {
            Method factory = t.getMethod("getInstance", String.class, java.util.TimeZone.class,
                java.util.Locale.class);
            String[] patterns = {"yyyy-MM-dd", "MM/dd/yy HH:mm:ss", "EEE, d MMM yyyy HH:mm:ss Z"};
            return factory.invoke(null, patterns[g.pick(patterns.length)],
                java.util.TimeZone.getTimeZone("UTC"), java.util.Locale.US);
        } catch (ReflectiveOperationException ignored) { }
        try { return t.getMethod("getInstance", String.class).invoke(null, "yyyy-MM-dd"); }
        catch (ReflectiveOperationException ignored) { return null; }
    }
    private static Object xmlParser(Genes g, Observation report) {
        try {
            Class<?> factoryType = load("com.fasterxml.jackson.dataformat.xml.XmlFactory");
            Object factory = factoryType.getConstructor().newInstance();
            String[] docs = {"<root><value>1</value><name>x</name></root>",
                "<root value=\"42\"><item>a</item><item>b</item></root>",
                "<root/>"};
            String xml = docs[g.pick(docs.length)];
            for (Method method : factoryType.getMethods()) {
                if (!method.getName().equals("createParser") || method.getParameterTypes().length != 1) continue;
                Class<?> p = method.getParameterTypes()[0];
                Object input = p == String.class ? xml : p == Reader.class ? new StringReader(xml)
                    : p == InputStream.class ? new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8)) : null;
                if (input == null) continue;
                try {
                    Object parser = method.invoke(factory, input);
                    if (parser != null) {
                        int advance = g.pick(4);
                        Method next = parser.getClass().getMethod("nextToken");
                        for (int i = 0; i < advance; i++) if (next.invoke(parser) == null) break;
                        return parser;
                    }
                } catch (ReflectiveOperationException ignored) { }
            }
        } catch (Throwable ignored) { }
        return null;
    }
    private static Object jacksonWriter(Class<?> requested, Genes g, Observation report) {
        try {
            Class<?> mapperType = load("com.fasterxml.jackson.databind.ObjectMapper");
            Object mapper = mapperType.getConstructor().newInstance();
            Object bean = new GenericInput();
            Class<?> javaTypeType = load("com.fasterxml.jackson.databind.JavaType");
            Object javaType = mapperType.getMethod("constructType", Type.class).invoke(mapper, bean.getClass());
            // Jackson 2.6 (used by this Defects4J project) exposes a provider
            // blueprint from ObjectMapper. Create a configured provider via
            // DefaultSerializerProvider, the supported API used by ObjectMapper.
            Object providerBlueprint = mapperType.getMethod("getSerializerProvider").invoke(mapper);
            Class<?> serializationConfigType = load("com.fasterxml.jackson.databind.SerializationConfig");
            Class<?> serializerFactoryType = load("com.fasterxml.jackson.databind.ser.SerializerFactory");
            Object config = mapperType.getMethod("getSerializationConfig").invoke(mapper);
            Object factory = mapperType.getMethod("getSerializerFactory").invoke(mapper);
            Class<?> defaultProviderType = load("com.fasterxml.jackson.databind.ser.DefaultSerializerProvider");
            Method createProvider = defaultProviderType.getMethod("createInstance",
                serializationConfigType, serializerFactoryType);
            Object provider = createProvider.invoke(providerBlueprint, config, factory);
            g.jacksonBean = bean;
            g.jacksonProvider = provider;
            g.jacksonOutput = new StringWriter();
            Object jsonFactory = mapperType.getMethod("getFactory").invoke(mapper);
            for (String factoryMethod : new String[]{"createGenerator", "createJsonGenerator"}) {
                try {
                    Method createGenerator = jsonFactory.getClass().getMethod(factoryMethod, Writer.class);
                    g.jacksonGenerator = createGenerator.invoke(jsonFactory, g.jacksonOutput);
                    break;
                } catch (NoSuchMethodException ignored) { }
            }
            if (g.jacksonGenerator == null)
                throw new NoSuchMethodException("JsonFactory.createGenerator(Writer) or createJsonGenerator(Writer)");
            Class<?> providerType = load("com.fasterxml.jackson.databind.SerializerProvider");
            Class<?> beanPropertyType = load("com.fasterxml.jackson.databind.BeanProperty");
            Method find = providerType.getMethod("findValueSerializer", javaTypeType, beanPropertyType);
            Object serializer = find.invoke(provider, new Object[]{javaType, null});
            List<Object> writers = new ArrayList();
            try {
                // Available on Jackson 2.6 and newer.
                Class<?> serializerType = load("com.fasterxml.jackson.databind.JsonSerializer");
                Method properties = serializerType.getMethod("properties");
                Iterator<?> it = (Iterator<?>)properties.invoke(serializer);
                while (it.hasNext()) {
                    Object item = it.next();
                    if (item != null && item.getClass().getName().endsWith("BeanPropertyWriter"))
                        writers.add(item);
                }
            } catch (NoSuchMethodException oldJackson) {
                // JacksonDatabind-1 predates JsonSerializer.properties(). Its
                // BeanSerializerBase stores writers in the protected _props
                // array; read that array only for these old releases.
                Class<?> base = load("com.fasterxml.jackson.databind.ser.std.BeanSerializerBase");
                if (!base.isInstance(serializer))
                    throw new IllegalStateException("Expected BeanSerializerBase, got "
                        + serializer.getClass().getName(), oldJackson);
                Field props = base.getDeclaredField("_props");
                props.setAccessible(true);
                Object array = props.get(serializer);
                for (int i = 0; i < Array.getLength(array); i++) {
                    Object item = Array.get(array, i);
                    if (item != null && item.getClass().getName().endsWith("BeanPropertyWriter"))
                        writers.add(item);
                }
            }
            if (writers.isEmpty())
                throw new IllegalStateException("ObjectMapper produced no bean property writers for DEReplay.GenericInput");
            Object writer = writers.get(g.pick(writers.size()));
            boolean requireUnwrapping = requested.getName().equals(
                "com.fasterxml.jackson.databind.ser.impl.UnwrappingBeanPropertyWriter");
            if (!requireUnwrapping && g.pick(2) == 0 && requested.isInstance(writer)) return writer;
            Class<?> transformerType = load("com.fasterxml.jackson.databind.util.NameTransformer");
            Object nop = transformerType.getField("NOP").get(null);
            for (Method m : writer.getClass().getMethods())
                if (m.getName().equals("unwrappingWriter") && m.getParameterTypes().length == 1
                        && m.getParameterTypes()[0].isInstance(nop)) {
                    Object unwrapped = m.invoke(writer, nop);
                    if (requested.isInstance(unwrapped)) return unwrapped;
                }
            if (requested.isInstance(writer)) return writer;
            throw new IllegalStateException("Generated Jackson property writer is not " + requested.getName());
        } catch (Throwable failure) {
            throw new IllegalStateException("Cannot construct Jackson BeanPropertyWriter: " + failure, failure);
        }
    }
    /** Build the non-constructible Commons CLI result through its public Parser API. */
    private static Object commandLine(Genes g, Observation report) throws Exception {
        Class<?> optionsClass = load("org.apache.commons.cli.Options");
        Class<?> optionClass = load("org.apache.commons.cli.Option");
        Class<?> parserClass = load("org.apache.commons.cli.PosixParser");
        Object options = optionsClass.getConstructor().newInstance();
        Method addOption = optionsClass.getMethod("addOption", optionClass);
        int numberOfOptions = 1 + g.pick(3);
        List<String> spellings = new ArrayList();
        for (int i = 0; i < numberOfOptions; i++) {
            String shortName = String.valueOf((char)('a' + i));
            String longName = "de-option-" + i;
            boolean hasArgument = g.pick(2) == 0;
            Object option = null;
            try {
                option = optionClass.getConstructor(String.class, String.class, boolean.class, String.class)
                    .newInstance(shortName, longName, hasArgument, "DE-generated option");
            } catch (NoSuchMethodException ignored) { }
            if (option == null) try {
                option = optionClass.getConstructor(String.class, boolean.class, String.class)
                    .newInstance(shortName, hasArgument, "DE-generated option");
            } catch (NoSuchMethodException ignored) { }
            if (option == null) throw new NoSuchMethodException("No supported Commons CLI Option constructor");
            addOption.invoke(options, option);
            spellings.add("-" + shortName);
            if (hasArgument) spellings.add("value-" + Math.abs((long)g.next()));
        }
        String[] argv = spellings.toArray(new String[0]);
        Object parser = parserClass.getConstructor().newInstance();
        List<Method> parseMethods = new ArrayList();
        for (Method candidate : parserClass.getMethods()) {
            Class<?>[] p = candidate.getParameterTypes();
            if (candidate.getName().equals("parse") && p.length >= 2 && p[0] == optionsClass
                    && p[1] == String[].class && candidate.getReturnType() == load("org.apache.commons.cli.CommandLine"))
                parseMethods.add(candidate);
        }
        Collections.sort(parseMethods, new Comparator<Method>() {
            public int compare(Method a, Method b) {
                return a.getParameterTypes().length - b.getParameterTypes().length;
            }
        });
        for (Method parse : parseMethods) {
            Object[] args = new Object[parse.getParameterTypes().length];
            Class<?>[] p = parse.getParameterTypes();
            args[0] = options; args[1] = argv;
            for (int i = 2; i < p.length; i++) {
                if (p[i] == boolean.class || p[i] == Boolean.class) args[i] = g.pick(2) == 0;
                else if (p[i] == java.util.Properties.class) args[i] = new java.util.Properties();
                else args[i] = value(p[i], g, 1, report);
            }
            try { return parse.invoke(parser, args); }
            catch (InvocationTargetException ignored) { }
        }
        throw new NoSuchMethodException("No successful public PosixParser.parse(Options,String[])");
    }
    /** Optional type recipes, shared across bugs; none contains a bug-specific expected answer. */
    private static Object chart(Class<?> t, Genes g, Observation report) throws Exception {
        String n = t.getName();
        if (!n.startsWith("org.jfree.")) return null;
        if (n.equals("org.jfree.data.Range")) {
            double a = g.next(), b = g.next();
            return t.getConstructor(double.class, double.class).newInstance(Math.min(a, b), Math.max(a, b));
        }
        if (n.equals("org.jfree.data.time.RegularTimePeriod"))
            return load("org.jfree.data.time.Day").getConstructor(int.class, int.class, int.class)
                .newInstance(1 + g.pick(28), 1 + g.pick(12), 1990 + g.pick(40));
        if (n.equals("org.jfree.data.time.TimeSeries")) {
            Object series = t.getConstructor(Comparable.class).newInstance("DE");
            Class<?> period = load("org.jfree.data.time.RegularTimePeriod");
            Constructor<?> day = load("org.jfree.data.time.Day")
                .getConstructor(int.class, int.class, int.class);
            Method add = t.getMethod("add", period, double.class);
            int count = 2 + g.pick(4), year = 1990 + g.pick(40);
            for (int i = 0; i < count; i++)
                add.invoke(series, day.newInstance(i + 1, 1, year), g.next() / 10.0);
            return series;
        }
        if (n.equals("org.jfree.data.category.CategoryDataset")
                || n.equals("org.jfree.data.category.DefaultCategoryDataset")) {
            Class<?> c = load("org.jfree.data.category.DefaultCategoryDataset");
            Object data = c.getConstructor().newInstance();
            Method add = c.getMethod("addValue", Number.class, Comparable.class, Comparable.class);
            int rows = 1 + g.pick(3), columns = 1 + g.pick(3);
            for (int r = 0; r < rows; r++) for (int col = 0; col < columns; col++)
                add.invoke(data, Double.valueOf(g.next() / 10.0), "R" + r, "C" + col);
            return data;
        }
        if (n.equals("org.jfree.data.xy.XYDataset") || n.equals("org.jfree.data.xy.XYSeriesCollection")) {
            Class<?> seriesClass = load("org.jfree.data.xy.XYSeries");
            Object series = seriesClass.getConstructor(Comparable.class).newInstance("DE");
            int count = 1 + g.pick(5);
            for (int i = 0; i < count; i++) seriesClass.getMethod("add", double.class, double.class)
                .invoke(series, (double)i, g.next() / 10.0);
            Class<?> c = load("org.jfree.data.xy.XYSeriesCollection");
            Object data = c.getConstructor().newInstance();
            c.getMethod("addSeries", seriesClass).invoke(data, series);
            return data;
        }
        if (n.equals("org.jfree.data.general.PieDataset") || n.equals("org.jfree.data.general.DefaultPieDataset")) {
            Class<?> c = load("org.jfree.data.general.DefaultPieDataset");
            Object data = c.getConstructor().newInstance();
            int count = 1 + g.pick(5);
            for (int i = 0; i < count; i++) c.getMethod("setValue", Comparable.class, Number.class)
                .invoke(data, "K" + i, Double.valueOf(g.next() / 10.0));
            return data;
        }
        return null;
    }
    static List<Method> setupMethods(Class<?> receiver) {
        List<Method> methods = new ArrayList();
        for (Method m : receiver.getMethods()) {
            String n = m.getName();
            if (!Modifier.isStatic(m.getModifiers()) && !m.isSynthetic()
                    && m.getParameterTypes().length <= 3 && !n.contains("Listener")
                    && (n.startsWith("set") || n.startsWith("add") || n.startsWith("update")
                        || n.startsWith("remove") || n.equals("clear"))) methods.add(m);
        }
        Collections.sort(methods, new Comparator<Method>() {
            public int compare(Method a, Method b) {
                return signature(a).compareTo(signature(b));
            }
        });
        return methods;
    }
    public static Observation execute(String target, String receivers, String signature, int[] genes) {
        Observation out = new Observation();
        try {
            Genes g = new Genes(genes);
            Method m = method(target, signature);
            Object receiver = null;
            if (!Modifier.isStatic(m.getModifiers())) {
                String[] choices = receivers.split(",");
                Class<?> receiverType = load(choices[g.pick(choices.length)]);
                receiver = value(receiverType, g, 0, out);
                if (receiver == null) throw new IllegalArgumentException("Receiver construction failed");
                // Compiler.compile owns a strict initialization sequence.
                // Random calls to its mutators before compilation can corrupt
                // state or spend the search budget on irrelevant setup.
                if (!receiverType.getName().equals("com.google.javascript.jscomp.Compiler")) {
                    List<Method> setup = setupMethods(receiverType);
                    int count = g.pick(5);
                    for (int i = 0; i < count && !setup.isEmpty(); i++) {
                        Method s = setup.get(g.pick(setup.size()));
                        try { s.invoke(receiver, arguments(s.getParameterTypes(), g, 0, out)); out.setupCalls++; }
                        catch (Exception e) { out.setupFailures++; }
                    }
                }
            }
            Object[] args = arguments(m, g, 0, out);
            out.reachedTarget = true;
            try {
                boolean jacksonSerialization = m.getDeclaringClass().getName().equals(
                    "com.fasterxml.jackson.databind.ser.BeanPropertyWriter")
                    && m.getName().startsWith("serializeAs") && g.jacksonGenerator != null;
                boolean arrayShape = m.getName().contains("Column")
                    || m.getName().contains("Element") || m.getName().contains("Placeholder");
                if (jacksonSerialization)
                    g.jacksonGenerator.getClass().getMethod(arrayShape
                        ? "writeStartArray" : "writeStartObject").invoke(g.jacksonGenerator);
                Object result = m.invoke(receiver, args);
                boolean closureCompile = m.getDeclaringClass().getName().equals(
                    "com.google.javascript.jscomp.Compiler") && m.getName().equals("compile");
                if (closureCompile) {
                    // Result is only a status object; the compiled JavaScript is
                    // the behavioral output that reveals whether an argument
                    // was removed from a globally exposed function.
                    Object js = receiver.getClass().getMethod("toSource").invoke(receiver);
                    out.token = "CLOSURE_SOURCE:" + stable(js, 0);
                } else if (jacksonSerialization) {
                    g.jacksonGenerator.getClass().getMethod(arrayShape
                        ? "writeEndArray" : "writeEndObject").invoke(g.jacksonGenerator);
                    g.jacksonGenerator.getClass().getMethod("flush").invoke(g.jacksonGenerator);
                    out.token = "JSON:" + Base64.getEncoder().encodeToString(
                        g.jacksonOutput.toString().getBytes(StandardCharsets.UTF_8));
                } else out.token = m.getReturnType() == void.class
                    ? state(receiver, m.getName()) : stable(result, 0);
            } catch (InvocationTargetException e) {
                if (e.getCause() instanceof VirtualMachineError || e.getCause() instanceof LinkageError
                        || e.getCause() instanceof ThreadDeath) throw e;
                out.token = "THROW:" + e.getCause().getClass().getName();
            }
        } catch (Throwable e) {
            out.token = "HARNESS_ERROR";
            out.error = e.getClass().getName() + ":" + String.valueOf(e.getMessage());
        }
        return out;
    }
    public static String run(String target, String receivers, String signature, int[] genes) {
        Observation o = execute(target, receivers, signature, genes);
        if (!o.reachedTarget || o.token.equals("HARNESS_ERROR"))
            throw new AssertionError("Cannot replay test: " + o.error);
        return o.token;
    }
    private static String state(Object receiver, String method) {
        if (receiver == null) return "VOID";
        List<String> getters = new ArrayList();
        if (method.startsWith("set") && method.length() > 3) {
            getters.add("get" + method.substring(3)); getters.add("is" + method.substring(3));
        }
        getters.addAll(Arrays.asList("getItemCount", "getRowCount", "getColumnCount", "getSeriesCount"));
        StringBuilder s = new StringBuilder("VOID");
        for (String name : getters) {
            try {
                Method getter = receiver.getClass().getMethod(name);
                if (getter.getReturnType().isPrimitive() || getter.getReturnType() == String.class)
                    s.append('|').append(name).append('=').append(stable(getter.invoke(receiver), 0));
            } catch (ReflectiveOperationException ignored) { }
        }
        return s.toString();
    }
    /** Only whitelisted value types are rendered. Never use arbitrary object toString(). */
    static String stable(Object value, int depth) {
        if (value == null) return "NULL";
        Class<?> t = value.getClass();
        if (value instanceof String || value instanceof Boolean || value instanceof Character
                || value instanceof Byte || value instanceof Short || value instanceof Integer
                || value instanceof Long || value instanceof Float || value instanceof Double
                || value instanceof java.math.BigInteger || value instanceof java.math.BigDecimal)
            return t.getName() + ":" + Base64.getEncoder().encodeToString(value.toString().getBytes(StandardCharsets.UTF_8));
        if (value instanceof Enum) return "ENUM:" + t.getName() + ":" + ((Enum<?>)value).name();
        if (t.isArray() && depth < 3) {
            StringBuilder s = new StringBuilder("ARRAY:" + t.getName() + ":" + Array.getLength(value));
            for (int i = 0; i < Math.min(64, Array.getLength(value)); i++) {
                String item = stable(Array.get(value, i), depth + 1);
                s.append(':').append(item.length()).append(':').append(item);
            }
            return s.toString();
        }
        if (value instanceof java.awt.Color) return "COLOR:" + ((java.awt.Color)value).getRGB();
        // Observe safe scalar properties of returned objects. This catches
        // changes to value caches and state while avoiding identity-based toString().
        StringBuilder observed = new StringBuilder("STATE:" + t.getName());
        int properties = 0;
        for (String name : Arrays.asList("getItemCount", "getMinY", "getMaxY",
                "getRowCount", "getColumnCount", "getSeriesCount")) {
            try {
                Method getter = t.getMethod(name);
                Class<?> r = getter.getReturnType();
                if (!r.isPrimitive() && r != String.class && !Number.class.isAssignableFrom(r))
                    continue;
                if (r == void.class) continue;
                Object result = getter.invoke(value);
                String token = stable(result, depth + 1);
                observed.append('|').append(name).append('=').append(token.length())
                    .append(':').append(token);
                properties++;
            } catch (Exception ignored) { }
        }
        return properties == 0 ? "TYPE:" + t.getName() : observed.toString();
    }
    public static void main(String[] args) {
        if (args.length > 4) {
            String source = new String(Base64.getDecoder().decode(args[4]), StandardCharsets.UTF_8);
            System.setProperty("de.generated.source", source);
        }
        String[] encodedGenes = args[3].split(",");
        int[] genes = new int[encodedGenes.length];
        for (int i = 0; i < encodedGenes.length; i++) genes[i] = Integer.parseInt(encodedGenes[i]);
        boolean closureCompile = args[0].equals("com.google.javascript.jscomp.Compiler")
            && args[2].startsWith("compile(");
        // Compiler.compile is an expensive whole-program operation. Fixed-side
        // suites are still executed twice by the runner, so capture its oracle
        // once here instead of launching three compilations just to check the
        // same deterministic source output.
        int repetitions = closureCompile ? 1 : 3;
        for (int i = 0; i < repetitions; i++) {
            Observation out = execute(args[0], args[1], args[2], genes);
            System.out.println("DE_TOKEN:" + Base64.getEncoder().encodeToString(out.token.getBytes(StandardCharsets.UTF_8)));
        }
    }
}

public class DEGeneratedTest {
    @org.junit.Test(timeout=60000L)
    public void testDE00000() {
        org.junit.Assert.assertEquals("java.lang.Double:OS4yMjMzNzIwMzY4NTQ3NzZFMTg=", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "abs():double",
            new int[]{-246,968,-316,-715,-740,-193,-312,-159,206,-837,-933,-114,650,314,-831,84,178,308,-582,-430,801,-58,555,494,-789,-749,-653,-554,-752,-972,202,511,413,771,-21,-391,-618,-151,91,195,580,-355,970,412,-887,-27,-91,-667,595,-836,377,-916,-245,-124,988,298,-895,-116,-491,630,374,923,-516,-146}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00001() {
        org.junit.Assert.assertEquals("java.lang.Double:SW5maW5pdHk=", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "abs():double",
            new int[]{-751,846,614,-290,-46,-207,51,-199,-701,-513,99,-684,-242,-522,-475,-648,530,338,748,-434,110,39,-493,949,-766,-542,404,397,623,892,908,692,-4,316,152,-630,851,-486,-250,-584,-290,191,-222,-306,692,710,35,-365,556,-812,767,768,-305,339,149,-570,946,-305,-34,205,524,-420,207,464}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00002() {
        org.junit.Assert.assertEquals("java.lang.Double:TmFO", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "abs():double",
            new int[]{166,728,324,167,194,-749,33,625,191,147,-70,-871,-802,715,990,940,-704,-638,983,-838,662,732,-234,831,1,551,402,-171,-347,-46,-476,100,705,-116,195,546,-498,-416,-666,384,-887,-836,-251,784,-509,751,-250,-846,364,-159,-580,550,-819,115,-313,417,880,-785,541,88,653,-248,-27,-714}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00003() {
        org.junit.Assert.assertEquals("java.lang.Double:NzEyLjAwMDcwMjI0Njg0NDY=", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "abs():double",
            new int[]{384,940,187,-838,712,-373,328,-109,488,538,165,123,-910,-409,-774,-268,569,-579,-276,286,56,740,-264,689,-976,-106,872,-821,-177,-759,463,-481,894,771,-916,75,-832,-161,110,929,-715,834,900,182,468,138,-787,147,-807,-163,-498,-719,-941,291,-163,376,728,896,-608,-208,202,165,654,326}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00004() {
        org.junit.Assert.assertEquals("java.lang.Double:MC4w", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "abs():double",
            new int[]{-257,-1000,-23,780,418,636,-803,1000,176,-200,630,-1000,-1000,602,-657,808,-1000,-47,-532,589,1000,488,1000,748,-1000,-236,1000,-735,1000,-710,486,1000,986,848,96,-739,464,-741,-1000,794,462,-1000,1000,59,-606,-344,-851,-163,850,1000,-458,1000,1000,-787,-1000,601,-60,-854,1000,90,356,-388,-933,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00005() {
        org.junit.Assert.assertEquals("java.lang.Double:SW5maW5pdHk=", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "abs():double",
            new int[]{-79,-799,191,764,-75,68,-88,-661,597,-983,-45,-730,602,-343,-233,248,-399,-851,587,-978,-959,-410,749,874,310,290,671,-48,-685,459,721,-272,546,655,933,674,-208,743,414,-276,799,118,220,-949,-635,433,435,307,661,216,266,541,-157,374,-930,-242,484,-156,378,-727,-257,-604,269,894}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00006() {
        org.junit.Assert.assertEquals("java.lang.Double:TmFO", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "abs():double",
            new int[]{987,967,406,463,-628,265,676,-396,610,906,55,717,-445,-271,770,-724,401,976,4,684,-554,273,-903,-453,-280,-794,482,315,105,72,73,-415,-439,-780,677,237,-794,805,815,-974,-928,746,-712,232,633,-777,800,565,415,-875,1,616,355,-450,431,-138,969,-368,-997,-531,-169,809,-83,-44}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00007() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "acos():org.apache.commons.math.complex.Complex",
            new int[]{-365,-357,770,-393,106,866,838,-788,-398,209,347,-750,-884,-870,-247,337,211,-952,-619,473,987,787,-42,-741,-495,-260,354,667,996,-256,517,120,-859,96,143,88,-549,-61,-940,18,382,301,-478,-554,-850,521,-323,-555,468,445,-724,-839,-606,868,-578,-851,322,-22,-438,-559,772,-760,-708,-154}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00008() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "acos():org.apache.commons.math.complex.Complex",
            new int[]{-462,-244,341,53,-930,189,-526,-321,993,42,924,-754,172,-831,579,894,138,771,676,709,859,-920,-696,-186,-8,-777,-481,-158,691,-992,792,-672,-992,-187,99,-75,-321,-449,-632,-938,648,757,241,609,87,-733,147,-535,843,-372,-470,-426,279,469,747,-180,282,330,628,499,836,149,979,602}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00009() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "acos():org.apache.commons.math.complex.Complex",
            new int[]{625,852,-1000,918,226,42,107,-268,-23,-1000,1000,363,-108,-36,357,1000,601,1000,754,-468,-406,667,1000,466,-655,304,-643,451,563,335,-753,-387,-1000,-484,-262,396,57,-532,-358,411,-876,884,-497,-863,1000,-268,-771,1000,-1000,-1000,-1000,-338,-469,-1000,1000,955,967,-668,-1000,-509,-295,514,99,215}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00010() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "acos():org.apache.commons.math.complex.Complex",
            new int[]{-1000,556,-587,230,-94,216,37,602,532,-1000,1000,868,-360,-155,232,992,5,1000,-233,-469,-451,-1000,81,1000,-77,-1000,667,276,-1000,250,-784,-447,-382,438,1000,-737,-834,631,1000,143,1000,-36,219,-1000,36,172,-860,1000,78,41,-960,-537,608,-1000,659,975,1000,-36,203,531,-506,388,285,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00011() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "acos():org.apache.commons.math.complex.Complex",
            new int[]{-488,450,-679,999,-337,-629,-826,437,-713,334,278,-94,-323,847,-382,940,909,955,765,-237,-766,-1000,-991,-772,-586,-805,-674,841,312,694,586,913,973,317,-950,194,-787,-115,571,-925,-704,158,206,410,-346,823,-85,-679,-161,-343,-56,-29,-161,27,-898,-773,798,234,-340,367,-262,836,-143,552}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00012() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "add(org.apache.commons.math.complex.Complex):org.apache.commons.math.complex.Complex",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00013() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "asin():org.apache.commons.math.complex.Complex",
            new int[]{1000,-269,-1000,1000,-952,-477,-1000,3,-993,-169,-1000,-657,-1000,-1000,389,948,-874,685,1000,887,-366,-566,-1000,-192,-1000,487,-1000,965,631,847,-36,388,-4,3,-162,-397,-547,-849,1000,-1000,-1000,-146,-1000,-326,-10,-1000,971,532,620,100,-565,1000,1000,-568,-98,522,-1000,178,307,-878,726,1000,-1000,954}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00014() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "asin():org.apache.commons.math.complex.Complex",
            new int[]{-572,396,343,-67,538,9,-738,-448,606,-95,120,575,-629,932,353,-9,599,-773,372,-917,-876,482,987,952,436,-221,256,377,856,550,968,756,-526,-533,-65,-828,368,98,-414,917,-611,-985,968,740,-216,-281,-790,-48,-714,213,-288,141,-52,-650,-78,-302,956,-814,-597,622,-70,-508,83,121}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00015() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "asin():org.apache.commons.math.complex.Complex",
            new int[]{-308,631,955,-94,-490,505,-557,-573,761,60,716,700,-563,943,-746,544,-758,-748,953,-416,-224,-245,382,-474,243,620,-865,-96,-889,-409,865,416,-746,-196,537,-722,-512,-569,784,291,-846,232,833,-727,384,-251,-565,359,-918,343,446,300,237,-418,280,328,206,588,328,440,-160,-145,594,-2}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00016() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "asin():org.apache.commons.math.complex.Complex",
            new int[]{245,809,107,-550,-642,120,-920,-777,765,-728,474,-71,374,-141,571,979,-212,-536,-474,-458,-740,903,144,550,-90,-1000,496,1000,1000,-241,191,1000,1000,-363,-1000,-304,227,592,-823,310,-861,499,860,568,-924,350,-970,752,531,520,-8,15,-27,-955,884,770,-290,-616,-468,87,1000,-688,-1000,456}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00017() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "asin():org.apache.commons.math.complex.Complex",
            new int[]{969,-34,1000,1000,-1000,535,-144,-622,-1000,-1000,-21,45,-222,-1000,658,-328,-1000,101,-531,-452,-908,630,-776,-80,-378,-280,-441,353,-114,55,673,-336,222,-36,-35,636,794,-181,143,1000,408,34,-1000,-626,-978,-869,658,649,128,567,643,315,350,-827,623,935,-704,1000,372,-448,822,260,348,125}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00018() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "atan():org.apache.commons.math.complex.Complex",
            new int[]{958,739,-64,-288,-191,261,455,-77,867,390,-851,454,-538,937,-479,-620,993,337,-438,22,12,488,-960,-765,-886,176,-189,-748,-952,101,-418,-688,175,709,880,347,-103,573,-829,505,993,-102,-958,975,-40,881,-854,676,383,116,-776,704,123,10,-71,-841,683,258,396,-78,504,844,-436,-719}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00019() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "atan():org.apache.commons.math.complex.Complex",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00020() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "atan():org.apache.commons.math.complex.Complex",
            new int[]{-508,959,339,-72,420,-22,604,454,-527,321,-761,358,169,552,-672,220,-286,-723,598,290,-949,330,-481,785,581,399,-213,744,252,607,-570,643,408,799,-954,145,-686,820,918,-271,585,867,694,-261,874,-804,105,418,-862,-104,833,-111,-439,225,17,-320,752,106,-863,-549,279,-251,56,-178}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00021() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "atan():org.apache.commons.math.complex.Complex",
            new int[]{-1000,-8,-460,-658,1000,-166,-870,-1000,-838,-143,853,932,-778,-1000,-198,-664,-1000,960,1000,-1000,-662,205,1000,641,130,484,31,1000,676,-709,-226,584,-260,143,-343,-664,-641,-701,939,726,-746,1000,1000,-352,-865,-1000,574,-1000,-340,-797,1000,-599,-1000,1000,1000,276,-1000,1000,485,27,-494,46,495,662}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00022() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "atan():org.apache.commons.math.complex.Complex",
            new int[]{342,-380,-598,-655,531,883,668,-252,-900,-347,-366,525,731,-876,-633,996,569,-457,416,-336,-386,-739,-994,-279,-947,305,669,241,293,576,599,-168,-853,-26,326,-348,145,-715,-501,141,275,499,-479,541,553,-610,603,339,828,-374,-623,-841,-71,484,642,269,-122,-686,27,905,-752,-706,437,-100}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00023() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "atan():org.apache.commons.math.complex.Complex",
            new int[]{688,-164,365,-520,551,255,239,-58,-119,-143,-704,912,-953,-894,996,-939,665,911,748,156,-509,-203,999,788,455,793,30,-778,183,-837,-726,231,-973,-625,338,881,117,-815,70,-335,-681,588,-14,131,-943,-501,-830,208,-38,532,-626,-199,-979,-18,-580,-98,-486,-762,-698,470,384,211,346,-371}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00024() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "atan():org.apache.commons.math.complex.Complex",
            new int[]{0,-1000,176,684,-631,553,-1000,646,-1000,-712,980,-1000,-563,65,1000,-710,671,-179,-872,207,941,-104,-1000,653,-1000,208,1000,851,496,-404,1000,502,-673,265,1000,-1000,581,-7,747,1000,-20,931,496,-419,1000,-892,-337,-125,779,348,40,-1000,-777,-955,349,-32,-1000,-682,733,138,144,-707,1000,27}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00025() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "conjugate():org.apache.commons.math.complex.Complex",
            new int[]{-284,353,-728,-730,-285,-773,-914,-25,946,83,970,-142,579,-550,809,750,206,-6,-818,920,-125,-453,-840,968,-665,428,-589,-899,542,572,472,631,915,588,404,304,630,277,-250,-366,-680,391,687,794,-59,421,-399,-165,286,-917,-117,979,-347,832,736,599,-483,-803,-20,85,683,49,421,-714}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00026() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "conjugate():org.apache.commons.math.complex.Complex",
            new int[]{-735,315,-742,356,341,641,423,963,481,-30,-357,621,473,660,617,-685,-599,795,172,-505,273,-237,-665,-613,514,222,576,115,-981,-124,-787,-124,-63,88,385,-810,110,788,-353,-208,182,321,-756,146,833,969,-570,727,-768,-293,831,265,904,-575,-258,-84,494,321,-460,29,-423,478,-71,-454}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00027() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "conjugate():org.apache.commons.math.complex.Complex",
            new int[]{324,534,283,619,-492,104,989,756,-329,890,475,-876,803,347,-979,-931,20,-329,-946,-446,-122,-311,579,-812,793,925,444,-560,-593,-306,133,-794,224,652,-893,631,-399,-361,425,-320,-720,918,353,326,-966,-100,-9,430,723,350,553,385,-929,-296,870,433,-162,-390,-58,-823,-336,-893,902,295}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00028() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "cos():org.apache.commons.math.complex.Complex",
            new int[]{839,-707,130,460,-643,-453,-872,668,-258,218,593,581,555,987,451,354,774,190,-586,-562,-93,-387,796,-986,195,75,-190,-851,-944,850,-905,545,372,-941,-542,-69,-92,-990,498,-795,-837,112,673,-790,-663,-513,632,-328,692,-312,-823,-686,598,-966,109,352,-206,-16,375,-289,-1000,-279,-568,-836}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00029() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "cos():org.apache.commons.math.complex.Complex",
            new int[]{-889,1000,1000,-86,-175,-677,794,-918,1000,1000,-605,-547,365,502,-292,-530,994,-1000,1000,271,-559,-1000,-1000,-463,-738,196,1000,-692,1000,204,1000,391,-976,-122,732,492,1000,-741,-425,-117,254,18,-1000,-859,114,-724,-142,-353,-785,71,969,-745,166,1000,8,124,576,-69,934,1000,210,605,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00030() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "cos():org.apache.commons.math.complex.Complex",
            new int[]{-10,897,-929,-5,-250,706,-714,-32,873,2,315,281,756,337,-834,-237,397,159,-9,-354,517,-44,-165,365,724,687,802,302,-663,-478,-185,292,-115,-73,-584,892,-979,-973,684,429,-413,-192,288,669,-59,-782,-80,-417,282,-492,-66,-882,679,-725,-149,170,-215,552,606,-998,-191,-945,890,-757}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00031() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "cosh():org.apache.commons.math.complex.Complex",
            new int[]{-681,324,-591,22,-677,-732,66,226,321,-4,128,898,260,-986,1000,997,151,-412,-171,207,78,-425,-905,-672,-197,561,124,-804,141,864,-198,-968,242,-549,-581,461,651,564,947,158,607,-33,-713,43,422,-898,-894,-729,-20,-833,-335,874,390,-841,778,-150,-311,243,-532,731,-927,-508,210,-778}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00032() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "cosh():org.apache.commons.math.complex.Complex",
            new int[]{961,154,406,-561,-850,367,-256,6,649,410,-234,690,819,-862,-707,689,-191,183,474,470,-984,-584,964,316,634,-626,716,25,398,643,-371,-904,576,684,-117,90,-948,-668,-766,544,865,-675,727,815,-988,-419,381,525,-537,676,-793,910,-608,5,-402,293,-574,425,640,-826,347,854,130,-65}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00033() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "cosh():org.apache.commons.math.complex.Complex",
            new int[]{-799,562,-1000,-569,26,-1000,103,-58,-277,819,-196,-848,-432,486,-815,-1000,627,-281,-691,1000,389,-1000,-180,-400,-228,616,398,268,110,474,-910,372,585,-137,-332,618,-1000,-132,-463,-695,251,112,682,-118,505,-278,-1000,362,588,-1000,1000,-23,-331,-1000,1000,-209,1000,-1000,-1000,-725,-118,206,-1000,-852}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00034() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "divide(org.apache.commons.math.complex.Complex):org.apache.commons.math.complex.Complex",
            new int[]{312,-736,-237,-795,-427,-179,-86,-717,486,-629,610,-738,852,-937,814,6,-599,-383,894,-251,179,959,882,269,-676,-32,355,-890,-502,-870,420,-826,-431,987,-239,513,347,744,40,991,-888,99,-914,637,490,-565,-761,979,829,893,978,-588,-351,-491,557,-251,945,-407,719,-492,-798,859,-211,190}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00035() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "divide(org.apache.commons.math.complex.Complex):org.apache.commons.math.complex.Complex",
            new int[]{370,347,-720,794,29,833,524,982,199,11,517,160,-548,-483,430,-481,941,149,87,-728,-799,-899,823,330,-920,-134,190,-204,513,-491,418,533,-824,174,23,562,243,-904,-685,-82,442,131,-364,700,388,-118,-820,556,801,884,932,595,585,941,884,-197,38,-226,-938,-535,435,-623,71,769}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00036() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "divide(org.apache.commons.math.complex.Complex):org.apache.commons.math.complex.Complex",
            new int[]{140,-846,-84,842,-982,791,-363,759,-563,-891,-41,-253,-576,-342,598,756,-373,-282,-882,-150,685,523,-689,-543,-691,-960,-37,-594,-73,-565,-457,-77,106,-528,903,-755,116,-470,348,-629,-7,-338,-380,625,-758,-820,-759,-854,924,-380,-531,-785,-709,-385,636,417,361,-789,80,12,-141,-552,31,-360}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00037() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "divide(org.apache.commons.math.complex.Complex):org.apache.commons.math.complex.Complex",
            new int[]{1000,158,-306,1000,15,279,255,403,46,-600,417,-172,-21,-377,475,153,-130,260,-421,343,-494,-857,150,-367,-560,-821,-467,287,235,-91,-10,-308,-201,-248,377,398,76,-1000,-501,-250,-1000,546,-467,286,-380,-160,2,313,570,384,-1000,989,24,-400,1000,134,-391,0,-1000,-139,-257,-566,715,-213}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00038() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "divide(org.apache.commons.math.complex.Complex):org.apache.commons.math.complex.Complex",
            new int[]{-201,-611,436,843,-834,499,-769,-482,527,-224,-248,-78,356,-872,-565,-530,773,572,-360,280,41,-363,-542,191,-989,779,683,819,-35,992,64,-146,-405,945,-534,-656,77,-629,874,546,-863,203,-651,-939,-174,-990,931,-539,-695,-367,320,352,-632,-365,654,946,-346,133,-828,594,-457,-72,-332,-573}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00039() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "divide(org.apache.commons.math.complex.Complex):org.apache.commons.math.complex.Complex",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00040() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "equals(java.lang.Object):boolean",
            new int[]{-515,345,251,238,361,709,782,-210,-849,357,235,-858,-9,-773,53,-123,984,248,-64,-722,-412,591,-838,-259,-832,-328,-833,-98,503,61,658,-269,753,-941,-931,486,-726,835,-208,596,521,-233,-723,304,-732,898,-143,-790,355,-735,909,-271,286,262,872,-78,-872,193,-467,-829,360,-337,-13,-301}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00041() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "equals(java.lang.Object):boolean",
            new int[]{718,-266,-486,-337,787,-808,419,-815,848,419,205,-610,669,362,303,-205,-978,569,-325,-877,-433,-7,937,866,-845,-997,524,-209,-103,823,737,723,-930,210,36,-459,-187,-654,-421,532,414,-371,674,-10,967,-648,-470,-743,-798,-916,526,-696,340,977,-955,-653,-995,-781,-145,45,408,341,-977,-648}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00042() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "exp():org.apache.commons.math.complex.Complex",
            new int[]{56,11,325,-674,-828,148,386,-834,-842,-366,147,-74,816,295,36,-108,-465,-303,-806,690,250,393,-964,511,189,945,-183,662,700,62,288,213,-631,-875,-532,-219,206,-664,162,-320,751,-192,-30,65,634,6,-778,-960,304,113,512,-801,-518,158,-648,-462,172,-989,-190,303,-958,-246,948,949}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00043() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "exp():org.apache.commons.math.complex.Complex",
            new int[]{-467,-616,1000,860,-962,199,-349,-667,-469,875,180,-1000,484,-483,260,1000,426,263,-995,862,581,1000,-496,912,92,-4,-715,288,601,45,596,1000,1000,-136,329,-308,305,562,875,-33,-835,515,-555,-992,-862,-193,-1000,501,-1000,609,-511,352,636,-251,284,1000,-689,-935,-799,-1000,-1000,-185,748,471}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00044() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "exp():org.apache.commons.math.complex.Complex",
            new int[]{985,971,923,139,-344,749,-772,-253,985,-797,-869,-610,392,955,25,-65,585,568,-751,372,-107,80,-628,-772,-105,-211,330,864,-206,-691,-337,147,955,-132,-916,-821,-440,-230,191,36,425,-984,249,-187,694,191,671,650,328,876,61,-134,-894,108,518,-140,-810,-315,264,14,223,503,-415,-545}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00045() {
        org.junit.Assert.assertEquals("java.lang.Double:LTkuMjIzMzcyMDM2ODU0Nzc2RTE4", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "getImaginary():double",
            new int[]{411,-341,-736,472,547,-930,342,975,729,761,-80,-437,12,-638,705,250,558,907,-967,-330,96,744,-987,-622,104,-818,-334,401,-529,790,925,-813,-972,-226,-990,942,484,-507,-120,-765,16,837,-786,-277,54,-65,683,821,648,444,-835,-713,208,-442,-32,-231,376,-238,-829,612,-667,397,-294,-523}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00046() {
        org.junit.Assert.assertEquals("java.lang.Double:MTg1LjA=", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "getReal():double",
            new int[]{516,-983,185,-469,-672,546,-639,720,-235,253,-58,36,-726,-648,815,-653,-265,921,574,266,-492,810,347,651,-867,-973,-922,461,-535,-232,363,198,687,-983,-114,-558,-620,941,544,-164,641,202,398,272,-926,730,759,22,429,512,-97,69,651,524,186,9,-881,30,656,-467,-2,205,-345,-266}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00047() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "isInfinite():boolean",
            new int[]{-885,746,-364,-223,-650,717,491,428,-381,-480,-765,533,61,907,-660,674,722,310,-964,765,-368,63,928,726,-705,536,108,847,574,-961,185,-872,83,495,-504,911,147,366,-692,-505,-846,-922,291,-870,690,269,733,-260,234,610,26,69,390,637,-198,536,-355,79,760,-962,-547,-523,-285,162}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00048() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "isInfinite():boolean",
            new int[]{605,831,380,-655,-196,91,-486,417,418,-816,694,682,212,-32,917,-755,-392,-161,318,-611,-537,594,821,-971,-718,-944,-93,719,-187,-945,-589,-323,115,-529,-951,-604,-879,539,-999,732,-511,398,-750,88,-900,-98,-355,-733,954,186,-311,-103,-588,130,874,946,-276,-82,-899,775,633,229,169,-592}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00049() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "isInfinite():boolean",
            new int[]{273,103,725,311,906,-262,-1,73,492,602,-231,-487,289,-570,-135,-718,916,-275,-45,255,-639,-597,406,812,579,436,209,555,-12,141,-266,522,269,-65,868,63,860,-139,679,-140,-728,-75,-813,-697,-73,397,-980,383,622,634,816,-382,894,-332,-963,103,587,-140,575,-269,750,-754,971,871}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00050() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "isInfinite():boolean",
            new int[]{88,577,678,849,-834,901,-117,-600,-28,-784,-403,-100,-181,174,-723,653,-452,319,-818,987,-36,-132,874,-60,-462,-826,-730,770,-12,-337,-198,935,526,135,119,309,-515,827,291,715,-203,-627,953,-435,385,922,-981,-615,883,-958,-358,-692,338,769,971,235,-477,181,885,316,-684,216,402,-402}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00051() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "isInfinite():boolean",
            new int[]{-681,758,305,943,-881,-87,479,-381,-419,147,44,695,-755,-580,429,31,479,-519,113,559,786,321,-627,-260,-932,751,-704,894,-241,407,-592,138,899,613,-887,658,-877,31,-282,-515,-659,-229,225,571,-571,-269,-672,-34,660,-643,58,240,769,-316,418,-150,590,-408,963,-853,-992,-483,809,-86}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00052() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "isNaN():boolean",
            new int[]{343,-220,-209,-374,-41,259,896,-836,-866,351,941,603,333,-696,-695,-228,-850,446,545,-868,-807,421,366,-241,-158,-984,-1,819,-364,-157,304,560,-767,-145,-440,128,502,-940,-142,-367,117,-898,315,795,-745,412,876,231,-534,548,414,-15,590,-977,-986,-730,-272,437,873,-477,701,44,-913,-103}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00053() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "isNaN():boolean",
            new int[]{-730,-101,-226,-100,-738,497,-621,-148,-656,654,246,-789,182,-717,492,-782,-330,40,-668,826,856,-455,-851,-988,-503,123,254,-698,-445,-546,216,-377,149,-898,290,-165,61,-592,414,-564,-227,-556,-432,836,148,-193,-193,-681,-576,936,259,-636,-63,303,-480,342,-842,370,-544,772,19,-511,230,-690}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00054() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "isNaN():boolean",
            new int[]{562,787,-457,55,755,-295,983,-900,577,-587,-135,749,895,582,-333,-690,526,475,195,224,887,530,-730,45,773,556,536,-833,442,-210,144,273,-593,691,-280,748,906,800,-36,-582,-113,-747,537,878,526,-399,-561,417,-216,-505,-975,-923,-668,452,-11,-261,-727,-514,-818,-698,-466,639,-43,983}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00055() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "log():org.apache.commons.math.complex.Complex",
            new int[]{-191,-574,829,-734,-871,-762,672,443,-401,-796,611,-263,-778,321,46,-197,-208,-258,810,995,-14,-2,273,857,-538,-583,214,-178,329,483,-645,-297,755,-50,-218,721,193,383,-937,-173,729,-574,849,-67,393,629,924,245,-60,-87,-688,394,533,870,-175,-725,85,30,695,-384,561,-80,-610,-850}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00056() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "log():org.apache.commons.math.complex.Complex",
            new int[]{-976,-1000,627,-443,-734,237,-166,-499,-635,-629,-353,865,-1000,-502,-961,-1000,-1000,743,-1000,-603,560,-889,63,-65,223,-702,255,-396,238,1000,287,356,1000,-382,-226,591,-768,-779,-101,-554,-99,712,-63,127,-79,575,1000,32,-1000,-641,10,903,-480,407,-598,1000,-789,-101,-1000,-586,-534,412,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00057() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "log():org.apache.commons.math.complex.Complex",
            new int[]{-976,638,-453,-181,-720,-689,-258,-423,-587,-495,594,-376,470,-502,-558,260,-356,-727,306,-19,-581,535,675,764,389,-409,13,-938,-303,480,-475,-305,-479,783,999,-983,687,405,191,750,-442,269,-863,697,-347,-642,16,-809,-878,828,750,564,-845,-986,-600,-803,686,-940,596,-215,-668,-344,725,-687}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00058() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "log():org.apache.commons.math.complex.Complex",
            new int[]{-250,-128,504,354,324,-433,-898,230,-750,419,-202,518,130,-656,-202,-508,292,979,-177,783,938,822,112,652,537,-439,399,-135,-470,-161,-996,674,-147,707,-548,-353,465,-87,-321,-933,104,-186,793,-526,842,-814,-382,-474,641,488,-194,830,91,270,152,637,-224,-724,-42,374,319,588,-240,868}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00059() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "log():org.apache.commons.math.complex.Complex",
            new int[]{-1000,-1000,576,528,1000,792,-1,-499,712,25,1000,174,-1000,906,1000,-1000,-697,-899,-154,-993,673,-1000,765,-70,413,1000,-1000,372,-891,-116,-1000,1000,1000,1000,-323,513,743,397,1000,-622,305,835,1000,-1000,779,757,-402,89,-688,-1000,1000,88,1000,-1000,1000,723,564,-1000,-703,-1000,499,-939,-675,-720}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00060() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "log():org.apache.commons.math.complex.Complex",
            new int[]{-586,887,-584,-27,-885,-453,987,-274,368,-537,929,556,883,328,-727,-403,-112,-667,715,-751,-373,-475,769,-828,-585,-817,-117,-390,145,-228,-553,-105,564,61,946,150,303,848,104,262,722,390,-184,-23,922,-861,911,-371,970,-356,324,455,-693,-385,147,706,612,-970,201,841,-29,-71,-735,-34}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00061() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "log():org.apache.commons.math.complex.Complex",
            new int[]{404,-828,913,-677,-255,-851,-61,-902,500,-438,320,796,-819,604,-788,-567,-669,768,-309,-481,-9,561,544,-969,-500,248,796,-637,792,688,-289,-898,790,-606,-739,724,-830,-220,-273,265,815,246,-5,886,-364,-800,356,-141,-968,442,-793,958,290,409,-136,504,444,723,-63,-635,-257,175,-825,-867}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00062() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "multiply(org.apache.commons.math.complex.Complex):org.apache.commons.math.complex.Complex",
            new int[]{547,-490,-1000,974,-247,-724,779,-156,354,171,-402,702,-107,307,742,-412,421,245,-129,335,-648,-248,-652,1000,573,107,658,-293,255,-938,-1000,-993,584,-264,455,727,142,191,-251,-34,262,-822,223,460,-360,616,-839,-519,573,1000,856,-1000,-651,543,978,-838,-1000,-564,-679,988,-374,-316,174,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00063() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "multiply(org.apache.commons.math.complex.Complex):org.apache.commons.math.complex.Complex",
            new int[]{-47,-880,241,409,-76,-815,-943,-230,496,-254,269,-991,-1000,-1000,-1000,-889,777,44,-1000,-1000,1000,298,-1000,92,-721,-1000,173,1000,522,-30,-694,-533,-421,-294,-1000,-932,-500,-361,538,-565,1000,-1000,-749,247,439,782,-617,-1000,747,-1000,1000,350,-1000,114,446,-544,-188,397,677,936,255,461,-1000,-265}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00064() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "multiply(org.apache.commons.math.complex.Complex):org.apache.commons.math.complex.Complex",
            new int[]{266,663,885,535,-321,-175,747,-997,984,-447,27,114,835,-51,-418,-380,63,-721,553,-983,-173,-382,-977,760,166,-665,-430,480,-892,-147,-333,-387,71,-290,682,994,-114,161,-846,-289,-553,-702,-37,-200,-260,-8,-982,165,-215,821,-804,586,-101,615,-629,581,-388,212,621,456,546,-379,-85,979}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00065() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "multiply(org.apache.commons.math.complex.Complex):org.apache.commons.math.complex.Complex",
            new int[]{588,-179,596,-607,630,-540,-923,120,39,927,-242,108,-982,901,-878,954,-964,413,464,-171,777,-79,988,-680,-663,866,658,273,570,-408,-58,995,-988,147,445,357,-558,657,-683,-941,809,-274,-737,588,987,631,-976,-745,-392,-43,247,-891,120,-250,-166,476,-910,266,51,445,810,-11,-68,-333}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00066() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "multiply(org.apache.commons.math.complex.Complex):org.apache.commons.math.complex.Complex",
            new int[]{401,101,971,-853,-797,149,-278,345,753,793,-215,-446,365,-180,288,-986,953,-715,-466,803,-351,-795,-437,460,590,348,-575,-857,618,571,675,-240,175,837,412,-276,294,195,-908,674,250,-246,294,-217,-823,43,-354,150,774,-44,175,-850,-968,993,-487,-394,916,-552,583,-840,841,-196,-347,354}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00067() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "multiply(org.apache.commons.math.complex.Complex):org.apache.commons.math.complex.Complex",
            new int[]{618,900,-32,-259,-950,729,301,521,-171,-50,-980,730,498,113,-660,-625,-529,-508,-533,-124,408,928,-932,544,629,-603,314,570,10,239,181,964,-627,-370,-405,29,985,-956,-158,-293,450,-759,-349,382,-973,588,-628,-405,190,-567,-267,526,125,669,-169,-940,762,643,186,-187,-52,115,-10,-446}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00068() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "multiply(org.apache.commons.math.complex.Complex):org.apache.commons.math.complex.Complex",
            new int[]{278,-893,-116,-735,586,-447,968,-556,775,-986,-296,644,590,11,616,520,-335,103,541,385,-715,25,450,-430,751,456,346,-730,-29,-253,-378,-774,-579,594,-903,-279,-728,825,811,-856,-903,227,-342,-392,367,-366,904,-13,-292,400,-225,-873,-256,-191,-623,-32,326,962,-526,-165,-136,274,885,-735}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00069() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "negate():org.apache.commons.math.complex.Complex",
            new int[]{172,619,-524,-702,650,-221,564,86,-938,509,547,165,-779,612,-806,-990,936,-694,888,-199,-896,-631,-913,329,873,940,-717,793,-706,733,-134,-193,248,-894,824,990,736,-583,639,-28,581,-595,-91,-711,509,968,240,734,-799,604,785,-972,419,86,430,-680,557,-574,-914,38,-876,118,782,-184}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00070() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "negate():org.apache.commons.math.complex.Complex",
            new int[]{738,-376,476,-472,527,903,599,-712,-64,-137,214,-658,-82,737,-495,765,-350,879,-592,-642,653,-224,411,224,-222,-638,-264,-277,-861,579,983,304,-492,-190,880,801,897,813,160,186,105,-924,-202,458,-137,149,-154,411,-133,-583,-96,339,473,59,-50,378,-880,447,-363,175,-352,158,-520,832}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00071() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "negate():org.apache.commons.math.complex.Complex",
            new int[]{-509,323,-457,-641,126,642,-178,-524,178,1,209,-774,791,921,867,-264,540,-991,923,-696,527,766,-302,769,403,468,922,-186,976,-882,572,760,-545,-826,-471,-502,638,720,656,599,-610,86,74,-616,582,520,439,-285,360,441,-158,655,-911,92,-413,-254,-427,-108,-465,-325,309,-268,-998,305}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00072() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "pow(org.apache.commons.math.complex.Complex):org.apache.commons.math.complex.Complex",
            new int[]{978,146,296,-805,-970,-637,-368,-252,124,-295,653,-29,221,-885,733,207,-710,915,-570,776,417,213,754,499,-307,359,-924,-526,528,-358,566,-60,-973,408,-545,-353,-504,490,212,-393,782,457,833,273,-835,-465,795,-710,-168,290,-6,-220,561,-872,-38,800,201,538,37,-912,751,-406,776,-488}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00073() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "pow(org.apache.commons.math.complex.Complex):org.apache.commons.math.complex.Complex",
            new int[]{97,195,-392,916,1000,-194,-431,1000,499,42,1000,170,740,-199,357,451,877,-219,-211,1000,-74,-394,526,198,-633,896,-966,332,-961,-1000,-287,-916,-212,-716,291,-376,270,-27,641,-66,-149,-1000,108,-735,-794,72,525,-1000,762,-729,-827,713,12,-806,79,-210,-980,352,-99,-423,808,365,-806,488}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00074() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "pow(org.apache.commons.math.complex.Complex):org.apache.commons.math.complex.Complex",
            new int[]{175,693,580,-164,724,585,-743,329,133,-722,-132,-919,-687,890,466,317,136,-475,-258,292,-440,-733,-398,465,702,-761,-176,-172,-733,-64,-69,754,-233,55,-116,313,-639,-259,-39,-542,-183,776,-725,-327,93,619,-186,737,-664,-611,554,119,724,912,250,153,508,746,-146,-334,-158,-222,131,-27}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00075() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "pow(org.apache.commons.math.complex.Complex):org.apache.commons.math.complex.Complex",
            new int[]{423,529,-788,-252,790,420,962,794,-1000,326,-103,506,640,-1000,-386,-671,1000,693,-1000,1000,732,-266,-1000,1000,17,1000,-730,-887,513,-909,493,-322,-637,839,1000,808,-649,-531,374,-574,327,-1000,-511,140,-1000,997,-1000,164,-737,-1000,-157,-363,1000,-711,200,-290,1000,1000,1000,1000,451,-858,-1000,334}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00076() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "pow(org.apache.commons.math.complex.Complex):org.apache.commons.math.complex.Complex",
            new int[]{-1000,-731,-273,-687,596,583,-41,-133,263,-165,-1000,525,1000,264,-754,-281,283,323,-107,607,870,-208,-101,247,195,-713,862,-285,-1000,-653,699,-400,-510,47,1000,520,984,-1000,295,-148,-645,-431,-729,-186,-313,-85,-604,723,-854,-208,999,-1000,-1000,909,-552,-186,290,176,-878,218,-11,764,563,-549}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00077() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "pow(org.apache.commons.math.complex.Complex):org.apache.commons.math.complex.Complex",
            new int[]{-465,-192,613,-763,-73,554,-742,112,-174,-424,-388,920,984,-538,-916,559,375,892,-231,-146,538,553,-207,967,-460,-385,-338,-644,-279,-959,35,-816,-543,-48,793,-339,541,-988,-932,-760,-527,396,-39,812,-77,-734,103,68,-33,897,902,-929,-711,577,-633,-260,481,266,-277,-578,839,595,677,-975}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00078() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "pow(org.apache.commons.math.complex.Complex):org.apache.commons.math.complex.Complex",
            new int[]{-388,311,823,502,914,738,951,-159,-960,-135,-967,698,667,-787,-504,-64,-212,260,-900,893,-708,402,198,101,45,985,304,-630,226,-998,-513,949,-233,-950,-441,-878,67,829,-192,-21,-122,115,-897,367,229,-550,-376,-981,551,-948,-862,-236,827,418,829,350,473,918,-40,909,-62,-651,-645,-633}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00079() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "pow(org.apache.commons.math.complex.Complex):org.apache.commons.math.complex.Complex",
            new int[]{-909,1000,-454,-1000,-1000,-913,139,215,-1000,34,-465,-367,982,-249,-1000,461,-1000,-594,514,-972,775,-1000,-1000,487,658,90,0,-941,-1000,-591,-205,-1000,825,-227,-406,-929,1000,-633,-1000,368,-1000,43,690,-1000,-543,-805,-203,-19,516,-1000,1000,278,-306,322,11,-1000,392,1000,-1000,357,865,928,978,-952}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00080() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "sin():org.apache.commons.math.complex.Complex",
            new int[]{-718,-394,-615,758,-92,711,-488,-242,-34,-293,23,587,-967,409,-966,-338,907,74,-933,-825,637,149,-207,564,-641,949,265,-633,-671,-419,-726,841,-974,693,-878,-568,470,-850,542,-910,25,659,763,-259,-133,487,779,-213,17,-36,-226,-580,387,-771,355,746,643,830,-257,244,846,178,-599,903}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00081() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "sin():org.apache.commons.math.complex.Complex",
            new int[]{-1000,-1000,-955,-206,316,-209,649,283,1000,1000,-497,65,-897,-1000,-684,124,-1000,1000,-921,-1000,1000,278,487,1000,883,1000,-324,92,683,850,964,1000,378,825,-756,-9,1000,-672,-330,-195,-737,1000,1000,628,-391,-714,1000,412,492,585,166,-937,616,-1000,1000,47,1000,492,-492,-966,78,-856,-800,-632}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00082() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "sin():org.apache.commons.math.complex.Complex",
            new int[]{-1000,-1000,-1000,-593,-446,-975,-522,1000,1000,1000,1000,-563,-1000,-1000,235,568,-659,1000,-1000,684,1000,-36,1000,1000,1000,-520,-325,-1000,1000,1000,331,1000,-635,-162,-620,1000,28,1000,-868,137,-646,268,1000,1000,-673,-1000,1000,-773,339,168,802,-1000,1000,-236,-14,-999,-1000,-1000,991,-1000,-841,-1000,-812,-147}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00083() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "sinh():org.apache.commons.math.complex.Complex",
            new int[]{-20,-922,-3,-313,-239,944,-467,109,3,229,-380,-804,530,-829,-387,23,210,-79,436,-385,-74,-104,181,-293,33,942,-699,-636,-641,632,-430,-718,-410,-273,183,-54,-987,-675,-126,993,-988,561,-192,-914,-530,836,114,426,-731,-481,-584,-393,-531,823,-519,945,-590,104,189,-353,-16,263,-552,210}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00084() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "sinh():org.apache.commons.math.complex.Complex",
            new int[]{931,-987,-348,-674,897,607,156,-485,293,-949,481,-266,-229,840,-764,922,-521,501,103,-949,913,939,891,377,151,-938,18,462,360,886,-572,646,312,10,210,39,-245,876,673,232,-92,-466,502,-65,109,-210,732,-478,-319,-464,-212,-929,-529,832,568,-87,188,-100,665,911,652,-465,-793,762}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00085() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "sinh():org.apache.commons.math.complex.Complex",
            new int[]{279,922,-778,859,-733,327,872,1000,119,-573,498,154,618,-169,339,-1000,-146,826,1000,-194,-217,-1000,-762,479,392,554,69,202,949,32,-1000,-840,-576,-162,1000,750,673,-77,754,-546,1000,-299,-1000,-939,-369,-226,479,-208,-970,-1000,-535,-1000,-679,210,351,-26,1000,-1000,125,-517,-1,-552,-776,963}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00086() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "sqrt():org.apache.commons.math.complex.Complex",
            new int[]{235,-332,-909,250,-250,898,-333,-263,979,-651,573,956,-949,-858,-114,758,150,128,-775,564,-86,737,281,-694,431,77,327,116,665,-983,19,-423,-102,-454,-628,994,626,-107,-597,-686,227,-393,-397,-913,-333,55,-855,179,544,-325,510,796,841,-295,117,-131,900,-899,-580,799,340,859,-51,154}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00087() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "sqrt():org.apache.commons.math.complex.Complex",
            new int[]{418,-846,-301,-804,-962,129,-443,841,1000,381,-1000,151,-596,-725,195,61,763,902,-297,-376,-503,-279,170,-444,483,-747,918,227,704,462,87,798,-332,-600,65,408,570,807,1000,-343,236,548,672,-316,1000,213,-697,371,-900,133,812,-445,608,162,-588,945,1000,419,104,-101,-831,-672,-507,-70}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00088() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "sqrt():org.apache.commons.math.complex.Complex",
            new int[]{-734,-625,969,109,-48,-725,-897,-969,407,-445,-544,-265,-114,474,72,957,240,-691,-280,688,450,643,-80,-203,-371,608,776,176,512,221,-393,149,-846,-476,901,-503,444,-586,747,-366,894,-246,565,-759,148,647,-316,-42,646,620,134,629,977,823,-143,17,599,375,487,932,-212,491,823,-753}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00089() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "sqrt():org.apache.commons.math.complex.Complex",
            new int[]{282,-401,1000,-588,-1000,978,513,-833,-381,-146,200,841,544,798,-558,-154,578,-442,342,1000,686,856,993,29,820,-1000,391,-1000,-33,324,196,-556,-644,225,-500,-804,-1000,-104,-1000,706,-638,-817,-386,-997,-1000,-1000,391,-412,-196,1000,305,57,738,-1000,1000,-178,-567,-1000,-530,-357,358,1000,-122,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00090() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "sqrt():org.apache.commons.math.complex.Complex",
            new int[]{-708,-799,-351,-24,-851,696,-81,619,-358,1000,369,178,609,-1000,-513,-1000,-1000,-295,681,291,-823,817,85,-1000,121,-1000,-990,-943,581,670,485,829,-865,-49,-73,-72,773,-783,924,-351,1000,-710,742,1000,-119,-789,285,552,572,386,-71,315,371,-662,480,298,-79,-826,217,-414,-569,723,1000,-420}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00091() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "sqrt():org.apache.commons.math.complex.Complex",
            new int[]{425,851,-840,585,-58,-995,474,-954,-20,-184,-959,991,383,-112,309,851,300,435,-669,-609,-230,925,99,-360,402,889,-595,-969,-890,-264,-305,714,-371,19,-89,-398,-647,-259,939,914,-45,27,961,736,-831,-246,-279,-574,175,596,-458,-438,53,330,771,590,-15,-761,269,303,-992,-44,-467,882}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00092() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "sqrt():org.apache.commons.math.complex.Complex",
            new int[]{1000,510,421,-125,929,-697,124,529,-1000,535,-1000,-58,-494,210,1000,-642,-780,-1000,1000,365,788,-708,661,859,-1000,861,130,-875,-834,14,-382,237,51,-65,-30,-1000,-1000,72,120,695,-199,1000,1000,-302,-981,910,-1000,-544,-269,695,286,-187,-831,335,729,404,619,-150,-104,-497,-709,-520,711,738}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00093() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "sqrt1z():org.apache.commons.math.complex.Complex",
            new int[]{305,-580,57,-43,77,134,-947,463,578,-19,468,-146,-877,-891,732,90,-149,-278,-856,626,-420,949,-238,-862,591,-177,-125,-906,-564,631,854,-359,85,-756,-737,777,-761,200,-403,96,-517,317,713,537,101,-636,92,-495,-161,-50,-551,510,663,-795,-124,-996,688,41,702,546,-209,-166,-442,-460}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00094() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "sqrt1z():org.apache.commons.math.complex.Complex",
            new int[]{943,-945,-57,-169,771,-593,226,256,925,530,-542,316,46,890,-739,115,68,567,-813,-442,479,-729,231,394,134,138,-791,657,-448,-159,617,297,-199,-37,675,278,-367,-279,-284,742,329,101,-182,976,-81,283,615,888,842,795,-376,408,-52,306,83,-138,777,143,-703,695,-510,700,-209,169}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00095() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "sqrt1z():org.apache.commons.math.complex.Complex",
            new int[]{1000,-51,450,-272,53,-1000,854,-815,-943,-430,93,-687,1000,303,-1000,-17,-633,711,468,-529,22,-337,825,635,260,-299,-639,1000,-931,-1000,-486,-224,126,879,264,-201,988,-783,-732,127,1000,-1000,-737,533,550,846,38,428,523,-357,1000,-818,-297,1000,-103,743,-452,-1000,-461,-516,-61,725,-723,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00096() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "sqrt1z():org.apache.commons.math.complex.Complex",
            new int[]{984,-796,-69,-681,-158,-369,-216,-309,-749,-387,-23,-257,841,-670,-675,127,448,711,241,439,360,529,163,598,-531,-868,-684,283,768,-839,467,-530,-165,-34,-592,-351,492,-417,-647,-419,655,-863,172,-355,526,302,454,713,773,-929,740,-692,92,495,-33,325,-361,-722,142,3,233,169,594,-959}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00097() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "sqrt1z():org.apache.commons.math.complex.Complex",
            new int[]{-1000,705,1000,-994,-147,732,-359,179,1000,730,767,558,-611,1000,-324,881,-143,-1000,1000,14,235,-1000,1000,1000,-17,490,10,87,-1000,-1000,-777,1000,-1000,-1000,946,336,434,-208,341,904,-845,1000,-524,-592,102,-866,-1000,-683,-1000,1000,689,1000,-1000,329,334,198,-532,23,190,1000,1000,-442,926,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00098() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "sqrt1z():org.apache.commons.math.complex.Complex",
            new int[]{-162,449,77,-364,-1000,1000,-911,940,-57,-720,68,247,-1000,-975,968,271,-640,4,-543,703,548,784,-987,-1000,903,-520,-461,-764,-1000,563,1000,-178,577,-205,-470,1000,-1000,-252,-931,-422,-1000,450,318,732,516,-598,-958,-1000,0,-918,93,-455,843,-393,912,-1000,1000,-268,641,1000,-336,671,724,-354}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00099() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "subtract(org.apache.commons.math.complex.Complex):org.apache.commons.math.complex.Complex",
            new int[]{-63,737,836,791,711,-294,632,-780,900,-814,-151,966,-619,32,244,-634,367,729,-327,601,903,-881,713,-353,-453,546,992,-450,-718,-887,-565,690,970,739,-975,74,-326,-7,852,412,-946,-666,269,781,675,-722,-254,983,-414,-707,709,381,769,-241,40,950,-779,-799,213,-449,-717,189,-905,40}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00100() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "subtract(org.apache.commons.math.complex.Complex):org.apache.commons.math.complex.Complex",
            new int[]{599,-911,-601,-55,718,399,896,534,-302,725,911,440,-562,-760,-220,-36,520,371,-66,-459,507,-170,398,910,-220,-596,881,-907,-748,-274,-564,867,544,-759,-929,-198,238,-113,-125,660,-320,-365,242,983,474,960,-412,-999,-719,551,-397,695,-164,-843,-483,763,-819,-724,-874,542,-933,647,-610,514}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00101() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "subtract(org.apache.commons.math.complex.Complex):org.apache.commons.math.complex.Complex",
            new int[]{-941,-654,527,984,729,-953,116,-932,856,289,430,234,584,954,642,-361,18,-317,749,-592,-711,-139,154,482,-726,865,539,483,712,431,-99,422,-287,44,-952,496,-330,489,20,906,468,-600,-78,-315,-475,508,-523,-154,-313,-430,-755,804,306,515,-112,0,-104,-811,144,-63,-278,-695,-787,-596}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00102() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "tan():org.apache.commons.math.complex.Complex",
            new int[]{430,-56,-956,-647,-98,-990,819,-629,-526,-907,537,-532,155,-294,-837,17,526,-706,-409,-117,-71,541,-454,664,-164,-624,139,-301,-631,-132,882,-310,306,756,926,-874,-121,-954,-265,-845,128,-247,442,998,679,695,-261,-435,-578,-972,-704,-436,756,133,-560,22,-184,-599,98,-82,-569,-494,861,-596}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00103() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "tan():org.apache.commons.math.complex.Complex",
            new int[]{376,391,-467,-727,-415,907,-931,32,-925,272,-704,978,78,-743,444,109,-552,611,-782,-789,-177,329,416,-751,693,718,-187,-567,940,-206,-719,-385,-217,97,956,-906,-974,692,-224,-731,963,805,731,-883,-587,309,759,988,-63,-880,-603,-166,-485,445,988,-334,-316,-224,559,758,475,556,-685,-75}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00104() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "tan():org.apache.commons.math.complex.Complex",
            new int[]{-1000,1000,72,907,837,-579,-822,68,1000,9,557,575,989,130,676,-284,229,1000,1000,552,400,612,275,-146,-367,1000,270,460,364,-1000,-536,968,-374,-1000,-1000,156,665,1000,148,450,1000,-693,814,143,628,178,261,-494,-937,641,1000,-930,-1000,401,176,-304,-275,-838,-1000,119,-735,242,625,330}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00105() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "tanh():org.apache.commons.math.complex.Complex",
            new int[]{84,917,-396,243,952,-242,587,-744,29,147,-927,-939,-783,-461,973,718,-615,150,-188,-799,3,-743,686,-589,641,-370,961,-313,481,293,975,874,507,0,409,-660,-97,773,-223,457,-680,628,-504,-987,-869,-733,-604,789,596,-133,-793,-908,-96,378,-451,-566,-489,741,-751,741,-147,339,460,472}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00106() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "tanh():org.apache.commons.math.complex.Complex",
            new int[]{-666,69,804,225,147,-305,428,182,-851,214,31,286,-702,297,-915,177,639,-266,844,-843,-625,-412,-590,-846,818,749,-748,991,473,938,7,-627,-986,-634,855,-667,784,267,-533,-21,-448,-737,632,369,-236,170,971,-919,284,249,903,-380,705,-876,955,193,-278,658,861,576,760,-99,495,803}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00107() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.math.complex.Complex", DEReplay.run(
            "org.apache.commons.math.complex.Complex", "org.apache.commons.math.complex.Complex", "tanh():org.apache.commons.math.complex.Complex",
            new int[]{-409,603,-60,-125,-176,-780,-854,223,-577,657,-688,-677,538,833,572,-148,-346,-338,360,-833,130,-42,-168,64,-924,691,-177,-262,607,973,25,-369,-911,288,443,230,-241,494,990,-22,326,-130,-910,430,-433,-864,557,537,-270,-258,-316,-487,651,-14,485,118,872,552,318,410,783,-111,-244,4}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00108() {
        org.junit.Assert.assertEquals("ARRAY:[D:5:29:java.lang.Double:LUluZmluaXR5:45:java.lang.Double:My4yNjA5NTQ0NTYzMzMxOTU4RTE4:21:java.lang.Double:TmFO:21:java.lang.Double:TmFO:29:java.lang.Double:LUluZmluaXR5", DEReplay.run(
            "org.apache.commons.math.transform.FastCosineTransformer", "org.apache.commons.math.transform.FastCosineTransformer", "inversetransform(double[]):double[]",
            new int[]{291,-438,861,803,-525,287,890,974,778,-363,671,-450,359,-420,-678,924,-810,-856,-50,662,869,733,-341,490,118,567,-71,674,-666,291,139,337,843,383,-522,252,-384,856,734,886,-855,933,-489,-911,-145,841,355,-297,-976,-267,907,-405,-496,-202,751,-874,-303,112,944,-82,-745,480,-668,-66}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00109() {
        org.junit.Assert.assertEquals("ARRAY:[D:5:21:java.lang.Double:TmFO:29:java.lang.Double:LUluZmluaXR5:21:java.lang.Double:TmFO:21:java.lang.Double:TmFO:21:java.lang.Double:TmFO", DEReplay.run(
            "org.apache.commons.math.transform.FastCosineTransformer", "org.apache.commons.math.transform.FastCosineTransformer", "inversetransform(double[]):double[]",
            new int[]{-469,511,516,83,1000,-465,-553,-323,331,-1000,378,-1000,-1000,-1000,534,417,1000,-1000,449,-607,23,1000,-1000,-111,41,34,266,-588,-1000,-642,564,-1000,-694,1000,-69,-1000,328,1000,1000,343,-1000,-317,-557,-1000,-438,1000,506,901,-1000,-690,55,70,256,-502,1000,-1000,-95,253,1000,-789,-284,-81,-695,-938}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00110() {
        org.junit.Assert.assertEquals("ARRAY:[D:5:29:java.lang.Double:LUluZmluaXR5:29:java.lang.Double:SW5maW5pdHk=:21:java.lang.Double:TmFO:21:java.lang.Double:TmFO:29:java.lang.Double:LUluZmluaXR5", DEReplay.run(
            "org.apache.commons.math.transform.FastCosineTransformer", "org.apache.commons.math.transform.FastCosineTransformer", "inversetransform2(double[]):double[]",
            new int[]{387,-295,-885,-745,600,-454,-40,63,-50,318,-80,964,-853,321,20,-614,-647,524,262,647,-395,490,-472,-753,52,-554,-789,332,784,-198,-823,-913,183,865,-971,632,-299,244,-263,138,-204,-514,673,375,306,847,847,-367,1,-178,686,-911,261,987,130,-931,877,-914,-37,364,-176,852,353,-190}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00111() {
        org.junit.Assert.assertEquals("ARRAY:[D:5:21:java.lang.Double:TmFO:29:java.lang.Double:LUluZmluaXR5:21:java.lang.Double:TmFO:21:java.lang.Double:TmFO:21:java.lang.Double:TmFO", DEReplay.run(
            "org.apache.commons.math.transform.FastCosineTransformer", "org.apache.commons.math.transform.FastCosineTransformer", "inversetransform2(double[]):double[]",
            new int[]{28,911,435,341,-37,1000,765,1000,-1000,21,110,500,1000,662,-223,369,398,1000,-321,-796,-673,-332,1000,-262,431,-1000,-248,-346,-97,480,1000,-1000,-948,-796,596,1000,502,519,-1000,977,-1000,-569,-1000,976,520,620,1000,-577,-87,604,-468,290,1000,-12,696,532,470,731,1000,-441,-857,-900,-230,-238}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00112() {
        org.junit.Assert.assertEquals("ARRAY:[D:5:29:java.lang.Double:LUluZmluaXR5:29:java.lang.Double:LUluZmluaXR5:21:java.lang.Double:TmFO:21:java.lang.Double:TmFO:29:java.lang.Double:LUluZmluaXR5", DEReplay.run(
            "org.apache.commons.math.transform.FastCosineTransformer", "org.apache.commons.math.transform.FastCosineTransformer", "transform(double[]):double[]",
            new int[]{2,985,132,-865,-513,-975,896,468,612,-985,-795,615,431,-910,-118,-292,546,512,553,-233,64,610,-179,243,-400,804,10,-784,-169,138,-575,-166,687,-136,309,-457,-366,-20,689,968,-275,374,-796,-59,79,-777,-381,86,-704,-341,261,624,-74,334,861,604,-425,520,-584,673,-517,-391,592,618}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00113() {
        org.junit.Assert.assertEquals("ARRAY:[D:5:21:java.lang.Double:TmFO:29:java.lang.Double:LUluZmluaXR5:21:java.lang.Double:TmFO:21:java.lang.Double:TmFO:21:java.lang.Double:TmFO", DEReplay.run(
            "org.apache.commons.math.transform.FastCosineTransformer", "org.apache.commons.math.transform.FastCosineTransformer", "transform(double[]):double[]",
            new int[]{967,144,-207,821,683,544,-641,-131,657,-657,-229,488,547,-490,265,-56,-783,130,-707,-924,448,698,571,-18,386,495,673,549,-424,561,-13,-32,7,-98,-971,404,980,-74,-828,258,796,-142,715,129,296,870,-146,-548,-923,37,-392,102,-133,848,59,739,971,989,345,607,984,373,770,-374}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00114() {
        org.junit.Assert.assertEquals("ARRAY:[D:5:29:java.lang.Double:SW5maW5pdHk=:45:java.lang.Double:Ni41MjE5MDg5MTE1OTI2NDk3RTE4:21:java.lang.Double:TmFO:21:java.lang.Double:TmFO:29:java.lang.Double:SW5maW5pdHk=", DEReplay.run(
            "org.apache.commons.math.transform.FastCosineTransformer", "org.apache.commons.math.transform.FastCosineTransformer", "transform2(double[]):double[]",
            new int[]{-734,421,-417,-811,-640,677,172,-407,-235,-124,390,159,878,-870,603,-298,-549,765,-627,-793,453,46,927,-872,-658,-616,-733,672,429,516,-41,-517,183,-446,-53,-61,277,534,893,463,17,-814,468,685,-669,-11,796,79,-13,250,-180,788,-135,979,-264,748,-787,-415,859,929,612,92,-735,547}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00115() {
        org.junit.Assert.assertEquals("ARRAY:[D:5:21:java.lang.Double:TmFO:29:java.lang.Double:LUluZmluaXR5:21:java.lang.Double:TmFO:21:java.lang.Double:TmFO:21:java.lang.Double:TmFO", DEReplay.run(
            "org.apache.commons.math.transform.FastCosineTransformer", "org.apache.commons.math.transform.FastCosineTransformer", "transform2(double[]):double[]",
            new int[]{177,-524,-617,-151,-721,-176,1000,-225,-197,752,-323,-592,-960,806,-1000,-1000,911,665,746,-768,-564,1000,31,-826,1000,-733,-900,1000,407,-528,1000,1000,-525,199,-554,532,1000,62,-1000,-364,-1000,888,1000,1000,-48,571,-854,-1000,-172,-487,98,-815,456,-176,-269,1000,731,64,105,67,-72,-837,-1000,531}));
    }
}
