import java.lang.reflect.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Deterministic test-program decoder. Used unchanged during search and JUnit replay. */
final class DEReplay {
    public static final int DIMENSIONS = 64;
    /** Local generic bean used to create stable reflection Type and Field values. */
    public static final class GenericInput {
        public String text;
        public java.util.List<String> names;
        public java.util.Map<String, Integer> counts;
        public java.util.List<java.util.Map<String, Long>> nested;
        public int[] numbers;
        public String[] words;
    }
    static final class Genes {
        final int[] values; int at; Field lastField;
        Object jacksonBean, jacksonProvider, jacksonGenerator;
        StringWriter jacksonOutput;
        Genes(int[] values) { this.values = values; }
        int next() { return values[(at++) % values.length]; }
        int pick(int n) { return Math.floorMod(next(), n); }
    }
    public static final class Observation {
        public String token, error, generatedSource;
        public boolean reachedTarget;
        public int setupCalls, setupFailures, nullFallbacks;
    }
    public static String signature(Method m) {
        StringJoiner params = new StringJoiner(",");
        for (Class<?> t : m.getParameterTypes()) params.add(t.getTypeName());
        return m.getName() + "(" + params + "):" + m.getReturnType().getTypeName();
    }
    static Class<?> load(String name) throws ClassNotFoundException {
        return Class.forName(name, true, Thread.currentThread().getContextClassLoader());
    }
    static Method method(String target, String signature) throws Exception {
        for (Method m : load(target).getDeclaredMethods())
            if (signature(m).equals(signature)) {
                // Public methods on package-private Defects4J classes (for
                // example Gson's TypeInfoFactory) are not reflectively
                // accessible until opened on the unnamed application module.
                if (!m.isAccessible()) m.setAccessible(true);
                return m;
            }
        throw new NoSuchMethodException(signature);
    }
    static List<Constructor<?>> constructors(Class<?> type) {
        List<Constructor<?>> out = new ArrayList();
        if (!Modifier.isAbstract(type.getModifiers()) && Modifier.isPublic(type.getModifiers()))
            for (Constructor<?> c : type.getConstructors())
                if (c.getParameterTypes().length <= 6) out.add(c);
        Collections.sort(out, new Comparator<Constructor<?>>() {
            public int compare(Constructor<?> a, Constructor<?> b) {
                int byArity = a.getParameterTypes().length - b.getParameterTypes().length;
                return byArity != 0 ? byArity : a.toString().compareTo(b.toString());
            }
        });
        return out;
    }
    private static Object[] arguments(Class<?>[] types, Genes g, int depth,
                                      Observation report) throws Exception {
        Object[] args = new Object[types.length];
        for (int i = 0; i < types.length; i++) args[i] = value(types[i], g, depth, report);
        return args;
    }
    private static Object[] arguments(Method method, Genes g, int depth,
                                      Observation report) throws Exception {
        Class<?>[] types = method.getParameterTypes();
        Object[] args = new Object[types.length];
        boolean closureCompile = method.getDeclaringClass().getName().equals("com.google.javascript.jscomp.Compiler")
            && method.getName().equals("compile");
        Type[] generic = method.getGenericParameterTypes();
        boolean jacksonSerialization = method.getDeclaringClass().getName().equals(
            "com.fasterxml.jackson.databind.ser.BeanPropertyWriter")
            && method.getName().startsWith("serializeAs")
            && types.length == 3 && types[0] == Object.class;
        for (int i = 0; i < types.length; i++) {
            if (jacksonSerialization && g.jacksonBean != null) {
                if (i == 0) args[i] = g.jacksonBean;
                else if (i == 1) args[i] = g.jacksonGenerator;
                else args[i] = g.jacksonProvider;
                continue;
            }
            if (closureCompile && (List.class.isAssignableFrom(types[i])
                    || (types[i].isArray() && load("com.google.javascript.jscomp.SourceFile")
                        .isAssignableFrom(types[i].getComponentType())))) {
                // Compiler.compile takes externs and inputs in either Lists or
                // arrays depending on Closure version. Keep externs empty and
                // supply a nonempty, gene-selected input program.
                if (i == 0) args[i] = types[i].isArray()
                    ? Array.newInstance(types[i].getComponentType(), 0) : new ArrayList();
                else {
                    Object sourceFile = value(load("com.google.javascript.jscomp.SourceFile"),
                        g, depth + 1, report);
                    if (types[i].isArray()) {
                        Object files = Array.newInstance(types[i].getComponentType(), 1);
                        Array.set(files, 0, sourceFile); args[i] = files;
                    } else args[i] = new ArrayList(Collections.singletonList(sourceFile));
                }
            } else args[i] = value(types[i], g, depth, report);
        }
        return args;
    }
    private static Number number(Genes g) {
        int n = g.next();
        switch (g.pick(12)) {
            case 0: return 0; case 1: return 1; case 2: return -1;
            case 3: return Integer.MAX_VALUE; case 4: return Integer.MIN_VALUE;
            case 5: return Long.MAX_VALUE; case 6: return Long.MIN_VALUE;
            case 7: return Double.NaN; case 8: return Double.POSITIVE_INFINITY;
            case 9: return Double.NEGATIVE_INFINITY; case 10: return n / 10.0;
            default: return n;
        }
    }
    private static String string(Genes g) {
        int mode = g.pick(16), n = g.next();
        String digits = Long.toString(Math.abs((long)n));
        String sign = new String[]{"", "-", "+", "--"}[g.pick(4)];
        switch (mode) {
            case 0: return null; case 1: return ""; case 2: return " ";
            case 3: return Integer.toString(n);
            case 4: return sign + digits;
            case 5: return sign + digits + "." + g.pick(1000);
            case 6: return sign + digits + "e" + g.next();
            case 7: return sign + "0x" + Long.toHexString(Math.abs((long)n));
            case 8: return sign + "0x8" + "0".repeat(g.pick(20));
            case 9: return sign + digits + "fFdDlL".charAt(g.pick(6));
            case 10: return " " + sign + digits + " ";
            case 11: return new String[]{"true", "false", "null", "NaN", "Infinity"}[g.pick(5)];
            case 12: return "a".repeat(g.pick(25));
            default:
                String alphabet = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ+-._ /\\\t\n";
                StringBuilder s = new StringBuilder();
                int length = g.pick(25);
                for (int i = 0; i < length; i++) s.append(alphabet.charAt(g.pick(alphabet.length())));
                return s.toString();
        }
    }
    private static Object value(Class<?> t, Genes g, int depth, Observation report) throws Exception {
        if (t == String.class || t == CharSequence.class) return string(g);
        if (t == Comparable.class) return "key" + g.pick(5);
        if (t == boolean.class || t == Boolean.class) return g.pick(2) == 0;
        if (t == char.class || t == Character.class) return (char)g.pick(128);
        if (t == byte.class || t == Byte.class) return number(g).byteValue();
        if (t == short.class || t == Short.class) return number(g).shortValue();
        if (t == int.class || t == Integer.class) return number(g).intValue();
        if (t == long.class || t == Long.class) return number(g).longValue();
        if (t == float.class || t == Float.class) return number(g).floatValue();
        if (t == double.class || t == Double.class || t == Number.class) return number(g).doubleValue();
        if (t.isEnum()) {
            Object[] constants = t.getEnumConstants();
            return constants.length == 0 ? null : constants[g.pick(constants.length)];
        }
        if (t == Object.class) return g.pick(3) == 0 ? null : "object" + g.pick(5);
        if (depth >= 3) { report.nullFallbacks++; return null; }
        if (t.isArray()) {
            int length = g.pick(6);
            Object array = Array.newInstance(t.getComponentType(), length);
            for (int i = 0; i < length; i++) Array.set(array, i, value(t.getComponentType(), g, depth + 1, report));
            return array;
        }
        if (t == List.class || t == Collection.class || t == Iterable.class || t == Set.class) {
            Collection<Object> items = t == Set.class ? new LinkedHashSet() : new ArrayList();
            int size = g.pick(5);
            for (int i = 0; i < size; i++) items.add("item" + g.pick(5));
            return items;
        }
        if (t == Map.class) {
            Map<Object, Object> items = new LinkedHashMap();
            int size = g.pick(5);
            for (int i = 0; i < size; i++) items.put("key" + g.pick(5), number(g));
            return items;
        }
        if (t == java.util.Date.class) return new java.util.Date(g.next() * 86400000L);
        if (t == Class.class) return String.class;
        if (t == java.lang.reflect.Field.class) {
            Field[] fields = GenericInput.class.getFields();
            g.lastField = fields[g.pick(fields.length)];
            return g.lastField;
        }
        if (t == java.lang.reflect.Type.class) {
            if (g.lastField != null && g.pick(3) == 0)
                return g.lastField.getDeclaringClass();
            Field[] fields = GenericInput.class.getFields();
            return fields[g.pick(fields.length)].getGenericType();
        }
        if (t == java.io.Reader.class || t == java.io.BufferedReader.class
                || t == java.io.StringReader.class) {
            String content = "header,value\n" + string(g) + "," + number(g) + "\n"
                + "alpha,beta\n";
            StringReader reader = new StringReader(content);
            return t == java.io.BufferedReader.class ? new BufferedReader(reader) : reader;
        }
        if (t.getName().equals("org.apache.commons.csv.CSVFormat")) {
            Class<?> format = load("org.apache.commons.csv.CSVFormat");
            for (String fieldName : new String[]{"DEFAULT", "RFC4180", "EXCEL"}) try {
                Object result = format.getField(fieldName).get(null);
                if (t.isInstance(result)) return result;
            } catch (ReflectiveOperationException ignored) { }
            for (Method factory : format.getMethods())
                if (Modifier.isStatic(factory.getModifiers()) && factory.getParameterTypes().length == 0
                        && t.isAssignableFrom(factory.getReturnType())) try {
                    return factory.invoke(null);
                } catch (ReflectiveOperationException ignored) { }
        }
        if (t.getName().equals("com.google.javascript.jscomp.SourceFile")) {
            Class<?> source = load("com.google.javascript.jscomp.SourceFile");
            for (Method factory : source.getMethods())
                if (Modifier.isStatic(factory.getModifiers()) && factory.getName().equals("fromCode")
                        && factory.getParameterTypes().length == 2 && factory.getParameterTypes()[0] == String.class
                        && factory.getParameterTypes()[1] == String.class) {
                    String replaySource = System.getProperty("de.generated.source");
                    if (replaySource != null) {
                        try {
                            report.generatedSource = replaySource;
                            return factory.invoke(null, "de-input.js", replaySource);
                        } catch (ReflectiveOperationException ignored) { }
                    }
                    String[] unusedParameterScripts = {
                        "window.f = function(a) {};",
                        "window.f = function(a, b) { return b; };",
                        "window.f = function(a, b) { var used = b; return used; };",
                        "window['f'] = function(unused) {};",
                        "window.f = function(unused, value) { return value; };",
                        "window['f'] = function(unused, value) { return value; };",
                        "window.f = function(first, unused, last) { return last; };",
                        "window.f = function(unused) { var local = 1; return local; };",
                        "window.f = function(unused, value) { var alias = value; return alias; };",
                        "window.f = function(unused, value) { if (value) { return 1; } return 2; };",
                        "window.f = function(unused, value) { value = value + 1; return value; };",
                        "window.f = function(unused, value) { return function() { return value; }; };",
                        "window.f = function(unused) { function inner() { return 1; } return inner(); };",
                        "window.f = function(a, b, unused) { return a + b; };",
                        "window.f = function(a, unused, b, c) { return a + c; };"
                    };
                    String[] catchDependencyScripts = {
                        "window.f = function() { var saved; try { throw Error('x'); } catch (caught) { saved = caught; } return saved.stack; };",
                        "window.f = function(flag) { var saved; try { if (flag) throw Error('x'); } catch (caught) { saved = caught; } return saved.message; };",
                        "window.f = function() { var saved; try { throw Error('x'); } catch (caught) { saved = caught; } return saved.name; };",
                        "window.f = function() { var saved; try { throw Error('x'); } catch (caught) { saved = caught; } return String(saved); };",
                        "window.f = function(flag) { var saved; try { if (flag) throw Error('x'); } catch (problem) { saved = problem; } return saved.stack; };",
                        "window.f = function() { var saved; try { throw Error('x'); } catch (problem) { saved = problem; } return saved.message; };"
                    };
                    String[] genericScripts = {
                        "function f(unused, used) { var local = 1; return used; } f(1, 2);",
                        "function f() { var unused = 1; var used = 2; return used; } f();",
                        "function f(x) { var first = x; first = 3; return x; } f(2);",
                        "function f() { var unused = 1; } f();",
                        "function keep() { var dead = 1; return 7; } keep();"
                    };
                    String modified = System.getProperty("de.modified.classes", "");
                    String[] scripts;
                    if (modified.contains("RemoveUnusedVars") && modified.contains("FlowSensitiveInlineVariables")) {
                        scripts = new String[unusedParameterScripts.length + catchDependencyScripts.length];
                        System.arraycopy(unusedParameterScripts, 0, scripts, 0, unusedParameterScripts.length);
                        System.arraycopy(catchDependencyScripts, 0, scripts, unusedParameterScripts.length,
                            catchDependencyScripts.length);
                    }
                    else if (modified.contains("FlowSensitiveInlineVariables")) scripts = catchDependencyScripts;
                    else if (modified.contains("RemoveUnusedVars")) scripts = unusedParameterScripts;
                    else scripts = genericScripts;
                    try {
                        String code = scripts[g.pick(scripts.length)];
                        report.generatedSource = code;
                        return factory.invoke(null, "de-input.js", code);
                    }
                    catch (ReflectiveOperationException ignored) { }
                }
        }
        if (t.getName().equals("com.google.javascript.jscomp.CompilerOptions")) {
            try {
                Object options = t.getConstructor().newInstance();
                // In Closure Compiler, unused-variable passes are enabled by
                // CompilationLevel, rather than by a CompilerOptions enum
                // setter. Apply the real public configuration when available.
                try {
                    Class<?> levelType = load("com.google.javascript.jscomp.CompilationLevel");
                    Object advanced = levelType.getField("ADVANCED_OPTIMIZATIONS").get(null);
                    for (Method configure : levelType.getMethods())
                        if (configure.getName().equals("setOptionsForCompilationLevel")
                                && configure.getParameterTypes().length == 1
                                && configure.getParameterTypes()[0].isInstance(options)) {
                            configure.invoke(advanced, options); break;
                        }
                } catch (ReflectiveOperationException ignored) { }
                // Also set the relevant options directly for Closure releases
                // whose compilation-level helper no longer enables this pass.
                for (Class<?> current = t; current != null; current = current.getSuperclass())
                    for (Field field : current.getDeclaredFields()) {
                        String name = field.getName().toLowerCase(Locale.ROOT);
                        if (field.getType() == boolean.class && name.equals("removeglobals")) try {
                            // Closure-1 specifically guards argument removal
                            // when globals are preserved. Keep the optimization
                            // pass enabled while exercising that configuration.
                            field.setAccessible(true); field.setBoolean(options, false);
                        } catch (Exception ignored) { }
                        if (field.getType() == boolean.class
                                && (name.contains("removeunusedvar") || name.contains("removeunusedlocal"))) try {
                            field.setAccessible(true); field.setBoolean(options, true);
                        } catch (Exception ignored) { }
                    }
                for (Method setter : t.getMethods()) {
                    if (!Modifier.isPublic(setter.getModifiers()) || !setter.getName().startsWith("set")
                            || setter.getParameterTypes().length != 1) continue;
                    String name = setter.getName().toLowerCase(Locale.ROOT);
                    if (setter.getParameterTypes()[0] == boolean.class && name.contains("removeglobals")) {
                        try { setter.invoke(options, false); } catch (ReflectiveOperationException ignored) { }
                    } else if (setter.getParameterTypes()[0] == boolean.class
                            && (name.contains("removeunusedvar") || name.contains("removeunusedlocal"))) {
                        try { setter.invoke(options, true); } catch (ReflectiveOperationException ignored) { }
                    } else if (name.contains("optimizationlevel")
                            && setter.getParameterTypes()[0].isEnum()) {
                        Object[] values = setter.getParameterTypes()[0].getEnumConstants();
                        for (Object value : values) if (String.valueOf(value).contains("ADVANCED"))
                            try { setter.invoke(options, value); } catch (ReflectiveOperationException ignored) { }
                    }
                }
                return options;
            } catch (ReflectiveOperationException ignored) { }
        }
        if (t.getName().equals("com.google.javascript.rhino.Node")) {
            try {
                Class<?> ir = load("com.google.javascript.rhino.IR");
                for (String factoryName : new String[]{"script", "root", "name", "string"})
                    for (Method factory : ir.getMethods())
                        if (Modifier.isStatic(factory.getModifiers()) && factory.getName().equals(factoryName)
                                && factory.getParameterTypes().length == 0 && t.isAssignableFrom(factory.getReturnType()))
                            return factory.invoke(null);
            } catch (ReflectiveOperationException ignored) { }
        }
        if (t.getName().equals("com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser")) {
            Object parser = xmlParser(g, report);
            if (parser != null && t.isInstance(parser)) return parser;
        }
        if (t.getName().equals("com.fasterxml.jackson.databind.ser.BeanPropertyWriter")
                || t.getName().equals("com.fasterxml.jackson.databind.ser.impl.UnwrappingBeanPropertyWriter")) {
            Object writer = jacksonWriter(t, g, report);
            if (writer != null && t.isInstance(writer)) return writer;
        }
        if (t == java.awt.Graphics2D.class || t == java.awt.Graphics.class)
            return new java.awt.image.BufferedImage(80, 80, java.awt.image.BufferedImage.TYPE_INT_ARGB).createGraphics();
        if (java.awt.Paint.class.isAssignableFrom(t)) {
            java.awt.Color c = new java.awt.Color(g.pick(256), g.pick(256), g.pick(256));
            if (t.isInstance(c)) return c;
        }
        if (java.awt.Stroke.class.isAssignableFrom(t)) {
            java.awt.BasicStroke s = new java.awt.BasicStroke(g.pick(10) / 2.0f);
            if (t.isInstance(s)) return s;
        }
        if (java.awt.Shape.class.isAssignableFrom(t)) {
            java.awt.Shape s = new java.awt.geom.Rectangle2D.Double(g.next(), g.next(), g.pick(80), g.pick(80));
            if (t.isInstance(s)) return s;
        }
        if (t == java.awt.geom.Point2D.class) return new java.awt.geom.Point2D.Double(g.next(), g.next());
        if (t.getName().equals("org.apache.commons.cli.CommandLine"))
            return commandLine(g, report);
        Object domain = chart(t, g, report);
        if (domain != null) return domain;
        Object language = language(t, g, report);
        if (language != null) return language;
        List<Constructor<?>> ctors = constructors(t);
        // Older Java libraries often use public singleton constants in place of enums.
        if (ctors.isEmpty()) {
            List<Field> constants = new ArrayList();
            for (Field field : t.getFields())
                if (Modifier.isStatic(field.getModifiers()) && Modifier.isFinal(field.getModifiers())
                        && t.isAssignableFrom(field.getType())) constants.add(field);
            Collections.sort(constants, new Comparator<Field>() {
                public int compare(Field a, Field b) { return a.getName().compareTo(b.getName()); }
            });
            if (!constants.isEmpty()) {
                Object constant = constants.get(g.pick(constants.size())).get(null);
                if (constant != null) return constant;
            }
        }
        if (!ctors.isEmpty()) {
            Constructor<?> ctor = ctors.get(g.pick(ctors.size()));
            try { return ctor.newInstance(arguments(ctor.getParameterTypes(), g, depth + 1, report)); }
            catch (Exception ignored) { }
        }
        report.nullFallbacks++;
        return null;
    }
    private static Object language(Class<?> t, Genes g, Observation report) {
        if (!t.getName().equals("org.apache.commons.lang3.time.FastDateFormat")) return null;
        try {
            Method factory = t.getMethod("getInstance", String.class, java.util.TimeZone.class,
                java.util.Locale.class);
            String[] patterns = {"yyyy-MM-dd", "MM/dd/yy HH:mm:ss", "EEE, d MMM yyyy HH:mm:ss Z"};
            return factory.invoke(null, patterns[g.pick(patterns.length)],
                java.util.TimeZone.getTimeZone("UTC"), java.util.Locale.US);
        } catch (ReflectiveOperationException ignored) { }
        try { return t.getMethod("getInstance", String.class).invoke(null, "yyyy-MM-dd"); }
        catch (ReflectiveOperationException ignored) { return null; }
    }
    private static Object xmlParser(Genes g, Observation report) {
        try {
            Class<?> factoryType = load("com.fasterxml.jackson.dataformat.xml.XmlFactory");
            Object factory = factoryType.getConstructor().newInstance();
            String[] docs = {"<root><value>1</value><name>x</name></root>",
                "<root value=\"42\"><item>a</item><item>b</item></root>",
                "<root/>"};
            String xml = docs[g.pick(docs.length)];
            for (Method method : factoryType.getMethods()) {
                if (!method.getName().equals("createParser") || method.getParameterTypes().length != 1) continue;
                Class<?> p = method.getParameterTypes()[0];
                Object input = p == String.class ? xml : p == Reader.class ? new StringReader(xml)
                    : p == InputStream.class ? new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8)) : null;
                if (input == null) continue;
                try {
                    Object parser = method.invoke(factory, input);
                    if (parser != null) {
                        int advance = g.pick(4);
                        Method next = parser.getClass().getMethod("nextToken");
                        for (int i = 0; i < advance; i++) if (next.invoke(parser) == null) break;
                        return parser;
                    }
                } catch (ReflectiveOperationException ignored) { }
            }
        } catch (Throwable ignored) { }
        return null;
    }
    private static Object jacksonWriter(Class<?> requested, Genes g, Observation report) {
        try {
            Class<?> mapperType = load("com.fasterxml.jackson.databind.ObjectMapper");
            Object mapper = mapperType.getConstructor().newInstance();
            Object bean = new GenericInput();
            Class<?> javaTypeType = load("com.fasterxml.jackson.databind.JavaType");
            Object javaType = mapperType.getMethod("constructType", Type.class).invoke(mapper, bean.getClass());
            // Jackson 2.6 (used by this Defects4J project) exposes a provider
            // blueprint from ObjectMapper. Create a configured provider via
            // DefaultSerializerProvider, the supported API used by ObjectMapper.
            Object providerBlueprint = mapperType.getMethod("getSerializerProvider").invoke(mapper);
            Class<?> serializationConfigType = load("com.fasterxml.jackson.databind.SerializationConfig");
            Class<?> serializerFactoryType = load("com.fasterxml.jackson.databind.ser.SerializerFactory");
            Object config = mapperType.getMethod("getSerializationConfig").invoke(mapper);
            Object factory = mapperType.getMethod("getSerializerFactory").invoke(mapper);
            Class<?> defaultProviderType = load("com.fasterxml.jackson.databind.ser.DefaultSerializerProvider");
            Method createProvider = defaultProviderType.getMethod("createInstance",
                serializationConfigType, serializerFactoryType);
            Object provider = createProvider.invoke(providerBlueprint, config, factory);
            g.jacksonBean = bean;
            g.jacksonProvider = provider;
            g.jacksonOutput = new StringWriter();
            Object jsonFactory = mapperType.getMethod("getFactory").invoke(mapper);
            for (String factoryMethod : new String[]{"createGenerator", "createJsonGenerator"}) {
                try {
                    Method createGenerator = jsonFactory.getClass().getMethod(factoryMethod, Writer.class);
                    g.jacksonGenerator = createGenerator.invoke(jsonFactory, g.jacksonOutput);
                    break;
                } catch (NoSuchMethodException ignored) { }
            }
            if (g.jacksonGenerator == null)
                throw new NoSuchMethodException("JsonFactory.createGenerator(Writer) or createJsonGenerator(Writer)");
            Class<?> providerType = load("com.fasterxml.jackson.databind.SerializerProvider");
            Class<?> beanPropertyType = load("com.fasterxml.jackson.databind.BeanProperty");
            Method find = providerType.getMethod("findValueSerializer", javaTypeType, beanPropertyType);
            Object serializer = find.invoke(provider, new Object[]{javaType, null});
            List<Object> writers = new ArrayList();
            try {
                // Available on Jackson 2.6 and newer.
                Class<?> serializerType = load("com.fasterxml.jackson.databind.JsonSerializer");
                Method properties = serializerType.getMethod("properties");
                Iterator<?> it = (Iterator<?>)properties.invoke(serializer);
                while (it.hasNext()) {
                    Object item = it.next();
                    if (item != null && item.getClass().getName().endsWith("BeanPropertyWriter"))
                        writers.add(item);
                }
            } catch (NoSuchMethodException oldJackson) {
                // JacksonDatabind-1 predates JsonSerializer.properties(). Its
                // BeanSerializerBase stores writers in the protected _props
                // array; read that array only for these old releases.
                Class<?> base = load("com.fasterxml.jackson.databind.ser.std.BeanSerializerBase");
                if (!base.isInstance(serializer))
                    throw new IllegalStateException("Expected BeanSerializerBase, got "
                        + serializer.getClass().getName(), oldJackson);
                Field props = base.getDeclaredField("_props");
                props.setAccessible(true);
                Object array = props.get(serializer);
                for (int i = 0; i < Array.getLength(array); i++) {
                    Object item = Array.get(array, i);
                    if (item != null && item.getClass().getName().endsWith("BeanPropertyWriter"))
                        writers.add(item);
                }
            }
            if (writers.isEmpty())
                throw new IllegalStateException("ObjectMapper produced no bean property writers for DEReplay.GenericInput");
            Object writer = writers.get(g.pick(writers.size()));
            boolean requireUnwrapping = requested.getName().equals(
                "com.fasterxml.jackson.databind.ser.impl.UnwrappingBeanPropertyWriter");
            if (!requireUnwrapping && g.pick(2) == 0 && requested.isInstance(writer)) return writer;
            Class<?> transformerType = load("com.fasterxml.jackson.databind.util.NameTransformer");
            Object nop = transformerType.getField("NOP").get(null);
            for (Method m : writer.getClass().getMethods())
                if (m.getName().equals("unwrappingWriter") && m.getParameterTypes().length == 1
                        && m.getParameterTypes()[0].isInstance(nop)) {
                    Object unwrapped = m.invoke(writer, nop);
                    if (requested.isInstance(unwrapped)) return unwrapped;
                }
            if (requested.isInstance(writer)) return writer;
            throw new IllegalStateException("Generated Jackson property writer is not " + requested.getName());
        } catch (Throwable failure) {
            throw new IllegalStateException("Cannot construct Jackson BeanPropertyWriter: " + failure, failure);
        }
    }
    /** Build the non-constructible Commons CLI result through its public Parser API. */
    private static Object commandLine(Genes g, Observation report) throws Exception {
        Class<?> optionsClass = load("org.apache.commons.cli.Options");
        Class<?> optionClass = load("org.apache.commons.cli.Option");
        Class<?> parserClass = load("org.apache.commons.cli.PosixParser");
        Object options = optionsClass.getConstructor().newInstance();
        Method addOption = optionsClass.getMethod("addOption", optionClass);
        int numberOfOptions = 1 + g.pick(3);
        List<String> spellings = new ArrayList();
        for (int i = 0; i < numberOfOptions; i++) {
            String shortName = String.valueOf((char)('a' + i));
            String longName = "de-option-" + i;
            boolean hasArgument = g.pick(2) == 0;
            Object option = null;
            try {
                option = optionClass.getConstructor(String.class, String.class, boolean.class, String.class)
                    .newInstance(shortName, longName, hasArgument, "DE-generated option");
            } catch (NoSuchMethodException ignored) { }
            if (option == null) try {
                option = optionClass.getConstructor(String.class, boolean.class, String.class)
                    .newInstance(shortName, hasArgument, "DE-generated option");
            } catch (NoSuchMethodException ignored) { }
            if (option == null) throw new NoSuchMethodException("No supported Commons CLI Option constructor");
            addOption.invoke(options, option);
            spellings.add("-" + shortName);
            if (hasArgument) spellings.add("value-" + Math.abs((long)g.next()));
        }
        String[] argv = spellings.toArray(new String[0]);
        Object parser = parserClass.getConstructor().newInstance();
        List<Method> parseMethods = new ArrayList();
        for (Method candidate : parserClass.getMethods()) {
            Class<?>[] p = candidate.getParameterTypes();
            if (candidate.getName().equals("parse") && p.length >= 2 && p[0] == optionsClass
                    && p[1] == String[].class && candidate.getReturnType() == load("org.apache.commons.cli.CommandLine"))
                parseMethods.add(candidate);
        }
        Collections.sort(parseMethods, new Comparator<Method>() {
            public int compare(Method a, Method b) {
                return a.getParameterTypes().length - b.getParameterTypes().length;
            }
        });
        for (Method parse : parseMethods) {
            Object[] args = new Object[parse.getParameterTypes().length];
            Class<?>[] p = parse.getParameterTypes();
            args[0] = options; args[1] = argv;
            for (int i = 2; i < p.length; i++) {
                if (p[i] == boolean.class || p[i] == Boolean.class) args[i] = g.pick(2) == 0;
                else if (p[i] == java.util.Properties.class) args[i] = new java.util.Properties();
                else args[i] = value(p[i], g, 1, report);
            }
            try { return parse.invoke(parser, args); }
            catch (InvocationTargetException ignored) { }
        }
        throw new NoSuchMethodException("No successful public PosixParser.parse(Options,String[])");
    }
    /** Optional type recipes, shared across bugs; none contains a bug-specific expected answer. */
    private static Object chart(Class<?> t, Genes g, Observation report) throws Exception {
        String n = t.getName();
        if (!n.startsWith("org.jfree.")) return null;
        if (n.equals("org.jfree.data.Range")) {
            double a = g.next(), b = g.next();
            return t.getConstructor(double.class, double.class).newInstance(Math.min(a, b), Math.max(a, b));
        }
        if (n.equals("org.jfree.data.time.RegularTimePeriod"))
            return load("org.jfree.data.time.Day").getConstructor(int.class, int.class, int.class)
                .newInstance(1 + g.pick(28), 1 + g.pick(12), 1990 + g.pick(40));
        if (n.equals("org.jfree.data.time.TimeSeries")) {
            Object series = t.getConstructor(Comparable.class).newInstance("DE");
            Class<?> period = load("org.jfree.data.time.RegularTimePeriod");
            Constructor<?> day = load("org.jfree.data.time.Day")
                .getConstructor(int.class, int.class, int.class);
            Method add = t.getMethod("add", period, double.class);
            int count = 2 + g.pick(4), year = 1990 + g.pick(40);
            for (int i = 0; i < count; i++)
                add.invoke(series, day.newInstance(i + 1, 1, year), g.next() / 10.0);
            return series;
        }
        if (n.equals("org.jfree.data.category.CategoryDataset")
                || n.equals("org.jfree.data.category.DefaultCategoryDataset")) {
            Class<?> c = load("org.jfree.data.category.DefaultCategoryDataset");
            Object data = c.getConstructor().newInstance();
            Method add = c.getMethod("addValue", Number.class, Comparable.class, Comparable.class);
            int rows = 1 + g.pick(3), columns = 1 + g.pick(3);
            for (int r = 0; r < rows; r++) for (int col = 0; col < columns; col++)
                add.invoke(data, Double.valueOf(g.next() / 10.0), "R" + r, "C" + col);
            return data;
        }
        if (n.equals("org.jfree.data.xy.XYDataset") || n.equals("org.jfree.data.xy.XYSeriesCollection")) {
            Class<?> seriesClass = load("org.jfree.data.xy.XYSeries");
            Object series = seriesClass.getConstructor(Comparable.class).newInstance("DE");
            int count = 1 + g.pick(5);
            for (int i = 0; i < count; i++) seriesClass.getMethod("add", double.class, double.class)
                .invoke(series, (double)i, g.next() / 10.0);
            Class<?> c = load("org.jfree.data.xy.XYSeriesCollection");
            Object data = c.getConstructor().newInstance();
            c.getMethod("addSeries", seriesClass).invoke(data, series);
            return data;
        }
        if (n.equals("org.jfree.data.general.PieDataset") || n.equals("org.jfree.data.general.DefaultPieDataset")) {
            Class<?> c = load("org.jfree.data.general.DefaultPieDataset");
            Object data = c.getConstructor().newInstance();
            int count = 1 + g.pick(5);
            for (int i = 0; i < count; i++) c.getMethod("setValue", Comparable.class, Number.class)
                .invoke(data, "K" + i, Double.valueOf(g.next() / 10.0));
            return data;
        }
        return null;
    }
    static List<Method> setupMethods(Class<?> receiver) {
        List<Method> methods = new ArrayList();
        for (Method m : receiver.getMethods()) {
            String n = m.getName();
            if (!Modifier.isStatic(m.getModifiers()) && !m.isSynthetic()
                    && m.getParameterTypes().length <= 3 && !n.contains("Listener")
                    && (n.startsWith("set") || n.startsWith("add") || n.startsWith("update")
                        || n.startsWith("remove") || n.equals("clear"))) methods.add(m);
        }
        Collections.sort(methods, new Comparator<Method>() {
            public int compare(Method a, Method b) {
                return signature(a).compareTo(signature(b));
            }
        });
        return methods;
    }
    public static Observation execute(String target, String receivers, String signature, int[] genes) {
        Observation out = new Observation();
        try {
            Genes g = new Genes(genes);
            Method m = method(target, signature);
            Object receiver = null;
            if (!Modifier.isStatic(m.getModifiers())) {
                String[] choices = receivers.split(",");
                Class<?> receiverType = load(choices[g.pick(choices.length)]);
                receiver = value(receiverType, g, 0, out);
                if (receiver == null) throw new IllegalArgumentException("Receiver construction failed");
                // Compiler.compile owns a strict initialization sequence.
                // Random calls to its mutators before compilation can corrupt
                // state or spend the search budget on irrelevant setup.
                if (!receiverType.getName().equals("com.google.javascript.jscomp.Compiler")) {
                    List<Method> setup = setupMethods(receiverType);
                    int count = g.pick(5);
                    for (int i = 0; i < count && !setup.isEmpty(); i++) {
                        Method s = setup.get(g.pick(setup.size()));
                        try { s.invoke(receiver, arguments(s.getParameterTypes(), g, 0, out)); out.setupCalls++; }
                        catch (Exception e) { out.setupFailures++; }
                    }
                }
            }
            Object[] args = arguments(m, g, 0, out);
            out.reachedTarget = true;
            try {
                boolean jacksonSerialization = m.getDeclaringClass().getName().equals(
                    "com.fasterxml.jackson.databind.ser.BeanPropertyWriter")
                    && m.getName().startsWith("serializeAs") && g.jacksonGenerator != null;
                boolean arrayShape = m.getName().contains("Column")
                    || m.getName().contains("Element") || m.getName().contains("Placeholder");
                if (jacksonSerialization)
                    g.jacksonGenerator.getClass().getMethod(arrayShape
                        ? "writeStartArray" : "writeStartObject").invoke(g.jacksonGenerator);
                Object result = m.invoke(receiver, args);
                boolean closureCompile = m.getDeclaringClass().getName().equals(
                    "com.google.javascript.jscomp.Compiler") && m.getName().equals("compile");
                if (closureCompile) {
                    // Result is only a status object; the compiled JavaScript is
                    // the behavioral output that reveals whether an argument
                    // was removed from a globally exposed function.
                    Object js = receiver.getClass().getMethod("toSource").invoke(receiver);
                    out.token = "CLOSURE_SOURCE:" + stable(js, 0);
                } else if (jacksonSerialization) {
                    g.jacksonGenerator.getClass().getMethod(arrayShape
                        ? "writeEndArray" : "writeEndObject").invoke(g.jacksonGenerator);
                    g.jacksonGenerator.getClass().getMethod("flush").invoke(g.jacksonGenerator);
                    out.token = "JSON:" + Base64.getEncoder().encodeToString(
                        g.jacksonOutput.toString().getBytes(StandardCharsets.UTF_8));
                } else out.token = m.getReturnType() == void.class
                    ? state(receiver, m.getName()) : stable(result, 0);
            } catch (InvocationTargetException e) {
                if (e.getCause() instanceof VirtualMachineError || e.getCause() instanceof LinkageError
                        || e.getCause() instanceof ThreadDeath) throw e;
                out.token = "THROW:" + e.getCause().getClass().getName();
            }
        } catch (Throwable e) {
            out.token = "HARNESS_ERROR";
            out.error = e.getClass().getName() + ":" + String.valueOf(e.getMessage());
        }
        return out;
    }
    public static String run(String target, String receivers, String signature, int[] genes) {
        Observation o = execute(target, receivers, signature, genes);
        if (!o.reachedTarget || o.token.equals("HARNESS_ERROR"))
            throw new AssertionError("Cannot replay test: " + o.error);
        return o.token;
    }
    private static String state(Object receiver, String method) {
        if (receiver == null) return "VOID";
        List<String> getters = new ArrayList();
        if (method.startsWith("set") && method.length() > 3) {
            getters.add("get" + method.substring(3)); getters.add("is" + method.substring(3));
        }
        getters.addAll(Arrays.asList("getItemCount", "getRowCount", "getColumnCount", "getSeriesCount"));
        StringBuilder s = new StringBuilder("VOID");
        for (String name : getters) {
            try {
                Method getter = receiver.getClass().getMethod(name);
                if (getter.getReturnType().isPrimitive() || getter.getReturnType() == String.class)
                    s.append('|').append(name).append('=').append(stable(getter.invoke(receiver), 0));
            } catch (ReflectiveOperationException ignored) { }
        }
        return s.toString();
    }
    /** Only whitelisted value types are rendered. Never use arbitrary object toString(). */
    static String stable(Object value, int depth) {
        if (value == null) return "NULL";
        Class<?> t = value.getClass();
        if (value instanceof String || value instanceof Boolean || value instanceof Character
                || value instanceof Byte || value instanceof Short || value instanceof Integer
                || value instanceof Long || value instanceof Float || value instanceof Double
                || value instanceof java.math.BigInteger || value instanceof java.math.BigDecimal)
            return t.getName() + ":" + Base64.getEncoder().encodeToString(value.toString().getBytes(StandardCharsets.UTF_8));
        if (value instanceof Enum) return "ENUM:" + t.getName() + ":" + ((Enum<?>)value).name();
        if (t.isArray() && depth < 3) {
            StringBuilder s = new StringBuilder("ARRAY:" + t.getName() + ":" + Array.getLength(value));
            for (int i = 0; i < Math.min(64, Array.getLength(value)); i++) {
                String item = stable(Array.get(value, i), depth + 1);
                s.append(':').append(item.length()).append(':').append(item);
            }
            return s.toString();
        }
        if (value instanceof java.awt.Color) return "COLOR:" + ((java.awt.Color)value).getRGB();
        // Observe safe scalar properties of returned objects. This catches
        // changes to value caches and state while avoiding identity-based toString().
        StringBuilder observed = new StringBuilder("STATE:" + t.getName());
        int properties = 0;
        for (String name : Arrays.asList("getItemCount", "getMinY", "getMaxY",
                "getRowCount", "getColumnCount", "getSeriesCount")) {
            try {
                Method getter = t.getMethod(name);
                Class<?> r = getter.getReturnType();
                if (!r.isPrimitive() && r != String.class && !Number.class.isAssignableFrom(r))
                    continue;
                if (r == void.class) continue;
                Object result = getter.invoke(value);
                String token = stable(result, depth + 1);
                observed.append('|').append(name).append('=').append(token.length())
                    .append(':').append(token);
                properties++;
            } catch (Exception ignored) { }
        }
        return properties == 0 ? "TYPE:" + t.getName() : observed.toString();
    }
    public static void main(String[] args) {
        if (args.length > 4) {
            String source = new String(Base64.getDecoder().decode(args[4]), StandardCharsets.UTF_8);
            System.setProperty("de.generated.source", source);
        }
        String[] encodedGenes = args[3].split(",");
        int[] genes = new int[encodedGenes.length];
        for (int i = 0; i < encodedGenes.length; i++) genes[i] = Integer.parseInt(encodedGenes[i]);
        boolean closureCompile = args[0].equals("com.google.javascript.jscomp.Compiler")
            && args[2].startsWith("compile(");
        // Compiler.compile is an expensive whole-program operation. Fixed-side
        // suites are still executed twice by the runner, so capture its oracle
        // once here instead of launching three compilations just to check the
        // same deterministic source output.
        int repetitions = closureCompile ? 1 : 3;
        for (int i = 0; i < repetitions; i++) {
            Observation out = execute(args[0], args[1], args[2], genes);
            System.out.println("DE_TOKEN:" + Base64.getEncoder().encodeToString(out.token.getBytes(StandardCharsets.UTF_8)));
        }
    }
}

public class DEGeneratedTest {
    @org.junit.Test(timeout=60000L)
    public void testDE00000() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.time.FastDateFormat", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getDateInstance(int):org.apache.commons.lang.time.FastDateFormat",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00001() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.time.FastDateFormat", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getDateInstance(int,java.util.Locale):org.apache.commons.lang.time.FastDateFormat",
            new int[]{784,84,-384,-166,-296,-135,51,754,-520,494,-606,-569,997,-491,924,402,640,-171,-745,-314,425,210,-365,-133,550,392,-580,927,-772,620,886,-199,33,722,728,242,626,219,-790,-948,688,32,749,978,-838,291,-70,653,-480,-551,433,-157,619,-536,-845,-39,-17,174,-60,-677,-179,-872,744,-77}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00002() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.time.FastDateFormat", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getDateInstance(int,java.util.Locale):org.apache.commons.lang.time.FastDateFormat",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00003() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.time.FastDateFormat", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getDateInstance(int,java.util.TimeZone):org.apache.commons.lang.time.FastDateFormat",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00004() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.time.FastDateFormat", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getDateInstance(int,java.util.TimeZone):org.apache.commons.lang.time.FastDateFormat",
            new int[]{33,154,260,862,354,326,-637,655,323,289,272,-400,-679,1000,1000,641,1000,1000,-1000,-683,567,1000,1000,-575,-1000,-1000,-310,-400,447,-653,1000,1000,-705,46,-648,1000,-603,-301,21,-902,679,275,-812,-959,-725,558,-563,116,809,-773,-595,-751,1000,350,-424,-582,-435,-408,875,-40,-106,205,-140,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00005() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.time.FastDateFormat", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getDateInstance(int,java.util.TimeZone,java.util.Locale):org.apache.commons.lang.time.FastDateFormat",
            new int[]{-616,-696,-365,-600,-266,-256,-339,-328,752,-495,264,-862,435,-979,-92,-799,869,-934,90,180,-699,-133,-165,-581,-54,-301,68,41,-305,457,667,-130,40,273,164,-83,-754,945,837,-173,-899,674,240,-352,-605,388,85,-606,721,826,861,22,119,-553,-477,-377,661,-764,223,907,-855,-488,98,414}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00006() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.time.FastDateFormat", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getDateInstance(int,java.util.TimeZone,java.util.Locale):org.apache.commons.lang.time.FastDateFormat",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00007() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.time.FastDateFormat", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getDateTimeInstance(int,int):org.apache.commons.lang.time.FastDateFormat",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00008() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.time.FastDateFormat", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getDateTimeInstance(int,int):org.apache.commons.lang.time.FastDateFormat",
            new int[]{914,888,-120,145,351,972,761,349,382,-975,181,-472,-237,13,-875,956,825,-748,698,-411,862,-468,912,-682,390,-924,-666,268,-469,-634,601,-86,787,468,73,866,498,-405,-789,-143,392,343,686,658,825,-715,-351,451,521,-573,150,532,-55,400,216,105,774,-794,-188,445,397,836,544,-330}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00009() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.time.FastDateFormat", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getDateTimeInstance(int,int,java.util.Locale):org.apache.commons.lang.time.FastDateFormat",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00010() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.time.FastDateFormat", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getDateTimeInstance(int,int,java.util.Locale):org.apache.commons.lang.time.FastDateFormat",
            new int[]{112,295,31,-431,-908,1000,-837,1000,-675,-321,1000,252,1000,-424,479,-290,-397,-381,-944,-137,-721,-181,788,-937,166,-103,-594,565,-281,217,-772,583,-201,-1000,-460,-367,939,824,558,32,-323,42,706,173,-361,1000,863,1000,-347,1000,-1000,-392,162,-388,-527,-300,-219,1000,-1000,-1000,621,1000,88,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00011() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.time.FastDateFormat", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getDateTimeInstance(int,int,java.util.TimeZone):org.apache.commons.lang.time.FastDateFormat",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00012() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.time.FastDateFormat", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getDateTimeInstance(int,int,java.util.TimeZone):org.apache.commons.lang.time.FastDateFormat",
            new int[]{669,-834,-348,277,-586,-1000,-1000,-560,1000,-633,-440,1000,-1000,323,-1000,1000,-238,-1000,161,-525,-1000,1000,-330,-605,-953,-585,-86,-661,-406,-85,430,-1000,-423,1000,-108,39,-233,-707,812,-441,-961,1000,-64,-874,-280,1000,610,19,44,31,39,-717,56,-123,847,-1000,709,777,557,-233,-568,698,-359,321}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00013() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.time.FastDateFormat", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getDateTimeInstance(int,int,java.util.TimeZone,java.util.Locale):org.apache.commons.lang.time.FastDateFormat",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00014() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.time.FastDateFormat", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getDateTimeInstance(int,int,java.util.TimeZone,java.util.Locale):org.apache.commons.lang.time.FastDateFormat",
            new int[]{882,708,-1000,793,-406,-1000,-800,-436,-883,-1000,548,-532,-719,-1000,-1000,-714,-374,-1000,-808,299,-140,1000,-1000,637,1000,-1000,1000,-1000,-1000,1000,1000,-330,-117,723,969,-582,-866,1000,-751,1000,1000,1000,-1000,-336,-1000,-225,1000,559,1000,258,1000,605,608,27,-437,159,1000,-1000,23,300,-832,660,1000,616}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00015() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.time.FastDateFormat", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getInstance():org.apache.commons.lang.time.FastDateFormat",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00016() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.time.FastDateFormat", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getInstance(java.lang.String):org.apache.commons.lang.time.FastDateFormat",
            new int[]{30,-107,-677,158,-1000,-929,-656,213,488,-350,1000,430,-362,1000,13,17,391,-225,-864,1000,-1000,265,-232,-547,-1000,1,68,552,732,-825,-815,405,-553,85,-1000,-393,-662,72,-474,-531,-502,-1000,-1000,306,91,926,647,961,876,1000,-656,-409,-1000,468,965,92,168,457,1000,261,-1000,-156,-448,166}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00017() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.time.FastDateFormat", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getInstance(java.lang.String):org.apache.commons.lang.time.FastDateFormat",
            new int[]{-915,-632,-164,-373,-313,1000,1000,1000,274,-318,-1000,-1000,981,1000,-370,1000,-690,-5,1000,653,1000,-704,-829,683,1000,225,-1000,1000,-617,-1000,-896,-946,-211,1000,1000,585,752,-346,-669,1000,520,1000,1000,400,-231,-1000,1000,359,-291,-428,850,970,1000,-1000,594,637,1000,382,-1000,-1000,1000,1000,1000,-209}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00018() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getInstance(java.lang.String):org.apache.commons.lang.time.FastDateFormat",
            new int[]{-194,-1000,-1000,174,-387,727,261,449,1000,-1000,-1000,-1000,1000,1000,-712,1000,-997,-436,1000,1000,1000,-736,-910,809,1000,-97,-321,1000,-188,-1000,-599,-798,-1000,706,739,252,617,-665,-795,558,-525,1000,981,-20,-368,-660,1000,446,268,972,662,-16,912,-851,619,1,1000,1000,-1000,-1000,255,664,1000,-793}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00019() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getInstance(java.lang.String):org.apache.commons.lang.time.FastDateFormat",
            new int[]{-529,826,1000,-6,-462,-297,-1000,1000,-1000,953,701,-290,536,1000,691,368,-1000,73,-1000,-331,-378,493,46,-765,-888,-467,-1000,-1000,1000,47,-766,-262,-570,669,1000,-132,-958,1000,1000,-1000,991,-885,-477,-1000,-1000,-1000,1000,1000,644,-1000,271,-378,688,-452,739,1000,743,-1000,745,-1000,342,1000,-635,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00020() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.time.FastDateFormat", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getInstance(java.lang.String):org.apache.commons.lang.time.FastDateFormat",
            new int[]{109,-1000,904,-798,771,1000,1000,819,1000,-249,-1000,-1000,1000,655,-581,1000,-527,-1000,1000,61,1000,-1000,-56,753,1000,1000,-1000,374,-1000,-1000,-181,-1000,-405,1000,1000,1000,1000,224,-731,1000,1000,1000,1000,-875,-1000,-591,-1000,139,-1000,-1000,1000,1000,1000,-1000,-111,957,1000,-1000,-1000,-1000,1000,1000,1000,385}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00021() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.time.FastDateFormat", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getInstance(java.lang.String):org.apache.commons.lang.time.FastDateFormat",
            new int[]{76,851,-28,-684,138,330,-745,957,-866,-23,857,771,351,-179,589,-151,61,-63,314,-546,272,51,-174,-465,-371,90,85,617,782,-772,-137,950,464,-827,-78,-662,-749,904,745,-995,-493,927,-470,-942,377,-823,-352,-378,-128,175,-858,573,27,-243,-94,-60,-43,-221,195,515,-801,542,-168,-31}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00022() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getInstance(java.lang.String):org.apache.commons.lang.time.FastDateFormat",
            new int[]{-898,-284,368,-742,105,1000,-584,446,-1000,259,-485,-1000,1000,655,658,1000,247,-463,-64,-1000,-193,861,-380,-173,-321,915,-941,-251,974,-1000,-1000,-414,-714,1000,1000,425,-431,524,400,-225,-1000,74,-436,212,-1000,257,1000,1000,-607,-980,-777,124,1000,-665,1000,1000,949,-1000,-704,-765,613,956,635,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00023() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.time.FastDateFormat", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getInstance(java.lang.String):org.apache.commons.lang.time.FastDateFormat",
            new int[]{-529,450,749,4,-811,-525,-1000,-417,-1000,925,701,430,663,644,612,498,-862,-345,-915,-531,-585,577,336,-813,-625,-126,449,-1000,1000,198,-98,-283,-665,0,605,-132,-1000,1000,-426,-1000,1000,-1000,-477,-1000,-1000,-790,1000,1000,969,-933,-114,-1000,0,-452,841,1000,423,-1000,921,-542,-36,872,-775,944}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00024() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getInstance(java.lang.String):org.apache.commons.lang.time.FastDateFormat",
            new int[]{445,419,562,-868,-173,514,-970,1000,488,739,1000,-1000,-130,811,353,342,1000,-64,747,530,-723,576,-461,420,-305,430,-810,-144,-1000,-1000,-491,50,-495,955,-199,-36,-277,183,-50,-1000,1000,736,538,-532,-1000,-252,-20,1000,-1000,-410,538,-469,1000,-207,109,1000,499,-322,-104,-55,224,986,-285,265}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00025() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getInstance(java.lang.String):org.apache.commons.lang.time.FastDateFormat",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00026() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.time.FastDateFormat", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getInstance(java.lang.String):org.apache.commons.lang.time.FastDateFormat",
            new int[]{-407,-1000,420,-700,851,1000,-377,875,-1000,1000,-204,-1000,1000,1000,492,1000,-1000,-418,-600,-1000,1000,1000,581,-699,1000,978,-711,-9,1000,-1000,-902,-396,-741,1000,880,-228,62,972,-504,-571,1000,1000,407,-1000,-1000,-1000,805,1000,-377,-1000,-207,-774,1000,-1000,261,1000,709,-1000,-238,-955,1000,1000,-83,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00027() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.time.FastDateFormat", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getInstance(java.lang.String):org.apache.commons.lang.time.FastDateFormat",
            new int[]{463,-825,647,-769,1000,1000,1000,562,488,803,-1000,-1000,1000,1000,335,1000,-1000,-735,1000,-1000,1000,103,-121,663,1000,1000,-1000,334,-24,-1000,-219,-1000,-474,1000,1000,691,860,228,-385,330,1000,1000,1000,-687,-1000,-316,-983,372,-612,-1000,892,92,1000,-1000,199,1000,1000,-1000,-1000,-1000,1000,1000,1000,536}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00028() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getInstance(java.lang.String):org.apache.commons.lang.time.FastDateFormat",
            new int[]{-529,1000,1000,404,678,1000,-39,870,-1000,564,-699,430,663,1000,1000,498,-862,-312,-864,1000,988,44,-883,357,165,-849,-1000,-1000,838,-825,-429,-815,-349,560,1000,320,-1000,72,626,-531,1000,401,-477,-497,-1000,-1000,1000,579,1000,-1000,888,368,1000,-491,841,746,1000,-1000,-510,-1000,-36,1000,765,683}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00029() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getInstance(java.lang.String):org.apache.commons.lang.time.FastDateFormat",
            new int[]{-529,321,-12,-6,-222,-78,1000,543,-1000,-149,-157,187,-400,81,-185,-400,-1000,-739,520,541,-400,-527,-639,240,-400,560,-768,306,-748,-516,-570,-407,696,537,-175,539,367,-267,-674,1000,664,-400,34,-20,440,1000,-1000,438,-54,-567,271,1000,-312,-486,911,746,-51,325,-1000,-1000,345,527,619,126}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00030() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getInstance(java.lang.String,java.util.Locale):org.apache.commons.lang.time.FastDateFormat",
            new int[]{159,-1000,-810,-12,-236,-406,-315,1000,348,-68,1000,-824,659,629,-1000,557,-293,619,1000,-30,-179,-400,570,-1000,-738,-482,-400,-376,71,502,-400,591,-1000,154,392,427,1000,-759,-23,783,-622,372,-384,-1000,1000,1000,-298,377,171,254,-883,-59,1000,-120,-242,429,988,169,-396,221,673,-1000,279,164}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00031() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.time.FastDateFormat", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getInstance(java.lang.String,java.util.Locale):org.apache.commons.lang.time.FastDateFormat",
            new int[]{-276,-908,-1000,-918,-73,1000,-290,521,-1000,-950,-604,108,352,112,-464,145,-779,-1000,-411,-629,565,1000,162,598,457,45,886,-192,1000,-796,1000,848,-580,1000,-158,1000,428,230,-47,809,268,-144,935,-347,-321,-36,-863,-400,-298,-307,282,-740,-204,572,563,495,8,-1000,435,-845,-546,-225,108,-144}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00032() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.time.FastDateFormat", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getInstance(java.lang.String,java.util.Locale):org.apache.commons.lang.time.FastDateFormat",
            new int[]{-529,-1000,-1000,403,-54,358,-697,-1000,-671,-839,-1000,-1000,-484,478,673,-543,-687,-22,-614,15,973,-1000,1000,1000,1000,579,1000,944,1000,780,668,1000,1000,986,-1000,-673,-1000,-684,240,-749,1000,405,1000,714,-1000,-421,1000,-999,-1000,646,1000,686,-1000,-1000,-763,-694,-866,529,1000,-892,0,1000,-18,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00033() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getInstance(java.lang.String,java.util.Locale):org.apache.commons.lang.time.FastDateFormat",
            new int[]{159,-1000,854,-507,-555,347,431,1000,1000,398,1000,-67,-242,1000,-1000,698,1000,-102,774,121,488,-365,-820,-1000,-1000,-530,-1000,-318,196,-698,840,310,-730,-100,1000,1000,1000,11,-764,-350,-1000,372,-644,-1000,1000,570,-740,377,1000,456,-217,-1000,1000,1000,777,429,-145,68,-1000,221,237,-1000,895,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00034() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.time.FastDateFormat", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getInstance(java.lang.String,java.util.Locale):org.apache.commons.lang.time.FastDateFormat",
            new int[]{-327,14,-1000,661,-319,1000,-905,415,-30,630,-178,-133,931,254,-317,152,-564,-600,-321,-773,584,1000,-589,229,777,437,437,79,-400,29,-83,-374,135,700,-43,-887,433,-37,-271,1000,-20,652,-110,709,309,-85,421,220,-1000,-49,1000,1000,-624,802,82,1000,-977,-593,734,-1000,-899,-311,490,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00035() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getInstance(java.lang.String,java.util.Locale):org.apache.commons.lang.time.FastDateFormat",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00036() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getInstance(java.lang.String,java.util.Locale):org.apache.commons.lang.time.FastDateFormat",
            new int[]{478,856,-23,934,338,1000,-1000,298,-1000,1000,623,933,336,1000,-1000,694,-297,482,-33,578,-724,1000,-1000,214,384,-775,-371,-1000,1000,-835,-5,658,113,916,439,94,-808,1000,-1000,1000,-1000,-5,-814,-795,795,194,-1000,797,-177,-983,825,-846,-450,61,858,-788,-365,-1000,-559,-116,-756,-676,-197,-984}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00037() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.time.FastDateFormat", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getInstance(java.lang.String,java.util.Locale):org.apache.commons.lang.time.FastDateFormat",
            new int[]{-71,-154,917,-21,-848,1000,1000,718,-95,-20,781,-352,-350,1000,-575,1000,534,258,744,423,713,1000,-396,-1000,149,-855,101,300,243,-402,154,-374,1000,259,808,61,248,-210,-1000,-486,-245,194,240,-644,488,431,-462,316,413,341,635,521,631,295,-1000,-172,-1000,-725,-1000,-162,631,-30,559,-503}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00038() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getInstance(java.lang.String,java.util.Locale):org.apache.commons.lang.time.FastDateFormat",
            new int[]{429,329,121,417,917,499,-901,-550,-259,-189,700,-276,836,-465,-689,742,-436,1000,-104,-52,-198,-353,582,-130,-864,979,276,618,534,-475,821,765,553,-756,-84,-46,147,49,-791,937,569,-902,272,38,851,-537,-482,178,80,-83,182,586,115,756,863,432,443,-323,-234,171,-139,91,-387,-207}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00039() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.time.FastDateFormat", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getInstance(java.lang.String,java.util.Locale):org.apache.commons.lang.time.FastDateFormat",
            new int[]{-145,-874,-886,-698,-1000,-1000,-725,-537,624,-818,-1000,-562,830,1000,-1000,-1000,-494,555,-401,1000,1000,-1000,374,1000,1000,276,-749,116,674,-735,-209,886,1000,-524,-1000,-293,-1000,-1000,1000,566,282,1000,1000,-625,-244,-148,-434,-49,1000,673,-923,1000,-1000,-473,1000,201,1000,1000,994,1000,-1000,1000,-1000,-204}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00040() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.time.FastDateFormat", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getInstance(java.lang.String,java.util.Locale):org.apache.commons.lang.time.FastDateFormat",
            new int[]{159,-617,-631,176,-236,77,-301,1000,190,92,1000,-427,659,629,-1000,709,-293,1000,1000,377,87,816,-994,-855,-738,-454,-388,-428,-51,530,-322,446,-738,325,601,349,1000,-416,-358,783,-457,375,-1000,-1000,896,-58,-236,-198,-34,375,-382,-59,768,1000,-242,1000,988,316,-603,-160,99,-1000,421,-235}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00041() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.time.FastDateFormat", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getInstance(java.lang.String,java.util.TimeZone):org.apache.commons.lang.time.FastDateFormat",
            new int[]{365,-200,36,856,284,-72,-566,-214,626,-600,400,-541,-1000,133,-495,415,-364,-833,524,-629,-356,-960,-1000,-383,397,-319,-284,341,-440,-286,-142,-10,1000,1000,103,1000,744,-357,238,184,-386,127,106,173,-519,-629,-449,137,1000,315,-413,-472,-244,511,363,-786,453,4,-947,-901,-415,-1000,268,274}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00042() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getInstance(java.lang.String,java.util.TimeZone):org.apache.commons.lang.time.FastDateFormat",
            new int[]{126,-1000,-111,295,454,571,-835,1000,84,1000,-620,-504,587,-400,-1000,704,-195,549,-360,-38,400,275,1000,-241,669,-99,-1000,84,-332,-474,-657,-974,29,-1000,631,1000,-793,-1000,1000,-426,-1000,-313,-841,425,-225,129,364,-469,509,-63,26,-506,678,-400,221,601,-97,1000,1000,-1000,217,3,-1000,71}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00043() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.time.FastDateFormat", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getInstance(java.lang.String,java.util.TimeZone):org.apache.commons.lang.time.FastDateFormat",
            new int[]{-436,662,1000,-707,-1000,-204,-1000,-418,-95,-996,-387,-435,585,-256,-1000,625,735,898,-177,1000,-449,-915,-688,-536,-134,876,82,-999,-470,308,904,296,-857,-694,-796,-1000,-193,-1,549,-187,-75,678,105,-420,213,-241,-336,-38,-223,402,164,-1000,321,779,20,-282,1000,-61,-338,704,804,1000,267,-125}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00044() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getInstance(java.lang.String,java.util.TimeZone):org.apache.commons.lang.time.FastDateFormat",
            new int[]{46,-1000,-55,260,-31,390,888,-519,466,1000,-337,-1000,400,-744,-998,25,-83,-681,548,-10,-277,616,1000,113,151,-608,-395,-882,-455,-1000,-941,-1000,33,-636,-373,1000,-574,-1000,284,-1000,-1000,1000,-165,498,-1000,-697,-1000,364,608,-1000,1000,-758,-1000,725,-634,736,555,-1000,1000,-137,693,256,316,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00045() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.time.FastDateFormat", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getInstance(java.lang.String,java.util.TimeZone):org.apache.commons.lang.time.FastDateFormat",
            new int[]{701,-521,-493,-449,34,-1000,-819,636,878,832,-247,930,-95,-1000,-643,-1000,-336,77,-457,-643,239,-625,-847,-101,-169,351,-312,-1000,-271,-176,307,260,897,-154,336,389,651,1000,1000,662,-306,-261,-43,277,102,433,502,651,-494,1000,-876,531,-511,785,110,-673,256,854,-959,-1000,-258,1000,-1000,-724}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00046() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getInstance(java.lang.String,java.util.TimeZone):org.apache.commons.lang.time.FastDateFormat",
            new int[]{-418,-487,-1000,-431,-1000,-301,-739,-1000,236,1000,-1000,816,1000,-1000,1000,-1000,1000,-888,-1000,-284,1000,1000,1000,801,1000,-624,-912,-1000,1000,1000,-1000,-967,-1000,234,309,-1000,-124,1000,-385,-505,-718,-141,-352,195,1000,813,14,-1000,-1000,-1000,1000,359,471,-244,518,-838,271,-783,1000,-608,389,1000,-19,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00047() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getInstance(java.lang.String,java.util.TimeZone):org.apache.commons.lang.time.FastDateFormat",
            new int[]{-850,996,462,168,-1000,206,-51,-1000,-1000,515,-948,-864,42,-757,10,1000,955,925,-412,246,-268,530,1000,1000,665,203,-317,-531,906,376,-999,-1000,532,442,1000,397,-1000,-659,-1000,-1000,-873,113,-88,-154,-218,-1000,-625,-1000,1000,-880,1000,-770,924,-81,-540,-326,609,-1000,1000,262,418,-74,-53,-32}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00048() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.time.FastDateFormat", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getInstance(java.lang.String,java.util.TimeZone):org.apache.commons.lang.time.FastDateFormat",
            new int[]{-551,0,1000,703,-525,1000,-1000,90,-1000,1000,-1000,-1000,1000,-1000,-614,1000,1000,251,-1000,137,-1000,1000,1000,-555,1000,339,-1000,-973,813,-251,-1000,-1000,423,-1000,1000,1000,-1000,-1000,-183,-1000,-1000,-787,-1000,1000,-116,-736,38,-1000,1000,-273,950,-1000,729,-1000,-658,829,6,827,1000,-223,403,-575,399,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00049() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getInstance(java.lang.String,java.util.TimeZone):org.apache.commons.lang.time.FastDateFormat",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00050() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getInstance(java.lang.String,java.util.TimeZone):org.apache.commons.lang.time.FastDateFormat",
            new int[]{-961,-966,685,8,-394,-492,1000,1000,-73,-1000,607,246,-1000,1000,-1000,-872,-928,-1000,822,1000,-1000,-1000,-1000,884,-1000,1000,1000,1000,-952,-761,-205,1000,1000,1000,146,-539,-568,666,-1000,-1000,435,-62,699,-1000,-1000,-1000,1000,1000,1000,1000,-1000,-361,97,1000,-461,739,453,1000,-1000,-379,804,-1000,446,-888}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00051() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.time.FastDateFormat", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getInstance(java.lang.String,java.util.TimeZone):org.apache.commons.lang.time.FastDateFormat",
            new int[]{-961,-50,1000,476,-1000,558,1000,785,-1000,48,388,132,758,1000,-1000,-1000,-834,-1000,-683,1000,-1000,-488,-1000,1000,-1000,693,1000,1000,-645,691,356,861,-1000,482,-157,-652,-1000,1000,-1000,-1000,599,-451,478,-1000,-1000,-1000,1000,1000,1000,1000,-303,-361,-1000,890,-1000,910,600,1000,-921,231,1000,-668,866,-955}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00052() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.time.FastDateFormat", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getInstance(java.lang.String,java.util.TimeZone,java.util.Locale):org.apache.commons.lang.time.FastDateFormat",
            new int[]{366,1000,-299,-759,-1000,-1000,993,-1000,1000,-746,-933,1000,1000,-1000,1000,-313,-281,1000,-1000,-1000,839,-371,-251,578,-797,-1000,1000,960,-1000,1000,967,1000,-1000,1000,-1000,-1000,987,-1000,-1000,-766,1000,953,-1000,-607,-792,1000,-556,800,283,901,-596,475,957,776,-463,-1000,805,10,442,-1000,-384,-1000,797,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00053() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.time.FastDateFormat", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getInstance(java.lang.String,java.util.TimeZone,java.util.Locale):org.apache.commons.lang.time.FastDateFormat",
            new int[]{537,1000,-350,-1000,-700,-500,993,-1000,1000,400,-1000,849,1000,1000,-66,-1000,385,1000,-1000,-928,253,-1000,175,-301,-1000,-1000,652,1000,-1000,1000,386,1000,-1000,1000,-1000,-1000,269,-822,-1000,-264,1000,1000,-1000,-933,705,400,-1000,647,283,1000,-694,433,1000,580,1000,-1000,1000,274,134,-682,-475,-1000,626,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00054() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getInstance(java.lang.String,java.util.TimeZone,java.util.Locale):org.apache.commons.lang.time.FastDateFormat",
            new int[]{-930,427,-1000,-407,-520,-571,-325,-289,1000,-984,-174,-4,-516,400,810,9,-608,-326,-781,931,169,301,435,-614,-883,-1000,157,506,-74,-107,-132,30,-957,-456,999,-477,670,482,318,-762,-471,1000,-634,56,552,63,-388,-762,446,135,-1000,-387,-118,-624,-859,103,-256,777,743,-1000,-1000,-397,-417,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00055() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.time.FastDateFormat", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getInstance(java.lang.String,java.util.TimeZone,java.util.Locale):org.apache.commons.lang.time.FastDateFormat",
            new int[]{-292,-851,-252,-156,299,-128,671,-375,-415,316,-319,881,-237,-60,-248,-280,765,-454,386,434,-815,-655,-201,201,336,-975,-740,382,-964,22,-912,-486,814,-637,-332,185,-811,-127,-604,325,459,-644,917,-875,954,-578,-775,815,-842,-959,253,-190,240,611,411,375,-398,-638,226,869,811,260,698,895}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00056() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getInstance(java.lang.String,java.util.TimeZone,java.util.Locale):org.apache.commons.lang.time.FastDateFormat",
            new int[]{542,948,222,-168,-534,-147,990,124,-967,-551,809,-76,976,-844,322,308,33,917,356,478,-582,-932,-732,-786,-103,988,-342,-272,95,-693,-945,603,-196,-420,980,542,26,812,-644,-955,-804,-20,702,771,677,-204,738,391,-84,-639,-911,995,933,51,-388,770,759,23,566,-426,-706,61,285,-706}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00057() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getInstance(java.lang.String,java.util.TimeZone,java.util.Locale):org.apache.commons.lang.time.FastDateFormat",
            new int[]{270,-435,-464,-78,571,372,1000,293,-1000,978,-12,-229,389,-1000,-785,-825,1000,25,1000,-391,-1000,-1000,-193,-107,-501,-504,-1000,-65,150,-1000,-1000,-235,332,-140,552,1000,-883,-554,-883,-58,-813,-1000,901,127,1000,-519,-27,576,-1000,1000,-513,878,-144,720,847,1000,909,-341,-180,545,41,-837,757,380}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00058() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getInstance(java.lang.String,java.util.TimeZone,java.util.Locale):org.apache.commons.lang.time.FastDateFormat",
            new int[]{-786,249,617,540,79,750,379,517,439,-614,638,-294,-618,143,367,781,-422,646,134,-572,897,-28,-943,281,776,470,86,141,-679,432,56,762,270,644,-245,-475,-141,276,837,-307,428,355,844,630,154,178,810,347,681,-632,-11,70,646,51,-930,-900,-945,-390,932,223,342,839,456,-877}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00059() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getInstance(java.lang.String,java.util.TimeZone,java.util.Locale):org.apache.commons.lang.time.FastDateFormat",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00060() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.time.FastDateFormat", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getInstance(java.lang.String,java.util.TimeZone,java.util.Locale):org.apache.commons.lang.time.FastDateFormat",
            new int[]{537,-50,724,9,944,1000,379,294,-961,400,166,-333,-190,-658,-66,-400,126,1000,1000,-884,897,-1000,-1000,133,1000,817,-311,-605,-1000,432,-490,445,313,1000,-559,-475,-1000,520,442,-9,-347,61,1000,18,554,-885,751,799,509,440,277,631,-155,319,-126,-900,-134,274,619,825,-475,954,433,89}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00061() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.time.FastDateFormat", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getInstance(java.lang.String,java.util.TimeZone,java.util.Locale):org.apache.commons.lang.time.FastDateFormat",
            new int[]{537,426,131,-149,-1000,-500,485,-370,1000,-676,487,-168,735,-416,369,-290,-332,330,66,-928,-1000,219,322,642,-1000,29,-89,224,387,160,124,1000,211,66,-1000,1000,251,-1000,-929,691,904,-580,-7,231,1000,161,-765,336,-948,680,-293,20,-218,654,1000,71,803,521,331,1000,-475,-1000,580,-213}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00062() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getInstance(java.lang.String,java.util.TimeZone,java.util.Locale):org.apache.commons.lang.time.FastDateFormat",
            new int[]{109,422,222,-168,-226,-1000,-1000,-1000,1000,-153,-1000,957,976,1000,439,-716,-312,-1000,356,478,396,-1000,1000,-145,-737,988,400,-239,1000,1000,1000,-1000,656,318,980,542,524,-1000,-943,1000,551,1000,-1000,-1000,-1000,-345,-1000,-1000,1000,611,-368,-640,154,-1000,1000,-93,582,490,-1000,597,-267,325,285,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00063() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.time.FastDateFormat", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getInstance(java.lang.String,java.util.TimeZone,java.util.Locale):org.apache.commons.lang.time.FastDateFormat",
            new int[]{-606,427,-557,-407,-436,451,-1000,-289,-64,-1000,1000,-622,-1000,400,1000,9,-1000,-1000,-766,1000,693,1000,905,-1000,-801,-1000,355,506,161,-107,-135,-512,963,-723,1000,-477,679,1000,1000,-511,-1000,-1000,-404,9,758,-917,-388,-1000,947,97,-1000,-1000,-1000,-1000,-1000,103,-939,1000,-547,177,-1000,528,-1000,-804}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00064() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getInstance(java.lang.String,java.util.TimeZone,java.util.Locale):org.apache.commons.lang.time.FastDateFormat",
            new int[]{-81,-227,380,336,152,977,-189,588,983,346,148,-647,394,-44,-988,561,-607,75,14,398,-297,-755,-475,-282,-215,-546,-832,771,67,383,-111,179,406,-71,-759,-857,749,-398,140,230,-281,-786,734,-232,-573,-646,-700,-106,198,530,-918,569,82,596,-138,-469,-945,-923,-285,-948,610,379,-119,648}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00065() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getInstance(java.lang.String,java.util.TimeZone,java.util.Locale):org.apache.commons.lang.time.FastDateFormat",
            new int[]{-258,135,-1000,238,256,100,-643,793,1000,1000,-488,1000,1000,-1000,-1000,-284,485,1000,1000,-344,-990,-1000,-1000,1000,-204,-541,-1000,539,-979,1000,-497,1000,-1000,1000,-1000,541,-1000,-1000,-1000,117,1000,921,-1000,-776,-957,-1000,890,1000,-1000,1000,1000,1000,576,-621,-142,-1000,-7,-244,243,-654,1000,25,1000,400}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00066() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getInstance(java.lang.String,java.util.TimeZone,java.util.Locale):org.apache.commons.lang.time.FastDateFormat",
            new int[]{-322,233,-872,186,306,-470,-883,140,1000,-1000,281,115,664,1000,961,-70,-463,-416,-1000,1000,-334,-449,-838,333,-854,-78,652,1000,-752,-121,-427,-1000,500,146,987,-383,432,-386,-486,-170,-1000,1000,-546,-1000,-716,310,-586,-520,283,429,-1000,-8,257,-424,400,914,141,1000,904,-532,-1000,-89,432,-51}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00067() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.time.FastDateFormat", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getTimeInstance(int):org.apache.commons.lang.time.FastDateFormat",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00068() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.time.FastDateFormat", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getTimeInstance(int):org.apache.commons.lang.time.FastDateFormat",
            new int[]{986,-779,233,326,510,224,142,239,87,382,876,929,-463,845,-913,-759,55,74,930,632,-812,737,266,-701,869,-246,-528,336,843,987,-609,-584,-114,322,650,583,960,-647,752,941,-329,282,166,246,212,-804,-33,-295,-631,-552,-510,-343,-919,-480,933,229,-429,443,881,546,106,627,308,623}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00069() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.time.FastDateFormat", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getTimeInstance(int,java.util.Locale):org.apache.commons.lang.time.FastDateFormat",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00070() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.time.FastDateFormat", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getTimeInstance(int,java.util.Locale):org.apache.commons.lang.time.FastDateFormat",
            new int[]{-707,445,471,43,-1000,-946,512,-1000,1000,-637,58,-439,7,250,-893,448,-1000,-925,-349,837,-364,-597,704,-402,149,-799,1000,-314,-1000,1000,354,-190,465,-193,85,33,-1000,-563,-716,-210,1000,-229,773,901,567,72,194,1000,891,-911,1000,400,-286,-437,-1000,-365,-965,-564,-1000,1000,-1000,-686,1000,46}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00071() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.time.FastDateFormat", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getTimeInstance(int,java.util.TimeZone):org.apache.commons.lang.time.FastDateFormat",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00072() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.time.FastDateFormat", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getTimeInstance(int,java.util.TimeZone):org.apache.commons.lang.time.FastDateFormat",
            new int[]{527,-599,-458,-471,92,-264,-225,-836,-236,-566,-42,12,312,-527,797,-267,714,830,-967,-630,-832,-491,-480,-746,915,267,-253,-745,378,736,788,685,268,-438,432,770,-913,94,467,-611,756,-790,-998,-444,-10,931,63,-11,458,619,719,29,-206,-245,482,156,67,-431,849,-581,458,132,518,171}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00073() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.time.FastDateFormat", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getTimeInstance(int,java.util.TimeZone,java.util.Locale):org.apache.commons.lang.time.FastDateFormat",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00074() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.time.FastDateFormat", DEReplay.run(
            "org.apache.commons.lang.time.FastDateFormat", "", "getTimeInstance(int,java.util.TimeZone,java.util.Locale):org.apache.commons.lang.time.FastDateFormat",
            new int[]{391,697,-691,376,-108,220,941,547,993,440,-801,931,588,-804,-752,272,570,704,500,-544,26,32,544,213,-173,801,-953,-881,-444,-807,129,399,-591,-100,798,262,-314,59,426,-456,-203,-618,-34,294,-665,721,-362,-407,-304,-872,139,374,-38,-896,-906,318,-667,-831,-574,-14,256,159,-416,278}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00076() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(java.util.Date,java.lang.String):java.lang.String",
            new int[]{1000,79,-31,713,892,1000,-1000,1000,1000,-193,749,-1000,1000,1000,-1000,1000,-1000,-171,-254,-1000,-779,865,-504,-1000,-1000,370,596,-1000,-10,-1,-1000,1000,1000,-1000,-954,-1000,-1000,-1000,26,1000,88,1000,915,-617,-1000,-32,-242,-1000,872,1000,1000,1000,210,1000,1000,1000,-1000,1000,-212,968,1000,-496,-1000,750}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00077() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(java.util.Date,java.lang.String):java.lang.String",
            new int[]{-246,-35,-232,994,193,816,-771,912,1000,-572,-277,-393,-585,976,-1000,-1000,-848,415,-1000,387,-832,1,-303,23,-1000,-888,-674,-369,1000,-1000,-852,1000,670,819,-225,-634,256,823,514,-1000,272,-671,-883,-494,280,497,86,-61,1000,852,-552,-563,1000,1000,-786,-628,532,69,-431,1000,254,394,441,977}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00079() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(java.util.Date,java.lang.String):java.lang.String",
            new int[]{714,254,54,1000,521,-383,403,-1000,665,-1000,-1000,1000,-1000,-1000,1000,1000,-826,568,-1000,614,70,-14,-71,-919,1000,1000,-628,-1000,91,346,75,-1000,629,655,361,-1000,1000,1000,958,280,-865,-494,1000,-372,343,1000,646,516,100,-145,-810,1000,118,-466,-1000,-1000,815,615,-599,821,404,297,338,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00080() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(java.util.Date,java.lang.String):java.lang.String",
            new int[]{-1000,878,-512,256,712,1000,-1000,869,702,314,177,-1000,500,1000,-1000,742,-1000,1000,468,805,40,754,-377,-344,-1000,1000,-842,241,706,506,-718,1000,486,11,-696,-178,-763,-238,-229,-1000,-85,850,-32,-505,-684,-663,1000,-1000,25,1000,1000,-206,1000,734,-224,544,-610,451,-614,1000,682,-88,1000,426}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00081() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(java.util.Date,java.lang.String):java.lang.String",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00083() {
        org.junit.Assert.assertEquals("java.lang.String:MjIx", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(java.util.Date,java.lang.String):java.lang.String",
            new int[]{-1000,-327,22,1000,289,682,-146,883,811,648,331,-1000,-537,980,-626,1000,-453,870,380,-1000,936,-1000,-1000,425,-812,-1000,-388,979,66,-1000,-1000,621,962,-124,-970,94,71,585,-764,-26,797,-502,147,-668,-1000,-40,-400,-1000,117,859,1000,421,1000,486,-812,-866,45,419,721,1000,283,1000,222,885}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00084() {
        org.junit.Assert.assertEquals("java.lang.String:QURf", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(java.util.Date,java.lang.String):java.lang.String",
            new int[]{1000,478,-589,970,-223,823,-1000,883,588,763,-575,-132,490,-13,-1000,-349,-673,425,1000,400,630,-391,-465,4,-1000,400,-288,513,580,-332,-180,1000,557,568,-179,57,-623,-335,137,-995,-40,-188,-100,-618,145,-1000,-400,400,356,216,701,121,-181,621,29,348,45,421,-104,1000,545,-139,222,196}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00085() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(java.util.Date,java.lang.String):java.lang.String",
            new int[]{-224,478,-1000,431,-114,977,-1000,1000,588,-254,-515,-104,1000,-872,-1000,-312,-1000,-498,1000,-118,-1000,720,227,-74,-1000,-852,303,-585,-689,368,979,883,557,122,1000,-1000,-623,-732,828,790,-40,237,211,578,816,488,1000,1000,1000,-366,-1000,-290,38,737,-201,1000,1000,701,-1000,1000,730,101,1000,-932}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00086() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(java.util.Date,java.lang.String):java.lang.String",
            new int[]{-60,-19,-1000,629,874,1000,-1000,884,1000,1000,-337,-380,731,928,-1000,-289,-1000,1000,-1000,-1000,-962,1000,38,-734,-1000,512,-1000,303,1000,-4,-1000,709,1000,1000,-589,-503,-956,134,490,178,964,77,-627,-488,280,-295,773,95,1000,854,271,1000,262,1000,-832,128,-938,1000,-1000,1000,814,506,893,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00088() {
        org.junit.Assert.assertEquals("java.lang.String:XDY3Xwpf", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(java.util.Date,java.lang.String,java.util.Locale):java.lang.String",
            new int[]{-917,-467,982,-1000,355,352,-250,-1000,-214,-1000,-1000,1000,389,218,428,523,-400,102,-631,1000,-417,1000,1000,-729,83,-984,1000,-912,-222,400,-456,72,-699,742,-18,-764,-1000,1000,-664,-1000,-771,519,76,-1000,-18,1000,-1000,-400,109,1000,-1000,-1000,1000,-657,-933,-1000,777,-1000,-403,1000,-177,-1000,592,453}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00090() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(java.util.Date,java.lang.String,java.util.Locale):java.lang.String",
            new int[]{-440,-305,-1000,-273,-377,-1000,-206,990,461,-1000,-432,476,-241,-60,1000,751,141,-709,-209,509,400,129,619,627,72,-444,172,-119,843,-921,1000,-487,819,425,417,-131,-482,-1000,663,580,-82,194,-305,400,-162,-256,1000,-319,-947,762,422,50,29,-177,62,1000,-235,-945,652,562,-3,506,-220,827}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00091() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(java.util.Date,java.lang.String,java.util.Locale):java.lang.String",
            new int[]{658,670,316,1000,416,66,-218,1000,474,917,-1000,1000,182,-731,-1000,782,-554,-731,-781,-700,-660,-169,814,-1000,261,-1000,188,-2,1000,146,773,902,-815,165,248,-1000,35,-768,98,102,-90,576,210,285,-1000,-242,-586,-1000,-453,-1000,-374,-1000,128,249,-1000,1000,725,-1000,-1000,254,-1000,-1000,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00092() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(java.util.Date,java.lang.String,java.util.Locale):java.lang.String",
            new int[]{1000,670,1000,1000,-811,-409,888,1000,1000,1000,577,747,-163,475,-1000,-225,909,-1000,-692,-700,-407,-801,-169,600,261,-770,-223,618,364,-312,-1000,1000,576,-568,248,-1000,416,-1000,-820,1000,827,-823,520,376,-91,-566,-231,-293,-1000,-1000,284,-199,-655,375,-1000,1000,-651,-1000,78,115,-870,1000,-99,97}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00093() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(java.util.Date,java.lang.String,java.util.Locale):java.lang.String",
            new int[]{-1000,751,976,319,304,-546,-335,547,-785,-92,-1000,1000,1000,-1000,-1000,697,-1000,118,-1000,-853,1000,1000,1000,-7,-1000,-1000,1000,-1000,643,905,-214,714,1000,-29,374,-1000,-86,-962,-1000,-180,1000,921,-1000,1000,-881,1000,169,1000,-582,-833,-221,260,1000,-1000,-1000,558,1000,362,-1000,1000,-1000,-442,1000,931}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00094() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(java.util.Date,java.lang.String,java.util.Locale):java.lang.String",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00096() {
        org.junit.Assert.assertEquals("java.lang.String:NTE4NA==", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(java.util.Date,java.lang.String,java.util.Locale):java.lang.String",
            new int[]{1000,-423,518,1000,157,-366,-1000,684,584,0,1000,-607,-1000,548,-1000,0,0,-102,-1000,-340,395,-1000,-1000,391,685,1000,-967,1000,0,-1000,-270,930,0,1000,45,-1000,661,-268,-134,-292,-61,126,783,632,491,-793,486,764,-975,-227,1000,76,0,551,338,1000,-948,1000,746,-135,-317,1000,237,-467}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00097() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(java.util.Date,java.lang.String,java.util.Locale):java.lang.String",
            new int[]{608,-962,-260,82,-619,-167,-1000,1000,769,1000,165,-375,-642,-886,-537,380,275,-1000,145,-657,-1000,-1000,-1000,-652,-162,256,-1000,1000,162,345,-108,703,-597,-351,1000,-1000,501,-343,1000,1000,1000,-1000,-864,-1000,417,-431,-779,-441,-884,-1000,303,5,-808,580,-927,1000,-165,-834,-1000,-839,-620,189,-115,471}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00098() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(java.util.Date,java.lang.String,java.util.Locale):java.lang.String",
            new int[]{282,-482,-1000,-200,423,-1000,-155,722,704,-1000,-1000,1000,520,642,-216,1000,191,-1000,-906,-95,159,202,878,784,-465,-925,48,211,683,-986,522,-1000,479,6,730,-1000,3,-851,1000,880,-778,-100,-1000,-132,-427,-334,-235,-477,-1000,222,-401,-99,-406,-324,-896,1000,149,-1000,206,1000,-906,1000,138,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00100() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(java.util.Date,java.lang.String,java.util.TimeZone):java.lang.String",
            new int[]{1000,-195,-663,4,-757,1000,435,3,-817,431,-462,460,-284,164,539,-480,557,-240,1000,710,226,-274,-1000,-923,-106,-1000,420,-1000,1000,-1000,803,1000,-63,818,-1000,570,719,527,1000,1000,-767,530,-893,-487,1000,-1000,-1000,-400,1000,1000,-134,-341,291,1000,-1000,176,-209,101,-1000,305,139,-1000,1000,-383}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00101() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(java.util.Date,java.lang.String,java.util.TimeZone):java.lang.String",
            new int[]{6,-499,-1000,1000,173,611,-591,-170,1000,-962,550,195,292,-44,-232,-280,309,822,569,3,-328,1000,-482,781,-1000,-1000,671,1000,-163,-588,-1000,78,426,-1000,-34,-266,-740,417,410,145,-477,1000,1000,-1000,-78,-518,84,-571,-1000,-689,-177,693,977,86,28,177,343,-20,-1000,-607,-350,-325,-1000,860}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00102() {
        org.junit.Assert.assertEquals("java.lang.String:MzQ0Mg==", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(java.util.Date,java.lang.String,java.util.TimeZone):java.lang.String",
            new int[]{-265,441,344,760,-89,-789,-638,565,738,-21,955,710,743,37,-955,-280,-768,394,278,-733,-1000,1000,-394,1000,-1000,-1,-135,423,-1000,-118,-757,-721,1000,-1000,816,-1000,-1000,400,-818,-695,-1000,-400,973,-456,-975,8,967,-347,-1000,-933,-237,1000,1000,-1000,951,177,47,-1000,400,-1000,-704,637,-906,-22}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00103() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(java.util.Date,java.lang.String,java.util.TimeZone):java.lang.String",
            new int[]{150,590,148,609,-89,1000,1000,565,446,1000,-100,-322,752,37,574,1000,119,109,438,-556,466,1000,-1000,-37,-136,-1000,-59,1000,-673,-1000,190,-493,79,1000,1000,-277,-410,-1000,944,1000,-1000,1000,561,-591,-165,-494,-1000,-1000,950,1000,-237,-615,81,1000,951,1000,47,1000,-1000,187,-904,-480,-867,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00105() {
        org.junit.Assert.assertEquals("java.lang.String:IA==", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(java.util.Date,java.lang.String,java.util.TimeZone):java.lang.String",
            new int[]{495,-798,1000,-17,-1000,-179,-900,-845,1000,-798,-1000,-543,441,-1000,-397,-704,488,-223,-1000,678,391,418,1000,273,-578,-803,-1000,276,-226,-1000,-1000,-106,85,-1000,-540,534,1000,-482,-170,-981,-432,-1000,-182,278,622,374,1000,-487,-939,1000,-1000,1000,891,-619,950,-923,-386,1000,-1000,-549,-552,-1000,153,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00106() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(java.util.Date,java.lang.String,java.util.TimeZone):java.lang.String",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00108() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(java.util.Date,java.lang.String,java.util.TimeZone):java.lang.String",
            new int[]{-1000,-913,400,-139,130,-789,-656,-160,625,-962,182,1000,-132,-44,1000,-1000,-253,610,491,1000,-1000,1000,-118,-57,-834,-513,671,831,-28,-673,-1000,-770,79,-1000,1000,375,-1000,509,-882,-789,-173,20,-732,-894,727,104,-107,593,-1000,-692,-177,1000,1000,-1000,-666,-1000,1000,-50,259,-1000,-1000,-1000,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00110() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(java.util.Date,java.lang.String,java.util.TimeZone,java.util.Locale):java.lang.String",
            new int[]{-1000,-529,906,-1000,41,-349,603,416,275,-1000,172,-1000,-364,227,1000,-1000,1000,-1000,-682,-580,-954,-1000,520,495,-512,317,1000,-444,715,322,142,432,1000,123,-596,-325,-459,-514,-567,956,905,-1000,725,948,670,731,400,-189,580,1000,-1000,845,-20,-1000,-1000,126,-1000,-1000,-954,834,1000,1000,798,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00111() {
        org.junit.Assert.assertEquals("java.lang.String:LS00NDE0", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(java.util.Date,java.lang.String,java.util.TimeZone,java.util.Locale):java.lang.String",
            new int[]{-953,-663,-441,631,613,621,-633,864,574,-836,-470,268,-305,-181,-15,-664,349,100,-264,-736,221,861,-785,-208,-789,65,-811,-369,-815,3,904,-473,693,739,-332,734,-179,59,-891,434,-86,732,28,463,-905,-492,-117,593,-805,968,762,606,-978,-952,972,357,718,-110,259,162,374,-500,-871,956}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00112() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(java.util.Date,java.lang.String,java.util.TimeZone,java.util.Locale):java.lang.String",
            new int[]{937,-897,409,614,197,-141,-567,-321,632,-432,-475,1000,705,99,-658,1000,-715,1000,632,-668,525,1000,-823,94,144,-1000,-1000,-508,-1000,-536,-1000,-503,-200,684,-108,247,1000,-291,-442,-947,-367,1000,1000,566,-286,-44,-210,81,-1000,-845,1000,474,292,720,1000,496,874,1000,766,1000,595,-1000,4,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00113() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(java.util.Date,java.lang.String,java.util.TimeZone,java.util.Locale):java.lang.String",
            new int[]{-565,-225,942,-1000,-109,758,503,811,662,-687,633,-1000,-624,-495,272,-802,-837,-711,-850,-387,14,-756,-993,794,127,178,1000,343,-159,-1000,-951,699,1000,731,550,-16,483,515,-491,1000,384,-1000,363,-1000,851,-698,452,170,99,714,-525,-400,-84,-558,-1000,-108,-1000,-798,-267,-171,1000,988,244,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00115() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(java.util.Date,java.lang.String,java.util.TimeZone,java.util.Locale):java.lang.String",
            new int[]{-1000,-563,866,-773,-738,-409,376,623,976,-145,-622,-1000,87,174,829,-297,-63,-881,-1000,-215,-564,-378,188,1000,-328,851,1000,-70,-117,527,-761,186,1000,202,-140,314,-752,1000,14,876,284,-817,882,251,571,-44,-164,-54,281,873,-1000,724,-1000,-1000,-13,159,-1000,-702,-935,-247,1000,1000,474,-998}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00116() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(java.util.Date,java.lang.String,java.util.TimeZone,java.util.Locale):java.lang.String",
            new int[]{-869,-529,1000,1000,693,1000,-1000,943,-469,-1000,172,458,-37,-1000,-959,-20,-1000,-68,-25,-161,820,-98,-440,-854,-410,-1000,1000,784,-480,709,439,491,513,681,-913,-908,601,-514,313,-219,905,863,-1000,-380,-50,-99,333,-1000,-849,-832,-1000,622,-268,-198,-1000,1000,682,-68,-797,834,-130,-1000,162,619}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00117() {
        org.junit.Assert.assertEquals("java.lang.String:IA==", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(java.util.Date,java.lang.String,java.util.TimeZone,java.util.Locale):java.lang.String",
            new int[]{41,2,-527,-359,237,151,-717,12,605,-355,-708,879,24,578,92,-679,-280,986,-817,979,380,-630,-715,-517,-977,-808,77,509,632,777,866,-894,-987,-497,240,669,-630,-354,807,-325,-293,780,750,142,-702,253,-896,-337,202,951,440,824,91,262,940,-177,-529,-21,-289,192,-166,-266,653,-314}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00118() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(java.util.Date,java.lang.String,java.util.TimeZone,java.util.Locale):java.lang.String",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00120() {
        org.junit.Assert.assertEquals("java.lang.String:MA==", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(java.util.Date,java.lang.String,java.util.TimeZone,java.util.Locale):java.lang.String",
            new int[]{-616,15,-1000,242,826,-727,-703,743,-338,-1000,125,-590,135,-299,-192,-60,-1000,-535,1000,164,209,-1000,574,-1000,197,-345,235,443,88,-1000,1000,676,826,464,201,1000,733,413,1000,33,-1000,429,-139,-1000,-513,802,-1000,1000,1000,-1000,-1000,926,-1000,-1,-1000,285,694,-198,-343,823,449,-35,69,377}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00121() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(java.util.Date,java.lang.String,java.util.TimeZone,java.util.Locale):java.lang.String",
            new int[]{206,-545,-166,837,867,1000,-1000,430,-29,-1000,-633,-1000,803,-190,257,-695,-1000,888,1000,-160,444,-1000,-509,-1000,-91,-519,-1000,194,-385,-1000,-761,79,-449,1000,265,1000,1000,312,-1000,-666,-1000,1000,910,1000,-890,749,-1000,1000,-1000,-1000,-19,764,-883,333,-1000,116,915,513,-935,1000,-953,-142,-62,820}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00122() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(java.util.Date,java.lang.String,java.util.TimeZone,java.util.Locale):java.lang.String",
            new int[]{109,-338,-208,120,980,-439,721,-1000,1000,-834,-301,1000,522,710,1000,-277,400,-154,876,1000,494,1000,-556,825,86,209,-318,740,-901,-1000,-650,-223,-1000,-309,1000,519,52,-217,1000,-219,-1000,405,533,729,-596,1000,-1000,-438,1000,1000,1000,794,1000,1000,1000,-736,138,248,-1000,1000,813,-126,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00123() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(java.util.Date,java.lang.String,java.util.TimeZone,java.util.Locale):java.lang.String",
            new int[]{682,-435,1000,1000,311,401,-80,353,711,-432,287,1000,1000,-863,-1000,1000,-1000,1000,561,-837,180,1000,92,-1000,487,-1000,-215,447,-1000,-470,-457,105,-1000,684,-970,-333,1000,-291,411,-1000,-283,1000,-102,339,-286,-532,389,463,-1000,-1000,-701,158,-654,1000,188,1000,1000,1000,-127,1000,-813,-1000,-589,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00125() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(long,java.lang.String):java.lang.String",
            new int[]{-225,162,-83,42,432,-79,603,656,-431,-282,-290,71,-1000,-487,53,30,256,-292,687,639,192,-633,191,339,325,-93,-201,380,-388,286,404,1000,-56,118,603,453,129,329,481,712,792,-486,160,291,635,335,-473,-13,140,-376,839,-510,-692,406,-235,921,77,-674,544,411,-68,-540,349,-146}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00126() {
        org.junit.Assert.assertEquals("java.lang.String:LTMxMTMx", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(long,java.lang.String):java.lang.String",
            new int[]{-554,-877,-455,-311,153,-808,-789,-486,545,-382,939,-970,-342,507,523,65,-749,-216,849,-669,361,-311,574,497,-902,484,331,-919,-518,338,512,-826,-733,661,319,60,357,578,25,-961,706,673,-846,-52,-628,653,627,-824,803,165,849,377,354,642,164,-564,543,750,-847,795,614,790,-165,762}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00127() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(long,java.lang.String):java.lang.String",
            new int[]{-133,102,655,-140,-806,707,-200,-243,190,-282,108,-960,-304,855,-932,-137,-219,-405,687,590,855,-250,-533,774,189,-93,600,-255,947,-776,196,846,-75,-612,50,-576,906,966,639,-97,792,-221,-149,-533,-521,523,-719,-801,-191,371,839,-128,912,965,-112,-978,694,924,-844,411,-656,726,277,546}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00129() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(long,java.lang.String):java.lang.String",
            new int[]{39,832,-17,421,96,270,642,1000,-1000,472,-656,725,-916,524,751,-782,-1000,100,-148,301,-590,-1000,-61,223,-244,-967,1000,8,448,283,-805,863,-322,-799,914,-62,-338,-1000,-9,-819,1000,-917,636,-182,881,-648,-364,-151,-252,257,-853,-273,539,-115,-174,1000,-292,1000,799,449,-1000,-1000,67,-188}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00130() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(long,java.lang.String):java.lang.String",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00132() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(long,java.lang.String):java.lang.String",
            new int[]{-417,-1000,-3,-312,269,309,-333,-338,255,426,-623,366,-49,483,-270,321,1000,-269,-70,-852,437,519,710,-541,755,586,1000,380,-430,-177,-651,626,-976,919,722,-24,148,463,153,88,1000,-547,-173,506,-252,609,777,611,1000,-724,-1000,-704,644,-305,870,152,-798,613,348,-1000,-183,204,-6,805}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00134() {
        org.junit.Assert.assertEquals("java.lang.String:UE0=", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(long,java.lang.String):java.lang.String",
            new int[]{-696,615,-68,991,-746,549,-428,473,-374,768,-273,703,60,884,-816,-912,796,357,-432,-764,-857,-843,-215,-907,-914,-409,-308,548,205,369,890,-920,-843,-729,-811,140,-287,201,512,147,-461,-157,-196,185,-219,680,826,-182,841,683,-334,779,700,-349,226,-279,645,-130,7,-294,-701,535,-901,-349}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00135() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(long,java.lang.String):java.lang.String",
            new int[]{-808,-366,-578,874,757,-446,-353,458,615,-5,-148,-596,378,-909,-21,182,-603,880,217,262,518,447,-889,-981,557,919,-772,-859,-593,380,551,687,-142,-873,-559,986,-140,59,-788,-194,237,-533,-841,398,-344,7,212,-623,-950,191,-676,-289,-380,-580,-874,-439,45,243,468,-855,-395,334,-981,419}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00137() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(long,java.lang.String,java.util.Locale):java.lang.String",
            new int[]{1000,897,-641,250,1000,885,1000,1000,1000,742,1000,872,-609,189,-640,-192,-1000,439,-1000,373,937,1000,-1000,173,1000,1000,-1000,-991,-694,744,942,678,150,-1000,-1000,-155,-157,1000,310,-548,1000,582,-791,-1000,2,-1000,-1000,-993,-563,-1000,-897,-894,1000,1000,1000,38,1000,-509,269,-578,985,-1000,85,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00139() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(long,java.lang.String,java.util.Locale):java.lang.String",
            new int[]{-715,514,-290,702,-21,-160,-1000,1000,248,-305,-1000,1000,-658,-1000,-1000,-267,232,-1000,184,-769,666,167,523,1000,283,-2,1000,279,1000,1000,-700,-1000,692,-568,-184,-1000,-1000,-99,919,-566,20,-866,204,1000,474,-1000,331,-59,-461,198,327,919,-1000,1000,-147,-1000,-307,-547,-179,-267,-619,-432,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00141() {
        org.junit.Assert.assertEquals("java.lang.String:IA==", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(long,java.lang.String,java.util.Locale):java.lang.String",
            new int[]{-109,948,866,457,-762,51,683,907,-714,884,23,458,-349,-595,-815,-307,-654,-925,-992,-24,494,947,838,-811,662,-614,423,911,317,922,-494,45,485,373,-276,61,-719,564,345,-283,671,-277,275,443,540,-72,-162,-619,-31,903,869,-492,-542,-166,844,-779,771,-51,-64,-682,-940,115,-825,-618}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00142() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(long,java.lang.String,java.util.Locale):java.lang.String",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00144() {
        org.junit.Assert.assertEquals("java.lang.String:MTAwMDE=", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(long,java.lang.String,java.util.Locale):java.lang.String",
            new int[]{651,1000,89,1000,-48,661,-550,589,580,1000,-1000,262,-385,-916,-1000,-191,-611,114,-490,55,-476,580,396,1000,719,-325,1000,-531,1000,627,165,531,-424,-74,-525,-715,-680,-467,885,597,580,928,531,227,317,-708,1000,-1000,-634,-580,503,-427,-400,1000,383,-727,580,-1000,575,-453,313,-580,-561,580}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00145() {
        org.junit.Assert.assertEquals("java.lang.String:MQ==", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(long,java.lang.String,java.util.Locale):java.lang.String",
            new int[]{976,853,-770,249,582,876,693,447,74,479,229,303,511,-60,458,-277,-885,471,-981,589,0,190,-89,179,666,83,-91,39,-963,-995,617,-652,-591,383,555,955,250,470,-429,16,502,775,-181,-585,-264,-431,-436,-990,-656,-711,152,-846,790,57,638,918,868,575,744,-46,922,188,-879,56}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00146() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(long,java.lang.String,java.util.Locale):java.lang.String",
            new int[]{502,1000,-513,249,-260,-613,200,-105,-346,734,229,408,931,-480,80,-342,-300,471,-1000,-194,-476,-551,325,1000,130,332,53,622,-930,-1000,1000,-1000,239,56,555,506,459,-212,-651,1000,184,1000,531,1000,-1000,-178,-430,-1000,-772,-291,585,-497,797,934,-1000,300,337,434,566,581,1000,608,-1000,56}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00147() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(long,java.lang.String,java.util.Locale):java.lang.String",
            new int[]{456,-1000,-115,1000,-1000,-733,-1000,42,-1000,732,-505,508,1000,-951,-258,-997,1000,-188,45,-1000,-1000,-1000,371,577,-1000,-1000,505,812,497,-1000,769,-1000,375,841,1000,-867,-1000,184,684,985,-898,1000,903,580,-239,-1000,1000,1000,-324,1000,550,1000,-1000,575,-1000,-535,-1000,61,1000,1000,-1000,1000,-1000,133}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00148() {
        org.junit.Assert.assertEquals("java.lang.String:LS0xMDAwMjU=", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(long,java.lang.String,java.util.TimeZone):java.lang.String",
            new int[]{-1000,591,169,1000,279,585,-1000,1000,-1000,644,-616,-450,-460,-1000,-573,-918,-619,-938,-825,1000,404,-158,-461,1000,158,1000,-1000,-1000,736,-668,1000,-1000,846,-356,-191,851,-375,-430,-567,-141,1000,-275,1000,-1000,588,-1000,-8,-1000,-1000,1000,-1000,324,1000,-951,1000,1000,-551,1000,-48,-1000,-1000,1000,216,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00149() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(long,java.lang.String,java.util.TimeZone):java.lang.String",
            new int[]{-918,-414,-1,707,1000,131,-959,1000,117,745,403,-189,-68,-890,1000,290,-744,-400,80,1000,-753,-101,-1000,1000,-343,638,-1000,-1000,-341,-954,886,-351,-305,-87,613,-828,537,132,1000,-1000,105,-1000,1000,-223,925,-403,-383,-367,-807,1000,-708,1000,-234,-470,1000,1000,-372,1000,186,-89,-947,610,1000,887}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00152() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(long,java.lang.String,java.util.TimeZone):java.lang.String",
            new int[]{-233,-872,62,-475,1000,338,-5,847,-23,460,806,-1000,-666,-118,-1000,-18,-1000,1000,583,-62,-623,946,-55,-256,501,-1000,-1000,-432,-575,-585,-667,206,337,50,-57,-455,611,1000,1000,-146,1000,-84,948,-103,959,1000,-1000,1000,290,403,346,-852,1000,1000,-1000,-400,-669,262,-211,1000,245,-608,-646,-947}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00153() {
        org.junit.Assert.assertEquals("java.lang.String:XzY4MDc4Ng==", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(long,java.lang.String,java.util.TimeZone):java.lang.String",
            new int[]{-1000,-1000,-979,430,248,-720,-1000,1000,-798,647,1000,-1000,-1000,-1000,1000,-621,266,1000,-256,-767,-932,1000,-372,-1000,231,342,-239,-109,-1000,-878,624,46,1000,-82,1000,-520,918,655,848,-864,-972,-711,890,-689,912,351,955,1000,-286,1000,-341,-441,620,-586,194,1000,-812,286,-702,1000,-955,126,-1000,-458}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00154() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(long,java.lang.String,java.util.TimeZone):java.lang.String",
            new int[]{-89,-321,781,-1000,580,868,-439,1000,1000,884,-550,126,17,-924,-1000,31,-945,37,-627,-1000,1000,-1000,-673,413,-482,1000,-1000,-435,-35,-354,317,-98,549,620,-759,-404,148,539,114,31,-8,651,179,-1000,-1000,969,316,-1000,682,-517,653,-487,481,-20,1000,100,-753,105,-20,-1000,-579,-1000,1000,929}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00156() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(long,java.lang.String,java.util.TimeZone):java.lang.String",
            new int[]{136,-1000,-898,-652,6,-137,1000,-764,788,-44,-134,100,432,1000,-1000,739,262,1000,-302,-115,471,153,794,-705,-498,-706,-1000,611,-687,-878,1000,1000,615,155,-929,-1000,-461,255,1000,88,-1000,-208,556,356,-190,916,235,-410,1000,-443,1000,-114,-129,802,-1000,-629,-445,238,434,872,1000,-469,-1000,-789}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00157() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(long,java.lang.String,java.util.TimeZone):java.lang.String",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00158() {
        org.junit.Assert.assertEquals("java.lang.String:XzYwNg==", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(long,java.lang.String,java.util.TimeZone):java.lang.String",
            new int[]{-743,673,-979,661,-343,-296,-1000,1000,525,1000,-706,-761,259,-1000,-101,-412,-1000,-899,-256,665,877,-1000,-1000,867,67,765,-1000,-742,1000,84,1000,-805,1000,1000,1000,-364,-204,734,-1000,596,820,-176,410,-1000,-763,-864,451,-1000,523,1000,59,322,1000,-1000,1000,1000,-606,571,1000,-781,-1000,769,-488,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00159() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(long,java.lang.String,java.util.TimeZone):java.lang.String",
            new int[]{-1000,-592,-243,599,587,397,-881,795,-245,932,704,-176,-1000,-1000,290,-266,-905,504,-352,155,-676,-640,-372,349,-131,342,-921,-1000,-93,-1000,884,134,1000,1000,399,-195,888,588,-78,-139,268,-729,1000,-1000,-198,-15,658,-337,214,1000,-346,-207,1000,-741,1000,1000,-1000,312,-532,162,-424,306,-450,-29}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00163() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(long,java.lang.String,java.util.TimeZone,java.util.Locale):java.lang.String",
            new int[]{-833,-241,285,-708,577,-295,-159,-101,697,864,-228,-159,1000,314,-233,-139,397,-1000,249,406,-486,378,292,649,-314,400,879,412,945,-556,-795,-427,-402,-826,-1000,338,928,-419,506,1000,1000,-697,155,707,1000,578,519,-346,-1000,76,-1000,845,146,-1000,-346,706,-202,-271,674,-1000,-1000,-901,-151,-528}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00165() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(long,java.lang.String,java.util.TimeZone,java.util.Locale):java.lang.String",
            new int[]{399,-540,590,-373,-480,421,637,-708,588,-963,620,-216,462,54,-150,151,-449,-928,-52,671,723,564,-895,-929,-536,-618,923,-304,98,810,390,667,394,-192,-613,-780,-450,-680,23,-861,157,241,37,470,-467,-19,519,567,-417,405,309,912,-778,-591,-460,129,-692,-644,-976,147,-970,186,432,-437}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00166() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(long,java.lang.String,java.util.TimeZone,java.util.Locale):java.lang.String",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00168() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(long,java.lang.String,java.util.TimeZone,java.util.Locale):java.lang.String",
            new int[]{-580,-509,-273,-1000,-1000,-615,316,1000,-1000,-558,-196,-46,-73,-69,-521,400,-420,-73,-776,202,1,-932,942,-954,1000,1000,-1000,1000,831,-366,-1000,540,559,641,80,-377,556,1000,1000,-401,407,-633,793,116,-864,-794,-16,-1000,411,494,-379,-655,-744,-435,1000,120,-975,749,-817,1000,-1000,58,-807,-384}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00169() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "format(long,java.lang.String,java.util.TimeZone,java.util.Locale):java.lang.String",
            new int[]{-1000,-619,302,184,-250,-408,472,541,399,948,-196,332,-895,175,690,151,446,1000,481,104,583,272,-62,1000,516,-615,336,-608,-1000,-1000,142,-635,-106,-648,-395,1000,1000,-519,526,-263,844,41,-618,-433,247,64,44,900,1000,-310,-234,36,1000,106,1000,1000,-538,966,-217,-886,-995,409,1000,-594}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00170() {
        org.junit.Assert.assertEquals("java.lang.String:MjI0Njg2", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "formatUTC(java.util.Date,java.lang.String):java.lang.String",
            new int[]{-534,-433,173,-224,854,-779,233,-818,1000,230,-1000,1000,39,624,89,1000,-1000,-292,-107,602,-214,-867,16,569,-935,-574,80,-32,606,-344,-1000,-1000,581,42,-741,828,710,683,202,1000,-656,215,1000,-1000,931,-1000,768,678,604,-16,38,538,820,1000,770,-1000,-853,203,722,-311,-842,971,-279,817}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00171() {
        org.junit.Assert.assertEquals("java.lang.String:LTM1NjI=", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "formatUTC(java.util.Date,java.lang.String):java.lang.String",
            new int[]{-295,-183,-356,585,-911,1000,-54,-51,1000,423,-160,305,-1000,-441,1000,-400,-307,753,1000,-453,-1000,-3,-1000,-151,532,-959,932,-466,-660,1000,94,945,248,521,50,50,264,-73,-286,-788,743,1000,1000,195,174,686,48,-1000,564,-34,337,108,-757,-784,571,-594,0,232,-211,728,1000,1000,9,-171}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00172() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "formatUTC(java.util.Date,java.lang.String):java.lang.String",
            new int[]{-629,-369,757,251,-495,443,-740,-6,892,-388,1000,-1000,908,349,387,1000,-728,473,-145,-1000,1000,-1000,888,518,696,240,-162,-1000,-496,636,-597,-159,642,-1000,193,348,-580,-1000,257,335,-398,-980,-1000,752,-598,677,858,476,-580,-948,-1000,-314,-400,1000,-221,-1000,-996,-831,-87,-731,311,1000,-201,817}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00173() {
        org.junit.Assert.assertEquals("java.lang.String:LTM1NjIzOQ==", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "formatUTC(java.util.Date,java.lang.String):java.lang.String",
            new int[]{-493,-183,-356,585,-705,1000,403,0,390,-202,259,-1000,1000,-41,-145,-83,1000,753,1000,-327,1000,-994,-69,-1000,153,-303,-1000,-1000,-660,94,-597,-667,1000,-499,994,468,-256,387,762,897,11,-149,-166,271,-1000,-1000,731,731,140,-858,523,803,1000,1,87,205,474,-879,1000,-371,-112,-1000,-1000,-973}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00174() {
        org.junit.Assert.assertEquals("java.lang.String:NjZfX0FNX182Xw==", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "formatUTC(java.util.Date,java.lang.String):java.lang.String",
            new int[]{-544,-947,986,-205,684,1000,1000,-1000,846,294,-1000,-1000,1000,-1000,-1000,-1000,1000,1000,13,-298,1000,-132,585,1000,394,1000,-1000,-1000,897,-263,-781,1000,1000,389,-1000,-750,-1000,547,1000,129,-1000,-1000,385,847,-1000,-1000,-1000,556,-1000,-374,1000,35,1000,-412,-1000,279,-277,368,1000,-1000,-1000,-1000,-1000,-924}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00175() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "formatUTC(java.util.Date,java.lang.String):java.lang.String",
            new int[]{-1000,-594,-460,52,489,146,-820,-297,813,-432,853,1000,-1000,-340,1000,1000,630,-1000,-465,-1000,-548,-106,-694,-1000,1000,-136,-182,493,378,908,-36,-170,-1000,330,-207,1000,318,-602,-554,612,567,229,859,-689,961,-317,-489,-301,375,-465,426,164,-975,-959,-92,485,185,-1000,630,749,1000,727,1000,-490}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00176() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "formatUTC(java.util.Date,java.lang.String):java.lang.String",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00177() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "formatUTC(java.util.Date,java.lang.String):java.lang.String",
            new int[]{-465,-369,-96,-269,-110,-1000,233,-1000,756,521,-1000,1000,-104,408,-635,1000,1000,-292,135,165,118,-401,-187,518,-935,-574,-79,-1000,1000,329,837,-1000,299,462,-1000,884,710,1000,1000,1000,-677,125,1000,-1000,1000,-1000,768,91,604,684,955,538,1000,1000,770,-1000,-996,309,1000,-295,-1000,1000,-711,817}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00178() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "formatUTC(java.util.Date,java.lang.String):java.lang.String",
            new int[]{-1000,-435,-125,-1000,565,113,-474,-1000,-197,-549,-456,1000,-357,-104,877,934,433,-425,279,-1000,-370,29,387,141,1000,-10,-125,-1000,821,12,-897,-307,-1000,-270,906,1000,918,202,-1000,1000,-1000,905,-1000,1000,1000,-1000,-856,1000,-201,101,125,-280,-368,1000,-972,725,-1000,199,-54,-205,1000,927,224,-142}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00179() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "formatUTC(java.util.Date,java.lang.String,java.util.Locale):java.lang.String",
            new int[]{-780,909,620,-1000,-754,-249,-406,-734,-369,293,-1000,1000,677,-241,1000,-98,-658,-122,200,-1000,118,-1000,-895,74,-1000,-46,-208,-1000,1000,-152,-524,222,-709,500,-720,-55,-677,-35,1000,477,1000,-977,-448,466,245,-230,803,183,-511,1000,189,-208,-793,515,-490,-652,-184,-34,-236,779,663,637,-451,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00180() {
        org.junit.Assert.assertEquals("java.lang.String:NzU0NDQ=", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "formatUTC(java.util.Date,java.lang.String,java.util.Locale):java.lang.String",
            new int[]{773,777,-754,-1000,-969,-466,546,-439,-669,798,-813,1000,-385,713,764,72,-246,-310,251,-1000,188,-614,-570,713,262,887,-130,-26,1000,1000,-553,620,-1000,-1000,-373,838,-1000,245,1000,867,1000,-1000,-1000,-282,-1000,918,115,955,-1000,218,-1000,716,-160,814,-1000,215,-1000,493,-782,435,1000,1000,412,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00181() {
        org.junit.Assert.assertEquals("java.lang.String:NTQ=", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "formatUTC(java.util.Date,java.lang.String,java.util.Locale):java.lang.String",
            new int[]{634,-199,-5,-1000,-455,-1000,129,972,-609,1000,734,810,-538,817,969,78,-1000,-719,307,1000,127,1000,-117,274,-1000,-1000,443,-1000,613,1000,-1000,379,93,-506,-248,-185,-1000,-1000,-755,1000,1000,45,-462,-92,47,-11,-74,36,1000,94,-1000,-908,-1000,763,1000,349,-1000,-1000,173,-790,-530,-357,133,-315}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00182() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "formatUTC(java.util.Date,java.lang.String,java.util.Locale):java.lang.String",
            new int[]{-744,447,626,1000,237,1000,-1000,-585,-321,-1000,-413,937,389,-973,-1000,-307,435,974,-896,-1000,-188,454,1000,-310,706,611,-1000,1000,-867,-1000,1000,1000,362,-959,1000,-171,1000,1000,1000,-1000,-157,-505,743,513,-17,-616,-447,-452,-1000,-796,1000,1000,145,-855,-1000,685,1000,-107,-30,266,427,-1000,363,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00183() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "formatUTC(java.util.Date,java.lang.String,java.util.Locale):java.lang.String",
            new int[]{438,479,752,-92,341,-77,190,1000,-1000,-1000,-1000,1000,1000,-557,1000,328,-32,359,-1000,1000,995,-985,87,-197,864,-125,1000,-288,1000,-66,137,-688,849,-389,334,-920,694,-783,-889,-389,1000,160,-728,-726,865,-514,264,-919,843,-757,-1000,793,-302,1000,-123,-499,-797,-478,1000,-471,-1000,-1000,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00184() {
        org.junit.Assert.assertEquals("java.lang.String:LUFN", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "formatUTC(java.util.Date,java.lang.String,java.util.Locale):java.lang.String",
            new int[]{-1000,334,-58,-935,-398,-292,10,-30,-870,1000,734,697,278,302,-949,250,-1000,174,-425,1000,-322,355,-117,-126,-1000,-867,122,-729,1000,-843,-454,-35,1000,1000,-944,-457,-1000,-281,1000,1000,1000,-1000,-708,-48,-197,-348,1000,36,-638,1000,1000,-242,-1000,763,-578,-736,-1000,-1000,76,497,1000,1000,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00185() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "formatUTC(java.util.Date,java.lang.String,java.util.Locale):java.lang.String",
            new int[]{263,-242,-429,-252,-584,-551,856,612,-811,548,520,-308,-649,730,398,582,-1000,1000,850,680,715,1000,-295,504,401,432,-804,1000,-396,97,-661,578,648,-1000,-756,74,1000,437,684,356,-1000,-207,170,-1000,-556,-1000,-600,274,627,-311,193,-306,-877,19,-252,1000,60,-814,-493,-992,-125,-1000,1000,420}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00186() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "formatUTC(java.util.Date,java.lang.String,java.util.Locale):java.lang.String",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00187() {
        org.junit.Assert.assertEquals("java.lang.String:LTQ5MzE4Mw==", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "formatUTC(java.util.Date,java.lang.String,java.util.Locale):java.lang.String",
            new int[]{-914,569,-493,-831,111,-492,-952,-238,-1000,472,-557,1000,351,-661,-39,272,-41,311,-247,-374,-425,-64,-761,1000,-489,-674,400,-1000,1000,-152,-588,-1000,691,580,-488,-704,-679,-1000,29,1000,747,-1000,-1000,254,1000,-718,448,996,-70,1000,189,-360,-1000,1000,296,-344,-766,-671,985,277,346,-18,-924,811}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00188() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "formatUTC(java.util.Date,java.lang.String,java.util.Locale):java.lang.String",
            new int[]{-1000,574,693,-49,123,-477,-952,-275,-845,542,-1000,653,-418,-367,-1000,69,-134,311,-247,-1000,-230,-64,-279,112,-1000,-674,1000,-1000,1000,-843,785,-1000,994,573,-918,-707,-1000,-1000,1000,1000,1000,-1000,-1000,190,523,-1000,1000,1000,-74,1000,1000,217,-1000,743,-159,-681,-1000,-208,985,375,576,1000,-963,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00189() {
        org.junit.Assert.assertEquals("java.lang.String:KzU3Mi45Njg=", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "formatUTC(java.util.Date,java.lang.String,java.util.Locale):java.lang.String",
            new int[]{274,-651,-572,-234,-32,756,40,-300,580,-122,125,796,209,-315,-781,-299,-595,-630,694,-64,-422,-274,-192,460,964,965,-102,-865,-752,528,-97,973,705,374,642,-223,27,-738,150,-384,891,-391,-238,-618,756,673,625,-336,378,-21,830,103,-909,-784,466,-521,-941,-879,-442,-115,-662,290,61,492}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00190() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "formatUTC(java.util.Date,java.lang.String,java.util.Locale):java.lang.String",
            new int[]{679,-674,-359,740,-801,-465,549,-578,-691,-731,218,933,-108,55,553,-151,629,374,-717,222,477,-856,533,47,234,230,-956,928,-279,452,-347,761,888,-469,-91,-17,458,405,550,-251,-424,463,-18,-741,-584,349,863,-642,650,-770,-560,562,-713,-347,-633,-347,-501,-516,-605,166,-265,779,563,203}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00191() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "formatUTC(java.util.Date,java.lang.String,java.util.Locale):java.lang.String",
            new int[]{906,302,-134,799,21,626,-1000,-653,-340,798,1000,-308,-326,706,-380,-741,1000,1000,-1000,562,-546,-304,927,-352,958,-1000,233,-611,570,-13,457,-744,-20,-1000,1000,-392,-1000,-239,-1000,-634,1000,984,448,836,-343,659,-1000,-431,936,218,-664,893,855,1000,298,-64,-1000,493,1000,435,-980,-1000,169,-536}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00192() {
        org.junit.Assert.assertEquals("java.lang.String:NDlfR01UNg==", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "formatUTC(long,java.lang.String):java.lang.String",
            new int[]{-92,897,367,-1000,-151,-296,600,-1000,958,1000,-329,355,-1000,-1000,-1000,-1000,-597,1000,138,668,1000,135,-1000,-1000,735,-681,282,-572,317,21,1000,-143,1000,198,1000,1000,-697,555,55,-1000,1000,-1000,1000,1000,-1000,-1000,-26,639,1000,1000,-735,-504,-1000,1000,365,438,248,-1000,1000,851,1000,-564,-968,200}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00193() {
        org.junit.Assert.assertEquals("java.lang.String:NjY3Njc5NA==", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "formatUTC(long,java.lang.String):java.lang.String",
            new int[]{1000,-1000,319,684,433,-44,1000,1000,656,1000,-809,673,1000,1000,-1000,-438,1000,1000,-1000,1000,1000,10,1000,219,-1000,738,185,363,-1000,-712,1000,-697,-574,-931,-1000,492,505,-1000,-533,-1000,-24,-1000,-1000,-652,-334,1000,-361,563,-1000,1000,-1000,-1000,-289,1000,1000,-753,-834,1000,-779,-19,1000,915,-1000,421}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00194() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "formatUTC(long,java.lang.String):java.lang.String",
            new int[]{-1000,790,30,-282,-831,-817,-172,-1000,162,-1000,1000,-549,-1000,-1000,-1000,1000,-699,-321,1000,-47,-778,376,-886,-628,-3,395,170,-388,1000,430,-842,1000,1000,701,405,408,-555,233,-252,628,921,-100,413,575,-1000,-1000,-1000,1000,481,-1000,796,-154,-205,-1000,-1000,613,-400,-1000,729,299,55,-1000,417,-44}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00195() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "formatUTC(long,java.lang.String):java.lang.String",
            new int[]{-586,484,269,231,-699,-467,332,-689,386,-580,319,-202,-640,-111,-831,580,-638,-5,859,-37,52,120,-566,-727,-65,-430,-108,-449,396,430,-567,888,910,-345,405,-561,-693,233,394,468,1000,301,-5,480,-687,-44,-580,220,1000,-215,1000,153,-438,-1000,-1000,-55,306,-1000,262,722,443,-580,-3,274}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00196() {
        org.junit.Assert.assertEquals("java.lang.String:XzgwNw==", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "formatUTC(long,java.lang.String):java.lang.String",
            new int[]{468,401,141,231,229,577,-1000,196,-178,836,777,113,17,-111,1000,-284,-278,-379,-1000,-660,-890,-733,-706,298,543,925,695,-780,-224,-804,1000,-89,-1000,1000,-805,-561,371,-1000,-1000,-603,-462,263,-1000,1000,1000,-44,1000,640,1000,-781,-738,-453,-274,400,850,375,-1000,-16,987,-736,-441,44,-1000,-138}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00197() {
        org.junit.Assert.assertEquals("java.lang.String:LkFENg==", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "formatUTC(long,java.lang.String):java.lang.String",
            new int[]{1000,1000,-563,556,144,428,64,-242,1000,1000,-571,1000,17,328,-400,-1000,-112,-505,-1000,-152,662,-1000,675,-359,398,729,1000,-1000,326,-1000,1000,-1000,-391,-690,-1000,428,237,-1000,-1000,-626,-392,-36,-428,1000,1000,1000,1000,213,1000,761,-1000,-636,-1000,1000,457,1000,-147,-848,1000,-254,599,601,-1000,536}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00198() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "formatUTC(long,java.lang.String):java.lang.String",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00199() {
        org.junit.Assert.assertEquals("java.lang.String:KzEwMDAzNDE=", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "formatUTC(long,java.lang.String):java.lang.String",
            new int[]{361,1000,457,-1000,-642,897,-940,184,739,400,171,-804,-366,-530,-1000,381,-1000,142,205,1000,-1000,-309,-638,-341,1000,16,416,-1000,1000,-637,-1000,410,786,1000,-300,892,-511,1000,-851,887,1000,683,1000,-1000,-1000,-243,-96,-1000,798,-692,544,20,-650,400,400,-258,1000,-327,1000,608,1000,182,448,373}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00200() {
        org.junit.Assert.assertEquals("java.lang.String:QU0=", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "formatUTC(long,java.lang.String):java.lang.String",
            new int[]{43,151,364,-758,-391,577,383,93,1000,1000,-504,-119,-398,604,-600,-626,21,-58,39,805,439,-733,96,-711,-195,-1000,-905,647,10,558,1000,-89,408,-728,506,928,-112,543,670,-603,729,263,-89,1000,-1000,-1000,864,1000,1000,659,-1000,745,-1000,1000,365,375,1000,382,987,676,1000,1000,-1000,433}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00201() {
        org.junit.Assert.assertEquals("java.lang.String:NjYzMTYyOF8=", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "formatUTC(long,java.lang.String,java.util.Locale):java.lang.String",
            new int[]{-1000,-548,365,-896,465,-643,1000,1000,585,751,1000,235,-1000,-701,1000,-1000,138,-21,-913,140,442,87,-769,-977,885,495,302,-786,-683,355,334,-996,-114,-701,465,-571,274,-3,1000,75,-906,208,-1000,662,592,1000,-950,814,-328,-397,-1000,494,-85,-441,341,785,-100,7,-430,-519,336,484,-826,62}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00202() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "formatUTC(long,java.lang.String,java.util.Locale):java.lang.String",
            new int[]{724,-1000,911,-177,-1000,891,-107,396,-249,-1000,-623,-1000,-400,1000,816,-689,-1000,1000,1000,-995,913,1000,112,-1000,-1000,-547,74,746,-392,-1000,401,-154,1000,-647,1000,623,-499,388,14,985,-1000,-810,-1000,-1000,-854,1000,-639,-1000,-129,-474,1000,1000,-1000,1000,-61,-485,1000,-508,1000,-1000,-1000,-489,543,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00203() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "formatUTC(long,java.lang.String,java.util.Locale):java.lang.String",
            new int[]{1000,-253,-290,-1000,-301,4,-1000,42,-733,-192,1000,384,1000,695,-235,-36,-1000,-42,256,-423,988,-1000,1000,-1000,-838,1000,487,-824,203,606,-277,110,24,-711,-853,446,-618,-3,1000,1000,-529,-594,232,862,-1000,-323,-633,-94,565,1000,-18,-540,-85,822,-513,-1000,586,880,-214,593,-298,249,848,-241}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00204() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "formatUTC(long,java.lang.String,java.util.Locale):java.lang.String",
            new int[]{-958,-1000,893,618,-16,-437,-573,1000,-842,-619,1000,-93,390,-398,971,-1000,-642,-21,177,-380,671,-895,412,-570,-538,-1000,525,-786,203,355,1000,977,327,-625,-529,330,-455,-1000,234,803,-334,-634,-132,449,-560,1000,-1000,-350,-21,990,293,601,-148,-712,-638,38,394,-825,-209,-1000,-652,464,88,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00205() {
        org.junit.Assert.assertEquals("java.lang.String:LS0zOTAyMjk=", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "formatUTC(long,java.lang.String,java.util.Locale):java.lang.String",
            new int[]{-744,224,-263,390,571,249,823,1000,427,1000,996,1000,-583,-1000,49,-198,257,249,-655,72,-284,13,-890,-172,873,947,128,16,-129,494,-672,-996,-385,-59,-1000,-369,350,824,319,22,44,-158,709,815,1000,-474,295,474,-464,210,-913,-697,-572,-134,246,417,-37,408,-151,-140,315,654,-352,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00206() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "formatUTC(long,java.lang.String,java.util.Locale):java.lang.String",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00207() {
        org.junit.Assert.assertEquals("java.lang.String:Xy5fNFBNNTYyOQ==", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "formatUTC(long,java.lang.String,java.util.Locale):java.lang.String",
            new int[]{1000,-726,31,-1000,-1000,534,-1000,-433,-1000,-564,-61,289,1000,226,-488,-689,-732,881,565,11,875,-1000,-1000,-628,-444,-963,232,583,652,-22,867,1000,221,93,-6,564,-348,-309,-826,647,-1000,-1000,-1000,-943,-1000,-221,-217,-1000,625,1000,1000,-180,129,1000,-1000,-189,212,-178,391,433,-1000,526,366,-298}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00208() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "formatUTC(long,java.lang.String,java.util.Locale):java.lang.String",
            new int[]{-543,353,509,755,-428,531,164,323,-652,830,623,1000,1000,-196,-1000,400,-196,734,-1000,423,-572,-338,-1000,-478,804,-374,-128,1000,-351,-375,-308,-1000,-433,-263,-713,-922,534,146,59,-908,65,-61,350,405,-200,-400,-214,-171,1000,951,319,-351,-179,-712,-1000,72,-1000,419,14,164,-1000,165,-92,972}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00209() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "formatUTC(long,java.lang.String,java.util.Locale):java.lang.String",
            new int[]{-222,-688,-114,-156,-860,-143,-536,641,147,877,860,125,903,-660,137,-213,-286,299,900,-414,282,-462,71,-918,433,139,-612,55,-728,-74,-214,769,-305,320,-926,142,212,248,673,763,135,-554,562,897,-609,-242,-974,-605,432,824,-663,-196,-989,-50,-938,844,980,880,-663,-90,-342,701,-831,300}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00210() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "formatUTC(long,java.lang.String,java.util.Locale):java.lang.String",
            new int[]{785,-645,-435,-1000,-465,-228,-617,330,-774,149,434,-447,1000,-1000,-84,182,480,104,488,-566,617,-994,-1000,-739,338,374,-284,247,-1000,476,-319,1000,298,968,-478,581,-363,484,-182,407,-143,-477,1000,839,-592,-398,323,-814,591,986,304,-917,60,716,-474,1000,152,923,-636,290,-1000,615,-1000,869}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00211() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.lang.time.DateFormatUtils", "", "formatUTC(long,java.lang.String,java.util.Locale):java.lang.String",
            new int[]{-615,-542,-819,-973,-451,-188,-940,524,-655,-97,1000,-302,1000,-926,-110,-1000,74,1000,400,-766,480,1000,159,-1000,207,-934,-255,716,-138,-272,572,-1000,686,-1000,-1000,509,-424,-1000,71,312,329,-660,-277,1000,-411,-71,-1000,-1000,562,1000,164,649,-487,793,-1000,735,326,701,-926,-108,-1000,866,-1000,383}));
    }
}
