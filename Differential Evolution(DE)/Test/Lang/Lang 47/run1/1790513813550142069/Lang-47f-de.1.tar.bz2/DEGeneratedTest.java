import java.lang.reflect.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Deterministic test-program decoder. Used unchanged during search and JUnit replay. */
final class DEReplay {
    public static final int DIMENSIONS = 64;
    /** Local generic bean used to create stable reflection Type and Field values. */
    public static final class GenericInput {
        public String text;
        public java.util.List<String> names;
        public java.util.Map<String, Integer> counts;
        public java.util.List<java.util.Map<String, Long>> nested;
        public int[] numbers;
        public String[] words;
    }
    static final class Genes {
        final int[] values; int at; Field lastField;
        Object jacksonBean, jacksonProvider, jacksonGenerator;
        StringWriter jacksonOutput;
        Genes(int[] values) { this.values = values; }
        int next() { return values[(at++) % values.length]; }
        int pick(int n) { return Math.floorMod(next(), n); }
    }
    public static final class Observation {
        public String token, error, generatedSource;
        public boolean reachedTarget;
        public int setupCalls, setupFailures, nullFallbacks;
    }
    public static String signature(Method m) {
        StringJoiner params = new StringJoiner(",");
        for (Class<?> t : m.getParameterTypes()) params.add(t.getTypeName());
        return m.getName() + "(" + params + "):" + m.getReturnType().getTypeName();
    }
    static Class<?> load(String name) throws ClassNotFoundException {
        return Class.forName(name, true, Thread.currentThread().getContextClassLoader());
    }
    static Method method(String target, String signature) throws Exception {
        for (Method m : load(target).getDeclaredMethods())
            if (signature(m).equals(signature)) {
                // Public methods on package-private Defects4J classes (for
                // example Gson's TypeInfoFactory) are not reflectively
                // accessible until opened on the unnamed application module.
                if (!m.isAccessible()) m.setAccessible(true);
                return m;
            }
        throw new NoSuchMethodException(signature);
    }
    static List<Constructor<?>> constructors(Class<?> type) {
        List<Constructor<?>> out = new ArrayList();
        if (!Modifier.isAbstract(type.getModifiers()) && Modifier.isPublic(type.getModifiers()))
            for (Constructor<?> c : type.getConstructors())
                if (c.getParameterTypes().length <= 6) out.add(c);
        Collections.sort(out, new Comparator<Constructor<?>>() {
            public int compare(Constructor<?> a, Constructor<?> b) {
                int byArity = a.getParameterTypes().length - b.getParameterTypes().length;
                return byArity != 0 ? byArity : a.toString().compareTo(b.toString());
            }
        });
        return out;
    }
    private static Object[] arguments(Class<?>[] types, Genes g, int depth,
                                      Observation report) throws Exception {
        Object[] args = new Object[types.length];
        for (int i = 0; i < types.length; i++) args[i] = value(types[i], g, depth, report);
        return args;
    }
    private static Object[] arguments(Method method, Genes g, int depth,
                                      Observation report) throws Exception {
        Class<?>[] types = method.getParameterTypes();
        Object[] args = new Object[types.length];
        boolean closureCompile = method.getDeclaringClass().getName().equals("com.google.javascript.jscomp.Compiler")
            && method.getName().equals("compile");
        Type[] generic = method.getGenericParameterTypes();
        boolean jacksonSerialization = method.getDeclaringClass().getName().equals(
            "com.fasterxml.jackson.databind.ser.BeanPropertyWriter")
            && method.getName().startsWith("serializeAs")
            && types.length == 3 && types[0] == Object.class;
        for (int i = 0; i < types.length; i++) {
            if (jacksonSerialization && g.jacksonBean != null) {
                if (i == 0) args[i] = g.jacksonBean;
                else if (i == 1) args[i] = g.jacksonGenerator;
                else args[i] = g.jacksonProvider;
                continue;
            }
            if (closureCompile && (List.class.isAssignableFrom(types[i])
                    || (types[i].isArray() && load("com.google.javascript.jscomp.SourceFile")
                        .isAssignableFrom(types[i].getComponentType())))) {
                // Compiler.compile takes externs and inputs in either Lists or
                // arrays depending on Closure version. Keep externs empty and
                // supply a nonempty, gene-selected input program.
                if (i == 0) args[i] = types[i].isArray()
                    ? Array.newInstance(types[i].getComponentType(), 0) : new ArrayList();
                else {
                    Object sourceFile = value(load("com.google.javascript.jscomp.SourceFile"),
                        g, depth + 1, report);
                    if (types[i].isArray()) {
                        Object files = Array.newInstance(types[i].getComponentType(), 1);
                        Array.set(files, 0, sourceFile); args[i] = files;
                    } else args[i] = new ArrayList(Collections.singletonList(sourceFile));
                }
            } else args[i] = value(types[i], g, depth, report);
        }
        return args;
    }
    private static Number number(Genes g) {
        int n = g.next();
        switch (g.pick(12)) {
            case 0: return 0; case 1: return 1; case 2: return -1;
            case 3: return Integer.MAX_VALUE; case 4: return Integer.MIN_VALUE;
            case 5: return Long.MAX_VALUE; case 6: return Long.MIN_VALUE;
            case 7: return Double.NaN; case 8: return Double.POSITIVE_INFINITY;
            case 9: return Double.NEGATIVE_INFINITY; case 10: return n / 10.0;
            default: return n;
        }
    }
    private static String string(Genes g) {
        int mode = g.pick(16), n = g.next();
        String digits = Long.toString(Math.abs((long)n));
        String sign = new String[]{"", "-", "+", "--"}[g.pick(4)];
        switch (mode) {
            case 0: return null; case 1: return ""; case 2: return " ";
            case 3: return Integer.toString(n);
            case 4: return sign + digits;
            case 5: return sign + digits + "." + g.pick(1000);
            case 6: return sign + digits + "e" + g.next();
            case 7: return sign + "0x" + Long.toHexString(Math.abs((long)n));
            case 8: return sign + "0x8" + "0".repeat(g.pick(20));
            case 9: return sign + digits + "fFdDlL".charAt(g.pick(6));
            case 10: return " " + sign + digits + " ";
            case 11: return new String[]{"true", "false", "null", "NaN", "Infinity"}[g.pick(5)];
            case 12: return "a".repeat(g.pick(25));
            default:
                String alphabet = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ+-._ /\\\t\n";
                StringBuilder s = new StringBuilder();
                int length = g.pick(25);
                for (int i = 0; i < length; i++) s.append(alphabet.charAt(g.pick(alphabet.length())));
                return s.toString();
        }
    }
    private static Object value(Class<?> t, Genes g, int depth, Observation report) throws Exception {
        if (t == String.class || t == CharSequence.class) return string(g);
        if (t == Comparable.class) return "key" + g.pick(5);
        if (t == boolean.class || t == Boolean.class) return g.pick(2) == 0;
        if (t == char.class || t == Character.class) return (char)g.pick(128);
        if (t == byte.class || t == Byte.class) return number(g).byteValue();
        if (t == short.class || t == Short.class) return number(g).shortValue();
        if (t == int.class || t == Integer.class) return number(g).intValue();
        if (t == long.class || t == Long.class) return number(g).longValue();
        if (t == float.class || t == Float.class) return number(g).floatValue();
        if (t == double.class || t == Double.class || t == Number.class) return number(g).doubleValue();
        if (t.isEnum()) {
            Object[] constants = t.getEnumConstants();
            return constants.length == 0 ? null : constants[g.pick(constants.length)];
        }
        if (t == Object.class) return g.pick(3) == 0 ? null : "object" + g.pick(5);
        if (depth >= 3) { report.nullFallbacks++; return null; }
        if (t.isArray()) {
            int length = g.pick(6);
            Object array = Array.newInstance(t.getComponentType(), length);
            for (int i = 0; i < length; i++) Array.set(array, i, value(t.getComponentType(), g, depth + 1, report));
            return array;
        }
        if (t == List.class || t == Collection.class || t == Iterable.class || t == Set.class) {
            Collection<Object> items = t == Set.class ? new LinkedHashSet() : new ArrayList();
            int size = g.pick(5);
            for (int i = 0; i < size; i++) items.add("item" + g.pick(5));
            return items;
        }
        if (t == Map.class) {
            Map<Object, Object> items = new LinkedHashMap();
            int size = g.pick(5);
            for (int i = 0; i < size; i++) items.put("key" + g.pick(5), number(g));
            return items;
        }
        if (t == java.util.Date.class) return new java.util.Date(g.next() * 86400000L);
        if (t == Class.class) return String.class;
        if (t == java.lang.reflect.Field.class) {
            Field[] fields = GenericInput.class.getFields();
            g.lastField = fields[g.pick(fields.length)];
            return g.lastField;
        }
        if (t == java.lang.reflect.Type.class) {
            if (g.lastField != null && g.pick(3) == 0)
                return g.lastField.getDeclaringClass();
            Field[] fields = GenericInput.class.getFields();
            return fields[g.pick(fields.length)].getGenericType();
        }
        if (t == java.io.Reader.class || t == java.io.BufferedReader.class
                || t == java.io.StringReader.class) {
            String content = "header,value\n" + string(g) + "," + number(g) + "\n"
                + "alpha,beta\n";
            StringReader reader = new StringReader(content);
            return t == java.io.BufferedReader.class ? new BufferedReader(reader) : reader;
        }
        if (t.getName().equals("org.apache.commons.csv.CSVFormat")) {
            Class<?> format = load("org.apache.commons.csv.CSVFormat");
            for (String fieldName : new String[]{"DEFAULT", "RFC4180", "EXCEL"}) try {
                Object result = format.getField(fieldName).get(null);
                if (t.isInstance(result)) return result;
            } catch (ReflectiveOperationException ignored) { }
            for (Method factory : format.getMethods())
                if (Modifier.isStatic(factory.getModifiers()) && factory.getParameterTypes().length == 0
                        && t.isAssignableFrom(factory.getReturnType())) try {
                    return factory.invoke(null);
                } catch (ReflectiveOperationException ignored) { }
        }
        if (t.getName().equals("com.google.javascript.jscomp.SourceFile")) {
            Class<?> source = load("com.google.javascript.jscomp.SourceFile");
            for (Method factory : source.getMethods())
                if (Modifier.isStatic(factory.getModifiers()) && factory.getName().equals("fromCode")
                        && factory.getParameterTypes().length == 2 && factory.getParameterTypes()[0] == String.class
                        && factory.getParameterTypes()[1] == String.class) {
                    String replaySource = System.getProperty("de.generated.source");
                    if (replaySource != null) {
                        try {
                            report.generatedSource = replaySource;
                            return factory.invoke(null, "de-input.js", replaySource);
                        } catch (ReflectiveOperationException ignored) { }
                    }
                    String[] unusedParameterScripts = {
                        "window.f = function(a) {};",
                        "window.f = function(a, b) { return b; };",
                        "window.f = function(a, b) { var used = b; return used; };",
                        "window['f'] = function(unused) {};",
                        "window.f = function(unused, value) { return value; };",
                        "window['f'] = function(unused, value) { return value; };",
                        "window.f = function(first, unused, last) { return last; };",
                        "window.f = function(unused) { var local = 1; return local; };",
                        "window.f = function(unused, value) { var alias = value; return alias; };",
                        "window.f = function(unused, value) { if (value) { return 1; } return 2; };",
                        "window.f = function(unused, value) { value = value + 1; return value; };",
                        "window.f = function(unused, value) { return function() { return value; }; };",
                        "window.f = function(unused) { function inner() { return 1; } return inner(); };",
                        "window.f = function(a, b, unused) { return a + b; };",
                        "window.f = function(a, unused, b, c) { return a + c; };"
                    };
                    String[] catchDependencyScripts = {
                        "window.f = function() { var saved; try { throw Error('x'); } catch (caught) { saved = caught; } return saved.stack; };",
                        "window.f = function(flag) { var saved; try { if (flag) throw Error('x'); } catch (caught) { saved = caught; } return saved.message; };",
                        "window.f = function() { var saved; try { throw Error('x'); } catch (caught) { saved = caught; } return saved.name; };",
                        "window.f = function() { var saved; try { throw Error('x'); } catch (caught) { saved = caught; } return String(saved); };",
                        "window.f = function(flag) { var saved; try { if (flag) throw Error('x'); } catch (problem) { saved = problem; } return saved.stack; };",
                        "window.f = function() { var saved; try { throw Error('x'); } catch (problem) { saved = problem; } return saved.message; };"
                    };
                    String[] genericScripts = {
                        "function f(unused, used) { var local = 1; return used; } f(1, 2);",
                        "function f() { var unused = 1; var used = 2; return used; } f();",
                        "function f(x) { var first = x; first = 3; return x; } f(2);",
                        "function f() { var unused = 1; } f();",
                        "function keep() { var dead = 1; return 7; } keep();"
                    };
                    String modified = System.getProperty("de.modified.classes", "");
                    String[] scripts;
                    if (modified.contains("RemoveUnusedVars") && modified.contains("FlowSensitiveInlineVariables")) {
                        scripts = new String[unusedParameterScripts.length + catchDependencyScripts.length];
                        System.arraycopy(unusedParameterScripts, 0, scripts, 0, unusedParameterScripts.length);
                        System.arraycopy(catchDependencyScripts, 0, scripts, unusedParameterScripts.length,
                            catchDependencyScripts.length);
                    }
                    else if (modified.contains("FlowSensitiveInlineVariables")) scripts = catchDependencyScripts;
                    else if (modified.contains("RemoveUnusedVars")) scripts = unusedParameterScripts;
                    else scripts = genericScripts;
                    try {
                        String code = scripts[g.pick(scripts.length)];
                        report.generatedSource = code;
                        return factory.invoke(null, "de-input.js", code);
                    }
                    catch (ReflectiveOperationException ignored) { }
                }
        }
        if (t.getName().equals("com.google.javascript.jscomp.CompilerOptions")) {
            try {
                Object options = t.getConstructor().newInstance();
                // In Closure Compiler, unused-variable passes are enabled by
                // CompilationLevel, rather than by a CompilerOptions enum
                // setter. Apply the real public configuration when available.
                try {
                    Class<?> levelType = load("com.google.javascript.jscomp.CompilationLevel");
                    Object advanced = levelType.getField("ADVANCED_OPTIMIZATIONS").get(null);
                    for (Method configure : levelType.getMethods())
                        if (configure.getName().equals("setOptionsForCompilationLevel")
                                && configure.getParameterTypes().length == 1
                                && configure.getParameterTypes()[0].isInstance(options)) {
                            configure.invoke(advanced, options); break;
                        }
                } catch (ReflectiveOperationException ignored) { }
                // Also set the relevant options directly for Closure releases
                // whose compilation-level helper no longer enables this pass.
                for (Class<?> current = t; current != null; current = current.getSuperclass())
                    for (Field field : current.getDeclaredFields()) {
                        String name = field.getName().toLowerCase(Locale.ROOT);
                        if (field.getType() == boolean.class && name.equals("removeglobals")) try {
                            // Closure-1 specifically guards argument removal
                            // when globals are preserved. Keep the optimization
                            // pass enabled while exercising that configuration.
                            field.setAccessible(true); field.setBoolean(options, false);
                        } catch (Exception ignored) { }
                        if (field.getType() == boolean.class
                                && (name.contains("removeunusedvar") || name.contains("removeunusedlocal"))) try {
                            field.setAccessible(true); field.setBoolean(options, true);
                        } catch (Exception ignored) { }
                    }
                for (Method setter : t.getMethods()) {
                    if (!Modifier.isPublic(setter.getModifiers()) || !setter.getName().startsWith("set")
                            || setter.getParameterTypes().length != 1) continue;
                    String name = setter.getName().toLowerCase(Locale.ROOT);
                    if (setter.getParameterTypes()[0] == boolean.class && name.contains("removeglobals")) {
                        try { setter.invoke(options, false); } catch (ReflectiveOperationException ignored) { }
                    } else if (setter.getParameterTypes()[0] == boolean.class
                            && (name.contains("removeunusedvar") || name.contains("removeunusedlocal"))) {
                        try { setter.invoke(options, true); } catch (ReflectiveOperationException ignored) { }
                    } else if (name.contains("optimizationlevel")
                            && setter.getParameterTypes()[0].isEnum()) {
                        Object[] values = setter.getParameterTypes()[0].getEnumConstants();
                        for (Object value : values) if (String.valueOf(value).contains("ADVANCED"))
                            try { setter.invoke(options, value); } catch (ReflectiveOperationException ignored) { }
                    }
                }
                return options;
            } catch (ReflectiveOperationException ignored) { }
        }
        if (t.getName().equals("com.google.javascript.rhino.Node")) {
            try {
                Class<?> ir = load("com.google.javascript.rhino.IR");
                for (String factoryName : new String[]{"script", "root", "name", "string"})
                    for (Method factory : ir.getMethods())
                        if (Modifier.isStatic(factory.getModifiers()) && factory.getName().equals(factoryName)
                                && factory.getParameterTypes().length == 0 && t.isAssignableFrom(factory.getReturnType()))
                            return factory.invoke(null);
            } catch (ReflectiveOperationException ignored) { }
        }
        if (t.getName().equals("com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser")) {
            Object parser = xmlParser(g, report);
            if (parser != null && t.isInstance(parser)) return parser;
        }
        if (t.getName().equals("com.fasterxml.jackson.databind.ser.BeanPropertyWriter")
                || t.getName().equals("com.fasterxml.jackson.databind.ser.impl.UnwrappingBeanPropertyWriter")) {
            Object writer = jacksonWriter(t, g, report);
            if (writer != null && t.isInstance(writer)) return writer;
        }
        if (t == java.awt.Graphics2D.class || t == java.awt.Graphics.class)
            return new java.awt.image.BufferedImage(80, 80, java.awt.image.BufferedImage.TYPE_INT_ARGB).createGraphics();
        if (java.awt.Paint.class.isAssignableFrom(t)) {
            java.awt.Color c = new java.awt.Color(g.pick(256), g.pick(256), g.pick(256));
            if (t.isInstance(c)) return c;
        }
        if (java.awt.Stroke.class.isAssignableFrom(t)) {
            java.awt.BasicStroke s = new java.awt.BasicStroke(g.pick(10) / 2.0f);
            if (t.isInstance(s)) return s;
        }
        if (java.awt.Shape.class.isAssignableFrom(t)) {
            java.awt.Shape s = new java.awt.geom.Rectangle2D.Double(g.next(), g.next(), g.pick(80), g.pick(80));
            if (t.isInstance(s)) return s;
        }
        if (t == java.awt.geom.Point2D.class) return new java.awt.geom.Point2D.Double(g.next(), g.next());
        if (t.getName().equals("org.apache.commons.cli.CommandLine"))
            return commandLine(g, report);
        Object domain = chart(t, g, report);
        if (domain != null) return domain;
        Object language = language(t, g, report);
        if (language != null) return language;
        List<Constructor<?>> ctors = constructors(t);
        // Older Java libraries often use public singleton constants in place of enums.
        if (ctors.isEmpty()) {
            List<Field> constants = new ArrayList();
            for (Field field : t.getFields())
                if (Modifier.isStatic(field.getModifiers()) && Modifier.isFinal(field.getModifiers())
                        && t.isAssignableFrom(field.getType())) constants.add(field);
            Collections.sort(constants, new Comparator<Field>() {
                public int compare(Field a, Field b) { return a.getName().compareTo(b.getName()); }
            });
            if (!constants.isEmpty()) {
                Object constant = constants.get(g.pick(constants.size())).get(null);
                if (constant != null) return constant;
            }
        }
        if (!ctors.isEmpty()) {
            Constructor<?> ctor = ctors.get(g.pick(ctors.size()));
            try { return ctor.newInstance(arguments(ctor.getParameterTypes(), g, depth + 1, report)); }
            catch (Exception ignored) { }
        }
        report.nullFallbacks++;
        return null;
    }
    private static Object language(Class<?> t, Genes g, Observation report) {
        if (!t.getName().equals("org.apache.commons.lang3.time.FastDateFormat")) return null;
        try {
            Method factory = t.getMethod("getInstance", String.class, java.util.TimeZone.class,
                java.util.Locale.class);
            String[] patterns = {"yyyy-MM-dd", "MM/dd/yy HH:mm:ss", "EEE, d MMM yyyy HH:mm:ss Z"};
            return factory.invoke(null, patterns[g.pick(patterns.length)],
                java.util.TimeZone.getTimeZone("UTC"), java.util.Locale.US);
        } catch (ReflectiveOperationException ignored) { }
        try { return t.getMethod("getInstance", String.class).invoke(null, "yyyy-MM-dd"); }
        catch (ReflectiveOperationException ignored) { return null; }
    }
    private static Object xmlParser(Genes g, Observation report) {
        try {
            Class<?> factoryType = load("com.fasterxml.jackson.dataformat.xml.XmlFactory");
            Object factory = factoryType.getConstructor().newInstance();
            String[] docs = {"<root><value>1</value><name>x</name></root>",
                "<root value=\"42\"><item>a</item><item>b</item></root>",
                "<root/>"};
            String xml = docs[g.pick(docs.length)];
            for (Method method : factoryType.getMethods()) {
                if (!method.getName().equals("createParser") || method.getParameterTypes().length != 1) continue;
                Class<?> p = method.getParameterTypes()[0];
                Object input = p == String.class ? xml : p == Reader.class ? new StringReader(xml)
                    : p == InputStream.class ? new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8)) : null;
                if (input == null) continue;
                try {
                    Object parser = method.invoke(factory, input);
                    if (parser != null) {
                        int advance = g.pick(4);
                        Method next = parser.getClass().getMethod("nextToken");
                        for (int i = 0; i < advance; i++) if (next.invoke(parser) == null) break;
                        return parser;
                    }
                } catch (ReflectiveOperationException ignored) { }
            }
        } catch (Throwable ignored) { }
        return null;
    }
    private static Object jacksonWriter(Class<?> requested, Genes g, Observation report) {
        try {
            Class<?> mapperType = load("com.fasterxml.jackson.databind.ObjectMapper");
            Object mapper = mapperType.getConstructor().newInstance();
            Object bean = new GenericInput();
            Class<?> javaTypeType = load("com.fasterxml.jackson.databind.JavaType");
            Object javaType = mapperType.getMethod("constructType", Type.class).invoke(mapper, bean.getClass());
            // Jackson 2.6 (used by this Defects4J project) exposes a provider
            // blueprint from ObjectMapper. Create a configured provider via
            // DefaultSerializerProvider, the supported API used by ObjectMapper.
            Object providerBlueprint = mapperType.getMethod("getSerializerProvider").invoke(mapper);
            Class<?> serializationConfigType = load("com.fasterxml.jackson.databind.SerializationConfig");
            Class<?> serializerFactoryType = load("com.fasterxml.jackson.databind.ser.SerializerFactory");
            Object config = mapperType.getMethod("getSerializationConfig").invoke(mapper);
            Object factory = mapperType.getMethod("getSerializerFactory").invoke(mapper);
            Class<?> defaultProviderType = load("com.fasterxml.jackson.databind.ser.DefaultSerializerProvider");
            Method createProvider = defaultProviderType.getMethod("createInstance",
                serializationConfigType, serializerFactoryType);
            Object provider = createProvider.invoke(providerBlueprint, config, factory);
            g.jacksonBean = bean;
            g.jacksonProvider = provider;
            g.jacksonOutput = new StringWriter();
            Object jsonFactory = mapperType.getMethod("getFactory").invoke(mapper);
            for (String factoryMethod : new String[]{"createGenerator", "createJsonGenerator"}) {
                try {
                    Method createGenerator = jsonFactory.getClass().getMethod(factoryMethod, Writer.class);
                    g.jacksonGenerator = createGenerator.invoke(jsonFactory, g.jacksonOutput);
                    break;
                } catch (NoSuchMethodException ignored) { }
            }
            if (g.jacksonGenerator == null)
                throw new NoSuchMethodException("JsonFactory.createGenerator(Writer) or createJsonGenerator(Writer)");
            Class<?> providerType = load("com.fasterxml.jackson.databind.SerializerProvider");
            Class<?> beanPropertyType = load("com.fasterxml.jackson.databind.BeanProperty");
            Method find = providerType.getMethod("findValueSerializer", javaTypeType, beanPropertyType);
            Object serializer = find.invoke(provider, new Object[]{javaType, null});
            List<Object> writers = new ArrayList();
            try {
                // Available on Jackson 2.6 and newer.
                Class<?> serializerType = load("com.fasterxml.jackson.databind.JsonSerializer");
                Method properties = serializerType.getMethod("properties");
                Iterator<?> it = (Iterator<?>)properties.invoke(serializer);
                while (it.hasNext()) {
                    Object item = it.next();
                    if (item != null && item.getClass().getName().endsWith("BeanPropertyWriter"))
                        writers.add(item);
                }
            } catch (NoSuchMethodException oldJackson) {
                // JacksonDatabind-1 predates JsonSerializer.properties(). Its
                // BeanSerializerBase stores writers in the protected _props
                // array; read that array only for these old releases.
                Class<?> base = load("com.fasterxml.jackson.databind.ser.std.BeanSerializerBase");
                if (!base.isInstance(serializer))
                    throw new IllegalStateException("Expected BeanSerializerBase, got "
                        + serializer.getClass().getName(), oldJackson);
                Field props = base.getDeclaredField("_props");
                props.setAccessible(true);
                Object array = props.get(serializer);
                for (int i = 0; i < Array.getLength(array); i++) {
                    Object item = Array.get(array, i);
                    if (item != null && item.getClass().getName().endsWith("BeanPropertyWriter"))
                        writers.add(item);
                }
            }
            if (writers.isEmpty())
                throw new IllegalStateException("ObjectMapper produced no bean property writers for DEReplay.GenericInput");
            Object writer = writers.get(g.pick(writers.size()));
            boolean requireUnwrapping = requested.getName().equals(
                "com.fasterxml.jackson.databind.ser.impl.UnwrappingBeanPropertyWriter");
            if (!requireUnwrapping && g.pick(2) == 0 && requested.isInstance(writer)) return writer;
            Class<?> transformerType = load("com.fasterxml.jackson.databind.util.NameTransformer");
            Object nop = transformerType.getField("NOP").get(null);
            for (Method m : writer.getClass().getMethods())
                if (m.getName().equals("unwrappingWriter") && m.getParameterTypes().length == 1
                        && m.getParameterTypes()[0].isInstance(nop)) {
                    Object unwrapped = m.invoke(writer, nop);
                    if (requested.isInstance(unwrapped)) return unwrapped;
                }
            if (requested.isInstance(writer)) return writer;
            throw new IllegalStateException("Generated Jackson property writer is not " + requested.getName());
        } catch (Throwable failure) {
            throw new IllegalStateException("Cannot construct Jackson BeanPropertyWriter: " + failure, failure);
        }
    }
    /** Build the non-constructible Commons CLI result through its public Parser API. */
    private static Object commandLine(Genes g, Observation report) throws Exception {
        Class<?> optionsClass = load("org.apache.commons.cli.Options");
        Class<?> optionClass = load("org.apache.commons.cli.Option");
        Class<?> parserClass = load("org.apache.commons.cli.PosixParser");
        Object options = optionsClass.getConstructor().newInstance();
        Method addOption = optionsClass.getMethod("addOption", optionClass);
        int numberOfOptions = 1 + g.pick(3);
        List<String> spellings = new ArrayList();
        for (int i = 0; i < numberOfOptions; i++) {
            String shortName = String.valueOf((char)('a' + i));
            String longName = "de-option-" + i;
            boolean hasArgument = g.pick(2) == 0;
            Object option = null;
            try {
                option = optionClass.getConstructor(String.class, String.class, boolean.class, String.class)
                    .newInstance(shortName, longName, hasArgument, "DE-generated option");
            } catch (NoSuchMethodException ignored) { }
            if (option == null) try {
                option = optionClass.getConstructor(String.class, boolean.class, String.class)
                    .newInstance(shortName, hasArgument, "DE-generated option");
            } catch (NoSuchMethodException ignored) { }
            if (option == null) throw new NoSuchMethodException("No supported Commons CLI Option constructor");
            addOption.invoke(options, option);
            spellings.add("-" + shortName);
            if (hasArgument) spellings.add("value-" + Math.abs((long)g.next()));
        }
        String[] argv = spellings.toArray(new String[0]);
        Object parser = parserClass.getConstructor().newInstance();
        List<Method> parseMethods = new ArrayList();
        for (Method candidate : parserClass.getMethods()) {
            Class<?>[] p = candidate.getParameterTypes();
            if (candidate.getName().equals("parse") && p.length >= 2 && p[0] == optionsClass
                    && p[1] == String[].class && candidate.getReturnType() == load("org.apache.commons.cli.CommandLine"))
                parseMethods.add(candidate);
        }
        Collections.sort(parseMethods, new Comparator<Method>() {
            public int compare(Method a, Method b) {
                return a.getParameterTypes().length - b.getParameterTypes().length;
            }
        });
        for (Method parse : parseMethods) {
            Object[] args = new Object[parse.getParameterTypes().length];
            Class<?>[] p = parse.getParameterTypes();
            args[0] = options; args[1] = argv;
            for (int i = 2; i < p.length; i++) {
                if (p[i] == boolean.class || p[i] == Boolean.class) args[i] = g.pick(2) == 0;
                else if (p[i] == java.util.Properties.class) args[i] = new java.util.Properties();
                else args[i] = value(p[i], g, 1, report);
            }
            try { return parse.invoke(parser, args); }
            catch (InvocationTargetException ignored) { }
        }
        throw new NoSuchMethodException("No successful public PosixParser.parse(Options,String[])");
    }
    /** Optional type recipes, shared across bugs; none contains a bug-specific expected answer. */
    private static Object chart(Class<?> t, Genes g, Observation report) throws Exception {
        String n = t.getName();
        if (!n.startsWith("org.jfree.")) return null;
        if (n.equals("org.jfree.data.Range")) {
            double a = g.next(), b = g.next();
            return t.getConstructor(double.class, double.class).newInstance(Math.min(a, b), Math.max(a, b));
        }
        if (n.equals("org.jfree.data.time.RegularTimePeriod"))
            return load("org.jfree.data.time.Day").getConstructor(int.class, int.class, int.class)
                .newInstance(1 + g.pick(28), 1 + g.pick(12), 1990 + g.pick(40));
        if (n.equals("org.jfree.data.time.TimeSeries")) {
            Object series = t.getConstructor(Comparable.class).newInstance("DE");
            Class<?> period = load("org.jfree.data.time.RegularTimePeriod");
            Constructor<?> day = load("org.jfree.data.time.Day")
                .getConstructor(int.class, int.class, int.class);
            Method add = t.getMethod("add", period, double.class);
            int count = 2 + g.pick(4), year = 1990 + g.pick(40);
            for (int i = 0; i < count; i++)
                add.invoke(series, day.newInstance(i + 1, 1, year), g.next() / 10.0);
            return series;
        }
        if (n.equals("org.jfree.data.category.CategoryDataset")
                || n.equals("org.jfree.data.category.DefaultCategoryDataset")) {
            Class<?> c = load("org.jfree.data.category.DefaultCategoryDataset");
            Object data = c.getConstructor().newInstance();
            Method add = c.getMethod("addValue", Number.class, Comparable.class, Comparable.class);
            int rows = 1 + g.pick(3), columns = 1 + g.pick(3);
            for (int r = 0; r < rows; r++) for (int col = 0; col < columns; col++)
                add.invoke(data, Double.valueOf(g.next() / 10.0), "R" + r, "C" + col);
            return data;
        }
        if (n.equals("org.jfree.data.xy.XYDataset") || n.equals("org.jfree.data.xy.XYSeriesCollection")) {
            Class<?> seriesClass = load("org.jfree.data.xy.XYSeries");
            Object series = seriesClass.getConstructor(Comparable.class).newInstance("DE");
            int count = 1 + g.pick(5);
            for (int i = 0; i < count; i++) seriesClass.getMethod("add", double.class, double.class)
                .invoke(series, (double)i, g.next() / 10.0);
            Class<?> c = load("org.jfree.data.xy.XYSeriesCollection");
            Object data = c.getConstructor().newInstance();
            c.getMethod("addSeries", seriesClass).invoke(data, series);
            return data;
        }
        if (n.equals("org.jfree.data.general.PieDataset") || n.equals("org.jfree.data.general.DefaultPieDataset")) {
            Class<?> c = load("org.jfree.data.general.DefaultPieDataset");
            Object data = c.getConstructor().newInstance();
            int count = 1 + g.pick(5);
            for (int i = 0; i < count; i++) c.getMethod("setValue", Comparable.class, Number.class)
                .invoke(data, "K" + i, Double.valueOf(g.next() / 10.0));
            return data;
        }
        return null;
    }
    static List<Method> setupMethods(Class<?> receiver) {
        List<Method> methods = new ArrayList();
        for (Method m : receiver.getMethods()) {
            String n = m.getName();
            if (!Modifier.isStatic(m.getModifiers()) && !m.isSynthetic()
                    && m.getParameterTypes().length <= 3 && !n.contains("Listener")
                    && (n.startsWith("set") || n.startsWith("add") || n.startsWith("update")
                        || n.startsWith("remove") || n.equals("clear"))) methods.add(m);
        }
        Collections.sort(methods, new Comparator<Method>() {
            public int compare(Method a, Method b) {
                return signature(a).compareTo(signature(b));
            }
        });
        return methods;
    }
    public static Observation execute(String target, String receivers, String signature, int[] genes) {
        Observation out = new Observation();
        try {
            Genes g = new Genes(genes);
            Method m = method(target, signature);
            Object receiver = null;
            if (!Modifier.isStatic(m.getModifiers())) {
                String[] choices = receivers.split(",");
                Class<?> receiverType = load(choices[g.pick(choices.length)]);
                receiver = value(receiverType, g, 0, out);
                if (receiver == null) throw new IllegalArgumentException("Receiver construction failed");
                // Compiler.compile owns a strict initialization sequence.
                // Random calls to its mutators before compilation can corrupt
                // state or spend the search budget on irrelevant setup.
                if (!receiverType.getName().equals("com.google.javascript.jscomp.Compiler")) {
                    List<Method> setup = setupMethods(receiverType);
                    int count = g.pick(5);
                    for (int i = 0; i < count && !setup.isEmpty(); i++) {
                        Method s = setup.get(g.pick(setup.size()));
                        try { s.invoke(receiver, arguments(s.getParameterTypes(), g, 0, out)); out.setupCalls++; }
                        catch (Exception e) { out.setupFailures++; }
                    }
                }
            }
            Object[] args = arguments(m, g, 0, out);
            out.reachedTarget = true;
            try {
                boolean jacksonSerialization = m.getDeclaringClass().getName().equals(
                    "com.fasterxml.jackson.databind.ser.BeanPropertyWriter")
                    && m.getName().startsWith("serializeAs") && g.jacksonGenerator != null;
                boolean arrayShape = m.getName().contains("Column")
                    || m.getName().contains("Element") || m.getName().contains("Placeholder");
                if (jacksonSerialization)
                    g.jacksonGenerator.getClass().getMethod(arrayShape
                        ? "writeStartArray" : "writeStartObject").invoke(g.jacksonGenerator);
                Object result = m.invoke(receiver, args);
                boolean closureCompile = m.getDeclaringClass().getName().equals(
                    "com.google.javascript.jscomp.Compiler") && m.getName().equals("compile");
                if (closureCompile) {
                    // Result is only a status object; the compiled JavaScript is
                    // the behavioral output that reveals whether an argument
                    // was removed from a globally exposed function.
                    Object js = receiver.getClass().getMethod("toSource").invoke(receiver);
                    out.token = "CLOSURE_SOURCE:" + stable(js, 0);
                } else if (jacksonSerialization) {
                    g.jacksonGenerator.getClass().getMethod(arrayShape
                        ? "writeEndArray" : "writeEndObject").invoke(g.jacksonGenerator);
                    g.jacksonGenerator.getClass().getMethod("flush").invoke(g.jacksonGenerator);
                    out.token = "JSON:" + Base64.getEncoder().encodeToString(
                        g.jacksonOutput.toString().getBytes(StandardCharsets.UTF_8));
                } else out.token = m.getReturnType() == void.class
                    ? state(receiver, m.getName()) : stable(result, 0);
            } catch (InvocationTargetException e) {
                if (e.getCause() instanceof VirtualMachineError || e.getCause() instanceof LinkageError
                        || e.getCause() instanceof ThreadDeath) throw e;
                out.token = "THROW:" + e.getCause().getClass().getName();
            }
        } catch (Throwable e) {
            out.token = "HARNESS_ERROR";
            out.error = e.getClass().getName() + ":" + String.valueOf(e.getMessage());
        }
        return out;
    }
    public static String run(String target, String receivers, String signature, int[] genes) {
        Observation o = execute(target, receivers, signature, genes);
        if (!o.reachedTarget || o.token.equals("HARNESS_ERROR"))
            throw new AssertionError("Cannot replay test: " + o.error);
        return o.token;
    }
    private static String state(Object receiver, String method) {
        if (receiver == null) return "VOID";
        List<String> getters = new ArrayList();
        if (method.startsWith("set") && method.length() > 3) {
            getters.add("get" + method.substring(3)); getters.add("is" + method.substring(3));
        }
        getters.addAll(Arrays.asList("getItemCount", "getRowCount", "getColumnCount", "getSeriesCount"));
        StringBuilder s = new StringBuilder("VOID");
        for (String name : getters) {
            try {
                Method getter = receiver.getClass().getMethod(name);
                if (getter.getReturnType().isPrimitive() || getter.getReturnType() == String.class)
                    s.append('|').append(name).append('=').append(stable(getter.invoke(receiver), 0));
            } catch (ReflectiveOperationException ignored) { }
        }
        return s.toString();
    }
    /** Only whitelisted value types are rendered. Never use arbitrary object toString(). */
    static String stable(Object value, int depth) {
        if (value == null) return "NULL";
        Class<?> t = value.getClass();
        if (value instanceof String || value instanceof Boolean || value instanceof Character
                || value instanceof Byte || value instanceof Short || value instanceof Integer
                || value instanceof Long || value instanceof Float || value instanceof Double
                || value instanceof java.math.BigInteger || value instanceof java.math.BigDecimal)
            return t.getName() + ":" + Base64.getEncoder().encodeToString(value.toString().getBytes(StandardCharsets.UTF_8));
        if (value instanceof Enum) return "ENUM:" + t.getName() + ":" + ((Enum<?>)value).name();
        if (t.isArray() && depth < 3) {
            StringBuilder s = new StringBuilder("ARRAY:" + t.getName() + ":" + Array.getLength(value));
            for (int i = 0; i < Math.min(64, Array.getLength(value)); i++) {
                String item = stable(Array.get(value, i), depth + 1);
                s.append(':').append(item.length()).append(':').append(item);
            }
            return s.toString();
        }
        if (value instanceof java.awt.Color) return "COLOR:" + ((java.awt.Color)value).getRGB();
        // Observe safe scalar properties of returned objects. This catches
        // changes to value caches and state while avoiding identity-based toString().
        StringBuilder observed = new StringBuilder("STATE:" + t.getName());
        int properties = 0;
        for (String name : Arrays.asList("getItemCount", "getMinY", "getMaxY",
                "getRowCount", "getColumnCount", "getSeriesCount")) {
            try {
                Method getter = t.getMethod(name);
                Class<?> r = getter.getReturnType();
                if (!r.isPrimitive() && r != String.class && !Number.class.isAssignableFrom(r))
                    continue;
                if (r == void.class) continue;
                Object result = getter.invoke(value);
                String token = stable(result, depth + 1);
                observed.append('|').append(name).append('=').append(token.length())
                    .append(':').append(token);
                properties++;
            } catch (Exception ignored) { }
        }
        return properties == 0 ? "TYPE:" + t.getName() : observed.toString();
    }
    public static void main(String[] args) {
        if (args.length > 4) {
            String source = new String(Base64.getDecoder().decode(args[4]), StandardCharsets.UTF_8);
            System.setProperty("de.generated.source", source);
        }
        String[] encodedGenes = args[3].split(",");
        int[] genes = new int[encodedGenes.length];
        for (int i = 0; i < encodedGenes.length; i++) genes[i] = Integer.parseInt(encodedGenes[i]);
        boolean closureCompile = args[0].equals("com.google.javascript.jscomp.Compiler")
            && args[2].startsWith("compile(");
        // Compiler.compile is an expensive whole-program operation. Fixed-side
        // suites are still executed twice by the runner, so capture its oracle
        // once here instead of launching three compilations just to check the
        // same deterministic source output.
        int repetitions = closureCompile ? 1 : 3;
        for (int i = 0; i < repetitions; i++) {
            Observation out = execute(args[0], args[1], args[2], genes);
            System.out.println("DE_TOKEN:" + Base64.getEncoder().encodeToString(out.token.getBytes(StandardCharsets.UTF_8)));
        }
    }
}

public class DEGeneratedTest {
    @org.junit.Test(timeout=60000L)
    public void testDE00000() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(boolean):org.apache.commons.lang.text.StrBuilder",
            new int[]{683,524,-612,-548,-1000,-965,-248,869,-684,-580,1000,-828,1000,106,346,-145,-633,-165,-1000,-1000,-280,-1000,-107,-897,864,-773,622,-294,-609,-1000,-1000,142,1000,385,419,-1000,-558,-392,1000,-1000,-1000,710,108,-707,-1000,1000,-303,494,255,-161,-703,1000,503,-1000,1000,-544,1000,1000,-1000,-703,-794,-1000,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00001() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(boolean):org.apache.commons.lang.text.StrBuilder",
            new int[]{730,-681,-696,-819,-1000,-740,-791,400,-523,-214,1000,198,1000,32,-296,-414,-467,-416,-1000,-659,-53,-1000,37,-718,799,-970,1000,878,-576,-400,-811,132,197,-92,779,-532,-883,516,1000,-1000,-874,922,-1000,-791,-120,225,-732,-520,-158,1000,-772,1000,410,-1000,1000,832,1000,812,-727,-400,-203,-1000,-400,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00002() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(boolean):org.apache.commons.lang.text.StrBuilder",
            new int[]{85,416,1000,-340,808,803,464,119,-848,-626,-711,329,-3,-389,-26,1000,671,-85,835,-105,340,610,-954,277,-98,664,-1000,53,-206,1000,508,-364,-46,-265,610,-370,-784,-951,-438,837,-801,751,-370,468,-224,-532,1000,-342,-651,-1000,-302,802,-626,748,-856,-369,-538,-28,-886,-414,-250,469,-35,-419}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00003() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(boolean):org.apache.commons.lang.text.StrBuilder",
            new int[]{778,-1000,-176,-1000,-866,-531,-948,-686,-144,731,531,-995,-278,-603,-1000,912,-36,964,-140,-361,-57,-834,-292,-500,1000,-1000,644,583,248,-33,-451,-1000,3,1000,1000,-1000,-1000,533,1000,-136,397,-578,130,1000,-1000,739,637,749,-1000,-404,-1000,-214,315,-235,1000,543,1000,276,130,811,1000,-94,763,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00004() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(boolean):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,469,1000,222,699,167,67,935,-768,-1000,-156,1000,807,21,1000,-298,397,-1000,256,735,190,755,-793,428,-676,853,-30,465,-261,-1000,269,-39,538,-460,-193,366,43,-1000,-972,226,641,1000,-841,-871,987,-77,-22,-703,600,-575,-41,1000,-352,184,-693,-691,-475,533,-781,-1000,-1000,518,-1000,224}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00005() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(boolean):org.apache.commons.lang.text.StrBuilder",
            new int[]{-790,-559,497,-507,252,-247,54,183,-472,-726,824,862,312,-386,-293,852,-513,-414,-913,-164,560,-438,-753,75,378,-31,-634,779,-149,400,249,-49,-1000,-330,703,-924,-1000,-1000,713,351,-112,1000,-225,78,-370,-1000,168,-824,-675,-69,-790,1000,144,-176,426,-1000,-683,824,-1000,-589,-374,-771,-324,-931}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00006() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{488,-1000,-957,-1000,-651,589,499,919,-1000,-375,-922,908,-645,-437,194,-1000,-278,-242,-287,-1000,-1000,-1000,743,-405,-769,-1000,153,1000,805,1000,138,914,1000,933,659,435,-1000,-439,1000,284,435,1000,-587,-869,-337,-864,-211,869,-421,723,265,-701,332,326,-1000,-71,-1000,-373,-968,856,-894,-1000,-70,-847}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00007() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-967,216,-863,801,667,949,874,497,-311,71,-530,-260,638,281,-454,411,87,926,981,832,232,277,-980,-597,505,-29,-856,-340,-377,-162,171,-824,679,-47,719,-967,-515,-779,96,-316,-801,30,994,948,487,628,-95,602,-53,713,129,-408,330,-548,-577,204,220,654,-137,751,252,-861,-639,259}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00008() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-1000,-375,-970,-72,298,264,866,-863,61,-787,526,-66,71,855,-1000,-201,-80,-328,-988,-1000,-1000,741,535,-639,-1000,-1000,773,402,959,-705,231,757,440,140,703,-501,-486,1000,-422,536,1000,-88,-76,-340,-269,-691,663,-714,-172,2,-7,106,-91,-1000,334,-951,-772,-344,825,-16,-1000,-112,49}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00009() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{121,-836,-76,162,-104,-43,512,-338,230,85,-891,-47,369,712,-1000,328,-420,953,1000,-487,-359,-369,1000,-1000,-254,-1000,610,574,-99,-159,119,-963,-910,1000,-881,1000,-923,-623,-1000,-606,-504,-260,1000,132,-1000,-1000,934,-100,1000,1000,484,-168,492,213,-703,-405,86,-136,-912,291,-843,-1000,338,-647}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00010() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,92,-175,464,1000,-111,981,1000,608,-205,74,-584,1000,936,-418,-1000,-268,289,-96,-898,1000,478,-207,-468,-264,-1000,358,5,-238,-773,842,-450,-843,-239,483,216,-7,405,-1000,157,-801,1000,106,1000,-410,296,-369,40,86,-97,-19,-995,-516,1000,-1000,-1000,-1000,-1000,-221,-602,-1000,-263,-22,842}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00011() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{683,321,918,-168,-770,-419,-254,371,551,-375,234,-959,46,394,-782,-516,-396,-899,-228,15,743,101,-979,146,-580,146,122,-853,663,292,138,601,458,-684,240,215,831,982,-440,224,-13,745,-634,676,503,539,-233,-404,-895,-785,-918,557,-673,837,201,-434,-485,-373,820,-679,-979,592,-758,-127}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00012() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{645,17,236,653,816,-302,-22,262,147,-403,-476,78,507,880,822,924,-62,-425,461,720,855,886,309,365,-71,389,-801,-621,-675,-402,404,-999,-855,-21,-756,705,533,-33,-829,-797,-268,-201,939,946,-411,-983,40,-192,487,-566,525,-752,-512,-1,490,537,592,-461,82,-155,464,677,688,932}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00013() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{913,-1000,-224,-48,1000,14,-168,1000,-791,-370,-961,949,-604,373,1000,-95,288,-1000,516,136,-1000,-388,1000,741,-1000,-28,-1000,497,-643,534,-693,-191,384,742,-152,1000,-23,-1000,1000,-468,459,838,495,99,-476,-1000,-618,1000,-111,403,904,-248,131,-792,-277,1000,163,-408,-301,898,1000,289,817,773}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00014() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(char[]):org.apache.commons.lang.text.StrBuilder",
            new int[]{-563,-79,490,-436,-756,934,-355,265,322,886,-498,877,103,190,-65,-489,-1000,1000,-400,101,-653,246,421,108,137,847,-897,425,-93,-190,1000,-548,874,-386,1000,-139,-767,-1000,1000,768,668,671,-246,-1000,56,10,14,-645,581,490,524,-491,-741,1000,229,1000,93,-420,203,-76,-400,-1000,890,60}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00015() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(char[]):org.apache.commons.lang.text.StrBuilder",
            new int[]{-101,681,-486,-129,659,626,925,952,578,413,-489,-719,879,942,-156,-589,-235,-866,88,484,-193,-293,276,485,985,398,-693,-999,11,170,-931,949,887,131,285,933,182,-317,-120,747,957,-205,23,900,-80,-860,296,967,955,-619,917,-894,955,855,398,100,596,-445,-412,-40,-456,434,-355,-737}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00016() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(char[]):org.apache.commons.lang.text.StrBuilder",
            new int[]{-447,889,10,804,682,-703,258,707,-537,-49,657,364,383,-172,197,-84,-680,478,786,198,-381,-743,539,368,635,717,-181,367,-420,653,181,-876,861,513,-497,-340,603,-336,866,59,-491,-656,6,647,846,-942,545,675,-56,-375,-363,286,-673,-873,-885,-382,-647,608,830,530,72,-474,-575,-395}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00017() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(char[]):org.apache.commons.lang.text.StrBuilder",
            new int[]{393,374,-161,533,-935,524,505,-316,488,392,-588,-66,-264,-82,-662,700,-1000,231,-597,485,-6,-511,1000,-14,-1000,-1000,-687,-1000,389,14,248,-836,320,-250,264,-204,362,114,328,1000,273,863,892,211,-686,135,6,224,376,-1000,620,-542,272,741,389,357,-485,-55,-1000,-604,-428,-1000,-244,501}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00018() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(char[]):org.apache.commons.lang.text.StrBuilder",
            new int[]{324,-484,-1000,-270,-920,1000,-378,451,748,1000,462,-758,356,283,-234,-914,-1000,1000,-94,1000,349,749,1000,400,-204,510,-495,327,-292,685,1000,-1000,666,-935,1000,-806,942,-1000,243,1000,323,1000,523,-1000,241,943,285,-701,581,831,810,-1000,-1000,1000,389,-1000,7,-129,578,808,-220,-377,1000,410}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00019() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(char[]):org.apache.commons.lang.text.StrBuilder",
            new int[]{-795,-487,-673,1000,761,-1000,797,-848,169,-131,558,1000,177,-667,-684,241,-482,1000,455,1000,1000,1000,393,502,485,1000,-290,139,-250,-531,1000,-609,1000,-72,457,-785,1000,-1000,-1000,-162,634,-411,-303,-891,292,-762,514,1000,727,874,-1000,-1000,-1000,-860,-749,1000,60,-895,715,1000,-496,1000,37,-511}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00020() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(char[]):org.apache.commons.lang.text.StrBuilder",
            new int[]{-400,-1000,-258,-1000,194,234,-269,102,-508,-107,573,104,-560,1000,-888,94,-669,983,1000,-279,404,-276,414,-1000,-1000,-890,-466,-606,710,1000,1000,-56,-407,465,384,-1000,893,-1000,-245,-31,-350,1000,502,-414,236,-29,285,-257,-819,414,-355,34,-289,-399,1000,357,-1000,560,1000,369,1000,232,-301,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00021() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(char[]):org.apache.commons.lang.text.StrBuilder",
            new int[]{-364,-1000,784,-600,-948,582,-583,860,345,1000,-740,976,-29,-28,161,-1000,-1000,728,-421,-151,-209,1000,-244,1000,60,509,-19,1000,-432,462,807,-63,-115,-1000,1000,-1000,1000,-850,-1000,717,1000,1000,-4,292,-970,963,-330,-1000,-755,1000,-116,-1000,-1000,1000,689,322,214,-1000,1000,-540,-145,-1000,940,198}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00022() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(char[],int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{59,371,250,-409,673,29,618,-1000,-1000,-1000,1000,345,-309,838,-1000,-862,572,258,-301,-1000,-889,-1000,116,45,-1000,-1000,-173,-590,1000,1000,-1000,104,-1000,-389,396,639,1000,-760,944,1000,-141,936,-1000,-236,1000,630,-1000,186,-1000,528,1000,442,-1000,-1000,1000,760,-1000,-275,343,-67,480,-1000,-217,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00023() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(char[],int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{366,891,23,47,-246,556,-536,-912,-689,-778,311,-725,669,415,582,-940,507,55,-379,-813,35,-966,-945,774,737,-801,-652,872,132,-259,727,915,-819,343,-859,117,-503,-124,-522,606,-526,897,-721,-204,124,780,837,393,-491,-97,-233,-731,-605,-16,-144,-574,-929,-585,-650,284,-952,-767,686,586}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00024() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(char[],int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{436,371,23,248,684,603,866,-341,-396,-1000,1000,-187,-330,1000,-232,-845,572,483,659,-1000,-701,-858,169,56,-54,-482,-1000,-935,328,1000,-1000,86,-786,-146,-238,172,1000,-580,720,858,-190,936,-124,-236,923,-477,-467,-392,-975,375,1000,442,-872,-1000,864,689,-1000,-477,-246,-506,-511,-943,-314,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00025() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(char[],int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-1000,433,1000,1000,99,15,-544,-306,28,1000,-586,-932,853,-1000,1000,420,60,-1000,-149,-218,157,-921,-99,-1000,-146,759,604,897,1000,-108,771,-40,-923,651,-231,1000,-180,322,-60,-621,-284,-369,-41,-1000,1000,-888,-1000,-110,-1000,672,410,-1000,1000,781,-766,550,-1000,346,-1000,-654,801,-894,681}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00026() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(char[],int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{370,-41,-1000,-665,-378,722,931,860,704,77,-786,-172,853,582,-763,-292,-836,825,1000,889,274,-120,-12,-902,-338,824,-526,187,-443,533,-1000,334,13,9,510,-524,400,383,457,300,-543,355,-25,135,142,296,-167,-574,-204,-639,-1000,-334,138,-377,-626,-33,-400,-1000,-1000,-22,506,80,-17,-449}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00027() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(char[],int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{439,-1000,-676,-1000,1000,1000,332,-188,-439,451,-910,-197,-696,1000,138,-38,768,-428,-1000,-1000,-203,-76,-428,712,-108,-616,-168,842,1000,66,-1000,178,-66,-74,68,897,-805,-220,1000,-187,-732,-479,-540,253,-20,-236,-640,-703,40,1000,1000,-228,-598,-267,681,921,-38,387,727,-841,-808,-476,404,899}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00028() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(char[],int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-452,176,-1000,-680,-1000,538,-76,402,922,235,-995,746,1000,-425,371,-584,-844,-157,965,932,54,-132,674,-710,341,733,-361,-151,-1000,744,-39,-339,261,-39,426,438,-1000,44,525,-445,764,-523,702,735,-4,-479,-111,-72,778,539,-1000,-43,605,-951,-666,423,-40,-587,-753,-470,-1000,-613,-152,-669}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00029() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(char[],int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-118,832,1000,1000,-926,1000,-627,-693,-917,1000,-776,-1000,801,-858,-195,607,1000,561,-996,-518,-1000,-681,723,463,327,207,-182,278,790,-1000,590,-400,-1000,367,219,1000,-45,-458,400,-302,246,-540,-555,400,204,-147,-316,-1,-4,1000,639,-1000,-83,1000,-609,-400,-63,232,-373,-978,-372,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00030() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(double):org.apache.commons.lang.text.StrBuilder",
            new int[]{-555,-436,444,-1000,858,-107,-226,-799,411,1000,-562,757,574,35,146,1000,-261,564,-677,-914,-534,-285,-1000,7,1000,-888,371,348,-1000,1000,-888,705,-720,81,264,-1000,373,-33,310,1000,616,1000,-612,39,-1000,1000,-622,-69,225,-395,-1000,86,88,1000,-877,-1000,216,4,-1000,-728,1000,140,126,953}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00031() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(double):org.apache.commons.lang.text.StrBuilder",
            new int[]{-256,-177,688,89,-1000,513,1000,707,327,445,254,-75,1000,762,-846,640,-174,-9,-508,-395,307,701,-1000,824,989,438,-1000,-967,559,258,-794,-768,1000,-390,124,-55,993,-818,175,-1000,-205,649,14,395,-65,1000,567,-8,1000,1000,52,-123,31,726,270,1000,-192,473,-406,-890,921,1000,-579,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00032() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(double):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,37,-301,4,808,-141,-464,-895,-434,447,82,320,696,258,743,645,600,1000,114,-214,230,-843,-808,622,633,551,-472,722,-1000,507,113,-464,284,141,-889,927,550,-954,740,849,217,972,-197,-11,-100,1000,775,707,814,247,-527,-5,1000,11,-676,85,-856,-818,-577,583,998,969,-257,904}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00033() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(double):org.apache.commons.lang.text.StrBuilder",
            new int[]{583,-277,-154,62,-707,514,-582,927,-728,-983,-538,-777,321,-124,-53,-761,779,-429,285,1000,299,-300,745,18,317,-385,-577,-805,326,-131,111,-570,58,-278,-529,700,260,466,168,-895,-483,-882,268,-855,521,-1000,-677,200,-741,719,944,-1000,503,542,-311,-137,-391,253,749,930,-783,-357,187,-438}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00034() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(double):org.apache.commons.lang.text.StrBuilder",
            new int[]{-176,-1000,112,943,1000,354,284,417,-1000,-1000,-167,-1000,129,-11,-23,-1000,1000,-173,-423,905,-382,20,89,592,1000,-523,-140,-387,-1000,18,355,1000,-508,-18,-460,885,-390,582,1000,-1000,59,177,681,-740,301,-452,-1000,864,-500,-435,539,-1000,378,1000,-497,-569,1000,-715,1000,-1000,-1000,-555,168,278}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00035() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(double):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,141,-701,436,-456,-553,-232,-988,-622,-281,-615,304,794,327,1000,536,676,1000,-309,238,-98,-805,258,1000,383,616,260,1000,-322,-31,-158,315,-1000,66,-312,310,-84,-458,171,1000,-333,1000,99,-541,433,156,1000,-1000,-163,497,-1000,488,1000,224,-46,853,976,-152,97,375,234,-539,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00036() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(double):org.apache.commons.lang.text.StrBuilder",
            new int[]{405,-964,-607,1000,-427,897,-531,552,-419,-1000,-800,-963,342,148,1000,-1000,1000,-736,411,258,823,-187,441,275,422,-540,-7,-398,-39,833,-301,-1000,491,218,-1000,1000,249,152,414,-1000,23,-488,-771,-766,800,1000,-348,-52,-855,368,1000,-296,649,-74,-362,82,-659,-297,-503,1000,-491,-437,531,-287}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00037() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(float):org.apache.commons.lang.text.StrBuilder",
            new int[]{-847,-286,-911,461,967,-561,353,-688,771,762,-243,25,-407,301,-826,836,-800,124,120,-780,-854,741,686,822,-774,292,-810,716,-249,70,506,-296,-754,427,732,40,-69,-955,123,-306,-347,-403,-889,78,827,868,-425,-991,372,596,-435,617,-378,447,151,881,-216,845,224,-458,619,690,681,230}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00038() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(float):org.apache.commons.lang.text.StrBuilder",
            new int[]{883,-492,144,369,-515,-946,246,50,1000,-273,-416,-427,852,-1000,735,-839,1000,-1000,-550,1000,-1000,-867,-186,-915,1000,790,714,1000,357,-1000,977,-100,1000,-766,191,-948,-489,-286,1000,207,346,159,67,-448,1000,-613,-1000,-448,207,-40,1000,-390,-219,-590,539,-35,174,-260,831,-362,-583,-255,-128,387}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00039() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(float):org.apache.commons.lang.text.StrBuilder",
            new int[]{-310,-1000,140,-785,-298,631,948,-16,-836,-1000,771,354,-469,-897,885,144,807,109,-853,-431,1000,117,975,-977,-176,615,-50,-938,110,1000,-318,1000,-580,471,-401,621,616,942,-931,-730,-625,848,735,-717,-3,249,602,873,-44,-876,-784,613,1000,207,215,-651,1000,-1000,-1000,162,-242,-1000,709,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00040() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(float):org.apache.commons.lang.text.StrBuilder",
            new int[]{366,1000,-30,907,-97,-577,556,-582,1000,263,-558,-653,301,-204,-207,703,-82,250,386,653,-1000,213,1000,-44,19,822,-1000,1000,-1000,-1000,879,615,-635,-1000,504,-1000,-1000,-754,-386,740,1000,-1000,1000,-493,520,-472,-806,-584,-69,192,373,-214,997,-396,898,94,132,551,1000,565,454,1000,-565,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00041() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(float):org.apache.commons.lang.text.StrBuilder",
            new int[]{-203,-556,-306,-591,419,-40,495,202,-180,-1000,725,-329,-737,-1000,-394,190,769,-303,-69,-276,416,284,1000,298,-343,811,-203,264,500,349,248,93,-495,1000,755,412,999,-1000,-145,-244,-841,1000,-587,37,-24,253,171,425,323,-798,-771,1000,35,1000,-379,665,149,-801,-864,-166,-309,183,867,-658}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00042() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(float):org.apache.commons.lang.text.StrBuilder",
            new int[]{135,1000,-1000,137,789,284,-720,621,1000,52,681,-1000,-545,704,-1000,775,583,268,1000,436,-1000,1000,425,1000,-592,467,-291,947,-712,-1000,1000,-100,-481,695,1000,-1000,81,-1000,499,1000,555,-83,-1000,372,1000,-322,-1000,-991,317,-303,-343,1000,-1000,-432,-547,-35,383,1000,797,133,535,1000,-228,481}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00043() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(float):org.apache.commons.lang.text.StrBuilder",
            new int[]{-297,-613,-306,839,923,-920,-501,-600,-386,-518,534,-976,168,292,629,819,-126,814,-570,138,227,-888,-712,982,52,-194,-592,-63,-634,411,255,636,-871,-929,-115,412,-224,-564,-809,542,721,-514,891,274,-71,175,-532,710,-943,906,286,-476,-290,53,-405,-523,-124,31,-725,765,764,-286,788,-682}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00044() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(float):org.apache.commons.lang.text.StrBuilder",
            new int[]{-991,-1000,-80,-1000,-594,131,957,-93,-1000,-1000,813,472,-648,-579,786,733,924,-126,-1000,-1000,-1000,117,1000,-655,1000,872,579,-1000,534,1000,-773,1000,-1000,1000,-490,1000,1000,1000,-1000,-1000,-1000,783,1000,-1000,836,844,1000,1000,-131,-1000,-1000,1000,1000,-142,720,-1000,1000,921,1000,-518,-633,-1000,207,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00045() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,727,87,-14,714,1000,717,-1000,1000,-446,-43,-674,676,812,-973,251,-851,-213,777,-184,-712,-445,777,-710,-472,41,841,-323,6,1000,-518,539,-1000,-809,563,-1000,814,-365,-1000,863,-1000,223,-924,-18,-514,137,803,685,482,382,1000,-473,709,-391,559,-5,199,-257,-20,457,-1000,-667,-972,-981}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00046() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-532,89,-111,-371,243,-776,-506,961,-1000,-1000,1000,511,-172,-1000,-38,-448,-1000,-166,-416,-517,1000,362,313,301,-1000,1000,-434,528,-342,1000,-599,-751,887,1000,-67,59,-194,748,-320,-252,-665,1000,523,-165,-1000,204,-158,300,-1000,-9,-212,-975,616,-381,-72,872,661,-74,629,-859,-790,480,481,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00047() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-532,414,304,-488,-274,-514,-49,979,-1000,-917,-72,85,24,-710,-497,-258,-1000,-114,-303,523,1000,-169,-815,726,739,318,250,1000,369,360,910,-272,-368,380,883,941,-374,558,736,-132,920,902,-73,886,-1000,137,-158,-340,-170,-1000,1000,121,-632,-196,272,872,-525,692,92,1000,95,568,481,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00048() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-640,1000,-315,-560,829,-803,1000,994,430,1000,311,-178,508,-1000,-704,-29,661,458,-75,-775,250,1000,366,1000,330,485,-798,-59,739,83,1000,-481,1000,-175,790,-953,420,-40,983,-306,-262,798,-1000,1000,818,-992,1000,-212,194,-1000,-1000,1000,-1000,-464,-827,-359,811,1000,-97,551,275,-777,925,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00049() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-1000,-750,733,-87,-821,-621,-231,-1000,-715,649,772,-386,-497,317,-1000,811,-330,-436,-510,257,-23,-655,586,641,279,-836,407,-1000,-878,-744,-414,7,660,-856,1000,-731,-610,-637,213,-295,-15,941,-1000,-109,521,-73,-1000,-259,729,208,368,442,-22,-156,90,174,-1000,101,322,-305,136,730,521}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00050() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-1000,-1000,1000,604,-1000,108,-659,-98,-468,628,1000,-763,-1000,176,-1000,1000,-1000,-501,-1000,106,1000,-655,586,663,568,-1000,821,-1000,-878,-432,-1000,-400,-551,-1000,-787,-313,-60,-1000,211,-1000,311,890,-1000,508,-195,1000,-562,-711,1000,-479,-531,1000,-241,-1000,-817,1000,-551,-17,126,-948,136,583,991}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00051() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,524,176,-14,-174,323,-115,-14,168,-551,-470,-518,588,112,-497,251,-704,233,289,-94,1000,-86,111,-568,135,1000,888,767,147,862,-103,247,-368,-486,454,-459,335,676,-358,213,-233,1000,-364,-72,-1000,137,243,89,76,267,949,-276,709,-548,366,-297,-484,-427,-41,108,204,51,-713,106}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00052() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{232,275,-906,-21,-37,474,-257,659,722,380,696,614,0,144,-58,-155,-280,1000,-525,-205,351,-928,410,53,919,633,304,-422,-10,761,-67,1000,1000,-693,402,265,-691,-815,1000,924,-184,667,595,827,581,867,191,-447,704,226,-71,-268,-431,5,-1000,-49,1000,-872,-584,551,-692,437,691,576}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00053() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.Object):org.apache.commons.lang.text.StrBuilder",
            new int[]{-362,418,-816,-541,-611,687,653,-829,458,681,-236,505,-218,434,-217,-114,-441,631,-534,-400,-677,-116,570,91,-136,-572,472,508,-666,204,336,-114,151,-258,-116,-788,676,137,448,-852,86,-52,709,-820,323,-101,262,-433,-436,894,-979,-367,-731,-956,-680,654,-479,163,570,875,-860,-508,-692,47}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00054() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.Object):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-394,634,-126,101,363,1000,1000,-293,-406,-542,459,-1000,288,-690,-73,-840,-1000,-337,605,-913,-1000,1000,76,-113,-883,284,-967,-1000,-465,-216,-1000,1000,532,1000,68,783,-1000,-311,90,-579,-587,-667,-420,123,795,725,-992,-834,426,269,-1000,917,-174,115,1000,-491,-596,1000,635,770,915,-862,805}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00055() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.Object):org.apache.commons.lang.text.StrBuilder",
            new int[]{-192,357,-816,466,28,388,1000,-63,117,427,-236,505,-710,271,-1000,-774,-1000,-124,-1000,1000,-151,-1000,778,327,-399,-375,-46,-520,-497,-526,-619,-1000,480,262,1000,-593,590,-1000,-1000,-506,86,-52,-461,-835,814,580,657,-603,263,206,910,296,-1000,1000,-92,1000,380,-687,1000,392,-860,-508,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00056() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.Object):org.apache.commons.lang.text.StrBuilder",
            new int[]{-362,53,764,585,65,-1000,138,1000,287,-240,-1000,-206,470,-219,-1000,-761,405,-958,-534,1000,1000,-1000,425,-848,-1000,-556,339,39,223,-1000,-856,-1000,-620,899,1000,-316,140,-1000,-1000,267,823,-52,-586,-895,323,1000,1000,-1000,980,894,-1000,1000,-731,-956,-296,1000,-140,-286,-258,-1000,1000,426,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00057() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.Object):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-303,433,852,204,-757,277,-4,277,400,-1000,619,-1000,1000,-1000,-284,1000,1000,-1000,1000,-317,-530,-607,46,-1000,-1000,92,-478,-741,252,-65,531,-821,1000,731,35,393,-371,-949,-1000,1000,816,1000,-412,1000,224,1000,-714,-806,-1000,-1000,1000,-1000,1000,1000,1000,122,-259,1000,-921,197,-520,-1000,-2}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00058() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.Object):org.apache.commons.lang.text.StrBuilder",
            new int[]{-362,125,-816,-307,120,212,397,732,169,482,-77,1000,-1000,22,451,728,-381,-962,-33,-1000,831,-662,570,399,863,-572,-348,-1000,1000,328,-1000,644,823,-17,818,-289,824,-518,-1000,1000,-114,-813,676,-1000,-643,787,1000,-654,116,437,-907,-951,1000,-1000,413,-915,-383,-421,-1000,681,204,-200,-1000,-37}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00059() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.Object):org.apache.commons.lang.text.StrBuilder",
            new int[]{877,-496,174,336,622,250,-671,124,-431,-834,-828,52,10,801,-907,-997,711,-481,-229,-330,403,217,39,-989,204,667,3,-640,714,129,781,756,795,289,823,-115,-556,-529,392,568,-448,-385,-493,716,864,-445,421,-711,976,-237,-478,-45,-164,921,-550,-149,878,-588,166,149,658,-823,-257,-37}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00060() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.Object):org.apache.commons.lang.text.StrBuilder",
            new int[]{964,517,-374,909,-911,879,-424,-1000,-184,1000,279,-1000,258,-492,454,506,1000,640,548,-516,944,-116,-738,1000,113,-806,-605,1000,-666,204,-701,584,-1000,365,-197,673,666,137,157,-615,-1000,513,298,844,-609,-19,262,-433,-1000,-386,-1000,1000,640,-956,680,291,-1000,927,94,-1000,-679,1000,-339,-791}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00061() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.Object):org.apache.commons.lang.text.StrBuilder",
            new int[]{631,-1000,1000,-357,-921,-1000,21,841,433,-359,-981,986,-1000,1000,-944,323,1000,26,-449,103,685,-337,39,-627,47,-1000,-956,-1000,358,271,-259,1000,-964,796,849,279,716,-346,-162,-423,119,575,1000,511,338,762,1000,-691,-203,-1000,-666,74,-251,-253,679,1000,-1000,-116,90,-1000,718,-362,-950,-559}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00062() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{23,-301,-486,-706,718,-806,48,-412,-400,-477,-216,-961,-617,912,-949,-738,-343,-703,988,222,132,-697,83,374,777,739,-327,-837,255,994,192,796,-321,-836,-546,686,417,-210,681,63,463,680,-425,-160,-297,436,323,36,284,-955,114,-194,301,-849,464,-580,968,506,-536,-548,-433,-528,-90,-166}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00063() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-864,162,358,229,-131,1000,-906,-1000,833,1000,1000,409,733,1000,176,261,349,525,646,-829,-945,963,-663,-1000,-474,488,675,-955,-545,-934,-930,-504,-670,1000,-666,-671,-1000,338,-1000,776,-363,-1000,-721,189,1000,858,154,1000,-114,369,-370,-770,68,1000,-153,-828,1000,5,1000,-1000,-116,-163,86,555}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00064() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{766,-1000,215,-503,690,-871,-736,-671,60,-1000,-804,725,-926,841,-769,376,-310,-284,379,-144,-1000,-261,-1000,-478,-579,-1000,208,1000,923,1000,1000,-263,-379,328,-983,-1000,219,-778,1000,-1000,383,568,-1000,-973,62,-1000,-156,-194,1000,1000,-1000,-14,465,1000,1000,99,854,368,-1000,1000,-646,336,-295,-701}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00065() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,340,-1000,-582,-14,-853,226,-438,-335,923,1000,-1000,321,683,51,-787,-179,-441,1000,238,819,-387,1000,1000,1000,1000,-285,-1000,-370,-85,-1000,-1000,-411,-966,614,1000,-86,620,-719,1000,-505,-322,208,372,360,1000,734,872,-1000,-1000,1000,-221,-665,-1000,-936,-1000,1000,92,790,523,295,-63,716,324}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00066() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,788,-368,-513,322,-11,-565,-667,597,105,1000,647,694,-1000,1000,-344,-1000,-532,251,357,-179,-362,880,470,374,-539,-1000,636,1000,-1000,-1000,611,96,-1000,1000,75,1000,941,-248,-1000,327,-204,1000,-554,-341,522,195,-62,-1000,-933,497,1000,940,-316,804,120,-28,-433,-720,523,-655,264,-156,-644}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00067() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-1000,956,-423,1000,830,-876,315,767,-522,-899,131,-234,1000,-1000,-128,989,-162,-1000,-1000,-443,748,-1000,-726,-762,-528,487,961,410,1000,416,-68,1000,1000,-1000,-1000,-180,90,565,-740,-148,-709,-1000,-721,34,-901,-668,384,1000,1000,-935,-1000,-441,1000,564,343,-295,634,-288,1000,-773,-802,756,-496}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00068() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{995,-1000,1000,252,208,-795,-691,61,-405,-695,-790,1000,-866,629,-1000,-1000,-5,27,-462,-712,351,-574,-1000,-1000,-1000,-1000,-60,1000,710,767,381,128,216,89,-1000,-1000,702,-390,1000,-864,-643,1000,-1000,-886,-39,-1000,-172,336,1000,980,-945,-793,151,-19,1000,688,-801,-288,-1000,281,676,-367,0,-22}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00069() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.String,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{142,-1000,-121,-909,1000,23,-228,-488,413,-488,519,-338,-1000,-917,1000,-812,-850,-786,409,-587,990,1000,1000,-369,-996,52,30,-489,-488,1000,11,237,-488,1000,490,-685,-1000,-1000,-1000,625,-1000,-711,924,518,-218,1000,1000,-417,1000,418,68,91,-474,-1000,1000,-995,1000,1000,-234,725,1000,591,389,-171}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00070() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.String,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{130,-189,914,-951,1000,964,-476,-488,-773,247,922,-904,-1000,-68,297,-617,214,-573,-28,-324,948,547,-157,-672,-845,390,872,618,-277,1000,-879,-903,-844,841,152,-1000,-284,-643,-1000,-544,-1000,-776,-900,452,698,111,796,279,766,558,-1000,27,-378,195,133,-494,1000,989,958,1000,733,1000,-591,923}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00071() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.String,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{501,-1000,109,-793,860,1000,-460,41,165,355,873,-91,-869,115,889,-1000,-1000,-1000,-15,-401,940,344,1000,-124,-284,865,-670,-1000,-771,924,135,487,-522,659,852,-700,-385,-763,-647,246,-925,-781,-632,-14,984,1000,397,224,387,202,-536,-184,2,-656,785,-1000,765,1000,49,380,557,-205,391,-541}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00072() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.String,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-403,376,1000,-725,334,80,702,-1000,-521,-599,-348,-1000,137,558,-1000,-121,-612,-297,-1000,26,445,506,353,956,-1000,1000,260,490,-106,387,-1000,-629,1000,-1000,298,-233,-359,-899,49,-865,-335,-735,-522,-372,655,1000,-360,-233,907,-1000,-622,-109,137,210,478,-183,457,1000,1000,1000,48,-544,-461,983}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00073() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.String,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{877,-1000,-912,-1000,1000,-43,-485,-53,1000,500,-560,-152,-765,-15,-75,-1000,63,-460,-787,-210,1000,732,428,-783,293,-241,-553,386,361,90,-209,475,777,47,1000,-58,-899,-1000,-991,-495,-1000,1000,234,-432,-697,-10,-320,120,907,408,459,423,-290,141,783,608,-219,99,-304,-432,650,-375,-180,-936}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00074() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.String,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{340,-436,-697,-909,-742,-916,-228,874,372,149,-523,451,1000,306,117,-486,-1000,-430,1000,-384,990,22,972,1000,1000,240,-782,376,-34,-566,883,189,291,1000,570,-156,-349,30,-184,1000,1000,614,-220,-351,-242,25,-1000,-752,1000,-877,-427,651,-22,-1000,-302,-587,33,446,-234,-1000,62,-861,223,-543}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00075() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.String,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{341,-1000,-1000,254,186,-474,773,1000,559,-465,-446,1000,1000,-200,1000,-265,-379,-810,1000,-293,201,57,810,1000,491,-836,42,398,340,-26,1000,1000,1000,-1000,748,-493,-517,-768,-605,1000,640,1000,68,730,-333,155,-685,-1000,-1000,200,524,-1000,501,-750,231,-410,765,-132,-1000,-1000,238,304,960,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00076() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.String,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{981,-1000,-1000,-1000,-527,-949,833,894,568,839,-516,111,816,25,-662,-1000,-1000,-606,-85,131,808,-26,1000,1000,-209,584,-117,-1000,-284,340,1000,27,1000,-658,335,-640,-261,-104,-280,134,1000,1000,-1000,-823,-151,-322,-1000,-233,-1000,-1000,1000,298,1000,636,145,-1000,-1000,290,-602,-1000,-519,-1000,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00077() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.String,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{818,-1000,-926,-884,430,652,645,989,640,516,178,785,400,303,221,-617,-520,-1000,63,-4,448,143,867,589,70,-11,261,132,-226,34,718,104,1000,-484,836,-759,-546,-838,-724,281,148,630,-291,188,304,408,-395,-288,-493,255,1000,236,343,-397,462,-590,600,208,-866,-877,439,-88,664,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00078() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.String,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{518,-1000,-1000,-870,422,-117,359,745,983,-150,-234,438,173,-440,712,-731,-958,-801,941,-122,794,240,1000,952,-225,-49,-347,-1000,-96,588,1000,610,763,-413,843,-504,-824,-768,-956,1000,-95,1000,-254,58,-207,603,-645,-972,-795,-161,1000,-79,461,-661,819,-993,835,557,-1000,-905,585,-317,807,453}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00079() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.StringBuffer):org.apache.commons.lang.text.StrBuilder",
            new int[]{802,863,-729,126,-386,669,1000,54,-836,-998,-796,-791,-563,335,-301,-229,137,-240,-36,-788,670,780,-530,278,-1000,-1000,514,814,965,726,657,1000,585,869,160,-1000,-1000,-928,-122,510,-1000,-867,1000,-399,-155,-724,-502,649,322,-150,-318,-195,-329,-215,75,-1000,-187,-87,-1000,1000,-1000,-1000,184,444}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00080() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.StringBuffer):org.apache.commons.lang.text.StrBuilder",
            new int[]{-123,261,169,394,760,-1000,1000,777,-599,-104,-114,213,-813,342,-80,-201,273,-548,905,-437,891,379,-296,1000,-1000,-1,199,1000,-12,-274,-435,179,-312,-358,-20,-156,382,90,604,1000,-810,706,621,-1000,162,-300,-685,455,249,-1000,-1000,56,384,688,441,1000,1000,-701,-688,731,-866,-999,-260,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00081() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.StringBuffer):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,304,-666,-703,114,-153,1000,-234,-233,-676,-962,-1000,-752,233,-960,-1000,977,-687,-986,-886,763,-351,66,190,-1000,-1000,-19,741,429,1000,1000,-522,-423,-995,363,-995,-1000,-1000,-460,1000,-1000,-1000,-405,-82,-1000,-1000,-1000,-198,544,-182,16,-392,-517,1000,126,-1000,-1000,741,-1000,1000,-1000,-125,-317,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00082() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.StringBuffer):org.apache.commons.lang.text.StrBuilder",
            new int[]{-302,-1000,752,239,1000,194,-403,1000,514,611,1000,542,1000,-797,-669,453,-25,-423,-534,1000,471,-233,121,807,585,948,-1000,-188,-55,-1000,414,-1000,-1000,509,889,906,831,1000,-364,-999,1000,1000,-1000,-276,247,267,-605,-743,-1000,-142,-1000,-187,465,169,1000,1000,778,-565,1000,-429,-224,341,-748,598}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00083() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.StringBuffer):org.apache.commons.lang.text.StrBuilder",
            new int[]{192,566,657,727,1000,242,-8,1000,-1000,474,1000,-49,1000,50,458,-144,225,-723,-124,1000,1000,-283,153,352,332,47,-337,-82,598,-1000,670,-809,-1000,539,1000,855,248,997,-178,35,656,1000,-859,-111,528,421,-459,-94,710,-261,-121,-574,921,-524,740,1000,202,-746,934,-650,-373,627,-548,211}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00084() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.StringBuffer):org.apache.commons.lang.text.StrBuilder",
            new int[]{571,863,-951,928,-632,-719,469,-781,623,-782,-713,-450,-783,-814,-382,-976,64,490,-289,-1000,119,549,-516,304,678,-613,905,804,-74,533,-82,1000,468,1000,-734,-1000,410,-545,305,451,-182,-475,1000,255,-1000,-840,-321,254,-458,973,-319,179,-331,224,-340,400,-393,318,-613,476,-584,-818,252,118}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00085() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.StringBuffer):org.apache.commons.lang.text.StrBuilder",
            new int[]{420,938,339,-764,545,-686,-823,-293,222,-893,201,-868,-662,-301,-330,-195,432,581,567,-900,-931,-629,-963,425,-864,89,-831,257,-527,6,-925,69,270,-154,-673,-297,271,-290,400,595,964,-327,984,-867,-322,-317,-217,395,-222,138,-297,524,-998,302,-752,86,381,598,-649,894,175,724,884,975}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00086() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.StringBuffer,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-885,-406,-906,355,-1000,-1000,149,-438,712,683,-368,-919,1000,315,263,-65,-273,1000,-383,-18,-699,-357,83,-329,-171,-19,-607,758,708,-345,-835,-1000,-1000,1000,705,-581,-1000,-517,-51,-273,-1000,457,-995,1000,-151,1000,-1000,113,-60,-662,-372,-44,-309,-1000,836,1000,456,197,-545,228,121,-313,1000,501}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00087() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.StringBuffer,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{636,429,-552,-578,-76,-45,-666,-279,-952,-6,474,-229,73,-471,441,9,345,-788,-425,29,-580,-357,40,307,891,58,394,-964,-894,-279,508,828,255,675,996,-544,915,-595,-322,-277,763,454,995,70,-118,-962,813,-417,854,331,585,683,-351,225,-544,-8,-756,116,570,605,-184,517,565,-697}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00088() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.StringBuffer,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{600,704,-288,-613,-881,-385,-481,-809,-274,-151,597,31,759,409,834,11,931,605,-1000,1000,-581,-1000,-1000,758,336,707,-470,-1000,1000,-1000,635,-447,-750,658,998,158,1000,-42,59,-1000,115,-318,147,874,-62,-53,633,-214,887,951,613,46,-897,-977,-1000,1000,-923,566,-199,693,1000,-28,768,587}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00089() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.StringBuffer,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-329,-1000,198,1000,-424,-271,-107,-339,627,-421,185,-559,326,319,-163,26,-8,625,692,987,84,1000,-891,287,1,722,652,-197,233,-628,941,-1000,-389,288,-1000,291,-1000,297,1000,-768,-830,-115,-738,342,567,843,-763,-355,-464,-971,229,-396,-946,-994,-1000,904,400,-162,-170,885,382,-1000,658,237}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00090() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.StringBuffer,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{564,281,-945,263,-747,587,-1000,-265,-425,-582,1000,52,-189,311,-747,-35,623,882,-481,-146,-288,-842,-350,627,1000,1000,737,-362,246,-58,143,81,838,1000,705,844,-1000,484,-340,-1000,-447,-161,479,12,115,-1000,705,-112,-580,754,810,885,-448,-327,304,1000,372,39,1000,579,16,664,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00091() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.StringBuffer,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{465,-764,240,-390,669,-454,-1000,615,-417,-68,252,-323,475,-989,-195,1000,-65,-465,431,351,-267,-357,564,690,-430,-400,-412,-147,-1000,-589,1000,800,507,17,1000,-1000,987,-1000,-651,736,1000,66,-713,-605,66,-1000,1000,-405,376,756,356,53,-183,448,-1000,-695,-1000,166,-186,1000,122,325,-271,91}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00092() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.StringBuffer,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-754,-697,-98,790,373,-1000,-616,-98,1000,671,-36,-1000,460,462,523,9,-331,520,-425,29,-201,161,-74,236,-714,58,-325,758,-894,-279,1000,-1000,-1000,271,-715,-1000,-1000,-661,-374,596,659,633,-858,645,-289,544,-997,-292,854,-652,-702,-1000,-300,-228,116,-1000,426,-313,570,-28,-506,-119,-262,317}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00093() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.StringBuffer,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{620,-390,823,432,-468,1000,-403,231,-509,-1000,-704,-700,-414,-275,-1000,-797,-653,398,-536,-72,1000,1000,1000,623,-575,-28,247,-443,937,-16,134,773,940,-1000,-405,744,427,-46,838,-156,-1000,-1000,-504,-1000,884,1000,-593,290,-298,1000,803,-203,627,-1000,-1000,307,-1000,-562,292,-339,1000,611,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00094() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.StringBuffer,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-985,1000,1000,317,581,288,-103,830,-480,-1000,-778,-920,327,-943,829,-1000,1000,1000,-101,-1000,1000,-502,-815,-626,-1000,-1000,1000,620,1000,-700,-1000,-1000,-1000,-1000,-1000,-1000,-1000,1000,1000,710,-89,-1000,747,473,603,-1000,42,87,1000,-1000,-1000,1000,-525,73,-1000,534,-1000,-118,-1000,-479,103,-1000,787}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00095() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(long):org.apache.commons.lang.text.StrBuilder",
            new int[]{-620,1000,-446,-119,-191,202,-339,-299,185,-391,1000,-1000,1000,-549,803,-1000,-817,-1000,-1000,-1000,-10,317,192,1000,73,20,-982,-284,-340,-671,680,-788,-1000,302,-485,998,838,841,-1000,1000,171,346,-462,219,738,-756,-1000,-100,991,-1000,-960,728,886,-539,590,-384,1000,304,823,947,-574,1000,103,-273}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00096() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(long):org.apache.commons.lang.text.StrBuilder",
            new int[]{371,410,-435,634,-809,697,460,693,-51,-783,508,533,1000,493,425,489,120,-724,657,-842,965,34,714,130,-355,822,249,-465,-207,96,1000,-918,302,311,-230,152,769,897,-512,-116,-218,471,92,-895,-783,189,272,1000,92,-955,755,932,445,-1000,690,634,-801,-79,1000,138,-268,-635,-71,-507}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00097() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(long):org.apache.commons.lang.text.StrBuilder",
            new int[]{305,1000,-132,492,-596,-228,1000,484,-168,1000,-317,-473,1000,730,351,-263,388,-472,-815,-75,-952,-801,58,40,-32,-290,769,-465,98,104,-647,-546,805,-1000,-1000,59,615,678,-1000,951,-150,406,1000,-1000,801,346,1000,-1000,1000,299,-366,-329,445,-88,491,-77,-320,540,-453,1000,-564,681,-768,942}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00098() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(long):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,107,202,232,640,512,119,-543,-178,-519,437,-112,312,-795,1000,1000,-1000,-165,-693,506,1000,-42,4,505,283,-928,520,105,228,-550,267,-892,848,970,-394,-1000,558,944,760,1000,199,-615,-891,118,707,221,-785,519,547,-933,542,367,-924,330,-548,391,159,-625,-883,533,-140,-26,12,-919}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00099() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(long):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,783,284,1000,-526,688,1000,484,-569,1000,766,-287,1000,1000,526,-1000,-1000,44,-1000,680,-659,-1000,-260,-885,-7,-1000,1000,-112,613,927,-1000,490,1000,-881,-1000,-553,470,787,-697,423,218,416,1000,-1000,1000,707,-1000,-1000,988,943,-426,-1000,186,320,570,-110,-872,603,-1000,689,-1000,160,-947,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00100() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(long):org.apache.commons.lang.text.StrBuilder",
            new int[]{-767,503,896,-857,831,-61,-468,-844,-323,-771,1000,191,518,-865,334,969,-1000,556,-874,-112,322,354,1000,1000,913,-1000,-332,420,-976,-1000,1000,-438,-400,-160,-538,14,598,751,-513,577,-15,-270,-346,-755,-757,-255,-1000,381,1000,-911,537,558,-114,554,-1000,-331,926,-214,742,1000,980,828,-829,-479}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00101() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(long):org.apache.commons.lang.text.StrBuilder",
            new int[]{596,-1000,721,697,-762,662,-446,100,-198,-1000,52,142,276,-178,265,1000,-591,-1000,67,-835,1000,606,224,-1000,413,-457,91,-518,-1000,553,860,1000,-194,226,1000,255,-999,418,-52,540,-582,-530,1000,-753,98,398,-647,1000,-212,358,885,760,617,-598,405,-439,-1000,-52,1000,-220,-1000,-1000,-712,-24}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00102() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(org.apache.commons.lang.text.StrBuilder):org.apache.commons.lang.text.StrBuilder",
            new int[]{725,797,925,506,-519,590,999,334,787,-193,785,-645,-450,474,-1000,994,-196,-435,1000,-280,45,-676,-18,-896,-1000,-52,305,-626,-656,-616,788,-810,650,307,225,743,-47,-116,579,534,150,-514,-274,-94,42,-265,-367,-464,-821,639,390,792,-793,1000,1000,-6,-1000,671,-107,1000,478,-542,720,-467}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00103() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(org.apache.commons.lang.text.StrBuilder):org.apache.commons.lang.text.StrBuilder",
            new int[]{-254,837,-247,-1000,-123,-244,1000,146,107,-865,796,-1000,1000,-900,-1000,1000,230,-1000,299,740,-1000,-774,360,-1000,-1000,115,1000,-914,-887,-1000,-512,-190,-329,416,-1000,920,721,-1000,1000,826,-239,68,189,-24,703,-757,285,183,-789,1000,-159,252,-1000,1000,1000,174,-1000,800,-1000,794,-52,726,804,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00104() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(org.apache.commons.lang.text.StrBuilder):org.apache.commons.lang.text.StrBuilder",
            new int[]{811,-71,1000,1000,479,-783,537,70,684,1000,539,516,743,-263,-356,127,1000,209,-127,-36,1000,286,-963,100,-1000,-220,-867,544,1000,-551,-302,59,1000,-612,21,-751,890,-1000,-378,-820,1000,-699,1000,-632,-1000,1000,522,-1000,-733,-852,911,1000,698,395,658,-932,-226,202,-683,-930,-358,270,-619,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00105() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(org.apache.commons.lang.text.StrBuilder):org.apache.commons.lang.text.StrBuilder",
            new int[]{-618,167,-617,167,527,-937,-874,-369,-869,437,-189,-505,364,-1000,559,-260,-140,222,-1000,829,-930,-1000,1000,198,293,-1000,1000,-993,51,418,-1000,-505,-190,-543,26,556,-311,-174,756,588,-1000,575,-226,283,522,-458,846,1000,109,633,-1000,-282,500,-7,44,-886,524,-170,1000,-996,388,1000,732,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00106() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(org.apache.commons.lang.text.StrBuilder):org.apache.commons.lang.text.StrBuilder",
            new int[]{-538,990,659,760,-771,992,-717,207,-503,-94,-161,23,-661,1000,-365,-617,-592,677,1000,-362,480,-1000,-771,-671,-1000,8,-6,-495,-872,786,1000,-1000,486,68,1000,884,-1000,1000,709,848,-823,313,-1000,240,626,-729,861,601,-545,656,-177,473,1000,1000,1000,-335,552,488,-814,1000,1000,-1000,1000,-507}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00107() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(org.apache.commons.lang.text.StrBuilder):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,287,-1000,-1000,-304,-485,-577,39,-610,514,742,-868,-1000,-1000,293,-8,455,-476,271,524,-1000,-1000,778,331,-889,-1000,1000,-1000,-1000,-416,464,-392,1000,-29,457,572,588,-95,113,878,-1000,204,-318,-192,800,-1000,628,1000,140,858,-468,-387,1000,180,612,-428,-200,-98,934,-176,423,1000,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00108() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(org.apache.commons.lang.text.StrBuilder,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-144,634,-481,-8,-1000,-1000,-909,687,111,721,-98,-112,1000,-1000,-1000,-519,-621,706,320,694,-642,-696,822,-997,727,-689,412,-247,1000,-1000,-491,1000,-75,1000,22,1000,-1000,96,-71,206,-730,-1000,-1000,254,-860,-807,464,1000,912,-1000,987,478,508,-307,-514,-1000,101,1000,656,1000,126,1000,681}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00109() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(org.apache.commons.lang.text.StrBuilder,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{14,-1000,-1000,-113,450,905,-261,-714,-1000,-306,-1000,484,384,-268,39,46,980,-398,-613,-102,-208,-793,609,-478,-927,-694,1000,-1000,85,-1000,-74,-87,221,845,-643,-1000,-824,291,336,1000,-235,1000,-446,529,1000,911,-785,271,1000,-927,-596,-444,337,378,115,138,-480,283,-553,-1000,-249,-746,-1000,532}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00110() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(org.apache.commons.lang.text.StrBuilder,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-862,1000,1000,1000,-474,-967,1000,-1000,1000,1000,8,-1000,605,-1000,228,-1000,-407,-1000,-71,-495,730,1000,-988,490,786,646,-1000,1000,-487,942,-400,-246,-645,-1000,-576,756,-899,-1000,-474,-1000,955,170,-220,-1000,-1000,710,799,831,-913,1000,-263,1000,-901,-732,1000,598,894,-25,-789,575,-41,-1000,-291,-903}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00111() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(org.apache.commons.lang.text.StrBuilder,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-605,222,478,500,-18,756,-158,-999,-1,-745,434,-5,-389,43,-464,55,-55,230,347,477,55,-1000,-565,1000,98,71,-694,-620,-175,1000,-198,178,960,860,588,213,561,1000,-394,232,-228,-886,-1000,-622,62,-841,657,246,498,-82,-420,211,1000,-386,-50,-376,-1000,-266,1000,886,235,266,1000,59}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00112() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(org.apache.commons.lang.text.StrBuilder,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-416,-1000,-605,-1000,-1000,404,-149,-1000,-1000,-1000,942,1000,-204,1000,781,-1000,-196,250,1000,1000,-1000,-1000,1000,-1000,-1000,-1000,1000,-307,814,-1000,409,-1000,417,790,-96,-719,-684,740,858,1000,-785,138,-1000,529,1000,-136,-326,-1000,1000,15,103,476,1000,1000,-1000,-1000,-1000,961,1000,1000,1000,-351,-492,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00113() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(org.apache.commons.lang.text.StrBuilder,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-1000,-628,-1000,-392,195,-842,-1000,72,-445,-360,849,221,1000,-55,-1000,-558,-614,924,896,-508,-1000,1000,-538,1000,-294,368,-11,-320,-144,-580,-927,-1000,36,587,-651,484,-67,888,1000,-348,255,-1000,-682,985,-476,-770,-3,1000,796,-1000,539,717,1000,-734,-304,-1000,316,1000,229,507,-479,1000,974}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00114() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(org.apache.commons.lang.text.StrBuilder,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-142,-832,-528,32,1000,523,-158,1000,-1000,-5,129,-304,-692,-429,-605,75,312,-1000,-877,59,835,-276,1000,895,495,304,1000,-620,-471,-334,-1000,-686,970,860,625,-1000,-313,137,166,1000,-33,751,-1000,91,420,758,657,-903,907,96,96,16,169,-1000,678,166,-69,19,-552,-428,-1000,-254,-1000,-343}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00115() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(org.apache.commons.lang.text.StrBuilder,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,739,664,-202,-207,-159,1000,405,1000,-1000,-786,-257,-1000,-1000,530,-432,361,115,-1000,-269,-275,-891,111,1000,1000,-781,-46,-1000,-171,344,1000,1000,-1000,1000,-907,269,-1000,-309,-1000,-505,895,-812,-860,607,-825,437,1000,-1000,-1000,-1000,362,-1000,1000,-1000,504,-454,1000,283,-1000,943,-777,1000,-155,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00116() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendAll(java.lang.Object[]):org.apache.commons.lang.text.StrBuilder",
            new int[]{602,884,-95,-388,495,728,-889,-1000,-754,63,-168,722,-839,-6,-759,293,781,-27,-679,772,-1000,293,-682,-1000,1000,317,-443,706,7,410,1000,-408,0,-179,-398,-1000,-459,-289,1000,-1000,297,-1000,390,470,-370,751,534,413,964,-626,343,-1000,1000,375,-348,303,-594,973,322,-36,1000,-97,608,-746}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00117() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendAll(java.lang.Object[]):org.apache.commons.lang.text.StrBuilder",
            new int[]{-542,654,533,-421,-257,217,749,-1000,1000,502,1000,1000,147,-248,1000,105,1000,-739,754,1000,-537,1000,-167,-1000,19,-1000,-1000,1000,1000,546,911,-1000,1000,750,-1000,-1000,-1000,-80,1000,-1000,465,-702,297,1000,749,822,321,-1000,-325,-822,373,-560,-588,1000,-601,37,682,-289,-61,-869,19,297,447,-591}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00118() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendAll(java.lang.Object[]):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,614,-608,19,-688,44,-254,-318,-245,-899,1000,219,1000,-421,1000,1000,578,274,401,676,-1000,-125,-1000,-888,697,-985,-94,1000,1000,323,1000,-1000,-296,11,-434,-927,78,1000,1000,-1000,400,-400,-273,175,-1000,-708,-514,-880,720,825,1000,-63,-526,-321,-409,658,626,170,1000,310,-600,-1000,451,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00119() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendAll(java.lang.Object[]):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-167,-662,-324,569,-911,1000,-1000,1000,1000,-59,843,979,-209,-204,670,282,295,-661,-208,-1000,782,96,-332,-556,13,-990,-715,1000,1000,441,-432,882,-826,-862,-792,779,-158,243,316,1000,-386,120,963,1000,-381,-1000,1000,-261,-401,-1000,986,-680,464,-281,1000,890,-1000,-911,-1000,661,-162,447,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00120() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendAll(java.lang.Object[]):org.apache.commons.lang.text.StrBuilder",
            new int[]{363,1000,151,919,493,-308,-1000,918,-753,505,-757,222,-459,113,-963,-1000,-946,-542,-238,-648,561,-112,515,903,-320,336,1000,-985,-1000,-1000,-81,584,462,-547,337,637,-1000,-622,-370,-149,-1000,1000,-754,-342,-1000,1000,-412,455,133,-315,-60,-1000,790,485,-1000,209,-116,544,129,107,588,669,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00121() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendAll(java.lang.Object[]):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,737,1000,111,643,558,359,-598,-1000,198,-103,387,-1000,531,-1000,-1000,726,-1000,-219,1000,1000,264,-347,-439,-536,-1000,-336,1000,-1000,-805,1000,1000,-940,1000,51,-977,-544,-574,211,-1000,-1000,1000,942,47,-1000,1000,1000,-594,1000,-1000,288,-716,1000,630,-1000,269,-1000,890,1000,1000,-23,584,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00122() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendAll(java.util.Collection):org.apache.commons.lang.text.StrBuilder",
            new int[]{373,1000,34,-278,-706,890,93,-687,-294,-579,184,1000,-352,-116,-587,-488,601,-542,-977,9,225,-355,-675,-727,774,247,538,-193,-702,1000,-848,-29,-164,915,456,-1000,-302,-673,109,-910,-550,758,518,-458,654,-615,633,-516,-303,-388,744,-17,1000,-540,-22,-63,-335,-51,711,77,140,-554,371,-18}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00123() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendAll(java.util.Collection):org.apache.commons.lang.text.StrBuilder",
            new int[]{216,-1000,-882,-917,905,-1000,-616,-391,849,1000,-581,1000,322,1000,-979,686,-1000,960,537,126,-597,546,-972,-368,33,1000,-928,688,1000,-1000,-555,944,-149,-905,-1000,-138,1000,647,-1000,-1000,1000,-143,935,-1000,1000,130,-709,874,-1000,-624,1000,974,994,-842,659,976,1000,-102,-238,-1000,-1000,1000,1000,772}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00124() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendAll(java.util.Collection):org.apache.commons.lang.text.StrBuilder",
            new int[]{858,-929,-263,282,389,-23,-645,727,-181,1000,178,342,428,761,-112,1000,-448,1000,405,-197,117,-239,-1000,-393,-213,1000,347,1000,-877,657,264,68,-446,-306,619,729,626,-864,-1000,1000,-842,1000,-943,-200,320,1000,-1000,597,-1000,1000,1000,1000,356,-1000,-960,-360,-796,-254,-1000,507,187,1000,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00125() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendAll(java.util.Collection):org.apache.commons.lang.text.StrBuilder",
            new int[]{-180,-1000,-1000,130,115,-661,589,528,317,215,-676,486,-580,1000,-886,1000,-907,1000,-693,276,-592,224,585,-147,637,-844,-1000,66,225,-114,-489,-365,412,-442,-145,195,1000,-226,-521,183,11,-378,294,-282,-184,492,349,-223,-63,-56,379,1000,352,-1000,-142,-412,81,1000,-1000,-945,-9,678,1000,-22}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00126() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendAll(java.util.Collection):org.apache.commons.lang.text.StrBuilder",
            new int[]{68,-402,-626,-815,-510,-1000,347,35,406,872,-517,-1000,296,-92,-566,-106,213,-64,692,-160,827,-1000,-1000,-597,-1000,698,438,421,-1000,388,656,-344,-522,1000,682,-370,-560,-1000,573,-359,-1000,933,-510,-528,355,-212,-824,-333,-761,65,1000,739,727,-1000,-938,-117,265,-122,956,-867,1,870,-1000,835}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00127() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendAll(java.util.Collection):org.apache.commons.lang.text.StrBuilder",
            new int[]{931,-365,-300,-782,489,-961,233,-519,101,377,245,-46,-144,-393,-332,-604,192,-1000,1000,-269,348,986,-769,-1000,-917,1000,339,183,375,-753,36,-555,-161,-233,-296,119,-96,436,-975,-783,742,-190,612,-318,933,-63,-658,576,-1000,-593,252,-899,1000,-63,718,1000,713,71,798,-194,-591,388,305,186}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00128() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendAll(java.util.Collection):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-178,-720,-688,-399,-1000,643,-87,-248,1000,-28,-1000,-646,1000,-834,-599,774,-807,1000,-641,1000,-33,-1000,-372,-1000,855,1000,688,-1000,-127,656,623,-647,1000,-1000,73,-1000,-1000,597,-862,-1000,1000,-970,-362,355,-799,-899,0,-1000,-1,1000,165,994,-843,-703,-206,200,-18,1000,-242,-46,640,1000,490}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00129() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendAll(java.util.Iterator):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-1000,-87,-604,27,-1000,-898,-23,429,815,908,-19,1000,-103,1000,1000,-941,-1000,-1000,1000,-250,-1000,-582,1000,336,-865,-380,467,-254,123,-8,-6,-441,797,272,1000,-1000,-244,-111,-1000,267,760,-657,-1000,-555,959,-249,-1000,-1000,503,381,-1000,-815,-1000,-997,-1000,20,1000,928,194,-1000,-566,0,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00130() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendAll(java.util.Iterator):org.apache.commons.lang.text.StrBuilder",
            new int[]{-619,147,-556,309,725,53,-677,-817,-164,-40,-232,719,1000,-83,415,717,-942,-637,-934,-421,-280,-225,-1000,828,583,219,-505,1000,-1000,411,-1000,-53,42,-110,-72,560,-157,-347,1000,361,139,-126,-413,-556,-418,937,433,-807,-663,1000,-14,104,-1000,-955,-533,-720,1000,1000,-367,-696,37,-576,70,94}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00131() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendAll(java.util.Iterator):org.apache.commons.lang.text.StrBuilder",
            new int[]{580,-29,404,-67,184,237,-972,513,-403,899,-614,-694,122,-231,338,239,170,-432,-609,-178,-174,-839,327,738,-809,-807,-333,784,260,-47,870,518,254,875,-658,-116,-989,-200,-933,-987,381,-181,-971,-557,-642,342,411,-947,-867,890,48,-823,-800,-962,-399,-455,-816,-103,-555,-21,-833,-381,-544,-892}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00132() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendAll(java.util.Iterator):org.apache.commons.lang.text.StrBuilder",
            new int[]{144,638,-617,470,497,343,-146,906,-847,-714,-693,473,343,-343,165,595,-396,-368,84,-727,505,107,-449,563,137,548,-366,601,-990,-36,-839,176,183,-438,-165,-229,165,-641,488,944,396,-266,46,-78,990,721,614,-609,-205,689,-445,577,-167,-2,416,-63,682,182,-850,-957,481,-710,169,563}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00133() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendAll(java.util.Iterator):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,935,1000,-348,514,966,-146,906,67,-287,-259,-1000,-1000,-878,-1000,744,141,1000,84,-430,26,-211,368,493,-1000,-1000,819,-1000,1000,-1000,1000,340,1000,1000,-165,-990,165,303,515,-819,396,396,-206,1000,-1000,-121,1000,-186,872,-627,348,670,1000,914,-1000,-289,-631,-1000,-1000,-399,-1000,-273,180,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00134() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendAll(java.util.Iterator):org.apache.commons.lang.text.StrBuilder",
            new int[]{199,-484,-185,-227,27,-71,-136,-463,-362,-338,369,-442,0,-103,237,1000,166,-759,-218,394,-167,-1000,-582,313,-401,26,139,-474,1000,-577,73,-785,-171,219,77,990,-1000,-1000,689,-1000,1000,1000,0,-184,-277,555,0,-747,0,-763,579,242,307,694,-73,-300,597,-148,1000,194,-623,-45,0,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00135() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendAll(java.util.Iterator):org.apache.commons.lang.text.StrBuilder",
            new int[]{-401,116,-322,-232,-962,1000,544,33,-1000,-762,-400,-400,-341,-1000,1000,489,-40,17,37,-220,791,-608,110,772,-626,-1000,-155,-1000,-359,-892,244,947,-79,1000,59,-1000,769,-1000,1000,-866,1000,23,-267,133,-370,542,383,-389,-289,-724,-847,-1000,507,972,-250,937,-446,244,702,-521,-273,-1000,511,-286}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00136() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendAll(java.util.Iterator):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-1000,-491,-500,-784,-1000,-97,-1000,654,-816,1000,632,-4,438,1000,900,-1000,-1000,-788,-355,444,-1000,535,1000,768,-1000,-155,-739,-191,-509,-626,-1000,-458,1000,1000,1000,-1000,-977,364,-1000,598,679,245,-1000,-1000,864,-275,-680,-877,-1000,21,-819,576,94,-901,-532,-446,1000,1000,1000,-1000,-1000,1000,-765}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00137() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendAll(java.util.Iterator):org.apache.commons.lang.text.StrBuilder",
            new int[]{-127,197,160,-83,-444,-241,273,-546,-64,-56,349,358,-81,-954,-108,-263,-354,-1000,-1000,-65,-1000,-1000,546,1000,-378,33,585,913,881,-88,199,-956,89,-395,-308,694,-774,943,-1000,-1000,424,118,583,95,498,1000,1000,-543,-1000,-119,1000,260,-1000,-802,-697,-630,539,68,-283,-78,-1000,-928,329,-524}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00138() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadLeft(int,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-1000,647,-796,436,99,-1000,911,683,-257,497,844,-1000,-1000,-188,-757,-412,-1000,-518,-101,368,515,1000,576,862,552,693,1000,258,-504,-1000,349,-592,339,825,880,1000,-377,-606,-1000,1000,-1000,-1000,416,-99,-916,1000,-967,-1000,-1000,-584,-1000,647,649,-772,-146,-46,-1000,-1000,52,-459,-909,-235,-936}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00139() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadLeft(int,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,355,-312,54,18,-318,198,575,340,-951,-467,-1000,773,68,-58,627,-116,554,-111,387,216,385,1000,-201,425,-906,148,-592,-1000,459,726,-1000,493,964,-308,484,-308,765,410,649,-656,1000,616,136,-1000,922,407,1000,223,542,-621,1000,-1000,816,-313,-1000,-570,-1000,1000,1000,-652,403,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00140() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadLeft(int,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-783,342,-901,712,671,1000,549,720,-969,814,-127,542,436,139,733,-692,275,364,-25,-931,533,-721,-861,116,388,-38,386,380,189,1000,-743,-186,-670,116,1000,-798,-759,-475,863,797,1000,451,-315,-702,994,986,-1000,-1000,589,-384,-284,-1000,987,-1000,-223,970,194,236,-452,-848,-758,701,-1000,146}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00141() {
        org.junit.Assert.assertEquals("THROW:java.lang.ArrayIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadLeft(int,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-405,-1000,228,398,301,104,-781,166,-405,578,438,561,194,91,969,-29,602,-316,137,-754,613,38,799,-281,305,41,-1000,-504,-1000,534,-400,-672,-398,8,1000,421,208,-1000,40,-753,75,-313,-876,-423,-288,639,-991,-649,-661,-338,-685,-1000,987,450,-1000,570,-715,-1000,-318,589,-540,-1000,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00142() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadLeft(int,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{78,-79,-120,823,132,-198,739,279,-1000,1000,-628,1000,577,275,511,412,901,-584,-488,-409,120,-122,-187,-663,26,186,-480,417,53,1000,389,557,-351,-983,467,-921,-477,-1000,-737,437,-36,-1000,396,54,-144,34,-805,-1000,312,264,442,-226,592,-562,-363,1000,608,402,-239,-44,-1000,-334,-984,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00143() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadLeft(int,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{248,-1000,-69,-728,436,-914,-341,9,737,-875,-304,604,583,-151,-619,-757,-412,-1000,-382,-1000,-971,-1000,496,251,-313,-643,-987,833,-1000,94,794,-633,272,339,593,-1000,472,-364,-372,114,455,-397,1000,416,-99,74,1000,142,-717,-423,99,1000,-176,668,-963,-470,-164,-554,1000,1000,-574,-1000,-235,-114}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00144() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadLeft(int,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{78,-1000,161,-107,301,-831,-200,467,-257,-149,-1000,1000,680,-121,75,421,904,-1000,91,-1000,-153,-122,49,770,507,-415,-480,1000,-700,785,-314,286,-143,-967,717,-1000,-787,-950,-835,-183,230,-1000,402,441,-1000,-304,479,-1000,-318,-653,435,-23,72,311,-835,303,433,-431,172,-44,-1000,-1000,-153,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00145() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadLeft(int,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-791,263,-352,-1000,301,-516,-454,-92,66,217,-1000,-325,-321,-1000,-398,135,-730,-618,-917,-409,342,395,1000,497,-252,-763,382,1000,639,-188,-103,1000,641,654,575,328,-194,1000,-932,299,55,6,729,663,28,-818,330,754,-131,-352,-762,685,-1000,-16,-111,-208,860,-923,-199,-821,-575,-55,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00146() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadLeft(java.lang.Object,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-1000,482,-1000,270,528,-663,1000,719,-923,411,-778,-965,-142,154,1000,-541,225,-569,-820,67,1000,-1000,893,-234,-1000,-1000,-485,-1000,166,-1000,-124,-425,-990,-1000,-295,-78,1000,1000,1000,1000,-20,255,10,31,370,-1000,763,-908,-195,-1000,-892,-112,-1000,977,833,-850,834,193,1000,-940,1000,254,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00147() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadLeft(java.lang.Object,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-795,-654,834,-809,712,-1000,225,-597,1000,-666,-1000,-1000,828,1000,42,1000,854,-626,-1000,-1000,615,1000,-392,893,-147,-515,-388,-571,-271,1000,-229,-1000,660,-147,-924,-1000,-1000,1000,381,-44,1000,-1000,870,632,392,-375,-1000,17,-1000,-98,-464,-1000,698,-886,-371,-177,-782,249,517,-630,-778,37,-449,-548}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00148() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadLeft(java.lang.Object,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{776,815,942,841,598,852,-910,-594,448,-984,-818,-727,55,711,213,-587,-541,957,-799,-209,-833,-932,-295,158,-6,458,-821,-774,927,-538,769,355,-622,647,408,-57,-801,-817,-597,-602,-7,-431,106,751,363,233,-304,-194,60,-643,643,-987,-798,640,-18,-795,-830,674,-816,776,-832,75,105,933}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00149() {
        org.junit.Assert.assertEquals("THROW:java.lang.ArrayIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadLeft(java.lang.Object,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-292,-759,937,-768,456,211,-548,529,-350,-552,1000,-1000,-569,858,1000,701,1000,494,-163,-108,-269,395,-99,608,-1,-1000,-1000,-171,68,278,101,-614,-251,-104,-471,-673,-837,1000,920,-238,1000,-517,801,311,10,352,-491,234,-820,-197,-672,-1000,1000,-321,-34,637,-662,1000,-584,845,-373,429,72,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00150() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadLeft(java.lang.Object,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{857,781,347,678,-82,-673,-734,187,609,-899,-841,-887,-1000,236,116,625,438,804,-904,-122,-956,954,-227,-590,792,-442,-1000,-20,128,-1000,-46,493,-229,-1000,-567,-609,-1000,127,-976,-1000,-475,-47,1000,-127,528,654,412,1000,-1000,607,-734,-1000,-1000,216,25,598,-343,-9,152,944,-315,937,730,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00151() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadLeft(java.lang.Object,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-777,-586,317,841,-319,-1000,453,-426,448,-464,368,-82,540,366,213,80,57,-537,466,50,310,-1000,-34,485,307,-917,200,-28,-966,-182,870,-777,-328,288,-259,-427,-850,606,104,897,15,-439,-89,737,363,-1000,-507,-581,-121,-431,643,37,747,-683,-137,-181,-312,463,-238,-1000,-832,75,105,55}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00152() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadLeft(java.lang.Object,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-681,-409,960,510,-759,-436,-645,-442,-303,-452,572,670,457,83,-171,-314,-884,165,443,501,-167,-283,-952,265,571,-57,-980,-848,-951,-942,-929,-89,591,-553,214,-499,-893,437,615,752,-436,553,293,251,467,376,23,-604,103,-46,-637,924,620,-931,-728,-854,-650,619,-539,550,-777,870,-719,508}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00153() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadRight(int,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-700,998,-1000,742,-970,1000,123,-226,-127,976,-506,1000,347,480,454,-126,390,33,-854,-116,-2,-400,-985,-549,-1000,-167,-412,-863,733,788,215,-1000,336,-724,-356,463,-898,-182,729,1000,-217,-110,1000,189,400,400,-474,494,442,796,-281,10,369,-1000,-532,-325,72,-462,185,-644,178,73,-712,864}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00154() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadRight(int,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-600,739,192,79,863,71,-774,-903,1000,-822,1000,941,258,1000,227,510,400,-242,-188,35,199,612,-684,-1000,-881,-1000,764,1000,-408,400,-433,991,-604,-231,512,-1000,-757,-705,118,-445,950,154,-7,-342,77,-897,-393,-188,242,-702,360,261,-340,-160,-135,-400,1000,-514,-901,365,47,-1000,417}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00155() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadRight(int,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{152,446,-625,679,896,-800,439,-1000,-888,-1000,-348,-49,-780,620,305,488,-989,1000,318,-691,851,-1000,241,671,-776,395,-745,684,1000,-888,1000,-210,-223,237,1000,-994,-246,-263,981,-195,702,-649,-151,1000,787,1000,1000,-1000,1000,1000,1000,357,-1000,285,-198,-491,-114,-609,1000,-133,169,-753,264,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00156() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadRight(int,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-571,-76,-1000,405,1000,185,344,-36,166,-977,-135,459,-756,-96,568,249,-1000,877,-352,697,900,-1000,-1000,821,-1000,132,-160,1000,405,-23,890,-433,462,-180,155,-422,51,-385,538,263,80,111,506,1000,1000,1000,1000,-780,1000,1000,267,537,-138,-293,-1000,-171,-325,-1000,336,-143,-174,-67,525,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00157() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadRight(int,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,601,-747,551,-406,146,-300,-854,-1000,-958,-942,727,-450,-141,-5,501,645,547,-556,810,950,-842,1000,-648,-1000,-1000,-3,-959,1000,-154,1000,-75,734,857,205,309,-1000,-454,-22,464,-873,1000,-509,856,-410,968,532,-87,906,339,-24,-162,-649,1000,-659,-532,326,-946,402,-794,416,-544,-547,417}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00158() {
        org.junit.Assert.assertEquals("THROW:java.lang.ArrayIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadRight(int,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-965,902,973,228,-970,-341,123,-464,-127,308,-674,-91,347,-637,541,-472,926,848,-287,352,-2,-935,762,-549,-521,-344,196,-863,916,83,453,-185,807,495,-777,74,-939,-182,-285,204,-738,-110,-856,82,-267,452,-474,152,246,-99,299,-910,696,857,250,-325,-973,-214,764,-644,290,207,-494,88}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00159() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadRight(int,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-1000,-933,-221,-311,795,857,347,44,211,1000,812,-139,-451,253,-1000,-1000,-1000,584,-375,-1000,1000,-1000,-657,1000,1000,-160,1000,-557,-23,-1000,-433,1000,-1000,-1000,-834,-24,992,383,899,-1000,-425,1000,-1000,-1000,-1000,-853,1000,-1000,564,-1000,743,500,-1000,792,-171,50,-74,-1000,-794,1000,-314,399,-248}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00160() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadRight(int,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-107,-706,528,-411,-1000,-912,827,-937,-200,1000,1000,1000,353,77,503,-22,318,1000,883,-52,-1000,264,1000,-826,-288,535,-684,699,1000,188,635,-150,838,-622,638,-1000,1000,445,-160,-1000,-766,-1000,-451,238,-680,-294,-360,-828,-1000,-765,1000,439,-511,438,-711,-62,-96,138,-1000,-16,1000,-775,-995,317}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00161() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadRight(java.lang.Object,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{305,-301,997,309,935,754,757,130,-323,1000,370,145,282,638,-626,-1000,-345,198,960,203,181,158,1000,-1000,1000,-1000,1000,-702,-76,-95,-692,1000,419,571,-871,1000,1000,1000,1000,1000,-1000,-1000,1000,-789,-586,23,-1000,-200,-846,1000,-120,116,-7,1000,60,-331,337,-410,510,360,-1000,232,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00162() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadRight(java.lang.Object,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{560,-945,-761,241,-291,-733,-1000,-1000,124,-1000,537,492,-738,116,560,667,191,265,1000,1000,949,-101,-102,129,375,-1000,725,494,-650,440,-553,-958,622,789,556,566,-118,493,-475,-123,461,981,-616,693,-585,351,633,-323,317,808,563,-839,301,-918,49,737,-1000,655,1000,615,1000,-692,300,129}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00163() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadRight(java.lang.Object,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-676,617,-175,997,-377,-626,-263,-426,-60,-348,-536,419,863,1000,-186,-64,-400,-763,950,293,946,-835,539,-347,914,-222,896,614,444,951,-522,-667,-521,-611,233,843,491,302,-919,331,724,-334,934,1000,-64,15,313,-190,-933,1000,-1000,-1000,719,-682,1000,1000,-973,-715,1000,1000,338,5,585,-370}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00164() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadRight(java.lang.Object,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-82,130,316,-682,293,882,1000,-467,876,448,-144,933,532,-191,-382,-1000,1000,-989,598,560,64,542,760,-1000,979,-1000,678,-487,278,523,912,1000,157,19,-919,829,840,1000,1000,1000,-1000,-1000,784,-641,290,-864,-376,932,-204,-675,685,406,-125,1000,-390,-528,152,-903,-171,-106,-1000,275,1000,999}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00165() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadRight(java.lang.Object,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-811,618,473,172,-573,-1000,-625,-161,401,-1000,-789,264,892,46,891,964,-402,-1000,-153,247,1000,-1000,-647,581,-451,496,-304,1000,603,1000,659,-1000,-332,-322,350,-264,16,-25,-1000,-384,681,286,332,1000,464,449,1000,-207,-742,-111,-599,-708,218,-1000,598,845,-292,-455,925,-578,560,-800,-801,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00166() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadRight(java.lang.Object,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{895,-1000,877,-1000,1000,-333,1000,844,527,623,1000,-523,1000,-1,1000,-595,391,99,-610,457,317,-447,182,-676,-299,-1000,237,-655,-645,394,720,1000,1000,1000,-8,1000,1000,815,-192,-34,-615,-472,362,-172,125,743,-266,52,-232,47,427,-1000,-1000,1000,-1000,-1000,912,550,273,443,-1000,-328,389,-970}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00167() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadRight(java.lang.Object,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{419,275,760,-964,-8,406,618,-649,-25,-866,-916,-806,15,-1000,1000,557,731,404,603,-716,87,691,-1000,412,1000,-515,-1000,1000,1000,1000,1000,-463,1000,727,-221,-1000,-857,-439,-1000,21,-945,410,-1000,220,-1000,-1000,327,770,-124,-715,1000,1000,-282,-539,-1000,263,1000,-1000,-346,-1000,-951,-681,-1000,-711}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00168() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadRight(java.lang.Object,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-210,329,-976,296,-264,-167,-199,-657,264,1000,-417,-1000,-281,190,-873,874,-37,64,441,613,-765,-423,371,-964,373,281,742,171,-401,377,-1000,-984,-1000,1000,959,-71,-473,44,-1000,-719,1000,1000,-343,1000,-1000,-487,-617,-115,701,1000,529,-1000,329,-614,167,812,930,-100,-128,-977,870,612,-212,-408}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00169() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendNewLine():org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-1000,-600,-1000,-1000,251,229,-151,136,1000,-604,761,-1000,-457,269,-541,-1000,-1000,972,507,491,1000,-935,-903,192,-634,-717,925,-1000,714,936,-1000,-564,74,-1000,1000,-23,1000,1000,-1000,-141,463,1000,1000,0,689,75,-1000,614,-1000,147,-576,1000,-408,262,-1000,-207,1000,-444,124,-665,1000,-294,186}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00170() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendNewLine():org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,993,-176,1000,642,-1000,236,-143,-59,557,-159,1000,950,-70,-122,213,211,1000,1000,-570,-323,-205,-93,-957,122,34,-1000,-1000,1000,-856,-400,1000,1000,77,-1000,527,33,749,1000,-260,1000,-1000,974,-305,1000,-1000,-1000,1000,478,1000,-743,-518,432,251,-824,448,667,282,-539,463,-1000,1000,-68,-850}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00171() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendNewLine():org.apache.commons.lang.text.StrBuilder",
            new int[]{538,-929,1000,-210,-176,622,-8,-136,264,-319,-713,932,-124,771,-137,-654,1000,491,-296,646,-425,572,381,705,529,-577,1000,-420,-381,952,73,690,-148,-602,448,1000,1000,-1000,455,103,-427,-204,-539,-573,-925,609,867,-473,558,-88,580,-1000,681,-1000,528,-873,-10,580,-208,533,-538,-383,-305,586}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00172() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendNewLine():org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,587,512,-1000,-832,438,-116,-18,-108,1000,-188,1000,541,-352,489,-299,116,-676,1000,655,-1000,1000,-1000,-923,-311,247,1000,615,1000,800,1000,-1000,-22,-248,-1000,1000,849,118,165,-1000,127,-207,400,1000,-1000,524,-248,-1000,987,-736,885,-628,958,-833,-347,-469,45,491,-872,626,291,1000,1000,430}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00173() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendNewLine():org.apache.commons.lang.text.StrBuilder",
            new int[]{647,-1000,-557,-1000,-1000,114,-464,-1000,-82,381,64,1000,-1000,-874,1000,-209,-1000,467,1000,382,1000,907,-451,-348,305,-270,-273,266,-418,1000,1000,-1000,-1000,-896,-1000,683,-1000,1000,714,-1000,-141,176,-70,1000,1000,611,1000,-28,1000,-719,1000,-75,472,-732,797,-1000,-518,785,-954,286,-969,-109,605,148}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00174() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendNewLine():org.apache.commons.lang.text.StrBuilder",
            new int[]{40,-1000,1000,-373,-381,397,-637,-136,601,79,387,183,51,219,310,-118,-625,24,319,878,1000,386,-89,225,279,-187,1000,-543,418,1000,449,332,574,-602,-323,771,737,-111,363,315,-330,-977,-636,92,-351,344,1000,272,371,166,338,-245,1000,-1000,335,-1000,133,666,-792,320,36,315,142,409}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00175() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendNewLine():org.apache.commons.lang.text.StrBuilder",
            new int[]{-455,-1000,-824,-551,-312,-794,749,-545,-166,720,-948,1000,-893,-88,134,-346,-1000,-627,1000,-541,945,814,-342,-163,240,-977,-1000,-875,347,859,1000,136,879,164,-1000,459,-731,361,996,360,1000,-1000,1000,732,1000,-634,495,999,673,528,-175,-633,316,-6,-631,-194,654,1000,-771,289,-1000,406,545,701}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00176() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendNull():org.apache.commons.lang.text.StrBuilder",
            new int[]{816,-520,90,-1000,673,-356,-87,-911,71,-922,-1000,149,880,-493,1000,-113,167,815,1000,513,-1000,102,-1000,246,-697,1000,1000,-38,-1000,-1000,-603,996,-408,-781,510,304,-171,-1000,-317,1000,-899,536,-1000,-320,439,713,-1000,-1000,-566,1000,540,-941,217,-995,775,-1000,688,-545,-134,-21,861,-483,201,910}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00177() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendNull():org.apache.commons.lang.text.StrBuilder",
            new int[]{583,-675,159,-654,159,346,511,-198,1000,-511,889,-186,-191,-42,511,-183,-1000,1000,83,195,-98,-1000,-696,-361,-1000,632,852,991,-537,693,-527,1000,-277,-1000,59,400,330,-1000,1000,-516,-1000,152,462,-928,1000,225,-949,-1000,647,1000,10,-1000,-294,-225,1000,177,1000,309,156,1000,159,-7,-1000,207}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00178() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendNull():org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-383,-264,113,-17,-216,-562,-1000,-63,-538,-196,585,-693,42,-385,-929,1000,1000,-188,-526,-258,-304,-644,-1000,478,450,-368,221,-647,-148,1000,-490,338,-671,406,488,1000,-721,-734,942,657,-150,782,-407,-590,-1000,685,-119,200,-1000,706,1000,158,-151,-54,315,-833,-242,1000,-339,-422,188,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00179() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendNull():org.apache.commons.lang.text.StrBuilder",
            new int[]{187,-250,729,-665,-405,-430,-156,16,171,-677,650,182,-1000,-426,-242,-167,210,428,-651,-822,-20,-894,-648,357,243,226,-139,-365,-484,1000,793,380,1000,-918,947,-1000,440,-697,-268,-1000,503,-1000,64,-593,-253,-1000,1000,-176,-55,-772,414,325,130,1000,641,400,-612,353,400,151,-1000,-187,484,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00180() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendNull():org.apache.commons.lang.text.StrBuilder",
            new int[]{537,-880,401,-720,872,-492,699,-582,-457,-888,272,30,-191,108,1000,-590,-1000,-152,83,-359,-572,725,-696,-361,125,1000,1000,140,-1000,-1000,1000,1000,305,-1000,1000,-579,1000,-1000,57,742,-1000,-751,363,288,501,590,-569,-555,-380,1000,535,-569,-317,-401,704,-491,216,115,650,202,783,-645,-276,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00181() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendNull():org.apache.commons.lang.text.StrBuilder",
            new int[]{-56,1000,272,590,604,-293,583,-864,-974,-677,-69,71,-1000,-476,30,-350,216,16,-251,-1000,-624,488,-751,-384,512,-357,27,-1000,731,343,1000,-578,-614,-114,1000,-400,440,-851,-515,-151,1000,-618,397,-585,118,-1000,1000,599,-1000,-1000,88,1000,-1000,-126,-753,-418,942,-1000,400,1000,-314,-356,1000,899}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00182() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendNull():org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-1000,-1000,941,-794,-786,302,729,-147,799,-1000,-1000,7,-1000,600,1000,443,519,337,345,-1000,1000,-626,-1000,-855,-1000,-144,-1000,593,-656,-261,490,-1000,230,764,501,-768,-1000,191,492,-427,1000,-1000,-1000,-1000,737,-115,-1000,-485,-497,-1000,190,1000,-349,728,129,-493,-1000,-283,55,-1000,312,692,-400}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00183() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendNull():org.apache.commons.lang.text.StrBuilder",
            new int[]{327,-1000,-48,-186,-1000,-216,196,336,982,-1000,211,585,369,417,444,1000,-168,803,-636,659,83,-304,30,-1000,-36,450,98,-1000,-647,41,-1000,1000,-1000,165,-686,1000,-213,634,-734,-223,-1000,-150,-1000,-683,-356,1000,547,-525,-1000,1000,-828,-1000,1000,1000,1000,1000,-833,-436,-587,676,-923,-812,-1000,-749}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00184() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendPadding(int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-1000,1000,-1000,1000,752,633,-292,69,563,728,-1000,-423,1000,658,-516,-172,1000,-1000,881,-911,-289,-591,-862,564,65,-183,-653,1000,-336,-1000,609,72,189,-12,-49,-144,1000,629,-888,-1000,-92,-326,1000,-671,1000,-164,-480,385,-465,351,-1000,287,258,-445,1000,-248,74,-333,-464,-1000,129,-319,168}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00185() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendPadding(int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{635,240,683,-868,-805,1000,460,-844,211,-837,-1000,-21,393,-911,1000,562,-970,-413,-1000,1000,-1000,-1000,-854,451,-1000,800,-149,1000,1000,-1000,-693,-1000,-1000,-804,1000,1000,-1000,-1000,1000,636,-1000,-381,1000,-930,-259,524,-318,1000,1000,-1000,-575,-1000,-1000,-539,-1000,797,1000,-1000,-753,690,-1000,993,-27,-420}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00186() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendPadding(int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-965,-1000,-334,630,20,-86,599,805,1000,-771,-1000,176,-146,-678,-927,255,404,-704,1000,1000,149,-545,675,-1000,312,202,326,273,1,-616,-476,-917,-646,82,695,1000,-1000,-1000,-304,1000,626,-1000,1000,-1000,-725,657,-1000,1000,764,-744,250,549,-1000,-822,-1000,142,1000,-1000,-289,542,-161,-743,270,-850}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00187() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendPadding(int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-1000,1000,-721,1000,643,558,-199,266,380,593,-423,-396,775,561,-266,-238,498,-883,910,-806,-395,24,-59,82,258,221,-639,841,-524,-973,530,-309,82,221,225,-192,1000,464,-281,-583,-169,460,731,-710,770,567,129,270,-654,-11,-229,190,111,-674,983,-93,-270,-206,-405,-1000,-604,-214,181}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00188() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendPadding(int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-637,-187,577,-884,85,666,517,-1000,180,-670,251,-1000,1000,322,-124,-83,79,-1000,-257,-346,143,-1000,-888,298,-774,-213,-1000,-141,548,-562,-1000,479,-838,-765,67,-29,208,-104,-1000,-1000,-945,-550,89,123,-225,544,1000,-396,-164,-322,758,-1000,293,-1000,868,259,490,-509,61,1000,-1000,525,288,-759}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00189() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendPadding(int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-861,-1000,-704,-13,-387,-86,522,936,550,-1000,-1000,173,-149,-428,-834,338,265,-254,396,512,505,-645,121,-1000,158,403,157,757,136,-1000,-511,-1000,-1000,-614,695,1000,-1000,-767,-260,1000,1000,-1000,1000,-1000,-684,657,1000,-221,1000,-977,568,492,-1000,-1000,-1000,356,1000,-212,14,429,-693,-893,70,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00190() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendPadding(int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-591,-1000,92,-996,20,693,599,805,634,-899,-490,-697,1000,29,-250,255,-152,-576,-909,517,-484,-682,-384,-862,-684,-213,326,-266,589,-731,-666,-942,-848,-903,1000,766,-1000,-1000,-599,524,-356,-511,352,-400,-494,760,-400,1000,764,-1000,267,-792,-1000,-597,-1000,1000,654,-1000,-327,941,-962,-930,135,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00191() {
        org.junit.Assert.assertEquals("THROW:java.lang.ArrayIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendPadding(int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-951,-326,-944,-288,-957,427,508,814,357,-1000,-1000,-7,-193,-432,186,487,-494,-654,661,1000,586,-688,175,-1000,-1000,591,84,775,194,-1000,-726,-1000,-1000,-806,1000,950,-1000,-1000,411,1000,1000,-1000,1000,-580,-443,657,-87,597,784,-1000,396,-65,-1000,-1000,-1000,448,1000,-1000,144,68,-777,-915,221,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00192() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendSeparator(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{347,-1000,666,1000,128,64,-638,595,358,-594,21,-1000,922,-717,1000,-495,-707,-793,-961,-306,-1000,-20,-629,-344,350,1000,-1000,-64,-783,337,1000,271,786,1000,-678,-1000,-825,1000,-761,-230,445,-970,355,-441,305,373,-511,-267,896,-809,1000,764,-497,670,-476,351,-575,-1000,541,-175,-341,-280,350,326}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00193() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendSeparator(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{54,54,503,127,1000,969,824,-134,-64,-447,-714,-623,1000,-1000,226,-556,-1000,-1000,-471,903,-1000,1000,-1000,-210,1000,538,604,-1000,496,-713,1000,-676,-260,451,250,-1000,-1000,1000,-1000,933,549,-1000,-829,228,672,127,268,1000,641,782,-121,-549,-695,102,-1000,263,-1000,171,-380,-343,-222,726,262,-174}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00194() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendSeparator(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{948,-116,1000,1000,294,-763,-628,348,-826,-1000,850,-1000,1000,-1000,154,-687,-1000,-422,-432,734,-1000,450,-738,-263,972,1000,-278,-1000,-442,572,1000,744,-451,718,-492,-65,-872,-993,-1000,1000,1000,-1000,1000,175,776,-210,-1000,-289,1000,148,503,1000,29,652,-386,707,-378,-1000,927,366,-99,442,-238,777}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00195() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendSeparator(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-74,506,-309,-1000,317,261,-26,404,512,400,-1000,261,-335,-1000,18,331,-597,-150,-663,713,-303,510,-570,400,-342,10,-650,110,656,950,-269,1000,313,440,38,254,-21,1000,-75,56,-38,400,-400,-1000,-125,952,879,218,293,968,94,264,687,-707,-366,5,-1000,466,581,-748,1000,443,-879,-102}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00196() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendSeparator(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{549,-637,-682,642,870,718,-521,-626,1000,-1000,117,68,711,-685,927,-1000,-643,-584,-617,359,-594,1000,-699,1000,1000,1000,74,-827,420,-317,1000,-421,239,1000,-689,-1000,-537,255,-479,991,988,-591,-1000,491,231,-522,1000,845,612,324,279,-390,-1000,411,-1000,-272,-985,406,825,460,-20,-146,-154,-156}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00197() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendSeparator(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{601,101,989,670,-546,-1000,-253,652,463,445,640,628,545,-124,1000,-1000,-67,-714,-607,309,-518,151,-262,672,188,953,-885,666,-653,243,-275,222,851,1000,181,-201,-475,152,81,-544,457,620,-67,-92,498,561,-400,-752,-152,-401,1000,253,-1000,519,25,98,-826,-917,678,134,87,-1000,-51,-324}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00198() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendSeparator(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{577,-637,-896,1000,-164,562,36,-1000,-278,-864,492,615,385,-1000,939,-503,-849,-326,-219,334,-341,1000,-1000,1000,1000,1000,301,-1000,581,-515,496,-806,729,1000,-6,-774,-659,-5,-342,1000,1000,-1000,-182,1000,410,252,-1000,856,309,340,279,-863,-629,-90,-795,-877,-805,172,1000,507,-438,-873,235,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00199() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendSeparator(char,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-684,-586,-1000,752,-89,6,209,-1000,707,863,46,869,-687,607,-136,-272,-74,-1000,79,-349,-1000,-763,-1000,-1000,-860,-1000,193,343,-929,-828,319,-68,643,-1000,-389,-44,75,475,513,-731,109,-776,486,-458,-86,39,65,514,-144,178,449,-287,-395,1000,288,253,-339,-221,-1000,-123,-319,-192,125,-341}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00200() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendSeparator(char,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-908,-204,-221,-686,-46,144,424,1,-361,511,449,-365,-203,-469,-824,-457,-313,-278,-99,31,-400,319,-677,-851,645,-347,1000,743,-671,-333,-303,-299,1000,-878,-884,378,-171,1000,318,-400,1000,-667,1000,272,-639,-345,-721,83,-175,1000,-459,-1000,270,-620,150,1000,-993,673,-1000,485,190,758,-340,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00201() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendSeparator(char,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-459,425,-207,-400,-679,-551,89,716,903,578,576,-783,528,372,761,-862,437,880,-421,838,-817,-970,-873,-838,-136,-109,-643,673,-278,-955,-327,-539,-817,115,-482,624,604,397,788,-764,732,484,145,308,211,820,-789,75,338,-842,970,794,-279,81,-286,159,-525,917,-603,433,-825,-334,-657,-558}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00202() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendSeparator(char,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-588,1000,-241,-686,-331,612,759,-37,-278,657,852,193,-203,-229,-547,-299,-1000,-468,-505,-778,-669,28,581,-1000,81,-1000,73,568,-1000,797,100,236,820,-47,-884,-492,653,1000,197,287,576,-989,940,-316,253,-125,-34,-192,189,14,51,-687,-435,443,203,1000,-464,779,-1000,-118,134,-384,-479,-768}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00203() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendSeparator(char,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{486,-1000,741,-585,589,-1000,93,286,-658,325,-1000,324,631,-493,-165,-983,-90,-477,-230,555,-300,-472,420,651,-955,-605,940,93,652,-1000,694,1000,318,607,-761,506,87,-273,-529,618,-1000,-524,319,272,813,-870,130,1000,1000,-693,695,759,30,173,510,372,119,-332,434,-914,963,-188,21,-137}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00204() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendSeparator(char,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{365,806,-402,-902,211,26,130,498,312,613,-407,-545,14,144,-25,-217,-861,-1000,-1000,-3,-51,-376,-1000,-609,671,-825,741,538,406,249,329,539,-273,-1000,-1000,945,452,-132,191,396,-1000,457,520,974,1000,-489,-331,1000,528,-1000,1000,53,-1000,-194,616,337,30,606,-625,-872,797,-145,484,365}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00205() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendSeparator(char,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{781,773,752,248,-177,244,216,-780,683,-285,924,-883,1000,-1000,-835,288,-1000,-276,-960,-276,28,1000,-581,449,-425,-424,-244,-868,-241,1000,-38,995,1000,-1000,-57,392,1000,-430,-931,657,1000,581,-592,479,-497,-1000,106,145,608,138,196,-1000,-863,-61,-794,846,-426,323,-248,66,311,-134,-93,-730}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00206() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendSeparator(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-509,395,-596,157,-119,-905,638,-519,462,1000,-630,24,310,135,-102,-740,-598,409,575,-261,-531,584,-590,-1000,12,-754,534,37,-6,-640,-489,-828,991,1000,557,-801,103,-673,-971,1000,-936,1000,908,423,-412,-12,-259,303,421,998,-486,-140,285,1000,620,296,1000,769,1000,441,801,267,323,-705}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00207() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendSeparator(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-712,57,749,-513,463,537,-268,-1000,384,181,-482,63,-1000,648,300,-453,1000,-704,1000,-1000,-586,-704,-1000,-1000,503,-874,-1000,1000,-831,338,-1000,-383,1000,185,668,-308,-438,-437,-33,561,-1000,990,1000,716,-481,-542,-719,96,965,138,-1000,-1000,551,844,1000,1000,178,-779,1000,1000,-23,791,1000,223}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00208() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendSeparator(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-901,-661,86,1000,-1000,-956,184,-883,-34,541,-596,-1000,813,-685,-418,-904,476,-90,1000,840,-895,-232,-497,658,-48,773,1000,-1000,-148,-426,-147,444,841,891,1000,-253,-919,-11,183,1000,320,-1000,796,449,-615,1000,-838,-239,-823,-736,1000,913,437,-386,147,296,-470,-113,-422,-39,-566,-380,-1000,604}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00209() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendSeparator(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,1000,138,305,922,-782,174,1000,-430,12,42,220,2,1000,1000,291,210,-1000,195,-109,1000,746,-366,977,-597,1000,-64,943,-953,1000,-543,427,390,-1000,937,-535,-732,-737,439,-151,-388,400,-1000,-249,59,-1000,-289,-162,-261,-309,-1000,-1000,399,306,-751,185,-907,139,-1000,312,688,1000,-415,-981}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00210() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendSeparator(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{894,47,636,886,0,-1000,-371,622,730,-1000,702,-498,400,1000,-141,-188,133,-38,-573,-961,-310,73,-237,-916,1000,-15,-652,604,-1000,-1000,-1000,1000,1000,468,-170,-212,160,573,561,304,-691,1000,773,591,-406,-336,177,-702,-296,852,-942,537,573,296,-780,757,742,-993,-640,158,388,-573,-153,-830}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00211() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendSeparator(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-1000,608,-81,-1000,739,-204,-1000,-36,1000,-2,-939,345,-808,-387,-493,-12,-120,1000,1000,-1000,-1000,-124,1000,-385,489,1000,-1000,-754,620,-168,-1000,996,1000,1000,1000,1000,-1000,-138,811,-1000,-1000,1000,476,-1000,1000,-1000,1000,762,-1000,1000,94,77,-1000,-231,-1000,-482,206,952,1000,-1000,885,78,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00212() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendSeparator(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-372,-495,623,204,-451,943,-668,-1000,-166,713,-489,1000,-117,354,-448,200,89,-1000,1000,-891,-1000,-887,185,313,303,47,-642,-256,-1000,1000,-953,-920,559,794,56,494,812,-1000,-846,693,-854,205,994,595,-652,508,-704,616,225,845,831,-391,-173,-1000,-658,386,140,-389,661,823,-330,280,-159,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00213() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendSeparator(java.lang.String,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,1000,-427,-870,94,-883,844,310,-524,-329,494,644,346,-636,-786,1000,167,722,-115,-506,-225,-811,-789,37,-1000,214,-1000,262,769,-1000,1000,-1000,-914,-247,835,691,728,728,1000,276,-759,722,-174,435,-1000,1000,-57,858,1000,1000,1000,736,-892,-458,1000,-797,242,871,1000,493,-1000,-264,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00214() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendSeparator(java.lang.String,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-904,-1000,-1000,-500,290,-406,390,832,913,-228,436,629,732,786,-366,-236,-1000,217,680,-403,-555,-10,356,768,-1000,1000,-609,-590,862,-1000,1000,739,26,817,-872,-728,34,-1000,1000,839,1000,607,195,1000,-1000,-373,-24,648,-289,-1000,-36,690,1000,245,-824,211,1000,-1000,-623,1000,-1000,-386,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00215() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendSeparator(java.lang.String,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{400,810,169,-12,149,525,-513,-812,884,463,-435,-1000,-1000,-156,1000,110,1000,-707,-1000,771,-138,220,346,181,447,-440,-733,-1000,1000,932,523,-30,1000,1000,-922,693,-1000,1000,-476,44,721,-424,1000,-17,-107,309,263,396,1000,653,756,937,1000,631,1000,-574,561,-185,-691,1000,397,-648,-1000,-687}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00216() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendSeparator(java.lang.String,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{75,-1000,-888,695,-700,-739,589,464,-928,412,417,26,914,605,-1000,346,-1000,-68,1000,-1000,129,-232,-765,542,-1000,-1000,42,-708,-181,787,-525,708,-945,-350,1000,1000,506,-1000,-917,869,-175,56,-1000,392,343,-46,-1000,-1000,-294,-554,-391,-1000,-826,-400,-609,56,176,-573,803,-1000,-758,-587,1000,684}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00217() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendSeparator(java.lang.String,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-1000,-29,-1000,331,356,242,1000,-905,-416,622,1000,1000,-69,-1000,428,-1000,626,1000,-1000,743,-1000,-1000,-216,-476,-1000,-1000,1000,454,-1000,754,-568,-1000,-1000,982,-542,1000,-297,-382,163,-831,1000,-1000,-542,1000,1000,-1000,1000,200,597,1000,-980,-1000,-734,-473,456,1000,1000,495,-1000,-1000,-1000,453,806}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00218() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendSeparator(java.lang.String,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{463,-889,544,-1000,88,-303,467,1000,-518,153,87,921,1000,100,-1000,66,-1000,104,995,-767,324,-743,-870,37,-574,-1000,-1000,456,226,-382,177,-318,-1000,-26,817,-192,978,-317,305,695,-1000,1000,-1000,-147,856,1000,-1000,274,-36,-362,510,-542,-1000,-1000,-61,224,628,1000,495,-821,-1000,-768,453,806}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00219() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendWithSeparators(java.lang.Object[],java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-253,-113,1000,542,1000,-521,1000,822,1000,-51,532,363,562,277,746,-719,-1000,738,-1000,-524,-570,416,-139,-94,-1000,792,288,1000,1000,-346,108,878,-21,-822,1000,856,656,111,-231,1000,251,-153,504,-67,-609,-570,859,313,-73,1000,-595,-225,-63,799,-104,1000,-811,1000,412,-506,427,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00220() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendWithSeparators(java.lang.Object[],java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-996,-256,878,-1000,378,-389,168,-153,1000,-737,-541,1000,254,-59,-1000,-1000,1000,538,-99,427,565,353,314,-483,39,-246,-463,1000,791,131,-44,1000,-1000,-624,556,1000,1000,-604,338,1000,1000,574,-943,-973,-1000,-407,851,-791,-244,176,297,-1000,4,645,920,1000,-1000,1000,593,-631,148,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00221() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendWithSeparators(java.lang.Object[],java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-514,-416,456,830,68,931,-870,-844,609,364,768,643,-727,989,675,-76,-987,-462,-378,44,124,-776,-928,429,-493,-622,755,-253,47,-707,922,479,-141,611,-752,-533,605,-894,55,766,548,786,-706,-308,-442,837,557,147,-81,-831,-717,993,438,-993,281,-441,93,-628,-305,-816,-721,78,635,-867}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00222() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendWithSeparators(java.lang.Object[],java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-136,-829,300,17,709,743,408,656,-150,936,23,-384,-388,256,52,629,-725,693,-839,720,173,299,299,488,-23,-200,-780,-74,387,-27,-871,920,803,-576,-773,996,-31,960,664,961,88,759,-882,-360,-561,201,-883,101,135,-595,-940,-541,-646,266,-132,645,-905,-904,226,-632,-692,869,-573,904}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00223() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendWithSeparators(java.lang.Object[],java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-82,79,80,640,-648,-261,-415,1000,-388,804,-927,-875,-123,905,141,-101,1000,328,400,-423,775,941,160,-564,1000,-97,-548,253,1000,643,194,782,195,-457,462,-308,-59,357,586,-704,839,37,-745,-268,44,-436,-833,-282,-813,-816,127,-321,245,651,-920,-73,195,125,-119,640,-1000,776,-1000,-281}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00224() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendWithSeparators(java.lang.Object[],java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-368,-997,-832,1000,-1000,790,-751,-554,-407,1000,-157,-774,436,1000,612,344,-783,-1000,1000,-499,164,-118,547,520,579,-498,403,523,1000,1000,816,-392,1000,-1000,-1000,689,1000,610,83,536,1000,1000,702,-826,-115,-767,-382,983,525,-147,445,-242,-225,-1000,224,249,1000,-1000,681,-475,-966,485,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00225() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendWithSeparators(java.util.Collection,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{659,816,-891,254,-678,-253,993,182,309,-589,502,-793,169,449,-583,557,-44,-739,-288,361,-220,65,-1000,842,138,-894,204,252,18,-1000,-180,-305,-36,251,-561,-8,-407,980,-617,-677,-326,187,500,485,1000,104,209,839,-827,-972,965,278,124,-105,979,84,130,-430,590,-906,-107,5,8,486}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00226() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendWithSeparators(java.util.Collection,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-164,623,-886,1000,-495,-152,1000,796,253,-1000,543,-158,402,86,-1000,337,-867,-1000,-117,-499,-1000,-179,-757,713,-184,-1000,932,220,988,-1000,-89,-1000,45,-601,132,-369,-8,685,-473,118,-704,-1000,1000,1000,1000,-193,359,217,340,19,1000,887,364,27,1000,-251,-1000,198,-121,-809,1000,-945,-700,839}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00227() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendWithSeparators(java.util.Collection,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{59,418,-213,1000,494,284,1000,874,187,-1000,396,1000,1000,1000,-367,429,-930,-597,491,-824,-1000,35,-412,772,-671,-1000,257,534,-954,-1000,-1000,-554,765,-167,197,221,-1000,182,73,569,-434,-1000,1000,1000,320,-946,897,152,318,494,1000,1000,-712,-390,152,-775,-1000,-501,-546,-475,788,-645,-556,75}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00228() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendWithSeparators(java.util.Collection,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{663,1000,-1000,-89,-667,797,630,-378,-116,-588,643,280,169,832,-92,1000,-12,-560,426,750,228,704,-700,1000,-838,-193,-12,1000,-1000,-714,-306,-722,392,1000,-1000,146,-663,909,-584,-566,-773,48,-579,-409,-821,-109,481,1000,-1000,-1000,195,949,-308,-378,458,73,-141,-1000,1000,-422,-740,1000,653,-712}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00229() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendWithSeparators(java.util.Collection,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,379,261,511,969,1000,477,24,394,-999,-171,1000,1000,-454,-299,427,-822,-464,1000,-443,-1000,-86,104,-485,-1000,2,-1000,1000,-725,494,-72,218,563,1000,-101,244,634,-615,-5,636,137,-1000,-541,-277,-569,-816,1000,1000,-185,498,-172,856,184,-1000,691,-1000,430,-187,-135,453,-184,735,918,-712}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00230() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendWithSeparators(java.util.Collection,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,513,574,977,1000,1000,1000,-326,984,-659,470,863,-356,157,-1000,-529,-1000,-726,1000,-1000,-1000,-253,-1000,-760,-446,957,-1000,1000,-808,-7,-521,-153,802,1000,-698,827,142,-236,606,876,-220,-1000,-440,-78,1000,-876,1000,712,-1000,674,-78,1000,-572,-1000,1000,-976,615,-1000,901,-174,-899,586,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00231() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendWithSeparators(java.util.Collection,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-40,544,-1000,-1000,454,-763,-1000,1000,1000,-363,131,1000,-54,-1000,648,1000,-602,-1000,729,1000,-1000,272,-853,-466,-1000,-487,-68,-593,-1000,353,1000,466,898,430,-1000,-1000,262,217,-1000,-730,441,-495,-791,433,1000,761,1000,-487,-429,-995,358,-259,542,-1000,-108,-54,-451,-895,-707,-1000,-543,804,-683}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00232() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendWithSeparators(java.util.Iterator,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{369,-1000,-589,696,-170,-592,-398,509,-781,741,728,567,-1000,-136,383,-342,126,1000,200,1000,-485,1000,240,1000,814,1000,806,1000,-1000,733,1000,-68,-86,574,-1000,-1000,-282,-193,-607,-1000,974,-1000,-883,-1000,1000,-518,191,-1000,636,-527,1000,1000,-903,-256,432,935,-1000,1000,358,68,-88,-333,-288,485}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00233() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendWithSeparators(java.util.Iterator,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-882,-378,-156,-646,-336,354,621,-121,97,1000,-1000,-408,1000,1000,751,343,1000,-1000,-580,185,-211,-1000,-775,491,910,-1000,-261,-832,-130,-1000,-1000,-49,-599,-1000,444,1000,-1000,-1000,1000,-925,-370,358,-819,180,-283,1000,1000,352,-157,194,-954,785,162,73,-730,-263,-333,-1000,-129,439,851,-414,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00234() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendWithSeparators(java.util.Iterator,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{454,-1000,-959,348,93,129,68,1000,-1000,356,163,165,-331,-127,154,-238,469,315,1000,514,-828,867,-1000,893,1000,108,1000,463,-1000,-802,456,-471,-258,645,234,-917,-258,323,952,-799,546,-1000,-1000,-38,1000,-1000,-326,-1000,1000,-782,121,1000,363,-724,583,568,-1000,867,651,-397,-114,-405,-574,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00235() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendWithSeparators(java.util.Iterator,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-69,-1000,301,1000,239,-698,-851,188,-551,826,376,-114,-85,754,459,12,240,597,22,907,-809,181,-692,874,588,678,1000,639,-709,-91,194,1000,135,759,-1000,-908,-710,828,376,-1000,-278,-1000,-931,-493,884,-545,499,-573,532,-367,223,1000,-799,-252,-419,-311,-1000,1000,961,405,578,-19,-174,400}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00236() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendWithSeparators(java.util.Iterator,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-69,-1000,-464,438,337,344,-353,188,-479,826,-350,-681,-514,-643,459,25,531,635,22,1000,-537,181,-692,874,588,678,723,974,-1000,178,194,-1000,-366,289,-1000,-596,-389,828,1000,-1000,-30,-1000,-931,-493,1000,-545,560,-626,339,-367,838,1000,-2,-252,216,779,-1000,1000,138,519,48,-339,-174,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00237() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendWithSeparators(java.util.Iterator,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-249,1000,471,888,-91,-771,-1000,-382,307,554,160,567,-1000,85,-890,-363,-1000,-178,-189,-230,186,337,240,1000,-317,652,75,-126,-455,1000,-51,533,316,-695,-117,910,-484,-193,-607,-181,974,-65,-492,-1000,-409,452,695,1000,761,-493,916,-766,601,-359,-254,-725,1000,-810,1,647,818,-287,341,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00238() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(boolean):org.apache.commons.lang.text.StrBuilder",
            new int[]{-316,-354,-86,631,-152,61,146,-93,166,718,-746,-19,-478,1000,1000,71,155,-557,-1000,-600,-256,-55,673,-293,784,271,543,484,552,177,659,-452,865,-1000,-51,-281,671,-332,-196,539,1000,-1000,542,-374,749,-278,-1000,585,-394,992,287,812,100,306,-662,-859,-933,49,454,223,350,-494,1000,-568}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00239() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(boolean):org.apache.commons.lang.text.StrBuilder",
            new int[]{-887,-613,1000,-20,-279,-660,293,1000,-103,-1000,1000,157,1000,-349,-421,-502,-1000,-11,868,-199,-212,454,-103,-46,-1000,-644,270,-226,-534,-1000,654,1000,-453,-572,382,162,-529,-837,1000,-968,-361,-1000,415,1000,490,-45,-1000,-195,456,-387,-617,-1000,-996,-150,910,1000,-397,256,1000,-1000,919,1000,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00240() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(boolean):org.apache.commons.lang.text.StrBuilder",
            new int[]{-192,967,-154,65,59,-481,752,-669,716,388,23,509,214,-504,1000,124,-333,-433,-609,714,34,-534,724,1000,295,-160,-505,-390,374,816,-722,-245,1000,-32,713,-121,624,-254,130,837,297,-22,-1000,-222,835,845,-712,-52,-6,828,-299,1000,965,555,-982,101,-408,617,-82,840,-742,494,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00241() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(boolean):org.apache.commons.lang.text.StrBuilder",
            new int[]{-119,-640,-586,1000,-520,561,-82,689,329,718,-1000,709,-903,1000,610,237,26,30,-36,-949,-529,-1000,1000,-730,784,1000,760,1000,1000,-22,659,-758,872,1000,-270,-560,-1000,-143,-1000,1000,-1000,-1000,542,-1000,339,-236,-187,115,-1000,992,885,1000,-408,617,-1000,-966,-933,-274,511,-46,364,-1000,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00242() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(boolean):org.apache.commons.lang.text.StrBuilder",
            new int[]{-847,-352,849,-1000,-317,-471,-705,-83,368,-1000,1000,-499,-126,-625,-741,-195,317,-703,466,-167,-641,607,-1000,-524,-1000,-681,331,-105,-62,249,-1000,1000,-267,325,653,-1000,-1000,-494,408,69,668,-1000,-314,-423,773,-120,23,-430,839,-1000,-513,405,988,155,1000,453,-408,-414,-524,-837,-498,-426,-859,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00243() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(boolean):org.apache.commons.lang.text.StrBuilder",
            new int[]{-457,-352,-432,1000,-173,549,-38,181,621,781,-1000,327,-809,1000,1000,347,277,-711,-748,-644,-945,-972,673,-514,865,697,861,658,749,177,734,-724,756,-301,-323,-748,373,-105,-796,837,450,-204,542,138,390,-278,-661,348,-640,863,379,497,182,197,-704,-1000,-960,-37,1000,-129,534,-798,779,-432}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00244() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-32,392,-25,-567,939,-757,-286,219,430,833,899,-633,-406,790,522,880,419,-1000,366,-63,-372,-918,-1000,-42,-484,-116,-628,909,710,-1000,209,123,137,-533,321,259,-126,-895,-1000,-1000,-239,953,-384,-1000,-850,-146,161,97,-512,-767,-20,-249,-747,-84,23,-756,431,-592,277,-658,430,825,285,-821}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00245() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{876,345,-436,288,-163,-498,-208,1000,184,1000,-792,-1000,-918,-380,626,69,214,-1000,-1000,911,-313,-509,-586,172,-1000,-215,-1000,1000,910,-456,1000,-91,-945,-494,-967,-795,945,465,546,-507,-549,384,-549,-1000,-846,736,557,783,63,-902,-1000,-261,-268,843,168,445,1000,-720,238,-594,392,1000,1000,26}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00246() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-359,34,-1000,691,644,1000,122,311,-114,-576,-1000,-592,894,-59,66,-1000,742,-848,1000,-259,1000,-694,-1000,-983,1000,1000,1000,400,-839,-1000,-1000,-781,-275,982,962,-515,406,1000,-540,1000,1000,186,1000,1000,-58,-922,-1000,-1000,-668,-400,-270,61,-1000,601,-487,1000,-832,1000,544,-1000,1000,-187,-1000,-265}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00247() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-8,-119,-863,263,304,507,290,-181,49,-384,-1000,-835,1000,-1000,246,-755,1000,-918,1000,124,-372,-1000,-1000,-42,53,-116,129,739,-34,-1000,403,-1000,-256,-533,345,-614,363,86,1000,574,-239,685,652,325,-40,-146,-1000,-1000,-596,-827,-488,-223,-1000,194,561,1000,-646,584,493,-1000,1000,5,-438,-602}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00248() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-438,392,-138,-554,214,255,-236,-168,229,-617,-292,100,1000,120,-190,-8,373,11,597,-704,440,-579,-588,-1000,1000,1000,822,-683,75,-494,-1000,-465,536,1000,1000,154,-65,-1000,1000,30,466,248,726,1000,-518,-1000,-1000,286,-629,247,645,-197,-1000,-606,-601,838,-645,152,399,-427,763,12,-1000,-344}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00249() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{427,-340,-320,917,-520,-182,-483,338,185,492,177,-782,-889,209,693,951,30,-456,-646,457,741,621,433,939,361,-738,-562,537,-453,531,889,285,-5,160,332,-446,-479,600,-992,-545,-951,-685,-584,570,-88,313,860,812,8,-85,-5,218,-437,264,374,31,-480,-818,-954,-409,-97,666,-631,192}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00250() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{346,812,699,-290,-630,87,39,129,651,-101,1000,-946,826,562,1000,908,-214,-789,-713,-297,-708,577,-34,-663,-572,-402,-1000,-285,1000,-37,59,748,-68,283,-1000,-713,411,-658,340,-366,-909,987,-1000,-1000,-552,1000,620,912,-279,269,-24,72,202,167,427,197,1000,-991,338,-444,263,388,1000,-136}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00251() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-60,452,-892,1000,1000,583,394,396,148,606,-1000,122,102,-1000,342,-766,1000,-1000,141,1000,3,-534,-1000,-770,-520,752,-411,1000,-9,-646,1000,-859,-1000,283,-888,-1000,1000,1000,1000,1000,627,660,436,653,-780,-1000,-1000,-1000,153,-602,-1000,-8,-730,1000,88,804,-150,1000,139,-1000,760,-53,-577,188}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00252() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(char[]):org.apache.commons.lang.text.StrBuilder",
            new int[]{847,-523,255,478,-799,-155,-310,376,-958,609,-15,856,1000,-77,786,-1000,-81,104,876,665,958,-1000,-393,524,-951,644,-396,-33,1000,-865,-1000,-426,48,-923,-139,1000,-728,531,964,-86,432,-429,-144,-271,-1000,986,782,421,308,-1000,-486,-867,486,-556,228,-1000,324,209,-204,1000,-72,1000,533,-819}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00253() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(char[]):org.apache.commons.lang.text.StrBuilder",
            new int[]{-262,-780,674,952,841,-427,767,-239,300,-879,-196,187,286,469,154,-478,670,241,1000,-208,246,1000,356,34,-528,579,331,-1000,351,-974,-940,216,-174,-692,239,1000,175,389,706,1000,-495,1000,-592,-302,-218,1000,-1000,-408,436,-470,-486,-440,-830,73,301,126,-785,-571,1000,242,-92,772,-13,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00254() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(char[]):org.apache.commons.lang.text.StrBuilder",
            new int[]{221,-503,491,149,-44,308,145,-184,-481,162,-1000,-9,68,-927,1000,107,-654,563,-609,-136,605,-268,-513,154,585,-282,1000,-260,708,-1000,-835,-449,361,-614,233,48,-1000,392,1000,400,-739,-675,-747,-868,-798,-70,-88,418,-417,-339,-415,-464,789,-828,-806,-792,-136,-628,-793,580,-270,1000,-967,-504}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00255() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(char[]):org.apache.commons.lang.text.StrBuilder",
            new int[]{-649,-1000,-86,-1000,849,79,-59,-787,-248,-1000,552,-407,1000,-958,430,-1000,-929,687,109,-497,1000,-163,-353,1000,16,1000,-1000,-638,82,-1000,-1000,-1000,-997,-766,92,945,-333,-417,313,96,-1000,1000,-1000,-888,-107,232,-960,58,-554,-591,-1000,110,-235,-504,-823,-1000,1000,-206,68,446,638,874,-284,729}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00256() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(char[]):org.apache.commons.lang.text.StrBuilder",
            new int[]{400,-1000,-327,1000,769,-954,-321,-818,395,-903,778,132,852,-1000,-306,-547,-1000,-363,1000,-753,1000,169,527,755,-1000,1000,241,-661,151,-818,-576,506,-134,-283,1000,1000,-1000,721,-127,826,659,-266,-188,-929,-532,1000,-1000,-361,-233,271,-423,697,-1000,-873,-213,-1000,815,-554,1000,955,-824,914,-818,-14}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00257() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(char[]):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-313,-240,220,375,-536,-743,-45,-396,-789,-498,-278,1000,-245,836,-199,642,-450,732,194,1000,-330,686,-1000,-1000,1000,-866,-69,-240,198,-886,-447,-250,-510,24,1000,-440,-317,1000,-1000,-102,1000,694,-17,-465,-805,-477,-319,-1000,-362,-746,587,979,59,727,-764,1000,1000,1000,-651,244,-44,-379,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00258() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(char[],int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{85,-1000,-361,-204,-584,-416,-728,729,-254,-552,810,923,517,535,898,-1000,738,-1000,572,-571,564,743,-236,10,-467,818,-150,301,319,-810,406,208,15,1000,256,320,430,139,-310,-549,981,364,692,617,-64,-558,787,-141,212,-1000,-1000,357,1000,-305,837,-77,432,-4,365,-867,711,647,539,214}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00259() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(char[],int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-531,-279,699,966,-344,800,-403,137,579,-194,379,-465,-802,37,-1000,276,-751,-192,-993,705,557,-909,97,112,665,-590,629,-255,-770,693,354,-264,69,-1000,-346,64,-209,728,591,966,-86,164,-1000,-721,-701,692,-1000,753,207,751,205,-381,-1000,700,-14,264,276,-561,-92,1000,-241,-1000,-901,401}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00260() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(char[],int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{533,-664,-547,-199,488,-720,-338,958,172,761,-868,637,854,-148,945,-876,445,59,-524,949,-487,629,-381,4,-637,308,475,-659,-359,-770,685,962,-768,373,877,926,-956,-184,593,-835,699,-115,512,-432,-891,-799,-253,76,-553,639,607,815,135,248,-697,600,-892,-719,792,569,846,-305,-814,135}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00261() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(char[],int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{783,-203,-741,-906,-267,-1000,-141,708,-447,-794,-303,633,1000,-674,1000,-915,1000,-590,1000,-960,-185,1000,-89,-749,-570,946,-339,-288,697,-1000,208,697,148,1000,585,327,545,-896,-439,-1000,616,-76,1000,1000,493,-1000,83,-1000,-3,-1000,-948,224,1000,-881,828,19,163,195,576,-1000,987,1000,1000,-861}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00262() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(char[],int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{126,-193,-1000,109,639,-1000,-516,485,677,263,-317,1000,796,-1000,935,-1000,1000,486,676,262,-346,1000,564,-449,-1000,1000,563,-501,-382,-1000,122,1000,-1000,-1000,784,898,-1000,735,453,-711,23,-1000,480,-1000,169,-462,-1000,-139,325,-394,1000,797,-516,332,1000,425,-692,58,-38,337,406,-43,-654,914}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00263() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(char[],int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-696,-799,-306,-549,117,-406,-904,958,163,92,-868,591,249,-148,-633,-876,382,-826,-524,-572,-822,1000,-364,598,-310,308,133,59,-448,923,640,-467,-465,-111,-509,-1000,489,672,-760,-619,-467,-17,-734,936,20,492,150,76,-553,-118,-537,706,-275,-206,35,225,-437,-1000,-860,-79,-232,-481,-814,270}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00264() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(char[],int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-133,-384,585,-1000,-901,69,-455,548,91,138,830,227,-1000,-551,-777,1000,8,640,39,-400,882,1000,-690,-1000,1000,-412,83,-1000,1000,-67,1000,-1000,-1000,-477,-577,308,1000,-1000,1000,70,-1000,-1000,-768,170,1000,-1000,1000,1000,1000,1000,-132,-1000,818,756,-1000,1000,1000,-1000,248,-1000,358,468,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00265() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(char[],int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-236,-1000,-1000,-235,-109,-1000,-186,447,494,-335,-392,1000,1000,-1000,-44,-728,339,-522,-411,87,-1000,961,-1000,-468,-1000,1000,161,-969,-994,-678,253,1000,-1000,938,155,-70,-774,161,-988,-360,765,-897,320,-424,33,-565,151,1000,1000,470,-704,1000,-915,63,254,-498,-218,456,-943,904,260,297,334,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00266() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(double):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,776,612,240,860,-426,-14,-219,-584,258,-23,1000,-902,-114,627,896,324,624,-897,537,-48,251,-10,1000,-908,-355,500,827,209,1000,183,-31,1000,-166,-449,-752,911,-1000,-303,-121,270,984,-48,-1000,55,-504,432,-786,-851,-1000,291,510,611,-851,-400,-12,-453,401,845,-7,-898,-374,326,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00267() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(double):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,363,864,198,-249,680,123,242,84,566,-428,-42,-310,-1000,-124,70,-766,-202,-867,397,503,33,-566,-443,-365,-600,979,-682,562,947,-625,-1000,476,1000,-283,1000,988,-945,425,-247,570,439,657,1000,-794,1000,-2,167,-817,1000,-494,-228,755,922,-424,-1000,-1000,-532,-552,1000,-217,-1000,-214,705}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00268() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(double):org.apache.commons.lang.text.StrBuilder",
            new int[]{-851,-523,-1000,647,-533,-511,-811,801,-1000,61,283,984,-61,1000,1000,67,-1000,-648,571,644,463,1000,740,1000,-759,598,-286,1000,-879,347,197,370,139,-731,-1000,-854,-250,140,-996,937,94,-1000,-644,-1000,1000,280,-1000,507,493,-462,-1000,-523,-231,353,355,384,-848,-640,82,1000,166,1000,1000,397}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00269() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(double):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-744,-16,69,-1000,280,945,669,-268,522,-708,120,44,383,605,312,-1000,-568,-303,394,1000,-613,-127,-1000,-239,239,783,-482,648,121,-503,-477,-313,601,-798,558,570,357,905,287,-598,-162,973,984,-164,1000,-963,1000,-640,1000,-444,-802,904,1000,-192,-1000,-197,-185,-745,725,540,-722,-432,97}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00270() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(double):org.apache.commons.lang.text.StrBuilder",
            new int[]{73,631,-1000,280,598,-566,85,-691,-1000,284,-142,-223,-104,864,65,35,1000,-591,-574,-596,-1000,377,740,1000,110,-189,-68,599,-88,1000,197,223,811,-451,1000,584,-211,-478,-996,-1000,833,1000,-1000,-709,-323,-1000,1000,-393,1000,-145,95,-921,-231,-81,-471,-76,-1000,993,634,-584,-1000,-390,253,404}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00271() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(double):org.apache.commons.lang.text.StrBuilder",
            new int[]{957,143,-358,478,53,184,-175,-241,-1000,275,1000,-738,-281,464,59,-1000,456,251,-856,358,-280,-513,-1000,-241,1000,74,439,210,725,1000,-11,-329,532,145,-1000,1000,1000,-614,475,-281,660,976,-542,689,-1000,-946,204,435,1000,497,-569,-588,90,488,-30,-396,-800,139,-953,-397,-231,-965,48,859}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00272() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(double):org.apache.commons.lang.text.StrBuilder",
            new int[]{305,263,944,-365,280,569,-111,-589,-104,-195,-301,-954,734,-444,-755,715,921,634,-954,-828,-839,-210,-564,182,342,-758,-351,-503,75,788,-449,579,454,-90,-750,703,-181,970,-175,-464,-628,395,-974,-131,-862,534,944,763,922,809,372,-940,697,708,872,-73,-852,-814,399,945,990,-858,-262,-960}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00273() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(float):org.apache.commons.lang.text.StrBuilder",
            new int[]{-283,-10,-259,-373,-297,-7,969,951,15,1000,-844,539,191,-1000,612,192,-408,162,-299,19,-1000,679,-372,-225,589,939,1000,1000,-96,275,492,1000,1000,-431,-475,-64,364,1000,-873,863,-241,-1000,762,125,779,-562,165,185,1000,759,987,674,833,394,715,-331,329,92,216,-431,1000,-168,-215,-225}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00274() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(float):org.apache.commons.lang.text.StrBuilder",
            new int[]{-350,-396,524,416,780,13,208,263,963,332,-142,-49,-342,-259,1000,1000,1000,621,-583,70,-808,528,-576,-530,-245,211,-214,1000,394,444,182,-323,1000,-623,41,935,658,948,852,1000,523,29,760,787,1000,-1000,1000,857,1000,-194,-646,-7,872,-168,-1000,-815,-224,1000,892,115,741,-762,-872,524}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00275() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(float):org.apache.commons.lang.text.StrBuilder",
            new int[]{529,544,-239,-344,464,-471,496,760,251,1000,-308,884,670,-898,59,579,-1000,-405,-952,358,-1000,58,-695,710,874,915,1000,1000,-129,131,-591,321,743,-1000,-570,-615,83,1000,-410,1000,1000,-1000,575,234,489,-157,-62,444,1000,1000,-950,843,-259,137,919,-161,861,-269,-110,196,1000,223,268,-27}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00276() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(float):org.apache.commons.lang.text.StrBuilder",
            new int[]{208,840,573,-623,-940,-466,-372,65,-214,238,-271,-943,-1000,-300,-145,453,75,53,790,1000,-544,-534,621,733,1000,1000,237,869,52,-613,425,-132,370,-326,-1000,410,387,654,-269,240,380,-413,226,267,-19,-370,885,675,828,310,1000,-140,759,85,302,-538,795,126,-37,4,529,-785,-719,-950}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00277() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(float):org.apache.commons.lang.text.StrBuilder",
            new int[]{486,614,-1000,-197,-1000,-30,7,336,-1000,-665,791,-318,21,-893,806,-1000,-598,-159,453,1000,1000,553,-543,-738,395,1000,527,-1000,-159,-769,1000,1000,689,1000,-1000,460,-1000,-726,-1000,-1000,-114,185,93,-1000,-358,-302,762,-91,-1000,627,-1000,-1000,816,471,1000,-45,-553,-1000,606,581,-1000,-581,8,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00278() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(float):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-324,-61,-604,-864,-1000,513,-496,-1000,-1000,-601,564,-323,-227,-809,869,232,1000,226,196,-425,-408,-656,464,284,782,416,-551,385,-819,664,-1000,655,367,-27,1000,-312,312,-1000,-718,242,854,815,-80,-970,-661,361,976,-918,-50,494,1000,47,-364,-587,28,-313,478,1000,281,-897,-199,-1000,-201}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00279() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(float):org.apache.commons.lang.text.StrBuilder",
            new int[]{-18,38,-592,-197,-276,-336,7,852,279,824,400,-200,27,-1000,166,-1000,-6,1000,626,285,-228,-1000,70,-779,288,1000,650,-243,462,421,783,1000,496,960,-405,487,-437,351,-1000,1000,173,-1000,765,89,-280,-900,-307,-1000,-684,481,68,681,1000,-134,1000,-266,385,989,-511,-989,159,-327,114,-924}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00280() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,534,504,95,-504,1000,942,-534,357,-984,-755,-191,-756,484,-39,282,27,216,19,-1000,1000,-1000,1000,114,-1000,-892,-1000,-1000,-391,977,-1000,-789,-1000,1000,426,-512,659,-582,495,1000,886,-1000,1000,-202,426,-546,919,-790,135,1000,0,591,867,246,-94,-147,-567,-509,285,278,-1000,675,767,-990}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00281() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{608,677,241,-539,-1000,609,323,793,719,-841,-590,114,97,-709,-728,-704,-1000,-469,748,66,881,-507,-336,-298,1000,-1000,-485,736,251,-399,935,1000,-914,-356,-187,-361,775,75,-576,67,-959,726,-144,535,355,-600,754,-270,270,-1000,-1000,771,944,29,741,-493,-989,610,557,1000,-141,1000,545,-423}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00282() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{504,1000,-393,-359,-663,495,-353,224,-370,305,-751,1000,-648,-905,-1000,432,-531,-709,319,1000,504,1000,357,-768,-1000,-345,295,-9,15,632,423,-176,-1000,-1000,-579,-346,602,-249,-1000,681,-575,-1000,-1000,-533,1000,-824,820,-417,-141,-29,-867,320,1000,521,1000,518,-847,496,382,703,-251,1000,-853,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00283() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{552,1000,-91,-67,-941,-208,-1000,-311,-209,458,967,925,691,-1000,-315,719,-1000,-270,-452,1000,-1000,1000,-610,-119,-1000,-525,1000,413,248,-1000,668,-391,-1000,-1000,55,-1000,-187,598,-332,262,-1000,-1000,1000,1000,1000,-49,1000,-454,-517,315,-1000,447,1000,452,1000,1000,-1000,1000,1000,27,570,1000,804,-366}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00284() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{906,243,704,35,-1000,907,981,-746,502,-974,25,-138,615,-567,154,235,-1000,8,256,401,1000,-313,1000,-72,-1000,-235,1000,-457,-351,4,-572,-1000,-1000,803,440,203,638,211,462,982,908,-1000,287,-890,530,-1000,754,-776,-803,1000,137,564,1000,-131,163,209,-755,-84,1000,-481,-951,1000,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00285() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{813,196,-359,-378,104,297,-744,-408,1000,464,-567,231,-92,-864,16,-93,-715,-96,186,-446,836,776,1000,605,-301,-790,10,730,-73,-971,60,-23,-1000,147,-369,212,-800,-1000,158,489,17,-625,688,416,-298,-946,416,-270,281,-466,-168,1000,739,236,1000,-987,-664,862,836,255,-1000,-92,-861,892}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00286() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{819,405,529,-185,-31,944,-419,-545,719,-789,-575,36,758,-709,679,4,-695,449,-962,1000,-400,400,544,-21,-1000,-148,1000,736,-351,-380,-320,-730,-348,-439,-187,-400,-154,403,-359,783,426,-977,-144,-405,939,-171,191,-270,-227,787,-273,1000,944,-150,640,209,-379,314,900,-14,-319,236,202,-423}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00287() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-1000,448,1000,-205,737,-518,-512,-220,-239,291,-812,-1000,-340,-333,1000,220,-766,726,-1000,1000,-1000,1000,410,-984,207,-1000,-1000,-1000,1000,1000,-1000,-1000,1000,1000,1000,1000,1000,896,1000,-1000,-1000,461,-1000,1000,-695,892,-1000,-1000,1000,1000,801,1000,-471,-67,400,-821,-1000,-311,-108,-1000,1000,-693,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00288() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(java.lang.Object):org.apache.commons.lang.text.StrBuilder",
            new int[]{331,1000,105,875,-11,-479,97,-851,1000,919,-815,-85,135,1000,-483,535,707,942,-778,1000,849,1000,20,520,579,-21,600,24,-1000,206,-627,1000,-666,888,126,67,455,-333,-87,-181,442,-1000,563,60,-690,466,-79,210,1000,1000,-556,522,-988,-946,-487,-1000,1000,-740,614,-20,-392,24,960,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00289() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(java.lang.Object):org.apache.commons.lang.text.StrBuilder",
            new int[]{-558,134,2,53,517,-567,144,-961,731,252,-667,-1000,275,637,-635,-1000,864,-1000,-270,412,500,1000,-142,-159,-1000,-229,-597,697,-455,784,-963,-158,-199,-59,459,-224,-136,-106,201,-936,541,249,-14,926,271,-762,575,398,1000,664,-66,-579,-443,-583,-322,-1000,1000,-915,364,1000,-459,-228,924,-7}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00290() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(java.lang.Object):org.apache.commons.lang.text.StrBuilder",
            new int[]{705,-726,63,701,326,-224,355,-53,801,-342,-439,600,-457,-376,-592,398,-376,400,-85,135,-111,-130,1000,472,609,407,-370,-288,-557,490,-42,154,-171,797,-620,1000,368,-823,163,374,247,-461,549,-511,-785,886,-461,-875,1000,-116,-465,614,558,-258,-289,-38,735,235,-1000,859,-312,-383,-450,-263}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00291() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(java.lang.Object):org.apache.commons.lang.text.StrBuilder",
            new int[]{-558,-53,205,138,432,-493,90,-421,811,664,-492,1000,351,658,-284,-198,907,-1000,-540,338,873,695,662,771,-1000,24,-597,606,-432,598,271,-297,-102,115,473,-824,54,-380,446,-875,462,328,-985,1000,455,-1000,168,320,1000,607,334,-625,-966,-295,-243,251,1000,-833,455,1000,-576,-197,1000,-14}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00292() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(java.lang.Object):org.apache.commons.lang.text.StrBuilder",
            new int[]{45,392,444,-95,-563,230,883,632,360,36,-358,460,1000,462,381,610,-456,-982,-1000,482,805,546,500,27,1000,822,613,-607,-738,52,515,961,-995,452,-677,-771,-375,-662,512,-537,-777,-1000,-93,510,-230,35,1000,643,1000,86,-675,262,-1000,-564,-926,-1000,1000,-501,1000,-541,-1000,-225,258,-496}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00293() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(java.lang.Object):org.apache.commons.lang.text.StrBuilder",
            new int[]{-571,-677,160,757,223,-703,617,527,794,752,-370,1000,891,678,-1000,-141,1000,-1000,-678,254,-48,975,763,531,-686,83,-1000,715,-497,941,161,15,-462,102,580,-814,-217,-393,965,-1000,659,-278,-350,1000,432,-1000,1000,237,1000,762,219,-444,-1000,-621,-683,-235,1000,-883,989,1000,-520,-366,1000,-411}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00294() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(java.lang.Object):org.apache.commons.lang.text.StrBuilder",
            new int[]{-426,812,496,63,-1000,-502,1000,331,334,-354,137,1000,-824,-1000,-614,862,-658,-672,-49,-1000,63,31,-719,-40,-1000,51,-438,383,-946,201,376,-986,452,-199,-466,902,-148,234,-707,-385,-625,1000,983,-455,670,-1000,-161,-724,353,-557,66,177,366,-806,53,-1000,-670,974,-98,504,-492,-94,522,-210}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00295() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{189,536,383,842,-597,887,877,261,-482,-621,927,-25,481,814,-865,74,786,-963,308,652,532,647,-295,-31,269,199,280,361,-740,260,-362,655,893,-486,642,-914,-116,-670,727,320,-356,-350,-172,98,739,921,-462,-805,692,-137,632,943,-417,-672,389,-599,845,235,-694,393,469,622,737,-903}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00296() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{997,-681,359,-634,428,-42,-245,-992,1000,870,1000,766,242,-416,426,-543,-192,-284,-563,1000,-276,-109,103,465,-494,-965,120,-89,-219,20,563,356,78,528,306,159,266,54,-35,850,813,-1000,385,190,80,293,1000,-819,702,494,821,-77,-1000,-145,-602,550,354,-883,968,-633,-196,666,-431,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00297() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-644,-363,-66,-866,652,-993,-1000,42,1000,1000,139,1000,992,324,-1000,-229,-938,916,1000,-786,-1000,-194,1000,-956,-399,1000,-391,-300,1000,1000,1000,-257,227,484,339,858,-40,-360,365,1000,-1000,-226,1000,126,126,1000,483,637,330,1000,-142,-1000,-1000,-1000,-419,1000,-99,1000,1000,-1000,-427,-987,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00298() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-673,-530,-6,-324,453,-626,-481,-1000,-1000,-711,-1000,-407,560,111,56,-357,109,620,-906,-62,-596,955,869,705,939,975,216,-407,1000,-558,437,845,208,-469,-636,1000,-1000,1000,346,-693,1000,-55,-543,-918,-989,-278,-943,1000,-544,-594,-999,-618,-343,58,740,-199,423,1000,-932,-284,26,-1000,115,740}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00299() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-546,-1000,344,992,1000,-951,254,346,486,773,463,-244,-976,-30,83,532,42,498,190,-501,-166,1000,766,672,1000,333,-264,883,1000,1000,-660,-68,1000,-1000,-1000,396,-466,-343,547,443,-34,-1000,-926,-1000,-425,292,-1000,506,379,1000,-198,943,1000,-193,979,789,188,-114,-676,-373,930,-287,737,-66}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00300() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-674,230,118,-646,22,34,104,-495,429,472,-899,-598,94,-961,-562,-107,-1000,708,-1000,-657,268,-633,823,-646,1000,781,-591,-400,512,254,-620,63,-373,1000,24,102,-1000,1000,-579,-564,288,909,126,1000,-673,387,-794,1000,-1000,-925,-1000,-581,-565,634,280,-1000,-634,1000,-1000,585,-486,-915,196,857}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00301() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-453,-1000,384,-1000,151,-494,-951,-1000,-200,-104,-268,436,1000,1000,1000,-103,-1000,564,1000,-39,-384,-1000,628,605,-526,-478,430,1000,681,440,1000,1000,608,-1000,1000,1000,-240,197,-310,508,716,-569,-1000,303,-1000,655,-543,-8,724,-550,1000,674,-728,-468,-88,942,-232,-371,1000,547,-1000,1000,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00302() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(java.lang.String,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{534,-832,857,-288,1000,-421,-191,171,-1000,384,-284,481,1000,-547,-472,-608,244,-133,-138,132,914,-281,-943,-1000,-508,-521,31,-120,-45,-360,1000,-465,193,69,-70,-3,62,1000,982,-224,-138,-586,-337,347,-917,-317,156,353,1000,643,-316,-945,-213,883,-268,-156,221,-285,-910,792,344,785,-702,950}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00303() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(java.lang.String,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-741,-781,-422,529,1000,-68,556,-315,-808,-426,-728,487,-744,601,643,942,-468,-608,953,1000,-658,947,-1000,-675,-983,-331,275,-585,-82,-557,1000,200,1000,426,-979,395,1000,1000,309,-240,-1000,-251,1000,-915,-1000,-418,-603,-34,-470,151,278,-388,-1000,867,1000,-1000,-1000,-1000,361,78,214,-343,-437}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00304() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(java.lang.String,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{918,-539,-96,588,324,746,-1000,838,66,-203,-858,-1000,1000,-406,-487,-708,-361,519,167,-1000,398,-1000,-822,-967,-898,-553,402,-1000,-426,580,353,70,-381,1000,427,478,-51,417,705,-647,304,-969,232,-610,-941,-254,396,-1000,335,285,-216,-70,1000,1000,-768,-233,315,153,-945,847,1000,1000,-545,456}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00305() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(java.lang.String,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{361,-462,-1000,-1000,194,-755,177,-369,-810,-612,745,-175,313,-13,186,849,163,-399,-12,-871,-234,1000,-913,-226,-778,-982,320,-66,638,1000,360,-507,159,-280,-751,-797,-154,-221,-1000,100,1000,1000,923,-1000,1000,-833,1000,-275,-1000,-1000,120,970,654,1000,-71,-1000,-511,808,-567,-951,554,596,-260,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00306() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(java.lang.String,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-1000,-1000,-1000,-151,-1000,-116,-678,-1000,-648,781,1000,871,217,-978,222,-952,194,-599,48,-55,840,-822,-1000,-184,-303,905,446,-129,411,874,-1000,296,-601,-546,1000,-779,-594,-1000,1000,-65,1000,871,-1000,496,604,183,1000,-5,-225,-863,-244,-324,593,-141,-1000,315,-89,-60,-308,-647,268,-357,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00307() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(java.lang.String,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-38,-403,-1000,83,511,-314,403,-407,394,-639,-181,929,705,445,-1000,-83,-496,-895,-1000,1000,429,58,605,-1000,-69,293,-196,867,-1000,-839,-498,759,960,-451,-83,1000,-889,1000,1000,-30,-1000,-342,-422,552,-252,475,-1000,1000,394,1000,-1000,434,-129,1000,944,-599,-1000,-781,554,830,-811,-495,-1000,-387}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00308() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(java.lang.String,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{426,-835,32,-288,-177,-971,577,-158,718,458,-414,467,910,-203,-1000,-1000,-51,984,44,-518,-208,-255,-1000,-469,-724,-41,564,416,-390,68,151,693,217,-808,-159,1000,-347,-996,-429,42,-158,470,-594,-635,1000,792,-332,249,298,984,-1000,401,26,548,-686,-1000,-703,1000,660,953,-665,882,-497,275}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00309() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(java.lang.String,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-146,-962,-501,1000,-253,-131,-785,-509,-102,377,-1000,997,1000,352,-1000,-244,707,1000,-759,265,1000,-1000,-888,-452,-916,-201,-422,-943,-106,1000,1000,-607,284,411,-282,93,-420,-1000,-538,1000,-474,911,-1000,-501,-1000,811,-581,248,384,211,-656,345,1000,1000,214,-537,-269,353,97,-162,822,-487,-975,435}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00310() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(java.lang.String,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-154,-1000,-606,-151,-370,748,129,-928,-547,781,732,1000,110,-217,-831,-795,-1000,26,-490,-562,445,128,321,-90,-303,365,614,-765,740,-223,-1000,238,-245,108,1000,190,758,-240,-234,-65,518,871,-1000,1000,-763,-237,1000,-5,-68,927,-244,-874,769,-582,-360,-869,586,-188,114,-802,1000,-1000,-479}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00311() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(java.lang.StringBuffer):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-419,-1000,493,-147,952,-832,-323,574,-66,-70,841,787,1000,543,-294,-369,-587,1000,182,700,-700,-308,-841,181,-688,-936,896,534,774,-767,-447,674,548,66,870,-1000,-290,784,161,-884,-592,830,-488,614,331,1000,-383,379,-709,-117,1000,502,152,-788,-1000,92,1000,-1000,800,-129,397,-436,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00312() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(java.lang.StringBuffer):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-1000,1000,-1000,1000,-845,699,177,31,1000,846,-1000,-404,-1000,-837,652,425,-1000,-1000,1000,-383,575,-1000,522,487,1000,1000,776,-1000,-958,482,-883,-1000,-1000,804,1000,-1000,600,-703,-938,74,-7,-494,458,1000,-719,-1000,-6,453,1000,-334,-822,1000,1000,-829,1000,-181,-1000,1000,-1000,-222,-1000,14,694}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00313() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(java.lang.StringBuffer):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-380,-481,-370,239,-881,-179,-145,-607,353,61,347,11,-628,-351,-382,306,-147,396,435,262,-696,798,232,-178,400,90,-1000,-578,303,826,29,388,538,555,897,-1000,463,-323,903,199,-1000,-322,441,810,-590,-1000,1000,851,-400,-613,-771,119,910,-1000,938,649,-1000,754,-45,-765,-390,-547,738}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00314() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(java.lang.StringBuffer):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,293,-648,459,393,-873,-46,-259,-1000,79,44,-231,625,-1000,-1000,-558,356,749,332,782,724,-949,1000,819,-300,603,293,-1000,-716,343,1000,1000,14,1000,529,1000,238,853,-1000,-183,-155,-1000,-1000,151,181,-737,-1000,42,-1000,100,400,-1000,477,128,-1000,62,1000,-1000,642,1000,-204,-847,-598,499}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00315() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(java.lang.StringBuffer):org.apache.commons.lang.text.StrBuilder",
            new int[]{548,966,-586,1000,522,313,-1000,-1000,-201,-1000,1000,-758,979,405,-83,-577,452,-1000,130,525,-166,-1000,-530,637,-885,-1000,369,286,1000,371,-857,-373,1000,-417,859,32,-849,913,-483,-92,-191,295,-74,-775,-847,1000,1000,126,391,384,-628,602,-711,-1000,-803,-852,13,410,-194,1000,1000,-782,-117,832}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00316() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(java.lang.StringBuffer):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-1000,-48,336,-183,168,561,-807,-1000,881,23,293,859,-1000,422,-606,416,-1000,-728,-872,-1000,363,951,643,-629,924,272,-380,-1000,633,-188,1000,-259,1000,339,281,-1000,1000,95,192,940,-37,657,1000,507,-248,-1000,1000,-947,221,-723,-1000,-661,950,-32,680,320,-535,457,595,81,-278,-642,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00317() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(java.lang.StringBuffer):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,617,-414,-124,675,308,-728,-78,-534,-161,-179,969,331,-761,-755,-647,195,-547,-831,1000,-580,-966,1000,-2,-133,-590,-432,-403,-744,-750,751,-363,1000,103,462,-1000,-372,966,-417,820,633,-1000,547,681,1000,-36,-322,777,-702,780,-984,-899,-986,487,259,349,-823,-536,43,-264,-739,303,-798,828}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00318() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(java.lang.StringBuffer,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{495,896,1000,-999,-404,302,58,-1000,772,1000,946,1000,335,0,896,806,1000,1000,-333,-1000,-892,615,-268,-1000,333,1000,-735,434,-907,-417,-408,493,-208,538,-1000,-1000,479,-1000,-1000,568,-1000,288,1000,1000,599,-234,1000,-323,-661,1000,-329,-675,1000,-487,105,-944,213,371,-545,1000,-1000,62,-1000,99}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00319() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(java.lang.StringBuffer,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{936,-333,-221,-361,632,276,731,25,-948,-548,-218,27,-153,-257,-304,776,840,-967,-332,987,993,850,316,-45,-1000,-395,-73,-921,572,-402,-808,655,-461,-748,404,157,-210,913,619,-940,742,-233,661,-654,576,972,976,298,776,-83,-638,890,639,681,368,-810,-602,222,-243,-488,319,618,-133,771}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00320() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(java.lang.StringBuffer,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-814,-47,-1000,768,-583,-193,-1000,-167,-512,639,-276,443,566,442,1000,-7,-435,829,-237,-1000,206,357,-229,984,-400,318,-94,509,-1000,834,-54,832,-959,598,457,684,-677,56,-765,-619,-930,-1000,387,-1000,-704,-1000,-287,-1000,1000,-1000,-943,451,39,904,-1000,400,1000,-319,936,532,451,1000,203,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00321() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(java.lang.StringBuffer,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-186,-288,-195,507,1000,194,1000,-262,100,768,71,178,27,810,-649,-313,990,-609,-988,1000,650,1000,954,552,1000,-684,-255,-908,1000,-1000,-1000,125,1000,-1000,969,102,1000,-280,-377,408,1000,-170,-48,601,1000,1000,233,734,-1000,217,-671,1000,-1000,-1000,844,-1000,-486,-574,-1000,-164,-713,196,930,-257}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00322() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(java.lang.StringBuffer,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-378,-1000,-1000,1000,269,-1000,-792,-159,-1000,890,462,465,-331,-176,399,-1000,-1000,1000,846,-551,466,1000,-244,1000,-755,325,-246,-900,-647,663,574,705,-825,903,1000,1000,-914,-401,-1000,-1000,-943,389,-164,-1000,-1000,667,-959,-1000,254,-1000,-1000,-1000,-232,106,-1000,-309,1000,-86,51,-1000,525,1000,-185,859}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00323() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(java.lang.StringBuffer,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-423,-571,529,-127,981,639,-311,439,1000,-552,254,497,308,854,512,520,-216,-427,-1000,-907,690,-613,-359,676,1000,-31,-106,727,39,-580,-1000,481,91,818,-177,198,-315,1000,326,-268,826,41,602,349,737,-730,-416,-1000,185,829,507,204,-367,598,327,-823,45,-523,-1000,-6,945,1000,577,461}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00324() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(java.lang.StringBuffer,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-59,-304,85,698,548,-1000,994,417,-4,-1000,576,-1000,366,1000,-709,318,1000,-1000,-1000,1000,1000,-21,92,342,301,-1000,-251,-1000,1000,-434,-962,317,749,-1000,272,-815,37,1000,1000,-1000,1000,549,63,453,266,-95,501,361,-444,-464,-344,-104,-616,-950,348,-681,-229,-101,-1000,-1000,432,256,231,-901}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00325() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(java.lang.StringBuffer,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-974,-1000,-1000,1000,179,-569,108,417,-1000,288,-958,-1000,-927,665,88,-1000,-810,297,-131,-231,1000,1000,232,1000,685,-1000,614,-871,-639,-643,-743,639,-314,480,272,1000,-1000,1000,-912,-1000,1000,549,-638,-1000,-1000,226,-1000,361,-88,-1000,-927,1000,-1000,98,348,-1000,-229,-636,709,-1000,39,1000,231,-199}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00326() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(java.lang.StringBuffer,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-39,-849,-181,156,-755,-563,-156,-288,-43,896,1000,679,883,496,184,-283,188,405,-515,449,169,-54,-510,242,549,61,-891,-194,-992,1000,-578,-435,-393,395,406,-174,134,-332,-333,-700,-678,960,958,-90,328,-173,300,-440,318,168,360,-683,92,213,-54,-632,821,-489,-361,324,224,-374,-1000,232}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00327() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(java.lang.StringBuffer,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-112,-944,1000,1000,-123,22,26,49,-1000,-1000,-1000,868,1000,-26,747,-393,-1000,-1000,314,1000,-621,333,1000,1000,-736,435,379,428,-452,-849,424,20,-946,852,662,-1000,1000,1000,267,1000,-1000,429,-569,202,-1000,547,170,-102,-584,41,1000,-1000,939,295,-317,751,-1000,-584,109,1000,806,1000,-124}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00328() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(long):org.apache.commons.lang.text.StrBuilder",
            new int[]{148,-513,144,59,-945,811,1000,-199,-326,-908,59,-253,591,218,-1000,1000,-400,-1000,390,830,-86,1000,155,-83,-421,1000,-1000,-818,1000,-811,-135,-134,627,125,-462,1000,-784,598,20,-1000,1000,-394,1000,264,-1000,150,-934,783,1000,226,314,-980,1000,426,-925,562,1000,19,-352,-771,-1000,-197,61,-180}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00329() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(long):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,257,462,678,-315,53,239,149,821,-226,422,693,-678,178,-267,-898,98,-525,567,344,-16,632,-70,1000,321,-763,-1000,860,-729,-214,-464,-707,82,791,-179,-296,-479,416,-1000,-79,-485,-78,-223,223,764,-568,-186,-38,-54,-958,-387,1000,-1000,520,1000,-172,-400,1000,-634,-976,-452,-609,-1000,30}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00330() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(long):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,811,-1000,761,-408,372,-1000,-989,-744,1000,374,-547,586,-946,36,-90,-399,57,-910,-1000,186,75,627,-50,-158,1000,-753,896,-497,400,898,-260,-126,487,-119,-759,-573,-21,-1000,-431,-194,-1000,-527,-753,338,1000,-368,439,-1000,-1000,592,1000,-17,-1000,443,-36,389,-819,862,-1000,-1000,-44,-52,382}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00331() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(long):org.apache.commons.lang.text.StrBuilder",
            new int[]{395,-350,-339,-371,-76,752,289,490,-956,753,-446,-514,-16,-977,-390,983,-995,-516,193,-7,423,-430,761,-781,-726,794,-997,-818,791,634,700,-134,-601,432,508,593,-980,29,-663,-845,150,-998,-312,-358,-616,518,-405,837,-152,-935,589,-405,347,-380,-492,174,938,-821,-97,-853,-880,-21,309,230}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00332() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(long):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,425,-18,287,834,1000,-171,6,-353,491,1000,130,-372,-1000,-769,-239,-208,-436,-1000,-19,1000,434,-21,-163,1000,458,-662,-101,-409,318,91,271,-447,-300,596,648,-1000,-37,1000,-203,-820,-663,-1000,-1000,-1000,158,1000,1000,-886,-395,-15,827,-451,-626,923,737,-1000,-338,-312,-713,-1000,83,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00333() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(long):org.apache.commons.lang.text.StrBuilder",
            new int[]{-588,-634,208,59,-461,13,1000,904,645,-1000,-1000,99,302,1000,-477,549,1000,-205,-310,991,-726,1000,-728,434,-234,820,245,-563,830,-1000,-552,-156,576,125,-258,1000,991,598,774,-712,1000,745,1000,264,-1000,-463,11,768,1000,1000,-220,-1000,1000,919,-746,563,1000,1000,-886,631,-525,-321,61,-171}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00334() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(long):org.apache.commons.lang.text.StrBuilder",
            new int[]{407,-77,-158,-378,-306,639,336,160,-130,-333,-342,-229,-196,-262,-770,-278,-682,-1000,1000,790,512,1000,-236,-1000,816,-157,-703,-304,-164,944,-323,1000,739,569,-624,-71,-1000,929,377,-704,-852,-994,-406,149,-444,-179,364,650,-1000,-624,-577,-65,112,496,199,224,-1000,-1000,654,-317,-1000,-22,-649,478}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00335() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(org.apache.commons.lang.text.StrBuilder):org.apache.commons.lang.text.StrBuilder",
            new int[]{-991,726,-496,641,718,854,-727,550,-119,819,872,-483,-968,1000,35,647,936,4,119,601,-487,-708,11,-1000,506,658,-149,-1000,-1000,154,510,102,-1000,-462,841,-843,180,-1000,-807,158,-1000,633,-111,-462,779,-902,-190,-313,382,-850,198,-1000,-1000,926,637,-842,836,-684,-297,-1000,291,-647,-301,504}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00336() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(org.apache.commons.lang.text.StrBuilder):org.apache.commons.lang.text.StrBuilder",
            new int[]{-169,-1000,-442,310,-357,-785,-47,-22,436,-966,-322,746,-1000,463,-436,449,956,-860,188,425,-149,859,-897,418,839,144,166,1000,225,-625,576,829,609,-195,-294,444,760,199,135,1000,562,704,-109,-647,259,81,1000,128,372,557,600,-85,748,-1000,-208,829,-767,3,-694,1000,-1000,48,961,-88}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00337() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(org.apache.commons.lang.text.StrBuilder):org.apache.commons.lang.text.StrBuilder",
            new int[]{458,-436,-609,1000,72,-1000,287,-621,1000,-1000,-1000,1000,-348,430,-783,1000,1000,-475,-1000,755,39,394,-1000,678,735,1,915,1000,282,-1000,167,92,1000,1000,-235,480,738,99,576,1000,118,-288,-1000,-560,37,23,1000,1000,-104,-525,1000,390,444,-419,49,1000,-1000,-176,-410,-103,-1000,-152,666,-552}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00338() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(org.apache.commons.lang.text.StrBuilder):org.apache.commons.lang.text.StrBuilder",
            new int[]{-231,1000,-654,642,633,922,-530,246,-408,1000,805,-460,-1000,766,108,427,936,-326,314,-255,-335,-690,11,-481,613,993,-891,-1000,-1000,-447,820,102,-1000,-44,-145,112,123,-657,-807,446,-682,474,596,-1000,947,-42,-336,-883,408,-496,-357,-1000,-678,897,307,-666,836,-843,-297,-673,291,-449,-383,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00339() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(org.apache.commons.lang.text.StrBuilder):org.apache.commons.lang.text.StrBuilder",
            new int[]{-178,-380,446,462,-316,-695,176,-501,617,-796,339,352,-508,-701,592,31,466,-641,613,93,-961,651,-98,34,-634,284,408,329,931,-913,-933,-554,397,768,-98,-786,498,-215,-704,719,136,-183,-708,541,550,29,313,610,-668,423,583,188,-629,489,704,-415,-592,-921,336,95,731,0,-259,-693}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00340() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(org.apache.commons.lang.text.StrBuilder):org.apache.commons.lang.text.StrBuilder",
            new int[]{133,-1000,-323,117,-150,-1000,54,-158,439,-1000,-1000,1000,209,-503,-806,566,447,-803,1000,303,262,282,-658,1000,532,-379,-266,1000,871,-1000,6,-420,817,1000,54,962,689,430,-1,512,553,-931,-631,82,-82,23,855,513,-730,-88,1000,479,880,-1000,-490,258,-931,-22,-481,792,-721,46,590,277}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00341() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(org.apache.commons.lang.text.StrBuilder):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,384,-292,123,-204,-224,643,717,472,-1000,1000,953,48,-458,1000,1000,804,-690,1000,1000,-1000,233,328,-876,-137,-618,103,1000,1000,-1000,-934,-371,904,1000,-269,-1000,155,922,-207,1000,646,-275,-839,-321,1000,-632,1000,1000,-1000,-125,-718,-480,-411,377,658,878,-1000,-487,1000,1000,1000,-426,-283,-618}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00342() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(org.apache.commons.lang.text.StrBuilder):org.apache.commons.lang.text.StrBuilder",
            new int[]{724,-871,-78,442,1000,-358,-423,-117,-540,-579,668,-245,1000,983,-1000,1000,503,1000,-1000,1000,1000,-1000,-1000,-355,1000,616,595,634,-1000,238,163,-332,515,-1000,230,-584,-783,1000,-631,-970,-1000,556,-887,83,121,-320,138,662,-270,-1000,698,777,627,-1000,-54,-553,714,318,909,70,-1000,1000,443,-652}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00343() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(org.apache.commons.lang.text.StrBuilder,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-240,-12,-24,-394,536,-137,-933,100,-617,-722,152,39,-620,-305,-1000,-413,336,-41,222,-114,1000,49,264,1000,265,-48,473,-95,966,-117,906,449,1000,-323,-1000,-32,1000,316,741,-1000,179,598,-400,1000,-1000,-439,-264,-380,682,-649,231,1000,-171,1000,926,-771,364,-1000,-200,1000,-1000,-379,-702}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00344() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(org.apache.commons.lang.text.StrBuilder,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{276,-293,250,-17,-176,517,1000,-800,-758,390,-806,456,55,-401,-480,0,492,652,-1000,655,-326,690,203,-41,563,1000,-154,-2,-653,457,-82,124,-200,289,-179,-616,-322,873,-335,429,-442,-291,474,-599,427,-1000,-32,-826,-47,547,304,1000,522,-419,301,664,-1000,206,-717,-319,550,130,-471,-413}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00345() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(org.apache.commons.lang.text.StrBuilder,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,635,1000,-657,332,-135,-692,-608,-577,1000,-486,377,-397,483,-931,161,966,683,-397,1000,171,-556,733,-311,-443,889,208,-1000,-1000,-220,-860,-1000,640,-1000,642,936,-1000,390,-290,-211,915,-882,206,-850,122,-1000,566,-1000,743,405,1000,723,-173,828,89,-145,-726,-431,545,459,-269,942,-306,-464}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00346() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(org.apache.commons.lang.text.StrBuilder,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{285,-1000,-174,688,-1000,-722,527,254,611,-474,-994,-200,451,-222,-1000,-190,214,158,1000,1000,-984,1000,42,19,1000,546,-1000,751,-806,259,-98,1000,-278,565,965,-523,916,-1000,842,1000,-281,-1000,820,-1000,-77,-1000,893,-227,-1000,-311,-1000,-1000,-866,-1000,1000,1000,-279,695,-362,-969,-816,-620,-971,-889}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00347() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(org.apache.commons.lang.text.StrBuilder,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-514,490,1000,-397,54,638,-855,-1000,-1000,1000,-786,783,-490,202,-1000,-692,363,1000,-471,1000,-321,669,999,282,363,566,-904,-927,-1000,-930,-1000,-906,-1000,-199,456,151,-1000,1000,133,36,1000,-365,732,-975,-53,-1000,237,-1000,763,-1000,731,1000,-1000,-572,-167,316,-1000,-344,-430,318,1000,1000,-343,46}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00348() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(org.apache.commons.lang.text.StrBuilder,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-99,-1000,-1000,31,722,376,159,632,-240,-123,-108,783,510,-5,-149,-569,-43,317,226,-288,-621,1000,-1000,508,1000,-58,354,-927,909,261,-638,894,251,-199,-192,-630,657,423,502,557,133,344,174,-380,-521,-2,350,59,-675,-500,802,-369,-1000,-859,222,-217,-255,552,-652,-116,1000,-161,-434,900}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00349() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(org.apache.commons.lang.text.StrBuilder,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-844,1000,845,-1000,805,-620,239,28,-1000,-1000,305,-324,949,-1000,-1000,-1000,-525,663,-32,-1000,447,1000,1000,385,-443,-1000,422,208,-382,1000,591,-419,1000,1000,210,501,-1000,1000,929,294,400,958,-882,457,-812,-492,-466,-964,1000,-1000,-1000,-708,-1000,7,857,1000,-683,-198,-773,735,267,-527,-718}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00350() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(org.apache.commons.lang.text.StrBuilder,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{545,-1000,1000,147,-554,842,418,-1000,632,-1000,-879,992,-644,-16,-751,0,-439,95,343,1000,-930,624,393,-78,741,576,-982,114,159,-71,575,68,-123,289,862,-963,118,-576,406,975,103,-57,522,-1000,-564,-544,-228,-386,-248,512,-1000,1000,223,-480,499,1000,-85,-50,-1000,-1000,391,-208,22,-577}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00351() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(org.apache.commons.lang.text.StrBuilder,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{439,-1000,477,-657,-1000,1000,-94,-748,597,-286,-994,74,-384,21,-1000,-240,400,59,390,1000,-1000,824,825,-306,-443,889,-1000,-43,-1000,308,-389,-115,997,-56,862,-1000,739,-664,382,1000,53,-1000,323,-1000,708,-1000,663,-1000,-1000,999,-920,-455,-84,-1000,954,1000,-581,16,-1000,-219,-269,233,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00352() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendln(org.apache.commons.lang.text.StrBuilder,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-1000,-12,184,-1000,789,344,64,1000,-1000,-872,-77,157,-298,-305,-1000,-700,-310,834,-120,-590,990,-219,360,1000,-268,-115,1000,190,1000,1000,1000,1000,1000,58,-1000,1000,-391,474,1000,-1000,-168,447,-418,1000,-868,-935,-138,-1000,1000,430,-1000,-709,-470,1000,1000,229,170,-1000,-949,884,-1000,-508,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00353() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder$StrBuilderReader", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "asReader():java.io.Reader",
            new int[]{-203,-532,-830,313,16,-156,139,-544,76,-58,464,-234,212,1000,-1000,145,-488,415,58,-492,-93,-954,-1000,-296,-146,-896,713,1000,1000,-539,-1000,-1000,224,-909,-294,-131,-1000,540,387,-738,-285,291,600,-491,-822,390,135,735,-210,19,-430,-809,144,-674,303,1000,710,366,173,-933,-1000,-16,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00354() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder$StrBuilderReader", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "asReader():java.io.Reader",
            new int[]{-441,-630,-322,11,-748,216,-430,263,-745,301,817,-443,-46,530,-886,692,-1000,-319,-379,58,-378,172,808,-1000,-603,-969,106,199,210,-1000,-834,-829,200,103,-1000,553,-59,437,-287,-1000,711,449,560,82,-43,-364,-113,803,-254,1000,381,-769,-813,-148,287,919,-381,93,-583,57,-1000,910,-375,737}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00355() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder$StrBuilderReader", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "asReader():java.io.Reader",
            new int[]{555,310,-553,665,-501,396,-1000,1000,1000,290,-492,-864,1000,-1000,267,820,-265,-704,-490,-44,-933,646,399,-1000,-1000,1000,787,-592,-884,485,1000,991,-1000,352,512,-611,1000,1000,796,65,-399,202,870,443,1000,-488,-305,-446,715,-714,15,-336,466,766,339,-753,-781,754,-306,819,1000,698,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00356() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder$StrBuilderReader", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "asReader():java.io.Reader",
            new int[]{988,-1000,-1000,699,320,-733,218,682,820,-918,-718,-996,360,1000,-482,217,-724,721,269,-911,-697,-914,-1000,-553,-970,-870,864,896,893,-958,-1000,-964,199,-1000,-879,-1000,-937,445,-73,12,-205,927,1000,-1000,-484,1000,360,359,787,-510,-1000,-1000,231,-1000,1000,802,-316,79,-282,-994,-412,-67,-1000,391}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00357() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder$StrBuilderReader", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "asReader():java.io.Reader",
            new int[]{-148,80,-74,651,-598,320,139,-249,-117,-341,1000,-23,212,315,-1000,824,-994,135,-79,431,809,-1000,-1000,-43,-664,-896,778,1000,1000,-479,-1000,-1000,9,15,-294,-131,-1000,390,903,-1000,248,219,-102,-1000,106,1000,-392,597,-1000,144,76,-473,-530,277,-231,1000,710,746,495,-688,-1000,-42,-1000,534}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00358() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder$StrBuilderReader", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "asReader():java.io.Reader",
            new int[]{717,-1000,-1000,1000,80,-144,139,-423,408,-1000,-101,-515,631,988,-1000,795,-666,337,58,-737,-691,-871,-1000,-641,-994,-461,740,511,1000,-1000,-1000,-1000,103,-738,-1000,42,-928,1000,814,-960,-226,370,225,-129,-822,1000,203,1000,118,-376,-735,-1000,421,-304,521,1000,152,245,-546,-796,-1000,241,-1000,93}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00359() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder$StrBuilderReader", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "asReader():java.io.Reader",
            new int[]{757,-1000,-33,-859,1000,-1000,-266,-1000,147,-735,35,592,504,-1000,-934,613,-522,1000,1000,-1000,-1000,284,-776,528,-637,485,387,440,1000,-1000,-1000,-1000,-170,-1000,-1000,-1000,-1000,814,558,1000,-1000,-118,946,-1000,184,145,1000,315,1000,-178,-1000,-1000,690,-102,-119,428,1000,-844,-1000,-1000,-236,608,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00360() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder$StrBuilderReader", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "asReader():java.io.Reader",
            new int[]{494,707,-592,21,-831,32,427,20,414,-148,271,-730,186,520,-434,328,-299,-552,-636,484,260,-421,-190,132,221,-504,1000,110,-117,705,-585,359,-814,286,86,-289,687,-594,-237,113,561,382,621,171,283,-675,-427,-721,-223,124,-666,-571,-736,233,-103,789,80,1000,658,724,-500,-38,-345,-470}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00361() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder$StrBuilderTokenizer", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "asTokenizer():org.apache.commons.lang.text.StrTokenizer",
            new int[]{963,-1000,-333,-1000,446,-386,411,721,-661,346,431,-36,-216,1000,390,392,167,-349,-1000,-187,821,-739,444,-136,-583,-152,947,244,520,-89,472,-1000,-1000,-876,197,-1000,-1000,-594,-314,-809,186,215,-666,760,416,-701,-755,-1000,-431,-1000,452,506,1000,-874,-522,-1000,-698,-571,-650,682,-390,-395,226,589}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00362() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder$StrBuilderTokenizer", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "asTokenizer():org.apache.commons.lang.text.StrTokenizer",
            new int[]{-222,-618,428,648,-1000,0,340,-140,919,-8,-575,-1000,-33,-938,396,460,-443,-1000,-443,-343,-33,942,-263,-875,-799,-433,1000,-820,-407,-1000,1000,345,1000,339,1000,21,-39,917,975,825,372,419,-609,-10,-793,468,935,-752,-288,712,802,-405,-1000,129,822,708,499,283,320,1000,29,-484,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00363() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder$StrBuilderTokenizer", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "asTokenizer():org.apache.commons.lang.text.StrTokenizer",
            new int[]{1000,-479,-574,-550,-446,-738,-66,546,881,-18,1000,159,-482,1000,673,520,76,709,-740,276,1000,-1000,1000,934,-279,875,412,-1000,315,1000,-876,-1000,-1000,-725,-70,-1000,-1000,88,-625,-1000,-470,-602,327,200,1000,-1000,-1000,-141,-29,-1000,-390,570,960,-457,-930,345,-1000,-977,-682,-3,-366,842,-802,-517}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00364() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder$StrBuilderTokenizer", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "asTokenizer():org.apache.commons.lang.text.StrTokenizer",
            new int[]{1000,-1000,-559,-1000,1000,-442,299,944,-1000,-1000,1000,324,-964,1000,843,-1000,-348,503,-1000,-1000,-503,-1000,886,-10,-1000,-725,675,1000,248,1000,-548,-1000,-1000,-1000,1000,-1000,-1000,-1000,324,-374,-1000,-1000,644,1000,864,-1000,-1000,-1000,306,-1000,-1000,1000,1000,-1000,182,-1000,-1000,297,-1000,-905,-1000,368,352,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00365() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder$StrBuilderTokenizer", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "asTokenizer():org.apache.commons.lang.text.StrTokenizer",
            new int[]{1000,-1000,109,-111,812,401,282,-876,-526,621,862,-784,189,107,40,412,634,-306,-1000,-261,580,-945,-673,-672,-718,-730,1000,261,376,-89,506,-588,-149,-1000,-413,-297,-449,-166,-446,76,299,296,-866,1000,-474,-819,-865,-399,496,-1000,1000,530,373,-262,453,-1000,-1000,-178,-766,773,-311,-1000,-1000,828}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00366() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder$StrBuilderTokenizer", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "asTokenizer():org.apache.commons.lang.text.StrTokenizer",
            new int[]{364,-1000,-144,-378,314,-876,653,128,-661,251,431,-473,-198,908,387,475,806,750,-1000,-33,529,-739,183,-498,-583,-326,-364,244,328,-89,-1000,-1000,-1000,-876,521,-508,-614,-5,-1000,-50,264,215,-771,760,519,-574,-755,-888,-431,-1000,833,258,561,-401,54,-1000,-698,-390,-587,-1000,-182,-575,606,589}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00367() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder$StrBuilderWriter", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "asWriter():java.io.Writer",
            new int[]{862,-478,146,31,-899,-327,882,960,839,638,230,-1000,1000,734,-7,648,-225,-951,791,-84,-773,1000,1000,610,-95,253,829,1000,1000,353,265,146,757,14,-961,1000,96,-335,-68,-1000,501,-1000,1000,832,-317,-230,348,-627,-322,1000,-496,-1000,1000,1000,10,510,-1000,790,-1000,1000,-251,787,1000,472}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00368() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder$StrBuilderWriter", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "asWriter():java.io.Writer",
            new int[]{285,-441,554,-509,406,233,-805,184,-38,-779,-497,517,882,444,1000,471,1000,-122,-939,875,230,-327,232,-494,332,-131,-203,384,1000,381,-142,-380,-182,-360,-351,777,-1000,1000,-25,-1000,11,26,-138,986,470,1000,449,1000,-1000,235,-869,388,1000,-374,890,1000,-276,-49,-912,614,14,-1000,232,442}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00369() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder$StrBuilderWriter", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "asWriter():java.io.Writer",
            new int[]{-925,-1000,-517,-782,1000,-862,633,207,-112,-835,-379,-774,800,-871,357,272,-66,777,-1000,-758,-899,24,-488,683,181,-313,578,1000,1000,-830,174,1000,-1000,410,-1000,-1000,-81,-21,-4,-43,-27,184,-932,1000,575,1000,420,757,-741,47,1000,-453,565,171,686,-857,-780,1000,-1000,431,1000,-257,692,781}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00370() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder$StrBuilderWriter", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "asWriter():java.io.Writer",
            new int[]{-165,-82,865,325,1000,514,804,400,-38,-55,603,608,-939,355,-471,810,-492,-257,172,1000,-730,718,-367,-553,-669,-1000,-1000,-924,712,193,365,1000,-618,-708,799,-600,602,-735,-935,650,-804,998,714,1000,215,-537,-839,-565,549,-123,-403,352,-203,-752,533,606,852,838,844,-146,1000,-1000,691,759}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00371() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder$StrBuilderWriter", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "asWriter():java.io.Writer",
            new int[]{933,-725,-501,400,659,-862,-224,-1000,-147,251,369,-66,982,418,-14,1000,1000,-911,433,774,-899,-99,428,-400,-372,-107,731,192,-808,846,174,238,299,163,-251,1000,-169,502,-463,-43,234,-324,-932,898,-319,471,-686,-172,-279,782,827,-69,565,427,686,1000,-503,-400,-355,904,-1000,-282,269,781}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00372() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder$StrBuilderWriter", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "asWriter():java.io.Writer",
            new int[]{-539,-1000,537,-439,281,-1000,639,34,-586,-87,728,8,638,74,-564,1000,-809,-117,-437,-28,-828,-174,681,-404,-1000,-355,578,629,1000,-544,690,1000,-1000,632,-1000,272,266,-402,-514,317,-595,219,468,1000,661,667,-746,-349,222,1000,1000,-260,1000,372,652,-194,-367,174,-309,1000,230,-629,1000,4}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00373() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder$StrBuilderWriter", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "asWriter():java.io.Writer",
            new int[]{113,-196,384,-157,1000,682,-1000,669,1000,-1000,-353,-921,498,253,-165,-639,911,365,-1000,191,-1000,1000,1000,1000,29,35,-600,1000,561,148,-112,605,550,-226,357,627,-252,-15,-681,-309,603,-816,23,550,107,964,296,39,-893,747,-195,-1000,384,67,-1000,-427,-274,1000,-1000,161,963,-696,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00374() {
        org.junit.Assert.assertEquals("java.lang.Integer:NDQ5", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "capacity():int",
            new int[]{-1000,290,57,-548,-740,-253,177,37,449,851,-216,-624,-1000,102,200,692,-60,-594,325,-334,-462,415,-417,621,912,-1000,-375,1000,674,-538,279,-364,56,1000,334,1000,795,1000,-367,-427,-808,-1000,-322,-187,212,210,-120,410,927,-726,17,-584,-750,-292,-947,1000,420,-67,1000,584,285,1000,441,576}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00375() {
        org.junit.Assert.assertEquals("java.lang.Integer:MzI=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "capacity():int",
            new int[]{-1000,204,-826,-1000,-159,351,-366,-1000,318,-343,-308,-734,-540,-153,-1000,712,779,-117,-265,1000,-403,1000,79,1000,806,-732,94,1000,1000,800,-2,-337,1000,1000,433,1000,484,962,1000,-1000,-781,-374,226,-511,154,417,405,-568,254,61,82,215,-166,-506,-1000,14,643,-446,938,837,-956,-106,830,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00376() {
        org.junit.Assert.assertEquals("java.lang.Integer:MzI=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "capacity():int",
            new int[]{1000,871,1000,-176,-2,-494,-1000,942,-865,-623,-286,222,14,206,946,120,-1000,-1000,-1000,1000,-1000,-1000,988,522,1000,-258,635,-1000,-1000,-117,761,-701,588,-1000,-295,-1000,-1000,-737,-1000,864,401,343,-1000,-1000,-431,-1000,1000,1000,809,1000,-231,667,638,-684,-239,427,-1000,-1000,-509,-1000,-1000,1000,-375,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00377() {
        org.junit.Assert.assertEquals("java.lang.Integer:NTY=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "capacity():int",
            new int[]{-304,278,424,194,-161,-321,-661,218,-1000,808,-486,-732,-888,-881,548,-749,-550,306,193,-641,-190,-56,-335,-1000,-313,-26,-551,301,-1000,-597,413,251,297,-288,766,-1000,950,-432,-1000,-124,573,-261,165,-214,862,-434,839,804,671,-572,260,-989,24,-814,16,695,-460,-538,319,-538,399,1000,-151,-337}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00378() {
        org.junit.Assert.assertEquals("java.lang.Integer:MzM=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "capacity():int",
            new int[]{-718,-394,130,92,164,84,-419,-315,-572,240,-187,484,44,96,452,651,-792,-260,-217,-677,-880,129,146,-580,288,191,232,703,-260,-721,-969,815,530,284,925,350,918,-412,-775,-124,-314,-590,304,273,216,113,397,761,111,526,142,-466,-521,-518,-25,65,-744,-631,598,-163,-602,780,916,-526}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00379() {
        org.junit.Assert.assertEquals("java.lang.Integer:MzI=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "capacity():int",
            new int[]{1000,605,561,-11,293,543,-853,1000,-911,-1000,-239,121,-522,-349,989,-86,-771,-278,-1000,1000,-748,-1000,1000,106,337,78,683,-1000,-1000,508,100,175,1000,-770,565,-1000,-574,-655,-1000,989,984,444,-216,-898,-264,-1000,912,1000,564,1000,-459,611,1000,-458,-30,-1000,-1000,-1000,-554,-1000,-1000,1000,205,-350}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00380() {
        org.junit.Assert.assertEquals("java.lang.Integer:MzI=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "capacity():int",
            new int[]{-931,-1000,928,841,-509,964,1000,317,125,1000,-300,-109,-1000,-156,146,-482,-1000,-117,667,-1000,-403,387,-394,-150,-114,-62,94,1000,447,-1000,26,30,1000,-259,-754,821,890,271,1000,703,-781,-994,455,1000,154,883,-1000,-10,-414,-1000,-133,-1000,-1000,-539,-1000,14,1000,1000,938,498,1000,-400,-901,62}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00381() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "charAt(int):char",
            new int[]{1000,-1000,646,-953,826,407,754,1000,-186,1000,-1000,649,1000,-598,931,419,68,-160,-1000,351,536,1000,-284,218,-624,-311,217,-1000,1000,1000,240,-451,-118,-1000,1000,1000,1000,863,-49,1000,286,-86,1000,1000,356,1000,-566,-422,811,-1000,-330,292,950,-708,-451,390,517,362,-547,1000,-1000,399,-403,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00382() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "charAt(int):char",
            new int[]{590,603,-437,-1000,57,-750,574,856,1000,-1000,-556,-1000,80,-842,907,1000,374,1000,-1000,-698,13,-389,-218,1000,1000,-883,-988,-964,-620,-789,544,1000,-529,52,-191,812,-606,593,209,-109,1000,-201,-508,-372,-1000,-251,-1000,456,653,-980,607,-19,1000,-559,822,-728,-1000,-1000,-316,-310,-661,288,-1000,101}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00383() {
        org.junit.Assert.assertEquals("java.lang.Character:AA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "charAt(int):char",
            new int[]{-204,830,-520,-669,578,-670,-302,-596,-276,159,-252,1000,345,-323,233,467,-441,391,-1000,-149,-654,861,-661,638,-376,-892,-160,-1000,882,-22,301,450,-589,165,400,-5,381,372,-397,-536,-374,-519,-1000,-419,217,-1000,-160,1000,-14,1000,-142,147,703,527,945,-273,-607,1000,-1000,149,454,-1000,515,553}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00384() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "charAt(int):char",
            new int[]{753,-148,450,-1000,222,-601,499,484,1000,-773,-974,-762,198,-441,882,827,391,1000,-846,-1000,1000,925,-1000,1000,444,187,-1000,-1000,-556,319,643,898,160,-255,1000,1000,320,1000,-239,1000,1000,-624,349,-456,-634,387,-1000,297,777,-999,-198,1000,280,114,963,-231,-1000,284,-809,807,-1000,41,-828,-520}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00385() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "charAt(int):char",
            new int[]{-767,509,225,-600,-301,-422,-394,-570,-756,883,224,739,923,241,-766,-512,-199,482,-1000,-591,149,260,-795,395,575,-565,-708,-584,668,-169,186,680,699,883,1000,-116,368,360,725,-536,97,-455,-315,236,137,-7,944,541,619,-239,-1000,1000,604,868,997,-262,-67,-243,599,536,682,-837,785,-650}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00386() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "charAt(int):char",
            new int[]{-57,654,554,743,-136,-633,239,-1000,217,-338,-78,-164,-1000,1000,-393,-874,-1000,642,323,-1000,1000,199,-1000,1000,-160,-568,17,-179,-185,-425,445,620,-974,694,-90,-243,-330,1000,-1000,681,153,-897,-240,236,-280,-77,425,625,518,741,-1000,320,-894,439,957,26,-635,-1000,-684,532,487,-644,65,396}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00387() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "charAt(int):char",
            new int[]{575,77,352,-1000,-69,-316,257,889,815,-512,-1000,-794,1000,-569,1000,0,734,702,-840,-359,775,903,-577,783,480,574,-1000,-1000,-556,653,620,744,662,-752,1000,1000,785,801,132,485,806,-242,349,3,-831,1000,-938,103,777,-1000,369,1000,1000,-273,-202,-563,-709,284,-665,1000,-1000,239,-506,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00388() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "charAt(int):char",
            new int[]{1000,1000,-244,-662,519,-574,474,-1000,587,-748,-31,-494,-411,1000,723,620,-137,1000,-502,586,-371,226,-141,1000,558,733,897,-313,649,-1000,625,7,-1000,236,-1000,731,-643,645,185,-1000,600,768,-595,971,-598,-643,-314,1000,574,1000,-81,-615,544,-1000,-275,-190,33,778,-485,-1000,-118,712,-698,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00389() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "clear():org.apache.commons.lang.text.StrBuilder",
            new int[]{580,-811,-678,937,-937,318,1000,897,618,322,-606,990,60,165,125,1000,242,1000,-722,611,-179,-139,440,724,1000,-217,308,-156,19,-1000,410,434,136,65,829,1000,-254,712,1000,-745,-646,-1000,395,291,-1000,1000,1000,-261,916,-995,607,864,778,1000,-515,-824,337,683,315,-956,120,696,1000,-631}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00390() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "clear():org.apache.commons.lang.text.StrBuilder",
            new int[]{-178,-249,974,-1000,711,-953,-1000,670,882,1000,-788,814,739,13,675,331,277,-1000,-1000,96,-469,-183,590,634,-437,338,-1000,-1000,-679,-989,-756,-607,-304,104,-1000,225,736,203,485,-948,-29,871,393,-66,-1000,-574,173,528,-163,-1000,1000,808,571,-342,-778,351,793,1000,-1000,-621,-591,726,-362,450}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00391() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "clear():org.apache.commons.lang.text.StrBuilder",
            new int[]{967,-1000,-1000,145,657,-697,-11,214,1000,488,166,1000,513,-115,309,951,991,-148,324,456,-839,-326,-466,194,-728,348,954,-82,-281,840,-292,811,-108,-329,988,1000,-428,-698,113,-768,993,-1000,426,-308,-1000,1000,1000,-95,-457,556,482,-1000,-256,859,549,-1000,-712,-1000,-413,-1000,-623,343,419,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00392() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "clear():org.apache.commons.lang.text.StrBuilder",
            new int[]{-999,689,-532,1000,-234,1000,339,1000,771,1000,-583,536,772,-1000,114,1000,1000,530,-891,-339,1000,-1000,579,86,-920,1000,1000,-1000,-1000,-602,-587,266,600,-944,1000,-1000,-826,-1000,1000,-1000,-1,-1000,604,-1000,-1000,-1000,-69,1000,117,-1000,950,-386,-576,684,1000,287,1000,816,-1000,390,-1000,95,-14,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00393() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "clear():org.apache.commons.lang.text.StrBuilder",
            new int[]{-178,511,827,-703,448,-219,-676,-298,985,1000,-633,1000,574,-931,763,1000,1000,-1000,-804,-257,-1000,335,-990,654,-1000,891,-1000,-1000,-1000,349,-1000,1000,569,144,-977,-123,390,203,485,-1000,214,481,571,-66,-1000,-649,484,835,-51,-1000,1000,1000,1000,-579,-357,77,793,393,-1000,-428,-596,964,-380,741}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00394() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "clear():org.apache.commons.lang.text.StrBuilder",
            new int[]{23,578,706,1000,-1000,-22,-546,656,-225,-55,-1000,544,-84,-364,1000,1000,698,297,-975,126,-801,-750,-1000,173,348,475,739,-371,-1000,-602,1000,1000,200,634,-1000,-353,27,-919,82,-807,1000,456,1000,-203,-620,-1000,265,1000,1000,-177,1000,-501,-296,-852,270,-219,1000,-435,-501,247,-779,975,-640,-853}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00395() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "clear():org.apache.commons.lang.text.StrBuilder",
            new int[]{-425,-760,-208,-1000,826,-609,-463,229,-182,-1000,697,263,-1000,848,27,-537,-1000,-801,674,717,73,490,687,251,1000,-1000,-321,1000,1000,433,210,-1000,-594,-1000,305,953,-365,-927,-651,-807,-370,-436,-1000,793,1000,1000,187,-1000,-920,875,-1000,-1000,1000,1000,635,-653,-1000,869,1000,-763,-779,491,-513,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00396() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "clear():org.apache.commons.lang.text.StrBuilder",
            new int[]{-365,-1000,667,239,-1000,-48,638,961,839,-546,-1000,1000,-615,122,1000,39,-913,-44,-571,-35,-1000,754,-521,171,1000,-1000,-123,-88,1000,-989,1000,-255,-1000,-305,-1000,-612,-66,-498,1000,644,433,-920,799,-701,-1000,-586,-368,-1000,973,-1000,666,-235,92,-176,-1000,-222,-388,1000,813,-1000,280,-133,478,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00397() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "contains(char):boolean",
            new int[]{128,-673,-158,-99,191,489,-216,67,-1000,344,156,325,-664,363,315,837,499,10,438,482,276,202,489,867,786,-440,-631,752,317,47,235,-1000,-980,-636,615,-365,-124,-698,-1000,548,832,-777,40,-139,508,-556,146,353,-253,-595,-667,-242,-530,11,72,174,106,151,-610,767,-826,-808,910,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00398() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "contains(char):boolean",
            new int[]{-1000,576,989,1000,341,580,1000,302,623,-862,-1000,-780,-8,-56,-764,173,1000,-97,-770,565,974,140,308,1000,627,-1,99,116,1000,341,-1000,-452,-62,63,-537,1000,-1000,887,-903,1000,1000,-863,-1000,-174,-1000,-42,-1000,-306,-913,1000,-116,1000,1000,-1000,439,1000,1000,-240,-980,-1000,-186,-619,257,126}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00399() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "contains(char):boolean",
            new int[]{-324,-446,-891,1000,-606,-102,52,-1000,1000,-381,895,306,970,1000,1000,607,808,-900,-1000,-954,376,-1000,-170,-117,812,-1000,-1000,1000,183,761,854,1000,-860,-1000,1000,-876,312,-451,86,806,36,682,1000,260,781,-927,1000,313,228,-19,422,-1000,697,152,-538,-329,-466,-354,-1000,124,-233,-438,263,557}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00400() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "contains(char):boolean",
            new int[]{149,-856,-65,889,91,215,-865,-94,1000,-1000,574,315,83,632,1000,1000,183,-109,-322,-693,-260,-339,-724,-458,-492,-1000,-1000,590,385,-5,1000,736,-929,-834,812,-1000,76,-263,906,-726,-1000,1000,702,877,1000,-486,405,309,1000,480,-1000,-611,122,247,-306,1000,-665,28,-968,-148,-194,843,-668,326}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00401() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "contains(char):boolean",
            new int[]{454,-202,82,1000,783,774,140,-236,992,-1000,1000,1000,477,1000,538,1000,1000,-250,-1000,-1000,1000,-1000,-1000,948,867,-1000,-1000,986,1000,1000,-35,1000,-959,-636,930,121,-350,-451,1000,449,675,1000,1000,302,42,-965,-51,345,-167,-53,-529,-925,1000,-259,544,400,528,-235,-1000,294,-1000,-438,263,703}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00402() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "contains(char):boolean",
            new int[]{-946,-958,1000,570,832,501,84,-826,471,-782,-1000,447,-1000,-830,606,1000,227,1000,-248,38,22,-1000,-931,1000,1000,1000,230,816,760,879,-545,1000,1000,212,96,897,-767,-351,-1000,670,222,436,-1000,-339,1000,971,667,605,-133,-324,-1000,-921,1000,-853,1000,110,953,721,707,887,262,-822,-11,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00403() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "contains(char):boolean",
            new int[]{-1000,-784,-783,-1000,50,-156,-673,-1000,-1000,1000,-168,528,-150,-696,-508,-956,-908,308,6,-100,-1000,-1000,1000,-1000,-426,790,961,702,-1000,-1,1000,-1000,1000,27,621,-1000,1000,-1000,-241,1000,-1000,-878,1000,-428,1000,399,1000,1000,-712,-1000,1000,-1000,-2,1000,-935,-1000,-925,-372,1000,992,987,-1000,968,48}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00404() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "contains(char):boolean",
            new int[]{-573,-1,128,1000,1000,658,-348,-270,-1000,614,-680,1000,-164,-96,-298,60,1000,-489,31,-1000,1000,-1000,-750,1000,1000,1000,-1000,1000,927,1000,-1000,-135,1000,-1000,-382,1000,930,-1000,-116,1000,-44,1000,189,-1000,-69,-30,-71,982,-1000,-1000,61,-1000,1000,815,269,-1000,263,-448,651,1000,-1000,-1000,379,-33}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00405() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "contains(java.lang.String):boolean",
            new int[]{-708,-1000,1000,-1000,340,-1000,-562,29,1000,1000,-190,-1000,-323,733,-182,-762,-1000,-1000,1000,902,1000,1000,-1000,-725,1000,1000,1000,-1000,-634,-483,-1000,-35,-833,-136,-322,-576,-1000,-1000,-91,113,-43,-97,-262,688,75,1000,-20,1000,1000,-1000,-515,-150,-1000,-1000,22,1000,-286,-912,-1000,-212,-251,1000,8,-602}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00406() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "contains(java.lang.String):boolean",
            new int[]{98,12,-811,896,713,1000,-35,-273,152,-528,1000,1000,597,-1000,-301,-110,487,146,-969,-56,-992,-1000,-591,-298,290,-719,-32,1000,-250,-242,-483,64,-737,-527,670,1000,357,1000,-1000,279,-34,1000,438,-614,-5,-1000,-312,199,-472,386,93,1000,980,671,22,4,-574,-532,619,-702,-141,-1000,1000,736}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00407() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "contains(java.lang.String):boolean",
            new int[]{1000,-1000,-486,152,966,588,187,183,-213,-551,456,1000,968,-989,367,-398,1000,930,-944,-400,-1000,-140,809,365,539,-1000,503,653,-1000,763,388,-433,-915,-237,1000,1000,-18,437,-545,-592,-110,-177,-259,350,835,-527,-475,-45,-374,-11,-837,640,382,1000,258,236,-204,254,1000,-728,830,-894,1000,402}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00408() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "contains(java.lang.String):boolean",
            new int[]{1000,-1000,227,464,966,568,187,183,-213,-979,-426,588,1000,-989,303,-317,1000,930,-728,-400,-1000,116,1000,111,539,-1000,503,-124,-1000,1000,388,135,-1000,-1000,1000,694,-18,95,15,-592,-791,68,-242,350,-536,-527,-26,617,-374,-11,-1000,503,382,1000,790,299,290,-105,674,-846,775,-411,808,128}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00409() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "contains(java.lang.String):boolean",
            new int[]{200,-1000,1000,-1000,974,-706,32,572,-436,546,-449,-683,313,-793,272,-888,-600,-257,483,258,634,1000,-625,-942,-256,-93,-491,-1000,-430,219,-1000,-358,-227,1000,-325,-1000,52,-1000,936,-433,-112,-1000,-252,1000,85,1000,-823,1000,322,586,-690,-1000,-355,-534,-323,864,136,662,-211,-693,1000,1000,1000,-83}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00410() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "contains(java.lang.String):boolean",
            new int[]{-1000,-1000,897,-627,444,583,-803,-469,953,1000,-68,397,-635,532,-663,59,-1000,-918,678,1000,-1000,284,-1000,-1000,-1000,1000,-818,-757,653,-1000,-756,638,-330,-147,-986,-749,-668,317,280,1000,524,-59,1000,-59,-1000,-1000,-837,332,873,764,835,-598,78,-117,-1000,1000,-421,-1000,-1000,-974,-577,717,858,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00411() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "contains(java.lang.String):boolean",
            new int[]{-27,1000,-1000,-1,817,494,-559,578,-688,-402,1000,169,163,-659,-1000,-43,438,-1000,-1000,1000,-67,-1000,-625,-566,1000,-921,815,1000,-146,-1000,756,777,-731,128,1000,1000,157,696,-1000,1000,707,1000,27,-1000,-414,-1000,464,-1000,475,798,1000,-176,1000,-664,245,358,-1000,-541,1000,-168,101,574,826,-83}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00412() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "contains(java.lang.String):boolean",
            new int[]{-992,-1000,1000,-1000,469,-977,-231,-143,644,410,-916,-1000,-302,546,-112,-328,-1000,-1000,741,504,1000,1000,-1000,-1000,809,1000,941,-694,453,89,-1000,638,-77,530,-713,-678,-427,-1000,85,368,260,235,414,376,-1000,1000,-387,952,254,-449,-59,-301,-871,-1000,-51,1000,-282,-940,-987,-522,-268,1000,8,-453}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00413() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "contains(java.lang.String):boolean",
            new int[]{-535,-1000,1000,-366,685,-224,-253,368,-467,-352,-793,-454,67,-118,-320,-293,382,65,-1000,434,-436,99,-191,-1000,334,400,559,1000,252,19,331,1000,-296,49,-64,72,488,437,495,-516,1000,-54,677,-32,-548,-1000,-20,395,-74,561,180,249,435,-932,572,325,-529,181,1000,-575,1000,240,434,320}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00414() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "contains(java.lang.String):boolean",
            new int[]{1000,-1000,335,-1000,1000,100,-53,912,565,145,343,300,732,252,80,-547,919,548,-850,61,-819,479,1000,-58,-440,-81,-69,-694,-405,183,107,-1000,-1000,436,1000,999,-217,-569,25,-442,845,377,-234,330,215,-608,-1000,1000,98,244,-647,-858,-1000,865,-386,364,-583,187,983,-1000,1000,-492,147,285}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00415() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "contains(java.lang.String):boolean",
            new int[]{1000,-1000,-608,526,644,459,202,-165,-66,-1000,350,1000,751,-569,317,-276,841,982,-972,-537,-1000,-364,902,324,868,-1000,860,1000,-1000,788,129,-60,-807,-266,1000,1000,1000,613,-677,-571,-148,152,-509,197,733,-759,248,-558,-626,79,-417,1000,362,904,712,-1000,-439,169,1000,-436,236,-1000,434,-167}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00416() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "contains(org.apache.commons.lang.text.StrMatcher):boolean",
            new int[]{93,-691,1000,1000,264,-612,-451,1000,-663,317,-793,814,733,55,-1000,1000,1000,-764,0,-466,-309,1000,-1000,-1000,-1000,-60,982,1000,-145,245,532,221,258,853,-1000,-924,641,426,1000,-679,1000,503,-230,-1000,863,-248,-906,901,-1000,-1000,-11,1000,-929,1000,-594,-1000,47,578,481,-1000,-520,183,692,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00417() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "contains(org.apache.commons.lang.text.StrMatcher):boolean",
            new int[]{1000,115,884,73,229,-474,-831,-557,343,-217,-53,-256,791,445,-348,-538,-476,304,-216,451,470,669,-236,949,106,261,-542,-400,795,151,-402,117,-171,205,770,-673,1000,-204,-226,-109,103,-248,-265,-659,19,-481,347,234,-628,-504,892,88,55,650,15,912,-936,170,-266,-495,643,672,341,-46}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00418() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "contains(org.apache.commons.lang.text.StrMatcher):boolean",
            new int[]{105,291,-552,677,-193,384,512,1000,-998,336,958,1000,-20,-115,79,737,-385,-720,-277,359,-1000,1000,24,1000,-1000,1000,1000,-815,-844,137,-1000,-773,-1000,-54,-59,1000,-1000,171,1000,843,-656,427,732,-1000,-1000,915,-616,-103,380,-1000,159,-152,-595,272,774,-1000,267,1000,481,1000,-1000,-61,-1000,-724}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00419() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "contains(org.apache.commons.lang.text.StrMatcher):boolean",
            new int[]{-1000,-811,1000,-118,264,-1000,873,76,267,663,-1000,-898,1000,529,-589,179,-378,1000,776,721,1000,107,-530,260,-239,-70,1000,1000,262,831,684,221,-329,671,770,-1000,429,1000,-925,-134,563,-299,-1000,650,1000,1000,-906,1000,-597,-1000,-495,168,356,-59,609,1000,-1000,-609,-866,-1000,540,-1000,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00420() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "contains(org.apache.commons.lang.text.StrMatcher):boolean",
            new int[]{192,-131,116,1000,316,-351,-80,588,186,-375,-26,1000,996,1000,-933,1000,24,-1000,15,22,-1000,-1000,-617,-316,-867,-1000,219,-914,108,885,903,-786,-1000,-1000,-537,460,-847,-824,-1000,-868,-1,766,20,1000,-518,-924,297,-428,-505,-31,1000,689,-916,1000,1000,-254,-190,133,-624,1000,-491,1000,-766,297}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00421() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "contains(org.apache.commons.lang.text.StrMatcher):boolean",
            new int[]{278,494,-495,-593,-573,279,-753,-854,-150,488,10,-180,-806,-1000,130,-1000,-1000,863,246,-762,438,-579,-596,601,1000,228,-864,1000,492,-372,-70,-11,146,459,717,250,639,-477,-372,1000,-591,219,-321,-437,-845,888,368,-625,76,-792,-1000,210,221,-1000,-405,154,790,-368,1,-747,-449,-1000,-12,-337}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00422() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "contains(org.apache.commons.lang.text.StrMatcher):boolean",
            new int[]{-801,-1000,-176,1000,872,-376,-1000,299,-62,-1000,991,1000,1000,568,581,1000,963,-1000,139,1000,-1000,-436,-1000,-865,-883,1000,1000,640,176,1000,147,-1000,-482,-1000,-607,228,-1000,438,234,-304,937,1000,-744,-40,828,-1000,560,116,-1000,656,1000,-502,-164,1000,1000,-72,393,1000,-757,761,-839,1000,-709,675}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00423() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "delete(int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-931,-1000,-47,-397,-363,-281,-663,984,478,134,-242,537,284,1000,-1000,141,-211,839,-170,569,331,266,361,789,-139,528,268,-108,234,1000,1000,435,-1000,367,182,638,-1000,3,1000,1000,-1000,557,1000,-105,1000,-328,1000,-590,259,258,-223,278,844,187,772,736,-375,885,-74,-326,1000,-661,-215,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00424() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "delete(int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-246,-1000,556,-546,-356,649,-286,-799,799,-41,-232,121,-123,806,268,354,-211,380,634,569,1000,240,-256,240,-1000,-381,734,1000,-248,-165,1000,435,-53,367,-690,-343,602,3,361,-242,-1000,1000,828,643,1000,-633,-335,496,230,626,551,46,-353,487,736,1000,816,212,5,-1000,632,-159,-486,-275}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00425() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "delete(int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{568,57,-216,-313,1000,448,-174,363,716,195,-1000,584,871,1000,-518,-1000,-145,-290,-602,528,-3,559,-154,-1000,736,-95,689,-765,-531,-140,957,937,-779,1000,857,1000,-1000,-1000,91,414,-312,-945,-969,512,1000,925,592,-421,-731,211,302,1000,1000,-1000,618,-1000,115,-235,-675,175,619,-442,1000,671}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00426() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "delete(int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{176,-592,86,-884,1000,-1000,-428,694,219,-750,204,915,578,895,-895,-737,-95,-384,33,660,-451,-125,-21,-431,1000,363,253,-1000,-534,-773,-659,916,-1000,-59,969,-791,-1000,-620,412,991,-173,-947,-206,199,-877,556,432,-1000,-804,-218,-356,853,989,-1000,384,-1000,-401,-5,278,146,414,80,518,686}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00427() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "delete(int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{669,223,-530,516,168,-568,697,844,474,0,783,957,-213,-185,-1000,588,264,-384,-1000,401,-1000,754,-979,325,923,1000,473,-1000,-534,-221,-1000,-484,-854,-938,1000,-591,-8,-620,-490,737,-120,-1000,306,-788,-304,1000,-343,-895,-1000,-1000,-722,913,965,-575,209,-1000,-834,-88,-969,257,1000,857,-327,-869}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00428() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "delete(int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{932,-901,158,-1000,694,-33,-6,-297,-175,-204,394,675,-432,925,-479,-440,-314,-795,48,1000,-746,-164,-642,-146,-115,687,-364,-545,-981,-721,-647,-366,-874,324,120,-1000,-1000,-188,160,131,-660,-301,262,1000,-488,-599,-490,-1000,-774,-53,-298,1000,246,-321,209,-423,751,374,1000,232,143,580,1000,-189}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00429() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "delete(int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{603,-1000,-1000,-426,-336,-859,503,572,545,-599,-290,-974,-1000,917,-268,400,-49,578,103,1000,233,494,-191,452,416,512,594,278,-1000,-81,-659,-328,568,211,679,-306,-1000,340,-651,65,176,-303,475,-124,452,-16,189,-1000,322,-1000,-732,1000,1000,-1000,1000,-221,-1000,983,-1000,-717,19,-883,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00430() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "delete(int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-1000,272,-185,103,183,33,-1000,644,242,-1000,-822,539,1000,593,-892,-923,951,82,470,956,327,-783,-831,-890,-1000,867,264,-951,-351,1000,-660,960,-300,-445,-1000,359,1000,-478,-962,679,874,-379,240,501,117,-201,911,-18,897,1000,-188,-524,200,525,463,379,-185,96,-1000,575,-262,-922,-118}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00431() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteAll(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{439,-613,126,818,21,-902,-141,-674,-1000,-847,284,549,85,419,877,392,222,35,687,-1000,654,271,-300,-684,56,1000,-574,-844,864,579,-819,-456,-880,-687,-521,-500,108,-827,-338,-397,-804,626,-1000,994,322,-847,-1000,479,1000,1000,1000,-390,-285,374,-1000,-653,-818,200,-235,-233,1000,-145,-699,-416}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00432() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteAll(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-315,-84,39,212,1000,-674,726,-1000,1000,-674,-118,-933,659,448,101,-1000,-525,454,1000,-239,-1000,-19,686,114,431,-1000,905,-773,255,-83,-784,44,125,-213,560,1000,1000,-959,-1000,187,1000,446,1000,-146,564,-204,-151,-1000,954,329,394,32,426,1000,1000,-85,679,-1000,-652,-1000,-938,55,844,238}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00433() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteAll(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{262,-1000,684,1000,-1000,325,-846,853,-1000,945,818,644,-463,788,1000,870,457,819,324,263,1000,-345,305,-266,-561,764,-28,-407,372,611,349,-455,51,46,-1000,-502,-210,206,1000,-699,-674,-293,6,-669,-810,220,-21,1000,-726,1000,542,-169,-642,37,-197,209,85,198,1000,312,1000,162,-918,-85}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00434() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteAll(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-1000,192,974,-293,-381,-748,-737,-961,1000,-391,287,-132,-69,1000,-1000,646,1000,-755,1000,73,-1000,602,230,-775,-30,-70,266,117,-499,-848,-1000,390,-781,-465,196,686,646,708,175,-68,-298,-857,-956,-417,554,1000,865,1000,18,1000,-1000,-117,638,-452,-193,140,-39,1000,-1000,823,10,-1000,-62}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00435() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteAll(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,44,-214,-100,847,223,792,-727,944,-992,305,-934,207,681,-950,661,-1000,-1000,-525,780,-456,223,-199,-269,287,-796,279,49,-102,-529,-397,-213,-128,819,515,208,-812,-453,-583,-701,635,316,796,-83,358,-312,365,-807,-318,-587,-651,1000,414,-329,1000,-301,413,-862,-863,873,-1000,665,1000,19}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00436() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteAll(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,569,-776,1000,903,-869,-431,-629,925,-1000,105,57,-92,-774,216,660,789,-1000,77,570,397,-1000,675,-448,-1000,-677,823,113,-310,-384,1000,161,920,1000,-1000,-767,-1000,-904,619,424,-142,1000,91,-937,-1000,-160,708,114,-297,-1000,101,-230,381,251,685,703,1000,276,375,897,-806,-282,158,-280}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00437() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteAll(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-749,764,484,-32,307,872,508,298,-893,-1000,-1000,-438,487,190,-1000,-1000,-941,326,-1000,795,-631,-127,1000,-261,858,-34,-1000,618,-92,-691,-789,-1000,-798,-824,1000,-190,198,1000,-44,1000,-1000,113,1000,958,83,-747,-1000,120,400,899,-148,194,-392,235,-92,342,475,382,1000,995,-830,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00438() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteAll(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{212,-154,-679,-351,-553,-93,306,-306,944,268,914,275,-413,-303,-160,1000,100,-1000,-1000,1000,763,-30,247,-147,329,-1000,504,1000,-1000,-507,666,-1000,205,650,-77,-640,-583,374,614,-739,1000,517,1000,-1000,-253,418,1000,-1000,-1000,-631,-1000,1000,722,-1000,495,-400,54,-1000,-1000,1000,-1000,811,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00439() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteAll(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{317,-1000,-1000,-141,-96,-751,129,622,1000,842,-394,827,1000,-1000,-457,207,-136,84,1000,-86,-768,-707,1000,1000,-1000,-456,-240,-911,-756,91,980,817,1000,-486,1000,-1000,-1000,-1000,1000,-148,1000,-1000,-551,-1000,-822,1000,-578,-1000,-5,-797,36,-616,1000,125,-1000,-171,-1000,1000,-1000,196,528,717,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00440() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteAll(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-1000,353,483,-533,-156,-988,42,-156,1000,137,673,-409,847,-696,742,-606,-371,269,954,364,-636,-377,517,894,-34,85,1000,1000,-1000,-966,131,-916,-111,-451,36,-442,400,948,-1000,-1000,775,1000,400,505,-1000,1000,-326,919,-1000,-653,-368,-265,-1000,146,387,-555,-659,-213,196,208,-1000,-420,648}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00441() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteAll(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-588,-581,1000,-29,174,-1000,-353,144,654,-420,-453,127,443,-1000,-977,-1000,127,-919,-580,1000,49,-764,578,15,956,-168,516,-592,-1000,-1000,192,-1000,-43,-718,443,150,1000,465,-76,-633,601,1000,789,535,-739,459,-687,1000,-425,87,528,-800,-778,1000,-726,-402,-852,1000,963,-666,35,-337,471}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00442() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteAll(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-1000,-400,181,-1000,-742,-100,-716,110,991,-889,1000,-462,-1000,128,39,142,240,-965,12,-573,-645,400,-580,-706,-138,-7,318,-1000,-129,-548,976,241,434,78,-351,-824,-1000,-400,73,653,-624,116,-37,-50,400,1,-37,-130,-1000,-323,239,321,1000,-400,-883,38,334,778,451,649,-560,17,-4}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00443() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteAll(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-870,-1000,-196,136,-1000,-248,-566,-354,-628,1000,-374,164,-919,424,-222,-859,-843,813,-131,-67,688,-452,-849,309,909,631,-398,1000,987,-1000,-1000,-679,-1000,58,-980,-984,-424,1000,346,-230,-1000,827,1000,1000,851,-1000,907,1000,-762,-832,-718,719,321,-777,1000,552,-154,-1000,704,-368,29,-381,-73,497}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00444() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteAll(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-239,-316,-84,1000,59,-117,487,6,-645,-174,894,-713,-702,164,633,486,102,947,-325,1000,118,-141,-894,401,403,704,856,165,-201,-1000,122,-723,-115,1000,-1000,-878,-8,342,-71,278,-277,1000,649,751,730,-792,178,-796,313,-1000,-523,942,-1000,-125,404,-306,-522,70,-762,-7,1000,-886,-795,-354}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00445() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteAll(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{857,280,51,765,228,-903,1000,-637,957,-1000,103,-848,1000,-1000,-1000,1000,2,-1000,-779,-1000,1000,-1000,-200,760,-1000,1000,238,94,-1000,429,-535,-1000,932,36,-289,-1000,168,55,531,61,1000,-505,503,514,-1000,-318,-289,-792,-866,-235,-667,807,-701,541,680,49,-579,-594,996,270,462,-294,675,931}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00446() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteAll(org.apache.commons.lang.text.StrMatcher):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-1000,679,809,1000,363,-988,178,599,15,-134,744,-374,-938,-1000,475,110,-192,-470,-130,-479,660,1000,-532,-218,-606,-308,-1000,375,1000,-199,-621,1000,1000,1000,-1000,525,-143,506,1000,1000,-776,551,92,-911,-945,-6,310,909,551,-747,687,1000,962,79,498,-454,-871,-1000,841,-625,-1000,-694,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00447() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteAll(org.apache.commons.lang.text.StrMatcher):org.apache.commons.lang.text.StrBuilder",
            new int[]{-544,894,-282,76,-417,-932,632,-643,196,-629,69,578,754,-781,967,390,-752,450,-610,-411,-627,-316,-235,498,-313,-631,939,943,-385,474,-585,-286,-74,-403,-310,-608,304,-55,606,-739,-15,-884,826,-342,-929,897,133,-456,112,-587,96,-636,-194,-144,-153,-682,-732,773,199,-942,200,412,143,513}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00448() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteAll(org.apache.commons.lang.text.StrMatcher):org.apache.commons.lang.text.StrBuilder",
            new int[]{782,662,1000,1000,-133,-161,-486,-588,-297,1000,96,-551,288,-1000,-832,-1000,-614,641,167,74,-1000,144,-149,-1000,1000,-1000,379,-1000,187,463,687,-955,892,1000,1000,-797,1000,642,124,765,1000,-133,-26,24,-1000,-408,69,368,808,-351,-957,948,1000,1000,1000,211,690,-1000,-920,-4,-398,-1000,-162,-225}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00449() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteAll(org.apache.commons.lang.text.StrMatcher):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-1000,140,861,-1000,1000,-208,-368,1000,457,207,-1000,-540,-1000,365,771,966,1000,934,-446,421,206,-992,-1000,1000,-1000,117,-1000,620,248,84,-982,892,360,1000,-1000,1000,-15,767,1000,626,-948,486,-477,-1000,-535,696,-1000,1000,1000,-1000,1000,1000,62,308,-107,503,-1000,-956,669,1000,-1000,-232,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00450() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteAll(org.apache.commons.lang.text.StrMatcher):org.apache.commons.lang.text.StrBuilder",
            new int[]{-501,1000,-387,677,-146,-1000,19,-79,-340,-233,-279,967,-312,-46,-1000,-1000,56,219,-1000,285,218,-481,-798,1000,-1000,-368,139,-406,-1000,-113,-786,243,-459,59,-875,-631,-46,-345,-1000,-1000,-1000,1000,20,-449,592,559,510,664,-1000,-666,1000,-1000,-1000,29,-562,716,-1000,1000,569,250,-821,554,-176,-219}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00451() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteAll(org.apache.commons.lang.text.StrMatcher):org.apache.commons.lang.text.StrBuilder",
            new int[]{-950,-1000,537,-1000,-16,452,-961,-521,-960,400,-1000,47,199,-1000,-1000,-215,289,-853,422,-257,-606,1000,449,-736,95,-359,379,-584,-103,-534,-570,646,-427,1,1000,-502,-119,-5,813,430,692,-513,1000,-1000,-1000,-561,520,-798,969,-441,-379,732,623,1000,880,857,642,-911,-1000,607,788,-1000,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00452() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteAll(org.apache.commons.lang.text.StrMatcher):org.apache.commons.lang.text.StrBuilder",
            new int[]{-56,-55,816,84,-1000,-221,-492,-917,1000,1000,1000,-573,696,-1000,-244,-1000,-790,1000,-186,-1000,-1000,945,-606,-1000,1000,296,-256,-243,83,315,1000,-1000,-894,1000,996,-1000,1000,-303,-1000,455,423,-1000,346,-141,-1000,982,-600,1000,-180,1000,-1000,507,1000,-1000,254,1000,-98,780,1000,-680,-31,-1000,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00453() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteCharAt(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{114,-1000,-1000,34,938,-424,349,-938,71,-818,427,1000,-554,-868,1000,1000,1000,198,881,60,858,-683,610,-164,-676,1000,206,-460,-1000,-627,1000,778,1000,-1000,-39,1000,368,-1000,303,-250,274,-638,-278,-944,-1000,321,1000,-1000,186,-1000,-506,-41,174,-98,614,315,108,-231,-910,-660,-295,-1000,-535,-561}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00454() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteCharAt(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-665,-207,-646,481,922,-501,833,380,-527,313,950,837,-401,-646,-973,372,850,822,44,867,-897,-955,-690,214,-559,211,828,4,159,841,-170,-69,-432,750,-103,409,-414,700,343,526,771,241,44,-79,412,-638,-159,406,550,447,750,257,433,815,-236,963,-253,615,795,914,-754,228,-530,-951}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00455() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteCharAt(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-989,-46,517,1000,807,-1000,-501,366,768,1000,-331,486,-934,854,41,-313,1000,-541,-539,400,-189,704,-259,-552,-775,105,724,-356,-40,-913,-257,359,655,-795,289,1000,1000,255,599,329,47,-121,-244,-566,163,1000,-701,103,752,-1000,1000,-1000,1000,-79,531,815,209,584,-548,686,519,-99,-744,583}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00456() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteCharAt(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-880,799,469,-120,1000,-21,167,1000,210,1000,-1000,-132,213,720,-346,-637,-616,468,166,433,-69,-159,-607,576,-1000,-180,-231,-258,-1000,-257,-892,898,284,-428,1000,-912,-395,-393,261,118,-1000,453,-516,-889,547,-59,-1000,-527,-1000,66,-531,430,138,893,-1000,959,-653,-698,-1000,-581,750,-344,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00457() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteCharAt(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{919,-1000,144,78,-925,822,270,-626,799,-106,-119,-1000,205,-611,408,-410,-121,-1000,-158,-1000,778,440,1000,1000,-21,-6,-1000,756,-495,-1000,-465,-828,1000,-949,1000,1000,-666,-2,-8,531,373,58,-651,-1000,-1000,815,128,-1000,850,524,886,-1000,626,323,1000,-885,1000,-619,-275,576,-247,70,94,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00458() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteCharAt(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{850,-380,-798,144,68,1000,74,-688,-404,909,888,106,706,27,-18,1000,-71,-82,1000,1000,951,-114,-501,-1000,-116,-1000,-667,-597,992,-1000,1000,-728,-347,-1000,-773,145,-830,-937,-671,1000,-1000,-216,757,-30,-1000,-139,-320,-1000,-1000,-42,-224,1000,1000,906,1000,-1000,-488,-1000,-1000,-115,-1000,1000,-1000,-180}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00459() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteCharAt(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{88,-880,-579,863,45,-878,-21,-85,444,560,143,564,-595,-243,467,310,614,-616,50,-213,868,-152,740,703,-54,741,-180,930,-101,-618,127,351,836,-912,444,903,672,349,254,-116,893,-672,-463,-979,-583,240,110,-896,852,-933,218,-997,84,-212,596,815,998,865,-24,-431,359,-941,-806,419}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00460() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteFirst(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-56,872,-344,-1000,-475,-221,-646,-1000,-616,145,1000,400,-183,540,395,-317,734,-27,-1000,-1000,-359,-69,1000,-1000,-816,-1000,-1000,-110,1000,108,965,-751,-1000,1000,373,1000,-453,-1000,-342,-223,1000,338,-1000,1000,1000,501,-1000,120,1000,-913,480,1000,1000,531,-1000,-1000,898,209,-1000,-1000,9,-1000,827,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00461() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteFirst(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-575,-941,-655,-242,-301,-343,-1000,-798,-108,-1000,970,-974,-1000,-1000,-22,-729,288,43,-325,-1000,733,606,1000,197,-1000,791,-939,-374,-1000,1000,-1000,-1000,-949,29,-1000,394,-909,-1000,626,-536,1000,-1000,-494,1000,973,-1000,-1000,-1000,-1000,403,919,1000,1000,-720,450,-159,380,-361,762,-1000,277,-459,-364,-574}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00462() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteFirst(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{34,-282,229,331,-637,-262,-1000,-669,-450,-184,529,-186,-53,-66,122,-55,333,-77,400,-750,-596,230,-432,-298,-467,354,173,-341,865,-86,-1000,-1000,-54,-98,-329,243,-686,-132,196,-417,216,-48,254,402,-636,-405,-305,-306,400,20,-986,-239,1000,-344,-33,361,-95,-82,26,-983,369,-296,-390,-889}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00463() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteFirst(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{311,-439,-330,172,134,-760,-1000,-976,611,-197,994,-118,423,777,-395,-48,-69,678,-271,-1000,-415,-1000,589,-445,-179,-1000,-534,-563,-226,118,445,-63,-337,1000,-52,898,-302,-1000,-125,-271,844,110,-876,-521,336,675,-647,599,121,-803,-94,284,761,-562,-1000,-446,712,297,-1000,-486,-87,-1000,-121,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00464() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteFirst(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-372,-1000,-200,1000,-482,-750,-761,-669,537,-665,294,-837,237,-582,244,53,-414,830,924,-993,-239,-1000,-321,-518,141,-269,354,-847,-147,448,-8,52,-43,753,-366,630,24,-797,825,-301,457,-424,-432,-37,303,-111,-284,359,1000,193,-1000,220,234,-398,-251,305,175,93,-556,163,525,64,-104,-294}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00465() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteFirst(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-656,-160,76,-342,129,-585,504,-63,-126,-744,74,-905,565,-766,777,-353,196,-244,757,-387,-110,-954,-30,-993,-346,44,-566,21,-275,284,105,-792,181,-321,-509,158,463,504,511,245,762,-888,-143,838,862,-127,79,-939,942,687,-986,654,-914,53,-213,-220,-179,91,598,732,862,218,-231,392}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00466() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteFirst(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-1000,636,1000,-1000,-801,-337,-578,862,639,-556,-544,1000,-721,1000,-4,-1000,1000,1000,-1000,-812,-1000,-1000,-656,1000,-1000,1000,-178,1000,871,1000,1000,1000,1000,1000,1000,612,-1000,1000,-870,570,476,-1000,272,1000,1000,52,1000,1000,-1000,-1000,-473,-682,-1000,311,-716,-784,1000,-877,1000,1000,31,824,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00467() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteFirst(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-1000,-785,-105,-432,425,-527,-988,-182,-1000,166,-1000,-1000,-1000,110,369,677,16,220,191,316,1000,-66,1000,-1000,1000,-1000,33,-1000,1000,-1000,-1000,-614,-1000,-616,-1000,-297,572,-1000,203,185,-1000,1000,1000,-707,-1000,-808,192,-1000,1000,544,1000,702,1000,1000,1000,-158,-1000,-1000,-1000,99,1000,1000,241}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00468() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteFirst(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{89,-814,704,-652,363,-463,240,-998,-354,-1000,467,-1000,-382,-1000,221,664,1000,-1000,720,-182,22,-306,119,469,-867,-51,-1000,-250,-330,862,-1000,-1000,-807,-1000,-1000,-488,134,1000,64,806,146,-468,356,529,-961,-1000,252,-1000,-458,206,-986,815,-200,303,1000,646,417,-978,1000,-668,382,868,-837,-864}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00469() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteFirst(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-972,35,-1000,-93,101,-50,679,-414,1000,-565,1000,-753,-440,261,874,-511,5,-159,-769,881,-412,-976,-918,273,102,313,591,-793,1000,833,-576,0,1000,223,993,-284,-928,328,1000,231,1000,1000,147,526,944,-1000,331,546,-706,1000,688,402,-1000,213,96,1000,-447,-1000,196,-297,-543,52,319,133}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00470() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteFirst(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-18,9,-93,101,143,298,-352,1000,-565,1000,-345,124,771,838,-516,100,-112,-802,814,175,-855,469,858,345,646,495,-720,744,1000,-152,284,-349,-434,1000,-360,-1000,702,675,32,736,1000,911,434,1000,-1000,-188,-26,-706,1000,-1000,1000,-828,10,214,1000,423,-843,-953,-297,-978,117,465,-922}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00471() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteFirst(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-867,-1000,-275,1000,-407,-59,456,-502,418,-1000,1000,1000,-844,-400,949,-1000,-566,-41,-510,79,293,2,-709,-6,128,678,-356,-947,-100,1000,-124,-276,1000,-197,1000,627,-771,-580,507,110,694,1000,306,537,1000,-986,1000,754,-1000,992,359,160,-658,213,-397,972,127,-921,196,-593,-1000,-591,1000,-33}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00472() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteFirst(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-543,467,-447,-42,971,-112,629,-1000,758,-865,-195,-948,726,343,800,400,825,393,-956,550,-366,-749,469,789,541,-590,600,-936,948,788,-272,277,630,-596,63,205,-6,-57,118,-302,-700,-301,-12,931,159,-55,579,855,-472,-63,354,980,-91,-286,589,311,-128,83,-355,-573,-950,1000,37,-373}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00473() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteFirst(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{879,-1000,-1000,840,-813,-581,406,-774,612,1000,385,-41,-58,-537,1000,154,-1000,-2,-823,1000,-338,-1000,-318,5,-1000,-88,231,-416,812,-1000,-917,1000,-1000,1000,1000,-1000,-240,1000,559,161,289,-388,-242,17,496,-481,-1000,425,308,783,331,1000,-640,-69,584,293,-106,-350,490,372,1000,1000,-638,-619}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00474() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteFirst(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-478,1000,1000,-34,-1000,906,26,653,-828,999,697,1000,772,57,-530,-1000,578,-1000,1000,358,-1000,-826,1000,17,375,1000,-1000,304,1000,436,97,-127,-708,644,-1000,-813,1000,-195,-318,684,809,799,1000,1000,-1000,-127,-1000,-147,928,1000,263,-1000,-371,-838,1000,476,161,-975,-708,-682,615,697,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00475() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteFirst(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-535,-286,-762,-73,439,-781,-7,429,795,-535,1000,-167,357,475,320,-858,257,317,-766,745,298,-329,-575,492,488,239,395,-487,574,544,77,120,762,-545,403,548,-481,319,648,522,302,983,803,-329,422,-820,910,-334,-186,772,338,641,-542,142,-679,897,416,-310,-295,224,-979,820,839,-753}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00476() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteFirst(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{290,-1000,-1000,273,-610,-428,-205,1000,595,1000,1000,506,-660,-905,825,-1,-1000,-400,-463,-99,-262,-315,-1000,-104,-1000,327,-192,-134,514,-930,-491,620,-626,1000,283,-353,-1000,962,984,704,694,1000,207,-914,1000,-986,-358,578,441,1000,634,-224,-658,730,-589,761,648,-759,959,1000,896,-848,-279,-92}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00477() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteFirst(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-621,-749,-218,-574,659,97,83,-302,-925,874,-54,206,-899,388,937,850,-650,-180,-616,-765,-357,-453,615,812,210,-856,313,911,-526,480,83,846,-811,-439,47,-314,-588,364,-589,-474,770,-719,324,-871,-204,-1,-922,654,723,-371,-286,862,60,-240,441,-329,516,692,919,-789,397,-382,431,-357}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00478() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteFirst(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{439,320,-772,233,-460,-748,464,-414,-171,874,-672,-39,146,-217,834,-119,993,286,59,-563,-855,270,760,111,595,129,992,-793,916,-429,-14,457,-523,-132,-752,825,642,-310,-6,731,-923,-938,387,983,-407,159,-219,530,564,-327,-799,842,-89,-671,-386,-812,-135,708,203,376,-706,52,-175,618}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00479() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteFirst(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-235,-1000,400,273,-539,-428,-205,903,603,-400,1000,581,-660,-112,825,-719,-237,-400,-463,-99,-262,-310,-1000,514,230,327,-192,-134,-786,400,51,357,400,-400,644,-59,-1000,224,581,426,694,1000,207,-717,1000,-986,400,578,84,1000,634,-224,-658,603,-142,761,648,-121,208,40,-127,-848,147,-92}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00480() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteFirst(org.apache.commons.lang.text.StrMatcher):org.apache.commons.lang.text.StrBuilder",
            new int[]{228,284,-865,-668,297,747,-583,-73,-250,160,-1000,141,225,-664,-584,60,-258,38,-115,712,109,-262,1000,-55,-309,-656,-766,87,-752,766,-951,400,-537,-649,89,366,58,902,943,34,465,-437,-1000,-416,78,-89,1000,7,-256,-386,-848,221,643,473,575,-669,763,293,-652,906,171,163,571,109}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00481() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteFirst(org.apache.commons.lang.text.StrMatcher):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-813,-686,37,1000,1000,-573,58,78,-347,-1000,628,600,-192,886,399,270,-708,607,-925,882,-597,470,449,-79,-1000,-688,181,-424,578,-826,-831,-340,-840,-578,1000,144,774,-1000,-1000,-312,45,-886,-390,1000,-598,1000,564,71,-317,-124,1,389,-74,441,24,575,275,-838,-1000,366,565,611,662}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00482() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteFirst(org.apache.commons.lang.text.StrMatcher):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-1000,623,1000,1000,196,-351,-362,1000,479,198,-1000,1000,1000,750,376,108,-1000,491,279,723,-182,-1000,834,338,363,-1000,874,973,-264,1000,-948,1000,-283,336,79,934,-789,-1000,-1000,-1000,750,1000,380,1000,-758,747,786,1000,-517,1000,-1000,-1000,-129,1000,791,-1000,312,-1000,-856,1000,737,-950,627}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00483() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteFirst(org.apache.commons.lang.text.StrMatcher):org.apache.commons.lang.text.StrBuilder",
            new int[]{-596,725,-431,-1000,-1000,299,89,-992,-381,-167,-243,-51,225,-199,-1000,-68,-258,-501,-1000,-125,-34,-302,871,-55,-595,-319,-339,103,-779,30,173,901,724,-649,89,-1000,349,902,-714,-909,-428,-1000,-411,-734,-7,842,1000,-409,-590,1000,-1000,-429,1000,314,1000,-131,347,538,-652,239,670,308,-312,-523}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00484() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteFirst(org.apache.commons.lang.text.StrMatcher):org.apache.commons.lang.text.StrBuilder",
            new int[]{-158,397,-102,-680,479,-71,-351,118,-1000,346,649,-212,673,-214,1000,220,-1000,-554,-374,-390,350,841,-257,-3,450,-203,-15,86,352,65,1000,-582,275,-1000,1000,-32,-643,-1000,-189,-1000,1000,-880,564,520,-973,-677,-661,-343,493,807,-798,756,-70,-518,354,480,101,-388,342,1000,-400,-293,-862,-847}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00485() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteFirst(org.apache.commons.lang.text.StrMatcher):org.apache.commons.lang.text.StrBuilder",
            new int[]{805,530,-304,-1000,-1000,-567,36,583,-1000,-776,349,1000,-654,-1000,-1000,-1000,-421,599,-347,105,241,1000,633,309,1000,-86,979,-1000,-21,-758,-450,1000,1000,-410,634,-268,-928,167,665,-1000,-505,-1000,-1000,343,-1000,385,-776,-1000,-1000,749,-1000,1000,1000,-550,-648,-235,712,-302,214,1000,-1000,-356,198,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00486() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "endsWith(java.lang.String):boolean",
            new int[]{346,-718,34,-407,-59,286,72,87,-781,-1000,105,-565,168,-906,-75,105,-397,-1000,275,69,-14,1000,-736,-1000,55,787,1,-121,834,154,720,-698,1000,-502,378,-989,692,-167,-307,-691,-40,377,-778,-499,-222,858,479,-14,-232,-646,414,-137,-840,611,-1000,677,-469,501,124,96,-815,-871,743,172}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00487() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "endsWith(java.lang.String):boolean",
            new int[]{222,-813,34,-407,-1000,286,144,-71,-781,-1000,-52,-894,476,-913,48,430,-393,-400,275,373,-14,426,-1000,-1000,748,853,-719,-244,1000,-1000,1000,-1000,1000,-361,590,-1000,537,365,-293,-974,125,752,-1000,772,-543,782,55,-211,-148,-122,917,-617,-840,897,-602,767,-440,48,-362,-127,-1000,-840,859,128}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00488() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "endsWith(java.lang.String):boolean",
            new int[]{-759,-613,161,186,-115,-442,-390,76,558,599,-709,227,-310,-474,-480,-163,-233,-840,419,997,244,-13,291,-540,743,-707,-288,-186,279,-170,-857,218,721,475,335,122,-403,256,-523,563,443,997,-827,575,407,346,630,992,566,441,-833,509,506,-345,-862,248,-872,-85,657,280,347,-61,147,547}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00489() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "endsWith(java.lang.String):boolean",
            new int[]{-641,-584,-339,-540,539,607,161,98,-383,158,-493,344,801,-989,776,-398,-247,216,707,761,-73,-831,-435,-5,685,354,522,666,793,-980,785,-879,469,-636,103,-527,939,822,-934,-391,660,792,-361,-371,-217,-212,-255,631,-748,-619,419,389,-18,554,6,808,984,103,-776,268,-995,-395,-497,-37}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00490() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "endsWith(java.lang.String):boolean",
            new int[]{-72,-877,-688,-195,536,-431,227,-489,-774,1000,-21,-736,627,-908,1000,-479,-1000,-334,716,-256,-666,-831,-503,-573,-904,-158,522,1000,969,-656,1000,70,-166,-721,-514,-99,939,742,-948,43,1000,739,-1000,-1000,212,1000,523,839,-1000,-678,530,1000,283,-1000,612,1000,-683,-33,861,1000,-511,-595,-72,-786}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00491() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "endsWith(java.lang.String):boolean",
            new int[]{1000,-709,1000,15,158,-1000,-143,-708,856,362,724,362,10,676,-424,324,-1000,540,-8,-93,-915,1000,201,561,-1000,-645,-84,831,679,1000,561,1000,-559,482,539,810,184,-1000,428,317,-1000,-582,-360,476,122,142,1000,-30,149,350,47,528,-1000,22,360,-1000,-853,679,-843,50,-271,-1000,664,622}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00492() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "endsWith(java.lang.String):boolean",
            new int[]{662,-1000,276,624,-237,-171,-404,-276,-23,-744,714,-1000,541,174,-1000,-402,-924,338,82,96,-392,1000,-661,-1000,-312,79,-903,-71,1000,24,895,-347,852,-182,411,-1000,-133,-284,446,-907,-17,-316,735,7,-139,1000,-454,-183,-222,776,372,-115,174,417,-370,237,-1000,315,339,259,1000,-835,1000,-160}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00493() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "ensureCapacity(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{595,-757,1000,-78,253,1000,-581,-1000,712,1000,917,-913,387,-503,142,250,-1000,976,551,-560,121,1000,1000,-1000,-1000,-1000,7,-1000,-169,-980,-758,-790,-1000,998,433,1000,-1000,290,-1000,-1000,-1000,586,323,121,-157,779,80,300,1000,70,-1000,329,96,-815,-491,-681,-1000,-544,-200,-522,557,-34,-103,-360}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00494() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "ensureCapacity(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-39,-591,999,-672,-673,-606,503,-999,1000,34,-1000,-970,-788,-918,156,403,-439,-603,876,858,469,1000,-565,58,733,-1000,417,-1000,-269,292,-612,-607,75,-95,-59,91,-595,-1000,-485,470,-791,483,-1000,1000,1000,489,579,1000,708,-681,141,478,413,233,-172,282,312,-489,-132,-638,-343,-1000,1000,-463}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00495() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "ensureCapacity(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{405,-794,1000,69,354,1000,-888,-1000,715,1000,669,-913,472,-376,166,203,-1000,922,571,-560,-43,1000,197,-1000,-1000,16,7,114,-598,406,-684,-790,-996,254,454,-1000,-1000,216,-1000,-999,-1000,652,105,9,-53,720,112,300,1000,140,-881,329,-18,-623,-362,-440,-1000,-544,-611,-336,536,46,228,-196}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00496() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "ensureCapacity(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,470,-735,-1000,-1000,407,-151,-304,-1000,-197,-1000,-772,-690,-1000,-1000,598,1000,-1000,-1000,1000,1000,213,1000,838,-232,-1000,10,-757,-1000,-816,-793,-870,1000,8,781,1000,-515,638,-1000,-1000,12,-206,-1000,1000,1000,-1000,-785,-1000,-723,-1000,1000,1000,63,1000,-1000,-704,962,-78,449,464,349,-1000,-477,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00497() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "ensureCapacity(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-23,-355,271,-698,28,330,507,36,-206,-93,-690,-206,741,-23,232,-49,1000,-186,461,-331,13,75,208,1000,-1000,-1000,-1000,400,-937,-280,222,-569,703,577,-105,-309,242,149,-631,-125,233,739,-123,194,411,-1000,-120,195,-488,37,1000,-40,-166,316,234,-174,-154,259,-882,130,-83,39,-410,572}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00498() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "ensureCapacity(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{128,-951,757,-698,555,586,202,-689,516,279,-690,-586,776,-23,335,117,1000,-80,1000,-331,-112,257,-841,576,-667,-619,-436,400,962,655,-764,-871,487,928,-438,-318,-195,-630,-889,-386,-235,922,-273,275,411,142,-47,323,191,37,548,357,-245,177,184,-101,-241,-240,-1000,699,406,369,-696,541}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00499() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "ensureCapacity(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{457,-667,553,413,157,-689,-912,-734,-99,-881,-22,621,-65,-629,966,-29,-499,932,862,794,215,-551,-551,799,577,-972,-332,-233,408,528,218,532,-977,602,-347,-464,307,-894,-707,-32,-504,786,-197,992,424,259,-785,781,290,-800,284,-795,-422,-591,623,-157,-345,939,-179,734,-211,857,-97,767}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00500() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "ensureCapacity(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{269,-1000,496,-387,-1000,-886,81,-439,-323,441,-1000,-822,-852,-918,-632,226,9,-1000,-346,856,-224,1000,475,115,1000,-814,1000,-1000,-318,-520,-834,-1000,547,359,-3,1000,253,-1000,-1000,-67,-678,-353,-828,775,1000,-121,-71,221,1000,-1000,317,1000,-248,898,-342,782,-57,-1000,88,178,-894,-628,938,-570}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00501() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "equals(java.lang.Object):boolean",
            new int[]{-400,-1000,842,366,-626,-837,-164,-614,741,510,-688,1000,562,-631,-1000,139,1000,-493,574,-13,1000,495,508,-559,-810,-50,-512,-716,-1000,1000,374,298,-62,-740,-247,1000,-113,-573,21,-121,1000,280,-468,-807,-365,1000,437,-221,-519,4,-1000,-31,-312,507,-131,390,333,1000,-162,-793,590,-623,-1000,-901}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00502() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "equals(java.lang.Object):boolean",
            new int[]{504,216,-351,377,-765,-1000,208,476,-34,-644,-171,797,1000,-936,327,-381,213,214,980,1000,-920,127,-579,968,54,-1000,-647,-73,835,317,1000,-419,1000,-736,-1000,640,273,-381,995,1000,-293,760,652,1000,209,442,1000,-1000,-1000,-192,740,713,-946,485,1000,-601,-106,274,-267,-601,1000,-1000,-228,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00503() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "equals(java.lang.Object):boolean",
            new int[]{-811,-1000,444,-129,-775,1000,-186,-572,421,-440,1000,1000,364,7,1000,795,-1000,-364,587,-222,-1000,-1000,-1000,1000,-559,-552,1000,-1000,1000,-1000,730,-530,-45,740,-375,1000,-801,-200,-1000,-980,-815,-1000,1000,1000,-39,-1000,-388,520,899,8,1000,159,1000,-198,-379,128,-1000,-1000,-842,640,83,1000,400,410}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00504() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "equals(java.lang.Object):boolean",
            new int[]{-1000,1000,-1000,439,-107,-1000,1000,-426,285,1000,-1000,1000,51,-570,-1000,-810,-725,-761,-194,-993,1000,43,1000,-1000,-116,530,-190,-41,-1000,1000,538,755,568,-1000,349,-2,-850,-950,895,1000,1000,1000,-275,728,-907,712,-1000,-613,-273,1000,853,-19,176,1000,-324,-1000,1000,1000,721,12,13,904,-1000,349}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00505() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "equals(java.lang.Object):boolean",
            new int[]{28,-1000,1000,1000,-1000,-518,-762,-148,361,-421,-343,315,780,-1000,-775,644,770,-1000,815,856,793,403,-85,239,-370,-1000,-404,-117,-417,1000,1000,1000,568,-489,-1000,752,402,-987,-294,235,865,210,-452,8,-318,1000,388,-157,-1000,-487,321,-285,124,-365,649,-199,247,783,-570,-467,1000,-399,-1000,-163}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00506() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "equals(java.lang.Object):boolean",
            new int[]{-1000,761,-1000,-174,442,-558,954,361,313,901,-728,-1000,311,-367,-740,-800,797,-165,-508,-849,1000,-103,1000,-913,-555,1000,225,-324,-1000,1000,268,-189,-885,-1000,1000,475,17,-549,837,185,459,1000,284,468,-384,-62,-1000,-35,245,716,-1000,-378,209,1000,-914,-864,921,331,396,-165,-289,826,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00507() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "equals(java.lang.Object):boolean",
            new int[]{-683,842,-381,433,688,-204,369,-480,83,246,-64,-1000,19,-721,34,-586,-405,92,-541,-671,-1000,-719,-1000,-335,256,2,1000,-276,844,727,279,56,-57,-866,1000,-632,-113,87,895,-448,938,-760,677,1000,-20,-759,-359,731,349,497,-218,-844,252,704,-912,390,575,-1000,253,350,-363,1000,264,-240}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00508() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "equals(java.lang.Object):boolean",
            new int[]{1000,977,400,452,627,228,-979,864,120,646,-336,54,1000,-571,1000,157,282,681,1000,1000,818,1000,-1000,884,721,-1000,-457,1000,-727,727,1000,298,213,598,12,457,1000,-925,6,1000,-951,-805,22,925,1000,549,-334,365,-1000,-1000,-339,1000,-446,-1000,1000,857,-412,68,-1000,-601,635,-1000,320,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00509() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "equals(org.apache.commons.lang.text.StrBuilder):boolean",
            new int[]{-396,-1000,-1000,-428,1000,1000,114,-343,24,659,739,20,1000,866,1000,121,-124,-190,593,-18,102,228,786,-436,-1000,-1000,-917,-1000,586,-1000,-962,-756,-837,36,115,-602,468,708,622,-485,-42,3,817,83,1000,-1000,-232,1000,-901,-367,-635,-301,-1000,-1000,-1000,-219,-85,778,1000,1000,1000,151,-212,268}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00510() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "equals(org.apache.commons.lang.text.StrBuilder):boolean",
            new int[]{791,143,1000,151,25,-1000,-647,-613,732,95,-269,80,-531,150,-902,118,908,-534,-724,1000,-1000,-866,-344,-549,798,1000,538,704,406,452,99,1000,-150,-15,-612,1000,-491,611,-658,71,1000,258,67,336,-749,1000,241,229,277,11,-347,970,658,287,445,-1000,-635,-854,-341,-319,-963,-994,782,-802}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00511() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "equals(org.apache.commons.lang.text.StrBuilder):boolean",
            new int[]{1000,-1000,-772,1000,809,1000,-977,-366,-34,22,399,-18,8,-288,342,34,-636,572,-800,612,-1000,-782,961,-1000,-756,-719,-1000,395,746,-1000,-1000,-365,-1000,553,1000,1000,1000,104,435,667,22,536,507,161,1000,167,-872,725,369,38,-682,-28,-1000,-649,-1000,302,499,959,548,1000,-519,-1000,930,286}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00512() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "equals(org.apache.commons.lang.text.StrBuilder):boolean",
            new int[]{-427,-403,-599,-324,634,596,-951,-549,-540,439,-605,-339,-24,-99,726,-726,-420,165,246,273,-141,278,-511,-132,-739,71,388,-924,123,-991,-357,-183,355,274,-342,-843,634,673,-299,931,530,167,268,1000,-9,-1000,598,948,-1000,296,-462,-124,-302,-775,-61,-339,17,205,747,-22,449,-355,972,-245}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00513() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "equals(org.apache.commons.lang.text.StrBuilder):boolean",
            new int[]{425,-265,996,188,112,334,429,-6,-158,-188,219,-131,693,-593,-1000,818,330,-178,295,377,-220,-323,347,63,876,-671,243,684,612,-368,-100,231,-1000,180,-1000,526,574,269,982,-823,-444,334,163,-1000,94,1000,-1000,713,786,285,34,959,-1000,821,-781,-599,-775,-665,626,461,377,271,-1000,526}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00514() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "equals(org.apache.commons.lang.text.StrBuilder):boolean",
            new int[]{506,-1000,992,-1000,180,-12,-829,-641,181,52,518,108,1000,-390,-325,-521,304,-542,533,866,-447,-808,-1000,351,984,-219,712,-294,760,-1000,205,772,-957,36,-274,95,-273,1000,-611,543,-116,759,-734,-506,-194,-1000,262,985,129,211,138,1000,-884,-809,-279,-971,-1,371,948,675,150,118,-435,-482}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00515() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "equals(org.apache.commons.lang.text.StrBuilder):boolean",
            new int[]{950,-484,466,30,516,93,-294,-545,865,88,267,405,781,584,-520,141,-48,630,-687,1000,-881,-982,782,-1000,638,-382,-496,409,614,-910,127,-125,-1000,53,-1000,1000,122,448,586,-464,330,79,67,-780,562,1000,-928,96,977,-12,-277,793,-742,41,-733,-291,-248,16,-284,1000,-292,-753,-859,-274}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00516() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "equals(org.apache.commons.lang.text.StrBuilder):boolean",
            new int[]{-352,-1000,194,-354,33,1000,-1000,-414,-77,1000,1000,-634,-1000,-155,627,13,1000,615,-658,-700,190,299,353,545,-1000,15,-67,-950,284,-619,-480,-1000,-38,-739,-276,-1000,1000,-748,725,-605,-246,-211,-1000,884,-1000,1000,-485,168,-1000,-434,-713,-76,364,-120,535,-241,578,443,-91,-846,-944,-503,-387,-553}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00517() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "equalsIgnoreCase(org.apache.commons.lang.text.StrBuilder):boolean",
            new int[]{1000,-639,-231,943,909,421,-230,22,882,635,-882,68,-808,240,1000,-46,-688,1000,256,727,536,-196,1000,1000,-543,738,-501,-690,-223,-306,-326,171,-455,1000,-809,-444,-207,1000,-2,37,219,-769,-1000,527,-147,-395,-42,305,-531,134,-303,182,983,-162,-598,41,499,205,-274,-116,909,450,-564,-473}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00518() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "equalsIgnoreCase(org.apache.commons.lang.text.StrBuilder):boolean",
            new int[]{-400,-136,412,-70,119,-726,-496,-866,-422,280,-467,61,913,132,-1000,-238,212,-255,397,-1,-350,-793,-991,-479,522,-906,-442,46,576,738,1000,-882,643,-779,1000,11,395,-1000,50,-506,-96,796,1000,-1000,257,-414,-542,-1000,1000,806,569,173,428,-117,904,356,613,-862,-246,874,-1000,20,93,83}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00519() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "equalsIgnoreCase(org.apache.commons.lang.text.StrBuilder):boolean",
            new int[]{707,54,724,-616,33,-1000,-460,-1000,-828,491,-818,236,149,176,717,1000,-630,551,299,1000,148,190,848,1000,-229,313,-419,-501,1000,83,-702,-162,704,45,-362,-358,-195,1000,-660,542,1000,1000,-835,-524,804,-598,-375,-438,355,181,218,875,-477,-1000,-128,859,-33,77,-602,489,-18,-349,-516,-329}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00520() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "equalsIgnoreCase(org.apache.commons.lang.text.StrBuilder):boolean",
            new int[]{-1000,119,744,-774,513,244,-315,-1000,-1000,334,1000,465,987,460,1000,1000,-585,52,-1000,1000,381,796,-773,1000,814,1000,975,396,792,1000,-649,-740,-166,-760,678,11,1000,-94,-1000,-607,1000,1000,-1000,-240,516,-729,-567,-396,1000,317,990,96,91,-1000,-1000,708,-1000,-812,1000,1000,-675,-1000,1000,456}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00521() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "equalsIgnoreCase(org.apache.commons.lang.text.StrBuilder):boolean",
            new int[]{-650,974,1000,695,-136,698,664,282,316,427,-633,-139,54,-362,748,-1,-257,202,-351,739,735,-298,1000,16,-985,1000,-822,-323,-1000,-529,-356,401,-1000,1000,-1000,187,35,1000,-310,1000,278,-1000,-1000,850,-285,-1000,369,-270,-319,505,-958,-189,-329,497,-934,-1000,1000,1000,629,257,1000,-609,853,-479}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00522() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "equalsIgnoreCase(org.apache.commons.lang.text.StrBuilder):boolean",
            new int[]{-517,699,138,794,192,290,56,-729,-317,-244,-540,-100,422,-381,-37,-128,-1000,-212,185,209,748,-437,-219,743,-1000,-474,-368,576,-622,-60,531,132,-214,-199,-524,469,-278,-46,-457,1000,-261,231,123,-827,285,488,-383,-926,1000,551,757,-580,-1000,7,-853,1000,583,511,-28,867,-410,-515,-212,458}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00523() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "equalsIgnoreCase(org.apache.commons.lang.text.StrBuilder):boolean",
            new int[]{1000,-1000,-736,110,1000,722,-1000,-939,1000,171,-642,-1000,-1000,427,-1000,136,661,-254,-277,508,-841,-820,-240,-805,757,-1000,-487,-882,185,353,1000,-786,-453,-1000,737,-1000,-1000,-358,1000,-1000,-1000,-268,-1000,209,-866,1000,-729,1000,-622,343,-137,1000,1000,-1000,1000,1000,648,-166,-696,-1000,-418,-147,-1000,586}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00524() {
        org.junit.Assert.assertEquals("ARRAY:[C:1:24:java.lang.Character:Aw==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getChars(char[]):char[]",
            new int[]{-66,-1000,235,668,-487,-768,183,-35,-78,1000,814,225,517,3,488,-371,-214,-553,909,645,571,275,810,235,178,-1000,-216,144,187,1000,-797,-169,1000,506,-393,-140,-696,248,208,-159,-1000,460,71,57,813,1000,548,-981,-833,801,933,-50,985,296,-467,858,-970,619,1000,-243,1000,-262,992,862}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00525() {
        org.junit.Assert.assertEquals("ARRAY:[C:1:24:java.lang.Character:aQ==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getChars(char[]):char[]",
            new int[]{-1000,246,-671,614,-3,-1000,303,-1000,80,71,-115,1000,-44,-533,-389,893,-323,-23,-362,855,35,667,-1000,-452,-798,-1000,367,-219,-561,273,-77,75,1000,85,216,-698,-551,54,-977,1000,-950,491,508,-14,995,1000,1000,130,-431,-1000,390,749,134,-179,-207,-115,743,-1000,375,1000,153,840,292,17}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00526() {
        org.junit.Assert.assertEquals("ARRAY:[C:45:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getChars(char[]):char[]",
            new int[]{484,-701,864,-507,938,-683,454,730,-776,1000,-1000,454,-400,-452,836,1000,-785,955,66,-431,-1000,-142,243,-780,1000,1000,94,980,343,-98,-191,87,-584,1000,622,765,-65,-484,1000,-713,1000,-721,557,-1000,-1000,-354,-85,-681,1000,-1000,-1000,-622,643,-213,461,-702,-334,154,-772,768,-856,591,-127,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00527() {
        org.junit.Assert.assertEquals("ARRAY:[C:1:24:java.lang.Character:eA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getChars(char[]):char[]",
            new int[]{854,-1000,-531,-534,-225,-1000,854,872,-595,1000,-123,286,85,-93,1000,1000,-429,-524,474,-8,-815,-312,667,-97,111,1000,-549,1000,1000,-1000,-1000,734,-1000,155,-149,899,-846,1000,1000,-1000,597,274,-306,-1000,-952,585,-1000,77,43,-1000,-951,-534,721,301,489,735,184,-586,1000,-796,-819,748,-604,-942}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00528() {
        org.junit.Assert.assertEquals("ARRAY:[C:3:24:java.lang.Character:CA==:24:java.lang.Character:Mg==:24:java.lang.Character:Fg==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getChars(char[]):char[]",
            new int[]{-46,-1000,340,426,-414,-666,82,290,273,937,544,312,517,109,144,92,-15,-393,375,520,434,278,514,-748,171,-509,321,265,1000,-210,-711,17,412,643,-194,590,-391,386,955,-442,1000,460,-841,-133,1000,1000,-372,-736,-816,-357,917,794,554,39,-68,858,-1000,-403,61,-878,269,-26,583,688}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00529() {
        org.junit.Assert.assertEquals("ARRAY:[C:3:24:java.lang.Character:IA==:24:java.lang.Character:GA==:24:java.lang.Character:aA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getChars(char[]):char[]",
            new int[]{731,-574,626,1000,1000,-616,104,-38,-307,800,-966,256,888,-322,376,994,-1000,505,118,349,-177,832,-247,654,240,-915,543,542,-1000,1000,-612,1000,-35,1000,-923,1000,229,526,-727,21,280,67,-686,-1000,-896,-328,378,-645,-1,612,1000,-603,763,-74,923,-132,81,609,73,265,-128,-727,248,-150}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00530() {
        org.junit.Assert.assertEquals("ARRAY:[C:4:24:java.lang.Character:Qw==:24:java.lang.Character:dA==:24:java.lang.Character:aA==:24:java.lang.Character:XQ==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getChars(char[]):char[]",
            new int[]{258,-1000,848,-387,-414,-666,82,1000,-384,1000,544,70,-298,109,144,106,-63,538,620,-356,-829,-524,1000,-675,227,400,-133,968,1000,231,-484,-807,-109,506,418,-71,-42,-717,1000,-1000,400,-409,628,-224,67,534,-212,-844,553,-599,-346,214,735,-137,-250,-108,-1000,27,-240,-405,-299,633,203,-480}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00531() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getChars(int,int,char[],int):void",
            new int[]{-203,-1000,-646,-675,613,-227,362,365,95,1000,-409,-129,-377,806,886,-1000,441,683,-462,600,-836,-18,-1000,-236,932,-482,269,-699,341,57,-996,-495,-255,1000,-657,752,1000,-263,-909,469,-899,-835,-12,-230,-669,659,-206,170,746,586,-83,758,-294,-1000,-345,304,124,-623,450,36,-527,671,-427,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00532() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getChars(int,int,char[],int):void",
            new int[]{1000,846,9,-903,102,-526,-461,-809,1000,-393,-908,-2,72,368,-959,-977,-745,-188,289,0,137,27,52,663,-816,-32,-375,1000,835,-550,818,1000,-312,-464,1000,138,-145,265,-89,837,-1000,-193,-257,608,-481,421,-914,-1000,-64,432,523,-134,-718,385,-980,-385,1000,-137,-983,-989,416,-590,-394,-190}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00533() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getChars(int,int,char[],int):void",
            new int[]{-812,835,-1000,-835,174,-753,-340,649,352,-471,-1000,504,-356,-615,-869,158,686,1000,636,519,-279,2,-688,304,-64,-1000,-1000,-229,1000,-145,-707,-1000,231,-107,-81,652,-768,-957,467,576,-103,-798,-585,-74,-1000,259,-1000,-147,551,1000,325,1000,-925,-304,-968,772,-816,-244,288,96,-117,1000,-832,738}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00534() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getChars(int,int,char[],int):void",
            new int[]{-838,180,-597,685,521,-479,-507,13,464,-1000,-1000,-833,-852,947,-743,158,-24,799,-399,-294,-59,-228,245,-271,120,315,1000,-138,1000,-389,154,-997,-654,-318,-624,248,-981,525,-741,1000,-458,-968,127,442,207,-31,276,-272,-347,-918,-165,776,-748,-1000,-1000,343,849,235,-194,-241,-552,632,-642,-148}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00535() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getChars(int,int,char[],int):void",
            new int[]{190,-1000,-1000,-1000,-1000,604,-183,-3,-250,-203,-166,400,-858,646,317,417,-94,-113,392,-1000,419,5,280,-835,-452,-346,214,-1000,1000,1000,9,210,-333,1000,-69,-1000,-393,-941,-859,-161,743,-43,1000,-177,1000,146,1000,481,318,-464,-1000,-1000,280,-880,768,281,-1000,-1000,437,866,1000,-755,580,-725}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00536() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getChars(int,int,char[],int):void",
            new int[]{-1000,-1000,-420,-1000,-1000,404,807,-426,-495,-29,-1000,-501,486,1000,1000,-65,-692,639,-803,-992,570,-937,452,-951,-970,1000,1000,118,275,-35,1000,414,-808,450,324,-1000,-558,-36,-1000,-659,257,-222,926,544,691,420,1000,493,-359,-780,-263,723,812,-1000,-1000,-774,1000,-668,-453,-505,929,-1000,331,-530}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00537() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getChars(int,int,char[],int):void",
            new int[]{401,689,-639,-310,-1000,639,-324,-723,-50,-542,821,79,-143,-275,275,863,61,-439,1000,-418,251,-109,-688,443,1000,-280,77,1000,-1000,-343,457,1000,-356,488,-517,-400,-1000,1000,-637,821,8,-1000,-450,-46,-161,1000,56,-124,-1000,-948,206,698,859,-1000,-910,958,-139,-1000,362,1000,713,-1000,290,738}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00538() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getChars(int,int,char[],int):void",
            new int[]{-442,-1000,-752,-811,103,-7,-281,-999,1000,431,-586,-99,-803,1000,123,-176,-157,778,-629,-518,519,-565,230,174,-457,529,1000,-295,58,-153,-443,-647,-126,165,-262,-904,-697,-256,-1000,1000,-432,-884,1000,743,-440,175,820,-646,645,-724,-1000,770,55,-925,-20,281,920,-674,-873,77,812,-655,-192,-973}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00539() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getChars(int,int,char[],int):void",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00540() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getNewLineText():java.lang.String",
            new int[]{-1000,-817,-1000,-81,51,1000,-596,-738,271,539,976,284,-818,-1000,-1000,-924,-261,982,-862,1000,-1000,-653,-523,-1000,-592,-1000,254,647,-935,1000,316,-865,-1000,910,306,1000,-1000,1000,240,-1000,226,-690,-44,344,-1000,-1000,-567,-1000,-1000,-1000,30,-1000,-1000,684,-193,1000,73,-239,541,-958,57,-179,1000,338}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00541() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getNewLineText():java.lang.String",
            new int[]{-1000,772,1000,-799,-672,42,729,609,-939,447,-246,-377,409,-564,43,1000,-28,-947,-240,-188,-945,-1000,-1000,-703,1000,-181,-542,-964,407,-223,-1000,-1000,475,351,-301,-753,-179,-189,-1000,-649,440,-416,-1000,-1000,761,1000,-105,1000,-686,815,-1000,1000,1000,400,-379,-1000,-443,-521,-2,811,584,-663,-1000,645}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00542() {
        org.junit.Assert.assertEquals("java.lang.String:KzB4ODAwMDAwMDAwMDAwMDAwMDAw", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getNewLineText():java.lang.String",
            new int[]{-1000,378,-191,1000,227,1000,768,863,1000,853,-662,997,-924,-1000,-1000,626,542,-686,308,48,-1000,-148,1000,-708,-28,-1000,-867,1000,-399,1000,-455,1000,-1000,263,591,-1000,456,117,-185,518,298,434,-204,-1000,-894,-630,1000,1000,-1000,-1000,410,1000,-946,592,-108,116,911,-539,-631,168,-557,-1000,163,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00543() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getNewLineText():java.lang.String",
            new int[]{-1000,-775,-336,657,-173,449,-528,233,-302,820,-606,47,-113,-15,1000,-309,92,902,-13,-698,34,-576,1000,610,-596,833,-482,765,-597,897,-251,84,-884,-962,-876,119,-500,1000,1000,655,-658,-980,-891,-1000,-1000,414,-364,828,1000,134,30,-191,-55,-865,-892,-6,158,-485,390,-794,-473,-185,155,29}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00544() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getNewLineText():java.lang.String",
            new int[]{-1000,-118,-145,1000,462,1000,104,-366,1000,434,534,-38,-1000,-861,-944,-1000,354,649,1000,-1000,-930,896,1000,-1000,-409,-693,-890,1000,-63,1000,-108,1000,-1000,-548,-597,-1000,-486,300,271,376,-150,-142,-122,-953,-1000,-1000,-272,-399,-530,-1000,1000,114,-1000,271,309,170,364,416,-810,-581,-1000,-363,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00545() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getNewLineText():java.lang.String",
            new int[]{-1000,-109,716,-81,51,-456,-756,-853,-1000,24,976,-825,-1000,-525,827,1000,-261,982,-540,1000,400,-1000,-523,-1000,-679,-1000,-993,-796,190,-348,-1000,-865,946,-788,-916,1000,-405,801,-190,-809,-197,-1000,-692,-1000,-863,901,-1000,301,-56,858,30,-233,527,-515,-362,-236,-475,-1000,541,-807,694,538,-709,-155}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00546() {
        org.junit.Assert.assertEquals("java.lang.String:ICsxMDAwIA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getNullText():java.lang.String",
            new int[]{-159,665,-275,915,1000,267,-1000,972,-1000,-732,-1000,-282,371,434,-716,436,-1000,-1000,-500,-3,-132,-56,1000,-486,1000,-238,400,361,-34,555,-228,-125,724,26,-1000,-906,877,-762,37,1000,1000,-1000,390,-1000,1000,123,1000,1000,50,-937,-235,1000,717,452,-1000,-358,1000,-1000,910,-527,-224,1000,384,-546}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00547() {
        org.junit.Assert.assertEquals("java.lang.String:LTYzNA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getNullText():java.lang.String",
            new int[]{141,-537,239,-856,563,-634,523,141,215,578,-183,-827,-507,934,-28,884,302,655,-805,116,-695,728,741,-626,333,-65,44,-303,1000,549,182,410,-447,453,-80,-748,343,-571,192,-484,-90,-614,-1000,-479,-24,643,-1000,65,-319,134,-437,-126,989,1000,-990,122,-690,-253,-253,-817,1000,739,959,964}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00548() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getNullText():java.lang.String",
            new int[]{704,-667,-458,-904,416,136,-451,-973,-1000,-253,1000,-808,-1000,632,96,319,704,-135,-189,549,-669,-430,1000,-977,-266,0,93,-661,-167,151,-164,-137,262,857,676,-397,-517,-18,262,-63,585,-714,-1000,-761,-58,-168,-783,-75,194,-1000,274,-180,12,1000,-372,427,437,-348,-379,-455,585,400,-454,573}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00549() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getNullText():java.lang.String",
            new int[]{377,-1000,-431,-1000,869,-832,941,98,-828,-1000,329,172,-474,785,1000,1000,914,1000,-666,213,-951,83,862,-648,161,680,477,-103,336,-655,-899,571,-1000,66,667,-1000,461,-1000,406,15,67,184,-1000,990,-747,1000,-561,262,-100,22,-936,464,-93,935,-446,-1000,-657,969,-986,423,767,181,872,892}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00550() {
        org.junit.Assert.assertEquals("java.lang.String:TWNC", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getNullText():java.lang.String",
            new int[]{171,685,50,-19,732,729,-514,59,-311,-672,-449,-698,-531,717,-149,402,-72,-184,-588,671,-307,-1000,1000,-1000,770,153,308,-252,816,645,-246,159,457,811,-173,-780,-437,578,-434,-49,905,-785,-27,-1000,455,244,248,336,-476,-599,-503,687,444,585,-678,-371,675,-821,-201,-162,331,245,-95,407}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00551() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getNullText():java.lang.String",
            new int[]{624,35,50,-484,490,654,-736,220,-1000,-542,34,-305,-358,1000,-1000,199,-448,-1000,-104,-153,-334,204,1000,-636,791,-386,244,292,29,999,-814,-442,1000,322,-22,-331,195,-153,976,289,1000,-1000,-27,-1000,1000,-781,481,1000,-335,-1000,66,1000,579,1000,-506,1000,1000,-1000,398,-439,-272,1000,-730,79}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00552() {
        org.junit.Assert.assertEquals("java.lang.String:IA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getNullText():java.lang.String",
            new int[]{-180,140,-741,-609,1000,-385,59,-116,-745,-134,-391,-279,-634,662,-881,799,290,670,-1000,-113,-727,697,1000,-193,345,1000,398,100,-244,228,1000,334,754,-560,750,-829,1000,-660,130,539,468,-1000,-1000,-948,-225,773,-396,632,32,187,-229,386,526,787,-916,-242,1000,-774,-251,1000,327,347,1000,278}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00553() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getNullText():java.lang.String",
            new int[]{-423,-580,176,-18,563,-631,298,-1000,400,592,351,22,-1000,-129,770,-614,457,1000,-381,1000,303,774,534,-1000,-706,900,-1000,-1000,439,-494,-407,972,580,1000,122,-868,-283,-802,-1000,-892,-186,-799,-980,-258,-922,1000,-1000,-427,221,151,362,74,-530,115,-920,-1000,-7,1000,609,-1000,1000,-680,-710,256}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00554() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(char):int",
            new int[]{435,-322,-57,-311,-911,-441,-748,904,1000,-52,87,-1000,-1000,-164,-631,-179,-280,924,-836,-1000,726,-128,-1000,444,840,-766,427,47,1000,165,1000,791,-231,1000,1000,182,-324,-327,-1000,1000,342,-900,1000,-681,782,-112,637,192,1000,1000,711,108,1000,-341,-450,-1000,513,370,-572,-215,1000,-1000,1000,-407}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00555() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(char):int",
            new int[]{-199,-490,364,-466,995,-1000,884,102,370,647,-1000,-833,199,477,-64,-908,-835,1000,-643,225,170,1000,1000,561,1000,1000,-1000,-1000,49,119,1000,-1000,821,771,497,1000,397,542,-659,536,-574,628,525,560,-856,-711,1000,-295,-949,742,237,164,-30,740,13,-1000,-103,-1000,145,224,788,-342,357,-407}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00556() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(char):int",
            new int[]{733,-542,269,1000,-801,-463,1000,-41,501,100,-1000,-1000,195,39,-448,55,-282,-892,194,27,-186,-73,638,-276,-505,-380,286,499,-861,566,-21,-717,582,426,276,-264,544,-274,404,-312,-411,-420,-95,-581,-654,21,51,-257,-582,-510,-1000,8,-59,-285,467,-538,-373,-1000,394,1000,130,-288,-574,-936}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00557() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(char):int",
            new int[]{216,-423,19,604,-468,-593,98,1000,129,679,158,-710,716,-340,-257,-661,-884,-336,-218,86,-373,-599,538,-500,261,428,-974,946,-787,868,-176,-2,-294,353,331,-633,-959,-798,-1000,89,313,210,-212,-785,-245,-165,-23,-189,585,15,261,186,-142,-285,15,-761,-167,-580,226,237,-47,207,101,-941}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00558() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(char):int",
            new int[]{128,173,1000,962,-785,-226,669,-89,-428,271,-1000,363,-61,380,-257,-661,837,-793,208,881,-313,277,-87,-616,-738,-844,811,946,-1000,506,380,683,67,453,-934,-1000,39,35,1000,-324,-595,-636,-543,-540,-1000,593,-23,-239,436,-813,-943,186,-710,-285,-38,635,1000,-222,1000,-336,64,-925,-1000,-760}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00559() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(char):int",
            new int[]{-526,-79,728,-317,994,-418,-946,832,458,726,27,-585,-468,39,493,210,-835,912,-67,899,378,566,942,253,577,789,-963,-316,-939,433,943,-448,677,771,-316,692,159,518,-694,536,-411,-134,-138,-139,-357,257,417,745,-227,742,237,604,-625,801,108,-659,-924,-755,754,561,788,-531,-284,-407}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00560() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(char):int",
            new int[]{394,-880,288,138,-1000,-567,392,627,606,463,-489,-1000,-383,-349,-975,361,-713,-1000,-603,124,332,-773,-403,-160,-51,-365,982,-186,536,658,1000,732,-301,786,296,-956,-9,-408,903,730,20,-821,-544,-1000,-895,-147,84,-906,635,116,400,147,338,-206,-556,46,1000,205,-80,-208,551,79,988,-956}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00561() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(char,int):int",
            new int[]{176,308,-267,-4,-142,-352,457,-443,735,-469,154,607,-97,-50,-473,701,375,-1000,284,-361,756,-570,-279,84,347,-297,-153,-378,-676,-599,-1000,-225,-198,-729,-422,224,291,-642,193,213,319,-246,-1000,108,-729,-188,-1000,507,504,1000,43,-1000,969,-168,810,-258,572,-490,-230,-8,7,-147,402,-350}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00562() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(char,int):int",
            new int[]{1000,-612,-726,-383,-1000,275,-278,-556,-1000,-464,-179,-834,190,1000,843,-873,357,-1000,1000,-337,-237,-190,-838,-241,984,546,-868,-1000,-819,1000,366,1000,1000,696,1000,375,-928,-61,406,-333,-762,-280,-759,-987,995,1000,757,-594,533,-374,-983,-1000,373,188,-1000,-970,-58,-1000,683,794,1000,894,975,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00563() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(char,int):int",
            new int[]{1000,1000,-921,-51,638,366,-1000,753,1000,-928,-374,-377,-941,608,-302,-382,107,-70,513,-435,63,-1000,-629,525,575,-595,527,1000,-895,-1000,-1000,874,1000,684,916,-1000,-299,-724,592,580,-202,-703,-1000,295,44,-191,-800,1000,53,-299,-1000,-442,552,470,189,-634,-986,-853,839,899,-69,-368,-691,452}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00564() {
        org.junit.Assert.assertEquals("java.lang.Integer:Ng==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(char,int):int",
            new int[]{793,287,61,828,162,519,-1000,334,122,-1000,-211,-101,-469,874,273,-1000,-1000,-1000,1000,435,-768,353,44,232,1000,-451,-626,-303,-1000,1000,-401,357,678,-393,234,-78,-1000,1000,248,-222,-1000,-751,-525,-824,-938,638,-2,-546,-388,286,-630,-1000,-267,1000,-769,-134,673,-1000,621,1000,1000,1000,545,-19}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00565() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(char,int):int",
            new int[]{1000,44,-1000,163,311,14,287,156,284,691,-795,-903,-75,-35,-539,-405,1000,-509,866,976,-100,-724,-659,125,-563,331,-555,-215,-397,-403,-22,1000,-1000,539,935,1000,-149,-1000,-988,-294,-616,-1000,750,1000,236,337,-1000,1000,232,-588,-1000,-354,318,403,-650,987,-442,-487,814,-493,-1000,-72,461,314}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00566() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(char,int):int",
            new int[]{1000,-433,353,-954,-84,-241,876,341,499,-857,-193,-474,-1000,317,-215,-413,-117,-427,248,926,562,-397,-559,-392,364,-662,400,-666,-554,1000,-919,-5,-1000,-447,314,-1000,-971,381,-1000,306,-517,-699,-67,-1000,1000,239,-1000,567,-578,83,-491,-985,588,217,-562,1000,643,-812,178,-46,956,1000,964,-106}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00567() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(char,int):int",
            new int[]{1000,869,-592,266,43,754,584,1000,-363,-1000,509,-805,-199,1000,-1000,-474,107,234,592,1000,1000,-1000,-828,-783,1000,23,-1000,181,-1000,-554,842,759,366,-241,1000,-1000,-1000,-338,632,476,163,-720,-990,-1000,369,1000,-1000,1000,-50,1000,-1000,648,886,807,-195,-498,-438,-1000,793,831,1000,966,1000,530}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00568() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(java.lang.String):int",
            new int[]{-450,995,837,-421,-513,302,-491,-597,-556,663,-359,157,1000,-637,-811,438,-1000,-390,-697,826,1000,-1000,-42,604,580,484,-834,55,776,-835,-423,-1000,536,-829,-174,-1000,-1000,887,633,-148,1000,713,-1000,143,205,-1000,-719,846,-1000,369,586,176,-1000,501,1000,-1000,-1000,-665,351,668,842,919,1000,206}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00569() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(java.lang.String):int",
            new int[]{307,729,-811,1000,-327,965,-388,810,-786,246,524,-183,-632,337,-479,1000,34,37,1000,-85,274,-526,127,-74,-919,-631,-1000,26,-708,-644,1000,-1000,132,-173,-924,-1000,-902,-480,-175,-158,196,-612,-1000,-82,-44,537,-367,19,-1000,776,43,588,466,-650,1000,-128,-417,1000,550,334,409,-260,1000,354}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00570() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(java.lang.String):int",
            new int[]{531,-721,764,521,244,954,271,-839,3,874,764,290,-714,-951,-417,440,-989,-910,1000,1000,-46,162,-926,592,-27,-398,32,-659,859,-353,314,825,969,778,-444,-127,-785,-161,899,-1000,722,997,576,804,699,-542,-970,-78,171,-1000,-999,-768,452,192,393,-457,-1000,1000,-889,1000,731,-1000,138,-792}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00571() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(java.lang.String):int",
            new int[]{790,-736,1000,-966,244,935,306,-561,-144,591,251,1000,-754,-1000,-417,-1000,-1000,61,989,1000,-159,8,-1000,-120,389,-206,445,425,584,-401,278,639,1000,607,-444,279,-245,93,1000,-902,1000,273,676,-199,421,-494,716,-78,900,-1000,-1000,-568,58,192,42,-734,-1000,1000,-1000,1000,1000,-1000,168,-839}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00572() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(java.lang.String):int",
            new int[]{-448,-626,-998,1000,381,337,-320,258,-16,373,-432,-709,-613,-133,1000,-815,1000,-774,301,-529,-947,1000,1000,776,194,913,264,1000,-1000,-107,-1000,-286,536,1000,-155,970,254,-255,-512,-431,-721,1000,-1000,1000,-301,1000,257,958,-860,29,1000,1000,518,-417,520,-35,666,-997,-359,620,-550,1000,1000,-79}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00573() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(java.lang.String):int",
            new int[]{381,522,852,532,719,-287,-176,703,563,179,-200,-333,500,573,-644,354,34,959,-168,-981,-769,-615,-347,126,-544,158,-515,426,215,859,-655,-285,579,892,-969,-452,-809,713,504,560,432,-191,-740,2,-45,950,-891,-412,517,273,-712,-180,799,-638,399,577,-265,631,231,956,754,-937,238,91}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00574() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(java.lang.String):int",
            new int[]{179,1000,-1000,1000,-107,-168,-708,344,-809,355,1000,301,-948,337,-899,673,-245,-858,1000,777,-1000,353,-439,-270,-769,-1000,-1000,267,0,-815,1000,439,303,-803,-735,-525,-860,-1000,-175,-1000,-362,208,86,-573,653,525,372,-265,-117,-462,-607,-731,1000,-887,974,651,-604,1000,-662,-758,419,-1000,614,-9}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00575() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(java.lang.String):int",
            new int[]{898,-1000,1000,-1000,185,-421,-992,-553,248,679,-251,-158,866,-622,-480,117,-910,246,-142,1000,853,418,-415,237,246,-117,990,596,646,-279,-282,-1000,119,-725,-160,-203,49,1000,276,-148,1000,-1000,732,-320,985,-31,-54,214,91,-270,80,370,-1000,409,-259,-973,-8,-875,-1000,-376,60,185,498,-2}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00576() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(java.lang.String):int",
            new int[]{-349,-826,929,-1000,278,-431,-886,-1000,364,749,130,309,1000,-3,-637,467,-969,-606,111,1000,1000,-625,-489,1000,821,137,-124,-462,941,-302,-275,-718,381,-1000,-1000,-1000,-777,963,689,-520,662,821,309,560,544,-1000,5,482,-690,443,757,201,-377,177,800,-1000,-987,-1000,209,613,776,1000,244,626}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00577() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(java.lang.String):int",
            new int[]{343,-1000,992,-785,808,486,-604,709,435,272,-362,1000,-517,-256,1000,-1000,121,710,273,-60,1000,789,198,419,972,773,1000,669,-561,197,-1000,123,1000,1000,-305,1000,772,671,124,213,868,63,85,936,-555,1000,427,150,1000,29,-257,337,-273,-90,536,-532,666,-189,-1000,602,281,-118,-132,-426}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00578() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(java.lang.String,int):int",
            new int[]{-673,-949,187,-404,1000,-75,692,-17,222,451,-307,976,-347,-628,1000,-685,59,-463,-488,338,-816,154,-256,800,-644,-1000,1000,1000,-700,415,-10,-625,-511,301,89,-861,-400,173,-482,663,334,-505,-324,174,-253,-60,464,301,-721,-390,654,-32,-96,-938,-217,-404,-8,1000,-76,-483,-556,1000,-374,-400}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00579() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(java.lang.String,int):int",
            new int[]{448,-822,-106,-633,916,-684,-168,20,165,664,-361,766,309,-760,534,-649,867,-433,-1000,728,-654,-70,-961,326,-782,-598,1000,1000,741,629,173,-275,-866,928,129,-689,-732,554,-510,-718,-164,-949,573,142,362,-768,-171,1000,-800,-764,-438,-541,13,-1000,-487,-819,241,1000,-594,-563,-732,284,-445,425}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00580() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(java.lang.String,int):int",
            new int[]{-312,938,-1000,-428,755,-529,-64,431,-1000,-417,-66,850,-300,-237,742,-70,-35,-739,496,729,-645,-488,-549,-580,-465,1000,-219,163,-560,338,-96,357,-764,-651,-152,578,-93,577,-319,115,346,-661,-107,1000,-54,-623,248,-797,-1000,285,1000,-298,744,-1000,-48,936,82,-193,66,-107,640,4,-71,818}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00581() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(java.lang.String,int):int",
            new int[]{838,371,-261,-594,278,-16,27,596,-490,-242,-244,-299,1000,67,-75,-1000,609,35,-16,797,-283,78,708,384,-434,489,406,540,88,-142,131,741,-358,826,-284,253,-354,-858,-814,-606,222,-384,-216,546,-198,-424,-199,698,-1000,1000,-619,-176,-89,-137,209,-371,114,-156,516,-808,226,342,-176,494}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00582() {
        org.junit.Assert.assertEquals("java.lang.Integer:Mg==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(java.lang.String,int):int",
            new int[]{1000,959,-1000,-465,647,-233,450,1000,-1000,0,-1000,401,629,-1000,297,-705,583,70,1000,1000,-345,1000,960,-1000,-16,763,269,-270,1000,-897,376,783,1000,1000,1000,1000,361,-653,166,-973,817,1000,-669,273,1000,286,-273,1000,-768,645,-1000,-1000,-359,-1000,-146,-1000,-687,-1000,-162,-927,-1000,-579,181,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00583() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(java.lang.String,int):int",
            new int[]{257,-1000,89,-673,1000,-635,-296,-419,478,1000,-402,822,-400,-677,804,-803,1000,-506,-1000,296,-588,-404,-1000,342,-936,-1000,1000,1000,483,720,532,-879,-908,720,12,-1000,-882,-392,-31,-371,-220,-964,1000,-392,160,1000,67,1000,-295,-386,-269,514,-521,-960,-492,-608,-110,1000,-720,-571,-602,351,-833,398}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00584() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(java.lang.String,int):int",
            new int[]{1000,1000,-425,-879,613,-640,557,188,-521,-204,-30,-1000,-1000,-592,818,-107,-101,1000,-311,745,671,-648,-1000,-975,-139,42,-586,-272,-84,-1000,1000,-650,581,-943,-547,1000,87,145,442,324,1000,15,155,82,627,1000,-230,1000,-386,-400,566,-167,716,-1000,448,-977,219,-551,206,1000,1000,-472,580,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00585() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(java.lang.String,int):int",
            new int[]{610,-532,-198,-659,806,-901,-179,104,-361,516,-884,861,385,-831,360,-953,921,851,-575,119,-177,-404,-390,-85,-763,-867,825,909,472,16,711,-233,-321,576,12,-195,693,687,-871,-46,130,-953,676,-329,180,-918,185,858,-815,-53,-436,-697,-949,-859,-124,-570,-190,219,-890,-820,-735,761,-833,779}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00586() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(java.lang.String,int):int",
            new int[]{-195,182,786,-676,-1000,-1000,-958,-476,-798,-573,-884,-1000,848,12,-928,-1000,165,-400,-575,-437,379,-1000,-1000,1000,-856,-213,-1000,-974,-1000,-240,-160,127,-1000,-1000,-1000,-325,-1000,-1000,-1000,396,7,-1000,33,-329,180,-714,185,-1000,-1000,1000,1000,-697,-513,929,529,-570,93,219,-890,-200,1000,294,-733,20}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00587() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(java.lang.String,int):int",
            new int[]{365,413,-496,-632,1000,-452,74,49,-37,766,308,-1000,-671,-556,1000,-268,1000,37,-158,423,541,-951,-1000,-1000,-30,-727,-657,-543,-331,-1000,1000,-1000,607,-1000,-470,397,1000,1000,425,435,1000,249,-338,12,742,593,568,-1000,-520,811,971,-354,134,-1000,219,798,-560,-379,-830,1000,984,-570,256,432}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00588() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(java.lang.String,int):int",
            new int[]{-347,959,129,-317,-426,-996,-987,128,706,-15,171,-784,159,-460,102,-556,-300,-365,-282,20,-887,-1000,-1000,-181,-487,-531,-1000,-1000,-1000,-31,232,-248,184,-995,-46,16,-1000,-370,-577,-100,644,-937,-989,-330,-216,400,540,-1000,-708,1000,482,496,978,-214,-25,795,-398,-105,357,400,888,-73,-264,-152}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00589() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(org.apache.commons.lang.text.StrMatcher):int",
            new int[]{87,794,-1000,-63,1000,1000,-557,-599,1000,-1000,2,934,-42,-783,706,-462,-123,849,-218,-897,-554,1000,1000,389,-32,-685,-825,-1000,-260,-136,405,1000,-1000,160,-99,339,-159,-89,-572,-1000,1000,691,1000,82,-444,-652,592,47,1000,-414,-1000,156,-792,495,-148,-822,-290,209,1000,793,-1000,234,1000,730}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00590() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(org.apache.commons.lang.text.StrMatcher):int",
            new int[]{-409,-759,-986,535,408,621,-480,-491,749,285,-254,-245,-223,55,737,940,-484,323,912,805,750,939,-258,147,-276,-869,-730,-243,-275,322,896,396,-845,-323,370,189,-208,-709,-906,-877,-386,14,508,-275,-244,95,580,473,979,-944,-735,-5,-645,525,-873,-316,-207,86,311,22,-503,-341,-491,-410}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00591() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(org.apache.commons.lang.text.StrMatcher):int",
            new int[]{180,-493,-550,-393,497,48,-958,-420,72,-501,108,-46,-1000,-1000,1000,540,1000,472,62,-653,1000,917,708,922,243,641,948,251,798,227,1000,-613,-1000,-120,486,167,843,-1000,-770,-1000,743,890,1000,604,-538,87,800,258,1000,241,-1000,-314,-360,361,-425,-1000,-867,-735,1000,1000,-1000,-853,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00592() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(org.apache.commons.lang.text.StrMatcher):int",
            new int[]{-205,146,-865,907,537,837,411,705,449,-211,728,206,-662,-563,-383,-125,766,-430,-716,338,493,349,-54,818,-497,-200,371,-957,-181,771,-850,817,855,312,-223,761,99,-489,-237,-959,660,-97,671,273,-647,-226,241,303,826,-118,-429,10,-430,-551,-305,920,552,-380,845,-971,692,-987,192,936}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00593() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(org.apache.commons.lang.text.StrMatcher):int",
            new int[]{66,467,-740,1000,62,1000,-606,-265,693,-1000,62,488,86,-53,709,255,117,193,82,233,300,1000,406,310,378,-653,99,-839,392,141,137,302,-343,-1000,367,526,839,120,-183,-855,540,388,1000,108,-685,-697,103,-575,896,42,-554,-362,-203,-438,-513,-115,-337,-281,749,534,-795,-283,785,507}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00594() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(org.apache.commons.lang.text.StrMatcher):int",
            new int[]{-1000,1000,-389,-197,-188,87,1000,-265,79,5,-448,-1000,997,-461,737,-363,172,323,1000,-1000,-1000,-401,-258,350,-1000,-546,-1000,-397,883,266,-1000,-567,-156,-50,-623,605,1000,-729,-815,450,-386,14,367,-1000,912,12,-276,781,979,1000,839,-217,214,318,277,58,-47,678,-1000,-1000,771,862,1000,-492}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00595() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(org.apache.commons.lang.text.StrMatcher):int",
            new int[]{744,200,-1000,546,477,548,-926,289,704,847,-521,-811,1000,802,1000,938,276,-829,447,-378,35,8,174,356,93,734,-1000,-674,-599,559,1000,961,-1000,-200,-489,-527,385,-1000,-1000,-690,1000,-329,356,-23,-888,-22,1000,-79,121,699,-428,-512,-627,377,-139,617,11,66,187,-113,-98,410,405,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00596() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(org.apache.commons.lang.text.StrMatcher):int",
            new int[]{1000,-469,-784,1000,-50,607,-874,1000,515,-113,474,639,-520,-1000,-191,-1000,1000,39,-613,623,1000,-293,1000,619,1000,993,319,-641,-1000,548,1000,1000,-927,1000,547,-333,-1000,-468,-134,-1000,1000,834,907,1000,265,680,1000,-1000,811,-55,-1000,-189,1000,-1000,-362,-496,1000,363,1000,825,606,45,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00597() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(org.apache.commons.lang.text.StrMatcher,int):int",
            new int[]{79,191,660,-1000,682,254,-103,41,-469,806,526,-524,411,-98,220,-34,793,-1000,-228,940,1000,-1000,354,1000,67,-361,-363,-805,380,-1000,-455,571,1000,1000,1000,370,378,547,-1000,-481,-289,-426,-7,320,322,-691,66,-449,-1000,-275,387,710,-458,627,-428,-544,-421,-1000,464,920,536,677,-863,-256}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00598() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(org.apache.commons.lang.text.StrMatcher,int):int",
            new int[]{-1000,513,-131,-418,136,-621,421,351,768,145,419,206,-727,716,-108,-578,-265,-635,39,639,582,-717,-80,622,-72,-479,-508,-41,427,-199,-775,456,1000,637,893,991,265,-17,42,-808,-179,-606,-190,-199,91,-133,95,-34,-56,-845,162,-218,-1000,-118,262,436,-726,-122,-50,289,78,432,-777,-559}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00599() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(org.apache.commons.lang.text.StrMatcher,int):int",
            new int[]{-71,803,-382,-9,1000,674,-1000,424,-511,203,170,577,496,402,-624,-69,-340,793,568,-305,91,-1000,505,827,-302,175,-625,79,228,-712,-1000,669,1000,-124,874,227,-747,287,-1000,-1000,-852,-128,-418,161,631,-33,965,-925,48,922,-1000,-441,-1000,1000,-66,53,456,-863,-149,-71,-394,608,-871,564}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00600() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(org.apache.commons.lang.text.StrMatcher,int):int",
            new int[]{-26,-283,-373,-537,487,25,419,-157,-668,1000,643,19,815,-1000,214,-81,1000,813,-390,-915,461,-599,-48,35,-1000,-569,1000,-484,426,359,-169,887,1000,608,1000,61,1000,288,-750,-431,448,179,-123,911,175,-644,-1000,727,-691,-273,758,245,674,-160,-951,-328,603,-614,741,-644,499,489,-923,-856}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00601() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(org.apache.commons.lang.text.StrMatcher,int):int",
            new int[]{-344,-1000,-974,-212,7,254,492,-363,-353,1000,81,-524,1000,-1000,442,860,419,858,-256,-1000,951,257,-536,-172,-1000,-128,1000,-1000,829,527,-490,549,1000,961,1000,993,1000,547,-459,-27,733,443,84,1000,587,-276,-1000,206,-1000,178,468,710,-985,467,-1000,-1000,602,-510,1000,-278,935,405,-797,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00602() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(org.apache.commons.lang.text.StrMatcher,int):int",
            new int[]{146,-638,-77,-152,324,192,708,-566,-814,139,1000,-567,154,-15,-289,-590,1000,400,243,423,-1000,-605,-380,295,-451,-814,847,116,-90,-683,501,-618,383,40,740,-223,333,700,660,-369,743,-36,237,282,-243,-406,-280,427,91,-1000,975,8,193,-195,-953,265,-1000,-926,335,182,791,336,-643,-647}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00603() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(org.apache.commons.lang.text.StrMatcher,int):int",
            new int[]{613,-1000,480,847,184,-351,1000,-839,-481,789,718,-1000,327,-668,-419,541,-332,-400,593,-608,-1000,288,-1000,-498,61,-281,881,-737,-213,-113,747,-1000,175,186,53,387,93,-605,-463,-65,1000,1000,-1000,-465,1000,1000,-379,-416,1000,-85,1000,538,234,-440,-1000,10,-1000,-81,312,188,-752,219,1000,608}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00604() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(org.apache.commons.lang.text.StrMatcher,int):int",
            new int[]{-759,836,737,-739,634,324,-87,-136,475,140,-682,471,-221,139,-763,755,-551,-533,557,112,-594,-942,24,692,-187,-569,-647,-767,-4,-184,-950,-551,925,23,848,-783,-407,592,-857,-865,516,-216,-452,-838,703,-272,-278,-5,-102,661,22,-404,-291,-384,-801,856,-722,131,-652,-230,-410,596,640,692}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00605() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,boolean):org.apache.commons.lang.text.StrBuilder",
            new int[]{-183,-70,-1000,209,-681,331,-491,-1000,87,1000,-542,499,-972,-1000,1000,-64,574,197,-128,-225,1000,-35,1000,-1000,260,-338,468,-1000,836,130,52,-1000,-589,920,1000,-1000,-1000,1000,-1000,-802,-1000,-10,-1000,-837,-131,663,-844,489,644,-416,-1000,686,892,-500,-58,242,-900,629,1000,-1000,350,-861,510,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00606() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,boolean):org.apache.commons.lang.text.StrBuilder",
            new int[]{727,243,394,-94,685,84,659,-1000,585,277,-403,-55,351,-924,-28,800,466,809,163,-17,263,-353,-1000,1000,698,263,338,-836,485,871,-225,-23,-284,-292,112,131,423,0,-526,-275,-1000,-962,198,-672,-43,648,-845,-979,694,-1000,-929,1000,504,634,271,1000,-587,886,679,-371,737,-540,-986,-261}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00607() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,boolean):org.apache.commons.lang.text.StrBuilder",
            new int[]{-11,610,1000,-20,183,116,1000,1000,-693,-44,-90,565,663,-408,-1000,-605,-256,-17,211,1000,-788,172,-1000,1000,172,-676,-66,1000,1000,-2,769,1000,436,-610,426,913,339,-1000,1000,913,534,-387,1000,632,70,395,1000,-645,1000,375,-670,210,381,-1000,-1000,347,965,-704,-713,731,-885,39,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00608() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,boolean):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,32,-136,635,-270,225,-191,-769,-204,615,-123,371,-393,433,-474,-532,22,243,641,-558,-886,1000,657,548,665,-1000,627,571,86,-685,1000,839,279,-115,239,1000,687,-350,1000,1000,838,-2,966,-105,-220,38,189,-640,-61,450,-345,1000,238,328,-738,761,1000,-468,-1000,215,264,78,11,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00609() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,boolean):org.apache.commons.lang.text.StrBuilder",
            new int[]{366,287,-1000,444,-200,573,-507,-254,-596,716,-1000,548,-554,-1000,1000,-64,109,-737,501,220,1000,329,964,-944,161,-338,1000,-1000,1000,-20,178,902,-757,695,1000,-1000,470,1000,-1000,-1000,-1000,189,-1000,-411,-748,1000,-683,626,1000,-416,-1000,192,1000,-704,-58,-485,-934,332,1000,-1000,747,-1000,-325,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00610() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,boolean):org.apache.commons.lang.text.StrBuilder",
            new int[]{517,68,767,374,65,674,944,-796,-669,-277,-201,16,-743,-267,-449,50,264,17,-89,768,-462,880,-404,336,419,395,230,-383,-1000,204,593,267,-234,773,-258,-18,90,-343,258,-166,1000,-433,548,-56,-95,95,-841,-453,-858,769,-405,1000,-413,149,263,876,-584,-336,499,-699,-551,-466,-303,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00611() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,boolean):org.apache.commons.lang.text.StrBuilder",
            new int[]{-161,944,368,-186,-145,-448,-286,-243,-595,-134,78,945,-2,-759,156,-124,209,-793,686,-17,-397,-1000,258,72,426,-277,1000,937,-126,-866,1000,-287,692,-737,-287,341,-768,-972,-45,443,571,-393,909,54,139,-523,375,47,-166,-925,-314,476,210,-207,78,-468,-447,825,-605,1000,-286,-579,-308,-207}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00612() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,boolean):org.apache.commons.lang.text.StrBuilder",
            new int[]{-697,-334,-563,264,325,1000,1000,518,-492,-757,617,-575,157,858,23,-795,349,-686,-721,680,-338,-303,412,773,906,42,556,-598,-285,1000,440,1000,478,316,147,255,434,-35,1000,1000,1000,225,1000,-588,118,-705,-1000,-270,801,-431,-332,-723,-1000,1000,1000,1000,-1000,691,429,-623,1000,292,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00613() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,boolean):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-273,459,134,-64,61,1000,-869,-1000,-147,401,852,-941,-1000,-731,-1000,774,197,-687,-140,-267,-140,-226,840,858,-910,-597,-1000,403,1000,736,207,-784,1000,-637,-536,460,-857,605,22,484,842,1000,453,308,-96,762,-620,-327,-72,-958,1000,-132,-1000,-938,1000,917,-943,518,-43,-393,-1000,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00614() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-146,-1000,715,1000,-595,-1000,-446,32,-721,934,362,1000,563,-1000,-251,-1000,-1000,-458,-809,-44,1000,-1000,1000,-607,-638,1000,-1000,970,284,-951,-287,-918,234,-1000,-1000,-1000,189,-906,327,1000,-392,880,-949,-1000,940,1000,752,-1000,-879,207,-1000,-1000,919,-744,-1000,-251,421,-1000,668,1000,-1000,270,389,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00615() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-281,480,199,-886,-85,566,734,942,331,346,-755,-345,27,584,480,-352,-311,-184,-105,870,-26,367,74,197,483,-707,742,-794,330,714,455,244,713,-229,223,506,-585,798,683,-773,770,-792,758,26,223,54,-816,926,364,266,763,667,-950,165,755,-466,82,994,-574,113,791,955,457,164}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00616() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-279,-991,628,106,-768,-796,-24,659,-47,464,237,1000,511,-1000,52,-1000,-1000,-1000,-1000,734,1000,-1000,935,-1000,394,1000,-1000,56,1000,-355,-861,-1000,-109,-727,-1000,-509,907,233,857,-1000,-1000,-30,-138,-1000,852,48,-479,-1000,-761,172,-851,-1000,-530,-1000,-1000,-1000,993,970,-1000,222,12,1000,133,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00617() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-359,-1000,939,397,-1,-698,-241,1000,-53,84,-382,169,926,1000,-32,-1000,-804,-518,-85,454,826,-773,1000,-757,211,-240,-119,928,578,-676,907,-1000,-471,-449,-64,-305,-187,64,899,-400,1000,-129,440,-1000,188,366,-288,-541,-318,766,-344,-865,-1000,79,-546,641,72,802,-1000,189,-1000,651,-115,727}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00618() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{434,-563,321,444,303,-1000,429,-480,-715,1000,-985,-1000,645,652,139,635,1000,77,83,-143,854,1000,785,1000,-251,-385,300,-488,603,7,461,1000,8,720,654,-697,-1000,1000,347,523,1000,-759,220,380,-522,-694,68,1000,184,230,609,-532,-620,923,1000,-487,-1000,984,573,90,734,596,-491,-215}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00619() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-234,-796,957,91,268,-1000,219,644,-62,-53,-338,53,593,193,-243,-719,-521,-396,-360,627,826,-26,1000,-295,-70,-926,-41,284,705,-825,1000,-334,51,-28,540,503,-252,763,830,-644,1000,-183,303,-1000,-282,-390,-384,-153,-162,678,475,-638,-1000,458,-110,682,32,1000,-604,412,-5,756,-25,67}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00620() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,44,736,1000,-204,-406,1000,-578,-731,-1000,-821,-772,1000,832,936,107,638,881,-581,235,-889,1000,551,-83,-55,-225,1000,-704,777,338,-1000,1000,338,1000,136,-607,-1000,773,1000,1000,1000,-1000,-301,-150,344,-365,-1000,995,1000,-572,1000,-790,-1000,1000,-475,1000,1000,1000,1000,-576,575,-296,1000,716}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00621() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,char[]):org.apache.commons.lang.text.StrBuilder",
            new int[]{362,-205,252,243,-402,446,819,1000,874,787,14,448,1000,682,294,-185,528,-438,-363,-1000,-889,97,-805,-318,426,1000,152,733,294,369,-21,-1000,1000,-8,-1000,-1000,-34,1000,-1000,1000,511,-1000,-663,-485,-634,-1000,-242,-875,-614,1000,-309,-126,-65,-508,-157,-227,-484,-246,602,537,1000,-1000,430,-814}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00622() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,char[]):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,282,344,281,-367,-256,-724,147,576,23,158,300,-61,-823,-18,-1000,-459,692,1,338,882,-849,651,-316,735,-257,391,-455,954,370,1000,96,1000,-557,-130,1000,-446,-142,431,-536,-78,400,190,1000,244,-1000,-1000,-127,940,9,-438,-756,-965,7,-129,1000,668,-769,687,-1000,-723,-332,708,452}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00623() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,char[]):org.apache.commons.lang.text.StrBuilder",
            new int[]{-237,-104,279,-970,203,1000,371,-168,-99,-821,22,16,477,949,722,-121,-450,-1000,-1,-427,-62,747,606,545,-645,1000,-98,-18,-216,-1000,-1000,933,551,-302,1000,-416,-1000,-44,1000,297,413,42,-506,-1000,-589,801,254,-664,244,-929,539,-41,169,1000,-1000,-991,257,610,789,723,239,939,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00624() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,char[]):org.apache.commons.lang.text.StrBuilder",
            new int[]{-308,-205,252,1000,728,-293,819,-933,-772,-60,-31,-163,-857,-1000,-1000,-256,-916,202,37,1000,-391,-794,-562,987,-95,-74,1000,-371,103,899,265,-840,-57,342,1000,1000,1000,93,-1000,474,1000,1000,225,391,-1000,-81,-114,-871,758,655,795,1000,-1000,-270,1000,400,-1000,1000,-932,-1000,1000,1000,-262,494}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00625() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,char[]):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-1000,-771,-231,-639,-1000,154,-1000,-420,-1000,1000,613,499,474,1000,826,-1000,-564,-422,651,79,1000,-652,-793,-997,1000,-546,-303,-1000,-832,-868,1000,514,1000,1000,-200,498,-729,-85,562,335,25,-469,-1000,-719,705,1000,587,647,-625,73,558,-1000,1000,-347,-139,851,1000,-442,-177,-815,301,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00626() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,char[]):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-1000,1000,1000,-1000,1000,743,-474,772,787,677,1000,-1000,-103,636,91,-416,-586,764,228,-1000,763,245,-1000,-1000,592,-90,1000,866,-1000,-571,693,-172,-265,1000,820,1000,34,1000,197,-459,-3,-1000,-919,-1000,1000,303,96,-57,-1000,1000,463,973,770,502,1000,304,1000,362,-1000,-20,1000,-759,-564}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00627() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,char[]):org.apache.commons.lang.text.StrBuilder",
            new int[]{-191,-817,144,-361,814,913,879,-168,36,-903,191,-27,272,730,248,251,-1000,-134,317,-137,90,441,1000,783,-787,1000,-40,-31,-513,-720,-869,466,-37,-371,627,-856,-608,211,1000,221,717,1,-506,-1000,714,1000,-5,-251,143,-851,1000,674,175,948,-742,-1000,-388,1000,714,636,789,939,-1000,660}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00628() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,char[]):org.apache.commons.lang.text.StrBuilder",
            new int[]{-800,-76,38,619,-606,247,732,439,500,-1000,-63,254,-464,-883,-1000,-416,230,-1000,1000,438,-770,-1000,-17,582,20,-358,1000,568,28,623,1000,-1000,-1000,237,1000,1000,-17,-56,-521,-332,741,791,1000,-16,118,-1000,-1000,875,554,1000,-880,-310,-1000,-306,1000,657,-131,-191,-91,-709,1000,-744,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00629() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,char[],int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{639,548,797,739,-225,109,387,739,-477,-592,-944,722,1000,458,-334,-256,-311,840,-699,-358,650,-23,383,-1000,6,289,-837,1000,-973,84,107,-151,-1000,-1000,245,-22,278,-332,-1000,-887,472,895,-982,-998,553,-613,-853,-707,-338,-443,280,-275,-62,546,108,1000,-1000,-543,-495,-1000,-775,-456,573,711}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00630() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,char[],int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-171,94,302,-680,433,55,181,249,-819,-169,923,59,-445,-833,-373,1000,978,-1000,311,690,1000,289,-496,-623,-1000,639,1000,627,344,-1000,350,1000,-972,-975,-266,-840,-674,527,-134,1000,784,-205,-637,-686,868,-313,-122,-287,-1000,700,1000,-845,-323,898,197,816,151,920,884,-882,794,-498,613,-13}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00631() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,char[],int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-763,-576,324,-673,535,57,-272,-511,1000,-244,503,265,-91,1000,954,-358,-615,738,706,-762,-849,-954,52,-461,1000,-1000,-1000,-614,-767,989,-54,-502,-460,-354,-202,-837,111,-1000,779,-260,-118,-130,566,902,189,-75,-1000,22,993,-1000,-901,-155,753,-1000,-1000,620,-259,848,173,1000,633,260,375,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00632() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,char[],int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,263,-611,150,-284,1000,564,248,1000,-447,-1,879,1000,449,933,-613,-1000,-25,1000,-567,-390,-398,937,-1000,-472,-864,-419,690,994,1000,482,-303,1000,-992,345,-619,-551,523,-121,-106,1000,307,-1000,-167,-16,-1000,-783,-1000,475,-1000,-1000,694,1000,-1000,-1000,-1000,-752,-1000,-220,509,-109,1000,-190,288}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00633() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,char[],int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-599,-1000,-857,-1000,1000,-16,-424,451,552,400,1000,-270,-1000,238,660,382,430,91,248,-343,642,496,-709,1000,667,-408,636,-555,1000,80,82,750,-87,-111,-1000,-1000,-645,-11,-221,46,87,-1000,277,899,214,1000,193,442,-56,-187,907,-30,-744,-1000,-916,1000,1000,1000,262,-1000,1000,-1000,425,31}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00634() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,char[],int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{699,500,514,265,-604,253,708,-65,401,-1000,-880,-418,719,-529,227,323,-1000,-297,-408,936,-240,-1000,993,-1000,-1000,453,527,381,-179,370,68,164,476,101,-63,47,-531,-465,-776,-348,1000,-710,-482,-76,1000,-476,98,-310,333,-927,-1000,569,906,676,1000,385,-824,-1000,-1000,-691,-1000,565,967,-764}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00635() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,char[],int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-31,-1000,-850,72,991,293,87,1000,46,753,681,136,-245,741,572,-1000,-834,1000,-861,208,320,81,-545,-392,-1000,83,-124,1000,508,926,425,1000,-307,448,-831,-774,738,-134,-226,734,-71,-1000,1000,-1000,-436,-670,-739,7,-575,-114,645,1000,-1000,-1000,-1000,209,-1000,540,1000,1000,578,327,-412}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00636() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,char[],int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,752,168,-1000,-1000,527,254,-522,-1000,-592,-801,742,-326,-28,-980,469,260,1000,680,264,-368,-400,245,-1000,607,222,847,207,59,-586,92,-308,147,-1000,653,593,-311,-764,-1000,1000,1000,407,-895,-998,787,-1000,513,-1000,-224,-443,280,1000,-710,622,-37,562,-1000,-812,-1000,-150,-691,-124,495,-722}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00637() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,char[],int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{980,119,-37,860,-1000,726,0,0,-360,-1000,-291,-14,0,114,-1000,264,-347,0,198,102,0,-1000,422,-1000,-248,-16,719,201,197,-74,457,-470,466,-9,-36,0,-258,0,-843,411,1000,-74,-799,-856,821,-1000,233,-769,0,-163,-858,1000,-98,1000,267,0,-434,-783,-1000,-1000,-755,0,753,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00638() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,char[],int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{268,-466,-226,224,433,935,-151,-1000,545,1000,489,483,-203,462,-697,-470,-402,-214,1000,690,-1000,-1000,-416,720,918,-1000,-17,-813,407,767,193,127,222,-975,-359,-590,-103,-1000,-864,1000,1000,-1000,-222,-130,-352,16,460,-316,419,-910,-1000,1000,-254,-189,197,243,580,527,884,1000,507,-603,-597,-534}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00639() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,char[],int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{239,917,928,1000,217,-653,205,1000,-396,846,-1000,-209,958,-51,-258,388,-527,930,643,213,-158,-664,681,-1000,889,1000,626,671,420,-108,-1000,-198,-434,-473,-567,-118,-43,-928,-725,1000,865,-249,-122,-851,1000,-452,-164,255,-225,-227,-594,-2,48,-328,-571,1000,-1000,-331,-1000,-1000,-1000,1000,921,505}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00640() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,double):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,194,-389,-752,1000,628,18,-237,1000,992,322,1000,377,511,298,1000,237,102,-346,-682,1000,359,-640,268,498,-616,-1000,1000,-826,317,-558,691,262,-526,481,275,-1000,739,-261,-738,-801,1000,-1000,134,-365,777,-1000,-321,429,-930,195,769,466,121,-1000,-1000,889,-9,64,236,-1000,769,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00641() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,double):org.apache.commons.lang.text.StrBuilder",
            new int[]{-129,903,-801,976,-177,459,204,954,768,-829,-961,114,-420,-662,-639,-907,883,36,-394,549,658,505,808,-17,777,-758,-695,-244,-693,-819,-118,334,-879,-18,257,-637,734,-589,-129,-982,602,-913,888,-715,-845,-565,-976,-699,-265,604,380,710,306,305,-218,75,315,72,334,-131,-607,260,828,-743}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00642() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,double):org.apache.commons.lang.text.StrBuilder",
            new int[]{-228,-1000,-985,-749,399,139,-732,666,1000,-345,717,744,616,997,-644,-161,111,-592,-164,-117,982,487,-486,-1000,1000,-139,-329,317,-750,-726,-945,-113,347,-461,760,962,-636,1000,-907,-952,-981,-718,49,-405,-921,975,-665,-30,-480,643,1000,-464,-223,537,-1000,-695,-208,1000,462,640,-786,65,831,-528}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00643() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,double):org.apache.commons.lang.text.StrBuilder",
            new int[]{-477,-941,-1000,-594,544,-798,-1000,-856,343,-616,1000,229,421,319,-243,-363,-790,-1000,-508,-839,186,185,-640,-1000,326,-65,294,414,440,-1000,-1000,106,455,330,982,1000,-772,1000,760,-504,-1000,-739,253,-813,-581,1000,-131,158,51,404,1000,-1000,-1000,611,-1000,-523,-1000,1000,255,1000,-1000,-302,784,-432}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00644() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,double):org.apache.commons.lang.text.StrBuilder",
            new int[]{30,194,949,-681,-1000,837,287,-354,1000,-486,-1000,367,183,-1000,90,1000,374,906,1000,862,-1000,-726,-1000,-406,-1000,-1000,324,-1000,69,-233,-359,440,1000,1000,-751,-921,1000,1000,438,1000,-311,1000,456,889,1000,1000,-343,-1000,-1000,-226,1000,671,902,-1000,1000,-623,-358,-1000,-364,-1000,417,-1000,-1000,-633}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00645() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,double):org.apache.commons.lang.text.StrBuilder",
            new int[]{646,-1000,958,-977,-1000,1000,-417,761,1000,-608,-1000,203,-321,-1000,-700,1000,117,881,553,634,-612,-1000,-1000,-1000,-155,-1000,434,-1000,370,-628,-558,691,913,1000,531,367,481,1000,-514,897,-1000,1000,938,-533,847,1000,-380,-748,-1000,1000,1000,1000,510,1000,1000,-1000,-784,-909,64,-1000,900,-1000,-1000,-1}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00646() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,double):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,521,-208,-411,966,158,-342,-1000,-1000,532,1000,767,373,-887,799,1000,-1000,99,587,-1000,791,-1000,-1000,666,-958,-1000,994,1000,1000,-98,228,875,1000,280,500,-491,-1000,627,332,469,-15,-354,-356,-340,568,958,-638,-126,1000,-1000,445,-1000,-1000,310,-895,-1000,-956,-1000,-1000,513,-1000,-532,-219,-978}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00647() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,float):org.apache.commons.lang.text.StrBuilder",
            new int[]{-237,-1000,-1000,27,381,-391,526,-258,1000,551,992,-323,729,555,275,487,730,-649,-415,1000,-127,-859,808,-363,-126,949,-470,-623,-35,-415,356,411,37,-147,823,-24,-834,582,1000,533,185,-1000,410,-843,-1000,519,120,-200,-881,-360,27,1000,-635,-7,784,-857,-151,-83,-201,122,-583,-295,733,-227}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00648() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,float):org.apache.commons.lang.text.StrBuilder",
            new int[]{-351,-455,-805,-598,-567,-236,-547,-354,295,-320,800,29,199,-49,77,-19,871,293,223,497,127,669,-450,-189,-305,385,-541,120,363,-594,617,-520,255,-613,205,-489,51,588,1000,365,235,-394,85,325,340,54,-101,-321,-698,-615,-666,-78,-723,-495,772,-152,-597,274,369,-861,-191,-567,271,211}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00649() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,float):org.apache.commons.lang.text.StrBuilder",
            new int[]{830,-94,-703,387,-707,424,834,-801,891,502,643,823,-41,821,884,108,-148,205,-468,60,96,-739,898,-802,214,-152,-748,-984,-865,-914,191,-726,451,-296,864,-646,-30,972,493,751,965,220,799,943,331,-32,-162,309,-537,96,544,-417,-933,146,853,-617,-632,-155,-360,-223,204,253,-85,549}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00650() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,float):org.apache.commons.lang.text.StrBuilder",
            new int[]{-753,-912,-693,-1000,743,362,-1000,-541,-1000,-180,-477,790,464,-896,-260,1000,1000,-1000,1000,1000,-463,1000,521,-119,-1000,546,-1000,-1000,1000,-1000,1000,542,1000,-1000,-1000,-121,-1000,-1000,-243,328,-491,-346,95,-673,-636,942,824,-59,-689,-1000,-1000,402,-1000,982,193,393,198,1000,1000,-372,-1000,-1000,-363,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00651() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,float):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-1000,32,-381,391,422,-546,961,-166,-1000,-718,289,-1000,-1000,-917,-709,1000,94,768,95,-832,1000,-520,786,-582,-913,-1000,-518,-229,-1000,1000,212,1000,-896,-522,-382,-867,-135,-771,594,-807,810,-146,369,244,955,997,35,-730,-1000,312,236,662,-313,36,1000,544,148,-102,-203,-320,-458,-621,-771}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00652() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,float):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-1000,-651,-1000,829,-292,-941,-787,-1000,-1000,463,186,366,-452,-1000,1000,896,-1000,1000,1000,-98,1000,744,-148,-822,1000,-1000,-1000,293,-1000,1000,601,787,-945,-846,-392,-1000,-740,-2,1000,-512,-680,549,-650,-955,1000,56,345,-420,-342,-1000,834,-561,933,117,-445,-669,1000,1000,1000,-798,-697,49,-674}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00653() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,float):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-1000,-1000,383,-334,-910,448,-106,1000,-474,1000,-558,97,-395,-1000,-819,105,-125,-936,77,-265,-228,-702,-414,-249,-333,-511,1000,-111,1000,-774,821,288,-264,-95,38,86,865,1000,664,-733,-594,126,568,-1000,862,42,-1000,-670,-165,-863,1000,1000,566,-1000,-342,-1000,-1000,-427,-986,-220,-634,626,-263}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00654() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-1000,189,-389,802,-288,-851,-76,427,1000,837,383,734,-140,1000,-192,1000,-718,144,2,-318,964,-913,611,-205,-639,1000,1000,529,1000,-304,522,769,-66,649,-374,-1000,361,-182,-863,1000,584,619,103,-1000,290,1000,1000,-262,-450,485,-993,-395,-270,-354,837,-626,-1000,-505,1000,-613,1000,854,-169}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00655() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-639,379,839,609,321,-365,299,-648,77,-339,813,26,-101,431,-136,693,-932,-387,-310,391,1000,-633,-139,-270,-829,487,-1000,165,-907,399,-610,196,-209,-285,835,-322,-791,-661,313,126,-590,-246,-1000,-445,90,765,-475,-912,-1000,-309,-790,417,325,-67,596,-378,1000,-525,569,-1000,795,750,358}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00656() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{38,796,-558,-886,-171,-304,643,-674,136,-21,262,-442,-1000,-1000,836,-382,-342,-272,-878,-10,163,-733,390,828,1000,214,359,-776,35,780,-146,-1000,50,374,-29,-1000,211,182,-294,-806,-512,348,-850,1000,441,905,535,1000,430,1000,1000,415,-823,1000,302,-1000,584,387,1000,372,838,174,447,504}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00657() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-1000,-166,-55,456,184,207,-401,-278,956,499,-149,840,-123,473,1000,982,-459,223,701,-309,1000,-633,809,-229,967,1000,1000,373,364,-399,1000,302,963,60,219,-991,-769,1000,-713,343,235,568,-1000,-541,-122,-685,96,-732,16,307,-581,-133,845,-576,1000,7,-576,-503,298,-879,1000,548,-43}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00658() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-823,-1000,636,168,1000,942,-851,688,250,583,-474,-130,-166,-192,1000,-48,984,-945,-851,-659,465,1000,-1000,-1000,-543,-639,616,-1000,276,253,225,-1000,621,-1000,-1000,-301,-225,38,210,-237,923,584,568,-195,-1000,-317,278,1000,-262,836,-562,-898,315,-270,1000,597,-80,-79,-362,798,-443,462,831,544}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00659() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-652,-639,130,532,-228,-351,-290,941,307,30,100,-588,1000,359,219,693,-890,-1000,-747,-1000,807,-480,-1000,650,917,879,-480,-690,552,1000,-408,420,-7,-1000,278,664,-28,872,-1000,1000,-120,390,508,-229,-1000,-890,1000,-650,-1000,13,-212,599,-18,1000,316,-656,-6,-523,629,479,519,-621,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00660() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{934,-901,256,1000,673,-294,-744,-561,-1000,-486,604,235,-180,1000,415,1000,1000,285,296,1000,-1000,-83,-546,-789,-1000,-977,-796,-583,-1000,-1000,1000,648,832,656,-19,-283,1000,-517,-612,594,729,-576,1000,649,306,-1000,780,-1000,50,91,17,82,79,-904,86,823,-933,710,791,-526,-260,187,-1000,207}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00661() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,java.lang.Object):org.apache.commons.lang.text.StrBuilder",
            new int[]{306,-328,308,157,28,-996,-153,-1000,875,-136,-391,-182,-333,486,-799,-612,-95,1000,-704,-901,-43,140,-1000,-42,911,-1000,-69,557,238,583,-1000,-68,-73,706,1000,-369,567,-524,795,-1000,196,-402,728,129,1000,-961,1000,-655,-1000,-673,-416,130,-661,460,478,-170,648,-931,-800,-429,136,681,810,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00662() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,java.lang.Object):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,1000,313,173,724,-853,414,-805,1000,414,-864,976,1000,-864,479,-573,-1000,646,-765,391,1000,-120,-456,-322,587,1000,246,1000,-969,1000,-626,-720,-85,1000,1000,20,349,1000,721,-561,389,631,217,1000,-700,-108,-125,-509,-1000,-211,-429,244,-418,148,-615,406,290,685,-872,-754,602,421,-135,-875}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00663() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,java.lang.Object):org.apache.commons.lang.text.StrBuilder",
            new int[]{532,-609,779,-81,848,521,367,-594,218,-136,-1000,1000,-192,1000,-750,-982,-493,1000,-150,354,-996,433,-322,1000,31,651,-1000,1000,-1000,398,1000,-1000,-336,1000,780,-355,1000,-1000,947,-1000,-1000,-1000,900,-34,-2,-1000,-292,-1000,-1000,-511,-1000,-484,-1000,553,384,896,1000,483,-894,-887,136,1000,-1000,-1}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00664() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,java.lang.Object):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,26,-36,419,387,-11,-616,-236,151,2,115,-926,-866,1000,-1000,-1000,886,1000,-201,-802,108,-595,-646,270,400,-539,569,987,-268,-242,-574,-493,-265,745,77,41,1000,-1000,1000,-1000,-163,-462,-172,-564,400,-1000,1000,-759,-826,-103,777,-73,-1000,932,731,587,753,-574,-737,-511,-429,-828,952,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00665() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,java.lang.Object):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-328,433,96,695,712,87,-545,25,846,-877,29,-333,1000,-551,-1000,61,1000,48,-275,369,-80,-654,1000,-477,-181,-1000,660,-762,-158,353,-1000,-874,706,404,540,1000,682,817,-980,-1000,-113,260,-435,1000,-961,1000,-1000,-487,-1000,-1000,248,-1000,6,-42,1000,1000,-720,-483,-702,-1000,681,-49,-88}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00666() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,java.lang.Object):org.apache.commons.lang.text.StrBuilder",
            new int[]{239,-64,154,191,254,-56,414,-1000,711,1000,-1000,67,288,427,-1000,-531,-266,733,58,-561,801,870,-434,715,-621,-558,-1000,524,-1000,1000,-128,-720,-579,956,846,373,1000,195,721,-1000,-314,-1000,-253,399,486,-534,526,-742,-1000,-1000,-1000,244,-1000,-212,-903,-190,1000,-701,-872,-125,602,1000,651,-349}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00667() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,java.lang.Object):org.apache.commons.lang.text.StrBuilder",
            new int[]{254,294,479,8,236,-348,146,-989,959,-124,35,-88,-214,132,-692,-523,-588,1000,-833,-901,-672,-208,-1000,238,1000,-1000,-382,557,622,794,-1000,-362,-2,625,1000,-407,947,-615,766,-1000,98,-566,1000,235,1000,-880,1000,-799,-953,-443,-586,48,-1000,455,553,67,984,-637,-689,-723,-39,749,810,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00668() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,java.lang.Object):org.apache.commons.lang.text.StrBuilder",
            new int[]{-12,650,0,824,-370,81,1000,1000,-365,1000,338,-364,-88,818,261,-21,28,950,8,-718,252,966,-595,272,193,-483,-131,1000,-654,-865,1000,620,480,-332,205,-611,1000,-887,-1000,-124,-911,365,1000,-1000,-879,441,1000,-1000,51,-516,-466,691,-546,1000,1000,346,-752,610,-327,900,-1000,-1000,1000,-567}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00669() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-649,-1000,1000,-432,-857,646,184,354,-659,-1000,-329,-714,-615,-639,-1000,317,-1000,1000,-200,-814,-1000,-1000,-649,-807,1000,1000,-1000,138,-434,494,-769,84,961,460,-55,506,675,-504,575,-400,324,885,-1000,-631,-280,1000,619,-268,1000,-99,415,-1000,-1000,419,-47,357,-1000,1000,1000,1000,-294,-1000,656,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00670() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-855,3,-378,-213,125,155,370,1000,-554,1000,-697,-813,-1000,246,767,-432,269,1000,304,1000,205,796,360,648,-1000,283,1000,1000,-1000,-244,770,-1000,162,-658,-314,-1000,-1000,1000,-232,117,695,-1000,-542,-395,1000,-930,1000,526,-1000,-952,-966,754,847,1000,-340,216,617,215,-880,723,-65,314,242,-227}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00671() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-8,35,-1000,-349,-623,13,-126,-363,-480,282,-118,-794,489,-238,40,871,-600,-665,-892,-275,-1000,394,262,-257,363,-404,22,-372,-919,814,-565,-404,57,-528,-400,-22,-313,531,469,900,628,547,-869,-743,-911,-191,324,-847,-418,441,-342,-99,-31,299,641,-298,-767,722,103,662,172,-987,254,-742}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00672() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,305,-34,-822,-545,792,-851,1000,-224,785,-876,-65,1000,-772,-873,448,-365,-1000,-1000,-1000,-109,1000,-314,-787,1000,-619,-988,91,-247,900,-1000,-558,0,285,790,340,598,-727,-427,1000,1000,866,-961,-843,51,454,-914,-450,129,751,-465,-1000,1000,266,431,240,-1000,1000,909,689,1000,422,-508,-184}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00673() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-300,-847,-258,-1000,193,-102,-1000,-980,-637,-39,-197,225,727,1000,-1000,1000,-1000,179,-1000,-1000,-1000,-966,-491,-1000,1000,-348,-1000,-598,-671,934,-643,33,7,664,-570,1000,430,-837,-281,302,781,1000,-1000,-1000,-1000,237,-15,73,408,1000,-749,-1000,1000,-78,-827,389,-1000,1000,1000,-630,631,979,-1000,745}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00674() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,227,-729,-1000,1000,-943,391,-548,-869,1000,-886,1000,-25,-591,-94,-1000,966,-514,-24,1000,481,506,925,1000,-1000,-1000,698,945,-898,-113,1000,-1000,569,410,-159,927,116,522,-1000,-1000,1000,-1000,-898,-981,1000,-1000,-1000,-487,19,-568,-105,-528,191,-639,-1000,-605,850,1000,-99,-823,-563,1000,-1000,655}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00675() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,512,462,-1000,-1000,1000,417,-1000,-211,-1000,-1000,308,-215,-573,-653,-1000,536,1000,-395,1000,-1000,236,578,702,-171,-298,1000,1000,-873,680,745,-1000,1000,-1000,-1000,326,346,-1000,106,-704,1000,-87,-1000,1000,-152,950,812,-1000,-10,-1000,-333,-1000,-990,-115,-91,-124,226,1000,598,-494,-1000,-500,-920,606}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00676() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{333,97,-80,42,-521,817,568,-1000,-617,-336,979,1000,1000,1000,-645,-53,-1000,-601,-24,-1000,-1000,-626,112,-700,525,274,-1000,23,599,839,-143,833,-196,1000,510,444,29,616,-514,346,-1000,881,-131,-486,-1000,860,378,196,-423,816,-955,-356,-206,-505,555,951,-563,567,841,-314,639,-168,701,655}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00677() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-976,-1000,1000,-432,-22,-125,-136,369,-1000,-327,-966,-710,-806,-96,-1000,640,-1000,1000,-200,-814,-1000,-1000,-1000,572,1000,1000,-1000,420,-685,448,-519,-325,496,225,138,506,475,-771,697,-849,795,885,-1000,-1000,-280,1000,513,-338,1000,-99,175,-1000,-353,1000,-979,508,-1000,1000,-187,692,-482,-211,-68,932}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00678() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-132,-322,112,-912,548,-495,1000,-462,425,817,-337,1000,-209,206,99,-170,-703,-391,112,867,-196,-838,784,810,642,-1000,-1000,174,547,-313,1000,270,645,327,998,23,771,-581,-1000,-1000,-424,-725,-613,-848,-364,-556,-603,31,377,-212,644,310,-61,-305,-972,-98,533,773,414,360,-944,1000,1000,127}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00679() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,long):org.apache.commons.lang.text.StrBuilder",
            new int[]{535,-1000,-745,-229,-13,158,-451,269,400,-922,-1000,347,608,743,1000,-1000,355,400,-910,778,674,657,1000,985,-608,720,301,1000,-6,1000,-830,512,106,-165,-176,-850,181,1000,372,-60,475,810,1000,103,174,-884,-666,972,894,-177,-1000,-394,-129,-160,301,-662,400,275,-141,-297,-502,107,-140,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00680() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,long):org.apache.commons.lang.text.StrBuilder",
            new int[]{615,163,-1000,367,-896,-897,1000,-841,1000,-837,-426,751,-102,-223,-202,-1000,-1000,1000,-1000,1000,-221,25,1000,-635,-882,-34,-1000,1000,-199,128,40,-828,-936,50,75,386,-1000,-247,681,-398,55,1000,112,106,270,748,-355,414,1000,396,-356,43,313,711,-455,-454,1000,190,325,-412,50,-1000,-732,681}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00681() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,long):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-1000,-212,-1000,-1000,-1000,943,461,-611,-409,-1000,242,1000,1000,1000,-668,-916,-513,-1000,796,-600,-393,-1000,-1000,-336,1000,1000,1000,-1000,1000,-1000,-1000,489,-246,-601,1000,-365,977,623,491,-91,-1000,1000,541,-287,-1000,-1000,1000,537,-282,-81,-802,169,-159,-95,-754,-948,1000,592,-39,-142,1000,1000,817}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00682() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,long):org.apache.commons.lang.text.StrBuilder",
            new int[]{167,-975,979,25,-614,-458,451,637,-451,-704,-968,-334,-228,-205,-383,740,632,-823,553,-825,-136,-179,-802,493,-350,955,-531,-180,403,-493,-395,-652,945,-618,360,281,492,-695,-629,936,-26,457,644,0,850,-794,704,-653,828,-562,-709,259,-333,-795,230,438,570,-272,-475,732,-369,-865,640,198}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00683() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,long):org.apache.commons.lang.text.StrBuilder",
            new int[]{167,212,-229,25,680,512,-457,-122,-902,752,-1000,-334,661,912,-27,554,1000,-34,-1000,-825,-441,-587,697,1000,-350,965,-1000,-180,334,-519,311,-652,1000,-1000,905,531,200,174,-1000,559,389,-264,800,-325,-453,-1000,-604,337,-228,-1000,68,89,-821,133,-492,438,206,-272,-1000,1000,-369,623,560,198}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00684() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,long):org.apache.commons.lang.text.StrBuilder",
            new int[]{-192,662,-714,-406,924,10,943,-223,59,-335,421,206,-731,-95,-369,-668,-916,930,371,397,-530,-393,274,-373,-305,-161,-810,47,270,66,486,380,-903,317,-295,-320,-498,-781,623,-368,-91,426,-169,-238,-399,32,-279,219,185,-293,-81,219,220,541,-875,-219,762,-124,592,-58,515,-249,-489,315}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00685() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,long):org.apache.commons.lang.text.StrBuilder",
            new int[]{954,-1000,992,286,-129,224,223,315,-1000,-83,-187,-1000,386,356,-332,514,557,794,-777,1000,-618,-697,-293,15,782,1000,-1000,-333,-288,74,379,146,-7,-959,62,116,82,-979,-1000,-767,-402,-840,628,746,-892,-1000,-1000,301,1000,-912,-1000,-614,-847,-168,-1000,-1000,1000,628,-884,1000,-409,980,667,-275}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00686() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "isEmpty():boolean",
            new int[]{507,437,319,-837,166,277,-894,-676,474,-304,-808,747,496,-676,874,663,-365,-368,855,-823,-83,840,419,466,-188,-790,-718,-147,-353,672,-631,108,487,-437,-322,-588,785,87,-202,559,48,-949,-328,189,335,406,758,79,465,-821,854,-101,495,487,-440,188,-774,499,-403,-219,-689,453,999,-565}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00687() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "isEmpty():boolean",
            new int[]{567,82,698,1000,699,-544,-766,1000,-343,-305,-558,-574,559,-727,-521,-192,1000,357,863,198,257,949,-1000,-802,897,-75,-120,-226,-330,329,-574,600,-242,1000,1000,635,554,449,217,319,856,-422,443,513,-1000,-507,-426,203,-1000,155,-417,-1000,-195,-465,495,-69,-1000,-321,-763,1000,-315,916,648,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00688() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "isEmpty():boolean",
            new int[]{-367,927,-917,183,97,390,-1000,-261,381,484,124,1000,401,-1000,-383,779,-754,127,1000,473,556,699,908,539,481,44,-368,1000,132,1000,-53,672,-734,197,-705,-286,1000,-668,-301,987,-154,255,-82,-474,82,249,392,1000,-594,-996,-56,-925,1000,1000,-1000,1000,-336,608,21,776,-978,510,53,-809}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00689() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "isEmpty():boolean",
            new int[]{185,-553,335,-245,-600,25,-196,-228,-1000,-47,372,-463,-479,-1000,-276,-1000,221,453,-780,1000,-932,1000,-553,-521,338,470,274,-258,133,670,-509,-83,101,1000,503,443,1000,548,391,-435,-676,-548,268,704,-976,-1000,-921,-681,-1000,942,198,-1000,234,615,-210,398,-270,1000,-1000,-852,-1000,-1000,-539,-430}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00690() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "isEmpty():boolean",
            new int[]{-417,-676,-1000,-1000,-903,720,-766,-851,-745,668,1000,-574,-935,-1000,500,-718,-1000,924,-1000,958,-603,637,-471,-523,897,-181,1000,11,828,-314,-737,-830,-341,1000,-1000,-192,711,-213,217,-1000,-1000,-422,201,513,-1000,-1000,-598,-1000,-1000,155,153,-1000,203,1000,345,-923,713,642,-456,-1000,-315,-742,166,477}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00691() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "isEmpty():boolean",
            new int[]{-784,407,159,68,-758,599,-454,-153,1000,-194,519,-203,706,-1000,398,-256,-486,-380,31,1000,90,1000,-243,903,1000,-1000,-735,-623,-132,529,-366,-59,-155,154,1000,-364,664,48,-1000,1000,634,600,1000,189,193,-600,-1000,1000,-1000,-485,328,713,495,-407,1000,233,-450,-477,79,35,-1000,-460,1000,-574}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00692() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "isEmpty():boolean",
            new int[]{-121,257,455,-11,-503,159,-409,333,-808,-496,-101,-394,661,-1000,-332,-796,640,-96,507,426,-333,1000,-307,-111,484,735,-635,61,-369,1000,-294,734,591,1000,1000,400,1000,631,-152,987,387,-801,-22,557,-112,-874,-887,507,-1000,481,426,-412,156,-382,-1000,1000,-766,476,-929,42,-1000,837,-603,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00693() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "isEmpty():boolean",
            new int[]{297,437,48,-837,-109,358,427,323,-14,1000,-279,6,4,-901,630,-940,433,707,-15,37,313,922,792,-66,633,-567,1000,-1000,317,672,-616,-780,1000,-94,1000,-342,954,1000,73,1000,-318,214,-121,826,756,1000,-887,1000,567,-593,854,287,828,-1000,-440,-1000,-1000,-464,-1000,94,-689,824,876,-775}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00694() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(char):int",
            new int[]{477,-1000,-302,334,317,922,207,447,-397,-174,-805,873,-531,-918,-23,219,-876,-1000,1000,-503,-295,-436,-510,-1000,-594,238,-51,-99,-1000,-1000,-473,390,935,-104,448,166,252,990,435,-596,286,-391,-134,365,382,358,861,-584,682,-1000,83,-1000,10,-414,-956,-153,-766,30,97,143,121,-568,846,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00695() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(char):int",
            new int[]{294,-294,844,-436,-841,1000,747,1000,902,-67,509,202,678,150,-346,-822,547,679,-52,728,-500,370,325,460,-704,-153,-1000,-988,760,-525,-18,820,150,-244,1000,1000,684,555,642,-254,445,1000,383,1000,-1000,1000,883,-774,600,-343,-1000,1000,-615,-1000,-1000,695,-18,1000,-345,212,782,-541,208,-802}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00696() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(char):int",
            new int[]{526,-867,-101,-196,239,524,1000,1000,-744,-618,-1000,1000,-212,-1000,-1000,1000,-191,-878,477,-457,1000,-711,-453,-666,-1000,1000,-1000,-766,-1000,-417,-1000,478,-120,1000,201,962,293,1000,-756,158,215,647,731,1000,1000,-312,1000,-826,592,-356,-520,-991,-1000,687,-1000,343,-1000,-719,-1000,-1000,859,521,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00697() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(char):int",
            new int[]{610,-1000,-877,-636,-708,564,241,1000,-383,-1000,-893,1000,984,-608,-1000,1000,-646,-1000,1000,-848,1000,-532,-1000,-183,-1000,-10,392,-708,-1000,-932,-1000,623,-143,479,647,1000,595,1000,1000,705,1000,-1000,25,1000,1000,-210,674,-1000,1000,-1000,1000,-570,-746,-414,-1000,584,-1000,-691,-1000,-1000,-481,-1000,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00698() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(char):int",
            new int[]{215,-1000,-463,1000,-473,-391,-1000,-528,-21,-623,944,519,357,642,334,-826,-337,116,-621,-33,-3,-691,-892,69,1000,-418,-268,-1000,905,-319,-143,238,-301,-218,1000,150,702,986,-1000,-750,1000,-698,-1000,-310,-215,82,-758,-527,546,-459,201,35,201,-1000,-937,-317,-665,747,640,508,-1000,1000,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00699() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(char):int",
            new int[]{438,-698,-205,691,-437,-719,50,315,-1000,-480,-703,608,-157,446,-70,-66,239,-397,-469,30,844,-373,-487,-680,856,845,-1000,-99,1000,291,-802,654,-124,797,782,-169,461,809,-359,-414,286,641,47,567,-536,-372,-590,95,13,-355,-1000,-1000,-985,1000,-849,-658,-321,272,-168,274,1000,321,-340,-915}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00700() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(char):int",
            new int[]{10,8,160,379,691,984,810,652,1000,229,-149,51,-1000,-607,520,-421,-132,1000,402,-193,-393,-889,1000,817,89,532,-458,176,99,-709,-90,-20,-119,90,-112,-399,-198,365,-380,-1000,-714,1000,251,250,361,838,-457,-771,350,-668,-1000,238,-696,133,-497,-148,287,-62,1000,578,-488,208,516,-717}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00701() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(char):int",
            new int[]{329,-481,-354,357,-484,329,118,610,1000,-450,-13,254,272,-133,-629,128,-563,68,215,-165,486,-657,-197,108,89,-139,797,-206,88,-647,-494,424,-1000,77,396,568,376,809,-332,-375,1000,128,-223,1000,1000,849,674,-1000,1000,-194,400,-498,-448,-1000,-849,198,-716,-19,-349,51,-449,208,152,-915}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00702() {
        org.junit.Assert.assertEquals("java.lang.Integer:Mw==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(char):int",
            new int[]{-361,-664,-563,731,209,-996,-891,-713,-32,-855,318,359,550,850,925,-217,569,-929,318,-424,697,-914,-844,-753,255,440,544,-784,958,360,-699,-424,-527,764,281,-908,-410,681,-888,-447,962,-880,-808,-626,613,299,-749,-315,-292,-551,434,78,-554,-586,430,-392,350,-275,948,-270,731,910,-458,-596}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00703() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(char,int):int",
            new int[]{-1000,-1000,-990,-319,777,919,886,1000,-307,704,365,-458,348,671,-328,-816,-458,495,-1000,-350,-25,575,-1000,-1000,-822,1000,-108,1000,1000,-823,1000,1000,539,125,601,815,1000,-1000,412,1000,1000,440,-189,543,-726,-591,61,-1000,1000,763,678,1000,645,-1000,-827,840,1000,1000,374,287,-64,672,1000,-814}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00704() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(char,int):int",
            new int[]{270,159,294,39,-687,-395,810,-753,-773,-466,93,47,-465,-225,-275,-223,-948,787,-404,-143,-204,-517,351,712,-123,111,362,-196,-787,5,347,-612,-495,152,318,857,653,-302,229,-955,-662,434,399,565,292,-45,-805,-656,-553,654,-541,776,-749,-794,92,282,-75,-215,-219,179,815,11,-891,-371}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00705() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(char,int):int",
            new int[]{-256,656,-230,-288,153,82,889,-1000,-61,62,53,56,434,96,-68,-360,-354,258,-71,-500,-500,-102,151,439,388,177,402,639,-240,-239,93,-1000,515,309,757,884,-617,46,-234,-283,-419,868,379,1000,148,428,-41,-744,683,-17,-152,286,-358,-690,-212,205,-313,461,-502,-173,1000,-165,-441,138}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00706() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(char,int):int",
            new int[]{-625,334,-96,-272,19,-261,939,-400,757,46,210,79,-240,-63,-70,-138,-865,-299,-492,-569,-152,-354,-89,400,121,-322,151,676,-337,-1000,237,-400,490,-557,486,904,-91,-321,-706,-563,-400,300,1000,841,400,118,-59,-400,-109,791,-278,105,-1000,82,-552,312,223,67,-432,520,901,-69,-198,82}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00707() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(char,int):int",
            new int[]{400,-1000,1000,482,-669,411,259,-759,1000,-1000,1000,-199,-948,-910,-1000,-807,-1000,1000,-1000,-1000,-608,90,444,1000,-1000,264,315,-520,-796,191,-756,580,-1000,-960,309,169,1000,87,1000,-1000,512,792,1000,1000,452,659,-1000,-539,-62,602,-838,588,-281,-1000,1000,1000,1000,-1000,-342,397,-494,1000,-497,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00708() {
        org.junit.Assert.assertEquals("java.lang.Integer:MTY=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(char,int):int",
            new int[]{649,260,445,501,-164,-283,578,97,799,-35,-313,190,100,-59,-124,1000,-507,-397,165,-310,-767,-1000,-520,116,546,-1000,1000,431,-179,435,923,-8,539,243,638,458,-1000,965,-1000,-349,542,436,796,538,821,848,501,678,-1000,258,-554,137,-1000,-1000,-56,-128,-519,1000,-352,287,799,-590,-854,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00709() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(char,int):int",
            new int[]{1000,-1000,-947,98,-581,1000,719,-1000,332,-451,1000,-1000,899,-309,-574,-1000,-472,1000,-15,-681,-383,975,246,712,-814,1000,412,579,-913,-665,129,320,743,287,441,704,-402,-1000,1000,-532,-656,796,1000,341,429,-587,-407,-1000,-400,141,-913,1000,-1000,-1000,86,122,944,467,-1000,-64,1000,1000,-988,-144}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00710() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(char,int):int",
            new int[]{-1000,-1000,272,1000,1000,-297,826,385,432,408,155,-291,428,-1000,-526,212,129,589,1000,-297,-1000,225,718,-406,-264,-315,188,1000,1000,35,311,-729,557,-74,424,628,-1000,412,-1000,473,1000,470,-836,1000,-1000,1000,702,1000,787,-1000,723,545,-493,-183,-125,1000,-675,1000,-1000,1000,1000,-400,718,371}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00711() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(java.lang.String):int",
            new int[]{228,-886,209,336,-846,-872,-634,423,584,-911,-643,836,-469,494,-872,111,-328,-546,910,810,-503,-616,-915,461,449,697,23,21,-978,-510,-985,-312,-480,-104,211,835,-559,485,750,-142,-678,-72,-829,806,-740,979,620,819,-684,759,-618,-417,545,-686,819,-712,-535,-533,-76,921,-535,-905,407,86}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00712() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(java.lang.String):int",
            new int[]{-1000,-643,739,-103,355,182,771,-1000,6,-404,-194,-1000,-544,1000,562,-429,749,-35,-359,-485,-520,12,1000,453,189,-138,424,717,515,-527,-189,-713,178,629,-375,281,-338,1000,40,-1000,-30,659,317,-227,-905,-463,487,794,-342,778,-320,1000,933,854,198,-240,388,-340,290,-302,876,813,-769,-481}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00713() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(java.lang.String):int",
            new int[]{1000,-318,-466,817,-552,-343,-495,-286,-97,-206,-287,1000,-815,-83,-709,-114,728,-20,910,826,749,-1000,-1000,80,-231,725,-19,363,-728,-553,-936,410,-480,83,-323,763,-298,-84,204,497,-823,-25,-227,806,-557,637,-41,739,-1000,1000,-962,277,-49,-432,782,-526,-868,560,10,-7,-493,-450,-443,-488}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00714() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(java.lang.String):int",
            new int[]{-521,-622,-614,-947,-380,-176,550,-468,270,565,-9,-573,137,801,663,-548,672,-68,-985,-248,-312,-682,177,-100,396,-865,748,485,-245,-248,262,539,776,-263,173,25,684,319,475,-387,710,956,-994,-947,-331,500,858,589,465,-622,-610,-910,203,204,-165,-192,661,-724,-326,14,559,-475,612,182}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00715() {
        org.junit.Assert.assertEquals("java.lang.Integer:MQ==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(java.lang.String):int",
            new int[]{-554,269,-1000,-363,-694,-401,369,309,589,1000,304,-300,-348,-597,-562,-551,803,594,-1000,613,-203,-1000,-507,-540,-1000,-1000,1000,170,-1000,938,1000,677,935,-507,102,-283,-1000,-111,-248,244,1000,259,-1000,-1000,-1000,1000,1000,919,-368,-1000,622,-1000,-106,-313,60,-275,1000,-1000,12,-338,300,-527,1000,-455}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00716() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(java.lang.String):int",
            new int[]{-1000,-985,274,-1000,-111,244,-38,566,-447,-322,411,428,-181,861,948,-70,-350,459,-429,-1000,112,569,684,-403,424,-1000,-805,978,1000,54,-66,101,1000,-641,80,241,32,605,-233,-226,-483,357,1000,496,-302,-714,-400,-173,1000,-1000,-309,-96,105,815,-392,-161,799,-560,-328,325,660,350,-558,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00717() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(java.lang.String):int",
            new int[]{373,55,371,1000,994,216,-1000,631,-1000,-538,-801,-258,-306,225,-135,-278,-30,508,530,-1000,506,1000,-268,-55,961,-1000,-843,622,1000,-88,-362,926,-1000,-587,-1000,-1000,-656,-1000,-534,1000,1000,-1000,1000,1000,1000,-1000,-1000,-681,1000,1000,-920,-1000,-1000,995,-1000,376,-1000,-1000,-1000,-1000,-798,-526,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00718() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(java.lang.String):int",
            new int[]{-346,668,368,-170,874,598,-404,-126,-489,-964,-730,619,905,989,-223,488,-864,153,165,-354,-755,-809,-131,-428,342,568,206,-140,-111,724,-904,-127,165,-924,206,-153,-801,-945,-956,-964,311,-806,-622,-402,786,135,-170,34,-776,358,473,-772,586,-590,823,-629,85,469,-234,-587,-264,187,621,61}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00719() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(java.lang.String):int",
            new int[]{412,-1000,1000,403,-640,-1000,-111,212,1000,-1000,-858,1000,-834,1000,-911,819,728,-720,1000,1000,-891,-899,-135,1000,421,1000,-38,-124,-984,-1000,-1000,-1000,-370,897,304,1000,-1000,1000,1000,-1000,-1000,694,-880,1000,-206,1000,1000,707,-841,1000,-1000,1000,950,-626,1000,-1000,347,-411,311,1000,-387,-196,166,358}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00720() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(java.lang.String):int",
            new int[]{-162,-1000,12,340,-767,-1000,-322,903,470,-380,-105,-726,-776,-624,-628,-362,237,348,-222,1000,-188,-912,-826,107,-681,-269,749,-453,-1000,846,-578,525,210,-594,-65,18,-1000,-186,720,-31,652,382,-1000,-499,-867,999,806,762,-614,-392,-857,-1000,-137,-844,250,-314,267,-710,-334,898,-378,-861,901,-86}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00721() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(java.lang.String,int):int",
            new int[]{829,914,1000,-63,266,-1000,93,679,141,269,1000,413,-546,-614,523,148,831,797,654,-193,-958,436,-700,-141,955,1000,372,487,106,-718,-267,648,889,-913,105,607,346,665,658,-580,-350,569,95,-89,-126,-468,-276,-111,975,-757,-237,-325,-184,-67,-122,-166,-673,-861,-1000,-1000,196,-804,-918,-348}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00722() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(java.lang.String,int):int",
            new int[]{-123,513,603,-484,-1000,-426,442,-508,1000,983,-352,1000,505,39,-484,773,573,-888,1000,-1000,-372,-1000,-510,-1000,464,625,-657,-231,437,-54,-532,1000,651,-1000,-365,-549,-492,1000,170,180,667,1000,-218,-707,-306,1000,-1000,1000,334,398,-255,-1000,-1000,1000,731,844,-292,1000,412,1000,1000,682,-1000,-444}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00723() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(java.lang.String,int):int",
            new int[]{167,71,332,801,697,-709,93,832,830,-171,741,57,-546,-740,372,-830,470,797,-311,-217,-418,-155,-540,-1000,-112,1000,982,-711,233,-1000,96,648,364,-1000,-229,1000,529,894,1000,-712,378,162,-466,466,-60,-917,52,-704,-14,168,-237,707,1000,-67,102,470,-785,-375,-369,688,1000,53,-1000,486}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00724() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(java.lang.String,int):int",
            new int[]{563,1000,1000,316,-741,-473,1000,-558,1000,811,-328,110,1000,1000,-306,1000,1000,-260,1000,-1000,-1000,-770,-1000,-1000,1000,1000,-1000,-1000,333,-918,-422,1000,1000,-1000,-757,1000,-1000,-1000,119,1000,643,-1000,-683,-1000,-592,1000,-1000,1000,1000,133,-950,-1000,-987,881,725,-88,-850,70,-297,1000,482,-181,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00725() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(java.lang.String,int):int",
            new int[]{-608,569,200,35,423,-746,-399,-558,1000,373,259,-294,-1000,1000,-241,29,-914,1000,-1,24,-291,97,-611,-62,715,429,-190,-754,400,-451,-174,404,795,39,-241,365,-236,289,-259,-281,126,-337,519,516,416,1000,-890,1000,623,-406,-671,79,-1000,260,717,-31,674,611,309,-383,240,-223,-1000,316}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00726() {
        org.junit.Assert.assertEquals("java.lang.Integer:MQ==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(java.lang.String,int):int",
            new int[]{5,-628,120,-680,578,-551,-1000,1000,-324,112,183,1000,-604,-533,-498,-832,-1000,982,-1000,1000,-136,557,87,1000,227,-448,1000,1000,-47,-654,657,-960,55,536,193,-558,1000,915,595,-430,-954,1000,1000,542,287,-1000,1000,-1000,44,467,243,682,-662,-1000,184,-442,321,-228,714,-1000,-758,831,699,779}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00727() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(java.lang.String,int):int",
            new int[]{540,-349,1000,253,1000,-1000,-201,1000,304,353,-264,1000,-92,215,-81,123,448,890,1000,-109,-752,57,-1000,1000,383,660,-118,579,-1000,-612,-111,230,1000,-717,467,-763,-1000,-359,1000,-848,-95,681,309,325,-62,-491,-695,-845,1000,-184,-730,-1000,283,-1000,1000,-477,-1000,-1000,636,-1000,-1000,-565,-362,-66}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00728() {
        org.junit.Assert.assertEquals("java.lang.Integer:Mg==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(java.lang.String,int):int",
            new int[]{-793,-121,163,106,-1000,-1000,-340,588,658,1000,-592,788,-999,-654,59,-1000,-794,512,-444,-1000,362,1000,584,21,-528,-205,353,-943,-1000,234,-308,44,143,-45,-390,-512,437,1000,-646,-75,356,-624,40,861,429,-284,-490,-260,-94,971,359,-73,1000,-331,-50,666,241,505,-390,-296,142,641,957,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00729() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(java.lang.String,int):int",
            new int[]{-656,-181,-79,-865,-822,-911,-763,472,-254,767,43,914,-292,535,-410,-676,-773,608,-884,325,-136,619,-324,669,300,-465,314,218,-47,-617,453,-430,707,249,-230,-379,91,280,296,103,-462,198,976,506,610,-745,516,-309,463,467,-12,-38,-775,-516,365,-567,482,-501,-76,-929,-427,254,290,-4}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00730() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(java.lang.String,int):int",
            new int[]{316,-370,149,1000,604,-1,358,184,304,23,779,626,-1000,-1000,1000,-305,407,881,-869,-184,-645,201,1000,-1000,-709,806,1000,534,-1000,-668,-1000,991,-1000,-841,1000,100,1000,1000,-80,-1000,820,693,-1000,-1000,-1000,327,1000,-241,-801,-1000,171,1000,-750,-64,131,19,-1000,1000,1000,926,1000,777,743,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00731() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(java.lang.String,int):int",
            new int[]{349,74,128,271,-179,-636,177,316,753,334,13,-989,-54,-787,-66,258,382,565,-34,-201,-508,409,57,-847,236,163,904,680,-206,-1000,128,735,156,-504,-70,1000,-209,-377,174,-617,43,0,-6,-752,-21,-405,134,-346,205,214,119,531,-424,-582,226,-515,-878,595,216,406,-112,383,812,11}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00732() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(org.apache.commons.lang.text.StrMatcher):int",
            new int[]{287,-784,-263,-584,1000,205,-821,497,1000,-890,-125,-926,572,93,-700,-1000,-608,-628,1000,-1000,-1000,70,-1000,-98,586,348,1000,1000,1000,1000,-644,79,-865,570,-7,1000,444,1000,-293,-985,-232,400,-1000,432,795,-313,701,1000,180,1000,-1000,-904,-832,600,-252,813,-469,467,-8,1,-1000,-619,386,-659}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00733() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(org.apache.commons.lang.text.StrMatcher):int",
            new int[]{1000,480,-551,-901,355,-813,-87,-784,967,-285,-1000,542,343,-281,123,-232,840,-703,1000,-291,-414,-885,1000,1000,58,1000,-940,-58,125,1000,-459,480,-1000,-1000,1000,1000,-172,-711,1000,-1000,-1000,-473,-1000,-818,321,825,1000,305,-1000,470,-729,1000,-1000,-96,1000,536,968,1000,-98,-1000,1000,-856,-315,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00734() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(org.apache.commons.lang.text.StrMatcher):int",
            new int[]{-1000,-754,484,978,395,364,-554,387,865,-185,614,-908,1000,283,790,136,1000,-658,310,163,-1000,1000,1000,-521,66,723,580,559,-62,-994,19,-345,346,767,-576,852,42,275,-295,256,-455,-982,-492,-899,-535,-836,-536,-1000,-719,698,-580,1000,-370,664,-515,-359,-217,-497,-340,1000,-792,-1000,709,-458}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00735() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(org.apache.commons.lang.text.StrMatcher):int",
            new int[]{-356,-296,-1000,448,-564,-241,-624,-847,-870,250,-830,19,-570,346,-50,768,207,-71,-408,-308,-380,-1000,-272,-47,-545,408,-936,-803,304,-236,-259,-438,294,-373,372,-997,461,173,763,343,-758,89,1000,184,112,-668,-682,96,-1000,-194,1000,-962,-642,-1000,79,1000,483,725,-138,-232,1000,-211,-1000,778}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00736() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(org.apache.commons.lang.text.StrMatcher):int",
            new int[]{-385,689,283,-204,-1000,-863,84,-483,-94,612,524,1000,-249,690,333,-13,-1000,987,335,1000,337,-1000,921,-50,-479,-286,-888,-1000,-1000,-21,212,695,1000,-1000,-104,-525,-573,-972,1000,465,-1000,197,320,4,419,1000,1000,-550,-102,-534,976,1000,-193,-594,135,124,275,1000,372,-1000,-329,530,88,381}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00737() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(org.apache.commons.lang.text.StrMatcher):int",
            new int[]{-435,17,238,648,104,1000,103,248,-23,475,-508,221,-468,-261,-438,-6,596,58,943,-1000,-167,-424,-1000,210,-51,-859,-72,-12,867,263,245,415,-65,537,-224,319,964,-252,695,-181,498,291,400,497,1000,163,-283,889,-1000,-400,400,264,-292,-722,72,974,-945,-336,-54,54,1000,-716,-907,754}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00738() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(org.apache.commons.lang.text.StrMatcher):int",
            new int[]{915,683,832,57,-66,-666,847,809,403,-939,-244,585,323,-376,692,-631,860,-295,734,938,678,973,501,845,132,-220,365,863,-420,-617,760,-173,160,-72,-262,-99,-890,-211,-863,-513,935,357,-497,-780,545,852,-736,-202,869,335,-442,-249,-611,729,587,-313,-469,-636,405,-980,-71,337,633,-234}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00739() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(org.apache.commons.lang.text.StrMatcher,int):int",
            new int[]{521,-580,-1000,85,624,1000,774,-522,8,365,709,-788,-651,539,1000,431,-872,363,-1000,-912,-23,-5,-303,900,34,-1000,-20,-657,1000,1000,574,-1000,367,305,-452,1000,967,485,1000,-1000,-179,307,-1000,-1000,532,-1000,-1000,325,1000,-835,1000,-1000,-540,-390,-880,-329,-644,83,1000,740,-612,-360,148,-312}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00740() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(org.apache.commons.lang.text.StrMatcher,int):int",
            new int[]{-840,-810,79,-488,-568,94,-511,25,-875,-409,617,716,318,-669,745,734,358,762,641,-356,-539,241,-589,497,-169,649,-565,-184,-612,366,-233,599,689,460,-23,-298,-224,-32,-488,296,289,-708,361,-521,-559,882,-950,579,219,615,-192,-782,524,605,136,-230,864,499,929,479,-297,-232,-179,-750}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00741() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(org.apache.commons.lang.text.StrMatcher,int):int",
            new int[]{-101,-1000,-824,-1000,-1000,481,-751,252,-365,432,1000,419,225,-103,492,-868,-1000,-470,372,114,744,1000,-483,684,-90,220,-325,955,39,-625,431,-715,-862,-431,-1000,-286,41,359,748,-290,495,45,-1000,-424,-1000,-537,-836,1000,367,784,248,-1000,823,-561,-82,-469,-429,632,-294,-545,-1000,-512,-125,-746}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00742() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(org.apache.commons.lang.text.StrMatcher,int):int",
            new int[]{1000,985,1000,1000,19,182,-973,85,-442,247,89,-1000,96,1000,1000,-230,-1000,355,44,1000,-1000,759,504,-596,-40,-10,816,823,-748,712,822,-1000,-1000,438,-44,-655,207,-1000,317,248,-514,-777,1000,-100,611,253,-1000,477,-549,1000,-812,503,609,-924,-1000,-250,-1000,-998,1000,-1000,-945,1000,346,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00743() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(org.apache.commons.lang.text.StrMatcher,int):int",
            new int[]{-997,-1000,523,426,-103,1000,697,-286,-32,408,424,421,-1000,-539,535,1000,307,1000,170,-113,22,-1000,5,749,-52,-1000,-813,-221,727,369,910,-94,-611,-49,549,899,1000,622,1000,-1000,-903,-68,-1000,-960,449,-421,473,1000,-366,-928,359,-328,-222,93,433,-64,-206,712,759,102,-1000,455,628,789}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00744() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(org.apache.commons.lang.text.StrMatcher,int):int",
            new int[]{-380,398,-287,894,-1000,-37,1000,427,-1,727,562,882,-663,-523,-571,23,-769,-53,-100,-1000,-1000,-1000,-357,112,974,1000,-949,-661,398,1000,-287,-91,749,-591,833,254,-1000,175,-42,-90,36,1000,-570,-14,-490,506,331,-498,-634,-202,598,0,-1000,555,75,353,965,422,-131,1000,339,-1000,-716,401}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00745() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(org.apache.commons.lang.text.StrMatcher,int):int",
            new int[]{109,-580,-368,-304,394,599,-830,1000,-518,422,709,-1000,-795,-60,1000,1000,193,-144,-1000,-1000,391,-524,-480,676,-126,-784,-324,1000,714,390,835,-898,109,-303,-950,1000,867,-309,959,-469,922,141,-159,-814,857,-871,-543,512,799,-1000,790,-640,-313,-642,-994,-632,-1000,-129,1000,-36,-596,50,-448,501}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00746() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "leftString(int):java.lang.String",
            new int[]{787,-988,-1000,75,464,-406,-616,879,73,-602,344,-640,94,-47,-350,988,857,542,179,-674,-776,1000,0,563,-223,569,632,494,-327,-1000,-1000,276,-730,-705,-920,-1000,-1000,238,-342,1000,-74,-702,385,521,710,-30,-685,-188,861,-272,702,-516,386,299,-666,-99,-941,48,-528,997,350,-1000,-97,-168}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00747() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "leftString(int):java.lang.String",
            new int[]{-1000,-417,-47,597,939,690,909,467,-38,642,-393,-676,1000,1000,-1000,150,-1000,1000,-92,-599,-375,-601,-232,-417,-340,-57,1000,490,-698,-580,-948,426,132,215,104,-1000,-780,472,-652,211,-1000,254,-666,380,1000,-321,-898,-1000,519,-1000,726,72,-48,591,-1000,1000,176,45,145,507,320,-900,-1000,-646}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00748() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "leftString(int):java.lang.String",
            new int[]{116,-593,-870,187,459,-312,-866,623,-587,-151,-570,-209,132,497,-73,894,857,637,-148,-664,-658,924,-399,494,-384,-104,659,723,-504,-594,-922,21,-544,89,-384,-935,-947,171,-371,464,-41,-825,58,-50,833,138,-519,-19,769,-124,39,-231,862,475,-666,93,-472,765,-150,428,693,-221,-664,-108}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00749() {
        org.junit.Assert.assertEquals("java.lang.String:AA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "leftString(int):java.lang.String",
            new int[]{45,92,-1000,577,-162,1000,-126,849,-398,-494,102,-872,487,-147,-59,560,137,668,-301,-183,-107,-65,-1000,1000,363,369,1000,7,-595,29,-812,-747,61,556,654,-912,-877,-1000,888,-897,240,-1000,-833,-540,1000,-345,-792,217,539,-716,-401,-767,-993,854,-669,-483,1000,-505,296,-790,-534,509,424,-657}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00750() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "leftString(int):java.lang.String",
            new int[]{-1000,-1000,-155,25,1000,638,-212,482,-17,-168,454,10,-284,-243,205,587,543,430,1000,262,773,1000,1000,-580,-932,461,283,83,800,-762,207,1000,-671,-1000,-1000,-1000,173,1000,-1000,1000,-156,-65,690,691,235,12,36,-1000,151,-1000,886,-45,811,-86,-838,285,-1000,-131,-75,953,514,-947,1000,160}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00751() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "leftString(int):java.lang.String",
            new int[]{269,-1000,870,350,-912,-436,-181,406,-605,452,-478,-859,-292,-443,-260,-680,322,380,1000,-242,-763,397,-156,-1000,761,499,0,797,-513,-580,-1000,114,151,-83,-484,179,303,-1000,1000,-1000,-245,-55,-400,943,477,114,1000,-191,2,-369,659,-127,497,574,575,-540,564,-165,-1000,777,916,-667,-1000,264}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00752() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "leftString(int):java.lang.String",
            new int[]{123,452,881,859,785,-212,357,455,-954,65,-124,927,502,320,616,132,-979,-996,-290,423,796,758,-750,901,-673,488,-218,793,908,-356,-28,103,447,228,-257,-74,981,525,144,-67,-872,797,-496,478,909,-751,6,-545,-149,478,-300,-381,98,292,209,419,-627,312,-91,-446,69,-914,163,-545}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00753() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "leftString(int):java.lang.String",
            new int[]{1000,-1000,-704,-702,1000,-352,-552,485,-115,-211,385,-733,-377,369,-923,751,27,561,1000,-1000,-1000,877,518,-454,-269,405,230,1000,-1000,-1000,692,1000,-1000,-1000,-1000,-904,-517,286,-178,1000,493,-582,1000,1000,529,437,177,-671,1000,8,1000,-1000,1000,-194,-618,599,-1000,-4,-609,1000,1000,-1000,-1000,774}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00754() {
        org.junit.Assert.assertEquals("java.lang.Integer:ODcw", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "length():int",
            new int[]{-477,929,-1000,-1000,886,177,414,-723,873,-870,-743,1000,-643,724,-95,574,452,562,870,803,-732,-796,-958,37,-333,297,1000,-1000,258,799,-323,-302,207,-284,232,1000,432,-838,1000,397,-989,1000,-531,1000,1000,269,-1000,-509,1000,-42,1000,-1000,1000,-1000,237,1000,-620,-780,-100,221,-955,-98,491,-936}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00755() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "length():int",
            new int[]{-180,580,-343,-911,-946,-418,-247,319,101,-722,127,698,318,-348,221,-319,-171,-698,303,212,19,-839,-901,356,-911,-13,642,-405,-716,699,327,-955,797,-746,62,181,-702,351,914,-883,-479,990,627,958,433,-330,-969,-718,102,-152,496,-566,603,-861,-684,985,-966,756,-823,447,32,642,-270,120}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00756() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "length():int",
            new int[]{1000,568,825,468,224,-538,-1000,-975,101,1000,1000,1000,100,834,-200,114,196,264,1000,507,19,-107,1000,918,1000,-1000,568,1000,-269,1000,-146,1000,1000,-946,-1000,-440,1000,693,154,448,1000,990,-657,-913,-699,-330,-1000,1000,-311,1000,-753,901,603,1000,1000,1000,1000,-416,378,344,1000,1000,193,120}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00757() {
        org.junit.Assert.assertEquals("java.lang.Integer:Mzc=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "length():int",
            new int[]{1000,456,29,-553,373,-230,-536,-803,597,-461,-327,1000,131,20,-381,-48,741,-639,1000,254,-411,-1000,42,-398,880,167,-147,-461,248,845,-1000,447,584,-628,-574,-618,546,1000,733,500,-404,1000,-566,-682,-435,-823,53,396,1000,-361,-222,99,-337,-1000,-283,730,290,923,1000,218,1000,763,757,-193}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00758() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "length():int",
            new int[]{405,-1000,-207,-391,-1000,-566,-78,292,-230,445,-50,-766,43,-1000,1000,-1000,-1000,-1000,-1000,-1000,-202,889,1000,-587,-128,-1000,-1000,1000,-528,-1000,351,52,-706,-913,-488,-1000,382,1000,-1000,-145,1000,-1000,1000,-1000,317,-217,514,-400,-865,654,-1000,1000,-195,1000,-1000,-1000,473,888,-25,-556,1000,-350,-1000,433}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00759() {
        org.junit.Assert.assertEquals("java.lang.Integer:NA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "length():int",
            new int[]{1000,-883,851,-619,-376,-557,-496,800,-750,114,-582,-12,-92,-326,-244,-1000,-244,-315,-309,-976,-554,396,470,-1000,-456,-385,-464,243,901,-39,877,1000,778,-492,773,-374,350,382,-792,22,819,-300,-212,-330,160,619,-664,-1000,-6,-1000,-819,1000,-866,1000,-646,591,-779,-1000,-1000,-796,1000,-31,-574,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00760() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "length():int",
            new int[]{1000,-1000,240,109,864,-497,-881,-509,771,185,-10,427,-146,-522,651,-141,28,-914,817,-8,695,-993,29,162,965,-1000,-421,1000,50,-343,753,192,406,500,-817,-646,52,1000,480,-325,1000,107,-298,-930,-438,-1000,-681,842,189,358,-1000,586,-255,-1000,513,-92,955,923,927,-1000,1000,962,117,29}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00761() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "midString(int,int):java.lang.String",
            new int[]{-424,554,1000,-378,935,556,-71,242,1000,-806,-253,823,1000,-424,-755,-1000,-592,-1000,-1000,651,1000,-617,1000,-1000,1000,-452,551,-152,1000,1000,1000,-785,-1000,154,256,-1000,-339,157,1000,-1000,721,-1000,-675,858,235,479,356,733,419,-1000,1000,324,-56,-369,-1000,-1000,386,-848,-1000,-394,801,485,78,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00762() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "midString(int,int):java.lang.String",
            new int[]{-33,-444,708,837,272,-737,-326,191,425,988,1000,888,-212,20,-312,689,265,-235,1000,61,602,-241,24,967,561,-927,234,-767,999,1000,852,451,-1000,1000,1000,400,1000,-224,-452,337,1000,-470,-123,-509,432,901,584,-22,330,-1000,874,859,1000,202,-683,400,400,-595,-232,-284,323,1000,1000,250}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00763() {
        org.junit.Assert.assertEquals("java.lang.String:AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "midString(int,int):java.lang.String",
            new int[]{-1000,509,1000,1000,1000,136,269,-389,898,422,1000,1000,768,1000,-948,-675,449,-898,256,742,873,-197,1000,-433,1000,-301,1000,-1000,957,-321,852,245,-1000,767,618,-1000,1000,847,948,-1000,914,-741,-730,-1000,-313,1000,-158,1000,-535,-840,842,741,232,-369,-1000,-1000,-1000,-1000,-1000,-97,1000,424,902,-815}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00764() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "midString(int,int):java.lang.String",
            new int[]{-626,-281,176,1000,364,-611,1000,-1000,-782,1000,-574,82,-1000,1000,-463,757,155,171,1000,645,-318,-9,1000,1000,-108,-698,258,-948,1000,-929,-1000,964,-931,-876,663,323,-142,468,-442,123,960,-688,-689,-1000,-94,990,-403,486,-210,345,-113,-13,577,-142,-1000,301,25,-394,93,519,-83,400,858,131}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00765() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "midString(int,int):java.lang.String",
            new int[]{-1000,362,798,363,1000,1000,396,-743,1000,191,327,1000,400,400,-1000,-949,715,-1000,-615,264,1000,-17,402,-1000,1000,1000,1000,-741,940,-1000,1000,-127,741,544,-461,-1000,-202,923,1000,-1000,-257,613,282,-397,-64,131,-60,833,-235,-1000,308,647,-1000,-290,-806,-1000,-1000,-760,-1000,157,1000,-403,-589,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00766() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "midString(int,int):java.lang.String",
            new int[]{-1000,568,856,439,618,197,313,-938,746,-927,-791,469,768,1000,-637,-829,310,-809,-672,1000,348,-193,1000,-520,664,158,360,-655,-434,-350,-400,255,-1000,-1000,257,-1000,-1000,826,885,-1000,303,-1000,-1000,-958,235,1000,-309,1000,153,-607,673,-220,-320,-637,-1000,-888,-1000,-371,-794,-135,618,-756,-76,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00767() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "midString(int,int):java.lang.String",
            new int[]{-219,230,980,-682,721,404,-96,-320,597,-649,-253,823,578,-550,-555,-1000,-636,-866,-1000,1000,911,-230,-216,-612,1000,-438,789,-484,1000,1000,1000,-767,-817,154,285,-651,-339,-753,561,23,1000,-1000,-532,1000,501,314,598,438,742,-1000,1000,226,-56,-181,-905,-1000,764,-758,-890,-1000,706,537,-121,-665}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00768() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "midString(int,int):java.lang.String",
            new int[]{115,617,358,233,45,-1000,644,888,735,301,-272,-265,-37,864,599,362,-709,-588,-273,729,-786,833,378,-113,-300,-632,383,-939,-457,970,746,744,748,-149,268,-63,-516,517,-235,291,-904,-35,-627,491,-909,-861,-54,999,-924,214,636,-28,205,854,-678,46,869,169,810,558,59,-206,-588,721}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00769() {
        org.junit.Assert.assertEquals("java.lang.String:Kw==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "midString(int,int):java.lang.String",
            new int[]{-893,503,997,702,618,197,331,-389,746,-927,-582,469,-212,1000,-455,-865,299,-809,-605,826,348,-156,1000,-520,664,-209,360,-631,-434,-350,-473,419,-1000,767,1000,-1000,-579,565,948,-1000,598,-1000,-730,-958,336,995,-134,748,265,-607,1000,-61,-320,-225,-1000,-888,-1000,-319,-794,-80,181,-70,672,-796}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00770() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "midString(int,int):java.lang.String",
            new int[]{-159,-1000,-896,941,58,-266,1000,77,-1000,1000,236,-311,-1000,66,6,1000,287,37,770,645,102,657,-1000,815,-576,-1000,-47,-820,1000,-1000,-343,466,314,-138,452,1000,1000,-250,-1000,1000,589,712,-689,-1000,18,-410,-20,-352,383,587,-572,-326,1000,-213,-347,223,477,59,326,569,-373,676,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00771() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "minimizeCapacity():org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-625,1000,-824,-23,-48,-601,-248,850,994,841,-443,524,1000,972,-668,-195,-701,17,574,365,895,-404,27,230,99,-349,983,1000,-616,-996,-549,543,348,-83,854,473,-592,564,862,274,839,-647,-863,-200,486,451,-88,58,143,186,11,347,-940,-870,-135,197,-49,37,-825,-781,31,315,-17}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00772() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "minimizeCapacity():org.apache.commons.lang.text.StrBuilder",
            new int[]{205,333,-661,1000,562,346,-24,-157,-241,-90,-479,-173,-209,-366,4,-688,-44,-1000,-223,1000,-169,-798,-178,-446,574,-360,618,-817,-67,475,-130,-362,-703,45,707,47,1000,-140,51,509,-739,63,-1000,109,-723,686,-991,-409,-338,973,57,-172,-159,-447,-348,-294,304,331,-273,317,319,291,-57,88}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00773() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "minimizeCapacity():org.apache.commons.lang.text.StrBuilder",
            new int[]{567,-625,569,412,678,714,-601,-662,850,1000,601,41,1000,569,205,-713,-636,-65,-461,686,1000,433,-341,27,841,361,-826,1000,-252,-1000,-821,-382,851,348,400,363,388,-658,181,1000,756,1000,-1000,453,598,711,1000,412,-597,1000,601,11,-1000,-1000,-1000,-514,-740,-49,205,-879,-781,221,-264,-193}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00774() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "minimizeCapacity():org.apache.commons.lang.text.StrBuilder",
            new int[]{69,-349,385,160,158,939,782,848,279,1000,567,839,877,-113,-616,-266,-194,582,-230,1000,1000,434,-897,-1000,-205,-169,-752,899,-920,-1000,-745,-117,192,519,1000,90,126,-581,704,1000,377,1000,-1000,-402,426,554,1000,259,271,1000,-87,1000,-458,-247,-748,-68,-1000,-264,-842,-1000,-1000,-428,67,174}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00775() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "minimizeCapacity():org.apache.commons.lang.text.StrBuilder",
            new int[]{-673,-170,350,-103,-506,-106,1000,664,1000,1000,-558,410,457,4,-1000,-192,566,130,556,574,365,1000,-1000,-364,-74,-531,-189,912,336,-616,-818,70,-22,1000,1000,1000,239,-441,1000,617,-162,-85,-834,-1000,-2,174,636,154,1000,143,-489,11,211,-432,-750,13,83,-400,-889,-1000,-1000,-937,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00776() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "minimizeCapacity():org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-187,-619,213,-282,-542,759,384,1000,639,-1000,523,-82,-189,-1000,147,166,-718,613,574,-544,773,-1000,-364,756,-1000,1000,34,280,284,-189,820,-857,930,1000,1000,-446,46,805,168,-521,-742,566,-1000,-1000,181,-316,-131,690,143,-1000,-483,-48,224,-841,-757,764,-180,-1000,-837,-1000,-289,981,867}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00777() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "minimizeCapacity():org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-1000,224,1000,1000,211,-655,501,-1000,-929,1000,754,1000,501,533,-264,-1000,-436,-1000,1000,1000,-1000,1000,-821,1000,1000,-1000,999,-1000,-1000,-700,-1000,557,-680,-217,1000,123,-440,-1000,168,314,-976,-619,1000,1000,1000,561,-804,-1000,553,1000,1000,-312,344,-556,326,-856,-77,1000,589,130,1000,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00778() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replace(int,int,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{326,-1000,-190,1000,-1000,168,-508,473,670,758,-984,-1000,-418,-1000,-633,-1000,1000,-646,-90,1000,295,-542,-223,-1000,-779,639,719,71,1000,-630,-1000,-116,353,916,-1000,-889,-407,360,562,249,594,340,934,-137,1000,-485,-1000,-683,-1000,1000,628,1000,1000,-227,192,-1000,-393,-390,-1000,-1000,1000,-59,393,-684}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00779() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replace(int,int,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-948,449,-11,-558,173,425,756,483,-529,-581,-1000,-510,585,284,1000,-614,621,1000,490,-360,597,-788,732,-1000,-240,210,824,821,428,1000,-1000,471,-1000,276,-395,-240,-520,501,1000,-760,1000,177,128,-690,-930,1000,-289,-261,-1000,-1000,-1000,587,-758,-524,-116,1000,990,65,923,-442,240,-631,-751}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00780() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replace(int,int,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{56,5,323,972,-339,-936,-165,852,803,-281,-128,-617,-425,-39,3,338,-936,-14,1000,-22,-701,188,-33,-147,347,-292,367,131,1000,213,-104,33,430,206,45,-242,349,79,132,641,-476,48,765,-703,351,-674,-775,-733,-333,74,225,492,494,579,616,-93,728,120,23,-744,180,-95,-1000,316}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00781() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replace(int,int,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00782() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replace(int,int,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-70,441,16,-369,-466,282,-709,444,919,-1000,-468,834,408,1000,-8,606,-55,-587,-806,-447,520,-704,862,864,-373,-733,-8,211,10,1000,71,17,-740,911,770,-1000,-9,824,1000,-62,931,-176,-618,772,-637,367,-619,-712,767,-721,-436,1000,183,-726,96,150,-745,-1000,-947,311,-215,-203,494}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00783() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replace(int,int,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,377,1000,360,493,101,534,699,1000,-150,-307,-754,-887,874,824,1000,-496,686,1000,-509,-1000,324,-192,1000,-878,-199,710,745,914,341,1000,-1000,374,-871,-203,-54,1000,-607,1000,1000,-873,1000,762,-116,-431,-1000,248,223,42,-1000,-1000,-472,159,47,43,1000,325,1000,-1000,-109,-312,475,247,-515}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00784() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replace(int,int,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-147,-1000,240,1000,70,178,116,1000,616,91,-783,-1000,-1000,617,-1000,510,632,-60,862,320,-540,204,-189,-1000,-1000,362,1000,-1000,1000,-235,-1000,-865,687,1000,-343,-1000,1000,735,589,581,-602,728,1000,-125,1000,-812,-424,-409,-1000,-333,-115,886,1000,-140,395,-174,1000,395,-82,-220,1000,-340,57,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00785() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replace(int,int,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-1000,958,546,1000,1000,303,737,648,-529,-180,-868,-217,-291,-36,1000,-539,810,798,1000,-803,-585,-1000,1000,-1000,-766,1000,-808,156,1000,1000,-1000,1000,-1000,1000,-357,1000,-829,-6,1000,110,-835,401,-89,-1000,-102,865,-601,-153,-1000,-1000,-1000,-100,-142,-742,1000,1000,-138,1000,10,-771,-154,-1000,-443}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00786() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replace(int,int,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-561,-668,1000,1000,-24,-509,-636,517,39,1,-78,-377,-1000,-121,24,-242,-625,386,738,-248,224,-6,1000,841,-375,-766,779,759,424,27,500,395,-309,806,-477,-432,600,-421,1000,-342,848,-1000,1000,564,-267,-422,-11,-293,-175,50,936,698,232,1000,1000,-425,-331,1000,-718,-1000,1000,-329,114,-315}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00787() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replace(org.apache.commons.lang.text.StrMatcher,java.lang.String,int,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-579,998,-823,-966,-22,918,-346,252,-920,-518,-105,221,-345,73,-488,-596,295,-945,-242,-321,182,-165,582,724,447,-737,-74,570,-780,785,-186,-972,354,83,-984,-164,33,464,-170,-351,-716,717,885,-741,-171,-219,778,819,-401,182,815,256,773,-86,-823,545,-747,206,-589,-932,123,448,-680,890}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00788() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replace(org.apache.commons.lang.text.StrMatcher,java.lang.String,int,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-797,327,-751,-432,861,469,1000,-109,-952,-1000,347,-453,1000,-573,284,-1000,-505,1000,-1000,114,432,1000,-576,370,1000,427,355,478,-799,-799,-1000,-1000,-1000,109,755,1000,-1000,980,1000,-70,-951,383,1000,966,317,61,1000,322,822,-1000,-917,-180,215,1000,-1000,1000,385,-441,147,348,-484,372,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00789() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replace(org.apache.commons.lang.text.StrMatcher,java.lang.String,int,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-1000,1000,1000,-72,-501,333,-136,512,249,-249,-654,1000,973,1000,-659,554,1000,81,273,118,469,-1000,537,546,971,387,17,127,-146,-351,442,43,-730,-29,672,-82,-790,-916,601,-432,-398,-61,305,-353,137,276,-284,-94,-550,-846,-638,258,-467,-103,-469,697,-773,-70,-113,10,-511,323,580}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00790() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replace(org.apache.commons.lang.text.StrMatcher,java.lang.String,int,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-955,-299,-834,106,-471,-183,559,600,-1000,-1000,364,193,628,139,556,-1000,1000,651,-195,812,529,1000,1000,801,869,880,-34,-151,-112,-602,144,-887,-626,625,755,1000,-1000,907,1000,435,-1000,658,1000,549,376,-136,1000,449,805,-1000,-408,-537,1000,1000,-1000,1000,453,-375,152,-522,-383,464,-796,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00791() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replace(org.apache.commons.lang.text.StrMatcher,java.lang.String,int,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,35,957,-572,215,1000,-307,544,-392,372,568,94,-313,264,-494,1000,-614,-1000,538,-460,-916,-305,-405,-196,-590,187,-432,-617,-439,-106,-1000,-794,-84,-1000,-907,-713,436,72,-281,-457,-911,-1000,-282,511,-1000,3,-765,5,-666,836,-2,89,-700,-394,1000,-1000,615,-350,-749,711,626,-556,-374,5}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00792() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replace(org.apache.commons.lang.text.StrMatcher,java.lang.String,int,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-866,-1000,-618,-140,1000,-1000,-681,-554,2,406,528,-188,-1000,-168,-308,-49,10,-728,1000,726,1000,782,672,-697,-590,-808,-1000,-1000,694,-981,965,83,-1000,160,1000,-7,-638,1000,19,1000,639,605,-72,238,1000,-1000,-78,-125,-322,10,-872,-1000,159,765,-235,61,1000,976,931,418,1000,890,401,137}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00793() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replace(org.apache.commons.lang.text.StrMatcher,java.lang.String,int,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-731,431,-560,-398,296,-80,-674,341,-826,88,661,-1000,173,25,-50,-123,1000,-787,73,534,90,848,1000,-119,-749,-652,-1000,112,470,-806,-208,159,-1000,548,671,-146,117,48,258,497,-140,-514,393,-1000,104,-451,393,769,1000,321,-1000,-587,350,-369,138,51,288,-1000,-4,1000,239,-238,-14,459}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00794() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceAll(char,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{948,-1000,-164,-1000,820,-307,252,777,822,-385,-507,-114,862,-520,1000,115,595,1000,75,722,345,-367,-241,674,201,550,-1000,-1000,-13,-1000,-732,5,-1000,-147,1000,-717,774,-625,114,886,-778,-1000,-1000,378,-1000,110,-711,648,929,322,338,485,369,-386,-382,-1000,-254,477,-293,-472,845,-126,-151,236}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00795() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceAll(char,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{712,171,119,-303,-291,112,287,680,-400,1000,339,1000,-528,933,-318,-172,98,139,1000,408,999,-801,-146,-243,-47,404,316,-1000,169,-395,-368,-304,-101,-961,-1000,540,133,-1000,-102,658,-1000,-993,767,487,480,860,-73,554,-337,-503,-758,851,-446,603,-828,1000,-97,746,-1000,49,534,779,-652,537}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00796() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceAll(char,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{633,-455,439,-127,88,-896,689,-404,-1000,-909,-288,-757,-631,-1000,1000,1000,-172,1000,-1000,-54,-1000,700,-797,-609,-178,323,-935,562,-663,-304,-27,257,-565,1000,1000,-253,114,-835,-1000,-157,740,977,-221,-36,90,-1000,482,-207,862,564,931,-747,1000,-215,1000,101,-1000,-392,-195,-277,-171,-1000,771,-572}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00797() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceAll(char,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{883,-1000,589,-777,467,-11,56,-123,187,491,-3,-72,1000,-317,791,-49,254,1000,-85,750,257,-204,-223,643,-342,691,-881,-1000,-143,-763,-980,-11,-631,-994,567,-469,369,-1000,420,487,5,-301,-464,145,-63,320,-307,202,624,149,93,429,300,-78,-335,-6,-621,-206,-242,487,341,-534,-127,562}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00798() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceAll(char,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-576,-1000,968,-87,-187,736,578,-20,654,-534,0,-52,-793,-590,156,-601,313,627,-20,557,327,-647,-525,-1000,-343,10,-274,805,-104,71,373,-96,-558,374,696,-407,566,-361,142,-323,663,-211,327,9,30,-122,155,967,265,308,803,-394,630,42,-859,72,-762,-792,-20,-483,-297,99,-595,539}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00799() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceAll(char,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{461,14,-515,-47,117,-759,920,-180,304,-400,-455,250,-318,-192,792,659,-106,696,-248,-557,-980,842,-438,-252,-628,-33,-690,831,-921,-541,-585,-562,-318,947,982,274,791,30,-754,844,-252,977,-99,-341,-794,-499,834,145,517,551,586,-539,-44,480,736,-132,-103,-89,303,303,298,-838,276,-645}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00800() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceAll(char,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{27,-43,-963,-728,-266,-314,-202,348,-1000,1000,10,1000,-726,738,-318,396,74,-768,457,-383,-401,219,-380,267,-524,172,233,-310,-431,-572,-548,-984,72,-182,-566,723,137,-888,-189,279,-1000,201,1000,-362,-458,293,686,-148,-734,43,-290,-161,-648,638,327,426,-197,981,-844,415,195,227,137,-93}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00801() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceAll(char,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-640,-548,-544,1000,-1000,304,-452,-97,-385,-769,226,1000,-44,1000,1000,192,1000,-846,-357,-1000,1000,-834,689,-454,978,-1000,1000,-706,-1000,-1000,-1000,949,-650,1000,-1000,1000,600,1000,1000,-804,1000,-1000,-720,-1000,-1000,-148,-665,-239,968,1000,-625,-588,275,602,-815,-806,613,486,-1000,934,-1000,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00802() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceAll(char,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-16,-1000,-400,533,-80,534,512,-177,1000,-400,1000,1000,790,1000,-400,-883,-572,-457,-248,-733,839,600,-221,-312,-1000,-400,-183,-1000,-1000,-1000,-1000,50,-263,-1000,-400,539,-356,-739,-754,-767,-649,977,-99,676,495,-499,504,683,1000,-436,586,-400,-427,933,736,766,537,24,1000,303,298,95,-1000,985}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00803() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceAll(java.lang.String,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-46,98,-168,-330,-554,-904,166,-537,256,249,227,-1000,-1000,1000,256,1000,-329,-920,-1000,-1000,-468,-1000,-1000,1000,-453,511,-519,76,781,137,348,-48,-377,-431,146,-1000,-105,-1000,-343,-894,-759,301,-1000,-1000,-1000,694,-1000,-555,569,-221,-453,1000,508,-805,1000,-322,-354,870,-276,505,-1000,-938,-1000,-303}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00804() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceAll(java.lang.String,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,42,-881,-400,-418,26,804,987,1000,719,1000,1000,811,-310,-78,-641,207,-674,290,-599,1000,1000,1000,-426,-295,-1000,-466,-321,-870,543,-106,-1000,222,-176,234,597,-71,1000,783,-1000,-764,-1000,141,1000,463,-609,-668,-788,780,467,1000,-1000,-1000,-1000,-393,-660,1000,854,440,346,-66,1000,267,168}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00805() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceAll(java.lang.String,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{116,-1000,1000,-601,-695,-643,508,-939,-266,-54,-141,859,-110,1000,-3,-194,235,-1000,-122,802,-1000,-471,-273,1000,-670,1000,488,346,-497,-1000,-848,-427,345,-791,-257,56,795,-1000,-32,-325,-1000,-146,-473,-1000,-308,874,567,720,-775,-800,1000,-71,690,-714,1000,-1000,-621,-1000,-797,250,324,48,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00806() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceAll(java.lang.String,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{413,-301,1000,-1000,-1000,34,173,-688,-1000,540,-1000,742,-216,1000,-1000,1000,-1000,-948,-240,1000,-1000,-963,-676,-91,-1000,511,129,794,-458,310,-864,754,-781,-1000,-1000,-542,1000,-1000,1000,1000,1000,-140,-1000,-1000,-164,1000,1000,1000,-1000,-731,1000,-663,1000,1000,904,-1000,545,-562,-390,-986,827,-495,1000,-508}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00807() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceAll(java.lang.String,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{907,1000,1000,1000,-197,-1000,-190,266,-764,-158,227,-32,-1000,1000,-84,1000,-149,-1000,-1000,-1000,120,-1000,-278,836,-1000,696,283,1000,-39,941,-477,-107,-1000,-429,98,-1000,1000,-787,-721,120,472,709,-625,-1000,175,613,-823,517,-479,-1000,-132,1000,1000,99,1000,-938,-1000,130,116,505,-292,-1000,-1000,-978}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00808() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceAll(java.lang.String,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{861,-1000,189,-468,-637,-1000,923,102,223,-121,948,-763,-249,986,101,544,-793,-846,-256,-237,550,-1000,-492,869,600,301,-657,138,-60,-335,398,722,-169,-1000,-461,-295,434,-1000,149,-621,-1000,435,-1000,-1000,-684,-360,28,-730,561,52,-1000,86,-313,-1000,642,688,469,1000,-711,-315,-1000,282,-541,-352}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00809() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceAll(java.lang.String,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-1000,-322,269,-982,-597,-469,731,595,402,604,-703,-1000,673,-659,1000,-379,-1000,-841,-450,367,-818,-915,-108,344,383,-566,115,309,879,-603,522,-81,208,819,-926,-605,-548,659,76,110,1000,212,180,-609,765,-1000,-68,189,-1000,-1000,-443,-157,39,-131,515,966,1000,166,136,-1000,-887,-165,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00810() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceAll(java.lang.String,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{20,-1000,-1000,-1000,-901,-690,1000,-1000,714,584,1000,-176,-328,855,1000,131,955,-593,-53,-501,-170,734,-828,1000,1000,566,-746,-1000,174,-999,779,218,1000,113,-714,-384,-1000,-1000,624,-707,-1000,-32,-1000,-1000,478,-1000,223,-785,824,157,-159,101,-805,-714,397,953,19,547,311,-1000,-415,487,541,680}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00811() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceAll(java.lang.String,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-511,-1000,-1000,-1000,-1000,1000,-1000,714,908,-400,-1000,-423,1000,1000,612,1000,-649,-478,-1000,-175,244,-1000,1000,662,-49,-1000,-1000,436,-321,1000,1000,1000,113,47,125,-892,-1000,567,-1000,-1000,-795,-1000,-1000,129,-1000,-1000,-1000,824,1000,493,544,-897,-719,551,261,45,1000,311,-487,-1000,545,282,688}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00812() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceAll(java.lang.String,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-400,-853,-974,1000,1000,1000,962,1000,808,903,-1000,1000,161,-1000,-1000,-1000,-1000,-971,1000,-310,1000,715,1000,108,-706,168,1000,1000,-440,-226,-1000,-1000,-1000,36,-702,9,1000,1000,400,350,-197,-1000,1000,-691,1000,64,-407,-765,524,-1000,1000,-1000,716,-1000,146,-1000,273,-119,-177,945,1000,-408,-132,-752}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00813() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceAll(java.lang.String,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{758,-853,-632,-848,-105,-597,-469,-826,992,477,842,-940,63,303,1000,179,743,-947,-2,12,364,307,-1000,-7,382,736,-790,-680,434,779,1000,989,363,-1000,755,-14,-1000,937,-420,-1000,-1000,165,-430,-83,-248,553,2,-904,615,846,-826,243,424,-1000,463,1000,720,1000,-1000,-213,-999,1000,-96,-440}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00814() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceAll(java.lang.String,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-1000,320,-964,-783,-936,1000,775,-504,-1000,-1000,-952,-168,311,1000,778,-285,-404,-955,-72,-941,-362,-20,-91,-884,1000,-406,-849,702,251,-651,-620,272,-1000,277,-715,1000,782,227,-694,-1000,-1000,-1000,93,449,559,-607,-565,816,-255,-847,-620,-558,-1000,-1000,421,-516,1000,-400,-593,1000,-898,-310,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00815() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceAll(org.apache.commons.lang.text.StrMatcher,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,338,-776,-621,1000,35,219,132,-322,-499,-1000,562,696,850,407,-59,250,-811,760,-38,-750,-76,1000,-305,1000,-816,545,110,1000,559,1000,1000,-107,1000,707,215,-1000,-617,1000,595,-1000,-896,-458,-146,1000,-654,-688,-576,761,-143,1000,-26,-1000,-252,326,434,90,1000,-604,-1000,606,751,-771,20}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00816() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceAll(org.apache.commons.lang.text.StrMatcher,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-198,252,269,-169,-16,846,-26,-798,-489,-132,-442,-115,654,124,908,549,909,144,-516,-822,265,-291,-867,869,377,-928,-647,713,-116,-246,-325,-253,-670,-36,60,-628,934,-61,20,-820,796,-208,582,704,29,822,105,-766,786,653,-490,-421,-811,-925,512,-619,-260,988,85,-539,984,-523,-420,525}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00817() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceAll(org.apache.commons.lang.text.StrMatcher,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{939,110,471,10,-296,-417,641,-402,-467,768,432,73,732,951,796,835,47,-589,-625,-840,-837,-296,953,4,179,60,219,-646,386,309,575,630,-159,974,932,-868,-934,383,296,-983,502,937,-704,889,295,68,748,-292,423,807,-141,455,-755,-598,736,739,-887,941,-506,-648,878,585,-564,-283}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00818() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceAll(org.apache.commons.lang.text.StrMatcher,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,1000,261,1000,8,-364,-1000,1000,-840,-363,316,116,519,-781,560,230,93,-768,-61,-1000,-385,813,-234,1000,683,1000,-656,-1000,-537,11,1000,291,60,-1000,-697,-1000,-593,-1000,463,-1000,1000,186,-1000,-1000,523,-1000,-524,-1000,-1000,1000,-521,-1000,-1000,684,-616,-455,939,-1000,1000,-830,-525,12,-1000,-720}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00819() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceAll(org.apache.commons.lang.text.StrMatcher,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-773,626,-297,-7,820,-581,392,518,197,-66,-307,286,1000,200,9,-604,-804,-750,1000,305,-1000,-513,1000,-742,703,-520,-24,42,1000,713,877,1000,928,1000,697,1000,-1000,19,1000,-132,-1000,-490,-785,-132,1000,-252,-950,129,288,-988,764,49,-961,-556,980,395,-798,869,-896,-322,594,511,1000,60}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00820() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceAll(org.apache.commons.lang.text.StrMatcher,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-613,344,566,439,-218,-63,-663,-229,135,-215,220,509,608,-1000,912,456,-70,-323,-590,-1000,-657,-582,344,594,435,60,-708,-310,-745,402,264,-347,621,-466,-252,-948,-48,-295,255,-1000,1000,-763,-735,-116,91,644,-117,-698,271,-535,-709,-618,-1000,-1000,1000,-435,-649,120,612,-648,706,-71,-480,176}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00821() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceAll(org.apache.commons.lang.text.StrMatcher,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-178,529,405,289,-546,-110,-1000,-579,579,-757,445,69,1000,1000,-821,280,203,-1000,-1000,1000,-7,-1000,1000,1000,-1000,-1000,-28,-1000,868,73,-654,-714,-1000,-542,-1000,1000,-252,-609,-1000,1000,-1000,1000,12,-673,1000,1000,-1000,121,1000,-1000,392,-1000,-598,116,-953,-494,1000,902,-1000,285,-407,182,-617}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00822() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceAll(org.apache.commons.lang.text.StrMatcher,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-487,-544,-1000,816,274,-518,-13,459,-519,-757,192,319,-163,573,570,585,-555,-1000,435,-1000,-498,1000,-688,674,-912,737,-122,850,-581,1000,784,-481,1000,-581,1000,-511,-95,852,1000,-1000,-949,246,73,1000,253,-709,206,833,-1000,866,54,-41,-770,-372,231,252,980,-1000,-179,9,1000,-262,652}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00823() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceFirst(char,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{922,-247,214,-59,1000,-390,-746,505,1000,-483,-937,1000,-978,1000,958,223,-766,624,-847,-623,1000,1000,-735,175,1000,-1000,-292,-81,263,332,1000,605,-267,857,-977,11,-161,-42,228,-785,-1000,392,443,393,-473,526,559,-707,707,-778,458,-150,370,-27,476,870,593,38,-703,707,-1000,-1000,1000,100}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00824() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceFirst(char,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-154,-327,384,304,-518,147,-524,-597,-449,612,1000,343,1000,-874,-1000,-780,1000,-880,381,-620,-357,-371,625,-737,-1000,-184,-782,-664,143,-274,-936,-1000,350,-716,228,686,1000,-724,262,-404,372,879,378,33,230,-1000,388,1000,-815,779,-1000,-988,174,851,94,715,-1000,417,814,24,1000,1000,471,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00825() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceFirst(char,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-1000,177,-920,1000,-391,362,-966,1000,208,-1000,1000,-893,755,1000,-314,-1000,1000,-1000,-1000,-1000,462,686,-273,613,3,-911,-67,63,998,1000,720,-677,1000,-1000,276,583,1000,-1000,-528,-781,-21,-486,-1000,-826,988,963,-259,656,782,-96,-530,-276,404,1000,1000,-283,-361,-717,1000,-202,-583,707,677}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00826() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceFirst(char,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{922,1000,610,691,-126,119,-196,-360,1000,1000,1000,1000,631,-1000,-1000,-99,49,624,579,-1000,1000,1000,359,-1000,-1000,-972,260,318,143,-1000,16,-711,293,857,-599,693,-382,-499,1000,-823,243,1000,443,1000,-473,526,-1000,15,-779,1000,-1000,-500,908,221,716,870,-1000,-772,-319,-993,930,963,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00827() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceFirst(char,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{922,-474,-703,292,-394,-390,9,-304,-113,1000,1000,400,-306,-660,-494,1000,-815,-1000,754,-623,1000,190,1000,-50,-385,440,675,67,370,-1000,1000,-845,974,510,-771,11,380,-825,-800,70,648,1000,443,115,-113,457,16,715,707,1000,-1000,-632,-380,527,476,-1000,-912,-1000,388,372,650,1000,-600,-55}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00828() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceFirst(char,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{998,527,1000,1000,-40,-670,644,436,426,-779,350,-661,-8,471,-461,-1000,-59,84,-320,151,373,-63,-1000,1000,96,-896,36,50,-900,217,1000,-640,54,6,-584,1,1000,275,-907,1000,-1000,128,1000,-405,-1000,-1000,1000,-230,-72,-208,-14,-117,-775,1000,400,747,578,146,87,-894,130,-481,689,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00829() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceFirst(char,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{488,200,138,95,218,-66,171,830,226,417,994,-667,-852,-573,-210,592,-70,-977,26,907,-871,-655,474,523,238,157,851,904,220,-764,-878,65,64,-155,-773,-242,435,-329,-777,779,230,875,649,-830,-745,-811,318,664,71,-659,-351,-611,605,550,188,-479,101,-733,996,-643,600,943,241,129}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00830() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceFirst(char,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-370,-1000,160,-491,-1000,-86,-66,-1000,960,-536,-410,1000,82,24,397,-692,-78,796,-1000,-1000,-939,409,567,-273,222,-31,-1000,-520,-98,656,1000,-917,-490,626,-538,892,1000,353,-826,-649,-106,261,56,-988,-244,-1000,868,672,13,1000,-1000,-596,-246,669,-818,1000,-1000,1000,-104,981,772,787,1000,-336}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00831() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceFirst(char,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{197,-736,590,-593,-183,62,678,-1000,-784,411,364,54,-88,44,-202,374,1000,-950,1000,738,-561,-1000,331,946,-658,1000,-771,-1000,803,-1000,0,-510,-113,393,-559,477,813,-479,-1000,947,1000,368,-798,640,272,298,1000,-457,928,-204,-1000,-959,1000,357,-894,160,-1000,604,468,97,1000,1000,-753,670}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00832() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceFirst(java.lang.String,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-312,890,1000,-1000,246,-1000,-588,626,-141,99,-855,216,47,371,1000,-88,1000,-504,-1000,-1000,1000,-276,70,960,-1000,-584,-710,-400,1000,1000,1000,-814,-1000,-1000,588,689,1000,398,1000,765,346,338,-949,-1000,-1000,794,-571,-225,294,-779,958,-893,389,-1000,1000,1000,-864,536,-357,-327,-677,831,950,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00833() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceFirst(java.lang.String,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{458,1000,555,-420,-283,-968,329,-601,299,-460,-1000,566,674,1000,1000,-878,1000,-216,-1000,-857,1000,-1000,-1000,1000,-1000,-890,-437,-961,1000,-784,982,-656,-1000,-1000,-243,182,-723,622,1000,1000,852,-63,-225,-114,-1000,1000,937,-315,1000,-717,221,-1000,-877,-1000,1000,584,-1000,-1000,-1000,1000,-251,1000,-308,-787}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00834() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceFirst(java.lang.String,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{29,500,191,-32,360,-1000,104,-566,403,-150,-330,-1000,-673,165,1000,-823,1000,-948,-871,-1000,368,-116,137,415,-968,-931,-398,770,1000,1000,1000,-159,213,-1000,-1000,274,1000,-38,-296,-218,-543,-230,-159,13,-1000,237,1000,214,521,-561,411,-245,-66,832,459,137,155,-661,-1000,-803,348,162,76,889}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00835() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceFirst(java.lang.String,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{539,453,749,-986,382,-1000,-429,625,80,-33,1000,-1000,-505,-576,-60,310,-1000,-1000,-45,-570,636,-630,1000,182,183,-571,-925,254,-1000,-587,-576,849,243,-25,1000,247,-386,723,-351,-136,-754,-753,334,32,-824,-366,258,-455,1000,-294,-23,-868,-752,-1000,-835,-413,-168,1000,-290,988,-900,-248,-333,-5}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00836() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceFirst(java.lang.String,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-279,788,234,-740,-25,-516,-189,-21,26,-944,-183,-799,-731,-662,499,430,852,-869,179,-957,626,-715,711,-324,78,-863,-105,634,907,993,264,342,175,-584,680,3,268,740,-666,-720,-658,-538,-125,120,-668,-59,646,-394,162,171,315,133,344,-669,-466,129,-182,237,-317,-962,571,-92,261,369}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00837() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceFirst(java.lang.String,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-244,-1000,-32,1000,788,-87,-612,403,-1000,-1000,-179,-1000,165,688,-823,849,-97,1000,-614,-874,1000,-264,-1000,955,-599,766,770,1000,1000,1000,-197,-804,-898,-1000,-1000,-618,-456,-1000,104,-510,191,309,1000,-248,15,-33,78,-411,150,411,1000,1000,832,1000,-434,1000,-501,498,-1000,1000,722,509,969}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00838() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceFirst(java.lang.String,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-1000,-1000,-290,644,-761,411,-211,343,-200,-1000,552,841,196,913,-354,-1000,357,1000,481,-1000,1000,287,-738,-1000,-88,-597,-237,-783,-368,-715,749,-562,184,-1000,-913,-386,-73,-725,264,213,-611,1000,-1000,147,-777,304,274,684,-618,-1000,496,-568,840,620,-341,1000,1000,-1000,-712,-216,170,-979,348}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00839() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceFirst(java.lang.String,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{605,809,-414,-827,-129,-127,-494,39,420,-164,-713,-154,1000,-508,43,689,-165,-137,138,-436,644,683,-1000,1000,140,-210,-532,1000,662,784,-1000,805,568,-180,846,-511,-564,1000,-1000,-1000,459,-656,496,1000,-179,439,167,-896,-993,696,238,51,-385,1000,771,154,-817,555,807,-610,279,-1000,308,-178}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00840() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceFirst(java.lang.String,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{888,-1000,-912,797,319,771,317,108,-470,1000,409,464,35,-183,-1000,-12,-1000,569,694,-60,-295,1000,-571,-1000,-280,1000,-128,-602,-1000,-1000,-181,-647,818,607,-500,495,-484,-460,-80,-1000,429,615,373,642,1000,-1000,-792,-250,-550,-471,-396,143,206,-716,678,-667,268,-257,1000,1000,-1000,-622,-156,-165}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00841() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceFirst(java.lang.String,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-983,26,729,-103,769,-464,-914,-694,-1000,-627,836,-400,-444,378,202,-386,1000,703,533,-596,789,-1000,-205,238,-1000,331,-154,1000,583,59,-694,-783,-421,-1000,7,229,988,1000,282,421,824,-370,-1000,965,-627,-598,1000,348,-1000,-260,603,580,1000,-248,1000,840,-265,45,-637,-223,591,-50,77}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00842() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceFirst(org.apache.commons.lang.text.StrMatcher,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-424,-174,572,317,-772,-166,1000,1000,485,1000,-623,1000,251,148,-1000,-1000,-1000,-1000,-17,1000,-1000,-902,-1000,-1000,-1000,-1000,742,1000,-1000,1000,1000,1000,884,-331,-1000,-1000,1000,-1000,1000,1000,587,638,505,1000,1000,118,-346,-1000,1000,430,-1000,-1000,-1000,266,-249,1000,1000,836,1000,447,1000,-1000,-279}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00843() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceFirst(org.apache.commons.lang.text.StrMatcher,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{899,276,539,139,17,228,166,167,-914,994,-405,-154,312,-451,20,741,144,-645,399,568,-321,622,-178,1000,-651,173,1000,-712,-416,316,37,467,-202,64,945,540,-61,245,66,-344,-960,-185,49,338,-1000,-850,693,424,437,-788,400,-910,906,828,280,-620,-321,-513,762,-423,380,-362,728,-309}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00844() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceFirst(org.apache.commons.lang.text.StrMatcher,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-917,-1000,-304,-863,176,662,347,-718,-618,51,114,-724,1000,186,419,-123,51,-1000,-1000,167,706,-165,590,-352,-1000,-225,597,755,1000,143,831,-136,-638,-1000,1000,-442,-11,13,-1000,488,456,-413,600,379,779,-580,-411,276,-882,1000,330,553,-223,178,-606,-230,83,-138,668,1000,-42,348,-276,-191}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00845() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceFirst(org.apache.commons.lang.text.StrMatcher,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-400,-483,-1000,-526,500,-81,-286,-48,697,-1000,1000,228,121,-1000,-653,-45,-40,398,-542,144,-1000,-592,-285,1000,620,169,-75,411,-401,-24,-774,-920,-1000,869,-1000,800,1000,-202,1000,-1000,425,-900,-803,-75,298,-1000,-73,-468,-1000,960,-84,931,104,-1000,66,-1000,950,1000,-1000,565,1000,1000,419}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00846() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceFirst(org.apache.commons.lang.text.StrMatcher,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-832,-1000,219,865,185,429,231,111,355,1000,297,1000,-477,-90,-341,-863,-944,-964,383,636,-675,1000,-1000,-1000,-1000,-1000,262,641,632,1000,-55,1000,113,1000,-900,-1000,-355,-895,442,1000,924,252,179,506,-54,-646,-100,-882,-353,701,-1000,1000,-753,-921,-230,1000,519,347,1000,826,1000,-581,314}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00847() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceFirst(org.apache.commons.lang.text.StrMatcher,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{882,-479,742,235,-716,72,-862,-59,-914,333,737,-654,142,987,286,-548,-11,158,767,517,76,481,894,186,-572,-807,948,-999,-615,-802,-255,744,-91,741,722,-603,46,860,667,-294,573,-906,453,278,-406,-953,-720,954,-81,396,400,-197,412,633,-926,-523,193,460,593,-74,567,-898,-400,499}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00848() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceFirst(org.apache.commons.lang.text.StrMatcher,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,323,-1000,690,-268,500,79,871,199,712,161,677,1000,-89,592,-653,-820,25,-1000,-688,436,-1000,-1000,-153,-548,-1000,-1000,1000,410,-756,-24,973,1000,345,869,-1000,523,482,-694,649,1000,373,-417,-759,1000,1000,-834,-73,-907,461,960,-1000,588,-1000,-310,66,891,1000,-347,1000,-483,1000,-558,198}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00849() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "reverse():org.apache.commons.lang.text.StrBuilder",
            new int[]{491,-847,-733,-139,199,-16,-845,671,590,-370,-315,147,297,418,999,511,623,937,-940,457,-465,149,522,-513,-840,741,-928,829,-560,-846,-895,-844,54,475,-664,-274,-659,975,65,824,966,-565,-780,-621,398,617,-27,532,-137,234,812,-435,368,610,-779,-914,663,-162,837,-331,-469,707,859,233}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00850() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "reverse():org.apache.commons.lang.text.StrBuilder",
            new int[]{-406,-858,-241,403,199,-834,-464,963,94,890,-476,147,1000,869,407,1000,-462,1000,-940,-297,-1000,667,522,177,-264,1000,-328,-100,-614,298,419,-1000,500,216,47,305,-463,-153,54,-17,128,-565,-709,-941,406,408,-27,-207,-386,-273,618,399,301,399,-779,-809,764,-394,177,-162,109,509,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00851() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "reverse():org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,479,225,757,-1000,154,-42,-730,25,-874,174,79,-589,-602,-370,171,-1000,278,-374,177,1000,22,741,-654,288,-1000,324,337,400,-403,-345,1000,-854,631,5,975,-860,148,335,702,20,6,-54,745,-560,988,-1000,536,749,-160,-30,190,-1000,245,-850,-189,534,-984,-171,-433,-622,54,-468,-212}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00852() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "reverse():org.apache.commons.lang.text.StrBuilder",
            new int[]{97,385,411,552,-551,314,-369,421,605,-376,-553,-759,296,445,176,369,538,129,-841,147,459,-47,-899,-304,-1000,-532,246,553,-262,-507,-115,744,-155,1000,-834,898,-453,1000,214,-432,-816,-1000,702,729,-41,683,-587,-1000,-187,659,-123,149,-454,-67,172,-601,363,-831,-480,-363,-564,-105,-1000,386}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00853() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "reverse():org.apache.commons.lang.text.StrBuilder",
            new int[]{620,35,691,1000,-768,-632,-386,-258,-547,-140,239,-405,221,-265,-428,245,-1000,200,582,635,266,654,1000,3,588,-724,554,-882,-278,607,873,427,-512,325,228,1000,-486,-1000,247,140,-26,-861,43,385,342,758,-479,494,133,-904,371,493,-1000,-701,-406,70,603,-1000,-851,-1,-78,-234,315,-196}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00854() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "reverse():org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,1000,914,1000,-727,-759,-1000,-8,-593,-678,-190,-131,-146,385,1000,-861,-1000,422,531,144,1000,50,1000,386,-1000,702,1000,-143,-1000,42,1000,1000,297,1000,-457,1000,-1000,-651,48,457,462,64,1000,338,-605,1000,19,-386,1000,385,634,-147,-1000,-984,-5,-288,-3,-1000,981,-767,-442,-327,393,-923}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00855() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "reverse():org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-16,144,1000,-908,297,821,-307,248,-1000,9,-363,-974,-1000,597,810,-836,685,389,775,386,-191,-308,-368,1000,-251,132,-725,447,-411,-813,1000,-1000,1000,184,710,-680,223,20,508,697,70,-349,590,-499,895,-40,518,297,-221,-485,636,-1000,1000,-139,-80,24,-946,-955,669,30,323,-405,-228}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00856() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "rightString(int):java.lang.String",
            new int[]{-366,-1000,-910,-998,-1000,-622,-176,-24,288,-470,-457,776,-995,413,-1000,-423,558,-529,-559,-248,-840,-571,562,-362,364,-95,840,73,519,-429,-558,-750,675,1000,550,803,-15,-506,-41,-1000,1000,-249,602,366,-1000,273,590,664,-47,407,720,-649,-964,782,-1000,677,228,1000,1000,-986,-43,687,628,29}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00857() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "rightString(int):java.lang.String",
            new int[]{-1000,-594,354,612,772,1000,976,-401,728,963,1000,-655,618,-1000,-152,537,529,338,-339,286,316,847,-575,293,514,347,-709,-821,-293,-511,-68,-474,498,385,-612,-753,-400,-548,-331,-902,-1000,1000,-1000,-646,-324,-128,-191,230,-593,1000,-825,952,372,23,250,-1000,-694,-800,-1000,780,-261,-909,-852,418}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00858() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "rightString(int):java.lang.String",
            new int[]{1000,-61,306,-216,-912,-857,212,377,-396,-286,433,697,-181,53,449,193,-617,156,451,-1000,400,-1000,464,400,902,250,1000,792,-1000,-1000,356,-894,-213,-295,-600,377,-31,400,-810,-976,-489,-792,-370,-244,400,-107,-1000,-400,439,295,1000,26,-320,303,-121,-10,540,-77,63,326,-127,-400,-561,-469}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00859() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "rightString(int):java.lang.String",
            new int[]{144,419,877,633,-1000,1000,352,520,732,-1000,174,-252,-1000,1000,455,1000,-951,403,813,1000,1000,69,-1000,-551,-894,-1000,470,1000,1000,366,156,90,-956,779,1000,-17,-753,221,1000,492,1000,1000,431,-499,245,27,1000,-1000,-899,1000,-369,952,430,-1000,1000,-1000,343,-539,1000,780,779,-132,1000,266}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00860() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "rightString(int):java.lang.String",
            new int[]{19,-863,-1000,513,-153,969,-832,-1000,59,734,-66,244,276,314,212,422,-1000,-764,1000,-928,55,-824,182,88,449,693,378,-220,-996,-956,-526,-215,896,-700,417,-814,-659,424,406,101,-848,-866,-164,-616,1000,-23,-207,636,890,19,330,176,579,-240,262,-611,1000,-604,-40,-162,-1000,191,205,574}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00861() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "rightString(int):java.lang.String",
            new int[]{-992,-322,632,705,-1000,333,593,-13,823,-537,-69,-1000,-83,-755,9,-619,805,-41,-75,1000,1000,481,-646,847,-472,-263,128,1000,451,177,922,-979,-831,485,1000,-229,-1000,-354,213,-952,664,516,-786,-60,-588,-480,-192,-753,286,1000,-236,701,-327,-595,820,-877,-294,-779,-701,-681,187,-386,294,485}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00862() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "rightString(int):java.lang.String",
            new int[]{-409,-1000,-944,-26,-407,-97,-914,316,679,-1000,257,-411,-1000,-226,-1000,-1000,927,-1000,-347,-1000,-1000,280,486,-465,409,-621,224,261,-430,-1000,-853,-10,623,662,43,1000,1000,-1000,327,366,985,-327,688,622,-1000,286,626,1000,-817,-1000,431,-1000,-851,1000,-145,471,894,912,587,-753,139,786,185,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00863() {
        org.junit.Assert.assertEquals("java.lang.String:MA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "rightString(int):java.lang.String",
            new int[]{-721,-322,632,630,-1000,333,-744,-277,659,-537,-24,-630,-83,-391,-486,-619,821,-193,-130,1000,762,393,-460,1000,-472,-448,-116,536,93,177,922,-624,-831,605,1000,89,-1000,-354,-644,-1000,829,516,-786,-60,-724,-74,260,-406,-215,835,74,701,-611,117,328,-1000,-294,-262,-590,-1000,154,-386,391,574}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00864() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "setCharAt(int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,419,-430,-556,-408,-26,852,116,635,26,-474,1000,-270,-488,-779,602,244,-298,-97,-507,222,-351,826,504,-305,-356,57,-15,215,908,253,-346,-752,-232,348,-941,-383,-461,-299,790,653,29,211,316,-54,201,286,241,-115,9,91,516,-175,216,-452,-376,-532,223,-597,403,210,373,259,-603}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00865() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "setCharAt(int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-189,207,-196,-890,-162,965,-513,201,-306,-411,864,-530,161,135,-572,-899,-946,498,165,-880,191,-762,-624,631,406,162,-890,468,-859,969,-395,-351,-398,224,250,850,718,-782,-500,351,-776,-180,897,-651,-938,387,-108,377,-998,946,527,671,888,444,178,-247,238,659,573,-737,60,-470,58,-903}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00866() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "setCharAt(int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{667,47,767,-796,1000,-1000,119,-278,411,-493,-371,389,36,587,-1000,464,111,-475,725,-1000,-1000,-199,636,204,-432,-110,1000,-625,1000,-938,-1000,1000,548,518,-328,149,-452,237,694,864,-38,850,78,-592,-310,-147,-490,317,-33,-242,-922,-844,-366,-200,-318,-1000,-1000,220,-688,-270,44,-313,-1000,-226}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00867() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "setCharAt(int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{105,-554,309,16,-813,234,226,-861,-657,-743,31,-914,-321,301,-284,612,-8,250,848,594,220,943,-985,-624,-820,-160,-572,766,487,912,-71,-360,974,95,-247,10,202,970,-673,-454,720,-121,99,-906,-384,-393,-62,-517,602,974,-998,-924,381,196,-872,-73,-620,718,792,157,-964,-622,-532,-779}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00868() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "setCharAt(int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-697,677,1000,-366,864,-917,59,-94,734,372,-794,-444,35,-29,-380,-285,517,336,324,-842,1000,-749,1000,18,-464,-112,513,217,415,188,-526,1000,36,-357,712,-62,568,-1000,403,111,379,1000,749,-720,145,1000,-852,-563,1000,-1000,-1000,336,644,355,16,176,-364,368,-628,955,-278,-233,-475,341}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00869() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "setCharAt(int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-34,-155,-1000,-711,-881,187,-213,-299,858,-453,-10,-62,-130,92,-964,643,-840,-1000,805,108,-649,-760,333,705,-55,546,584,-1000,189,663,-125,-279,692,61,-1000,-1000,-47,715,-1000,1000,689,-515,-419,542,-1000,-661,598,1000,-1000,445,-229,1000,-795,-144,376,-966,-356,667,-176,-1000,648,-39,-119,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00870() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "setCharAt(int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-587,-469,192,-929,531,148,791,-90,-653,-790,-106,-1000,-246,136,-1000,1000,605,-1000,150,-263,-814,1000,-216,-1000,576,1000,1000,-750,-839,243,-543,1000,652,1000,-149,-383,1000,476,-609,-628,-591,-372,-1000,149,-575,-788,-497,-388,475,-667,-1000,-433,-987,-1000,275,-92,-313,-700,1000,-323,325,360,678,-747}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00871() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "setLength(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-400,752,1000,868,-316,-95,-297,226,1000,1000,-959,-896,579,-12,-539,566,-502,-780,382,524,706,-1000,432,-496,-1000,-84,273,-58,-844,1000,329,357,97,671,-909,-882,-615,-400,-1000,261,-376,455,-356,598,260,-114,1000,328,1000,351,-970,1000,-1000,402,234,-917,-925,-6,-248,1000,-1000,1000,-100,811}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00872() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "setLength(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-729,429,936,1000,-1000,-1000,409,448,944,257,927,-296,-701,111,1000,-1000,341,771,-670,954,-1000,1000,-401,-351,-587,-879,867,606,124,-526,-958,873,468,-1000,-392,-1000,-993,-1000,-114,-1000,1000,251,1000,728,-956,750,-595,1000,-314,957,432,1000,-969,1000,81,-470,-1000,-702,964,-1000,1000,1000,430}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00873() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "setLength(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{461,653,-360,462,177,-1000,-711,364,-575,464,711,1000,-503,-193,-491,562,-1000,1000,865,-761,1000,-136,736,-692,-756,-458,-349,176,206,205,-354,-1000,610,934,-1000,163,-1000,-1000,-833,-95,-248,225,400,699,1000,-1000,1,-1000,159,131,860,-937,1000,-1000,857,34,-7,-837,-1000,-414,765,59,-408,105}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00874() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "setLength(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{556,202,799,50,832,23,-337,-498,-185,405,-533,-1000,-575,484,169,72,-339,-539,-1000,-745,196,-197,557,-345,-862,-54,164,334,589,-1000,668,569,952,473,264,-411,-976,90,-210,-632,587,855,78,236,24,652,913,-501,1000,345,1000,1000,-1000,202,281,-1000,-77,489,-122,1000,-271,-24,1000,389}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00875() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "setLength(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-1000,-993,941,108,-1000,382,1000,-283,-201,995,1000,-361,350,1000,-509,155,1000,401,-55,1000,1000,290,853,-890,-1000,-827,-641,361,-135,-1000,495,-480,-241,1000,381,-504,74,1000,1000,-260,433,433,377,-318,541,-950,-1000,-1000,-1000,1000,238,1000,-12,-233,1000,318,-1000,-1000,-446,570,371,1000,438}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00876() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "setLength(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-1000,-912,-351,1000,-259,464,1000,-133,117,-562,-1000,-866,-327,-124,-1000,1000,1000,-245,684,292,1000,-1000,1000,-144,47,274,524,1000,-1000,897,1000,-909,-34,1000,-932,-841,1000,1000,1000,1000,182,1000,-1000,737,1000,266,-1000,-1000,1000,1000,1000,400,1000,-1000,-237,531,-110,463,-782,-1000,650,1000,453}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00877() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "setNewLineText(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{895,-523,-829,436,48,468,335,867,829,-962,957,-707,-188,-429,595,23,780,615,295,-1000,-523,553,-523,-764,306,-805,-822,-931,-218,-92,-773,-751,-403,-620,-489,912,313,-33,1000,592,72,-1000,-1000,-789,1000,-477,827,-740,1000,299,-396,1000,487,587,1000,-324,-1000,-583,-923,-1000,-300,1,61,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00878() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "setNewLineText(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-420,465,159,1000,444,469,339,-572,-52,1,337,319,-1000,313,-847,-119,-1000,-268,-1000,-342,375,-1000,537,-517,552,-176,1000,1000,-856,-1000,-61,-385,-1000,1000,1000,264,-360,141,47,829,283,-1000,-496,1000,-1000,-943,161,-824,-1000,-11,-820,-978,690,-404,16,-431,-1000,1000,1000,14,-387,-1000,620,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00879() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "setNewLineText(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{253,-1000,-512,345,1000,-226,637,-500,342,44,-162,406,-672,-1000,-542,-621,430,985,504,-790,65,-459,327,-600,-1000,1000,152,-82,258,-170,204,-822,6,-1000,-175,55,170,1000,-290,549,-311,-656,-973,-1000,1000,297,-414,-475,377,1000,-835,188,399,677,710,540,-167,-592,-634,569,604,-1000,-323,-482}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00880() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "setNewLineText(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{817,-65,-300,249,399,-760,342,611,431,-956,558,-707,-762,3,433,-592,-620,296,-157,-811,0,175,-523,-656,648,-869,-822,-984,-766,-955,-685,-578,-764,-905,353,929,315,-302,910,108,89,-709,-843,121,977,-606,661,706,741,38,-525,970,651,-587,637,-780,-995,366,-923,-865,209,239,413,746}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00881() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "setNewLineText(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-159,-190,-56,335,149,-980,-426,-136,836,66,-756,-763,-535,-468,-437,-505,404,-202,-123,-401,-71,-444,-401,-449,283,456,1000,1000,-400,59,134,-453,13,-170,-402,-193,-737,-23,-647,-431,-165,1000,-457,491,268,209,668,-1000,228,523,-835,-844,1000,-178,710,55,-696,417,601,1000,435,556,-198,-617}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00882() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "setNewLineText(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{197,158,278,1000,-16,-547,294,-229,97,-636,-280,-1000,-158,319,-196,657,-620,-161,-1000,-407,375,-1000,49,-727,969,-655,559,895,-1000,-1000,-765,-473,-1000,569,1000,645,-176,-462,490,-231,-270,239,-655,995,493,-706,447,-594,-730,-363,-279,190,1000,-683,-1000,-342,-1000,1000,1000,-216,105,-306,301,-180}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00883() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "setNewLineText(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-1000,-411,1000,354,-404,563,-746,908,-1000,1000,181,832,-805,-74,329,640,1000,848,-911,434,982,-1000,-1000,-328,54,-419,-1000,391,247,-932,-827,564,-707,-416,1000,796,739,1000,918,-781,-1000,-1000,-1000,1000,-215,-137,-32,-413,154,-689,1000,725,766,1000,-217,-782,-1000,-44,-1000,-603,-697,-743,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00884() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "setNewLineText(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{349,-679,494,-32,1000,1000,-332,-769,502,48,-656,637,-623,1000,-603,-696,20,388,683,-324,733,138,264,-544,-761,700,1000,69,616,396,265,-701,685,-1000,-411,67,17,812,-353,93,-318,476,-588,-156,476,579,170,278,-132,715,-763,-335,1000,179,43,70,-157,-29,601,1000,600,431,-754,-327}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00885() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "setNullText(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-991,84,-236,89,539,1000,-213,279,269,-563,150,-865,-410,370,250,-383,215,1000,1000,588,438,-1000,-1000,757,965,-26,227,-22,456,-784,1000,845,-529,203,-397,-323,-534,346,-620,-392,-337,-1000,-1000,-372,-1000,727,558,-1000,796,-215,681,-403,690,913,894,386,377,-74,-1000,1000,386,-963,649}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00886() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "setNullText(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{245,-864,318,-236,290,348,-128,992,-88,60,411,912,24,205,736,600,476,356,-398,-207,695,587,-33,-990,-1000,929,-118,662,345,-71,-189,-228,849,-47,-116,460,-349,-112,-196,-554,440,167,-1000,75,-415,190,890,295,275,619,584,913,-150,395,929,-464,-966,664,-550,-193,-1000,163,310,-147}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00887() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "setNullText(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-41,-740,-110,333,749,-88,-1000,-14,-241,-671,-547,266,452,294,733,691,255,1000,-1000,-401,-830,-723,-374,-209,-861,1000,-1000,804,218,54,413,550,-23,540,487,650,699,-815,466,122,83,477,-996,600,285,-466,868,-660,193,304,752,181,-467,-292,-406,-868,690,410,-253,-60,-973,850,230,-482}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00888() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "setNullText(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{835,-1000,715,251,-232,3,-243,173,813,-520,-899,-70,-1000,539,-402,-75,-1000,247,1000,-581,756,170,-269,16,-417,-739,179,-414,-845,540,-419,-458,102,283,-1000,-1000,-136,-772,-999,-434,-96,-1000,-1000,433,-970,-1000,308,136,54,803,-1000,-422,-607,-828,-1000,1000,1000,249,785,-161,7,-575,-1000,-325}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00889() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "setNullText(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-1000,282,-135,204,377,-184,120,-286,348,-844,-675,-102,337,536,-1000,496,323,-39,106,905,598,-1000,-875,1000,1000,-1000,943,722,1000,-58,524,671,678,145,727,-486,1000,-184,-1000,875,-205,-1000,-709,610,-548,1000,1000,-167,283,1000,856,-977,675,436,-2,288,995,138,-972,-255,475,-579,465}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00890() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "setNullText(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{55,-1000,-591,-98,1000,388,1000,852,-1000,1000,-59,710,330,-379,1000,-433,732,-431,-339,1000,-381,157,-1000,-959,609,1000,-1000,470,1000,1000,1000,-10,491,305,1000,1000,131,207,-206,-822,1000,-172,526,154,1000,1000,931,653,-923,-233,1000,1000,-1000,-573,1000,675,-721,975,117,-1000,768,477,940,966}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00891() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "setNullText(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-268,-550,-240,-362,1000,69,1000,781,-167,-112,-514,-547,507,563,-462,831,999,794,-1000,1000,1000,398,-109,-984,668,184,-957,17,750,1000,-580,559,409,312,136,109,-332,909,-1000,-1000,-555,-833,160,-835,1000,-1000,1000,456,813,930,642,1000,514,-972,808,762,-1000,1000,185,-1000,391,83,915,-143}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00892() {
        org.junit.Assert.assertEquals("java.lang.Integer:MTc1", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "size():int",
            new int[]{757,-1000,-281,-321,-1000,-311,-174,686,538,-679,427,175,179,81,1000,-630,-368,787,-646,333,40,-675,696,202,-428,-334,-1000,-475,139,69,989,-652,1000,-1000,637,1000,-1000,-395,691,-223,-604,-1000,472,51,-705,-1000,-705,609,-1000,-1000,-1000,201,-320,1000,-1000,509,480,297,-217,106,-716,523,220,40}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00893() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "size():int",
            new int[]{-835,33,84,-1000,517,-373,-84,-486,-381,472,486,-202,148,24,-787,555,291,-303,1000,-655,-488,776,-386,-722,233,-65,-844,-206,-506,-804,544,1000,-1000,1000,-141,935,354,1000,-736,-507,504,82,19,-274,-645,-1000,678,-836,951,-907,22,60,531,178,451,1000,-910,-139,121,1000,-775,29,-607,-526}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00894() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "size():int",
            new int[]{-337,-460,-918,1000,-623,263,-103,-454,-1000,-198,678,-497,-944,-1000,1000,137,372,-1000,-488,1000,363,-1000,1000,-715,-1000,-423,-275,-179,907,1000,-1000,-1000,821,-462,235,897,-534,-1000,1000,1000,-1000,-240,-1000,-75,1000,-5,-981,250,-1000,-816,-1000,1000,1000,702,-954,-1000,1000,-480,-91,-281,-709,-792,234,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00895() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "size():int",
            new int[]{975,77,605,-693,253,1000,-1,-29,-460,-1000,-843,-812,-512,4,825,284,-1000,-37,1000,317,-206,545,222,1000,1000,-977,-58,621,-62,63,359,1000,-100,-417,1000,-157,-1000,-687,247,650,-763,-377,1000,798,140,-238,-986,1000,-799,-1000,-403,758,-520,-1000,803,302,-150,-22,-869,-291,355,257,266,-578}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00896() {
        org.junit.Assert.assertEquals("java.lang.Integer:MQ==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "size():int",
            new int[]{-35,271,744,-430,-487,-550,387,545,229,479,-1000,400,1000,1000,-1000,496,-1000,1000,600,-155,350,890,-1000,-115,1000,715,-837,241,-1000,-1000,1000,105,199,-120,-496,-1000,134,1000,-1000,-965,914,-450,1000,207,426,856,1000,-97,186,162,242,641,-1000,29,-1000,910,-1000,240,-531,-315,1000,514,786,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00897() {
        org.junit.Assert.assertEquals("java.lang.Integer:MQ==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "size():int",
            new int[]{-1000,893,-848,-109,33,-333,-479,-846,-837,918,877,-937,-227,-322,628,-346,330,-194,912,1000,-1000,-185,74,-1000,-1000,-1000,-1000,86,-446,987,437,-1000,607,-23,735,121,-1000,-1000,872,84,-219,-245,-15,628,560,932,-878,84,-178,228,-976,843,-45,1000,-537,400,742,-801,-125,1000,-1000,608,234,188}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00898() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "size():int",
            new int[]{1000,-1000,1000,-451,517,291,-117,767,130,-764,-1000,179,608,24,-1000,-134,-1000,266,-804,-3,485,1000,-749,189,601,436,503,-661,490,-1000,184,589,-678,65,805,-659,315,1000,-1000,-192,43,993,633,-443,326,-591,76,342,-347,-546,22,891,-203,-445,1000,-92,-1000,506,-92,-954,1000,29,933,-799}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00899() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "startsWith(java.lang.String):boolean",
            new int[]{-1000,-1000,1000,1000,-1000,-54,-168,314,-1000,1000,1000,967,892,1000,-793,-684,995,-214,-1000,1000,-532,526,529,807,1000,-621,-430,-1000,-917,1000,225,1000,205,-1000,1000,1000,-1000,990,909,-788,1000,-1000,-1000,32,-1000,-669,-1000,1000,928,634,-43,1000,387,63,1000,1000,-1000,-336,-450,1000,-1000,-1000,593,3}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00900() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "startsWith(java.lang.String):boolean",
            new int[]{-92,-879,689,192,-861,-482,516,1000,-508,436,-478,850,-278,-378,-322,-743,1000,1000,-471,-190,-1000,614,50,256,462,-82,-768,-1000,634,945,93,554,211,-1000,1000,255,-438,138,-312,-926,108,-473,-425,-737,-587,-693,-434,-456,543,-881,-985,983,-275,93,937,129,-185,-31,-390,831,-558,-440,-261,-150}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00901() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "startsWith(java.lang.String):boolean",
            new int[]{-140,-40,518,721,1000,178,244,951,1000,-149,894,1000,-956,256,-957,-726,12,-655,335,656,-540,-760,-271,349,-62,-1000,513,761,136,872,-1000,-205,614,-665,902,-614,770,-1000,350,-1000,-649,297,-319,-1000,-353,631,1000,5,525,-346,276,96,298,-1000,-562,-264,798,-21,490,1000,-1000,-778,-435,-271}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00902() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "startsWith(java.lang.String):boolean",
            new int[]{-1000,350,-63,-1000,995,-937,-394,-503,681,-403,-1000,-148,484,114,916,-987,-1000,1000,400,-79,-815,-1000,728,211,-1000,-632,-286,-1000,-577,1000,293,-836,-663,400,-342,-400,-1000,573,1000,-839,-1000,-201,428,-15,1000,-253,-313,-596,445,-896,1000,-400,-422,171,-759,1000,941,1000,866,118,1000,321,-400,-511}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00903() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "startsWith(java.lang.String):boolean",
            new int[]{21,-180,959,-241,-143,806,262,-1000,-1000,373,1000,-1000,-932,-547,-847,-969,1000,1000,-1000,494,952,-906,-71,-272,-805,-593,1000,-722,1000,1000,-297,1000,6,475,1000,-411,-1000,1000,784,-261,1000,76,-1000,903,646,-897,-305,-456,818,-696,-1000,226,74,1000,587,269,-1000,-25,-778,1000,1000,854,659,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00904() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "startsWith(java.lang.String):boolean",
            new int[]{196,-1000,1000,1000,-1000,-61,365,1000,-981,1000,1000,1000,-180,627,-370,-639,1000,286,-1000,638,212,1000,-423,204,1000,-1000,-476,-1000,-383,1000,-405,1000,949,-1000,1000,1000,-973,344,848,-902,1000,-111,-1000,561,-1000,-1000,-788,966,444,377,-1000,1000,347,-81,1000,1000,-1000,-500,-1000,856,-1000,-1000,-403,84}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00905() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "startsWith(java.lang.String):boolean",
            new int[]{549,-827,-401,-293,-802,-308,573,683,496,195,-510,450,-701,-1000,118,-936,865,723,-199,15,60,278,-683,1000,231,-302,-648,-836,713,-54,-344,-134,286,-1000,545,-65,-159,207,-402,-1000,-275,-247,-178,246,-410,-933,-191,-275,739,-496,-1000,988,34,-33,267,-201,471,176,-435,855,-368,-200,171,-312}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00906() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "startsWith(java.lang.String):boolean",
            new int[]{-1000,-1000,-80,-1000,583,-627,-69,87,1000,530,-903,451,1000,334,-230,3,-1000,686,-283,662,-1000,-1000,1000,1000,-1000,1000,-551,-1000,-830,-1000,1000,-1000,-639,-253,760,-400,-1000,1000,1000,-870,-1000,176,650,-337,905,122,-1000,-827,1000,-733,462,1000,-203,-37,-470,-1000,252,1000,1000,1000,1000,328,1000,-363}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00907() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "substring(int):java.lang.String",
            new int[]{1000,410,711,-101,-1000,-487,114,-434,560,972,918,-356,-510,1000,-1000,-182,297,-906,1000,-518,234,89,-30,1000,1000,-1000,981,-596,123,-343,333,1000,-508,384,755,-810,387,-902,-1000,27,-1000,1000,-900,14,792,754,-991,813,-246,-923,163,-924,-1000,337,932,-66,390,-282,-224,-1000,-822,-188,97,-366}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00908() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "substring(int):java.lang.String",
            new int[]{-194,759,804,-449,725,19,-115,288,-37,111,-42,-827,1000,433,-257,-868,1000,-518,-694,16,574,646,356,134,-1000,568,-630,-865,637,463,-818,-44,831,-56,206,-119,-337,-754,-256,0,252,-660,-11,15,247,-294,52,-179,-512,-43,-558,729,-211,241,-395,-184,62,1000,-535,250,902,660,616,269}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00909() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "substring(int):java.lang.String",
            new int[]{1000,1000,863,-377,-421,-238,12,492,579,1000,1000,-102,-718,722,-1000,-261,-314,461,1000,-789,1000,89,-204,746,351,-844,1000,-992,-15,538,333,1000,-149,1000,1000,-1000,519,-978,-1000,982,-485,1000,-1000,675,1000,200,-988,1000,-1000,-1000,311,169,-597,-342,-139,-837,906,373,-419,-1000,473,271,1000,-993}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00910() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "substring(int):java.lang.String",
            new int[]{436,794,497,-90,-198,-317,87,956,346,1000,1000,40,402,981,-743,-767,-384,-322,784,-1000,805,1000,-1000,471,-456,-409,-710,-795,-223,1000,-524,1000,279,229,1000,-848,377,-242,-1000,1000,-324,-125,-1000,633,761,-1000,-737,1000,-923,-506,1000,770,-824,203,355,-1000,254,476,-622,-686,677,-506,922,-672}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00911() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "substring(int):java.lang.String",
            new int[]{-67,-1000,734,-820,921,39,-402,-517,-801,-973,-354,19,-131,932,-80,-150,759,569,554,-386,-942,867,394,-256,-253,-857,877,-554,-52,995,-1000,-324,-700,818,34,-235,471,-1000,34,-246,-115,436,-409,883,466,-50,-1000,178,1000,614,-311,-1000,757,-681,146,-59,-900,-1000,1000,-1000,-740,-1000,-1000,94}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00912() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "substring(int):java.lang.String",
            new int[]{-1000,-478,750,1000,955,-455,87,866,-911,-463,-650,-131,323,-1000,696,-323,-933,589,-365,884,100,1000,767,692,-1000,890,-373,-771,-223,1000,-1000,1000,-836,-1000,-1000,228,228,-242,876,-283,1000,-1000,-1000,-147,761,-834,-737,-606,-83,679,-813,455,-11,-898,-1000,-1000,-539,-383,194,662,509,-573,1000,-11}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00913() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "substring(int):java.lang.String",
            new int[]{-688,-1000,627,1000,-46,-751,-854,-1000,-857,-1000,-1000,-472,249,-416,1000,-238,46,1000,-249,1000,-963,1000,1000,968,56,524,-29,-413,556,-1000,-1000,-792,-1000,-986,-1000,714,-96,-57,1000,-1000,-61,-1000,1000,-595,-208,60,-67,-1000,1000,1000,-1000,-1000,-597,113,-1000,559,-1000,-846,135,180,-1000,-855,-1000,771}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00914() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "substring(int):java.lang.String",
            new int[]{-711,-939,863,-1000,-206,544,-1000,-849,217,-636,-762,-209,888,106,149,-1000,274,-449,-165,81,561,733,282,636,-760,443,1000,-600,-420,629,-1000,348,-467,-338,-540,19,-736,-518,-252,304,47,-1000,-393,-77,254,-957,313,-352,-1000,563,0,708,228,-137,-1000,-534,-882,282,-109,-4,-120,-1000,392,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00915() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "substring(int):java.lang.String",
            new int[]{-511,-1000,928,-31,1000,-127,-1000,-597,-873,-1000,-1000,46,-454,-800,-353,-241,-144,-844,530,682,-1000,430,818,975,-832,-495,1000,-635,648,-79,-1000,58,-1000,-245,-400,-954,-245,-673,367,-278,516,-506,593,960,1000,-168,-140,351,1000,341,-883,-503,-144,-1000,-1000,-429,-697,-559,993,-318,-138,-546,-765,-354}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00916() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "substring(int,int):java.lang.String",
            new int[]{329,422,892,1000,-469,345,4,-841,-285,129,-36,695,-1000,-228,985,-613,20,-156,796,-223,-627,179,-197,98,-197,96,1000,-1000,-1000,-395,90,1000,-1000,-646,-263,599,1000,-823,427,1000,-68,-657,159,-237,397,1000,783,1000,-1000,-616,-481,-1000,-259,459,1000,503,-1000,45,-363,313,146,-1000,-1000,130}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00917() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "substring(int,int):java.lang.String",
            new int[]{1000,490,580,1000,-841,984,-294,-733,-122,-422,1000,330,-484,-1000,-58,-1000,-811,-584,127,114,-500,-652,-492,-163,-129,19,1000,-904,-1000,921,216,544,-1000,-193,-819,1000,675,-1000,-169,1000,108,-639,76,-69,-162,871,919,214,1000,-818,106,-542,185,930,676,662,-648,-567,-373,-201,465,-482,-506,-138}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00918() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "substring(int,int):java.lang.String",
            new int[]{329,-306,-508,401,-526,-481,-530,-283,466,-926,-442,797,-263,-228,1000,-33,-921,-36,20,-470,-112,-386,464,-639,-526,459,987,-718,-326,526,580,564,-1000,-779,-549,381,785,-596,-492,391,255,382,225,-181,-130,609,-132,646,-904,-616,-1000,201,169,1000,563,503,-1000,201,-201,613,190,-925,-356,93}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00919() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "substring(int,int):java.lang.String",
            new int[]{-1000,-700,-654,-1000,-13,-581,-438,-118,-689,-290,-26,750,-1000,1000,-1000,23,-392,152,-1000,-1000,492,-966,856,-149,-872,3,941,-1000,1000,62,-25,-160,1000,245,381,-1000,78,-1000,-1000,-1000,1000,1000,518,294,545,-1000,193,-1000,66,727,-941,1000,576,325,-108,-1000,-907,830,-171,185,-441,58,348,-605}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00920() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "substring(int,int):java.lang.String",
            new int[]{-869,-382,-882,304,334,1000,769,640,227,-587,-415,-348,-847,948,571,-921,-437,340,-512,-591,-214,-773,-701,-565,391,-7,-412,597,908,-101,648,-852,402,-609,-414,-424,-462,576,-907,-836,626,-855,300,81,-553,-707,-454,1,556,561,801,860,278,-63,-987,94,586,57,693,-565,693,873,680,-785}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00921() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "substring(int,int):java.lang.String",
            new int[]{530,-37,324,-705,-668,369,-389,-602,288,-676,-306,624,-511,-631,1000,-55,-360,-358,481,38,-960,-260,-407,-285,-8,367,987,-1000,-1000,-450,363,720,-1000,-889,-318,1000,917,-553,67,1000,78,-447,-226,-289,-85,1000,248,-451,-860,-1000,-524,-424,-208,893,860,1000,-893,-376,-268,918,819,-893,-817,158}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00922() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "substring(int,int):java.lang.String",
            new int[]{1000,-1000,-944,1000,-156,804,-524,687,73,-22,196,91,470,-757,1000,552,-683,896,651,289,363,-769,-766,-537,-143,979,-1000,454,744,631,1000,-831,-618,375,-386,132,-337,239,-1000,-1000,154,-484,-1000,262,-843,-515,-1000,-590,806,-1000,902,708,270,717,130,1000,1000,-802,-397,-396,1000,513,1000,285}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00923() {
        org.junit.Assert.assertEquals("ARRAY:[C:82:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "toCharArray():char[]",
            new int[]{813,293,-751,-49,846,384,615,928,-836,800,901,-388,-741,669,-648,-259,538,-264,614,650,-554,215,-714,-12,-419,751,-705,-367,-532,589,-423,820,-962,223,-291,-278,336,-349,375,-449,461,625,-155,-392,-629,-733,-966,-313,-224,-153,75,-320,-897,-431,897,-642,218,-198,779,-115,492,-644,-472,833}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00924() {
        org.junit.Assert.assertEquals("ARRAY:[C:0", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "toCharArray():char[]",
            new int[]{619,-19,1000,145,-1000,-72,864,-1000,-13,911,912,922,1000,1000,-934,-1000,188,-1000,-1000,1000,-239,-1000,-132,1000,145,736,155,113,-411,-285,-1000,-901,290,-857,1000,684,-545,-528,716,-388,858,-1000,890,-1000,-69,1000,249,413,-1000,1000,-262,706,248,-1000,881,-546,-481,1000,-1000,300,-421,991,582,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00925() {
        org.junit.Assert.assertEquals("ARRAY:[C:0", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "toCharArray():char[]",
            new int[]{-879,-507,538,56,-365,-23,-924,519,-817,638,-1000,-1000,286,1000,911,-122,628,95,-666,59,1000,-704,-319,-340,-915,-23,208,-543,-895,550,-759,117,-906,-309,552,237,524,788,-1000,-744,931,656,-718,-924,1000,-376,1000,-1000,-966,-555,-126,-617,-440,-691,376,-197,-351,-1000,592,-206,-2,-860,-199,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00926() {
        org.junit.Assert.assertEquals("ARRAY:[C:0", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "toCharArray():char[]",
            new int[]{619,-1000,-666,280,451,-124,729,834,-1000,1000,-1000,-1000,256,476,851,279,226,310,174,787,897,-387,258,1000,721,1000,309,-697,-931,585,-510,-645,110,-863,899,186,-1000,-550,-756,-1000,1000,-1000,-1000,426,-129,-45,913,-803,408,821,-1000,-903,-504,180,642,-527,-477,543,644,-1000,-1000,950,369,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00927() {
        org.junit.Assert.assertEquals("ARRAY:[C:0", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "toCharArray():char[]",
            new int[]{371,1000,244,-651,-96,802,241,-105,77,800,1000,913,-990,1000,-1000,571,1000,-956,-330,932,-1000,-1000,-457,-1000,-959,751,-276,-28,-1000,589,-637,-198,-1000,4,-104,53,519,-349,375,405,556,511,1000,-1000,-421,472,-1000,942,-400,246,164,490,-897,-1000,1000,-421,189,1000,-435,529,388,1000,-384,-499}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00928() {
        org.junit.Assert.assertEquals("ARRAY:[C:4:24:java.lang.Character:bg==:24:java.lang.Character:dQ==:24:java.lang.Character:bA==:24:java.lang.Character:bA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "toCharArray():char[]",
            new int[]{194,-763,587,-186,-818,-553,256,-116,-816,-150,-553,1000,736,526,219,84,-247,889,161,978,-69,-462,-379,236,658,44,-232,88,-316,-18,-664,248,28,-383,243,983,-161,-955,274,-854,532,-271,-245,-508,775,-893,645,899,-39,913,237,-791,-775,-164,923,-198,-436,871,181,-52,-620,207,389,843}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00929() {
        org.junit.Assert.assertEquals("ARRAY:[C:0", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "toCharArray():char[]",
            new int[]{826,77,96,839,-58,-417,-463,167,-388,-1000,-517,-260,117,648,-124,234,-984,-1000,388,-272,-666,-1000,-1000,-828,-621,1000,-1000,478,-113,361,-1000,-1000,-119,677,-223,602,-428,-21,-89,-9,-51,731,167,-1000,352,-231,788,-1000,-604,-257,743,1000,-398,292,618,-1000,-1000,-1000,156,621,-1000,-633,1000,243}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00930() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "toCharArray(int,int):char[]",
            new int[]{-1000,-1000,-1000,1000,-857,-1000,-579,-883,256,659,1000,-544,1000,-835,-1000,-914,491,-878,1000,586,-1000,556,-802,-1000,-867,1000,687,874,181,-1000,-185,330,805,-847,1000,1000,-174,1000,-1000,-401,143,1000,-1000,-815,-251,-531,165,-1000,313,-1000,379,1000,-1000,-414,-963,-1000,530,326,1000,-355,1000,1000,731,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00931() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "toCharArray(int,int):char[]",
            new int[]{975,-696,-326,360,-941,-33,131,598,-279,-517,-494,778,352,-301,-765,-1000,601,-697,-294,-836,-1000,417,-917,-1000,-964,1000,499,-325,223,-1000,-567,-602,1000,-1000,789,-639,-530,-241,-455,965,477,1000,-296,60,305,372,971,-903,-652,-998,-750,603,355,-26,1000,-1000,-240,312,-415,-226,858,1000,1000,-779}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00932() {
        org.junit.Assert.assertEquals("ARRAY:[C:0", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "toCharArray(int,int):char[]",
            new int[]{-542,-1000,-355,-1000,97,-1000,449,-1000,594,-61,117,311,189,-816,1000,-994,-274,-686,-1000,24,498,-420,1000,575,1000,-130,793,-646,865,1000,-725,-916,-886,941,450,563,-739,-236,103,47,-1000,-354,351,318,499,507,-1000,-1000,159,333,-862,-468,173,54,-1000,931,1000,-338,-816,1000,-883,-428,-403,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00933() {
        org.junit.Assert.assertEquals("ARRAY:[C:1:24:java.lang.Character:AA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "toCharArray(int,int):char[]",
            new int[]{684,-731,601,-486,-941,-871,-202,734,331,530,-161,575,366,400,387,-1000,158,-957,-135,-1000,-22,893,-871,-1000,-848,1000,305,-348,52,-517,-226,-657,163,-1000,1000,141,-270,-426,-455,444,441,684,198,602,-195,1000,-353,-5,-652,-1000,-543,1000,293,-440,762,-237,621,676,-808,1000,750,1000,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00934() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "toCharArray(int,int):char[]",
            new int[]{396,-1000,369,-227,-941,-626,-649,244,-563,461,-948,-371,198,782,387,-1000,-788,-581,1000,-1000,403,1000,-871,-1000,-1000,1000,17,-268,443,720,594,-91,98,-1000,1000,1000,18,609,-455,792,513,1000,-506,534,-1000,635,456,227,-652,-1000,-261,1000,-1000,-1000,762,453,621,1000,-756,1000,750,1000,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00935() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "toCharArray(int,int):char[]",
            new int[]{-434,-1000,-581,564,-747,-731,8,-339,195,156,754,-79,434,-441,-981,-783,335,-690,811,-697,-1000,49,-717,-1000,-810,707,480,821,324,-1000,247,-46,913,-681,975,497,-79,381,-1000,-27,315,1000,-1000,-593,-1000,-61,377,-872,-1000,-959,313,1000,-935,-590,545,-306,-54,-80,1000,-471,1000,944,842,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00936() {
        org.junit.Assert.assertEquals("ARRAY:[C:0", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "toCharArray(int,int):char[]",
            new int[]{742,-565,-608,-681,-600,823,656,215,302,102,275,-91,-308,-912,-24,-638,989,331,400,-721,-1000,231,1000,-425,-783,210,495,-330,818,-468,66,-419,38,358,-388,-1000,-319,-1000,84,541,799,-287,-2,-489,344,1000,-325,-552,810,-182,-325,487,770,803,41,-467,-257,-201,-283,12,290,172,97,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00937() {
        org.junit.Assert.assertEquals("java.lang.String:AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "toString():java.lang.String",
            new int[]{-821,-361,-1000,-629,1000,-291,899,1000,-356,-409,-1000,-1000,232,742,886,-518,-856,752,644,-1000,-1000,-466,-717,462,-1000,-1000,-138,-136,-1000,-777,1000,-398,347,1000,639,-519,1000,1000,-1000,-729,-298,1000,-899,-407,-1000,1000,957,113,433,-196,-1000,329,225,661,-1000,-288,-727,-355,1000,-1000,794,-761,828,-581}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00938() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "toString():java.lang.String",
            new int[]{-1000,-510,569,-767,-27,-63,-417,1000,521,-151,-368,-1000,-458,-2,569,-1000,-1000,662,-233,339,-1000,201,714,1000,972,-1000,-783,549,-522,-667,-614,-27,-1000,-369,-927,72,83,1000,1000,-367,-1000,-177,-866,-43,-1000,852,335,-618,-1000,63,-1000,307,-558,496,481,508,437,-217,-120,-890,446,-1000,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00939() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "toString():java.lang.String",
            new int[]{-370,-1000,945,-353,161,-758,-671,-64,-31,1000,-621,-51,1000,-1000,1000,488,708,581,246,799,900,902,509,-655,18,-153,-199,306,761,1000,897,-702,1000,75,-701,-1000,-1000,1000,654,1000,-333,-1000,-1000,-963,-170,-1000,-697,1000,-236,-1000,-510,988,1000,988,-383,-935,-516,24,-1000,425,-549,24,93,-753}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00940() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "toString():java.lang.String",
            new int[]{-386,-28,42,867,1000,-707,-593,1000,499,360,-929,108,-1000,1000,652,627,-1000,299,1000,487,1000,-399,-868,-1000,-1000,-444,1000,-1000,1000,-777,824,-1000,561,169,460,-305,-10,388,-1000,324,-301,-1000,-547,48,538,-44,-790,907,503,-1000,-387,578,-816,557,475,-646,-36,-355,-730,704,1000,-739,-873,-6}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00941() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "toString():java.lang.String",
            new int[]{986,-152,-125,287,-971,733,23,1000,-31,-791,1000,1000,-983,1000,-156,-614,-1000,1000,-28,354,534,489,-585,109,151,1000,968,-1000,-1000,542,-931,637,-32,-137,69,-268,-11,-478,1000,-712,-426,-283,679,-890,-447,-932,663,-312,960,-638,25,-325,540,-418,-446,-681,254,-1000,458,1000,705,9,1000,663}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00942() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "toString():java.lang.String",
            new int[]{-357,-271,-444,-998,1000,-656,429,-446,-1000,-570,416,-1000,-611,67,1000,-322,-83,868,974,-493,-1000,-381,-3,416,-102,-1000,-1000,477,-354,594,-376,-435,417,867,287,-1000,1000,1000,24,-524,-835,267,-295,-57,-1000,283,474,263,-49,-385,-125,-42,-617,373,-296,-469,-690,234,606,-772,-30,-442,-515,453}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00943() {
        org.junit.Assert.assertEquals("java.lang.String:AA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "toString():java.lang.String",
            new int[]{372,-1000,368,-491,-499,623,532,176,745,663,-745,-712,1000,193,449,722,422,685,-490,-1000,-15,-211,846,-593,-1000,456,-1000,-1000,-1000,1000,-1000,-702,958,-97,-468,-108,-510,1000,-1000,727,776,980,-950,-860,-570,-1000,-674,1000,404,-392,-409,1000,914,281,-1000,-352,-568,610,-622,-851,633,-21,-821,-748}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00944() {
        org.junit.Assert.assertEquals("TYPE:java.lang.StringBuffer", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "toStringBuffer():java.lang.StringBuffer",
            new int[]{237,-1000,283,673,1000,311,-916,582,271,-121,-171,426,-200,-297,-389,-766,-1000,-581,4,183,553,-613,690,-404,525,-478,857,-1000,761,-793,407,775,-663,636,10,-193,408,-261,-933,1000,-661,-529,-1000,-771,-308,-665,-710,-65,10,-345,-481,-129,-95,1000,235,735,459,-602,-572,-673,673,-869,305,220}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00945() {
        org.junit.Assert.assertEquals("TYPE:java.lang.StringBuffer", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "toStringBuffer():java.lang.StringBuffer",
            new int[]{-754,-126,-632,7,959,-771,-806,-368,325,767,-1000,-767,790,-200,-376,-1000,-910,-449,-889,611,1000,1000,40,-109,650,695,-305,-1000,386,-284,497,1000,-227,-205,773,-1000,255,-366,-933,556,-720,-623,-1000,-749,616,-288,-852,1000,553,137,244,51,-256,889,722,1000,1000,-168,477,-658,313,-825,391,220}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00946() {
        org.junit.Assert.assertEquals("TYPE:java.lang.StringBuffer", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "toStringBuffer():java.lang.StringBuffer",
            new int[]{-519,-942,-282,256,163,1000,-144,677,1000,319,828,99,957,267,989,42,1000,700,-827,223,686,-34,430,970,-31,564,1000,472,1000,46,234,-607,-68,-255,-558,-892,144,361,380,171,804,-326,378,-470,-486,306,-249,217,1000,142,-1000,-897,1000,229,-928,-1000,1000,746,1000,4,-142,-126,-1000,-873}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00947() {
        org.junit.Assert.assertEquals("TYPE:java.lang.StringBuffer", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "toStringBuffer():java.lang.StringBuffer",
            new int[]{613,-428,-542,-590,744,866,-421,250,666,541,-938,1000,1000,-983,657,-831,149,-879,-163,817,966,170,935,163,578,-952,657,-38,1000,577,327,219,76,748,774,-1000,763,-1000,-774,116,-315,-863,505,-682,-855,-170,298,-1000,618,867,-1000,-821,446,1000,-685,-499,807,-503,220,-1000,200,-917,2,-464}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00948() {
        org.junit.Assert.assertEquals("TYPE:java.lang.StringBuffer", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "toStringBuffer():java.lang.StringBuffer",
            new int[]{-518,104,-232,592,1000,-204,-101,-418,516,310,-128,-409,-143,346,979,-1000,113,237,526,-33,432,-152,1000,-1000,1000,336,1000,120,245,-1000,340,585,-432,508,-334,-245,-183,641,-1000,-32,-912,-1000,-1000,-766,-863,1,-828,-205,-769,-119,-849,-283,-1000,804,241,866,1000,351,71,-136,642,-753,630,382}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00949() {
        org.junit.Assert.assertEquals("TYPE:java.lang.StringBuffer", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "toStringBuffer():java.lang.StringBuffer",
            new int[]{-311,-1000,381,1000,-138,-61,-1000,371,100,-369,-1000,-321,-46,-411,-1000,0,-1000,-975,-73,-808,129,608,-1000,1000,-322,-1000,176,755,882,-283,561,1000,-9,486,872,739,332,100,-1000,1000,-812,-42,-425,-1000,670,-15,-1000,633,-505,132,467,1000,-1000,266,1000,-499,1000,-1000,-1000,-260,648,-446,731,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00950() {
        org.junit.Assert.assertEquals("TYPE:java.lang.StringBuffer", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "toStringBuffer():java.lang.StringBuffer",
            new int[]{780,-832,-367,-949,-505,867,597,-971,685,-110,-28,695,-414,466,97,1000,45,868,756,-202,485,-1000,298,1000,324,419,242,-146,552,339,1000,-665,9,-171,1000,-1000,-316,-437,713,477,216,178,609,1000,-955,-819,352,-4,917,-993,57,-164,1000,1000,-847,-967,-1000,730,1,-537,-365,-1000,120,-456}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00951() {
        org.junit.Assert.assertEquals("TYPE:java.lang.StringBuffer", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "toStringBuffer():java.lang.StringBuffer",
            new int[]{532,344,-448,14,0,94,-446,372,561,335,-71,882,-350,-441,583,-930,-48,-553,-484,317,775,-361,663,-821,857,-288,172,-207,639,-541,575,1000,-177,708,276,-577,-405,-384,-980,277,-728,-859,-1000,-931,-792,-566,-182,-719,338,-696,37,-688,366,324,96,440,566,-537,162,-55,679,-961,420,-253}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00952() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "trim():org.apache.commons.lang.text.StrBuilder",
            new int[]{-447,-331,-1000,-845,133,1000,53,-68,506,-482,621,-356,-1000,214,697,-331,-967,60,10,698,-296,926,-144,-468,-707,108,-1000,587,-1000,-47,421,378,-659,-356,-616,442,-1000,102,1000,-302,66,529,33,-601,-36,765,-165,579,101,639,-955,767,-1000,-1000,-81,922,1000,-691,-91,153,-598,-246,118,-849}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00953() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "trim():org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-717,-406,-1000,-963,-1000,529,-146,484,659,1000,49,-1000,-261,-362,-291,70,436,-108,400,-689,400,683,-416,878,214,-434,442,-400,-415,400,-594,-114,-400,-273,775,-476,-256,1000,559,724,189,268,-400,-411,953,525,1000,-147,1000,-477,-219,-475,-798,-381,400,400,-334,331,-400,-953,-861,815,627}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00954() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "trim():org.apache.commons.lang.text.StrBuilder",
            new int[]{539,-1000,495,650,772,500,-511,-826,-290,92,-585,-385,562,-255,1000,-118,-1000,-744,-106,394,-446,-546,-1000,-988,571,262,234,-14,-701,412,42,355,533,-302,974,65,-186,-1000,-806,-641,-13,903,489,652,-343,1000,603,-1000,834,1000,-680,496,-1000,-600,1000,440,563,387,-51,-812,313,-829,-786,118}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00955() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "trim():org.apache.commons.lang.text.StrBuilder",
            new int[]{-676,-439,75,-628,-544,1000,-126,-526,-320,394,470,202,883,-1000,-989,-766,-23,-584,-1000,0,-1000,-831,-38,-372,657,154,1000,-622,670,-375,-638,-687,-26,80,-242,1000,472,-1000,69,37,-11,434,-42,780,111,871,1000,469,-230,911,-213,-1000,199,-335,-1000,-436,-201,-602,190,3,-1000,-668,407,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00956() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "trim():org.apache.commons.lang.text.StrBuilder",
            new int[]{954,442,-753,333,-672,-991,-834,316,63,1000,-48,1000,47,955,-71,-928,1000,-411,417,-52,-567,-375,-751,388,100,1000,-513,-849,-749,697,-557,-1000,-2,336,-1000,-690,-760,-2,588,-488,-972,-610,-868,-627,1000,-705,-1000,482,-894,-374,220,221,-894,-657,-1000,623,618,-1000,-1000,-108,-889,1000,1000,834}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00957() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "trim():org.apache.commons.lang.text.StrBuilder",
            new int[]{802,14,-57,225,-94,-991,-808,-21,409,769,217,-139,265,793,-137,-240,998,-254,488,160,-245,-745,17,234,595,888,-472,-915,-523,811,-152,-908,651,-114,-435,-479,-760,545,572,-976,-318,-280,-191,-534,396,-735,-767,661,-449,-121,188,-5,-873,-657,-659,678,618,-937,-846,-575,-363,349,425,729}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00958() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "trim():org.apache.commons.lang.text.StrBuilder",
            new int[]{516,-1000,556,-172,824,571,-301,-1000,761,-724,199,-1000,1000,-668,607,192,-1000,-710,-465,975,-1000,653,-744,-76,1000,-72,-1000,-1000,-1000,548,342,231,200,-1000,-358,920,-1000,-1000,-446,-1000,-123,1000,-393,-383,-825,670,71,218,-669,639,-1000,335,691,92,-994,1000,1000,-272,749,-1000,-1000,-1000,-215,-807}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00959() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "trim():org.apache.commons.lang.text.StrBuilder",
            new int[]{465,635,656,-78,371,190,-147,-15,-989,-164,-486,595,85,-534,-430,-778,-924,-230,285,-577,-652,-203,453,-62,-587,305,267,-495,-259,810,-722,786,780,-463,774,-20,893,-931,-348,-801,-174,371,-625,493,10,109,977,-481,503,663,-768,-707,718,-867,107,185,-796,719,-638,-589,690,-617,819,-386}));
    }
}
