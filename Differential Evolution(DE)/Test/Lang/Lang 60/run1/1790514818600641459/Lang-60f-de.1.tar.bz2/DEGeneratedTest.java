import java.lang.reflect.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Deterministic test-program decoder. Used unchanged during search and JUnit replay. */
final class DEReplay {
    public static final int DIMENSIONS = 64;
    /** Local generic bean used to create stable reflection Type and Field values. */
    public static final class GenericInput {
        public String text;
        public java.util.List<String> names;
        public java.util.Map<String, Integer> counts;
        public java.util.List<java.util.Map<String, Long>> nested;
        public int[] numbers;
        public String[] words;
    }
    static final class Genes {
        final int[] values; int at; Field lastField;
        Object jacksonBean, jacksonProvider, jacksonGenerator;
        StringWriter jacksonOutput;
        Genes(int[] values) { this.values = values; }
        int next() { return values[(at++) % values.length]; }
        int pick(int n) { return Math.floorMod(next(), n); }
    }
    public static final class Observation {
        public String token, error, generatedSource;
        public boolean reachedTarget;
        public int setupCalls, setupFailures, nullFallbacks;
    }
    public static String signature(Method m) {
        StringJoiner params = new StringJoiner(",");
        for (Class<?> t : m.getParameterTypes()) params.add(t.getTypeName());
        return m.getName() + "(" + params + "):" + m.getReturnType().getTypeName();
    }
    static Class<?> load(String name) throws ClassNotFoundException {
        return Class.forName(name, true, Thread.currentThread().getContextClassLoader());
    }
    static Method method(String target, String signature) throws Exception {
        for (Method m : load(target).getDeclaredMethods())
            if (signature(m).equals(signature)) {
                // Public methods on package-private Defects4J classes (for
                // example Gson's TypeInfoFactory) are not reflectively
                // accessible until opened on the unnamed application module.
                if (!m.isAccessible()) m.setAccessible(true);
                return m;
            }
        throw new NoSuchMethodException(signature);
    }
    static List<Constructor<?>> constructors(Class<?> type) {
        List<Constructor<?>> out = new ArrayList();
        if (!Modifier.isAbstract(type.getModifiers()) && Modifier.isPublic(type.getModifiers()))
            for (Constructor<?> c : type.getConstructors())
                if (c.getParameterTypes().length <= 6) out.add(c);
        Collections.sort(out, new Comparator<Constructor<?>>() {
            public int compare(Constructor<?> a, Constructor<?> b) {
                int byArity = a.getParameterTypes().length - b.getParameterTypes().length;
                return byArity != 0 ? byArity : a.toString().compareTo(b.toString());
            }
        });
        return out;
    }
    private static Object[] arguments(Class<?>[] types, Genes g, int depth,
                                      Observation report) throws Exception {
        Object[] args = new Object[types.length];
        for (int i = 0; i < types.length; i++) args[i] = value(types[i], g, depth, report);
        return args;
    }
    private static Object[] arguments(Method method, Genes g, int depth,
                                      Observation report) throws Exception {
        Class<?>[] types = method.getParameterTypes();
        Object[] args = new Object[types.length];
        boolean closureCompile = method.getDeclaringClass().getName().equals("com.google.javascript.jscomp.Compiler")
            && method.getName().equals("compile");
        Type[] generic = method.getGenericParameterTypes();
        boolean jacksonSerialization = method.getDeclaringClass().getName().equals(
            "com.fasterxml.jackson.databind.ser.BeanPropertyWriter")
            && method.getName().startsWith("serializeAs")
            && types.length == 3 && types[0] == Object.class;
        for (int i = 0; i < types.length; i++) {
            if (jacksonSerialization && g.jacksonBean != null) {
                if (i == 0) args[i] = g.jacksonBean;
                else if (i == 1) args[i] = g.jacksonGenerator;
                else args[i] = g.jacksonProvider;
                continue;
            }
            if (closureCompile && (List.class.isAssignableFrom(types[i])
                    || (types[i].isArray() && load("com.google.javascript.jscomp.SourceFile")
                        .isAssignableFrom(types[i].getComponentType())))) {
                // Compiler.compile takes externs and inputs in either Lists or
                // arrays depending on Closure version. Keep externs empty and
                // supply a nonempty, gene-selected input program.
                if (i == 0) args[i] = types[i].isArray()
                    ? Array.newInstance(types[i].getComponentType(), 0) : new ArrayList();
                else {
                    Object sourceFile = value(load("com.google.javascript.jscomp.SourceFile"),
                        g, depth + 1, report);
                    if (types[i].isArray()) {
                        Object files = Array.newInstance(types[i].getComponentType(), 1);
                        Array.set(files, 0, sourceFile); args[i] = files;
                    } else args[i] = new ArrayList(Collections.singletonList(sourceFile));
                }
            } else args[i] = value(types[i], g, depth, report);
        }
        return args;
    }
    private static Number number(Genes g) {
        int n = g.next();
        switch (g.pick(12)) {
            case 0: return 0; case 1: return 1; case 2: return -1;
            case 3: return Integer.MAX_VALUE; case 4: return Integer.MIN_VALUE;
            case 5: return Long.MAX_VALUE; case 6: return Long.MIN_VALUE;
            case 7: return Double.NaN; case 8: return Double.POSITIVE_INFINITY;
            case 9: return Double.NEGATIVE_INFINITY; case 10: return n / 10.0;
            default: return n;
        }
    }
    private static String string(Genes g) {
        int mode = g.pick(16), n = g.next();
        String digits = Long.toString(Math.abs((long)n));
        String sign = new String[]{"", "-", "+", "--"}[g.pick(4)];
        switch (mode) {
            case 0: return null; case 1: return ""; case 2: return " ";
            case 3: return Integer.toString(n);
            case 4: return sign + digits;
            case 5: return sign + digits + "." + g.pick(1000);
            case 6: return sign + digits + "e" + g.next();
            case 7: return sign + "0x" + Long.toHexString(Math.abs((long)n));
            case 8: return sign + "0x8" + "0".repeat(g.pick(20));
            case 9: return sign + digits + "fFdDlL".charAt(g.pick(6));
            case 10: return " " + sign + digits + " ";
            case 11: return new String[]{"true", "false", "null", "NaN", "Infinity"}[g.pick(5)];
            case 12: return "a".repeat(g.pick(25));
            default:
                String alphabet = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ+-._ /\\\t\n";
                StringBuilder s = new StringBuilder();
                int length = g.pick(25);
                for (int i = 0; i < length; i++) s.append(alphabet.charAt(g.pick(alphabet.length())));
                return s.toString();
        }
    }
    private static Object value(Class<?> t, Genes g, int depth, Observation report) throws Exception {
        if (t == String.class || t == CharSequence.class) return string(g);
        if (t == Comparable.class) return "key" + g.pick(5);
        if (t == boolean.class || t == Boolean.class) return g.pick(2) == 0;
        if (t == char.class || t == Character.class) return (char)g.pick(128);
        if (t == byte.class || t == Byte.class) return number(g).byteValue();
        if (t == short.class || t == Short.class) return number(g).shortValue();
        if (t == int.class || t == Integer.class) return number(g).intValue();
        if (t == long.class || t == Long.class) return number(g).longValue();
        if (t == float.class || t == Float.class) return number(g).floatValue();
        if (t == double.class || t == Double.class || t == Number.class) return number(g).doubleValue();
        if (t.isEnum()) {
            Object[] constants = t.getEnumConstants();
            return constants.length == 0 ? null : constants[g.pick(constants.length)];
        }
        if (t == Object.class) return g.pick(3) == 0 ? null : "object" + g.pick(5);
        if (depth >= 3) { report.nullFallbacks++; return null; }
        if (t.isArray()) {
            int length = g.pick(6);
            Object array = Array.newInstance(t.getComponentType(), length);
            for (int i = 0; i < length; i++) Array.set(array, i, value(t.getComponentType(), g, depth + 1, report));
            return array;
        }
        if (t == List.class || t == Collection.class || t == Iterable.class || t == Set.class) {
            Collection<Object> items = t == Set.class ? new LinkedHashSet() : new ArrayList();
            int size = g.pick(5);
            for (int i = 0; i < size; i++) items.add("item" + g.pick(5));
            return items;
        }
        if (t == Map.class) {
            Map<Object, Object> items = new LinkedHashMap();
            int size = g.pick(5);
            for (int i = 0; i < size; i++) items.put("key" + g.pick(5), number(g));
            return items;
        }
        if (t == java.util.Date.class) return new java.util.Date(g.next() * 86400000L);
        if (t == Class.class) return String.class;
        if (t == java.lang.reflect.Field.class) {
            Field[] fields = GenericInput.class.getFields();
            g.lastField = fields[g.pick(fields.length)];
            return g.lastField;
        }
        if (t == java.lang.reflect.Type.class) {
            if (g.lastField != null && g.pick(3) == 0)
                return g.lastField.getDeclaringClass();
            Field[] fields = GenericInput.class.getFields();
            return fields[g.pick(fields.length)].getGenericType();
        }
        if (t == java.io.Reader.class || t == java.io.BufferedReader.class
                || t == java.io.StringReader.class) {
            String content = "header,value\n" + string(g) + "," + number(g) + "\n"
                + "alpha,beta\n";
            StringReader reader = new StringReader(content);
            return t == java.io.BufferedReader.class ? new BufferedReader(reader) : reader;
        }
        if (t.getName().equals("org.apache.commons.csv.CSVFormat")) {
            Class<?> format = load("org.apache.commons.csv.CSVFormat");
            for (String fieldName : new String[]{"DEFAULT", "RFC4180", "EXCEL"}) try {
                Object result = format.getField(fieldName).get(null);
                if (t.isInstance(result)) return result;
            } catch (ReflectiveOperationException ignored) { }
            for (Method factory : format.getMethods())
                if (Modifier.isStatic(factory.getModifiers()) && factory.getParameterTypes().length == 0
                        && t.isAssignableFrom(factory.getReturnType())) try {
                    return factory.invoke(null);
                } catch (ReflectiveOperationException ignored) { }
        }
        if (t.getName().equals("com.google.javascript.jscomp.SourceFile")) {
            Class<?> source = load("com.google.javascript.jscomp.SourceFile");
            for (Method factory : source.getMethods())
                if (Modifier.isStatic(factory.getModifiers()) && factory.getName().equals("fromCode")
                        && factory.getParameterTypes().length == 2 && factory.getParameterTypes()[0] == String.class
                        && factory.getParameterTypes()[1] == String.class) {
                    String replaySource = System.getProperty("de.generated.source");
                    if (replaySource != null) {
                        try {
                            report.generatedSource = replaySource;
                            return factory.invoke(null, "de-input.js", replaySource);
                        } catch (ReflectiveOperationException ignored) { }
                    }
                    String[] unusedParameterScripts = {
                        "window.f = function(a) {};",
                        "window.f = function(a, b) { return b; };",
                        "window.f = function(a, b) { var used = b; return used; };",
                        "window['f'] = function(unused) {};",
                        "window.f = function(unused, value) { return value; };",
                        "window['f'] = function(unused, value) { return value; };",
                        "window.f = function(first, unused, last) { return last; };",
                        "window.f = function(unused) { var local = 1; return local; };",
                        "window.f = function(unused, value) { var alias = value; return alias; };",
                        "window.f = function(unused, value) { if (value) { return 1; } return 2; };",
                        "window.f = function(unused, value) { value = value + 1; return value; };",
                        "window.f = function(unused, value) { return function() { return value; }; };",
                        "window.f = function(unused) { function inner() { return 1; } return inner(); };",
                        "window.f = function(a, b, unused) { return a + b; };",
                        "window.f = function(a, unused, b, c) { return a + c; };"
                    };
                    String[] catchDependencyScripts = {
                        "window.f = function() { var saved; try { throw Error('x'); } catch (caught) { saved = caught; } return saved.stack; };",
                        "window.f = function(flag) { var saved; try { if (flag) throw Error('x'); } catch (caught) { saved = caught; } return saved.message; };",
                        "window.f = function() { var saved; try { throw Error('x'); } catch (caught) { saved = caught; } return saved.name; };",
                        "window.f = function() { var saved; try { throw Error('x'); } catch (caught) { saved = caught; } return String(saved); };",
                        "window.f = function(flag) { var saved; try { if (flag) throw Error('x'); } catch (problem) { saved = problem; } return saved.stack; };",
                        "window.f = function() { var saved; try { throw Error('x'); } catch (problem) { saved = problem; } return saved.message; };"
                    };
                    String[] genericScripts = {
                        "function f(unused, used) { var local = 1; return used; } f(1, 2);",
                        "function f() { var unused = 1; var used = 2; return used; } f();",
                        "function f(x) { var first = x; first = 3; return x; } f(2);",
                        "function f() { var unused = 1; } f();",
                        "function keep() { var dead = 1; return 7; } keep();"
                    };
                    String modified = System.getProperty("de.modified.classes", "");
                    String[] scripts;
                    if (modified.contains("RemoveUnusedVars") && modified.contains("FlowSensitiveInlineVariables")) {
                        scripts = new String[unusedParameterScripts.length + catchDependencyScripts.length];
                        System.arraycopy(unusedParameterScripts, 0, scripts, 0, unusedParameterScripts.length);
                        System.arraycopy(catchDependencyScripts, 0, scripts, unusedParameterScripts.length,
                            catchDependencyScripts.length);
                    }
                    else if (modified.contains("FlowSensitiveInlineVariables")) scripts = catchDependencyScripts;
                    else if (modified.contains("RemoveUnusedVars")) scripts = unusedParameterScripts;
                    else scripts = genericScripts;
                    try {
                        String code = scripts[g.pick(scripts.length)];
                        report.generatedSource = code;
                        return factory.invoke(null, "de-input.js", code);
                    }
                    catch (ReflectiveOperationException ignored) { }
                }
        }
        if (t.getName().equals("com.google.javascript.jscomp.CompilerOptions")) {
            try {
                Object options = t.getConstructor().newInstance();
                // In Closure Compiler, unused-variable passes are enabled by
                // CompilationLevel, rather than by a CompilerOptions enum
                // setter. Apply the real public configuration when available.
                try {
                    Class<?> levelType = load("com.google.javascript.jscomp.CompilationLevel");
                    Object advanced = levelType.getField("ADVANCED_OPTIMIZATIONS").get(null);
                    for (Method configure : levelType.getMethods())
                        if (configure.getName().equals("setOptionsForCompilationLevel")
                                && configure.getParameterTypes().length == 1
                                && configure.getParameterTypes()[0].isInstance(options)) {
                            configure.invoke(advanced, options); break;
                        }
                } catch (ReflectiveOperationException ignored) { }
                // Also set the relevant options directly for Closure releases
                // whose compilation-level helper no longer enables this pass.
                for (Class<?> current = t; current != null; current = current.getSuperclass())
                    for (Field field : current.getDeclaredFields()) {
                        String name = field.getName().toLowerCase(Locale.ROOT);
                        if (field.getType() == boolean.class && name.equals("removeglobals")) try {
                            // Closure-1 specifically guards argument removal
                            // when globals are preserved. Keep the optimization
                            // pass enabled while exercising that configuration.
                            field.setAccessible(true); field.setBoolean(options, false);
                        } catch (Exception ignored) { }
                        if (field.getType() == boolean.class
                                && (name.contains("removeunusedvar") || name.contains("removeunusedlocal"))) try {
                            field.setAccessible(true); field.setBoolean(options, true);
                        } catch (Exception ignored) { }
                    }
                for (Method setter : t.getMethods()) {
                    if (!Modifier.isPublic(setter.getModifiers()) || !setter.getName().startsWith("set")
                            || setter.getParameterTypes().length != 1) continue;
                    String name = setter.getName().toLowerCase(Locale.ROOT);
                    if (setter.getParameterTypes()[0] == boolean.class && name.contains("removeglobals")) {
                        try { setter.invoke(options, false); } catch (ReflectiveOperationException ignored) { }
                    } else if (setter.getParameterTypes()[0] == boolean.class
                            && (name.contains("removeunusedvar") || name.contains("removeunusedlocal"))) {
                        try { setter.invoke(options, true); } catch (ReflectiveOperationException ignored) { }
                    } else if (name.contains("optimizationlevel")
                            && setter.getParameterTypes()[0].isEnum()) {
                        Object[] values = setter.getParameterTypes()[0].getEnumConstants();
                        for (Object value : values) if (String.valueOf(value).contains("ADVANCED"))
                            try { setter.invoke(options, value); } catch (ReflectiveOperationException ignored) { }
                    }
                }
                return options;
            } catch (ReflectiveOperationException ignored) { }
        }
        if (t.getName().equals("com.google.javascript.rhino.Node")) {
            try {
                Class<?> ir = load("com.google.javascript.rhino.IR");
                for (String factoryName : new String[]{"script", "root", "name", "string"})
                    for (Method factory : ir.getMethods())
                        if (Modifier.isStatic(factory.getModifiers()) && factory.getName().equals(factoryName)
                                && factory.getParameterTypes().length == 0 && t.isAssignableFrom(factory.getReturnType()))
                            return factory.invoke(null);
            } catch (ReflectiveOperationException ignored) { }
        }
        if (t.getName().equals("com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser")) {
            Object parser = xmlParser(g, report);
            if (parser != null && t.isInstance(parser)) return parser;
        }
        if (t.getName().equals("com.fasterxml.jackson.databind.ser.BeanPropertyWriter")
                || t.getName().equals("com.fasterxml.jackson.databind.ser.impl.UnwrappingBeanPropertyWriter")) {
            Object writer = jacksonWriter(t, g, report);
            if (writer != null && t.isInstance(writer)) return writer;
        }
        if (t == java.awt.Graphics2D.class || t == java.awt.Graphics.class)
            return new java.awt.image.BufferedImage(80, 80, java.awt.image.BufferedImage.TYPE_INT_ARGB).createGraphics();
        if (java.awt.Paint.class.isAssignableFrom(t)) {
            java.awt.Color c = new java.awt.Color(g.pick(256), g.pick(256), g.pick(256));
            if (t.isInstance(c)) return c;
        }
        if (java.awt.Stroke.class.isAssignableFrom(t)) {
            java.awt.BasicStroke s = new java.awt.BasicStroke(g.pick(10) / 2.0f);
            if (t.isInstance(s)) return s;
        }
        if (java.awt.Shape.class.isAssignableFrom(t)) {
            java.awt.Shape s = new java.awt.geom.Rectangle2D.Double(g.next(), g.next(), g.pick(80), g.pick(80));
            if (t.isInstance(s)) return s;
        }
        if (t == java.awt.geom.Point2D.class) return new java.awt.geom.Point2D.Double(g.next(), g.next());
        if (t.getName().equals("org.apache.commons.cli.CommandLine"))
            return commandLine(g, report);
        Object domain = chart(t, g, report);
        if (domain != null) return domain;
        Object language = language(t, g, report);
        if (language != null) return language;
        List<Constructor<?>> ctors = constructors(t);
        // Older Java libraries often use public singleton constants in place of enums.
        if (ctors.isEmpty()) {
            List<Field> constants = new ArrayList();
            for (Field field : t.getFields())
                if (Modifier.isStatic(field.getModifiers()) && Modifier.isFinal(field.getModifiers())
                        && t.isAssignableFrom(field.getType())) constants.add(field);
            Collections.sort(constants, new Comparator<Field>() {
                public int compare(Field a, Field b) { return a.getName().compareTo(b.getName()); }
            });
            if (!constants.isEmpty()) {
                Object constant = constants.get(g.pick(constants.size())).get(null);
                if (constant != null) return constant;
            }
        }
        if (!ctors.isEmpty()) {
            Constructor<?> ctor = ctors.get(g.pick(ctors.size()));
            try { return ctor.newInstance(arguments(ctor.getParameterTypes(), g, depth + 1, report)); }
            catch (Exception ignored) { }
        }
        report.nullFallbacks++;
        return null;
    }
    private static Object language(Class<?> t, Genes g, Observation report) {
        if (!t.getName().equals("org.apache.commons.lang3.time.FastDateFormat")) return null;
        try {
            Method factory = t.getMethod("getInstance", String.class, java.util.TimeZone.class,
                java.util.Locale.class);
            String[] patterns = {"yyyy-MM-dd", "MM/dd/yy HH:mm:ss", "EEE, d MMM yyyy HH:mm:ss Z"};
            return factory.invoke(null, patterns[g.pick(patterns.length)],
                java.util.TimeZone.getTimeZone("UTC"), java.util.Locale.US);
        } catch (ReflectiveOperationException ignored) { }
        try { return t.getMethod("getInstance", String.class).invoke(null, "yyyy-MM-dd"); }
        catch (ReflectiveOperationException ignored) { return null; }
    }
    private static Object xmlParser(Genes g, Observation report) {
        try {
            Class<?> factoryType = load("com.fasterxml.jackson.dataformat.xml.XmlFactory");
            Object factory = factoryType.getConstructor().newInstance();
            String[] docs = {"<root><value>1</value><name>x</name></root>",
                "<root value=\"42\"><item>a</item><item>b</item></root>",
                "<root/>"};
            String xml = docs[g.pick(docs.length)];
            for (Method method : factoryType.getMethods()) {
                if (!method.getName().equals("createParser") || method.getParameterTypes().length != 1) continue;
                Class<?> p = method.getParameterTypes()[0];
                Object input = p == String.class ? xml : p == Reader.class ? new StringReader(xml)
                    : p == InputStream.class ? new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8)) : null;
                if (input == null) continue;
                try {
                    Object parser = method.invoke(factory, input);
                    if (parser != null) {
                        int advance = g.pick(4);
                        Method next = parser.getClass().getMethod("nextToken");
                        for (int i = 0; i < advance; i++) if (next.invoke(parser) == null) break;
                        return parser;
                    }
                } catch (ReflectiveOperationException ignored) { }
            }
        } catch (Throwable ignored) { }
        return null;
    }
    private static Object jacksonWriter(Class<?> requested, Genes g, Observation report) {
        try {
            Class<?> mapperType = load("com.fasterxml.jackson.databind.ObjectMapper");
            Object mapper = mapperType.getConstructor().newInstance();
            Object bean = new GenericInput();
            Class<?> javaTypeType = load("com.fasterxml.jackson.databind.JavaType");
            Object javaType = mapperType.getMethod("constructType", Type.class).invoke(mapper, bean.getClass());
            // Jackson 2.6 (used by this Defects4J project) exposes a provider
            // blueprint from ObjectMapper. Create a configured provider via
            // DefaultSerializerProvider, the supported API used by ObjectMapper.
            Object providerBlueprint = mapperType.getMethod("getSerializerProvider").invoke(mapper);
            Class<?> serializationConfigType = load("com.fasterxml.jackson.databind.SerializationConfig");
            Class<?> serializerFactoryType = load("com.fasterxml.jackson.databind.ser.SerializerFactory");
            Object config = mapperType.getMethod("getSerializationConfig").invoke(mapper);
            Object factory = mapperType.getMethod("getSerializerFactory").invoke(mapper);
            Class<?> defaultProviderType = load("com.fasterxml.jackson.databind.ser.DefaultSerializerProvider");
            Method createProvider = defaultProviderType.getMethod("createInstance",
                serializationConfigType, serializerFactoryType);
            Object provider = createProvider.invoke(providerBlueprint, config, factory);
            g.jacksonBean = bean;
            g.jacksonProvider = provider;
            g.jacksonOutput = new StringWriter();
            Object jsonFactory = mapperType.getMethod("getFactory").invoke(mapper);
            for (String factoryMethod : new String[]{"createGenerator", "createJsonGenerator"}) {
                try {
                    Method createGenerator = jsonFactory.getClass().getMethod(factoryMethod, Writer.class);
                    g.jacksonGenerator = createGenerator.invoke(jsonFactory, g.jacksonOutput);
                    break;
                } catch (NoSuchMethodException ignored) { }
            }
            if (g.jacksonGenerator == null)
                throw new NoSuchMethodException("JsonFactory.createGenerator(Writer) or createJsonGenerator(Writer)");
            Class<?> providerType = load("com.fasterxml.jackson.databind.SerializerProvider");
            Class<?> beanPropertyType = load("com.fasterxml.jackson.databind.BeanProperty");
            Method find = providerType.getMethod("findValueSerializer", javaTypeType, beanPropertyType);
            Object serializer = find.invoke(provider, new Object[]{javaType, null});
            List<Object> writers = new ArrayList();
            try {
                // Available on Jackson 2.6 and newer.
                Class<?> serializerType = load("com.fasterxml.jackson.databind.JsonSerializer");
                Method properties = serializerType.getMethod("properties");
                Iterator<?> it = (Iterator<?>)properties.invoke(serializer);
                while (it.hasNext()) {
                    Object item = it.next();
                    if (item != null && item.getClass().getName().endsWith("BeanPropertyWriter"))
                        writers.add(item);
                }
            } catch (NoSuchMethodException oldJackson) {
                // JacksonDatabind-1 predates JsonSerializer.properties(). Its
                // BeanSerializerBase stores writers in the protected _props
                // array; read that array only for these old releases.
                Class<?> base = load("com.fasterxml.jackson.databind.ser.std.BeanSerializerBase");
                if (!base.isInstance(serializer))
                    throw new IllegalStateException("Expected BeanSerializerBase, got "
                        + serializer.getClass().getName(), oldJackson);
                Field props = base.getDeclaredField("_props");
                props.setAccessible(true);
                Object array = props.get(serializer);
                for (int i = 0; i < Array.getLength(array); i++) {
                    Object item = Array.get(array, i);
                    if (item != null && item.getClass().getName().endsWith("BeanPropertyWriter"))
                        writers.add(item);
                }
            }
            if (writers.isEmpty())
                throw new IllegalStateException("ObjectMapper produced no bean property writers for DEReplay.GenericInput");
            Object writer = writers.get(g.pick(writers.size()));
            boolean requireUnwrapping = requested.getName().equals(
                "com.fasterxml.jackson.databind.ser.impl.UnwrappingBeanPropertyWriter");
            if (!requireUnwrapping && g.pick(2) == 0 && requested.isInstance(writer)) return writer;
            Class<?> transformerType = load("com.fasterxml.jackson.databind.util.NameTransformer");
            Object nop = transformerType.getField("NOP").get(null);
            for (Method m : writer.getClass().getMethods())
                if (m.getName().equals("unwrappingWriter") && m.getParameterTypes().length == 1
                        && m.getParameterTypes()[0].isInstance(nop)) {
                    Object unwrapped = m.invoke(writer, nop);
                    if (requested.isInstance(unwrapped)) return unwrapped;
                }
            if (requested.isInstance(writer)) return writer;
            throw new IllegalStateException("Generated Jackson property writer is not " + requested.getName());
        } catch (Throwable failure) {
            throw new IllegalStateException("Cannot construct Jackson BeanPropertyWriter: " + failure, failure);
        }
    }
    /** Build the non-constructible Commons CLI result through its public Parser API. */
    private static Object commandLine(Genes g, Observation report) throws Exception {
        Class<?> optionsClass = load("org.apache.commons.cli.Options");
        Class<?> optionClass = load("org.apache.commons.cli.Option");
        Class<?> parserClass = load("org.apache.commons.cli.PosixParser");
        Object options = optionsClass.getConstructor().newInstance();
        Method addOption = optionsClass.getMethod("addOption", optionClass);
        int numberOfOptions = 1 + g.pick(3);
        List<String> spellings = new ArrayList();
        for (int i = 0; i < numberOfOptions; i++) {
            String shortName = String.valueOf((char)('a' + i));
            String longName = "de-option-" + i;
            boolean hasArgument = g.pick(2) == 0;
            Object option = null;
            try {
                option = optionClass.getConstructor(String.class, String.class, boolean.class, String.class)
                    .newInstance(shortName, longName, hasArgument, "DE-generated option");
            } catch (NoSuchMethodException ignored) { }
            if (option == null) try {
                option = optionClass.getConstructor(String.class, boolean.class, String.class)
                    .newInstance(shortName, hasArgument, "DE-generated option");
            } catch (NoSuchMethodException ignored) { }
            if (option == null) throw new NoSuchMethodException("No supported Commons CLI Option constructor");
            addOption.invoke(options, option);
            spellings.add("-" + shortName);
            if (hasArgument) spellings.add("value-" + Math.abs((long)g.next()));
        }
        String[] argv = spellings.toArray(new String[0]);
        Object parser = parserClass.getConstructor().newInstance();
        List<Method> parseMethods = new ArrayList();
        for (Method candidate : parserClass.getMethods()) {
            Class<?>[] p = candidate.getParameterTypes();
            if (candidate.getName().equals("parse") && p.length >= 2 && p[0] == optionsClass
                    && p[1] == String[].class && candidate.getReturnType() == load("org.apache.commons.cli.CommandLine"))
                parseMethods.add(candidate);
        }
        Collections.sort(parseMethods, new Comparator<Method>() {
            public int compare(Method a, Method b) {
                return a.getParameterTypes().length - b.getParameterTypes().length;
            }
        });
        for (Method parse : parseMethods) {
            Object[] args = new Object[parse.getParameterTypes().length];
            Class<?>[] p = parse.getParameterTypes();
            args[0] = options; args[1] = argv;
            for (int i = 2; i < p.length; i++) {
                if (p[i] == boolean.class || p[i] == Boolean.class) args[i] = g.pick(2) == 0;
                else if (p[i] == java.util.Properties.class) args[i] = new java.util.Properties();
                else args[i] = value(p[i], g, 1, report);
            }
            try { return parse.invoke(parser, args); }
            catch (InvocationTargetException ignored) { }
        }
        throw new NoSuchMethodException("No successful public PosixParser.parse(Options,String[])");
    }
    /** Optional type recipes, shared across bugs; none contains a bug-specific expected answer. */
    private static Object chart(Class<?> t, Genes g, Observation report) throws Exception {
        String n = t.getName();
        if (!n.startsWith("org.jfree.")) return null;
        if (n.equals("org.jfree.data.Range")) {
            double a = g.next(), b = g.next();
            return t.getConstructor(double.class, double.class).newInstance(Math.min(a, b), Math.max(a, b));
        }
        if (n.equals("org.jfree.data.time.RegularTimePeriod"))
            return load("org.jfree.data.time.Day").getConstructor(int.class, int.class, int.class)
                .newInstance(1 + g.pick(28), 1 + g.pick(12), 1990 + g.pick(40));
        if (n.equals("org.jfree.data.time.TimeSeries")) {
            Object series = t.getConstructor(Comparable.class).newInstance("DE");
            Class<?> period = load("org.jfree.data.time.RegularTimePeriod");
            Constructor<?> day = load("org.jfree.data.time.Day")
                .getConstructor(int.class, int.class, int.class);
            Method add = t.getMethod("add", period, double.class);
            int count = 2 + g.pick(4), year = 1990 + g.pick(40);
            for (int i = 0; i < count; i++)
                add.invoke(series, day.newInstance(i + 1, 1, year), g.next() / 10.0);
            return series;
        }
        if (n.equals("org.jfree.data.category.CategoryDataset")
                || n.equals("org.jfree.data.category.DefaultCategoryDataset")) {
            Class<?> c = load("org.jfree.data.category.DefaultCategoryDataset");
            Object data = c.getConstructor().newInstance();
            Method add = c.getMethod("addValue", Number.class, Comparable.class, Comparable.class);
            int rows = 1 + g.pick(3), columns = 1 + g.pick(3);
            for (int r = 0; r < rows; r++) for (int col = 0; col < columns; col++)
                add.invoke(data, Double.valueOf(g.next() / 10.0), "R" + r, "C" + col);
            return data;
        }
        if (n.equals("org.jfree.data.xy.XYDataset") || n.equals("org.jfree.data.xy.XYSeriesCollection")) {
            Class<?> seriesClass = load("org.jfree.data.xy.XYSeries");
            Object series = seriesClass.getConstructor(Comparable.class).newInstance("DE");
            int count = 1 + g.pick(5);
            for (int i = 0; i < count; i++) seriesClass.getMethod("add", double.class, double.class)
                .invoke(series, (double)i, g.next() / 10.0);
            Class<?> c = load("org.jfree.data.xy.XYSeriesCollection");
            Object data = c.getConstructor().newInstance();
            c.getMethod("addSeries", seriesClass).invoke(data, series);
            return data;
        }
        if (n.equals("org.jfree.data.general.PieDataset") || n.equals("org.jfree.data.general.DefaultPieDataset")) {
            Class<?> c = load("org.jfree.data.general.DefaultPieDataset");
            Object data = c.getConstructor().newInstance();
            int count = 1 + g.pick(5);
            for (int i = 0; i < count; i++) c.getMethod("setValue", Comparable.class, Number.class)
                .invoke(data, "K" + i, Double.valueOf(g.next() / 10.0));
            return data;
        }
        return null;
    }
    static List<Method> setupMethods(Class<?> receiver) {
        List<Method> methods = new ArrayList();
        for (Method m : receiver.getMethods()) {
            String n = m.getName();
            if (!Modifier.isStatic(m.getModifiers()) && !m.isSynthetic()
                    && m.getParameterTypes().length <= 3 && !n.contains("Listener")
                    && (n.startsWith("set") || n.startsWith("add") || n.startsWith("update")
                        || n.startsWith("remove") || n.equals("clear"))) methods.add(m);
        }
        Collections.sort(methods, new Comparator<Method>() {
            public int compare(Method a, Method b) {
                return signature(a).compareTo(signature(b));
            }
        });
        return methods;
    }
    public static Observation execute(String target, String receivers, String signature, int[] genes) {
        Observation out = new Observation();
        try {
            Genes g = new Genes(genes);
            Method m = method(target, signature);
            Object receiver = null;
            if (!Modifier.isStatic(m.getModifiers())) {
                String[] choices = receivers.split(",");
                Class<?> receiverType = load(choices[g.pick(choices.length)]);
                receiver = value(receiverType, g, 0, out);
                if (receiver == null) throw new IllegalArgumentException("Receiver construction failed");
                // Compiler.compile owns a strict initialization sequence.
                // Random calls to its mutators before compilation can corrupt
                // state or spend the search budget on irrelevant setup.
                if (!receiverType.getName().equals("com.google.javascript.jscomp.Compiler")) {
                    List<Method> setup = setupMethods(receiverType);
                    int count = g.pick(5);
                    for (int i = 0; i < count && !setup.isEmpty(); i++) {
                        Method s = setup.get(g.pick(setup.size()));
                        try { s.invoke(receiver, arguments(s.getParameterTypes(), g, 0, out)); out.setupCalls++; }
                        catch (Exception e) { out.setupFailures++; }
                    }
                }
            }
            Object[] args = arguments(m, g, 0, out);
            out.reachedTarget = true;
            try {
                boolean jacksonSerialization = m.getDeclaringClass().getName().equals(
                    "com.fasterxml.jackson.databind.ser.BeanPropertyWriter")
                    && m.getName().startsWith("serializeAs") && g.jacksonGenerator != null;
                boolean arrayShape = m.getName().contains("Column")
                    || m.getName().contains("Element") || m.getName().contains("Placeholder");
                if (jacksonSerialization)
                    g.jacksonGenerator.getClass().getMethod(arrayShape
                        ? "writeStartArray" : "writeStartObject").invoke(g.jacksonGenerator);
                Object result = m.invoke(receiver, args);
                boolean closureCompile = m.getDeclaringClass().getName().equals(
                    "com.google.javascript.jscomp.Compiler") && m.getName().equals("compile");
                if (closureCompile) {
                    // Result is only a status object; the compiled JavaScript is
                    // the behavioral output that reveals whether an argument
                    // was removed from a globally exposed function.
                    Object js = receiver.getClass().getMethod("toSource").invoke(receiver);
                    out.token = "CLOSURE_SOURCE:" + stable(js, 0);
                } else if (jacksonSerialization) {
                    g.jacksonGenerator.getClass().getMethod(arrayShape
                        ? "writeEndArray" : "writeEndObject").invoke(g.jacksonGenerator);
                    g.jacksonGenerator.getClass().getMethod("flush").invoke(g.jacksonGenerator);
                    out.token = "JSON:" + Base64.getEncoder().encodeToString(
                        g.jacksonOutput.toString().getBytes(StandardCharsets.UTF_8));
                } else out.token = m.getReturnType() == void.class
                    ? state(receiver, m.getName()) : stable(result, 0);
            } catch (InvocationTargetException e) {
                if (e.getCause() instanceof VirtualMachineError || e.getCause() instanceof LinkageError
                        || e.getCause() instanceof ThreadDeath) throw e;
                out.token = "THROW:" + e.getCause().getClass().getName();
            }
        } catch (Throwable e) {
            out.token = "HARNESS_ERROR";
            out.error = e.getClass().getName() + ":" + String.valueOf(e.getMessage());
        }
        return out;
    }
    public static String run(String target, String receivers, String signature, int[] genes) {
        Observation o = execute(target, receivers, signature, genes);
        if (!o.reachedTarget || o.token.equals("HARNESS_ERROR"))
            throw new AssertionError("Cannot replay test: " + o.error);
        return o.token;
    }
    private static String state(Object receiver, String method) {
        if (receiver == null) return "VOID";
        List<String> getters = new ArrayList();
        if (method.startsWith("set") && method.length() > 3) {
            getters.add("get" + method.substring(3)); getters.add("is" + method.substring(3));
        }
        getters.addAll(Arrays.asList("getItemCount", "getRowCount", "getColumnCount", "getSeriesCount"));
        StringBuilder s = new StringBuilder("VOID");
        for (String name : getters) {
            try {
                Method getter = receiver.getClass().getMethod(name);
                if (getter.getReturnType().isPrimitive() || getter.getReturnType() == String.class)
                    s.append('|').append(name).append('=').append(stable(getter.invoke(receiver), 0));
            } catch (ReflectiveOperationException ignored) { }
        }
        return s.toString();
    }
    /** Only whitelisted value types are rendered. Never use arbitrary object toString(). */
    static String stable(Object value, int depth) {
        if (value == null) return "NULL";
        Class<?> t = value.getClass();
        if (value instanceof String || value instanceof Boolean || value instanceof Character
                || value instanceof Byte || value instanceof Short || value instanceof Integer
                || value instanceof Long || value instanceof Float || value instanceof Double
                || value instanceof java.math.BigInteger || value instanceof java.math.BigDecimal)
            return t.getName() + ":" + Base64.getEncoder().encodeToString(value.toString().getBytes(StandardCharsets.UTF_8));
        if (value instanceof Enum) return "ENUM:" + t.getName() + ":" + ((Enum<?>)value).name();
        if (t.isArray() && depth < 3) {
            StringBuilder s = new StringBuilder("ARRAY:" + t.getName() + ":" + Array.getLength(value));
            for (int i = 0; i < Math.min(64, Array.getLength(value)); i++) {
                String item = stable(Array.get(value, i), depth + 1);
                s.append(':').append(item.length()).append(':').append(item);
            }
            return s.toString();
        }
        if (value instanceof java.awt.Color) return "COLOR:" + ((java.awt.Color)value).getRGB();
        // Observe safe scalar properties of returned objects. This catches
        // changes to value caches and state while avoiding identity-based toString().
        StringBuilder observed = new StringBuilder("STATE:" + t.getName());
        int properties = 0;
        for (String name : Arrays.asList("getItemCount", "getMinY", "getMaxY",
                "getRowCount", "getColumnCount", "getSeriesCount")) {
            try {
                Method getter = t.getMethod(name);
                Class<?> r = getter.getReturnType();
                if (!r.isPrimitive() && r != String.class && !Number.class.isAssignableFrom(r))
                    continue;
                if (r == void.class) continue;
                Object result = getter.invoke(value);
                String token = stable(result, depth + 1);
                observed.append('|').append(name).append('=').append(token.length())
                    .append(':').append(token);
                properties++;
            } catch (Exception ignored) { }
        }
        return properties == 0 ? "TYPE:" + t.getName() : observed.toString();
    }
    public static void main(String[] args) {
        if (args.length > 4) {
            String source = new String(Base64.getDecoder().decode(args[4]), StandardCharsets.UTF_8);
            System.setProperty("de.generated.source", source);
        }
        String[] encodedGenes = args[3].split(",");
        int[] genes = new int[encodedGenes.length];
        for (int i = 0; i < encodedGenes.length; i++) genes[i] = Integer.parseInt(encodedGenes[i]);
        boolean closureCompile = args[0].equals("com.google.javascript.jscomp.Compiler")
            && args[2].startsWith("compile(");
        // Compiler.compile is an expensive whole-program operation. Fixed-side
        // suites are still executed twice by the runner, so capture its oracle
        // once here instead of launching three compilations just to check the
        // same deterministic source output.
        int repetitions = closureCompile ? 1 : 3;
        for (int i = 0; i < repetitions; i++) {
            Observation out = execute(args[0], args[1], args[2], genes);
            System.out.println("DE_TOKEN:" + Base64.getEncoder().encodeToString(out.token.getBytes(StandardCharsets.UTF_8)));
        }
    }
}

public class DEGeneratedTest {
    @org.junit.Test(timeout=60000L)
    public void testDE00000() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(boolean):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-112,-8,499,-1000,979,-742,-698,544,-397,448,-643,-719,1000,-405,17,-12,706,1000,685,948,-314,-421,79,74,631,-532,7,-812,1000,249,207,-691,567,-6,476,261,-611,248,-212,-30,819,189,-231,692,50,300,-725,-138,463,-774,-701,219,289,459,677,-387,-312,269,518,204,150,-869,-823}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00001() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(boolean):org.apache.commons.lang.text.StrBuilder",
            new int[]{-649,-759,-96,-953,283,198,155,736,-301,-458,62,-261,226,-389,-848,308,253,310,-165,857,-51,-38,-30,851,-411,-474,15,231,-726,756,-865,-435,324,-590,-594,385,-492,-932,625,-554,-422,-244,102,25,-432,158,332,-217,-195,957,442,211,-376,-421,908,-771,437,-550,-783,109,975,-216,843,580}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00002() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(boolean):org.apache.commons.lang.text.StrBuilder",
            new int[]{-406,-1000,880,128,-795,459,27,82,232,-859,692,-825,-436,1000,-955,-381,-1000,1000,-636,1000,-116,-583,598,-930,-676,1000,-381,-188,1000,1000,1000,1000,-368,1000,-1000,733,249,-198,1000,-944,-753,-131,452,-870,1000,-1000,-1000,-1000,1000,862,-307,-869,1000,-289,814,1000,-885,-14,950,1000,-337,-465,-86,-706}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00003() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(boolean):org.apache.commons.lang.text.StrBuilder",
            new int[]{595,1000,529,1000,633,1000,-938,387,865,-253,1000,-36,742,1000,-286,-794,-740,1000,982,-1000,1000,-346,-57,362,1000,-1000,-1000,-577,-1000,-130,-397,74,-998,-1000,842,476,496,375,-669,-181,-769,-39,-8,-839,-1000,325,464,-831,-765,-1000,1000,-403,665,1000,1000,30,1000,-253,539,-857,258,713,-928,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00004() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(boolean):org.apache.commons.lang.text.StrBuilder",
            new int[]{-616,578,534,505,-382,667,-742,702,544,-45,656,-643,-719,1000,859,321,-457,-273,1000,-1000,948,306,-421,249,1000,-45,-707,197,-187,764,-189,-269,-691,-1000,1000,620,-634,-626,-1000,493,445,1000,375,349,-1000,436,514,-16,398,-569,323,792,155,962,459,-112,526,-660,912,353,204,1000,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00005() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(boolean):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-526,273,-590,-1000,-301,-183,-688,-1000,-1000,-64,-457,-544,1000,259,889,-351,-880,716,740,-623,60,-5,-606,736,1000,909,-157,856,1000,179,-502,-705,543,248,900,-352,-1000,-272,-318,1000,1000,606,358,-518,-436,-505,1000,1000,409,-148,790,-1000,-1000,-879,-56,-1000,506,1000,1000,512,1000,-35,-788}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00006() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(boolean):org.apache.commons.lang.text.StrBuilder",
            new int[]{79,185,559,-650,595,-472,-284,-561,-418,-956,308,-994,-339,-656,-628,-437,-379,-108,-251,-425,-423,112,884,-459,-688,-903,-674,-508,-898,-461,-987,-437,542,887,-803,577,710,315,235,834,416,-373,352,-305,160,-120,-9,-36,-2,-788,338,-465,-479,-873,-715,367,-197,325,-825,-592,371,-961,441,-197}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00007() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-400,-175,676,81,-255,544,-1000,-620,-759,-30,-19,-1000,-913,1000,-26,575,-9,-497,1000,-400,392,400,377,1000,-149,-381,-519,-195,123,319,826,168,254,318,677,400,-553,-373,-313,765,-1000,-533,30,-613,400,468,-73,-453,-205,33,1000,-19,775,832,-35,567,-362,-196,400,175,-231,-1000,-871,-470}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00008() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-849,59,-223,730,734,-281,829,-1000,588,-125,799,147,-1000,-1000,638,-1000,1000,654,1000,-773,-1000,-1000,-703,-674,871,-839,-386,-669,1000,-381,-1000,1000,1000,-641,-1000,-1000,1000,1000,-855,1000,-819,-209,746,-392,-1000,-1000,-1000,100,111,83,1000,1000,468,775,1000,-1000,-855,-1000,-37,-184,310,1000,83}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00009() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{660,-658,-26,-10,162,267,674,-584,-43,-54,-296,134,778,-969,396,201,82,236,988,-1000,1000,-983,1000,-762,-212,619,479,118,27,-307,236,-129,-258,1000,137,329,192,-953,-296,367,97,-244,-79,263,400,-353,956,-717,292,-895,-66,-245,-1000,-44,266,348,-394,-1000,1000,-227,821,-400,-1000,823}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00010() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{341,-511,-500,-23,-103,1000,224,-908,291,-54,123,-406,1000,-1000,-30,304,110,-455,972,-1000,1000,-269,1000,-793,138,987,-223,431,-421,-579,133,124,-639,528,851,1000,506,-926,-622,816,-290,-11,310,441,1000,-14,1000,-548,363,-1000,-33,-847,-702,611,215,235,-177,29,1000,526,1000,-197,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00011() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-4,148,-1000,842,413,169,576,-699,1000,-433,857,-89,-656,-1000,854,-770,726,223,1000,-737,-1000,-967,-580,-620,765,-691,-372,1000,252,23,-1000,1000,660,-1000,-1000,-846,1000,1000,-1000,966,-567,-97,922,-1000,-1000,-1000,-1000,1000,370,-645,883,290,646,322,958,-1000,302,-1000,-211,-367,1000,936,172}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00012() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{872,418,-1000,-482,728,402,-181,85,-869,1000,-141,834,-787,-975,109,686,-126,745,33,1000,-686,-1000,-1000,-626,-612,784,-838,-283,1000,-1000,1000,-399,175,500,-1000,-194,-48,1000,-212,-1000,-460,-922,76,836,-1000,-679,-1000,-1000,913,633,-545,481,-171,1000,462,1000,-1000,-1000,-450,-892,-69,1000,-71,-409}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00013() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{992,-1000,912,218,-1000,-606,642,184,447,-896,169,-380,295,703,-596,247,-879,466,-1000,-559,527,-1000,-153,-245,429,-414,-593,347,-1000,1000,-1000,-971,730,274,211,-1000,-1000,-774,1000,-389,320,1000,1000,-700,991,-987,1000,1000,-873,758,973,-837,818,-202,536,1000,479,-77,975,752,637,1000,826,-409}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00014() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(char[]):org.apache.commons.lang.text.StrBuilder",
            new int[]{-339,965,623,762,84,180,-147,-75,-892,-339,-85,-397,27,789,515,264,773,-575,-823,633,-507,-472,34,184,414,-964,216,-772,-706,540,-909,-677,-943,-358,-12,-715,154,-764,-34,749,637,348,690,-92,-15,-305,571,856,300,644,898,761,663,-115,943,3,-839,777,719,-628,362,98,-587,-585}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00015() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(char[]):org.apache.commons.lang.text.StrBuilder",
            new int[]{-939,-942,-1,351,194,-255,-512,65,-441,-160,-432,-180,626,1000,558,57,-525,-1000,-654,1000,-1000,3,-73,655,508,-577,-59,-1000,-1000,279,-1000,-858,-916,-477,23,63,-281,-322,-196,339,765,369,592,604,-378,-830,759,218,300,-34,807,676,930,579,646,159,-968,837,1000,-364,-371,378,-669,-66}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00016() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(char[]):org.apache.commons.lang.text.StrBuilder",
            new int[]{909,-862,417,1000,141,358,752,865,-173,427,1000,-111,-541,-955,-1000,-761,1000,54,555,400,1000,-936,-784,-1000,546,-1000,-400,420,417,1000,1000,473,-301,1000,-191,561,-280,-214,1000,-283,-1000,575,592,-5,1000,1000,-674,1000,1000,919,-223,-165,145,-1000,901,-1000,1000,1000,1000,320,1000,-1000,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00017() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(char[]):org.apache.commons.lang.text.StrBuilder",
            new int[]{-672,-497,-1000,566,4,-253,314,731,101,114,-368,578,-736,366,-1000,-849,1000,-697,991,657,-345,-580,-621,-795,-723,245,-722,-569,1000,617,-98,152,-255,1000,-641,-109,941,526,1000,-562,-1000,1000,442,1000,-649,-229,-522,-1000,1000,-1000,213,531,-123,-1000,402,-900,1000,1000,597,636,303,-635,72,45}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00018() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(char[]):org.apache.commons.lang.text.StrBuilder",
            new int[]{423,-310,-810,-128,-1000,-183,314,667,-492,877,-373,-183,-736,366,-984,-1000,-1000,-243,-143,1000,322,-620,-1000,-1000,985,-791,-722,-354,-246,997,951,1000,-727,300,-1000,1000,1000,-1000,1000,-802,-1000,131,200,758,941,397,-27,515,120,-130,668,-99,-954,-461,299,-900,1000,1000,697,1000,768,-842,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00019() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(char[]):org.apache.commons.lang.text.StrBuilder",
            new int[]{631,785,-801,263,-441,-770,156,-54,-975,416,-524,-416,-467,640,-741,741,-788,-518,-15,116,235,-608,-44,-84,751,708,263,-783,9,71,895,404,-347,454,-5,-656,87,447,203,631,-708,795,-458,-109,497,-266,-668,-48,705,-829,291,478,228,-590,135,-413,127,740,-247,909,-296,14,357,560}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00020() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(char[]):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-1000,752,-409,76,488,566,-617,590,-589,967,-1000,-1000,-1000,205,1000,1000,1000,-1000,-1000,1000,-945,1000,-1000,761,-38,1000,1000,-214,-398,879,-162,-244,175,1000,-63,-146,-220,-975,1000,433,1000,1,-1000,1000,997,-1000,1000,-687,1000,1000,1000,-702,-1000,1000,1000,-598,894,-1000,-276,950,-87,-420,-728}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00021() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(char[],int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,560,1000,-1000,206,-985,-442,39,205,-1000,-261,1000,-816,1000,883,-48,-1000,477,1000,671,-317,979,-383,-1000,-1000,-1000,1000,264,-1000,1000,458,-752,802,319,590,152,-124,-1000,1000,-1000,-897,-1000,-140,1000,1000,311,205,283,942,652,-1000,440,1000,-1000,1000,159,1000,-709,180,1000,558,580,-1000,41}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00022() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(char[],int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-25,351,29,419,148,768,-198,-414,1000,1000,-228,222,243,-1000,-193,-363,-650,964,995,127,1000,-571,319,390,185,802,253,654,900,-180,-355,137,1000,-510,-783,-879,-1000,1000,275,-1000,-865,-529,290,-1000,352,369,-809,608,722,808,-306,-81,-20,665,-1000,125,-470,957,454,-960,-881,-535,-886,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00023() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(char[],int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-366,-869,189,-253,-423,564,-617,-1000,1000,956,-1000,332,440,-1000,-787,578,-292,967,642,97,1000,-348,331,986,983,667,-555,-297,-560,-897,206,-444,-703,-300,-843,-1000,-243,176,-718,852,-412,1000,-753,-54,459,-180,-605,-355,-113,-1000,-539,27,-400,-1000,-71,-179,-300,80,-167,-559,248,-356,169,376}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00024() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(char[],int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,1000,-509,-564,-306,-98,-587,-575,1000,-151,-1000,-1000,-208,939,-153,-493,90,604,505,191,294,238,-309,1000,-836,171,-815,339,-985,654,180,-349,679,-235,-391,-193,-511,-1000,1000,232,88,-1000,-821,167,1000,15,309,477,942,409,-1000,1000,-1000,942,271,234,-333,-132,57,537,-823,155,-1000,114}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00025() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(char[],int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{444,-1000,509,-141,-51,341,-518,-965,-715,-378,20,1000,493,206,451,-606,-581,254,562,962,1000,-540,989,986,1000,40,862,223,1000,1000,-577,-316,756,-1000,-466,110,-783,-569,6,117,-429,949,139,32,864,-1000,-97,-10,-1000,-499,-262,344,793,-1000,-526,15,83,817,-185,-1000,-65,-1000,1000,-436}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00026() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(char[],int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-723,-118,-818,-385,153,-1000,-622,-941,-503,738,253,-1000,224,1000,485,-681,1000,-440,932,858,441,-106,751,636,-137,906,596,1000,-1000,-421,-225,44,-820,1000,879,372,-584,-288,-581,-896,-194,1000,-1000,-242,-278,54,478,255,115,740,-841,387,0,89,1000,166,188,-846,68,1000,-244,-883,-225,-12}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00027() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(char[],int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-1000,482,786,-64,98,-144,-190,-816,-1000,-947,1000,955,722,453,-1000,307,-520,1000,738,971,-1000,923,-1000,1000,14,1000,-185,-178,-1000,-665,-290,710,504,-718,133,-1000,-1000,-1000,1000,-897,1000,-140,38,712,1000,256,1000,-1000,-423,704,745,942,-717,-581,258,-43,1000,490,705,-1000,998,1000,-519}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00028() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(char[],int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-815,-93,-306,-936,-64,-86,359,-422,887,733,770,116,-241,935,780,-76,-941,345,-990,-223,-139,112,-268,927,245,-179,-743,786,-594,995,149,353,-960,728,-613,164,-936,848,129,-380,925,-988,155,976,802,450,-763,-35,867,677,704,51,-570,441,-714,675,266,411,-24,-535,-269,650,-942,391}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00029() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(char[],int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-73,-448,-279,-340,-1000,-693,-338,925,-692,-872,456,750,-719,-208,12,826,257,-400,-45,1000,-423,50,330,168,103,513,82,466,-257,996,-185,193,737,-27,-774,-525,-269,-507,737,-482,-680,400,-787,706,-502,-276,599,-20,-1000,-1000,1000,-785,-265,-946,-1000,1000,1000,94,136,-414,-67,117,270}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00030() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(double):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-508,1000,415,573,313,-801,-807,928,365,126,-88,53,299,-615,512,-581,899,427,-520,-512,517,1000,-312,581,1000,532,-347,-430,400,341,792,543,1000,682,261,-62,-103,251,-685,1000,-23,99,-860,-750,-106,-214,-463,-53,-485,-241,-443,205,49,924,188,-429,953,1000,-40,1000,1000,531,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00031() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(double):org.apache.commons.lang.text.StrBuilder",
            new int[]{-881,-483,703,72,509,362,-41,-1000,986,48,908,-184,617,-402,422,835,-358,-331,1000,-1000,-865,-74,970,-5,-744,419,-405,-1000,257,1000,-395,674,-170,736,-177,-934,-901,135,244,-993,929,728,789,-393,134,316,794,381,-622,835,-54,203,98,818,719,-367,-682,914,416,-328,914,-47,69,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00032() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(double):org.apache.commons.lang.text.StrBuilder",
            new int[]{137,1000,-619,815,-511,961,304,111,-802,-496,812,-541,-247,-1000,-1000,96,-1000,-301,-1000,132,446,268,1000,715,968,-782,856,-1000,-943,-1000,1000,228,1000,-488,1000,256,238,1000,-420,96,933,99,471,-683,-1000,1000,79,-840,730,226,-1000,-486,823,-712,181,654,-1000,318,1000,178,-866,-1000,-84,-933}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00033() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(double):org.apache.commons.lang.text.StrBuilder",
            new int[]{-679,410,60,1000,1000,1000,-536,-738,-63,1000,406,230,-237,-630,-1000,512,-1000,259,-595,-176,124,1000,1000,-149,912,405,872,-1000,-278,-1000,891,646,531,865,1000,261,80,-182,-248,-279,1000,-1000,226,-1000,-1000,-746,-90,-436,1000,-485,-1000,-1000,1000,-24,847,1000,-813,562,1000,879,-513,-423,668,-844}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00034() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(double):org.apache.commons.lang.text.StrBuilder",
            new int[]{-881,-1000,653,689,1000,220,499,-1000,1000,48,862,-212,269,472,218,1000,-735,239,-588,-770,-1000,-336,1000,-265,-458,1000,-286,-346,336,1000,-395,141,-580,349,-177,-1000,-906,-688,-734,-1000,167,-367,601,-784,1000,316,1000,1000,-825,835,-285,539,98,510,89,-367,-1000,253,416,-263,1000,1000,1000,-622}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00035() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(double):org.apache.commons.lang.text.StrBuilder",
            new int[]{-144,-681,703,167,-5,97,667,-838,750,48,1000,-648,1000,-490,902,631,-310,-508,-248,-951,-1000,-1000,970,345,-1000,419,-1000,-853,-104,1000,-664,-208,-148,-4,-83,-881,-677,907,-399,-518,826,418,1000,-491,830,670,1000,228,-622,1000,382,1000,382,378,-628,-1000,-1000,937,244,-1000,973,-47,312,-28}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00036() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(double):org.apache.commons.lang.text.StrBuilder",
            new int[]{36,86,400,813,-280,519,342,61,427,556,343,-360,-174,367,-173,22,488,-16,-81,-411,-930,69,957,153,-1000,-57,-131,-468,-618,256,-232,931,1000,1000,-1000,-45,-646,499,837,115,753,-626,938,-338,-485,-340,259,-371,263,-131,-469,-390,505,-223,947,-3,-684,947,1000,272,752,596,200,146}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00037() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(float):org.apache.commons.lang.text.StrBuilder",
            new int[]{196,393,519,1000,-36,-725,82,-323,889,677,427,274,220,146,-498,-175,-490,-1000,-324,415,-1000,-1000,550,1000,-102,-236,-980,-892,511,-1000,-703,-1000,-590,-861,612,178,404,-1000,273,830,811,1000,-253,-3,94,-815,-44,1000,514,-1000,320,-979,549,1000,-291,-320,-969,1000,-494,-1000,535,-863,37,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00038() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(float):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-697,-596,1000,-616,-378,-811,-858,1000,925,-779,1000,1000,-262,158,-1000,-962,1000,786,-78,1000,897,-1000,907,-546,335,644,-407,871,733,1000,514,673,-1000,270,-35,-107,1000,669,-564,-1000,85,1000,-535,-335,74,1000,147,-797,87,1000,-783,-447,844,1000,-1000,-239,-1000,703,300,580,740,-238,978}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00039() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(float):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,1000,332,482,64,-542,-189,-469,-870,-738,928,390,-129,76,618,1000,-1000,-1000,1000,1000,134,-1000,-958,1000,1000,-1000,163,253,619,-1000,570,-117,-1000,-620,589,542,729,293,-395,1000,-267,758,-1000,-460,-1000,251,1000,1000,1000,186,738,472,161,270,-1000,1000,323,735,-223,1000,-1000,413,922,-157}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00040() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(float):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,38,800,-558,383,599,-628,702,435,-521,-304,-127,-355,-57,-4,422,945,-275,475,-473,24,-774,451,238,250,-1000,-544,1000,-27,-120,-391,346,-534,215,577,589,-82,147,521,830,682,-437,-1000,-175,-421,566,529,-375,642,1,-129,690,358,-1000,-1000,1000,229,373,-378,182,-1000,-924,-454,-831}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00041() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(float):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-1000,813,-778,482,1000,168,1000,-531,481,87,-995,-1000,733,-1000,-1000,-1000,1000,-1000,-1000,-1000,-67,541,650,755,1000,-240,1000,1000,-449,-827,-484,-282,1000,1000,342,-1000,-26,877,-1000,1000,-1000,-782,530,1000,609,-879,-1000,-957,-1000,904,-731,432,-1000,-852,-768,1000,211,-1000,-1000,-1000,-1000,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00042() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(float):org.apache.commons.lang.text.StrBuilder",
            new int[]{246,-1000,1000,1000,315,-1000,453,636,1000,325,1000,-543,-181,-972,-1000,-567,-1000,1000,-241,136,-597,-779,1000,1000,75,228,-1000,-1000,685,-1000,-1000,-310,-1000,-658,197,-417,-996,-1000,962,689,1000,446,-162,-25,484,-215,101,508,120,-1000,-310,-1000,1000,1000,-1000,-1000,347,1000,-494,-1000,611,-1000,-937,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00043() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-567,1000,-1000,1000,894,-396,1000,482,1000,116,457,953,431,1000,217,823,1000,757,-1000,1000,232,943,-570,1000,72,-1000,-868,1000,-1000,-550,-1000,-1000,732,-1000,559,1000,-1000,-418,1000,-1000,1000,1000,-220,-670,36,-19,-1000,1000,1000,535,1000,1000,543,-996,853,811,-400,1000,1000,250,-1000,-954,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00044() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-468,233,545,908,823,-851,1000,166,1000,95,175,881,-796,1000,320,449,-1000,1000,-1000,620,379,158,1000,563,-169,-1000,-638,1000,-3,-685,-1000,-1000,475,-600,67,1000,93,-507,1000,-405,579,1000,-1000,-684,-1000,-34,-643,457,1000,1000,408,869,543,141,856,518,119,730,1000,111,-1000,147,-424,952}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00045() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-14,-876,-176,-50,12,-537,-533,19,-128,461,-763,-252,202,132,31,-428,-283,441,-162,574,282,476,-954,-561,-575,1000,324,-1000,-8,423,-338,239,744,445,-481,523,93,68,-761,988,1000,-747,485,515,521,625,892,-277,-911,-832,-1000,-302,-884,651,-279,-173,260,-492,-1000,-1000,349,2,118,376}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00046() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-651,-439,177,-385,222,-666,270,437,959,-256,-823,557,-842,131,-1000,-180,-132,1000,475,855,770,191,1000,786,146,-404,-655,207,558,-765,-722,-1000,69,1000,-400,-6,315,65,-299,742,899,-285,-1000,-835,-1000,466,-600,455,-1000,732,-368,874,-125,265,457,764,465,-1000,-369,337,-1000,597,1000,-451}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00047() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-704,682,922,374,-561,994,1000,1000,182,185,143,-398,539,-1000,-686,-355,1000,-1000,1000,-74,510,685,694,158,-1000,-746,-133,985,-1000,-437,-1000,401,1000,-1000,1000,879,73,1000,716,523,1000,-1000,-1000,137,1000,-429,-31,43,912,-954,908,-45,635,-711,663,1000,-383,905,52,-1000,-954,633,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00048() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-375,-646,-1000,-972,-194,729,399,966,-449,466,103,917,-556,955,861,-74,-795,-184,987,-1000,-971,-1000,-1000,870,242,-519,12,-13,-860,-422,-753,-188,-1000,-1000,-20,-733,680,81,-834,518,-1000,-1000,90,-549,-717,348,-721,-1000,1000,1000,125,-552,1000,167,-549,1000,-123,-743,1000,1000,455,1000,993,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00049() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-14,-691,-176,558,390,-467,-533,1000,1000,187,702,1,248,243,-1000,-816,447,-89,-564,1000,-418,944,-65,572,-605,-775,-578,-1000,-100,423,-506,-260,492,796,-1000,1000,529,190,-761,988,61,1000,-367,-1000,728,1000,-53,-208,43,280,-1000,444,-391,93,-713,-175,1000,-554,1000,-131,-948,-1000,-414,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00050() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.Object):org.apache.commons.lang.text.StrBuilder",
            new int[]{113,-701,1000,73,849,167,1000,102,-323,514,-349,-921,-636,174,821,1000,-147,263,-78,373,669,-1000,-936,1000,675,372,-433,-892,20,-932,-1000,1000,1000,695,713,-549,1000,1000,-694,884,1000,-1000,528,855,1000,1000,-1000,118,-204,-19,1000,177,-501,1000,622,-59,441,-851,-570,-261,918,-1000,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00051() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.Object):org.apache.commons.lang.text.StrBuilder",
            new int[]{119,-94,871,266,-1000,399,-13,-467,527,-794,279,254,585,16,1000,-1000,313,34,-539,615,-94,-1000,-145,-34,-1000,-183,738,452,334,1000,805,-433,-752,861,-793,682,-646,410,1000,-859,400,671,599,-481,-977,-911,-395,1000,503,871,-751,-1000,-577,298,-364,14,-257,-399,1000,950,-793,-690,1000,152}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00052() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.Object):org.apache.commons.lang.text.StrBuilder",
            new int[]{-328,828,362,-716,-66,141,-719,1000,183,970,-404,1000,-342,-335,622,-300,-36,202,-236,-115,-1000,728,45,889,-1000,176,149,297,1000,893,895,-1000,-519,-80,-582,1000,199,693,-887,-55,-1000,749,743,-638,295,-1000,-874,-165,-941,61,-685,-333,-646,-244,570,-55,293,1000,-537,551,370,-746,-654,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00053() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.Object):org.apache.commons.lang.text.StrBuilder",
            new int[]{-240,-721,-166,-187,-135,524,817,210,278,-589,-449,235,-96,208,186,1000,841,479,-208,-466,350,-1000,-65,965,-690,260,-516,-462,-286,-919,-509,373,489,220,332,-310,400,354,-546,159,400,133,293,891,-956,-636,-405,820,343,-154,-271,409,132,-453,136,1000,778,-241,-118,818,204,-537,110,-88}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00054() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.Object):org.apache.commons.lang.text.StrBuilder",
            new int[]{-240,-791,1000,304,-541,484,1000,-167,266,-595,-286,52,114,-6,581,-80,-136,424,-278,354,215,-208,61,574,-1000,-19,95,-279,-286,110,-228,578,328,495,199,57,400,445,-311,-524,400,-98,669,312,-956,400,-400,1000,241,-562,-109,132,-354,-453,136,1000,778,-357,209,921,-44,-1000,193,30}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00055() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.Object):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-1000,976,-300,-1000,919,701,461,854,-828,-742,725,125,572,370,-1000,667,525,-830,660,-62,908,-137,41,-1000,265,-127,715,-1000,737,1000,206,-1000,278,-1000,1000,-1000,183,637,-722,-1000,671,1000,414,-1000,-1000,1000,1000,-316,152,-764,-692,-449,-1000,-1000,1000,1000,-461,1000,491,-814,339,1000,-398}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00056() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.Object):org.apache.commons.lang.text.StrBuilder",
            new int[]{-937,-889,-1000,82,-338,856,894,-62,465,-1000,71,711,-1000,917,417,304,-549,597,-818,-866,647,-772,313,-512,-324,-232,-1000,602,-1000,-237,500,-300,104,518,163,94,-1000,1000,383,-1000,175,1000,-1000,698,-1000,-745,268,908,-390,405,-1000,97,662,-1000,-1000,1000,1000,192,1000,1000,-864,815,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00057() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.Object):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-265,-866,-520,-192,400,252,459,822,-420,-249,577,-528,334,212,418,-263,398,-151,-444,-463,-992,250,974,-431,542,-1000,-62,-13,-324,664,-691,-627,-202,-568,611,-488,305,187,14,142,484,84,241,-434,-1000,271,743,-566,644,-649,-510,988,-1000,-364,477,120,133,1000,15,-262,-163,884,-468}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00058() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-576,-355,-586,-905,299,-741,434,1000,-158,997,-920,316,841,952,-605,747,-472,-791,497,522,232,-1000,120,-1000,372,412,-546,-585,326,537,-537,567,-1000,1000,445,-1000,-1000,-703,-543,-417,395,-943,-765,-727,-288,115,53,239,-815,604,429,891,-722,-377,-886,1000,-102,1,-727,568,236,-329,1000,-163}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00059() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-206,-450,34,432,1000,-758,908,1000,1000,454,55,684,-108,212,346,-197,1000,387,-1000,414,891,-719,-624,-601,733,-1000,994,-87,39,16,1000,829,135,-469,-1000,-1000,-1000,910,-356,646,1000,-1000,-1000,221,-597,-533,251,-468,-122,656,-60,492,686,308,-1000,1000,-197,-1000,-1000,-126,63,-1000,822,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00060() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-220,658,-403,319,-211,-264,420,-213,422,563,96,-41,130,-452,-1000,-873,-870,-105,962,-890,-433,-320,-261,-235,-928,-34,237,905,30,-1000,-28,-295,-399,-290,1000,1000,287,-309,985,-120,-190,-434,716,743,455,-45,-785,-557,-190,88,-86,283,-677,-462,1000,-388,467,533,-224,655,-7,-658,-687,326}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00061() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-422,704,-39,1000,-704,857,768,-123,-211,-1000,226,185,379,151,-496,158,381,326,-1000,328,-1000,-125,1000,1000,538,1000,1000,304,-1000,-277,-35,79,1000,1000,-153,1000,1000,-267,463,845,1000,1000,-778,158,-678,-682,115,901,-460,-150,1000,-502,842,547,-571,-606,348,54,437,-1000,-992,-231,358,-111}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00062() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-451,652,-1000,894,-176,-746,862,400,-679,-671,-164,1000,-38,400,132,323,-257,649,496,-328,-191,-350,217,-1000,-1000,236,-1000,485,-400,-1000,251,400,-1000,773,1000,1000,931,613,1000,354,-511,1000,1000,1000,-722,-770,394,-221,-913,999,97,783,-835,-193,516,256,868,-54,628,589,-1000,80,287,703}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00063() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,407,610,1000,194,999,607,-1000,18,-1000,-237,-652,834,-1000,-84,-203,115,261,-1000,40,66,678,1000,1000,914,1000,1000,-581,-1000,-114,1000,-1000,869,-66,-1000,137,532,-1000,-1000,779,301,257,-1000,-323,-210,-82,-1000,859,-43,-956,545,-543,1000,1000,-751,-1000,558,505,-95,-269,-642,98,-838,-587}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00064() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{95,-139,-113,-126,-377,-41,268,499,-471,-526,706,822,476,189,985,478,919,203,-511,48,-1000,-1000,305,144,452,952,1000,875,-502,-669,-89,913,1000,540,180,279,897,157,1000,-21,551,-496,104,1000,-556,-959,513,686,-885,-97,338,-29,871,378,459,-173,97,-1000,1000,-496,-2,-1000,1000,725}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00065() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-751,-538,-432,-85,-1000,689,-502,502,-197,-1000,180,512,-1000,504,1000,-267,-358,-918,-786,-75,-951,-76,1000,1000,-510,-573,1000,46,-77,-408,-1000,1000,850,1000,563,840,277,385,1000,1000,-334,470,519,879,424,659,-338,611,-250,-91,1000,1000,570,-831,-65,993,163,-1000,403,-1000,197,191,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00066() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.String,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,752,-454,767,680,-337,785,-879,-224,-548,503,-263,552,803,1000,-209,591,542,-1000,-466,-24,-1000,-618,58,-378,114,-526,258,849,-112,-233,-1000,-51,513,1000,67,525,1000,1000,-1000,254,-810,678,-1000,944,-362,689,-1000,327,125,-175,-1000,-969,1000,769,368,-470,654,43,145,-845,-712,-621,-226}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00067() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.String,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-342,1000,-392,-291,193,-831,163,792,-409,507,339,1000,373,333,-1000,-500,248,1000,-342,-548,762,970,251,-1000,436,559,-228,612,-109,-670,-399,-1000,910,277,1000,845,-199,1000,-1000,-1000,512,-774,366,673,-675,-1000,690,-444,82,-130,-982,-1000,-1000,872,883,653,-518,372,1000,997,-1000,-745,1000,410}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00068() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.String,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{29,-573,484,-716,294,-934,-649,-135,-428,-687,-72,-98,526,396,679,894,-404,-861,-925,1000,310,-25,-7,1000,-35,-350,-478,-329,649,-584,-525,921,-275,-625,-1000,-859,1000,-204,-129,505,-400,168,-202,-1000,210,-80,656,177,-477,144,99,1000,1000,-192,-1000,-740,185,931,-1000,316,318,-144,-518,-984}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00069() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.String,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-922,-1000,441,-66,1000,-37,-612,-627,630,-168,184,768,526,894,1000,1000,-362,-777,-1000,626,-840,-1000,187,1000,209,-252,-1000,145,-438,-219,231,812,-554,-873,-790,-1000,608,526,-42,-91,-594,-195,642,-651,1000,399,627,774,472,-460,-143,879,616,-68,-1000,-358,-837,1000,-1000,1000,1000,604,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00070() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.String,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-367,-1000,-359,292,633,34,538,-839,1000,788,741,801,-608,-562,-1000,-569,1000,264,-460,-318,1000,666,-908,-1000,-473,498,-1000,-648,411,-254,789,1000,-726,-1000,26,-91,-189,-857,898,741,36,-1000,363,-510,639,1000,-909,1000,-1000,-981,-244,347,1000,285,-110,-21,722,1000,176,378,-499,-408,-698}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00071() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.String,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,473,-221,487,530,158,701,418,-409,-1000,389,1000,373,600,-753,-84,666,1000,-283,-836,25,-430,-628,-1000,-227,174,-577,533,96,-229,204,-1000,1000,250,1000,263,-1000,1000,-269,-1000,505,-871,807,1000,-675,23,682,-952,255,-684,-1000,-1000,-1000,1000,1000,653,-841,813,40,145,-642,-745,288,-341}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00072() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.String,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,125,192,1000,1000,-29,647,469,954,-1000,93,564,392,156,478,361,810,367,-452,-253,-119,-1000,-696,-525,311,1000,-1000,88,768,368,746,-1000,199,136,474,779,-951,550,939,-889,-44,-1000,375,112,-671,202,-718,-529,-524,-121,196,-1000,-1000,709,998,616,163,640,109,133,-707,-260,-359,-386}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00073() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.String,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{960,932,289,880,-798,-496,989,-316,-150,886,37,-753,498,-828,70,-891,284,-982,810,-112,825,-187,-212,-762,612,516,394,-994,857,247,-286,-280,213,-570,210,671,-1,-751,682,227,614,-486,-869,-284,-321,642,-816,-711,-898,370,520,-554,-251,101,419,-373,687,-690,-33,-824,-913,-694,715,290}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00074() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.String,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-217,-1000,-221,565,1000,613,1000,-674,690,-802,323,986,1000,166,954,832,173,418,-58,289,-520,-1000,-620,130,-357,174,-750,-3,150,356,857,-428,524,-880,220,-246,-473,1000,-169,-472,-33,-839,-277,-109,840,826,169,-1000,255,-805,-879,-660,-447,1000,-225,-847,-862,1000,-636,145,487,730,-61,-81}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00075() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.String,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-409,-1000,-457,203,707,-133,-9,-1000,1000,-1000,-421,224,766,831,1000,1000,143,-873,-267,1000,-576,-1000,213,903,893,393,-1000,-304,823,-50,-115,-280,-564,-893,751,-313,490,1000,730,-1000,-1000,-592,96,-1000,463,356,-500,-196,729,-272,537,-596,-357,603,-927,-322,-136,1000,-1000,-537,269,206,86,290}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00076() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.StringBuffer):org.apache.commons.lang.text.StrBuilder",
            new int[]{761,335,4,103,-214,929,127,1000,-410,254,-410,708,-60,352,56,-19,-72,344,-699,-166,1000,-513,-546,17,1000,1000,-688,926,777,-529,-1000,904,-908,158,184,-1000,-1000,176,623,-104,372,-1000,-630,473,1000,-585,-447,78,-708,-87,460,268,324,-146,-1000,871,1000,40,1000,87,-293,-223,-160,-422}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00077() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.StringBuffer):org.apache.commons.lang.text.StrBuilder",
            new int[]{450,-606,28,172,-173,921,1000,-858,430,606,-897,83,304,-689,-175,-1000,666,-159,208,469,-911,533,-530,1000,138,-158,-949,-865,-10,120,-784,86,789,376,264,71,-271,-19,377,88,-886,16,-988,-777,1000,-73,-1000,-695,-1000,-418,389,-430,-72,-76,-586,89,1000,1000,133,-1000,191,-687,-123,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00078() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.StringBuffer):org.apache.commons.lang.text.StrBuilder",
            new int[]{741,-970,-1000,-966,-500,944,424,241,11,-205,917,456,-312,-479,379,-658,-468,1000,293,-442,112,568,155,93,777,-20,-482,-187,467,-1000,-1000,729,-937,309,43,-858,-815,-2,-569,-1000,-1000,-965,-373,606,1000,265,-208,-330,-1000,-257,1000,-1000,1000,-1000,-676,541,796,-397,456,-216,20,-223,727,-382}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00079() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.StringBuffer):org.apache.commons.lang.text.StrBuilder",
            new int[]{-136,464,1000,-207,436,964,98,489,-525,732,67,-198,-118,-77,82,-469,293,-175,-872,296,231,1000,-948,323,-87,1000,-1000,354,-76,676,-696,-801,571,257,504,640,-236,-9,1000,982,623,209,-645,-284,1000,-1000,-383,91,-265,-730,-421,221,-1000,1000,-688,403,325,714,-748,-179,-582,1000,616,771}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00080() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.StringBuffer):org.apache.commons.lang.text.StrBuilder",
            new int[]{701,-755,696,-776,639,362,1000,606,1000,404,-864,57,333,-716,-649,-1000,1000,400,622,233,-558,554,-149,72,336,-483,-522,-1000,-38,-97,-639,515,-1000,166,-222,298,713,1000,1000,77,-1000,-1000,-847,-753,1000,252,-441,-552,-1000,-361,-166,-276,-939,496,102,-193,1000,1000,217,-1000,889,-1000,422,823}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00081() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.StringBuffer):org.apache.commons.lang.text.StrBuilder",
            new int[]{76,-403,-690,122,-860,1000,992,-438,-1000,-227,-397,138,-496,-701,1000,-432,765,621,-14,-974,238,587,737,-376,371,927,-970,214,804,-525,-430,1000,-75,34,884,-1000,-1000,-403,-1000,-1000,198,55,111,642,1000,635,582,-688,-337,-361,1000,-645,39,-590,-762,467,-648,-1000,543,592,-665,1000,486,186}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00082() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.StringBuffer):org.apache.commons.lang.text.StrBuilder",
            new int[]{15,-241,-650,-408,739,338,513,-1000,-373,-583,-80,-911,13,-1000,358,-1000,-274,662,1000,-868,-805,998,469,641,-1000,-1000,-1000,-1000,-557,-1000,-213,1000,151,174,1000,858,509,284,-74,-488,-1000,1000,183,-570,1000,252,482,-1000,-459,-1000,256,-1000,242,-897,1000,-791,-452,-363,-341,-454,333,992,603,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00083() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.StringBuffer):org.apache.commons.lang.text.StrBuilder",
            new int[]{149,368,-16,721,-313,-434,-458,-740,-249,655,-1000,665,537,1000,1000,755,470,-621,-592,-976,183,251,166,-737,164,496,446,562,-333,892,413,-1000,-261,-1000,-552,865,-282,66,-467,697,584,55,-772,165,42,124,-1000,75,915,321,388,45,549,564,-315,515,-968,-34,-1000,368,-157,-101,812,455}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00084() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.StringBuffer,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-873,-1000,1000,-1000,282,-388,108,1000,957,328,851,-181,15,717,1000,-854,875,-1000,-1000,1000,-1000,-22,371,1000,-1000,1000,679,-211,-1000,214,1000,-1000,114,-1000,176,1000,-1000,1000,806,-225,-161,1000,32,635,-779,696,1000,1000,-149,-1000,1000,1000,1000,-532,1000,1000,-636,-1000,953,-1000,78,1000,-1000,898}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00085() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.StringBuffer,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-495,538,-667,937,399,-729,659,-983,-485,490,26,89,193,-1000,-87,715,244,525,694,592,-62,19,711,-388,428,-776,-385,103,1000,-321,668,-680,-1000,1000,1000,1000,1000,515,917,-156,1000,-783,-1000,31,1000,1000,294,142,-641,-103,606,704,478,1000,284,-490,-771,173,-669,516,-103,-1000,-550}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00086() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.StringBuffer,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-813,-191,1000,-605,624,1000,145,191,200,221,-491,209,-1000,39,-1000,384,667,-70,-319,673,871,-713,-1000,-503,-927,188,-1000,-1000,47,842,-550,1000,-1000,324,1000,812,1000,1000,-88,1000,-188,593,1000,-1000,881,1000,-199,558,324,-372,-211,1000,-78,650,1000,308,772,-510,1000,-572,1000,509,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00087() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.StringBuffer,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-634,144,467,-832,711,786,-1000,-16,929,323,-911,718,-343,-184,-918,-1000,777,-876,-818,-45,-495,942,-867,-838,400,-211,-580,-562,1000,222,467,336,1000,-1000,514,1000,-91,1000,650,1000,723,-397,27,-261,331,230,-1000,1000,-1000,320,942,1000,-723,1000,780,-6,-753,-150,999,-852,607,-1000,324,141}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00088() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.StringBuffer,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{485,-1000,580,-1000,1000,194,459,608,367,-527,1000,-458,-391,-1000,-246,-165,1000,-1000,-351,1000,-361,226,-851,1000,-1000,812,-1000,-1000,-1000,789,1000,-1000,-388,-532,761,-345,497,563,849,1000,7,1000,1000,-953,-1000,772,764,948,935,-862,930,1000,524,61,1000,-16,270,-182,1000,884,-343,963,-1000,497}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00089() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.StringBuffer,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{283,492,-293,849,346,343,-1000,607,162,-96,-927,650,446,-108,-396,-295,-1000,-483,-236,-510,948,1000,-482,-498,1000,-226,673,483,-391,-709,-629,1000,-1000,-567,347,922,-558,1000,-107,-20,-441,-1000,-329,231,1000,-1000,-210,583,128,1000,110,291,-787,469,-609,567,-198,-260,766,-600,-711,108,1000,-605}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00090() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.StringBuffer,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-1000,398,-956,-107,650,-487,171,233,308,1000,-1000,1000,-247,987,-77,947,391,-1000,216,-1000,1000,1000,862,-1000,1000,-757,342,130,1000,1000,-1000,549,-1000,764,1000,1000,-375,1000,-1000,281,1000,407,-797,10,-207,1000,-473,659,-1000,521,13,320,-1000,1000,-499,-160,-1000,-699,566,1000,-309,-1000,617}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00091() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.StringBuffer,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-618,251,-64,-866,1000,592,423,1000,450,705,14,-128,-1000,-573,-400,-841,367,-536,-728,-1000,1000,-1000,-1000,-320,400,1000,-1000,-1000,-391,608,1000,400,-344,-567,1000,512,1000,570,-367,1000,1000,332,1000,-1000,370,1000,-941,1000,965,400,226,942,-1000,1000,603,-1000,96,1000,1000,-1000,597,828,-474,-50}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00092() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.StringBuffer,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-829,-316,239,-101,-750,448,-1000,1000,533,-43,-1000,647,446,416,584,-869,-368,-822,-740,-350,-400,678,64,238,1000,507,1000,529,-1000,-476,238,34,-794,-1000,-8,1000,-558,1000,-356,243,-434,-322,-329,658,797,-628,473,927,-40,630,1000,1000,149,-71,-404,1000,-1000,-201,998,-1000,439,693,926,325}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00093() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(java.lang.StringBuffer,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-597,839,-521,817,-1000,-428,-992,1000,-27,-145,-800,656,525,619,-704,-233,-139,-337,175,-164,1000,824,-630,-490,-352,-540,481,112,-130,-516,-1000,1000,-839,-381,54,772,-1000,386,-916,57,-1000,-871,-110,590,-68,-1000,-308,1000,310,-177,939,638,-511,918,-1000,999,400,853,634,634,-660,193,593,-763}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00094() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(long):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-1000,-874,-641,-1000,-1000,663,779,201,-726,-908,-1000,-223,830,442,-824,-1000,1000,204,-401,-256,-123,-144,-440,-1000,-1000,-1000,-1000,1000,204,1000,-1000,1000,-1000,135,-920,42,-754,203,1000,-351,658,-1000,-1000,-298,277,1000,1000,50,717,1000,-1000,-1000,-400,909,450,-1000,653,1000,-1000,-855,-971,-45,-888}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00095() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(long):org.apache.commons.lang.text.StrBuilder",
            new int[]{26,-543,-11,-669,439,819,97,252,-554,-565,727,720,-365,-1000,-138,223,144,-515,-475,-437,-859,1000,366,-892,372,221,173,109,-540,-428,-1000,603,-777,469,-283,-709,195,611,815,844,400,1000,760,1000,-6,503,-1000,-498,1000,822,-859,984,830,-362,-972,-105,749,846,-114,404,-183,-282,-86,52}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00096() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(long):org.apache.commons.lang.text.StrBuilder",
            new int[]{40,140,113,635,321,453,-41,828,-1000,-183,83,319,-256,-1000,86,934,753,854,356,-909,-70,840,926,-1000,-1000,601,-178,-552,-692,-595,-336,-249,-1000,-734,-1000,-961,-345,1000,-32,984,342,615,640,384,-346,-660,-98,111,566,-99,245,376,1000,-260,-523,-483,1000,-301,285,1000,-430,-263,-113,957}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00097() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(long):org.apache.commons.lang.text.StrBuilder",
            new int[]{-24,-476,1000,-584,224,-416,724,396,-1000,-982,-216,-201,900,-320,829,692,148,1000,-178,457,-733,674,1000,-362,1000,298,518,-141,-413,-1000,-97,172,-1000,-516,-125,-896,-1000,1000,414,235,843,-638,-307,422,234,679,745,-240,296,-55,505,-77,1000,938,-716,885,1000,-125,246,299,540,-215,-241,-274}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00098() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(long):org.apache.commons.lang.text.StrBuilder",
            new int[]{-276,890,-956,-738,-157,529,201,1000,-456,318,237,1000,-84,-1000,-138,410,-66,-1000,206,-1000,1000,-61,124,-1000,-118,1000,153,914,-1000,5,-26,480,104,1000,-326,-462,969,210,-1000,-1000,-598,770,1000,1000,-813,-891,-930,-498,-684,-1000,680,576,58,-332,660,-1000,607,480,-1000,965,-46,1000,-121,-716}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00099() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(long):org.apache.commons.lang.text.StrBuilder",
            new int[]{900,-1000,-800,-193,-1000,44,-40,167,7,709,889,-425,-883,-132,99,-396,-275,43,348,-922,-616,1000,-798,-1000,-443,-1000,-858,-29,638,455,-57,-497,186,-716,117,-1000,1000,-44,962,1000,-208,1000,-142,400,-1000,-77,-805,-977,1000,1000,531,475,-107,-1000,-437,-435,207,919,651,-1000,-974,-863,190,-417}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00100() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(org.apache.commons.lang.text.StrBuilder):org.apache.commons.lang.text.StrBuilder",
            new int[]{59,558,14,202,1000,-409,809,608,1000,247,766,-477,526,397,-296,-810,-577,-335,665,-724,322,-56,-240,551,1000,-18,-850,-638,-617,-430,-335,-59,1000,19,1000,1000,850,316,523,-663,-890,-43,-911,589,-412,917,-113,575,-511,-432,155,-20,-1000,-649,-617,-131,1000,1000,-167,443,-767,-247,581,-311}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00101() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(org.apache.commons.lang.text.StrBuilder):org.apache.commons.lang.text.StrBuilder",
            new int[]{-410,-689,766,489,818,383,-347,-652,468,-564,65,-358,-547,341,-26,-985,488,-528,492,-291,-434,356,258,300,475,91,764,731,798,-563,863,159,-341,-357,-702,352,-619,800,-259,136,-825,792,-399,659,-999,749,-360,-823,-195,349,301,455,499,233,578,-94,249,-613,232,-850,896,401,240,797}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00102() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(org.apache.commons.lang.text.StrBuilder):org.apache.commons.lang.text.StrBuilder",
            new int[]{-330,-70,-276,-818,-340,1000,-341,-969,7,-191,226,-364,-76,-1000,785,-242,-60,-969,-335,838,554,466,-9,-1000,-512,-25,1000,532,-385,1000,-364,536,-847,-75,-1000,-359,-837,-265,998,-15,-453,-634,-918,77,-978,-357,-1000,-493,-205,25,-1000,1000,-400,1000,-1000,-307,-1000,-780,-1000,702,-661,-914,-946,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00103() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(org.apache.commons.lang.text.StrBuilder):org.apache.commons.lang.text.StrBuilder",
            new int[]{160,899,-760,417,1000,47,119,197,143,-87,62,-374,643,-58,332,-534,212,-181,-316,555,64,-33,-40,210,627,825,-497,-805,-234,171,-642,-542,591,-208,-114,219,842,-29,828,-594,-1000,-817,-1000,-40,-16,745,-270,-163,-505,341,445,523,-347,-373,-57,-209,721,1000,26,-38,-516,447,-335,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00104() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(org.apache.commons.lang.text.StrBuilder):org.apache.commons.lang.text.StrBuilder",
            new int[]{294,920,1000,-156,-1000,1000,399,247,439,-1000,-521,-1,-45,-58,1000,577,-1000,333,-981,-806,-123,-1000,-400,725,-1000,312,-421,1000,-241,-554,893,-913,-225,-43,-170,1000,-736,-735,548,416,-52,539,367,1000,-1000,57,-356,-149,-539,-437,39,-160,83,-312,-460,-1000,-650,699,-1000,-769,-1000,616,80,-314}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00105() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(org.apache.commons.lang.text.StrBuilder):org.apache.commons.lang.text.StrBuilder",
            new int[]{-478,-1000,-454,-566,167,-441,-4,163,7,-529,766,-477,939,922,-886,-866,171,-418,911,-724,-814,44,-580,307,1000,-405,520,-727,-139,-290,-335,-59,389,1000,23,1000,-1000,-545,523,591,1000,677,-749,139,-1000,798,245,1000,-874,-1000,-1000,-1000,1000,437,-1000,-131,-755,1000,-778,-1000,-1000,1000,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00106() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(org.apache.commons.lang.text.StrBuilder):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,1000,23,62,-87,730,61,-140,-1000,127,-861,1000,51,-690,-676,1000,-372,-1000,-1000,384,915,-1000,180,-336,-1000,942,-1000,146,-1000,426,-817,-651,-531,1000,-80,-1000,-295,79,-873,-302,-326,-85,-257,421,-288,767,-158,-679,608,603,-873,-1000,1000,1000,1000,62,-400,-550,340,-1000,837,1000,-612,24}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00107() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(org.apache.commons.lang.text.StrBuilder,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-380,240,793,1000,47,-1000,821,-933,1000,-493,329,-1000,-285,656,-669,542,60,-19,148,540,-776,-1000,725,-670,-367,228,-1000,-498,652,1000,-93,747,815,785,-218,1000,-1000,486,-440,-289,-151,953,-1000,-780,348,796,-58,-1000,300,308,1000,-372,14,-987,130,557,907,154,237,-1000,1000,725,-54,-302}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00108() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(org.apache.commons.lang.text.StrBuilder,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,641,1000,1000,1000,-1000,134,-985,994,739,829,-1000,-594,-13,-1000,1000,-378,1000,-125,664,-1000,-1000,597,-406,-361,-319,-1000,-152,938,1000,-709,1000,1000,1000,-792,1000,-1000,953,-1000,1000,-1000,612,-1000,-1000,1000,717,-973,-995,-156,1000,1000,-1000,717,-1000,165,1000,1000,896,-1000,-1000,1000,1000,-851,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00109() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(org.apache.commons.lang.text.StrBuilder,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-270,-1000,-1000,805,900,1000,74,536,-741,-606,502,499,544,-270,-400,1000,143,400,-373,-704,-1000,-400,-159,984,932,162,582,-1000,848,-856,265,-624,-577,824,-440,543,-400,-716,258,-261,1000,-511,128,337,361,812,-400,1000,506,35,1000,-801,1000,364,-117,604,25,901,-1000,-719,1000,-324,-883,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00110() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(org.apache.commons.lang.text.StrBuilder,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,707,1000,740,1000,1000,623,926,-1000,386,1000,-1000,289,-835,-975,-126,-1000,1000,961,662,741,-659,1000,403,884,-1000,-1000,0,-321,1000,-534,-479,876,-513,-1000,-410,-1000,443,-982,1000,386,260,25,1000,-453,-121,-990,-767,-990,688,255,-599,468,-1000,-711,-121,-164,177,-1000,-1000,1000,892,-1000,-624}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00111() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(org.apache.commons.lang.text.StrBuilder,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,191,-760,-61,-10,1000,-1000,422,591,14,592,-785,237,-716,-274,-711,1000,869,-1000,-1000,75,-383,-975,854,1000,-1000,149,638,-959,-85,-184,-1000,-376,611,-1000,-459,-1000,399,-327,-342,30,-552,652,672,0,-496,-559,380,153,-294,437,-1000,810,-22,-650,-481,-159,376,1000,905,395,-1000,1000,-85}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00112() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(org.apache.commons.lang.text.StrBuilder,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-545,443,287,1000,772,-1000,554,-709,1000,293,29,-785,-778,1000,-575,1000,-964,-104,-788,293,-780,-383,-66,-1000,-917,-1000,-632,-500,1000,1000,-786,1000,1000,1000,630,935,-1000,695,-1000,470,-520,1000,-1000,-565,666,377,-952,-1000,349,819,765,-716,-90,1,674,891,1000,1000,-501,-1000,173,889,-1000,-213}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00113() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(org.apache.commons.lang.text.StrBuilder,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,551,-404,445,496,10,-541,-308,1000,846,-38,-1000,-150,1000,-1000,343,-337,1000,-475,149,-907,-1000,1000,626,-665,-803,-1000,208,467,427,-1000,299,1000,1000,-1000,535,-1000,496,-817,470,-571,236,-1000,-565,521,377,-952,-1000,664,1000,1000,-1000,296,-1000,-368,648,681,1000,-128,240,1000,-574,-1000,-519}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00114() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "append(org.apache.commons.lang.text.StrBuilder,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-127,-485,279,-460,134,759,-162,865,-911,-609,-50,862,-1000,-1000,-624,-839,-319,541,412,-875,-1000,285,7,66,1000,-996,-769,1000,19,64,398,-523,-513,549,1000,368,-1000,780,57,1000,422,57,-245,33,726,-31,-869,1000,238,908,-1000,1000,-996,-325,650,-315,180,-1000,981,1000,-208,-491,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00115() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadLeft(int,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{686,-160,580,-333,-1000,-76,-266,-1000,802,-344,266,949,913,20,753,48,-406,-399,-869,512,-798,-104,525,395,498,575,985,519,-691,-990,-127,-245,-302,640,65,334,1000,664,-564,-1000,830,-365,632,-494,-1000,-414,-990,-218,1000,-353,400,511,354,-145,-88,44,-94,1000,-1000,-1000,553,175,-393,-627}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00116() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadLeft(int,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-27,-276,-666,877,-943,-132,569,-869,-749,-92,1000,607,-1000,-957,-604,-657,-843,1000,-1000,317,522,-49,-1000,-307,-472,-1000,1000,-913,-726,181,650,-230,-889,-1000,337,698,-610,460,1000,183,1000,-1000,425,1000,611,517,-1000,1000,225,1000,1000,1000,-309,-611,-573,890,613,1000,1000,-1000,189,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00117() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadLeft(int,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-161,224,769,255,-894,-231,-614,-1000,75,-150,1000,956,108,-512,1000,-423,-376,154,128,-109,-493,422,-395,101,204,620,227,590,-1000,-1000,866,-668,-1000,111,180,247,833,-95,62,594,-873,-267,-536,186,192,259,404,-1000,1000,-223,1000,913,963,-1000,-137,-1000,-1000,770,283,-52,454,-103,385,-380}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00118() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadLeft(int,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{248,124,187,451,549,112,-499,-342,-135,-776,-842,252,227,184,-35,862,-965,185,538,705,549,245,-386,-873,-201,562,682,-712,-116,-769,-8,-597,-22,-849,-979,303,-397,-384,-656,660,700,-869,-493,-831,887,334,1,235,879,533,-296,240,560,364,-726,-641,-618,318,-107,-923,-99,496,-520,23}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00119() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadLeft(int,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,17,987,364,-751,-137,439,-148,788,-99,-846,238,292,958,-431,-412,-1000,-400,-178,1000,1000,-791,-62,247,797,-70,691,-962,-119,887,-1000,-212,-65,-112,-999,-75,-870,-106,554,-822,-405,-1000,563,648,699,118,-550,-506,-299,46,-1000,725,-188,-610,-132,85,508,-257,-214,1000,978,1000,79,-719}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00120() {
        org.junit.Assert.assertEquals("THROW:java.lang.ArrayIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadLeft(int,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{508,17,5,191,-248,935,-98,-148,177,-509,-288,161,-335,-73,275,823,-1000,292,-189,769,110,239,-321,247,37,130,988,-605,1000,390,-592,-146,363,-277,-999,786,-1000,160,220,-822,-405,-965,-96,611,-31,-1000,451,-239,-605,-352,-1000,212,437,-1000,460,-267,508,239,338,293,231,277,-1000,-612}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00121() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadLeft(int,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{105,-1000,215,472,27,112,-422,-242,-113,-726,-871,413,257,46,-5,599,-960,-87,461,573,670,287,-325,-599,-119,562,-462,-400,-572,-407,74,-597,44,-705,-1000,484,-1000,-335,-192,641,746,-902,-168,-18,1000,121,-835,-169,569,229,-381,499,608,67,-558,-224,-463,307,647,-660,-53,434,802,-467}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00122() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadLeft(int,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{686,-1000,912,358,-1000,-1000,-457,-839,463,-733,30,949,454,796,502,-456,-513,-457,421,734,1000,562,552,-772,498,100,-1000,164,-691,-1000,15,-1000,21,-326,-1000,-59,400,253,-1000,1000,830,-926,371,-494,1000,1000,-1000,-404,1000,671,400,892,557,-145,-1000,-600,-1000,789,-106,-1000,486,940,-393,-233}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00123() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadLeft(java.lang.Object,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-37,1000,-775,-1000,149,-396,157,-584,400,16,403,-1000,-1000,-248,260,-998,227,-214,-1000,-1000,1000,591,-673,-832,-1000,988,922,454,1000,400,-817,238,-986,843,-1000,-1000,-577,272,-1000,380,1000,1000,194,-530,1000,563,369,1000,-1000,-603,1000,-549,572,1000,-1000,66,-1000,1000,-1000,1000,764,134,854}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00124() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadLeft(java.lang.Object,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-726,-669,-442,-390,759,-452,1000,113,480,1000,303,-848,-155,-618,748,-1000,-142,507,991,775,-265,892,687,-630,-817,-71,1000,123,-51,-236,797,-20,1000,70,-486,921,-502,48,-712,601,129,-617,-1000,866,-616,-42,-352,1000,-953,-303,-554,161,-1000,-48,-916,504,1000,-130,452,1000,-52,-92,-81,-303}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00125() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadLeft(java.lang.Object,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-357,-199,265,-408,144,387,899,218,853,-305,929,-1000,-533,-309,-357,561,-349,-437,38,-654,251,-907,-406,119,2,1000,-84,-50,1000,571,75,-27,-1000,-70,-699,-1000,-135,-100,-990,975,812,654,1000,-874,177,1000,1000,446,-345,-297,303,1000,-502,1000,-146,-1000,469,95,291,-1000,-1000,-136,1000,-512}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00126() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadLeft(java.lang.Object,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-153,-556,-344,-315,-19,324,614,-363,612,600,1000,-178,-1000,-841,-761,525,-285,277,1000,-728,-348,-4,-562,-975,-20,162,236,93,648,-636,387,685,-1000,-362,-389,-930,-952,-1000,-777,-272,342,567,1000,-1000,-189,286,-177,868,-61,-1000,1000,759,3,-142,467,-203,-91,-570,1000,-90,744,-279,587,140}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00127() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadLeft(java.lang.Object,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-97,-809,-750,630,93,329,480,88,776,-796,984,-770,-950,-841,7,525,-381,137,741,-506,157,-225,-875,807,-511,544,-16,-26,693,-306,387,693,-720,-529,-507,-868,-144,-665,-380,185,842,-304,769,-888,171,87,446,868,-783,-382,234,904,-349,60,291,-762,384,-21,732,229,-656,-44,632,-408}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00128() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadLeft(java.lang.Object,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{505,-301,529,1000,688,894,-568,390,463,-1000,-146,-330,271,570,-706,-1000,21,-981,1000,-183,1000,-1000,1000,489,-284,1000,523,-1000,1000,-867,-1000,1000,602,-1000,-175,71,414,-715,347,282,1000,-240,-441,-1000,-79,-206,414,-1000,-304,199,378,1000,-99,644,1000,-1000,-1000,-1000,720,287,-436,947,-880,956}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00129() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadLeft(java.lang.Object,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-742,497,352,832,352,432,447,430,874,-723,413,-658,-411,-617,-886,169,14,-150,1000,4,550,-613,-674,475,-836,-114,-558,-801,925,-4,-52,480,-1000,48,-862,360,-840,129,-587,549,1000,-228,838,-398,32,686,267,1000,-253,-358,-281,1000,-209,120,1000,-257,86,636,800,1000,-1000,-240,197,-534}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00130() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadRight(int,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-956,-1000,261,-493,-61,1000,-531,699,1000,160,549,-954,1000,-307,-981,129,208,829,-158,256,-306,-372,-379,1000,-506,219,-230,1000,-1000,-185,1000,558,549,-1000,242,-797,-198,-441,1000,-664,-593,786,-1000,410,1000,-888,-130,241,-517,-54,-35,1000,-872,562,623,-983,1000,483,-14,1000,-93,1000,-472,320}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00131() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadRight(int,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-443,-645,-516,587,969,1000,459,232,1000,1,-915,-849,331,-142,549,-633,392,-386,-388,-1000,1000,468,241,421,-655,-142,-814,942,850,-348,-1000,-793,670,-799,-368,-912,784,456,524,1000,-849,998,-524,-927,71,-314,13,-65,226,585,-926,-872,-924,-256,-240,-246,1000,-22,681,-7,-765,358,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00132() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadRight(int,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{925,-142,209,809,-61,-461,-347,635,167,139,-1000,852,-673,-1000,191,-323,-369,-216,-58,-372,-1000,149,694,-1000,-527,-70,-1000,106,800,56,-236,391,81,-1000,-329,-233,-452,-240,-1000,380,122,849,-77,-717,-520,-117,-346,582,921,1000,-329,-865,-304,-216,-1000,-59,-400,-462,880,428,-207,-96,-262,-400}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00133() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadRight(int,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{78,862,-1000,1000,919,-518,-233,173,382,833,-709,-401,225,-922,-1000,-374,-259,1000,-355,-240,604,131,-1000,-1000,256,506,-508,-474,-850,370,185,987,-1000,-1000,-509,1000,-369,266,366,-443,1000,-1000,-1000,-399,-1000,52,845,998,489,-147,849,-988,202,988,-147,477,912,-349,903,335,-88,1000,-112,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00134() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadRight(int,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{710,-144,-271,862,1000,-518,283,902,-65,-174,-985,116,-732,102,708,29,164,-479,-231,63,604,492,11,-1000,-162,-259,-1000,-474,498,611,-130,831,467,-550,-938,-1000,-369,-104,-863,585,-264,773,598,-157,-677,-504,-868,1000,489,-147,-573,-838,-743,-445,-814,346,-424,-663,800,-1000,-957,-953,-467,571}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00135() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadRight(int,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{635,-1000,1000,-490,1000,-982,-451,837,204,-739,-93,893,472,-719,535,1000,717,-778,593,589,-49,-1000,158,-38,45,-160,-1000,-1000,443,565,-1000,1000,-73,-83,641,-121,-261,-478,-186,-20,-52,-903,-477,1000,269,-1000,884,481,-475,-783,-520,218,-974,552,735,-132,751,-1000,1000,-10,-1000,37,309,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00136() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadRight(int,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{773,-1000,992,-407,1000,-797,312,783,83,-1000,-505,1000,-251,-381,1000,1000,1000,-1000,-261,1000,642,939,481,-324,446,-884,-1000,-1000,1000,478,-1000,1000,897,233,-331,-1000,-746,-235,-1000,884,754,252,631,740,495,-785,-339,568,569,-1000,-1000,-536,-1000,-318,284,-221,1000,-1000,1000,-766,-1000,-1000,-437,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00137() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadRight(int,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-1000,-566,587,1000,351,14,464,1000,-345,-464,956,996,-142,282,1000,1000,-98,-3,80,-6,-836,314,297,172,-643,-643,-1000,850,-348,-1000,-793,1000,183,541,-1000,525,456,439,1000,-841,-674,-419,-518,1000,-314,548,1000,428,557,-1000,856,-1000,-791,775,614,1000,-1000,601,-1000,-852,1000,-407,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00138() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadRight(java.lang.Object,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-1000,181,-212,1000,58,-566,-805,-455,267,241,-422,-251,-1000,-453,-1000,1000,-993,932,346,195,-237,389,295,-1000,908,0,39,-1000,-1000,-464,-755,-464,224,99,397,-47,1000,-229,-459,439,-78,435,-52,-139,-1000,-45,51,-1000,1000,-149,58,-463,685,676,70,-59,-1000,102,-674,1000,-513,534,621}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00139() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadRight(java.lang.Object,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,201,359,-859,919,-1000,-564,-273,892,-726,-508,230,-621,-1000,-58,193,395,-287,564,-1,436,-883,-118,-47,184,335,345,653,-1000,378,126,-915,-165,887,-313,694,-364,378,299,-1000,974,-524,710,-1000,-636,-1000,1000,1000,-173,1000,-224,-696,-276,1000,-340,-1000,864,846,1000,-523,1000,212,645,512}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00140() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadRight(java.lang.Object,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-1000,181,525,-68,621,-771,-578,-550,1000,-44,1000,229,-919,-851,-1000,1000,-1000,518,478,590,-89,389,-55,-1000,979,-614,-325,-392,-1000,-573,-462,-225,197,211,170,525,378,-137,55,483,902,-851,773,11,112,170,-279,-714,1000,-149,182,-463,661,995,497,122,-1000,-774,-605,1000,155,-412,453}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00141() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadRight(java.lang.Object,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,55,1000,628,-316,-536,384,1000,147,-299,-700,1000,726,-170,-1000,-677,-814,-343,907,-1000,925,30,-1000,-115,665,-534,-141,-280,-1000,28,827,-241,1000,-921,-951,-898,-352,-1000,96,-1000,876,-1000,1000,-631,100,-1000,-1000,334,874,307,-1000,-874,1000,441,257,-1000,-314,1000,1000,320,-1000,-509,1000,282}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00142() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadRight(java.lang.Object,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-1000,-1000,611,-360,1000,-77,-389,-1000,1000,378,381,-20,-377,187,189,817,-1000,155,-1000,-687,783,851,284,-1000,435,-253,257,535,-1000,736,92,-427,366,247,330,595,638,145,994,-909,1000,-1000,1000,798,172,100,-317,686,835,-8,952,-1000,-917,575,1000,-522,-1000,-944,30,1000,-510,-932,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00143() {
        org.junit.Assert.assertEquals("THROW:java.lang.ArrayIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadRight(java.lang.Object,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-979,-1000,147,387,1000,-767,-179,-806,714,472,-518,-403,-599,109,-565,871,-1000,575,1000,277,302,723,295,-1000,545,0,575,104,-1000,-1000,-202,-785,401,354,397,52,1000,497,330,274,262,-338,923,462,-1000,-45,-1000,-1000,1000,-1000,397,-773,-306,-274,1000,31,-1000,-542,-396,1000,-277,-789,621}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00144() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadRight(java.lang.Object,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{405,-1000,177,-38,680,-543,1000,282,-314,-119,563,633,-359,-547,759,-590,-86,519,862,358,-129,-186,-734,-455,-637,256,189,53,-423,-147,-803,205,460,147,47,-325,-438,146,190,-359,551,-1000,324,-17,-445,-893,557,99,-699,840,561,-310,400,63,28,122,515,-245,90,-501,-535,121,566,798}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00145() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendFixedWidthPadRight(java.lang.Object,int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-597,-163,-544,838,644,-1000,292,413,424,694,1000,47,-768,-874,253,-1000,-432,167,1000,1000,384,-421,610,1000,-1000,496,340,1000,217,38,-446,369,-714,458,-343,-345,-325,-219,-669,-1000,283,-1000,-386,-658,53,-1000,-484,-292,-832,1000,748,-59,254,-804,-383,-566,604,-972,288,-522,633,-25,-46,86}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00146() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendNewLine():org.apache.commons.lang.text.StrBuilder",
            new int[]{535,357,-731,802,690,790,981,288,-629,-279,350,-26,120,962,783,453,768,-904,421,-607,-408,-784,624,482,504,-87,-633,80,-808,-173,-264,938,-248,800,-263,590,143,979,-410,935,560,-866,808,860,-311,831,-535,-224,-260,173,293,467,140,-671,486,711,-207,223,453,849,967,461,-880,639}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00147() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendNewLine():org.apache.commons.lang.text.StrBuilder",
            new int[]{-673,398,71,253,770,313,-539,-408,662,-324,-434,282,-542,973,543,-811,-118,-61,-1000,-48,-586,-767,-104,-634,309,-1000,-1000,-369,-227,-421,56,663,190,681,6,-115,-200,-20,461,-336,-21,-1000,116,-273,36,464,20,112,-582,15,-515,-272,-202,-178,-703,-281,155,290,406,-66,-20,187,-916,85}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00148() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendNewLine():org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,220,137,592,489,501,-682,-1000,1000,-161,-474,835,-336,895,694,-1000,-935,134,-569,-438,-1000,-409,-132,-967,723,-44,899,-178,-235,-35,-110,763,853,821,1000,-1000,-1000,-1000,729,-1000,796,-945,-617,-174,42,654,1000,755,-1000,749,-908,-522,-1000,1000,-746,-790,1000,845,153,-48,153,-1000,-742,-683}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00149() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendNewLine():org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-238,-415,679,-214,-527,-1000,2,333,282,-1000,-18,-1000,-1000,-982,-70,1000,-873,-777,-326,-25,-1000,-682,-139,4,1000,334,-668,1000,-897,-737,794,-693,-1000,-1000,1000,-310,-1000,1000,-262,-1000,-357,752,-242,914,1000,1000,-1000,127,905,274,-125,-928,-1000,808,-363,1000,-491,1000,-1000,-619,-324,60,2}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00150() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendNewLine():org.apache.commons.lang.text.StrBuilder",
            new int[]{513,242,608,277,1000,-638,-556,-496,874,261,-389,983,379,1000,1000,963,-651,-1000,-855,-406,1000,-563,-592,-685,326,1000,-206,-491,-480,1000,-1000,-692,-826,550,-786,-1000,216,454,-201,-207,1000,1000,-319,-56,-1000,793,-1000,78,-657,-961,-1000,-94,-432,683,-605,974,-184,738,1000,222,727,552,469,-355}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00151() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendNewLine():org.apache.commons.lang.text.StrBuilder",
            new int[]{892,231,388,802,-1000,565,162,288,-726,134,1000,-561,-1000,-1000,-1000,-347,820,-229,621,510,-557,-1000,713,845,335,1000,-633,-318,666,-883,139,1000,-145,113,-1000,1000,483,85,-434,930,-1000,1000,1000,791,390,831,-1000,-1000,1000,-498,1000,443,211,-305,777,460,-1000,-1000,453,-545,408,673,-347,968}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00152() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendNewLine():org.apache.commons.lang.text.StrBuilder",
            new int[]{-395,-1000,-997,941,136,663,994,-1000,624,-289,1000,939,-1000,-140,17,151,238,690,-1000,-19,-1000,-1000,1000,-395,1000,-513,1000,-523,-348,993,-828,1000,1000,467,-1000,339,-1000,-478,146,-951,-852,71,-831,619,716,675,1000,767,-812,1000,425,114,532,-933,-17,699,1000,-177,1000,-450,-1000,-949,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00153() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendNull():org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-1000,503,-290,1000,49,-448,321,720,138,234,-1000,915,977,1000,155,-759,-1000,1000,1000,32,49,1000,-782,926,-186,620,1000,475,765,1000,1000,-1000,-687,-483,-909,1000,846,-1000,90,-385,-437,455,433,-378,-1000,-504,1000,66,1000,753,-1000,-409,-494,54,970,-1000,592,-1000,98,422,-315,-967,538}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00154() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendNull():org.apache.commons.lang.text.StrBuilder",
            new int[]{-89,15,-311,47,-858,643,-776,-453,1000,433,-1000,-258,774,489,1000,66,-1000,1000,430,645,669,410,116,-700,-124,-1000,1000,909,-646,-175,828,1000,293,-1000,1000,-200,378,-544,-630,-187,932,-1000,-664,-728,-659,-497,-255,-151,1000,49,-501,1000,411,-36,-202,-117,1000,-1000,-1000,-938,738,1000,-388,-486}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00155() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendNull():org.apache.commons.lang.text.StrBuilder",
            new int[]{968,-1000,374,-435,1000,492,404,121,-202,546,670,162,-758,3,240,106,38,-1000,608,135,-554,13,1000,844,688,798,395,465,1000,1000,-42,-1000,-961,-587,408,-309,35,1000,-478,1000,-881,866,817,634,275,-1000,-282,634,170,59,1000,-1000,-128,288,-502,11,-888,1000,-280,1000,-17,-897,1000,640}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00156() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendNull():org.apache.commons.lang.text.StrBuilder",
            new int[]{956,-700,525,116,540,-850,-327,94,-128,201,-958,1000,-61,-38,1000,200,455,-866,1000,1000,237,892,1000,521,21,1000,665,601,794,-756,735,-34,-1000,-862,835,117,137,1000,-1000,1000,660,-1000,867,799,974,-1000,-1000,184,374,1000,-704,-1000,-590,66,-1000,347,-984,-620,-1000,-213,-385,-1000,878,261}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00157() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendNull():org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-116,841,0,577,-906,-463,-322,198,80,-125,-967,1000,-343,458,-220,-1000,471,1000,254,-972,-1000,-1000,-1000,900,-1000,455,713,-352,1000,990,1000,741,20,-9,191,1000,-528,-793,-652,528,217,-1000,-766,-51,-672,-61,815,602,950,32,649,-114,-822,1000,-161,235,421,10,-681,99,574,-1000,231}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00158() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendNull():org.apache.commons.lang.text.StrBuilder",
            new int[]{758,-352,288,-282,41,-951,994,-172,465,230,501,21,678,-598,856,-211,-312,-840,420,790,492,697,452,704,-591,462,-298,319,312,867,-193,292,197,-4,-120,959,931,252,341,40,-575,330,-309,-892,962,-990,-234,299,-18,868,784,-118,-801,-808,-584,-951,-362,166,-939,548,887,661,-474,643}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00159() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendPadding(int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{252,-889,-613,550,-100,252,-481,-339,-383,706,591,-1000,-613,375,-481,271,-696,925,-668,368,-954,-33,-437,-777,1000,-1000,246,591,73,-957,282,-384,1000,1000,-1000,-1000,772,-582,420,883,191,1000,391,-958,35,-705,-781,-247,1000,726,354,-538,-1000,-851,-86,868,266,-6,-494,-955,388,-863,1000,-514}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00160() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendPadding(int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-405,-671,-398,218,311,-675,232,-502,-632,844,-821,-304,849,193,-335,-886,602,45,747,-654,141,1000,-160,1000,-311,-633,276,399,1000,-648,-391,718,-94,-17,-745,131,-20,772,-322,229,953,-685,-207,897,-501,-331,-930,1000,588,184,1000,-1000,68,202,747,-533,53,-571,-217,509,-213,1000,-300}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00161() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendPadding(int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-651,192,414,563,-723,-568,413,-751,426,474,-950,321,-32,-785,-460,269,747,-766,-72,46,-106,458,554,1000,243,308,328,69,50,-1000,887,136,-189,822,-564,693,-763,-107,684,32,-1000,522,817,-242,-1000,846,936,622,-69,597,-520,-562,-164,544,356,-215,95,78,-194,328,-264,417,-213,214}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00162() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendPadding(int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-708,484,-490,-771,607,1000,-646,449,-1000,-100,777,214,96,1000,-335,1000,-1000,1000,-1000,-725,-360,1,-865,-585,272,-718,-485,282,-707,-665,-1000,227,844,117,188,-1000,-19,173,-455,18,480,762,-813,-968,862,-666,-906,-183,868,923,-716,-348,-553,-260,-133,184,-613,529,-34,271,-854,779,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00163() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendPadding(int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-943,-1000,-1000,667,1000,1000,-541,501,-717,940,183,-618,-963,-732,87,917,-217,-237,44,1000,-488,457,-335,-446,583,-1000,818,-134,-192,-1000,1000,-623,-185,1000,-980,-466,559,-1000,1000,1000,117,833,391,378,374,-470,-760,-173,128,225,505,-700,-662,-118,-239,391,1000,-80,-172,-170,750,322,610,290}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00164() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendPadding(int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{484,-196,1000,918,-1000,-449,-6,-504,-43,336,47,-146,704,-225,-254,110,-451,-187,42,-271,15,25,658,-23,1000,-511,212,-388,-221,-970,497,-833,141,1000,-1000,58,-700,-707,594,-101,-948,1000,418,-759,-1000,605,746,96,806,1000,-1000,-881,-775,416,1000,126,486,241,267,-1000,747,170,878,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00165() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendPadding(int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-1000,481,-261,-670,393,-170,-239,-155,1000,-363,894,386,-1000,-437,757,115,534,-920,-2,-286,692,-475,598,899,-1000,1000,524,-725,-1000,1000,-724,-569,870,-1000,-380,62,-894,1000,1000,-409,1000,1000,-552,-912,549,47,341,74,633,-173,-1000,-487,732,676,251,1000,-650,304,-1000,348,-108,613,-555}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00166() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendPadding(int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-147,-1000,-640,1000,-409,593,-54,239,-173,-8,-14,-178,254,-222,180,476,-456,194,-129,46,-414,390,738,571,524,-814,-412,329,-792,-1000,682,-710,-237,1000,-1000,-552,-212,-624,820,-20,-809,785,600,94,-965,-44,55,-97,872,712,-367,-487,-612,-35,693,396,610,62,-186,8,-65,-561,936,-346}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00167() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendWithSeparators(java.lang.Object[],java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-376,333,293,-788,-549,1000,-293,1000,841,64,139,281,1000,-340,953,-118,-1000,-121,253,950,-686,-87,-534,378,-281,1000,1000,-187,-373,715,-382,-166,-242,1000,702,122,212,-22,-1000,-23,-728,-1000,439,740,682,737,-426,18,-860,-855,910,-915,1000,144,1000,1000,-214,567,-237,1000,465,-1000,829,287}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00168() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendWithSeparators(java.lang.Object[],java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{922,-925,791,-706,200,909,-709,-109,-872,-457,850,-644,78,-385,359,-522,-645,317,468,-381,-176,-522,142,491,-17,740,141,703,-701,710,276,-614,902,211,206,-564,-201,-627,-708,380,-367,171,-470,-323,-246,270,968,402,836,526,-829,-324,-388,-649,-745,-42,-554,298,848,367,-610,675,878,-420}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00169() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendWithSeparators(java.lang.Object[],java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{947,781,522,-618,-29,-310,-669,641,820,47,295,264,736,-408,-172,-559,-321,-233,529,-675,-8,15,-512,460,-626,900,963,90,-76,299,-536,360,265,454,767,-314,-59,-2,-1000,-342,-309,-458,324,837,81,662,-642,-76,-123,-614,753,-1000,901,491,1000,610,-122,275,-471,1000,35,-175,566,-68}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00170() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendWithSeparators(java.lang.Object[],java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-864,920,-1000,-531,-1000,974,-451,872,1000,474,-1000,392,1000,-564,-770,-1000,8,-121,-742,379,-686,1000,-1000,-400,-45,301,-522,-895,436,113,-568,-166,-1000,915,-398,126,115,533,-893,-619,-737,-1000,591,1000,1000,-264,-1000,28,-1000,-1000,1000,-419,-191,1000,1000,641,161,-802,-809,715,1000,-1000,-246,-688}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00171() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendWithSeparators(java.lang.Object[],java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-313,-427,1000,-587,-179,472,134,121,-400,-965,400,-876,-517,-896,14,-564,-140,136,121,-1000,-601,-750,-21,1000,-109,734,258,163,-56,521,-513,-1000,872,111,924,-591,-659,-553,-858,366,-170,-58,-465,-97,337,48,-252,-448,100,98,336,-1000,1000,-1000,-79,1000,-333,1000,871,111,-363,232,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00172() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendWithSeparators(java.lang.Object[],java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-490,486,-931,-779,635,921,-211,-531,-224,-831,-803,-794,-1000,-1000,-241,-1000,-477,1000,-386,-991,-431,216,888,364,-594,276,-685,-409,-59,-1000,957,-1000,888,71,-520,-809,-234,-185,705,-97,1000,1000,-1000,-617,-460,-836,-811,-1000,984,-816,-1000,1000,-373,-1000,-599,764,-719,-900,81,-718,-634,497,-117,-426}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00173() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendWithSeparators(java.lang.Object[],java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-956,-303,-977,-260,389,833,-597,-326,-821,-733,-173,-64,-200,-917,-747,-881,-269,759,-374,-740,-165,723,-82,359,-135,-530,274,122,73,-618,641,-953,20,-333,184,-839,-212,435,530,176,663,800,-596,-302,59,-849,-421,178,984,-784,-761,771,-382,-581,-173,1000,-220,-842,229,-834,-62,97,-236,-168}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00174() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendWithSeparators(java.lang.Object[],java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{116,-1000,176,-737,1000,-926,-693,-310,-1000,-1000,833,-415,-1000,-797,547,224,-616,1000,320,-845,-500,-434,292,1000,1000,775,1000,598,-194,-594,1000,-1000,1000,664,-1000,-933,302,-192,319,1000,922,925,-1000,1000,-690,-631,106,-1000,1000,-1000,-1000,647,-813,-1000,-146,-843,-698,-181,1000,148,948,995,735,94}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00175() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendWithSeparators(java.util.Collection,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-150,-726,-934,-538,-438,563,443,-615,660,-740,7,-623,-1000,-575,-488,-749,1000,494,345,78,1000,-296,-166,-865,781,173,577,-524,846,-253,1000,829,885,1000,162,790,734,-890,1000,1000,668,-1000,-241,-1000,454,645,1000,-1000,250,-403,-390,-129,-1000,-1000,-334,-212,-960,-465,-865,72,-382,888,259}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00176() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendWithSeparators(java.util.Collection,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-187,-1000,11,-756,234,1000,-781,119,-1000,1000,517,-1000,329,-976,-1000,-1000,-1000,1000,-561,-712,377,-532,448,-640,-260,-77,911,794,-740,-214,855,411,657,222,-274,333,1000,-497,-1000,-122,847,637,-217,-854,-1000,688,127,-397,-442,400,-1000,-129,663,193,-395,1000,421,615,361,1000,-487,-1000,1000,128}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00177() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendWithSeparators(java.util.Collection,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-72,382,609,660,-866,961,783,-123,-54,-930,-158,-638,-270,-1000,-376,-615,783,981,-341,185,-501,1000,-687,298,222,-252,-408,629,-485,404,378,1000,-192,-251,742,446,25,-667,767,293,1000,584,-1000,-554,-406,1000,-325,339,-339,-1000,-993,1000,1000,235,-1000,457,-715,-1000,318,656,-21,-17,728,484}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00178() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendWithSeparators(java.util.Collection,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-1000,813,-981,-894,-545,426,-303,728,466,-887,367,-701,-159,-1000,263,-418,1000,258,-637,-930,896,119,-203,-1000,679,662,545,-1000,1000,-740,1000,-880,116,436,358,-973,511,-1000,651,1000,-197,-1000,21,1000,1000,1000,1000,-1000,869,178,-1000,1000,-719,-1000,-579,-886,-430,-342,-51,431,-545,1000,408}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00179() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendWithSeparators(java.util.Collection,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{745,-742,656,465,474,-117,-1000,656,878,-1000,-272,1000,-1000,674,942,-129,-480,5,402,287,-969,-111,-674,154,-1000,1000,-849,-623,838,1000,-1000,-397,-159,1000,-345,-1000,-709,680,381,750,-1000,-73,158,1000,661,-621,-1000,549,111,986,1000,-767,-1000,-1000,-625,-1000,-1000,529,1000,-363,282,840,-756,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00180() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendWithSeparators(java.util.Collection,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-760,-246,-1000,-517,-836,26,946,385,-315,-786,645,-631,123,-122,-763,972,190,-281,1000,-733,202,-1000,129,-556,1000,-461,669,-610,1000,-772,1000,1000,-658,974,207,1000,153,-1000,569,267,-565,-372,197,-209,1000,891,1000,-996,402,18,857,1000,-944,-519,-1000,-1000,-94,-112,312,-562,122,202,482}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00181() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendWithSeparators(java.util.Iterator,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-684,155,-44,1000,814,-771,997,100,743,45,261,513,836,-1000,841,-185,700,-818,-327,-1000,-30,97,420,-397,-877,538,779,-1000,-958,11,-343,92,235,67,-1000,-128,13,-248,-385,-314,-1000,-559,-1000,869,-424,-1000,-36,273,-411,589,-388,388,1000,-65,58,888,1000,-362,202,-563,-252,-1000,885,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00182() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendWithSeparators(java.util.Iterator,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-277,141,-802,129,877,-139,350,447,296,322,1000,591,423,703,-474,342,1000,402,602,3,-596,48,-845,-644,623,361,733,-82,-412,-1000,-712,950,-1000,-986,153,252,1000,-147,440,-629,-506,-560,-1000,276,97,-108,-1,-83,714,440,86,-291,689,-1000,460,806,603,1000,928,711,697,-214,-5,-710}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00183() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendWithSeparators(java.util.Iterator,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{535,757,-969,-558,39,-952,-637,-661,-217,-741,400,408,751,917,-607,180,848,649,619,923,672,307,-806,392,51,119,-5,386,872,-826,-250,-924,-388,-703,65,-146,935,602,-120,-258,-253,-76,-356,275,-822,678,374,-751,86,699,657,669,-93,-855,-323,853,934,623,379,727,428,390,-23,78}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00184() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendWithSeparators(java.util.Iterator,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{744,-349,-281,-987,-620,-42,-424,-176,-654,79,-122,-747,323,175,540,557,-764,-750,289,-471,-381,-981,-319,961,-116,-468,-59,-20,686,-936,-603,-544,-488,503,939,-644,519,734,696,329,-286,374,-82,-405,-370,624,884,708,-226,-34,-381,-259,-622,-31,-828,-982,-807,565,-760,-374,-554,826,-925,-353}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00185() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendWithSeparators(java.util.Iterator,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-353,491,92,1000,1000,-1000,314,-190,889,-420,1000,570,1000,-1000,946,-185,531,-552,156,41,355,11,108,-247,-170,9,28,-836,-862,-822,303,-237,786,-230,-1000,590,138,547,-120,-289,-1000,-265,-1000,1000,369,-1000,403,1000,406,986,-206,388,1000,-971,-251,1000,946,-301,996,-216,1000,-1000,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00186() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "appendWithSeparators(java.util.Iterator,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-499,-1000,128,333,1000,749,401,1000,-248,1000,-778,-1000,-556,-1000,311,-1000,-1000,-373,-1000,-1000,-1000,-1000,1000,115,-794,664,975,-623,-1000,56,-219,1000,-420,879,154,-1000,-598,-935,825,1000,-381,1000,-650,-767,-967,-929,-461,1000,-74,-1000,-1000,-20,1000,-406,-1000,-1000,-201,606,-1000,-1000,-535,-10,-528,-776}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00187() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder$StrBuilderReader", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "asReader():java.io.Reader",
            new int[]{-276,-1000,235,92,-806,-719,214,-511,-22,-852,1000,-144,-635,-1000,-594,-1000,-378,887,-301,-81,-695,-227,-341,-309,-1000,-980,201,-1000,1000,-492,230,-1000,1000,576,-671,-495,385,-651,508,-1000,282,764,-304,83,-809,1000,-309,201,997,-1000,-85,188,-957,-255,-800,-984,1000,798,1000,1000,1000,791,-855,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00188() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder$StrBuilderReader", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "asReader():java.io.Reader",
            new int[]{-1000,-453,-466,-28,-851,410,293,388,-37,-363,-506,-25,-548,-182,231,-677,122,43,440,-668,-109,380,618,-484,101,-381,-295,-98,356,-135,-279,11,-1000,-131,-191,693,373,494,-151,486,-1000,74,-95,-472,81,264,-289,-884,-347,-229,118,-163,93,-597,83,376,-482,-607,1000,-312,-60,-8,-672,21}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00189() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder$StrBuilderReader", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "asReader():java.io.Reader",
            new int[]{884,-1000,422,1000,903,426,-116,486,-183,72,-723,-231,-857,1000,-17,57,1000,-462,807,-462,1000,968,-1000,184,1000,386,1000,928,1000,-268,-1000,989,-898,-1000,998,-106,-1000,703,1000,1000,-339,-507,621,-85,1000,-1000,922,-1000,-520,-1000,321,284,721,46,449,264,-799,-1000,-311,-1000,-1000,-1000,-431,662}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00190() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder$StrBuilderReader", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "asReader():java.io.Reader",
            new int[]{43,-456,99,-684,-1000,-1000,942,1000,199,686,-62,-160,-1000,899,576,351,559,-685,-199,-654,-664,618,-444,420,464,-491,-139,477,958,-876,397,-252,425,173,14,-5,49,-696,-390,-901,594,418,-414,24,-131,-170,-653,158,2,784,-292,-829,168,-257,-528,-716,-269,-608,486,442,276,-149,-1000,-97}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00191() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder$StrBuilderReader", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "asReader():java.io.Reader",
            new int[]{445,-650,-91,-502,-178,227,-1000,936,-340,-133,-560,242,-1000,267,-902,-1000,804,400,280,41,1000,782,-473,184,1000,-1000,1000,-114,518,57,409,17,590,911,331,-728,-172,342,566,1000,-243,281,628,-185,543,-1000,1000,-1000,-196,-1000,-340,761,296,213,459,-1000,-1000,-1000,-348,-1000,-331,-1000,-1000,-416}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00192() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder$StrBuilderReader", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "asReader():java.io.Reader",
            new int[]{1000,-1000,-207,-1000,133,-27,-1000,592,939,-431,-636,1000,-1000,260,-1000,-801,-825,843,-126,-927,230,1000,1000,-1000,-341,1000,1000,-1000,997,392,330,-1000,-435,119,-1000,-141,901,1000,-1000,-478,-1000,1000,-732,-1000,244,605,1000,-1000,421,-237,-1000,-1000,1000,1000,1000,-945,287,-1000,-769,-625,-978,-490,-191,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00193() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder$StrBuilderReader", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "asReader():java.io.Reader",
            new int[]{-900,-568,480,-284,1000,432,958,-134,-1000,-1000,652,1000,-623,40,-971,802,-306,1000,1000,-65,1000,365,-1000,-418,-352,-1000,903,-46,-544,-585,1000,-1000,471,-1000,1000,-221,-1000,1000,1000,1000,512,394,805,-927,555,-658,1000,-1000,966,-400,-510,243,-550,7,1000,-1000,1000,-1000,-759,622,-376,-713,285,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00194() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder$StrBuilderTokenizer", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "asTokenizer():org.apache.commons.lang.text.StrTokenizer",
            new int[]{-275,-1000,-869,232,-781,13,594,462,-864,-753,-31,-53,-371,1000,1000,426,-725,898,1000,-903,1000,-614,-90,-1000,1000,1000,-1000,362,-1000,-1000,-904,-450,792,69,195,-754,-614,309,-548,1000,1000,-235,-72,-1000,1000,-1000,163,-148,367,1000,-330,1000,-876,974,36,-1000,226,-806,199,-433,-326,-933,400,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00195() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder$StrBuilderTokenizer", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "asTokenizer():org.apache.commons.lang.text.StrTokenizer",
            new int[]{799,246,-866,-658,-251,-905,-227,-1000,-1000,-1000,-817,-1000,-783,262,1000,345,-604,1000,-1000,-1000,1000,-216,-527,949,1000,542,736,178,-1000,-1000,909,-821,-735,-290,444,-1000,-868,747,-988,159,1000,-752,-552,999,1000,-1000,-156,-193,-812,1000,-31,836,-618,-224,-1000,385,62,329,1000,-105,1000,-1000,12,-283}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00196() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder$StrBuilderTokenizer", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "asTokenizer():org.apache.commons.lang.text.StrTokenizer",
            new int[]{654,1000,481,1000,-411,-378,-1000,211,-836,-847,-960,-227,-528,63,1000,701,-678,-1000,772,2,-1000,877,-1000,392,642,297,608,-1000,-635,142,1000,636,-263,-512,-1000,405,-1000,654,-1000,-561,-434,1000,42,-525,1000,1000,985,-150,-1000,-479,-709,-1000,737,743,-1000,-1000,1000,-254,36,1000,-879,686,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00197() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder$StrBuilderTokenizer", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "asTokenizer():org.apache.commons.lang.text.StrTokenizer",
            new int[]{1000,422,400,943,87,-512,369,-914,-330,702,123,1000,-333,599,-400,1000,492,-400,-64,32,1000,-1000,-138,1000,978,-74,780,1000,140,-1000,-265,894,-835,-1000,-834,-1000,-355,-536,79,480,1000,-610,231,17,-712,-271,-699,1000,-241,1000,-467,508,-1000,-464,-485,-322,-1000,258,627,-1000,936,-992,194,707}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00198() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder$StrBuilderTokenizer", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "asTokenizer():org.apache.commons.lang.text.StrTokenizer",
            new int[]{46,-1000,-394,-313,146,-471,369,586,-330,-168,-190,-74,-795,-162,413,-398,14,-217,-684,411,-991,-1000,-138,1000,-400,-311,400,-1000,140,1000,-612,894,116,768,-834,36,600,1000,79,621,-896,957,940,-1000,-712,-271,343,-714,239,-1000,-1000,508,-271,267,-10,1000,103,-323,627,947,-572,413,-681,-909}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00199() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder$StrBuilderTokenizer", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "asTokenizer():org.apache.commons.lang.text.StrTokenizer",
            new int[]{-1000,-1000,-911,1000,-1,-486,-1000,249,117,311,-930,1000,-973,1000,-505,-377,-722,-797,-1000,330,735,-798,-755,250,1000,-289,-1000,296,-136,-1000,-1000,-1000,-193,-20,441,778,-597,824,-289,1000,488,-111,580,-579,781,-886,311,925,978,1000,-885,38,170,1000,1000,384,789,-313,323,-50,-1000,-302,-1000,-127}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00200() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder$StrBuilderTokenizer", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "asTokenizer():org.apache.commons.lang.text.StrTokenizer",
            new int[]{1000,-696,-801,1000,402,21,479,-119,-309,452,946,217,-355,745,1000,-377,-1000,-511,768,-796,121,-798,242,141,604,321,449,-818,-687,-1000,-387,1000,830,-20,-753,778,631,552,-258,643,-1000,511,680,745,-705,-360,-622,-1000,-1000,17,-910,38,343,1000,490,384,96,-684,415,1000,-1000,794,602,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00201() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder$StrBuilderWriter", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "asWriter():java.io.Writer",
            new int[]{-940,56,936,-38,-34,353,358,-103,880,587,-351,-301,-846,-105,254,-536,425,-460,143,992,-368,-714,-455,-602,927,-110,173,-659,858,754,-789,-448,722,-163,-408,297,-579,-637,-883,745,-689,-460,825,825,566,-448,-309,-946,400,416,206,135,111,-56,-313,-415,-621,24,-738,-381,-514,690,399,621}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00202() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder$StrBuilderWriter", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "asWriter():java.io.Writer",
            new int[]{-1000,420,609,637,-235,58,-424,234,-188,1000,1000,738,644,-643,244,-493,-285,1000,-558,-1000,-852,-474,-1000,183,726,-796,-1000,441,-431,343,-441,-320,472,-925,-1000,-35,-1000,-1000,-1000,15,505,1000,-852,657,302,531,931,-113,1000,-1000,-182,-859,582,-1000,-651,855,744,-426,-560,-721,-1000,849,829,-965}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00203() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder$StrBuilderWriter", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "asWriter():java.io.Writer",
            new int[]{1000,80,-258,173,-1000,-1000,-851,91,202,739,1000,-89,-87,-1000,19,179,736,-1000,-856,173,1000,372,1000,-72,-1000,140,-652,-547,-1000,-980,-347,-423,-660,284,132,670,-812,396,392,813,-88,-824,-1000,-897,-386,821,43,749,-463,-1000,1000,-189,359,-1000,250,690,852,1000,-60,1000,-1000,-614,1000,-964}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00204() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder$StrBuilderWriter", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "asWriter():java.io.Writer",
            new int[]{356,292,771,69,-482,324,278,228,-500,1000,594,572,-230,1000,478,-778,339,654,-6,-448,-386,-326,-1000,-97,269,-593,-209,166,300,424,222,-531,615,232,-1000,110,-543,-738,-918,29,-307,637,-782,428,564,-123,535,104,580,-509,277,61,920,-90,459,-1000,467,-292,-598,-1000,-1000,1000,579,-125}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00205() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder$StrBuilderWriter", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "asWriter():java.io.Writer",
            new int[]{832,-19,1000,-131,194,218,739,-1000,394,193,594,381,-302,407,927,120,557,-644,-1000,1000,731,-948,-18,747,-885,223,-253,82,669,920,723,-762,748,-853,-1000,508,-1000,-437,-829,123,1000,-1000,691,316,-381,-1000,-868,-788,-1000,1000,557,-567,-186,-188,-1000,-136,-1000,709,-203,33,-795,-772,587,735}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00206() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder$StrBuilderWriter", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "asWriter():java.io.Writer",
            new int[]{283,290,-1000,155,-1000,-33,-402,-289,1000,-725,-272,969,651,-554,249,138,622,-546,-409,1000,-200,-367,1000,279,-405,-656,-240,-949,-1000,-188,-291,-410,-709,-895,-189,-222,-795,-368,642,646,1000,-1000,-611,-536,1000,-106,-978,-583,-33,877,737,-84,-1000,-626,-1000,294,10,558,-909,328,-400,-110,1000,-447}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00207() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder$StrBuilderWriter", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "asWriter():java.io.Writer",
            new int[]{-958,197,1000,338,246,147,739,-846,201,193,594,-32,-977,659,104,-842,-158,-832,24,394,-452,-1000,-618,747,557,-503,-267,31,813,1000,397,-279,916,30,-324,-150,-586,-759,-918,1000,-334,-22,1000,1000,-405,57,-868,-977,580,-9,200,-630,-18,-422,-364,-615,-1000,-65,-203,-620,-788,691,335,-182}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00208() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder$StrBuilderWriter", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "asWriter():java.io.Writer",
            new int[]{-1000,554,160,702,-480,597,-305,-348,599,659,-48,357,146,1000,-602,-692,454,-36,880,-746,-665,-111,-385,569,608,-747,-282,-628,-1000,594,-317,-107,-574,-235,506,-831,-771,-848,-341,629,-585,1000,179,181,552,412,-349,-476,995,244,-105,-251,-764,-326,-932,923,-10,-360,-1000,-261,-527,1000,1000,-460}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00209() {
        org.junit.Assert.assertEquals("java.lang.Integer:MTAw", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "capacity():int",
            new int[]{1000,-205,1000,-844,-400,1000,-106,-150,-132,566,399,-1000,-1000,-236,-709,836,-1000,-858,357,1000,-938,1000,-190,-731,12,-1000,-363,619,481,-374,-169,874,841,-569,401,251,-77,-139,-158,-566,-651,-424,430,-531,-711,934,-646,553,1000,319,507,-161,-62,646,-570,-461,-1000,824,-292,-429,209,-700,-979,-20}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00210() {
        org.junit.Assert.assertEquals("java.lang.Integer:MzI=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "capacity():int",
            new int[]{183,366,-207,492,-377,320,-438,608,1000,-744,415,1000,996,-741,-992,-275,-1000,-617,71,972,274,1000,1000,-507,-986,-501,49,250,251,117,-87,781,-1000,-244,-474,436,-329,671,1000,-916,-711,-66,-796,140,-373,1000,-1000,-761,-337,1000,-667,-355,-213,683,423,531,176,819,950,-400,-981,-1000,-774,342}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00211() {
        org.junit.Assert.assertEquals("java.lang.Integer:MzI=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "capacity():int",
            new int[]{1000,-205,174,-433,-404,1000,173,-279,172,31,399,742,178,-96,60,507,-1000,-1000,193,338,-938,1000,57,-584,619,-426,-319,619,905,-715,711,465,411,-569,638,251,-58,-1000,483,-475,-59,-1000,660,-922,450,179,284,894,1000,1000,-763,-923,-311,156,-845,-461,-1000,1000,-579,-429,209,-719,-1000,-527}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00212() {
        org.junit.Assert.assertEquals("java.lang.Integer:Mzk=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "capacity():int",
            new int[]{-755,659,901,334,148,310,583,-501,-306,698,-875,-1000,-724,1000,1000,-534,-113,409,-852,-1000,-941,-1000,-1000,82,-161,-1000,396,775,319,565,-587,-1000,-471,-233,556,-1000,1000,584,-198,188,-826,287,283,1000,894,818,399,-686,-372,-1000,1000,739,-276,-508,690,416,489,-51,-245,-646,954,994,678,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00213() {
        org.junit.Assert.assertEquals("java.lang.Integer:MzI=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "capacity():int",
            new int[]{472,1000,-766,249,867,599,-624,79,669,539,-136,-325,103,-223,-1000,-1000,1000,-1000,661,-575,-313,-1000,228,-160,-511,657,1000,-20,-14,-47,548,1000,-376,-964,620,-567,60,465,768,-778,103,836,-1000,219,-610,-72,-900,-735,-494,-1000,-762,-400,-150,-428,577,-485,1000,1000,141,995,1000,645,429,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00214() {
        org.junit.Assert.assertEquals("java.lang.Integer:NDA=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "capacity():int",
            new int[]{1000,-1000,-245,-777,-1000,214,-211,6,9,-68,1000,92,380,-40,-584,664,-722,-900,211,911,-642,620,-453,-670,369,-258,-106,446,260,-101,186,991,230,349,-302,786,-867,-627,304,244,-41,-1000,217,-677,153,906,-83,417,213,1000,296,-578,375,298,-875,-1000,-446,676,258,-746,-380,-387,-968,-443}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00215() {
        org.junit.Assert.assertEquals("java.lang.Integer:MTAw", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "capacity():int",
            new int[]{1000,257,432,-1000,1000,674,74,-167,156,-552,-64,-988,1000,-422,-1000,596,-1000,-157,878,33,-88,830,734,281,-846,-1000,-103,719,600,-320,-1000,221,836,-895,6,-1000,517,1000,-700,-708,-357,970,311,-566,-1000,1000,159,-662,1000,-385,1000,854,337,308,309,835,-283,512,-153,-607,1000,-136,-241,418}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00216() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "charAt(int):char",
            new int[]{250,-1000,-1000,-1000,500,738,674,1000,-418,-573,685,-155,946,-1000,369,-800,1000,-241,-1000,513,-1000,-341,-1000,1000,-1000,615,-1000,553,-874,-1000,1000,383,413,714,1000,521,-1000,307,669,1000,-1000,-1000,-137,-1000,-342,-638,1000,-1000,603,-861,-109,400,-1000,1000,-1000,1000,776,-688,-602,-1000,-1000,583,690,-849}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00217() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "charAt(int):char",
            new int[]{90,-287,-646,1000,-221,-798,336,-109,-263,87,328,-621,-939,-186,-773,-364,615,618,448,-214,-1000,836,-1000,1000,349,-478,400,591,1000,-479,213,-33,-1000,-361,52,-1000,-460,-651,-669,-88,-553,-808,-1000,29,-473,309,1000,-571,1000,-1000,768,141,-934,-576,-665,-989,391,-885,186,-932,711,14,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00218() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "charAt(int):char",
            new int[]{78,462,629,164,97,-392,-1000,-809,-219,-1000,972,-463,-1000,360,-1000,1000,262,609,-138,1000,60,694,-84,-578,114,-872,1000,-345,300,471,-1000,1000,-770,1000,-772,-103,1000,-1000,-341,-643,1000,-969,-165,-323,376,572,977,-100,-260,-6,-305,-1000,-88,-1000,552,473,-777,850,-1000,1000,-76,832,67,841}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00219() {
        org.junit.Assert.assertEquals("java.lang.Character:eA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "charAt(int):char",
            new int[]{-1000,-1000,919,400,-1000,342,721,-804,228,492,423,-878,-651,863,-271,-383,-876,347,1000,-1000,-1000,738,-1000,913,322,-990,-1000,446,1000,444,532,812,-1000,-599,-846,-1000,-814,242,-1000,-27,362,-591,-1000,930,-748,777,-64,342,169,-769,81,1000,89,310,-58,-1000,-567,-1000,753,-952,1000,-1000,-816,-57}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00220() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "charAt(int):char",
            new int[]{165,-151,-432,176,786,-106,339,40,427,-129,-421,1000,-1000,989,-112,135,274,-454,-456,671,-198,710,942,619,214,-232,-1000,444,-286,-708,-805,-138,299,1000,739,-441,1000,388,504,-418,644,-995,139,-178,101,-944,916,-376,198,729,546,-869,-1000,-778,899,805,761,466,456,1000,915,-1000,-1000,399}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00221() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "charAt(int):char",
            new int[]{389,-910,-1000,-1000,1000,-961,944,986,-29,-379,1000,-468,-401,-863,-701,1000,-735,-943,-911,766,-577,-290,-430,111,-1000,533,-615,234,-884,782,644,-556,551,854,1000,1000,-1000,207,870,1000,571,-476,652,-970,1000,-191,233,202,289,-327,-100,-635,161,1000,-572,236,-661,262,-1000,-1000,-1000,804,1000,-776}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00222() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "charAt(int):char",
            new int[]{1000,380,-708,-357,1000,-1000,-112,12,-144,-761,-604,368,590,107,-186,-189,1000,427,-650,981,-63,-42,38,909,-877,359,260,215,-1000,-429,-619,-554,-459,199,425,541,24,106,216,67,-992,-1000,1000,305,465,181,1000,-1000,186,1000,316,-1000,-952,-688,-173,537,-232,1000,-377,-241,-693,1000,433,-381}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00223() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "clear():org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-502,5,-288,52,-537,738,107,159,1000,-53,852,1000,97,1000,166,-668,-337,-1000,770,-617,-438,963,1000,-1000,-301,459,928,99,1000,1000,-227,138,1000,1000,730,-459,215,182,-147,852,-148,-20,567,1000,-458,-544,-220,-755,-957,-1000,342,301,-59,-1000,1000,-295,-749,814,789,-115,263,-327,267}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00224() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "clear():org.apache.commons.lang.text.StrBuilder",
            new int[]{439,-816,-101,-846,223,1000,-1000,1000,-514,-1000,-37,-802,177,-917,-590,-406,-922,-1000,1000,680,-670,348,-521,-143,-825,-244,957,-1000,-124,-416,40,-1000,202,-558,562,810,373,1000,-60,-215,-1000,1000,5,1000,349,-1000,583,-451,-727,85,466,-329,735,-1000,-617,-1000,-227,542,-184,44,-1000,-765,-502,129}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00225() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "clear():org.apache.commons.lang.text.StrBuilder",
            new int[]{-485,-799,1000,876,128,-545,-12,-919,-432,-725,-307,-528,-1000,853,-934,-1000,-1000,700,574,422,-491,-381,75,-1000,-571,114,471,218,421,-741,-618,-1000,319,347,-34,-382,37,-736,733,1000,227,-1000,-400,-1000,1000,34,142,1000,-948,618,-362,-933,1000,-442,623,910,1000,-1000,173,-922,593,-124,-654,105}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00226() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "clear():org.apache.commons.lang.text.StrBuilder",
            new int[]{563,128,673,-720,308,-222,189,-811,457,-708,558,59,-672,-768,-845,-132,-387,207,574,462,-530,-106,75,-92,-26,-57,231,-378,970,734,-618,-979,-203,977,787,-359,37,995,978,-332,484,-796,792,677,-128,796,738,960,533,-108,-23,341,134,-442,-986,-446,915,-16,406,-596,424,-134,-713,777}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00227() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "clear():org.apache.commons.lang.text.StrBuilder",
            new int[]{389,1000,-1000,-718,-91,451,-45,652,-313,1000,-528,184,559,-81,-155,737,956,-478,282,77,-725,874,-365,1000,575,-1000,-473,804,-803,1000,-866,984,1000,-619,411,1000,-746,-15,-152,-1000,-300,1000,234,883,-1000,49,-156,-121,993,-1000,-515,1000,-717,184,123,-435,-1000,463,225,1000,-369,-588,-206,-346}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00228() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "clear():org.apache.commons.lang.text.StrBuilder",
            new int[]{292,-1000,-16,-1000,679,318,324,712,-50,1000,1000,-1000,-834,264,29,-1000,-926,-239,186,1000,-1000,908,1000,-354,-456,-1000,1000,-435,1000,201,228,-853,1000,1000,759,-93,808,843,-543,156,1000,599,357,-243,1000,162,-1000,175,-43,888,-743,868,-324,529,-128,795,-1000,-702,-1000,965,-942,48,-217,901}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00229() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "contains(char):boolean",
            new int[]{805,338,-737,1000,16,-495,869,423,-982,1000,650,-956,-1000,589,-355,-1000,1000,1000,12,1000,-26,-203,1000,361,-181,1000,-451,82,-497,-826,1000,-306,-778,374,-545,-155,-1000,-409,876,-1000,-473,-389,203,-555,461,-921,250,1000,149,1000,1000,-1000,732,1000,371,-889,170,1000,963,938,-1000,668,-245,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00230() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "contains(char):boolean",
            new int[]{444,189,258,-22,587,-841,449,1000,-368,-494,-205,-199,400,-211,-1000,-1000,745,1000,-379,-1000,-879,-117,1000,144,-169,1000,671,-268,-2,648,-1000,-785,-150,170,509,-1000,483,-950,-377,-484,-314,-1000,1000,-758,721,-494,162,1000,-6,-458,-1000,94,767,776,-969,-1000,243,824,301,1000,-72,168,-607,596}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00231() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "contains(char):boolean",
            new int[]{697,-1000,-529,810,642,-1000,649,-751,-388,-941,902,13,-278,916,871,-589,-1000,415,-706,1000,888,6,-1000,940,1000,60,802,894,-795,-831,-654,-1000,-264,1000,914,439,-1000,-1000,257,-267,-953,-1000,644,-1000,-840,751,293,1000,277,-389,-1000,641,-261,-1000,-633,-787,991,1000,835,827,700,-188,426,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00232() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "contains(char):boolean",
            new int[]{115,553,1000,-142,-896,-68,352,-97,-504,-743,768,-624,1000,379,-1000,-205,714,-1000,-500,480,-784,-483,1000,-1000,580,-983,-226,465,-197,-199,-750,-1000,-518,-90,-1000,-546,-479,-1000,299,953,-480,-1000,489,36,1000,-62,691,-279,-629,139,803,443,588,787,-778,-79,315,-72,-595,664,-448,418,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00233() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "contains(char):boolean",
            new int[]{-625,-1000,285,-1000,1000,621,112,1000,-910,-1000,-227,1000,-1000,-222,886,1000,-1000,-1000,216,-828,1000,187,-257,-295,1000,-1000,1000,938,-1000,324,672,907,-281,-168,794,-1000,55,1000,725,14,-578,-258,-912,-1000,-1000,643,746,-1000,-461,-320,-1000,1000,-792,-1000,1000,319,1000,-927,-230,-28,1000,-1000,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00234() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "contains(char):boolean",
            new int[]{-264,-1000,-156,-608,1000,29,321,-596,493,-1000,882,1000,1000,113,1000,400,-1000,-985,65,-1000,1000,484,1000,-1000,1000,-920,1000,522,-748,145,-838,-506,26,-26,1000,120,78,-562,-388,216,-477,-47,158,-1000,979,1000,689,-977,712,-1000,-1000,1000,-1000,-1000,-560,316,1000,-532,147,-956,1000,-1000,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00235() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "contains(char):boolean",
            new int[]{46,-1000,-960,-403,1000,29,671,-596,-105,-577,1000,1000,1000,113,1000,-446,-417,-44,-155,-1000,689,-50,480,-945,1000,-611,727,819,-498,323,-1000,-1000,353,275,1000,-226,-891,-1000,-259,470,-262,-282,1000,-1000,1000,941,270,-191,206,-628,-1000,985,-754,-997,-1000,-53,1000,-307,147,-1000,1000,-677,927,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00236() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "contains(java.lang.String):boolean",
            new int[]{313,-1000,343,708,-487,-657,-208,772,-269,-648,1000,-73,76,247,192,-542,-1000,-1000,52,-807,-1000,135,-1000,353,-92,305,1000,-91,169,-1000,-776,197,292,352,-516,51,960,1000,1000,1000,1000,-447,-1000,475,-933,1000,-709,-260,-576,1000,-1000,-332,762,-14,1000,-301,-612,-707,908,759,363,164,663,-299}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00237() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "contains(java.lang.String):boolean",
            new int[]{890,144,664,-874,772,-940,-629,353,834,166,797,-785,69,244,913,197,308,177,-107,-447,-675,-771,163,444,463,-566,-321,-24,-90,-955,975,-626,-817,298,-611,-469,118,886,981,-59,727,493,175,-368,651,-524,885,154,603,387,989,867,-768,380,441,-156,-920,-233,-30,-441,999,987,394,-834}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00238() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "contains(java.lang.String):boolean",
            new int[]{281,-1000,1000,-1000,-514,871,738,369,754,-777,-433,259,841,1000,1000,-578,197,424,-1000,-942,-502,-1000,318,-1000,-694,879,-1000,-414,728,-803,206,160,61,432,60,1000,-359,1000,-1000,891,1000,870,-713,-883,-959,1000,806,-1000,847,565,1000,-470,1000,-135,751,-181,-1000,-1000,267,-345,-71,-559,-101,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00239() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "contains(java.lang.String):boolean",
            new int[]{-878,-1000,-146,1000,-665,580,-1000,433,-1000,83,280,-191,479,-659,-1000,-1000,-1000,-564,-566,533,812,697,-1000,1000,-1000,-683,756,572,853,209,-1000,-420,443,1000,-179,490,-252,1000,1000,869,-312,-1000,-22,737,-1000,-418,-641,400,-1000,-1000,518,-1000,490,-1000,399,96,-220,-603,-28,97,-277,22,387,-445}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00240() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "contains(java.lang.String):boolean",
            new int[]{527,457,834,993,138,177,-31,474,-744,48,-215,-107,-473,542,937,62,-360,382,702,-657,-479,-261,-835,287,4,-294,394,-533,-117,-638,-337,-20,-820,-536,952,24,266,115,397,-196,609,23,-458,-217,-710,101,867,337,83,-570,-981,-386,483,332,56,-325,-1000,-624,905,902,-110,658,-592,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00241() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "contains(java.lang.String):boolean",
            new int[]{403,-1000,-1000,1000,263,536,-1000,1000,-1000,789,-1000,-95,1000,-388,75,-1000,-1000,-1000,-1000,-1000,-1000,66,-1000,1000,-1000,61,-27,709,-305,470,-1000,652,-524,1000,-1000,1000,-102,1000,-5,1000,1000,-1000,-1000,1000,163,1000,-631,-1000,-387,-1000,-749,-104,1000,-1000,403,-663,-1000,-499,1000,1000,-1000,-1000,1000,49}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00242() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "contains(java.lang.String):boolean",
            new int[]{665,-1000,-239,-400,357,-798,286,578,598,189,-814,12,-112,-231,128,-445,-177,98,-1000,-91,344,400,69,-240,-353,673,-775,437,205,-760,-1000,101,1000,-413,258,-400,-93,82,820,63,566,262,-104,-400,-989,-463,-308,-329,273,-1000,-922,-303,59,-189,476,-579,518,209,-28,-662,-119,-370,-306,631}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00243() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "contains(java.lang.String):boolean",
            new int[]{-79,290,534,-121,800,-107,743,119,401,-515,-39,-56,-464,300,393,377,754,102,-162,-255,202,262,541,-636,826,587,-86,-982,-287,-688,-221,-745,540,-203,952,-736,-90,-296,-711,130,573,-11,-496,-1000,-1000,-297,572,-917,355,612,-839,812,461,93,119,-500,157,28,-440,-211,104,-109,-101,96}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00244() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "contains(java.lang.String):boolean",
            new int[]{386,-1000,-301,802,1000,-28,-979,794,52,129,-336,155,-60,-317,-287,-415,-118,-628,-1000,66,-80,-721,-306,835,587,1000,-589,30,-431,-463,-756,-1000,-1000,1000,-1000,1000,-171,-250,204,1000,186,-1000,-1000,144,-503,539,-724,218,334,-1000,-503,-289,476,400,347,-591,438,577,-689,123,-600,-1000,800,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00245() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "contains(java.lang.String):boolean",
            new int[]{873,-679,714,296,379,-670,-158,850,-151,1000,1000,-330,12,-853,-894,-1000,-908,-596,-477,-807,-1000,-744,-382,2,-68,735,-489,-400,366,-912,-723,-505,292,1000,-135,1000,960,1000,-131,1000,1000,-415,-1000,1000,-934,676,-499,882,263,-1000,-1000,-70,609,1000,1000,-410,-612,-1000,1000,759,944,-156,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00246() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "contains(java.lang.String):boolean",
            new int[]{909,-1000,-240,-336,642,-351,-20,751,-4,905,-310,311,506,-71,-218,-411,-106,-393,-701,-1000,-729,16,-270,-182,-168,1000,-1000,188,334,-1000,-19,536,1000,1000,-422,51,-394,1000,-843,615,1000,-20,-458,388,-933,185,-876,-518,900,-356,-364,127,570,791,56,-687,-612,-360,374,1000,-996,-705,380,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00247() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "contains(org.apache.commons.lang.text.StrMatcher):boolean",
            new int[]{-620,800,-324,-935,-361,812,-281,414,788,1000,-1000,-33,3,-1000,792,401,575,1000,505,-51,-537,316,-856,-141,1000,-250,805,251,-964,-1000,-157,527,-644,791,-499,-499,170,-307,-1000,254,-77,493,-413,-72,-614,-177,288,556,106,572,1000,-11,104,785,75,1000,512,253,220,246,-1000,-454,-615,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00248() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "contains(org.apache.commons.lang.text.StrMatcher):boolean",
            new int[]{109,-6,714,-304,-69,-30,-797,478,-244,-522,-1000,495,322,-1000,688,-145,-734,-557,-175,699,-1000,-895,-344,-1000,204,-46,-1000,-1000,512,681,1000,333,-210,-460,-146,480,-26,1000,-544,20,-593,-1000,388,-20,-83,599,775,-32,1000,1000,210,323,-247,-787,-411,-679,382,58,629,200,-349,962,-1000,336}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00249() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "contains(org.apache.commons.lang.text.StrMatcher):boolean",
            new int[]{-52,1000,-368,114,269,432,-456,-486,-168,595,-397,-1000,-876,-881,-191,221,400,-417,-366,-584,88,-242,317,255,-361,-97,-1000,337,-298,-260,867,69,881,1000,-19,765,-832,187,1000,1000,-999,626,-769,361,306,899,-282,147,-620,-683,244,-197,67,869,1000,554,-41,740,-34,-597,-1000,512,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00250() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "contains(org.apache.commons.lang.text.StrMatcher):boolean",
            new int[]{-275,155,-881,1000,-869,910,-50,-459,619,369,275,-1000,211,-889,959,1000,969,15,-123,-294,397,317,-203,-1000,677,-1000,-642,-715,262,-519,876,-83,-312,-688,-316,-1000,97,-396,70,-775,885,1000,-461,445,-315,-785,237,1000,-568,1000,149,581,43,-903,-536,-558,-1000,-319,-151,-1000,-710,617,-838,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00251() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "contains(org.apache.commons.lang.text.StrMatcher):boolean",
            new int[]{-144,-228,129,202,681,-97,-3,660,-93,519,-106,-554,363,721,106,-1000,514,-98,-325,-16,-119,521,93,1000,396,367,79,-12,72,366,-165,-251,247,160,208,732,-446,-661,152,32,-649,-76,161,90,-564,856,-64,-218,-772,-315,89,-208,-48,244,102,363,-552,538,188,-401,280,107,-23,24}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00252() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "contains(org.apache.commons.lang.text.StrMatcher):boolean",
            new int[]{-418,-409,-1000,159,-683,1000,-318,-896,256,1000,-848,-118,-1000,-1000,1000,-1000,510,-637,504,635,750,-946,-1000,1000,-354,-750,119,-454,-970,-1000,1000,1000,1000,938,596,-213,-54,978,32,-311,-353,1000,-42,1000,552,176,-840,1000,-1000,100,1000,286,237,505,352,1000,878,477,-509,-1000,-1000,-479,-142,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00253() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "contains(org.apache.commons.lang.text.StrMatcher):boolean",
            new int[]{177,-409,1000,-1000,489,241,-413,-59,-769,960,-540,246,-1000,-873,-262,-145,-1000,-920,297,729,343,-1000,222,1000,-38,542,-523,-104,-49,25,307,507,368,954,-414,1000,-940,314,632,133,-999,-813,-229,-560,-240,1000,-930,-59,-1000,-1000,772,-730,846,610,924,1000,84,1000,109,-362,-656,-318,811,-933}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00254() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "contains(org.apache.commons.lang.text.StrMatcher):boolean",
            new int[]{285,848,-547,-1000,188,1000,-596,-550,-447,1000,-81,-219,-373,-306,-401,-145,235,-1000,899,678,631,-1000,350,148,-248,312,-1000,-270,-698,-556,-1000,1000,1000,1000,-817,1000,-1000,603,1000,618,-1000,-48,-1000,1000,-527,1000,-1000,335,626,-1000,1000,-1000,371,803,1000,1000,-97,1000,-936,215,-436,66,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00255() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "contains(org.apache.commons.lang.text.StrMatcher):boolean",
            new int[]{-216,-385,-272,159,-645,602,87,-222,-16,302,293,-1000,146,-1000,325,1000,1000,135,-596,-617,-220,-1000,-103,-1000,440,-779,-642,-6,-23,-75,292,-608,215,-143,239,-883,-68,-276,-109,-97,639,416,-1000,-318,-289,-785,301,452,412,-1000,-129,235,336,-374,13,1000,-386,-256,417,-501,-583,502,-530,283}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00256() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "delete(int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-262,-604,-889,-865,-521,-511,-508,-1000,1000,-675,1000,292,637,-638,370,-50,612,536,62,125,-1000,-169,-611,645,1000,-1000,-896,267,1000,641,-449,1000,-894,200,635,-495,981,100,-995,-1000,808,-71,481,-1000,-9,1000,732,196,-1000,1000,-1000,121,-559,665,522,-1000,1000,75,1000,-1000,707,403,510,912}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00257() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "delete(int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-459,-600,804,129,184,1000,475,852,-579,689,-1000,-1000,0,-293,631,0,1000,-1000,34,-369,1000,775,1000,-1000,-953,-357,53,-27,-1000,-689,0,-246,817,653,-1000,462,-1000,-77,847,776,-727,-175,402,235,677,-272,0,-965,1000,-502,1000,443,904,658,614,38,490,-97,0,265,186,-212,-43,-49}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00258() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "delete(int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-916,1000,-910,129,974,218,-577,1000,-258,-911,-953,-1000,792,463,-936,0,296,-475,508,697,639,775,1000,-1000,502,1000,121,-94,598,1000,-740,-442,-205,1000,-1000,-31,869,-77,-520,356,-727,204,402,235,-233,10,-268,67,-1000,-502,257,953,-1000,-1000,-89,-26,296,-462,290,-11,-836,41,671,-871}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00259() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "delete(int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,857,652,-517,818,-676,348,-663,-1000,373,-439,-595,1000,303,207,-1000,61,859,379,-746,-552,-1000,51,1000,625,22,-513,-1000,-1000,1000,-299,37,744,-17,-177,148,483,329,1000,1000,-1000,-1000,1000,222,-63,-609,-875,-304,-1000,400,1000,-1000,-1000,406,940,136,-444,753,177,320,197,466,350,-10}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00260() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "delete(int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-338,299,915,442,733,-356,401,-77,-540,584,-724,-734,639,-437,149,-544,308,191,-545,361,-188,-328,-129,180,-115,326,-70,-215,-1000,-62,753,-73,635,573,-751,518,-431,607,-829,1000,656,-152,-120,151,-46,-1000,327,-147,320,-15,1000,-623,-48,-527,-50,-193,-787,941,-74,-251,468,516,255,235}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00261() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "delete(int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-89,857,-1000,174,741,-8,189,-300,-783,564,-1000,-706,61,746,198,-1000,941,-438,-268,-162,-122,-257,252,142,-75,153,-712,223,-675,576,923,-476,791,-7,-694,-108,-301,-236,996,793,-1000,-985,-826,-100,-371,-1000,1000,-67,-549,-104,1000,-334,-814,-69,377,312,-444,1000,-103,287,-279,-510,-549,-10}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00262() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "delete(int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-649,-526,-879,-543,171,-561,-425,-1000,546,151,-181,49,-623,57,492,431,-309,794,-419,183,-737,515,-385,449,1000,-842,-742,-358,789,-800,221,605,539,-379,184,-528,766,-240,-701,-457,424,873,-198,-825,146,708,-17,-268,-305,452,-706,-227,85,292,865,-479,885,-189,454,-887,323,928,346,650}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00263() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "delete(int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-410,-1000,-608,-269,-36,4,397,-804,451,155,893,-130,-226,600,657,952,224,432,-357,523,-191,1000,142,-32,286,-694,-708,223,400,-833,469,255,587,-801,30,-400,400,-164,-797,-530,869,1000,-778,-687,353,429,1000,-444,59,499,-400,332,1000,-233,814,-446,549,-382,400,-584,734,1000,-155,841}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00264() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteAll(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{24,-391,-45,-446,330,684,-72,632,-807,383,35,592,-60,-981,-514,830,9,1000,-411,-576,710,-486,-204,695,197,818,-331,865,-1,-777,-938,-778,-1000,-1,667,329,-450,-8,946,-753,519,95,1000,623,676,-500,1000,412,-242,403,-969,-87,-874,1000,476,135,-665,-161,200,-396,-197,872,-207,-150}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00265() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteAll(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-173,-969,874,827,1000,323,-1000,956,-444,327,-330,610,137,886,-25,450,-232,-319,907,182,1000,521,-275,-457,-445,1000,-739,74,836,-1000,22,833,-378,-110,-832,1000,-578,405,349,-455,34,694,-162,-742,-212,349,543,-114,-179,37,-269,1000,57,963,-747,-571,-469,-683,900,193,-597,713,673,310}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00266() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteAll(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{6,-264,-476,-621,599,953,-386,837,-137,124,-958,523,-96,442,182,161,540,771,117,395,-70,491,305,567,-59,297,-730,-32,1000,-1000,-474,316,556,57,-787,84,-1000,361,476,-551,328,37,1000,92,-1000,1000,1000,-897,754,251,-651,843,-400,22,633,-114,-798,-69,829,-343,858,94,-923,149}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00267() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteAll(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-838,-43,-524,1000,1000,929,-268,-904,-1000,834,559,-1000,1000,-1000,66,443,-89,494,375,-1000,-2,-382,1000,1000,-59,-911,133,-405,-770,-194,-829,336,-907,726,-122,-1000,-948,1000,1000,-1000,1000,266,-295,1000,1000,-358,-1000,-802,-745,287,-377,95,1000,13,-294,-161,-1000,217,30,-1000,1000,1000,346,957}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00268() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteAll(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{114,1000,-868,1000,408,-988,-2,-623,698,-190,-601,-512,817,-267,787,811,722,296,-1000,316,242,-130,1000,-34,611,-1000,75,-497,-1000,216,798,1000,857,677,505,-1000,-338,-31,415,908,-271,-650,89,343,783,-565,656,-614,-471,-1000,-690,-1000,558,-105,-177,1000,-904,-72,-305,-308,879,-342,-1000,120}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00269() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteAll(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-325,137,614,733,-414,-46,1000,-202,-99,-368,111,-836,183,-608,73,-256,-715,-238,-52,-734,-559,-742,784,14,-62,-923,-358,53,127,-126,-264,282,30,70,840,-1000,94,903,552,106,942,-477,-77,1000,475,-569,-754,-782,384,149,-75,133,1000,-990,-390,537,-537,-569,-694,-1000,789,-239,-131,-225}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00270() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteAll(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{621,-1000,-15,-114,-97,264,937,451,-1000,219,550,-233,1000,-1000,-882,1000,465,1000,-388,-1000,108,-126,1000,-912,-497,-1000,455,-143,732,-660,-1000,-532,-1000,1000,-330,-1000,-1000,-219,1000,-1000,773,1000,1000,180,-996,-1000,-8,1000,-1000,244,-580,-265,-1000,-1000,-319,357,-1000,-611,-1000,-829,15,1000,603,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00271() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteAll(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{374,-1000,-848,-314,223,-443,826,1000,-647,-922,-238,1000,650,286,-506,-370,959,808,-1000,64,879,178,265,-765,-697,855,-423,-469,1000,-587,-784,-1000,-1000,1000,-1000,175,-429,-1000,-587,-272,-357,1000,25,-1000,-1000,-838,1000,832,-902,-686,112,15,-630,-22,-986,1000,-218,-644,508,-182,-1000,215,-499,-714}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00272() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteAll(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{90,614,-572,-881,715,644,746,488,-587,-1000,-848,204,-398,-524,635,562,-677,171,-77,1000,161,-1000,-364,-333,-52,-774,981,716,-146,-564,-92,837,375,217,-371,-553,346,349,786,561,-971,221,324,187,-709,915,-801,1000,-971,540,-441,484,-335,229,-188,-43,-554,348,898,-488,1000,992,-23,-235}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00273() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteAll(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-6,320,-198,-199,-531,-1000,258,-156,843,579,176,323,433,774,-642,447,61,-401,-134,787,-1000,-1000,301,70,242,-312,-450,-477,-49,446,-307,-397,-38,-370,226,227,-158,743,-233,1000,442,56,-290,585,846,-826,90,195,-336,556,-352,-395,-797,137,614,219,-829,271,-436,375,-1000,-112,-241,115}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00274() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteAll(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{198,130,-314,-317,-306,-76,-271,262,-124,-928,-294,-98,-67,-305,745,688,-774,-10,-518,645,359,-795,-273,-197,263,-1000,727,-29,198,-95,732,638,-583,-85,-750,-687,542,381,326,956,-811,-884,526,-169,-196,-301,377,1000,-1000,-503,-609,-594,634,304,-1000,-188,-88,-56,555,-629,89,19,-316,-465}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00275() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteAll(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{411,-225,134,314,197,-282,643,-737,165,-768,435,-306,-581,463,231,-516,-554,-451,-222,1000,-594,-927,-126,-172,-385,-377,-271,-508,696,756,281,-218,-333,-1000,-364,-468,48,891,-703,350,-971,343,528,-170,320,-1000,-719,773,-154,937,-74,-985,-321,265,831,603,-660,330,205,-684,-1000,557,-91,-992}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00276() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteAll(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-316,359,-328,-561,253,214,604,587,236,251,-923,594,-251,223,639,371,291,-93,587,645,-18,-521,73,171,36,236,553,925,-216,-684,-56,352,-64,176,773,167,257,372,551,-559,-114,-1,133,668,-1000,852,-470,18,-1000,751,-396,1000,634,304,-1000,-188,-554,211,-32,-267,963,559,-318,-282}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00277() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteAll(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{130,359,-1000,853,847,1000,912,554,-977,-360,-527,-161,-1000,81,889,132,476,980,923,169,81,-521,178,7,1000,23,528,1000,1000,-946,-1000,1000,1000,-201,1000,167,-1000,283,1000,-941,-577,-113,-532,668,959,1000,-510,-193,-624,647,-46,1000,-1000,1000,-1000,970,5,-129,-637,-378,-434,1000,-715,-667}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00278() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteAll(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-552,-1000,224,29,-166,34,-957,902,-509,-619,1000,502,686,838,697,1000,-70,-242,-1000,303,762,-171,-1000,-207,776,-400,1000,-424,619,-369,774,-2,-469,-523,-389,-1000,553,139,672,229,126,-551,625,-1000,1000,-133,624,359,-245,-1000,-978,-1000,-131,-806,528,-828,406,-358,415,-432,849,-834,-475,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00279() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteAll(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-411,-1000,-859,-766,1000,-290,-643,944,-269,332,-681,306,827,-249,1000,850,42,-688,-1000,-130,594,-126,35,-747,926,-769,653,-485,-856,-756,748,866,-396,398,813,-873,1000,407,1000,-789,-899,-423,407,-1000,765,47,719,-38,-637,-1000,-950,407,-576,-858,-652,-484,77,-1000,-205,-273,1000,581,-516,-338}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00280() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteAll(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-958,-253,-395,530,869,792,-924,-406,-272,459,-331,603,-1000,855,330,-1000,239,-36,606,-829,1000,-604,287,-7,1000,491,-21,800,74,-1000,-1000,1000,187,1000,1000,388,-1000,-508,1000,-447,333,-646,718,-468,-243,309,1000,-195,-232,-632,-1000,1000,-1000,378,-1000,637,1000,-453,-972,615,76,1000,76,-684}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00281() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteAll(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-160,-517,612,-516,-761,-393,-1000,522,164,-709,-176,-263,455,207,642,-869,-598,-275,-1000,-351,-420,-987,-561,-963,-441,-1000,967,-690,-250,51,1000,345,-1000,-896,-1000,-923,166,227,-8,1000,-321,-1000,290,-1000,158,-1000,1000,1000,-164,-1000,-495,-978,361,-447,-947,-710,518,-261,280,-479,-177,-1000,-351,-524}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00282() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteAll(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-86,-1000,-143,320,52,-761,-370,331,193,-52,1000,52,-395,1000,788,338,774,42,189,645,233,-460,517,155,843,-167,345,-827,733,42,240,298,-79,-66,-180,-391,687,397,-1000,-800,-212,575,738,-1000,1000,-178,-502,490,-507,-1000,-985,-1000,169,305,-894,-279,584,-551,-436,-602,-1000,565,-633,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00283() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteAll(org.apache.commons.lang.text.StrMatcher):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-1000,-856,-122,378,1000,-231,-631,238,67,-491,310,27,-114,-1000,-198,-823,13,318,530,-452,-1000,1000,-52,-132,400,-400,-413,-813,546,-278,-300,-850,-513,-811,963,958,-1000,-514,536,-344,-69,-797,-794,221,-1000,-1000,133,-734,456,387,1000,866,-255,71,400,91,1000,-691,654,470,-799,622,58}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00284() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteAll(org.apache.commons.lang.text.StrMatcher):org.apache.commons.lang.text.StrBuilder",
            new int[]{0,453,94,91,1000,585,637,-691,-263,-955,76,-462,-436,80,-1000,-10,656,-1000,973,1000,-1000,-907,-1000,-1000,-1000,1000,-794,891,-1000,-495,-1000,1000,-1000,-799,1000,59,-491,-1000,683,369,-1000,629,-963,95,-899,938,-114,-575,-346,-1000,642,769,708,917,-1000,-642,-508,616,-840,301,-1000,785,494,-405}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00285() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteAll(org.apache.commons.lang.text.StrMatcher):org.apache.commons.lang.text.StrBuilder",
            new int[]{-998,580,779,614,999,902,39,-53,427,-1000,-90,-743,-531,506,24,-322,1000,1000,1000,-1000,334,1000,795,892,1000,-1000,593,1000,108,1000,-654,-1000,446,895,1000,-1000,1000,-37,1000,-1000,-1000,-895,-532,-1000,940,-1000,-205,1000,-864,949,190,-888,811,649,-683,-831,216,-1000,817,-579,880,-544,1000,-206}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00286() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteAll(org.apache.commons.lang.text.StrMatcher):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,110,-727,-818,969,-363,869,-902,337,-226,-272,951,225,933,500,-534,-1000,457,-1000,-283,-813,-1000,541,-1000,-1000,1000,1000,587,-1000,-212,-826,42,130,-1000,-753,-616,-971,-997,457,1000,1000,821,85,1000,370,466,-419,334,-785,1000,982,-774,303,157,-443,-1000,335,981,-448,467,526,771,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00287() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteAll(org.apache.commons.lang.text.StrMatcher):org.apache.commons.lang.text.StrBuilder",
            new int[]{400,-1000,219,191,1000,1000,834,-423,164,-353,-628,483,27,-114,-330,-198,855,-400,130,744,211,-555,801,1000,876,91,-1000,-400,1000,811,500,-300,-1000,-116,-414,1000,338,-504,-514,1000,-648,-753,-502,-307,343,-1000,-782,-479,-1000,-359,-438,400,-3,-426,122,776,278,-240,-310,190,758,-555,22,475}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00288() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteAll(org.apache.commons.lang.text.StrMatcher):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-1000,15,237,-1000,1000,724,-727,-126,-816,-1000,-966,827,-239,-1000,1000,1000,246,1000,251,250,-321,1000,836,1000,-910,-1000,-113,1000,1000,1000,-1000,-81,1000,-297,1000,-911,-337,-1000,-725,59,-1000,-1000,-1000,-606,-771,381,656,-78,-419,-865,952,1000,-94,-83,1000,-291,194,522,334,0,-1000,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00289() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteAll(org.apache.commons.lang.text.StrMatcher):org.apache.commons.lang.text.StrBuilder",
            new int[]{400,110,272,-112,-784,888,960,-423,464,-464,-729,712,-707,159,-1000,286,1000,1000,1000,-1000,-1000,-867,652,787,134,-1000,738,-400,425,1000,521,51,-164,-385,-1000,790,786,-1000,158,9,317,-809,829,-1000,521,475,-841,-325,-1000,1000,722,1000,500,235,-603,-300,474,400,-26,-933,758,956,781,-30}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00290() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteCharAt(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{921,-1000,-45,1000,775,87,-604,-1000,-1000,-1000,-298,1000,-421,-830,-1000,868,-283,163,31,6,-1000,-1000,-1000,1000,-96,-167,-547,-1000,622,1000,1000,1000,450,-901,-963,350,781,-1000,712,-1000,170,523,35,-633,710,-1000,-1000,-1000,-1000,381,-621,1000,417,1000,-601,-614,-1000,1000,268,615,154,-1000,-665,-42}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00291() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteCharAt(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{293,-819,129,810,-1000,272,1000,522,179,489,400,-542,1000,1000,410,-400,1000,210,-400,-1000,577,98,726,-1000,195,1000,398,-1000,-830,-1000,-43,-400,1000,1000,552,-1000,-677,836,-567,1000,97,-682,1000,-1000,-400,582,554,400,1000,415,426,510,944,-1000,807,314,934,-400,0,-381,-421,98,403,766}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00292() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteCharAt(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-422,901,-853,790,-592,527,-208,-591,-158,638,-707,-658,161,483,53,187,465,244,-540,20,497,-914,-118,-48,276,479,-262,130,-637,-893,-401,620,639,923,-749,-964,-101,-79,955,941,289,79,764,-935,594,582,-303,-786,776,892,-206,380,774,-434,652,-5,-444,788,-100,542,690,-488,260,812}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00293() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteCharAt(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-976,-400,-1000,466,467,61,-331,-724,-1000,-1000,-1000,359,-833,-486,-1000,1000,-363,-101,144,1000,-1000,-1000,-1000,1000,-1000,-1000,-976,-708,-154,1000,-292,1000,-1000,-532,-1000,970,-360,-1000,1000,-1000,90,85,195,-955,1000,-233,-888,-1000,1000,-758,1000,-29,-152,879,206,375,864,1000,1000,-1000,403,-404,-144,-458}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00294() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteCharAt(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-706,-1000,-1000,-362,-499,346,-121,149,-632,548,-1000,-1000,708,638,-610,1000,320,739,1000,-31,224,-688,-106,202,-312,522,-181,-550,-349,-925,-760,1000,706,882,-848,-721,-712,-564,568,959,117,-294,1000,-955,1000,289,-846,-1000,843,546,600,156,-84,-1000,499,448,858,1000,630,-321,979,98,-60,812}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00295() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteCharAt(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{140,-1000,-1000,-1000,1000,-1000,-331,506,-1000,-827,-1000,719,-1000,106,-1000,1000,-1000,1000,1000,531,-858,883,-121,-672,-1000,-1000,-955,294,1000,1000,-120,1000,-1000,-687,-1000,1000,646,-1000,1000,-1000,-1000,691,-898,380,1000,-233,-1000,-1000,-152,-1000,1000,-699,-1000,1000,1000,-62,1000,666,1000,621,-1000,1000,-819,-440}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00296() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteCharAt(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-633,353,-607,-382,628,-461,-307,13,921,-1000,-711,1000,-635,-523,-730,1000,-282,367,963,1000,-806,-517,1000,-1000,-1000,-1000,-700,-108,-531,175,-100,181,-318,-1000,-839,1000,392,-1000,1000,-1000,-409,12,260,355,-326,-1000,-684,-1000,-791,-538,-471,176,-801,975,-5,617,-715,241,1000,-978,1000,-368,65,50}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00297() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteCharAt(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{778,535,400,206,568,-119,1000,873,464,589,400,-209,335,674,517,-400,167,21,-846,632,70,-615,283,-310,101,271,-103,-225,-24,-893,957,-400,659,928,400,-1000,574,1000,-163,941,193,581,215,-890,-346,-1000,322,1000,1000,897,-400,543,1000,1000,-688,-1000,-1000,-400,862,1000,-410,735,391,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00298() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteCharAt(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{554,-1000,-864,226,672,-253,-844,-743,-757,197,-809,-400,-1000,255,-708,1000,-1000,310,235,434,14,27,-523,404,-651,-620,-1000,227,577,338,-594,713,-999,310,-808,-178,289,-613,1000,80,-804,854,-382,-633,827,-445,-967,-967,-1000,-1000,1000,-164,-1000,733,1000,-117,750,711,1000,1000,-596,534,-63,-183}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00299() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteFirst(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{887,-1000,1000,-247,1000,439,473,1000,87,592,167,304,409,1000,-528,-1000,-1000,-1000,276,-1000,-487,935,-683,-515,-1000,1000,-1000,353,310,1000,889,-1000,-1000,-497,-1000,-589,-1000,-850,474,-294,540,1000,-1000,441,-634,-797,-641,-1000,1000,-1000,-1000,1000,-134,1000,1000,-1000,-1000,87,1000,1000,-1000,-529,1000,376}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00300() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteFirst(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{154,-39,964,-744,-954,409,906,766,-964,-166,-565,597,-725,371,194,-996,-344,-724,-634,-586,386,920,518,574,750,-274,-147,77,-839,-712,-494,350,296,-111,-200,-47,492,-338,-782,-181,-606,-326,-746,-65,320,417,294,889,-190,342,190,686,374,366,-714,299,-406,-385,343,-497,-581,-960,989,-231}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00301() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteFirst(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-1000,-819,12,-27,536,496,-483,798,233,178,438,-373,-237,-487,1000,-48,-393,351,-1000,1000,830,-934,-65,663,57,1000,-895,257,-44,521,-948,-1000,141,942,238,-1000,-870,230,415,-743,1000,1000,-856,-970,710,489,97,272,439,335,-465,294,277,-1000,1000,1000,606,888,64,-393,-1000,556,-310}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00302() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteFirst(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{779,-512,28,928,-306,627,370,645,577,-615,-96,810,-596,113,347,517,739,-61,-757,-1000,802,119,-980,-338,85,52,791,-1000,-84,-990,477,-138,247,473,823,-125,-1000,-43,-611,-136,-382,618,587,-805,-786,529,265,106,266,205,690,-788,-1000,-787,-664,783,1000,970,764,-919,-460,-1000,1000,307}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00303() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteFirst(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{119,32,1000,158,-199,1000,-347,-423,715,-971,-152,-206,-323,633,-1000,-210,14,714,-692,-637,784,-1000,-866,-554,-497,1000,-599,-1000,1000,-1000,233,-1000,-240,957,153,-62,239,28,-1000,1000,843,88,1000,-47,-1000,871,-715,1000,-304,867,-300,18,-981,-133,-178,804,843,960,-183,-831,777,1000,451,-494}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00304() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteFirst(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-852,-667,-1000,-842,-795,329,104,876,856,240,1000,582,380,-656,-961,731,271,-755,1000,134,-604,1000,-302,-577,203,-509,791,770,213,169,883,460,-600,-400,-419,40,-5,-1000,581,-792,-288,-480,585,-1000,-349,-142,1000,-562,615,-271,270,-1000,399,-348,224,-556,146,592,-161,655,391,-554,849,-474}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00305() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteFirst(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{481,-1000,400,-953,1000,488,817,464,87,592,972,118,649,882,-528,-794,-400,-1000,265,-268,-1000,440,-890,317,-1000,1000,-1000,188,129,900,359,-418,-26,94,-1000,-460,-1000,-184,511,-986,41,724,-321,327,18,109,-566,-25,147,-44,-142,400,-615,165,841,-631,-1000,289,626,1000,-304,-1000,986,376}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00306() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteFirst(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-964,-1000,605,706,1000,-891,-106,1000,216,1000,385,-1000,-14,-784,331,-257,59,224,-1000,761,1000,-1000,-178,-1000,904,-149,-423,1000,-951,758,-1000,-462,-440,-352,141,-1000,-637,-493,-463,173,762,293,-289,-930,-112,-410,-639,1000,-120,-673,212,-288,351,-214,171,-105,559,265,16,-795,-548,333,443}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00307() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteFirst(char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-173,-1000,-451,-67,367,1000,-911,-821,372,-182,-947,-205,2,1000,-1000,-488,-951,-480,525,-1000,420,-1000,-648,-748,-772,811,-1000,1000,749,-391,263,-1000,-974,1000,-870,554,-509,-678,323,123,100,87,907,4,-625,-391,-401,-927,1000,310,-400,1000,296,585,461,-294,-1000,-997,-684,234,1000,39,-287,-30}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00308() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteFirst(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-1000,1000,1000,583,-798,643,-947,-441,-1000,-622,-81,835,173,721,-574,1000,-1000,925,-1000,338,-1000,-1000,-1000,-1000,-1000,1000,-1000,1000,1000,-518,-1000,1000,-1000,1000,-1000,1000,-109,-1000,-685,1000,1000,-281,-1000,-1000,1000,1000,1000,982,-1000,486,-883,-1000,1000,922,-583,-75,122,-937,-564,1000,1000,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00309() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteFirst(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-1000,1000,1000,-1000,588,369,-638,1000,286,1000,65,-913,105,1000,755,-226,-1000,940,-829,1000,-952,-815,598,593,668,-320,334,1000,843,-87,1000,914,165,557,1000,-1000,529,-1000,1000,1000,-1000,-177,1000,-73,1000,-947,-1000,1000,-1000,901,-492,484,282,-143,-700,-1000,-1000,1000,-949,524,-207,-617,-593}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00310() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteFirst(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-50,-325,1000,787,1000,1000,-239,-386,-160,-619,-358,802,297,640,-1000,-206,-647,-20,1000,-459,-460,1000,582,-544,-786,102,881,867,-49,-1000,-222,-1000,1000,1000,433,-526,-146,1000,1000,-823,-693,260,307,-1000,-83,702,856,814,-1000,301,-788,-803,1000,1000,1000,828,581,-1000,-816,-641,291,-10,-1000,-187}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00311() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteFirst(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-716,-396,-127,391,-517,-73,460,1000,662,806,96,58,-393,-170,-390,326,301,-290,-167,-237,950,-552,-337,49,-203,-284,982,285,741,0,-122,-405,419,-43,938,-114,-1000,310,570,327,475,-738,568,942,674,618,-305,376,1000,-899,1000,-1000,-559,-582,-390,-960,475,-783,1000,-596,-273,-111,-1000,-913}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00312() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteFirst(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{642,275,301,-490,-835,1000,-314,-51,232,39,94,-102,192,341,256,389,804,158,388,-1000,-1000,-689,-1000,-877,-1000,-617,1000,-76,-580,193,-863,112,258,-177,563,194,-1000,-738,888,534,528,-44,-126,97,270,-602,251,-497,223,-1000,106,-594,339,1000,-171,-919,1000,-990,796,243,1000,-298,344,-971}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00313() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteFirst(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{476,325,-400,1000,254,-269,-234,236,-1000,-1000,-622,1000,-1000,1000,-896,-873,900,-794,997,-14,-1000,1000,251,-137,1000,-1000,-1000,240,-400,469,913,-688,-400,-513,-1000,-1000,1000,132,579,-876,66,891,-177,44,266,325,189,1000,-1000,-1000,486,-883,-350,1000,206,1000,-75,667,-1000,-349,375,-217,-1000,400}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00314() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteFirst(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-265,41,-1000,189,-600,144,-681,998,-657,385,1000,207,1000,183,109,338,581,-1000,-164,52,222,-63,-234,-111,-610,33,-976,1000,-452,-1000,343,-82,183,974,847,1000,577,465,442,1000,928,40,-805,794,-694,-676,70,384,681,-401,-1000,821,1000,-542,480,1000,780,1000,1000,-565,-510,1000,-320}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00315() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteFirst(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,893,400,-170,-1000,-252,596,-338,1000,956,876,-1000,148,246,-896,541,355,46,-1000,1000,158,-1000,251,-431,-375,1000,-257,-217,400,-506,-583,954,-1000,-874,1000,549,-1000,-71,-573,-876,1000,-1000,-177,220,-1000,-526,189,-1000,1000,-144,-34,-31,-350,579,-1000,-898,-75,-437,12,-598,-80,394,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00316() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteFirst(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{382,-1000,530,-117,-38,111,1,1000,-83,-271,-590,127,-813,1000,290,-139,-1000,855,400,-300,431,803,695,-884,593,809,329,805,1000,-11,1000,-102,687,-1000,-302,-135,-291,221,-23,-400,417,-1000,1000,-580,-458,400,1000,884,-516,629,-1000,-274,-1000,427,1000,1000,147,718,-222,-290,410,1000,-551,193}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00317() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteFirst(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-1000,1000,667,-797,87,954,-393,726,-359,-382,-84,-918,969,949,998,-90,-4,1000,-1000,202,-608,-685,68,-528,-864,1000,22,1000,1000,-1000,1000,1000,1000,1000,-132,123,-1000,-67,630,660,225,1000,124,-415,761,788,272,391,-1000,501,-1000,-1000,1000,640,-788,1000,-1000,440,-418,956,220,-1000,-419}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00318() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteFirst(org.apache.commons.lang.text.StrMatcher):org.apache.commons.lang.text.StrBuilder",
            new int[]{7,-508,190,-385,153,728,-658,-583,-1000,89,-18,44,-361,-626,-1000,-50,-303,-585,369,1000,400,-148,186,1000,164,853,274,-1000,-370,-578,762,-1000,-805,542,-169,-1000,594,-1000,-1000,1000,1000,-1000,425,75,414,-479,221,-394,-66,550,-221,-125,-978,496,275,-579,242,1000,-666,-411,400,-953,-825,72}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00319() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteFirst(org.apache.commons.lang.text.StrMatcher):org.apache.commons.lang.text.StrBuilder",
            new int[]{-208,-609,-476,601,-243,877,-1000,253,-114,669,47,-1000,-64,-817,-328,936,-78,-331,904,-1000,-1000,-757,-1000,37,1000,521,560,-423,-148,-174,-1000,-1000,1000,1000,-471,463,-36,-1000,-983,1000,-60,-764,-1000,-166,-1000,-734,1000,673,523,786,-982,-840,651,-544,-742,914,-1000,522,-55,-153,-1000,916,-301,-394}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00320() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteFirst(org.apache.commons.lang.text.StrMatcher):org.apache.commons.lang.text.StrBuilder",
            new int[]{40,-508,1000,-1000,-779,-401,-792,-494,-1000,-791,-197,-286,-128,-533,-917,-299,-321,1000,225,767,1000,1000,727,1000,-1000,-823,-966,-1000,1000,119,-258,17,-512,-1000,1000,-1000,-372,-703,-574,368,1000,256,345,-1000,919,1000,115,540,78,451,250,60,-898,-1000,1000,147,872,1000,42,-947,699,-1000,-634,400}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00321() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteFirst(org.apache.commons.lang.text.StrMatcher):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-1000,-447,-50,34,373,182,-461,-30,-134,267,-625,-1000,-559,200,509,-191,1000,367,1000,-1000,-1000,435,-807,1000,-875,717,731,-1000,1000,-1000,-1000,228,1000,760,860,-474,-587,-525,694,361,1000,-745,-574,-1000,179,1000,-1000,-217,32,-1000,278,1000,-1000,-850,768,-1000,1000,-1000,-1000,-599,845,-818,480}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00322() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteFirst(org.apache.commons.lang.text.StrMatcher):org.apache.commons.lang.text.StrBuilder",
            new int[]{528,-917,-1000,1000,424,1000,-205,-494,1000,-191,1000,-641,-735,1000,503,-167,-329,24,214,-182,-565,-1000,543,-1000,1000,-487,299,1000,-532,1000,-534,606,-149,415,79,1000,-1000,647,-885,122,-1000,278,-237,-8,-564,-107,75,-942,-365,-1000,400,1000,-898,168,-1000,896,70,-158,-131,320,1000,1000,-44,480}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00323() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteFirst(org.apache.commons.lang.text.StrMatcher):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-1000,-171,455,-414,596,469,-18,-753,-294,930,-808,-566,-1000,266,543,-805,303,1000,1000,-633,22,150,45,-817,1000,1000,-234,-852,-538,-707,-206,1000,240,170,-588,-507,-1000,-278,-342,1000,-388,-1000,-114,-1000,1000,202,1000,-6,879,-858,101,433,-225,137,-580,-443,1000,-687,-1000,-1000,-801,-719,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00324() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "deleteFirst(org.apache.commons.lang.text.StrMatcher):org.apache.commons.lang.text.StrBuilder",
            new int[]{-350,-409,288,-314,-41,524,179,1000,-27,-960,462,133,1000,1000,-484,-3,-78,-238,-4,-1000,1000,1000,148,517,82,239,475,-240,943,-142,1000,1000,-1000,-1000,853,-1000,-433,1000,-912,-691,242,211,1000,-146,1000,1000,-1000,-400,-818,-520,1000,1000,-885,86,545,914,1000,-365,669,983,1000,-690,791,-21}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00325() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "endsWith(java.lang.String):boolean",
            new int[]{-733,-364,1000,-1000,1000,-1000,287,-383,146,335,796,-735,-314,1000,-1000,461,-1000,-328,206,1000,664,935,1000,512,47,-698,1000,-827,-414,172,422,1000,1000,-953,511,-1000,-703,115,1000,-1000,737,954,1000,-533,680,764,62,-376,-1000,1000,257,-510,1000,-219,98,-1000,608,-627,-170,-1000,-123,445,-546,-680}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00326() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "endsWith(java.lang.String):boolean",
            new int[]{1000,-219,504,-895,487,447,-776,672,1000,79,-491,418,-722,436,-535,1000,644,219,514,1000,400,-843,-276,1000,230,-874,-178,-1000,403,1000,-967,-461,-80,418,-1000,512,163,-388,1000,-595,-301,-121,1000,-520,-674,529,624,-165,20,156,-1000,-799,786,1000,-1000,-920,-432,778,224,-1000,-290,423,881,-115}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00327() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "endsWith(java.lang.String):boolean",
            new int[]{-1000,-970,1000,-1000,261,-1000,742,-11,-1000,171,510,-1000,158,1000,-1000,1000,-1000,1000,588,1000,-1000,1000,964,1000,-1000,-1000,1000,-1000,27,-487,-1000,1000,-1000,-1000,1000,-1000,-1000,607,1000,-1000,738,1000,940,-145,72,1000,-1000,-152,-1000,1000,-985,1000,1000,-784,-1000,-1000,520,-265,-1000,130,-1000,1000,-1000,-305}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00328() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "endsWith(java.lang.String):boolean",
            new int[]{-283,301,-793,180,-156,-84,91,-1000,303,752,-660,-35,500,371,772,-241,-1000,749,472,1000,1000,659,-184,890,779,365,-994,514,202,-398,1000,-603,-941,-56,-892,-464,-649,-346,-1000,113,-118,-894,877,-1000,-172,26,236,-120,-770,-165,299,-191,-815,416,729,395,-60,-723,1000,-279,-322,-354,-990,-192}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00329() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "endsWith(java.lang.String):boolean",
            new int[]{-226,-292,805,-704,1000,1000,168,-221,353,416,192,-933,268,840,498,199,-661,1000,1000,909,216,1000,-458,1000,230,1000,312,-1000,1000,-219,62,534,1000,-923,324,-1000,-912,-455,628,-904,1000,1000,473,-333,-36,1000,-1000,385,-1000,898,-57,-444,1000,495,-1000,-1000,301,-151,562,-964,-653,400,-849,760}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00330() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "endsWith(java.lang.String):boolean",
            new int[]{-110,215,-583,-161,47,-650,-396,733,6,-1000,833,-14,-356,-871,726,-625,-292,51,-1000,426,1000,-39,-1000,-203,564,-725,-821,-1000,-497,228,875,-446,-519,1000,-619,112,-575,-533,-1000,-229,1000,-767,645,293,955,361,215,-681,-169,-1000,-242,-1000,-392,-1000,1000,1000,317,-432,930,-1000,750,-913,-273,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00331() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "endsWith(java.lang.String):boolean",
            new int[]{805,-502,690,-36,879,82,634,-368,842,1000,-6,236,18,346,-106,535,-383,-445,700,81,1000,1000,817,-528,793,-95,-673,573,-269,955,1000,-1000,-1000,744,-805,-1000,-73,-766,-707,167,-1000,-909,-10,-17,220,-142,1000,358,-562,-382,-594,-1000,-644,1000,1000,898,520,189,1000,-282,220,-14,595,334}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00332() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "endsWith(java.lang.String):boolean",
            new int[]{-77,866,783,686,-361,1000,509,-32,-1000,-522,-429,-400,582,-231,647,212,-807,678,390,264,-814,1000,450,372,221,1000,172,101,-919,-848,-913,-209,-367,174,995,-1000,-648,-194,7,-377,-140,-88,10,829,70,647,-144,-54,-693,33,1000,1000,-151,-336,896,329,-742,250,-395,1000,-90,977,-309,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00333() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "endsWith(java.lang.String):boolean",
            new int[]{1000,-82,-537,400,-1000,343,-381,-564,-782,72,-254,1000,851,385,-628,118,-448,-70,111,520,-347,-185,274,-575,186,-489,711,261,376,69,1000,-781,-1000,-366,-837,1000,512,-708,-1000,316,-1000,-1000,86,-924,-1000,951,1000,1000,223,1000,-918,746,-1000,1000,635,1000,1000,777,227,846,-654,-1000,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00334() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "endsWith(java.lang.String):boolean",
            new int[]{104,749,784,-241,584,-709,-103,-806,235,-403,-137,-229,258,-404,417,996,107,-995,-539,-720,918,-727,-919,68,648,149,-60,686,-162,23,-73,98,-429,-348,-671,-736,-124,-60,295,866,-367,20,918,-230,-179,44,-151,-174,887,-190,58,298,-69,-348,64,603,447,-168,-205,839,424,-874,45,98}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00335() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "ensureCapacity(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-453,-1000,507,630,73,970,312,287,-649,-1000,-288,909,-674,-671,-650,-1000,-973,-914,-1000,705,-103,927,-975,-693,394,-1000,1000,-1000,1000,1000,28,-1000,-669,-103,-1000,-549,25,-228,-610,-930,-1000,1000,350,243,-699,-468,-901,-147,-153,-69,965,-645,991,16,1000,1000,146,157,436,793,-1000,-613,651,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00336() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "ensureCapacity(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-564,294,744,560,-361,-240,-400,308,-884,398,785,909,379,648,964,-421,899,132,678,39,252,63,-124,-693,403,260,-985,230,929,-865,28,756,-669,293,810,512,-490,-228,-180,918,904,-648,-99,750,881,-142,484,850,-479,-69,965,-510,-878,350,-761,-172,448,-334,114,793,59,-363,675,815}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00337() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "ensureCapacity(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-667,323,543,580,-902,1000,-996,-138,-152,1000,-639,-906,253,977,554,-343,787,969,-552,637,1000,140,102,1000,1000,-1000,-469,-773,1000,1000,393,-1000,-124,491,592,695,-715,345,-1000,-327,-610,1000,215,418,-392,57,756,1000,-283,253,-1000,-974,613,578,-425,-31,987,570,132,-1000,-1000,-176,410,563}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00338() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "ensureCapacity(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-824,730,427,-703,159,-1000,-1000,-373,16,-300,-537,-25,-360,249,-1000,-922,759,-20,155,91,-200,1000,-1000,1000,29,821,556,1000,-1000,857,-262,167,705,1000,-158,-1000,-239,70,-711,504,-770,-133,1000,187,-333,-575,-912,-262,362,998,-210,-1000,1000,-390,969,1000,7,1000,-14,715,130,-1000,860,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00339() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "ensureCapacity(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-542,242,543,-1000,-109,979,-416,-215,733,398,-476,766,-351,294,122,-528,174,-7,504,-99,1000,385,-677,-636,-190,566,128,330,-471,-865,-20,355,-563,240,408,-116,-71,162,-727,940,-725,-520,100,516,527,-1000,808,94,-401,1000,-119,-574,12,-644,184,311,-1000,1000,1000,1000,-290,-452,587,885}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00340() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "ensureCapacity(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-666,155,1000,580,-177,552,-3,-138,-1000,-1000,-666,909,726,-235,-650,-1000,-815,-866,-485,-552,426,428,-703,-908,1000,-881,1000,-705,1000,1000,104,-1000,-556,-23,592,-549,-525,-333,-623,-1000,-610,1000,585,842,-650,-424,-375,-147,-860,503,965,-164,991,842,-400,1000,204,214,431,-1000,-713,62,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00341() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "ensureCapacity(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-1000,1000,1000,-824,1000,-681,898,-392,-1000,-855,-1000,43,400,221,-973,522,-1000,-359,251,1000,525,-436,479,1000,-1000,-195,-43,1000,1000,-819,-78,386,983,-1000,-173,-1000,64,-1000,-99,-402,817,736,807,376,-874,-684,1000,-238,679,-1000,-963,461,806,-131,1000,970,236,-553,-1000,-1000,-416,761,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00342() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "ensureCapacity(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-280,-649,224,-150,472,-818,441,-295,116,-966,87,-347,-670,-1000,175,535,-356,-726,-1000,140,-282,285,-959,814,336,607,-838,-1000,-1000,346,608,-81,-1000,-283,-186,105,1000,872,1000,1000,663,1000,-604,-924,834,569,-811,-146,-1000,-1000,269,-246,-339,-495,948,-313,-753,-324,838,371,-614,-100,911,-948}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00343() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "equals(java.lang.Object):boolean",
            new int[]{-562,128,70,205,789,140,-991,248,-441,203,1000,-762,-121,-1000,-971,-118,977,-926,-1000,407,1000,737,-1000,-103,-1000,964,-472,301,-794,1000,-17,783,611,-102,1000,-572,-719,130,-968,382,-343,-796,369,-415,184,-503,-1000,-174,-425,1000,-750,489,-218,-984,1000,-1000,100,18,-1000,-844,1000,-954,877,-524}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00344() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "equals(java.lang.Object):boolean",
            new int[]{-1000,696,-11,-506,-1000,-1000,-385,-1000,-23,576,-732,787,-349,585,-89,641,-382,1000,-825,-1000,124,203,744,-862,539,63,-422,-616,-333,-244,-222,360,-1000,-1000,468,-133,-67,1000,-382,-563,-1000,871,-191,1000,425,1000,-96,210,722,1000,180,-1000,115,206,241,-259,68,922,428,1000,393,77,-846,297}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00345() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "equals(java.lang.Object):boolean",
            new int[]{121,779,390,483,243,32,-86,166,1000,511,1000,-511,-996,268,-179,-1000,1000,-733,565,1000,-734,1000,-223,521,966,462,-59,-644,-916,-94,711,167,603,245,527,-901,-1000,-258,-65,1000,547,-1000,138,-450,1000,-1000,726,-580,-291,-950,-1000,306,492,-701,1000,-960,-1000,399,-1000,-1000,1000,-1000,791,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00346() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "equals(java.lang.Object):boolean",
            new int[]{713,-37,-413,-1000,1000,-481,-248,-828,-785,-1000,-189,-271,-1000,-1000,620,882,-1000,-400,-474,-881,1000,-182,-22,-1000,-1000,84,-378,1000,693,1000,-1000,414,-102,-396,52,-306,641,1000,797,-379,-576,671,-274,-427,-1000,172,-117,-572,673,963,516,709,-251,-760,13,-1000,1000,1000,-774,649,643,604,-915,515}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00347() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "equals(java.lang.Object):boolean",
            new int[]{115,-341,-716,-73,-301,27,-895,-1000,-46,1000,-156,-1000,-1000,729,128,-66,1000,-1000,5,408,825,764,538,47,378,1000,-489,-601,1000,1000,1000,170,-49,-669,487,-658,-1000,94,1000,381,-1000,-1000,589,-1000,924,258,-1000,-1000,-1000,1000,-765,-547,-615,-559,594,-519,898,-226,-364,-1000,1000,-1000,-805,-11}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00348() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "equals(java.lang.Object):boolean",
            new int[]{215,-244,-611,-807,-132,-1000,-6,-1000,459,-181,-1000,-1000,-914,172,754,-870,-1000,168,859,756,-1000,645,1000,1000,96,-1000,-925,-389,1000,359,195,909,-750,597,-200,-989,-1000,584,1000,219,-919,-1000,-886,-799,277,18,1000,122,363,-1000,-1000,-136,1000,129,-1000,63,-532,667,383,345,-65,1000,-762,2}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00349() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "equals(java.lang.Object):boolean",
            new int[]{295,-361,848,-316,-1000,-994,-796,-370,-1000,-167,-1000,507,164,123,717,1000,-1000,-156,-1000,-1000,-1000,-871,1000,-1000,-648,291,-20,435,1000,-11,272,1000,-1000,-1000,-257,755,1000,1000,624,-1000,-1000,1000,-50,-919,-498,1000,-332,-362,358,294,267,-1000,-794,1000,-1000,227,961,299,1000,1000,-838,1000,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00350() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "equals(org.apache.commons.lang.text.StrBuilder):boolean",
            new int[]{-497,736,238,-473,123,-198,-704,637,288,-492,-562,-136,-119,-77,-693,363,641,-615,782,-5,1000,-453,825,-348,126,431,366,321,309,1000,-722,-82,536,140,-485,-549,-265,-343,1000,1000,-308,-461,230,-200,1000,-779,511,858,315,216,702,13,804,1000,-971,246,437,89,-431,832,734,1000,73,313}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00351() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "equals(org.apache.commons.lang.text.StrBuilder):boolean",
            new int[]{1000,275,206,284,287,1000,193,-1000,-908,868,-651,-931,388,-462,887,-963,1000,180,-1000,-366,-1000,945,-577,421,-359,-1000,1000,966,-235,-1000,1000,441,191,-246,-895,1000,75,1000,-1000,-1000,1000,-203,1000,-963,-1000,-1000,-1000,1000,-557,362,-1000,-1000,236,-274,-1000,-699,102,1000,-796,185,315,-322,1000,-191}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00352() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "equals(org.apache.commons.lang.text.StrBuilder):boolean",
            new int[]{245,-524,-715,-67,-536,672,549,-913,-159,969,-886,-416,470,312,427,-460,0,9,-773,457,-632,215,-406,704,-878,-821,208,368,139,-853,48,355,-913,-833,1,986,537,938,-750,-712,307,342,-281,-338,-720,300,-649,-293,-242,217,-483,-443,-816,-593,-496,-663,-979,650,-328,-965,-521,-717,621,454}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00353() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "equals(org.apache.commons.lang.text.StrBuilder):boolean",
            new int[]{-1000,-1000,332,-1000,-1000,-1000,-711,1000,1000,-751,-274,-266,470,1000,-1000,-460,656,-1000,1000,-193,1000,215,1000,634,-366,1000,-1000,-1000,1000,-853,48,-209,-292,253,1000,-1000,158,-1000,616,1000,-1000,342,-1000,-338,1000,550,1000,-1000,-242,-1000,1000,1000,1000,1000,1000,1000,-996,125,1000,-466,518,411,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00354() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "equals(org.apache.commons.lang.text.StrBuilder):boolean",
            new int[]{415,215,-21,-68,-515,969,639,-294,822,829,-1000,-856,1000,810,411,10,762,-533,-286,605,-842,354,136,-259,-184,-490,1000,740,1000,-687,-773,215,404,-1000,-1000,1000,-151,1000,24,-500,-951,-17,1000,-713,108,-615,14,1000,82,105,-188,-419,1000,91,-1000,-646,6,553,608,-24,483,964,1000,195}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00355() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "equals(org.apache.commons.lang.text.StrBuilder):boolean",
            new int[]{-775,-1000,133,-804,-1000,-473,124,122,1000,-275,-682,-388,1000,1000,-185,125,736,-1000,651,-320,-120,-1000,1000,236,-167,697,-604,-686,1000,772,-1000,-81,-317,-62,899,-1000,-22,-1000,-784,636,-1000,694,-1000,889,1000,464,830,-1000,-553,-1000,292,498,1000,982,-138,1000,-1000,415,1000,-708,324,-100,-433,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00356() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "equals(org.apache.commons.lang.text.StrBuilder):boolean",
            new int[]{629,529,-812,-368,-651,432,874,-1000,884,1000,-621,-651,193,1000,369,-720,-559,396,-1000,612,-1000,28,-1000,1000,-1000,-1000,629,-89,219,-957,219,1000,-1000,-650,-675,1000,153,1000,-491,351,838,-292,21,-1000,-1000,-657,-855,-497,1000,1000,-683,-332,-1000,-851,-1000,-1000,-1000,650,-1000,-951,-1000,-1000,-360,454}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00357() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "equals(org.apache.commons.lang.text.StrBuilder):boolean",
            new int[]{246,-1000,661,-44,-979,243,864,-601,686,-589,214,598,1000,-742,404,-902,1000,-248,-255,-1000,-1000,765,-1000,-393,1000,964,268,-398,539,-417,-45,-313,-306,1000,416,96,-748,69,-1000,699,-941,1000,-559,479,-49,1000,99,617,-325,-1000,-442,-670,685,-140,-462,526,286,-993,1000,196,484,-351,595,-834}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00358() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "equals(org.apache.commons.lang.text.StrBuilder):boolean",
            new int[]{9,-77,-114,348,-849,-188,398,-509,-1000,-333,585,211,47,-1000,400,-850,94,9,-336,-995,187,52,-561,745,-302,-145,-132,120,-692,-853,841,719,158,1000,-439,-400,-457,-78,21,50,1000,-187,-147,-558,-375,-60,-405,-97,72,358,-209,-19,-283,-364,-496,-156,173,650,-1000,-97,-193,-1000,-357,-437}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00359() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "equals(org.apache.commons.lang.text.StrBuilder):boolean",
            new int[]{507,-1000,-869,-127,-520,792,1000,-1000,884,1000,-1000,-234,614,-365,1000,-633,945,-490,-727,-91,-1000,37,-392,483,-723,-553,629,146,1000,-1000,-279,972,-1000,-1000,-274,963,699,1000,-1000,-1000,-546,700,223,-73,-8,-449,-260,881,-839,-746,-873,-364,-617,-101,-1000,-118,-1000,1000,371,-1000,113,-436,1000,530}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00360() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "equalsIgnoreCase(org.apache.commons.lang.text.StrBuilder):boolean",
            new int[]{59,-940,534,285,1000,-443,404,-1000,-363,1000,239,800,-1000,21,-630,1000,-315,-836,-45,213,180,1000,-412,-1000,1000,1000,-1000,-319,411,-865,93,131,-263,-670,-1000,344,397,20,328,-1000,-470,445,364,1000,-182,-465,388,888,-436,-392,-1000,1000,-185,443,-318,83,-1000,-533,-1000,54,451,161,-400,204}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00361() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "equalsIgnoreCase(org.apache.commons.lang.text.StrBuilder):boolean",
            new int[]{-170,-470,1000,521,729,794,268,-225,1000,455,641,527,995,-1000,519,-45,1000,394,-813,-184,907,446,87,-316,53,-1000,455,1000,-610,-606,563,-109,-444,-373,668,584,-1000,1000,117,1000,77,503,-604,-1000,135,-1000,-832,208,-438,-14,518,-565,-86,-168,264,-362,564,-864,1000,-318,-33,311,1000,351}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00362() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "equalsIgnoreCase(org.apache.commons.lang.text.StrBuilder):boolean",
            new int[]{868,-1000,836,-448,445,-177,-407,-874,316,1000,447,-246,704,755,-573,887,-116,-790,-109,-365,-486,1000,-1000,-680,-467,-1000,-1000,109,-155,-1000,86,936,184,281,-527,-746,-1000,313,-444,-897,961,528,-116,-981,-1000,-798,598,-492,28,608,-1000,-218,-636,-431,-966,-897,-19,161,495,-603,1000,418,-202,-573}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00363() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "equalsIgnoreCase(org.apache.commons.lang.text.StrBuilder):boolean",
            new int[]{685,133,-50,1000,909,107,1000,-314,207,-500,667,1000,-776,-687,175,-1000,1000,1000,-934,809,1000,-313,875,-203,1000,258,-230,1000,491,371,319,-821,-139,-950,705,-271,62,1000,1000,60,-1000,1000,-115,1000,870,-465,-1000,269,-719,-998,1000,-615,602,197,1000,-813,152,-1000,232,391,323,902,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00364() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "equalsIgnoreCase(org.apache.commons.lang.text.StrBuilder):boolean",
            new int[]{-312,-1000,-483,-465,-571,375,343,-609,-18,-529,491,-675,324,-427,-586,-482,-239,-947,-486,739,-39,177,-673,-790,-145,-120,-269,-676,-620,69,-442,6,-897,-373,-488,-351,765,-400,1000,-851,-1000,-525,-487,-1000,-1000,-1000,867,215,260,-677,329,717,-366,-427,-366,429,-970,-1000,1000,-1000,-60,-1000,-1000,451}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00365() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "equalsIgnoreCase(org.apache.commons.lang.text.StrBuilder):boolean",
            new int[]{837,-1000,1000,940,1000,-1000,1000,446,1000,-1000,1000,900,-1000,-438,-416,-1000,993,1000,291,-365,1000,-347,-1000,-90,1000,1000,-718,1000,217,1000,-78,-1000,-1000,-1000,110,1000,-257,1000,1000,666,-1000,1000,-250,1000,1000,311,-1000,-643,-700,707,1000,981,1000,865,1000,-1000,99,-353,-396,621,-240,350,1000,-307}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00366() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "equalsIgnoreCase(org.apache.commons.lang.text.StrBuilder):boolean",
            new int[]{-115,-808,1000,-64,-612,414,234,-684,-1000,769,407,1000,-638,520,-257,567,351,-1000,109,-972,-18,1000,-659,-577,183,-264,-699,951,-565,-514,698,170,1000,-989,-117,602,1000,-226,1000,-584,-64,-427,-74,-105,-780,166,426,450,65,-1000,-828,-867,402,-1000,-1000,-1000,-518,-130,400,-704,1000,1000,-187,-344}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00367() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "equalsIgnoreCase(org.apache.commons.lang.text.StrBuilder):boolean",
            new int[]{43,458,496,383,733,-713,924,446,876,-1000,810,401,-218,-438,-122,-799,274,615,791,1000,465,57,1000,-90,953,1000,-508,930,-551,1000,263,-273,-1000,-445,110,661,-588,1000,533,-80,-316,1000,-260,995,620,311,-341,-320,-40,-662,580,921,1000,276,859,-1000,323,-124,-293,-271,-546,244,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00368() {
        org.junit.Assert.assertEquals("ARRAY:[C:1000:24:java.lang.Character:dA==:24:java.lang.Character:cg==:24:java.lang.Character:dQ==:24:java.lang.Character:ZQ==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getChars(char[]):char[]",
            new int[]{-291,128,43,-153,857,1000,503,-998,1000,323,139,-528,428,-499,-536,-670,-28,1000,457,164,272,1000,508,-469,-384,1000,223,1000,-400,478,-541,400,1000,-90,22,-331,1000,-50,-159,-400,-262,609,-157,-239,547,422,-542,1000,-700,-411,-138,-870,-218,287,-1000,1000,109,-1000,396,242,-804,-940,545,891}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00369() {
        org.junit.Assert.assertEquals("ARRAY:[C:4:24:java.lang.Character:Gw==:24:java.lang.Character:WA==:24:java.lang.Character:Pg==:24:java.lang.Character:SA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getChars(char[]):char[]",
            new int[]{-161,-121,-511,-108,808,174,107,111,-96,392,-1000,-224,388,385,-888,465,-274,822,-262,-285,268,-869,344,574,-824,296,-400,-538,-41,-533,-390,151,-460,-81,575,-795,730,-497,-1000,1000,-879,782,-566,496,1000,642,-125,-408,-654,-488,-1000,-940,337,450,-356,542,-679,-902,-128,-231,-1000,123,-312,931}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00370() {
        org.junit.Assert.assertEquals("ARRAY:[C:2:24:java.lang.Character:Qw==:24:java.lang.Character:aw==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getChars(char[]):char[]",
            new int[]{-716,141,564,-271,701,438,356,-1000,499,26,525,-488,-793,-1000,-228,-1000,-1000,-829,-149,758,-85,-1000,-559,-644,-899,1000,-20,677,-19,17,302,184,672,623,-665,-436,1000,-896,154,-820,-795,651,89,-627,-767,39,-930,1000,-606,-104,608,358,-279,-700,-1000,-653,-224,-368,390,240,-524,721,528,201}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00371() {
        org.junit.Assert.assertEquals("ARRAY:[C:5:24:java.lang.Character:CQ==:24:java.lang.Character:fw==:24:java.lang.Character:cw==:24:java.lang.Character:Xg==:24:java.lang.Character:Zw==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getChars(char[]):char[]",
            new int[]{-497,-43,788,54,-125,-436,736,38,-105,-106,346,973,37,-1000,215,-558,-1000,918,-103,393,-769,-397,-674,103,833,241,-740,-232,-717,896,670,1000,696,992,-438,-491,57,950,573,-857,-177,369,61,-348,988,369,-1000,238,310,-136,366,-669,354,-714,-530,68,1000,-156,159,-741,-76,512,310,-179}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00372() {
        org.junit.Assert.assertEquals("ARRAY:[C:2:24:java.lang.Character:GA==:24:java.lang.Character:aA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getChars(char[]):char[]",
            new int[]{-613,-1000,-45,339,-1000,-43,-323,110,454,-598,-587,6,-1000,-1000,1000,-115,690,-862,-1000,464,-687,1000,129,-1000,968,-1000,-132,1000,-55,103,496,945,-542,-465,899,1000,-721,978,-855,-1000,861,-887,30,-751,865,-1000,939,-250,1000,-608,769,-1000,861,-1000,316,-191,-680,851,342,938,923,971,216,865}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00373() {
        org.junit.Assert.assertEquals("ARRAY:[C:66:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getChars(char[]):char[]",
            new int[]{-1000,-644,388,-207,-781,530,1000,-858,666,-794,609,601,-391,-831,1000,-912,-108,830,-126,1000,-994,724,-270,-1000,991,1000,528,1000,-1000,167,826,1000,194,1000,297,1000,344,-349,-899,-1000,1000,96,709,-595,-1000,103,141,-106,670,-878,1000,-1000,-740,-1000,-456,1000,1000,-275,836,57,505,54,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00374() {
        org.junit.Assert.assertEquals("ARRAY:[C:1:24:java.lang.Character:GA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getChars(char[]):char[]",
            new int[]{-540,-1000,-224,1000,-1000,-237,330,-734,540,-967,843,792,35,-1000,937,-1000,492,-431,190,499,-488,908,-781,-1000,1000,948,358,780,-161,306,1000,42,504,1000,64,1000,-811,596,-319,-1000,1000,-387,287,248,-322,-150,199,891,1000,-610,1000,-830,-732,-622,-104,846,1000,-299,370,360,512,168,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00375() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getChars(int,int,char[],int):void",
            new int[]{201,971,471,1000,105,-161,-855,-423,-322,142,624,-357,-294,863,11,-579,349,-465,-65,667,-321,-679,-436,454,-660,-153,-586,-375,-911,-902,808,616,473,-7,441,-869,989,-547,673,-93,1000,-171,90,-455,-376,-450,433,408,-737,549,-614,-46,-891,418,13,601,-216,357,1000,-382,-542,632,-928,689}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00376() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getChars(int,int,char[],int):void",
            new int[]{-262,225,706,387,281,647,-33,-811,796,-1000,983,-105,7,1000,59,-58,-400,-608,-1000,1000,274,-1000,714,871,200,650,483,-272,-1000,-357,296,1000,-229,-400,591,-1000,645,-69,-980,1000,941,858,551,35,214,763,384,-598,-502,736,-44,62,-912,493,-285,1000,-726,442,-774,543,1000,11,-36,219}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00377() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getChars(int,int,char[],int):void",
            new int[]{151,-220,783,-316,710,-74,868,-507,-462,106,-755,-930,404,81,-680,-211,802,-735,-527,448,443,-117,-706,174,400,98,117,14,200,854,173,-1000,436,230,852,339,263,-587,393,-169,131,-575,336,-284,-263,-1000,543,757,758,504,-481,601,-39,908,-24,469,-115,-890,-928,-82,-340,-385,-75,-320}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00378() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getChars(int,int,char[],int):void",
            new int[]{217,1000,1000,691,941,-223,-1000,-575,1000,-1000,406,102,188,1000,1000,556,-312,247,-1000,1000,440,-1000,751,115,-1000,1000,-1000,692,-1000,-1000,153,-1000,574,-1000,1000,-1000,949,-1000,-333,103,1000,523,1000,-556,-178,-122,481,-271,-1000,771,-1000,214,-1000,1000,-885,241,1000,357,164,-1000,858,1000,-836,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00379() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getChars(int,int,char[],int):void",
            new int[]{-509,-1000,641,-481,-87,-492,-699,378,-1000,-481,-274,-592,173,355,-1000,-1000,1000,-1000,-755,1000,31,-47,-253,820,1000,-1000,1000,-1000,-1000,1000,40,-1000,583,1000,214,1000,-27,-1000,-1000,1000,376,-876,-144,-195,1000,-55,787,-759,-1000,1000,333,-1000,-1000,397,1000,-139,-339,-1000,-1000,1000,-615,860,1000,-666}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00380() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getChars(int,int,char[],int):void",
            new int[]{403,-1000,-363,-803,-55,305,-451,292,-789,373,-733,-1000,579,-1000,-527,-247,1000,-542,819,439,-86,260,-1000,-520,754,-167,1000,-208,1000,454,192,-874,746,784,-1000,1000,-383,-148,-193,-504,-738,-562,-224,-197,-883,-580,595,1000,357,305,227,-519,376,-99,963,553,-585,322,-1000,619,133,-1000,-221,186}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00381() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getChars(int,int,char[],int):void",
            new int[]{554,-463,-1000,593,324,51,-456,863,-586,70,-280,-920,312,-1000,-453,-114,-400,-252,819,177,-125,260,-535,-552,-37,-423,810,-344,212,516,123,45,314,893,-1000,698,669,-832,-187,-14,-1000,359,-586,-256,-1000,313,345,778,442,-148,739,-497,554,-1000,733,665,-615,1000,147,619,133,-1000,-1000,234}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00382() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getChars(int,int,char[],int):void",
            new int[]{179,713,-224,297,371,571,-508,-265,889,-417,661,642,-513,183,175,169,-927,-600,-575,940,342,-884,658,-345,-926,126,533,-408,-969,-85,690,626,92,-419,-979,-692,834,127,-937,746,-889,459,397,-442,-659,881,298,-996,-801,585,-14,-436,-791,-267,-189,673,305,64,415,117,898,661,-461,681}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00383() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getChars(int,int,char[],int):void",
            new int[]{201,-1000,471,1000,105,-407,-1000,-75,-691,400,1000,-343,-539,68,-478,-1000,349,-465,532,896,-203,-509,-436,57,-254,-374,905,-833,733,-147,836,-468,888,325,45,-218,-616,-917,673,-400,743,-1000,91,-456,-376,-736,-169,1000,-65,360,-614,-59,-699,484,383,781,-892,-44,-774,-382,410,-769,-952,689}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00384() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getChars(int,int,char[],int):void",
            new int[]{-8,-1000,-60,370,-1000,-600,-563,-473,1000,690,-1000,-748,399,777,835,-221,-62,-1000,-1000,-1000,-957,770,697,21,-191,848,-1000,156,-382,-366,-1000,1000,1000,-1000,885,-322,-1000,-1000,765,-1000,925,-8,72,1000,-621,-672,185,-322,1000,-362,458,144,-896,-109,-939,-1000,1000,-1000,-318,-676,-793,1000,480,474}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00385() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getNewLineText():java.lang.String",
            new int[]{99,-1000,-121,625,166,584,-738,84,406,-236,181,-426,-914,-340,-8,-391,-1000,-592,385,-1000,-539,458,-62,546,-1000,-1000,-600,585,58,944,815,426,-118,-413,-155,-89,-212,622,-1000,382,-332,-876,938,-285,125,466,-259,177,-336,460,-490,-592,-85,1000,1000,-534,-473,-956,20,-356,785,178,-703,913}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00386() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getNewLineText():java.lang.String",
            new int[]{240,-168,29,316,494,31,200,326,640,-319,-927,-1000,117,244,899,-59,695,-1000,273,155,-114,1000,559,-1000,-111,-427,-1000,-916,1000,268,806,728,1000,-700,-574,1000,-1000,883,-945,361,422,-1000,-134,470,1000,-37,-440,831,-10,226,173,375,-258,574,-1000,1000,71,-847,-116,-559,548,-664,-981,212}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00387() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getNewLineText():java.lang.String",
            new int[]{-648,-74,-954,45,829,-153,971,-714,-939,333,200,-485,-46,1000,-270,143,1000,57,699,1000,832,211,62,-558,-166,427,-978,-453,-623,-502,258,1000,291,97,53,970,-482,1000,-1000,1000,312,-193,-602,1000,375,-890,463,-593,-450,12,-55,649,480,188,-752,1000,533,-1000,-39,1000,-500,1000,-980,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00388() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getNewLineText():java.lang.String",
            new int[]{-566,-1000,565,157,555,693,653,-634,1000,-180,744,-506,-91,757,854,-570,-416,-800,1000,-816,197,801,-545,427,-567,-646,-332,247,722,564,1000,533,624,299,-518,-146,-1000,974,-1000,120,-129,-631,154,546,611,391,-285,1000,-637,109,562,-255,-63,79,-1000,1000,490,-327,-258,89,169,139,-989,-310}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00389() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getNewLineText():java.lang.String",
            new int[]{-842,-1000,574,575,1000,1000,-407,-781,-1,574,482,1000,512,365,-447,141,677,-1000,-346,-1000,874,1000,-942,415,-1000,-1000,-651,-335,234,775,1000,400,313,-1000,-161,785,566,1000,-1000,1000,-448,-1000,1000,1000,243,24,-733,18,-205,-831,-1000,-794,-818,-316,1000,468,-165,-1000,-1000,413,740,274,-1000,-688}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00390() {
        org.junit.Assert.assertEquals("java.lang.String:LS0weDgwMA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getNewLineText():java.lang.String",
            new int[]{-224,-547,191,348,-52,-318,-708,-953,183,-743,-573,-826,-472,649,-87,616,320,-781,142,-28,-418,-900,-906,290,-852,648,-205,507,468,145,158,118,-424,834,-405,-282,604,686,-929,-29,374,314,860,273,132,365,-842,-48,-750,-574,-79,-837,-109,956,-171,-173,-983,-891,107,936,887,442,-915,-671}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00391() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getNewLineText():java.lang.String",
            new int[]{209,-1000,208,-118,-208,184,92,148,1000,-1000,59,-1000,-1000,-311,1000,-513,-614,-1000,1000,-944,-1000,1000,-343,399,-645,533,-175,-217,1000,1000,732,679,105,161,-1000,-278,-1000,1000,-124,-211,396,206,-421,-491,1000,1000,388,1000,-1000,-450,1000,-464,-867,1000,-997,-262,97,216,149,-400,857,-246,-1000,411}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00392() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getNullText():java.lang.String",
            new int[]{313,-1000,-1000,559,-156,624,779,-168,296,899,916,955,68,-40,-680,97,28,244,-563,164,-126,932,-181,-727,-709,1000,-1000,-804,-375,945,834,1000,-1000,-379,-590,190,817,-1000,-541,169,817,-203,-502,714,324,34,-1000,340,1000,-764,-75,-659,654,-1000,279,-790,-305,422,-944,-857,853,-998,-489,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00393() {
        org.junit.Assert.assertEquals("java.lang.String:LS0weDgwMDAwMDAwMDAwMDAwMDAw", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getNullText():java.lang.String",
            new int[]{-12,-708,-296,1000,-999,-854,-82,-1000,494,1000,128,103,-124,198,-168,239,269,14,977,52,-84,758,70,-1000,-1000,679,-859,-765,-447,48,601,254,-92,-822,327,339,-1000,172,-403,-1000,719,835,-477,414,355,422,519,-1000,297,-327,-69,-618,1000,-1000,1000,271,473,-33,301,364,1000,-644,905,636}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00394() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getNullText():java.lang.String",
            new int[]{1000,-478,-1000,227,-151,602,-206,992,1000,624,409,913,-876,-1000,-129,-580,275,983,882,-18,-631,404,-135,-814,-516,1000,-1000,-1000,772,1000,224,1000,-1000,1000,256,-646,71,-1000,-1000,1000,-189,105,-550,804,681,-1000,-915,1000,1000,-1000,276,-382,267,289,-1000,-1000,-288,-422,-894,-716,566,-615,211,-973}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00395() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getNullText():java.lang.String",
            new int[]{1000,830,-766,-164,-508,624,-796,400,-244,-241,916,-424,504,-1000,-103,97,1000,400,1000,-63,-714,932,370,760,-579,680,519,-1000,359,368,271,696,-459,-507,318,-905,-1000,-240,177,927,392,-203,-1000,-227,1000,-1000,417,340,-860,445,191,-643,-681,273,-1000,-737,-71,-581,-320,670,403,-1000,551,899}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00396() {
        org.junit.Assert.assertEquals("java.lang.String:KzB4ODAwMDAwMDAwMA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getNullText():java.lang.String",
            new int[]{1000,-268,60,-586,-498,-1000,718,-96,1000,447,42,109,305,-828,-399,-420,32,231,-1000,-707,-383,367,551,65,-1000,-104,527,47,291,686,-1000,587,-276,807,-1000,915,-826,186,37,232,641,252,918,532,397,737,-258,-294,332,248,947,-480,305,-483,351,-311,-955,366,117,-1000,1000,-523,813,247}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00397() {
        org.junit.Assert.assertEquals("java.lang.String:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getNullText():java.lang.String",
            new int[]{-1000,-188,494,1000,337,-886,283,-461,1000,170,-808,207,47,956,-411,-334,303,-51,-1000,-100,-148,135,254,-512,-956,644,-383,-305,-1000,688,1000,1000,-508,-1000,-176,-98,-529,-435,-220,-949,1000,198,-167,833,553,481,-514,-950,1000,1000,224,-594,1000,-1000,1000,419,-209,298,-30,-354,622,-1000,17,-225}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00398() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "getNullText():java.lang.String",
            new int[]{-555,-1000,-368,1000,803,127,502,182,-675,1000,-641,1000,174,1000,379,291,-586,213,-1000,-112,292,1000,-1000,-1000,-796,542,-1000,-444,-1000,1000,1000,1000,73,-414,-326,-688,272,-553,-776,-1000,875,336,162,910,280,335,-60,37,1000,-1000,644,-383,1000,-427,863,-207,-83,760,-1000,-1000,1000,-171,-65,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00399() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(char):int",
            new int[]{638,170,-817,721,736,-949,-579,-606,5,-100,87,-201,-223,-253,688,310,189,-952,376,639,61,977,220,-76,-367,-220,-291,484,-737,942,999,-221,37,523,478,-921,-124,952,999,-253,-758,-184,-207,637,-185,744,517,-890,-377,-669,-855,-581,-985,257,484,-171,-384,242,989,-296,903,-741,242,45}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00400() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(char):int",
            new int[]{-1000,-408,-476,-890,-717,992,-579,1000,-336,179,1000,1000,-243,868,636,314,-501,-586,-237,-377,-1000,1000,-844,-191,961,571,-1000,237,1000,-481,1000,-604,-304,-1000,178,-554,-1000,445,407,-389,554,-243,943,-376,-1000,-510,-761,-652,-94,-598,-408,-945,110,1000,-1000,1000,655,-1000,-260,-1000,1000,-169,15,416}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00401() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(char):int",
            new int[]{-471,-439,-223,694,-574,64,-321,385,-384,-1000,786,-637,-330,-102,862,-1000,-1000,382,-325,-172,-1000,204,-253,-1000,912,85,-511,-677,-751,-348,124,-46,920,-988,917,1000,-1000,-310,-352,137,216,-266,-67,-1000,172,-842,-871,85,-247,1000,1000,933,-619,-121,-803,585,1000,-1000,-108,-1000,-449,165,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00402() {
        org.junit.Assert.assertEquals("java.lang.Integer:MQ==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(char):int",
            new int[]{164,-1000,-1000,-1000,-76,-939,-403,-449,-389,352,552,987,18,-469,888,-163,351,894,159,-840,663,-418,-908,70,698,1000,964,-566,-217,925,167,43,-58,-346,-14,-1000,71,185,766,107,1000,-143,395,712,-95,-1000,-1000,-964,739,111,-68,-1000,49,120,-62,1000,415,615,-408,19,319,-1000,283,-279}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00403() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(char):int",
            new int[]{229,-1000,-809,-1000,-482,-292,-598,832,385,862,520,987,-24,1000,672,1000,234,-59,-427,-829,258,-352,-357,504,-352,-469,591,1000,826,1000,-1000,-290,-68,-54,824,-626,-1000,252,1000,-278,1000,-46,-316,1000,-961,-281,-326,-775,421,-342,-782,-90,-809,754,-133,486,1000,-207,45,-86,1000,-473,1000,41}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00404() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(char):int",
            new int[]{48,79,-1000,929,403,-752,-990,-333,-580,-640,87,171,-431,-8,-266,-232,-420,-236,-413,1000,61,977,1000,-76,-486,431,48,434,-1000,-272,258,-475,627,119,24,-587,-269,952,-472,-1000,688,848,-207,637,-1000,1000,-383,-391,-38,-187,-403,-741,-1000,276,559,-789,-1000,-66,1000,-652,558,-741,1000,45}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00405() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(char):int",
            new int[]{-889,-1000,-464,-88,-187,54,-896,1000,-1000,-1000,762,1000,-509,-639,-760,-1000,-628,756,-1000,-1000,-419,280,-1000,-1000,1000,751,-1000,-1000,1000,1000,-143,-753,355,-1000,-771,1000,42,-654,-1000,956,-119,617,-204,741,271,-1000,-1000,1000,1000,1000,869,1000,1000,1000,-1000,-21,129,-337,-257,-593,-1000,1000,263,-358}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00406() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(char):int",
            new int[]{133,-397,-1000,-679,463,-744,-551,-82,150,321,286,987,-897,-105,114,262,844,448,83,319,1000,-32,-513,435,-367,-245,-223,-266,-573,782,262,-5,418,468,-182,-228,71,604,-17,840,-268,297,46,491,476,735,517,-742,-2,52,-1000,-973,23,238,-72,607,171,519,742,-152,319,-316,-402,-590}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00407() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(char,int):int",
            new int[]{491,-1000,-1000,-171,187,-171,-686,-1000,733,1000,-125,1000,151,-556,34,-340,363,-83,316,793,233,104,823,460,172,264,-659,-314,789,-68,399,483,380,-151,-1000,-289,-133,582,-330,1000,125,817,491,58,322,-1000,875,502,-262,1000,582,-686,-939,45,-329,228,-630,506,-519,335,-888,-533,839,-405}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00408() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(char,int):int",
            new int[]{516,282,294,-1000,1000,-284,711,-184,-81,252,1000,-231,360,-353,-411,248,-669,-782,852,-655,-417,-416,-2,-298,1000,-1000,-115,-413,-37,-398,-969,-416,-44,259,192,-32,-791,-918,476,802,-973,-1000,-44,-9,-595,155,875,-310,1000,-1000,-565,718,686,-1000,-289,1000,-470,-1000,-310,824,441,1000,708,377}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00409() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(char,int):int",
            new int[]{-295,1000,720,230,-816,-104,-257,-1000,754,-29,-246,871,599,-908,394,611,779,1000,-981,995,-733,535,52,-432,201,-98,15,989,649,806,-578,505,36,868,453,-303,1000,-346,-444,1000,-72,1000,-869,-84,747,-1000,987,221,262,112,301,-1000,1000,610,1000,-632,726,-990,1000,-592,403,-720,1000,-328}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00410() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(char,int):int",
            new int[]{32,116,-663,756,-55,944,-206,-23,1000,986,111,723,533,26,-591,433,41,933,-804,444,336,397,1000,-651,-232,694,-772,-500,-37,-133,431,266,261,356,-1000,88,151,282,-324,1000,532,324,-129,327,843,-868,146,-665,-657,-1000,885,-720,-14,1000,1,-1000,-586,-496,-169,-297,-294,-439,623,-187}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00411() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(char,int):int",
            new int[]{-581,-1000,849,852,413,819,-776,1000,1000,959,152,-725,856,83,-1000,773,-748,24,792,-100,953,-324,949,-450,-114,1000,-1000,-1000,1000,-752,1000,817,-1000,173,-1000,-166,-1000,522,-845,-871,1000,-697,1000,1000,-404,-904,348,-728,-1000,-1000,1000,756,-1000,-938,-807,683,-1000,987,-1000,1000,-1000,-662,-1000,-425}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00412() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(char,int):int",
            new int[]{-448,221,731,904,420,-291,243,-953,-59,-244,287,205,745,-111,200,1000,1000,205,-1000,528,-888,928,235,-1000,-834,-763,528,1000,8,872,-1000,469,-1000,750,521,-483,519,3,360,1000,-303,722,-1000,420,209,-59,782,473,924,-367,-80,-874,1000,263,1000,-968,1000,-1000,1000,-1000,1000,178,203,106}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00413() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(char,int):int",
            new int[]{492,-1000,-622,-359,-290,-21,-177,-1000,330,-966,430,824,192,102,841,-201,591,-181,496,444,-378,-94,585,508,-31,-580,-642,-254,-208,316,254,138,575,259,-541,-328,-468,365,21,-791,-197,520,44,-25,144,-478,1000,262,-57,1000,509,-1000,-149,-1000,-102,1000,-682,509,-722,-878,36,-130,468,294}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00414() {
        org.junit.Assert.assertEquals("java.lang.Integer:NA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(char,int):int",
            new int[]{-412,-1000,-643,895,-266,217,-1000,-363,645,-418,354,1000,456,878,136,434,707,931,210,584,499,-189,1000,-900,10,-33,-932,93,305,-218,-210,-31,421,-797,-1000,-133,-961,69,-427,244,1000,939,778,1000,-118,-1000,786,-683,-228,1000,1000,-120,388,-552,214,44,-764,695,-1000,-150,-635,161,-480,989}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00415() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(char,int):int",
            new int[]{843,116,-800,-1000,895,777,-111,217,-559,-1000,151,746,849,-1000,-180,-196,734,711,-1000,624,222,577,1000,-1000,513,-1000,212,1000,-248,-17,-1000,254,1000,172,-1000,-552,298,-19,39,-110,-140,637,-252,-408,1000,-420,1000,-311,712,898,524,-92,1000,-100,294,282,877,-847,-1,-691,148,-54,1000,344}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00416() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(java.lang.String):int",
            new int[]{-129,-1000,947,295,-630,-287,662,402,-812,1000,32,271,-157,730,-954,-578,527,-1000,-605,790,-883,398,-18,-369,1000,219,-898,566,-263,820,-775,-1000,404,-661,26,1000,368,-1000,-599,97,-198,-726,-628,-1000,560,115,-163,-372,-976,1000,-1000,-412,1000,-148,915,77,1000,-832,-1000,645,1000,-986,188,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00417() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(java.lang.String):int",
            new int[]{128,-117,267,414,194,203,541,787,-239,397,994,-881,-652,-12,-162,-1000,-47,163,201,-797,-923,-616,-1000,-416,-118,-142,-1000,83,482,583,1000,-717,-316,451,-790,506,139,680,22,1000,445,-303,-1000,-1000,-1000,690,608,-512,396,74,-1000,1000,620,33,547,-1000,128,57,-467,-84,193,-748,597,181}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00418() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(java.lang.String):int",
            new int[]{-1000,-1000,574,875,557,1000,163,842,-66,331,841,-449,-245,187,-172,-621,-416,-784,120,-443,-469,1000,-1000,-382,976,-479,-903,1000,933,684,242,-22,-262,9,-1000,1000,1000,-131,-155,743,379,123,-417,-773,560,901,143,-800,-738,-636,-1000,1000,834,-325,986,-732,309,172,-1000,-707,215,400,-213,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00419() {
        org.junit.Assert.assertEquals("java.lang.Integer:Mg==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(java.lang.String):int",
            new int[]{-407,-886,-1000,-1000,-293,294,696,-581,-591,776,-1000,1000,1000,-1000,-967,-720,-141,-1000,-742,1000,-1000,-1000,-1000,1000,360,1000,-533,92,119,473,-1000,-439,359,-1000,547,576,32,-5,889,1000,-1000,-1000,-176,1000,-1000,-278,238,830,1000,-59,677,1000,-776,1000,761,-538,-87,-801,-822,1000,1000,-1000,985,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00420() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(java.lang.String):int",
            new int[]{-1000,-886,-316,-80,476,-126,344,-1000,1000,-805,-46,-394,1000,1000,-961,-597,-1000,-721,-152,-798,-403,-283,-309,-1000,-327,-828,159,1000,1000,407,-1000,738,-1000,-1000,510,749,-440,508,632,-14,619,-491,-120,-457,681,865,238,1000,1000,219,245,312,-254,335,793,-538,1000,1000,-378,73,712,400,703,771}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00421() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(java.lang.String):int",
            new int[]{-549,-1000,6,986,-113,-1000,828,-121,1000,-656,1000,-1000,-74,-1000,-947,-270,-234,829,-981,-1000,972,1000,400,-1000,410,-1000,-683,445,298,893,-634,859,-1000,529,-618,-1000,-1000,669,312,-1000,403,519,224,1000,1000,620,-1000,-224,-1000,-1000,1000,260,952,-1000,-785,-192,1000,840,823,29,215,1000,-842,814}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00422() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(java.lang.String):int",
            new int[]{-385,480,699,-783,-712,-695,-493,-520,498,-596,17,-881,-862,622,-445,264,304,862,-296,-782,518,59,552,666,65,-457,571,-454,-927,583,922,437,880,-247,-700,800,-543,345,-898,-310,248,559,653,-310,-380,416,501,692,-661,426,382,-92,930,-57,-640,-968,640,-189,853,813,805,433,789,-514}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00423() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(java.lang.String):int",
            new int[]{-561,835,-160,-190,178,334,416,891,-1000,-266,1000,-256,-1000,-497,706,-1000,655,-289,-414,-200,425,-1000,82,990,844,1000,-988,616,-243,-477,-296,-1000,-306,1000,-1000,66,-672,-190,-420,507,-417,-900,-1000,-548,-1000,1000,818,-497,-1000,13,-1000,1000,142,-765,664,-106,1000,-918,-1000,847,-314,-480,-539,162}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00424() {
        org.junit.Assert.assertEquals("java.lang.Integer:Mw==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(java.lang.String):int",
            new int[]{780,-1000,525,-1000,-624,158,268,817,3,705,-1000,163,1000,-895,-1000,738,736,575,-532,1000,-301,131,272,1000,46,29,777,-1000,175,217,-400,-79,718,-60,727,-692,163,537,740,-400,-76,-754,864,400,1000,-32,-1000,58,-1000,270,1000,-129,-954,1000,-934,374,-531,-59,1000,1000,-233,508,-755,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00425() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(java.lang.String):int",
            new int[]{-715,-916,-160,588,438,-296,684,-675,-235,-120,1000,-510,362,421,-961,-1000,-1000,-140,-744,-515,-256,-242,-624,1000,1000,-1000,-763,1000,925,454,-775,1000,-1000,-347,-1000,74,237,218,518,-410,509,-88,-670,-936,969,1000,58,-758,-1000,557,348,896,1000,243,275,-205,816,1000,8,-151,256,-294,240,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00426() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(java.lang.String,int):int",
            new int[]{-396,-1000,1000,1000,482,-227,209,594,1000,1000,-1000,1000,142,-530,1000,-139,1000,-1000,1000,378,-319,-952,-1000,884,-1000,-463,707,175,-268,1000,-1000,1000,948,1000,-1000,105,-1000,-868,-1000,1000,-700,-1000,-1000,-889,-1000,456,-390,746,1000,-1000,-349,148,144,423,-1000,-1000,1000,-1000,-741,-1000,139,885,-170,463}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00427() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(java.lang.String,int):int",
            new int[]{748,241,283,-11,-496,-210,-43,73,-925,69,460,424,-641,-882,265,-708,-38,234,-124,800,410,319,1000,382,538,1000,-738,292,582,-161,748,248,-637,1000,94,1000,0,1000,1000,-278,294,1000,-857,-636,-813,262,343,176,-178,868,-140,415,-746,405,-1000,145,-200,327,-1000,1000,674,628,-422,-142}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00428() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(java.lang.String,int):int",
            new int[]{-1000,575,309,-700,164,-1000,232,481,1000,1000,-1000,-53,-1000,1000,-446,227,1000,-641,-235,-1000,-1000,807,350,191,-1000,-1000,1000,1000,1000,24,-1000,-554,249,166,-442,-1000,1000,-1000,-318,740,739,-870,1000,-615,1000,123,14,-120,179,-1000,-305,-914,559,1000,-666,403,-1000,-596,1000,-252,443,-855,-970,-456}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00429() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(java.lang.String,int):int",
            new int[]{-543,-1000,419,325,509,39,-184,229,459,573,-184,325,-74,457,-76,94,1000,-882,-275,364,-512,-454,1000,458,-541,-139,296,1000,-514,-230,-823,-148,10,-89,-276,825,-914,-256,-491,244,-291,-300,-922,-652,-847,618,-485,-469,-1000,-252,75,417,-952,14,-921,118,451,-395,399,1000,1000,962,-150,-454}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00430() {
        org.junit.Assert.assertEquals("java.lang.Integer:MQ==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(java.lang.String,int):int",
            new int[]{444,-1000,-1000,-1000,-71,-338,-999,177,-1000,-1000,1000,-1000,-1000,-160,-854,94,797,1000,-1000,954,125,1000,-400,-1000,1000,408,-806,1000,1000,-386,-275,-1000,-1000,-676,-305,991,-186,1000,838,-1000,-412,1000,415,-1000,228,-1000,1000,-979,-1000,1000,-659,-878,-792,-1000,400,-583,-976,1000,399,1000,1000,471,-181,-496}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00431() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(java.lang.String,int):int",
            new int[]{-591,-1000,156,-233,326,-1000,-141,-166,-533,653,274,-617,-963,0,-372,-34,1000,-699,-47,-109,-10,-84,389,148,498,-359,-179,1000,518,-969,-400,-921,99,469,-612,-93,33,976,-416,400,-788,-26,214,-1000,63,-380,655,-107,2,-400,-643,-878,-1000,-175,-1000,660,-774,-145,28,-248,1000,-741,-1000,-215}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00432() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(java.lang.String,int):int",
            new int[]{261,688,-1,523,-261,540,862,-914,205,170,-192,333,219,-445,-138,236,-164,760,719,-20,877,-995,-620,672,875,726,-838,64,-731,-970,654,815,-207,-797,544,409,884,339,212,-537,432,-458,-537,-109,206,666,-155,-857,902,94,621,-433,903,-329,677,842,579,-420,-650,382,-786,-316,531,-378}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00433() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(java.lang.String,int):int",
            new int[]{-938,-1000,456,570,-1000,338,267,-406,417,700,-62,881,304,931,-191,-938,655,-377,1000,212,-675,-1000,1000,788,31,-256,306,384,-474,-758,-865,132,-61,-484,-189,1000,-869,-761,-99,-829,117,-403,-1000,-503,-810,738,83,-221,-1000,484,276,-260,91,-408,-835,636,596,-468,-1000,-153,-5,1000,1000,-720}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00434() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(java.lang.String,int):int",
            new int[]{-1000,-1000,-234,-193,-1000,-321,-621,627,-520,-255,117,498,343,1000,-471,-477,1000,281,526,-305,-433,-401,-400,438,1000,-302,113,-63,1000,-1000,387,-801,-758,-1000,334,1000,-199,-1000,102,-1000,536,21,-102,-533,494,380,112,-17,-432,1000,456,238,-1000,-1000,-1000,833,257,-113,254,313,-122,-916,-1000,-998}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00435() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(java.lang.String,int):int",
            new int[]{434,-388,-325,-194,-1000,158,-527,-577,-163,-173,491,455,580,1000,245,6,-325,748,1000,564,-310,-990,411,1000,947,820,-303,291,308,935,378,1000,-909,-1000,74,580,544,-182,-366,-983,789,47,-842,-435,-37,774,405,720,-596,601,1000,-323,154,52,234,1000,748,82,-577,424,-985,858,779,316}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00436() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(java.lang.String,int):int",
            new int[]{224,744,533,-1000,-447,498,-144,584,362,348,22,140,-1000,-317,15,686,347,148,338,260,-101,-1000,981,494,77,262,522,266,1000,-158,224,-520,-382,-1000,-192,400,399,400,-318,-154,316,530,113,-931,699,1000,954,703,-646,308,-443,76,-333,1000,-1000,237,-828,333,-352,59,1000,-13,-566,-560}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00437() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(java.lang.String,int):int",
            new int[]{900,-475,-288,-1000,867,-226,-688,1000,-1000,-763,594,-1000,-1000,51,-214,362,-183,521,-1000,431,305,1000,580,-512,-489,580,-695,296,1000,1000,695,-477,-197,724,-741,416,512,1000,-318,1000,-140,829,-395,-1000,866,-705,970,-660,-1000,1000,-808,-268,-401,1000,-670,-484,-1000,798,181,907,345,1000,-316,983}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00438() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(org.apache.commons.lang.text.StrMatcher):int",
            new int[]{-1000,-1000,114,243,543,-578,-188,1000,-110,-736,-513,1000,371,1000,721,328,427,400,-292,-884,201,226,121,-275,-105,1000,-104,-864,-501,861,640,1000,1000,1000,924,-270,-934,130,-341,-158,-1000,156,-441,-579,-1000,400,937,-447,-807,-1000,552,309,-618,84,504,-1000,-49,1000,31,766,-163,-370,-1000,-773}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00439() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(org.apache.commons.lang.text.StrMatcher):int",
            new int[]{-772,-801,19,416,-1000,325,542,-743,-757,45,841,1000,1000,-754,-1000,380,-310,-448,-444,-602,-99,1000,-1000,-235,183,1000,79,670,-1000,184,-840,-81,-226,-326,-455,657,-668,1000,803,1000,357,109,-939,-164,117,-335,-1000,603,182,-1000,-189,1000,-1000,392,723,854,315,593,947,953,-2,559,68,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00440() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(org.apache.commons.lang.text.StrMatcher):int",
            new int[]{-710,908,-269,-580,400,324,-896,-360,32,978,335,322,97,1000,-494,-1000,-875,85,-187,704,-435,983,-613,-1000,-775,501,-1000,87,-624,-974,-1000,105,-1000,339,-554,726,1000,-573,516,1000,-330,-966,-1000,1000,1000,-1000,311,1000,1000,-305,-641,624,-866,-845,938,-146,1000,562,-1000,342,211,1000,249,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00441() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(org.apache.commons.lang.text.StrMatcher):int",
            new int[]{-863,172,364,-730,-747,-321,-1000,-1000,-406,-461,-513,-175,-684,-709,-657,755,-775,-298,-287,170,-132,1000,1000,529,529,1000,681,1000,-1000,453,-123,-725,577,-1000,-1000,957,125,-613,925,-898,1000,-324,334,-591,355,643,-714,126,-430,687,436,-171,283,16,-686,-1000,-315,-1000,-178,-186,-881,-788,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00442() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(org.apache.commons.lang.text.StrMatcher):int",
            new int[]{-896,-409,1000,400,-1000,-773,-572,-368,610,247,-1000,-498,-568,51,-346,674,821,-36,-275,13,-159,-1000,-519,95,-715,839,1000,909,463,1000,465,-335,1000,-673,1000,627,46,1000,142,-1000,-107,650,470,-676,-1000,1000,-1000,-1000,53,1000,-13,636,578,-149,-911,-102,-484,-868,-477,433,509,-1000,-407,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00443() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(org.apache.commons.lang.text.StrMatcher):int",
            new int[]{527,-427,161,1000,-971,168,962,711,-1000,-907,173,537,1000,-1000,-485,-841,1000,173,-1000,-1000,1000,-331,235,-1000,-762,676,-70,433,824,-584,212,413,208,1000,504,-567,-338,-733,-623,-400,166,1000,-1000,-640,-1000,-565,111,1000,949,-1000,456,-1000,-352,-281,-112,-486,-61,77,1000,-742,670,170,-1000,-671}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00444() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(org.apache.commons.lang.text.StrMatcher):int",
            new int[]{-311,-1000,791,205,296,-619,599,160,-369,-1000,-659,61,387,-802,6,529,960,-1000,525,-462,-116,-114,-769,309,1000,1000,227,-1000,108,903,-450,1000,1000,18,588,202,-990,333,-352,140,-1000,775,-441,-397,-1000,580,17,-613,613,-1000,1000,79,-651,629,168,-258,473,-298,-5,280,72,-559,-643,-841}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00445() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(org.apache.commons.lang.text.StrMatcher):int",
            new int[]{-600,65,-560,465,-1000,-959,-608,-620,-857,599,219,-77,468,321,283,-717,301,-1000,-221,-358,329,-536,-1000,-491,129,-781,-543,596,824,-839,38,-1000,946,38,-651,-365,1000,534,492,-406,-151,227,921,715,-637,-369,271,623,1000,493,343,-115,847,-1000,-401,-489,172,-11,-236,-690,950,546,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00446() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(org.apache.commons.lang.text.StrMatcher,int):int",
            new int[]{793,-1000,-956,-1000,-735,534,967,-834,779,737,530,564,-228,720,478,136,326,587,-888,488,-800,-788,768,-1000,-625,-87,674,-84,162,557,516,426,-329,86,847,-22,-1000,-167,-583,-57,-1000,366,379,-283,-43,876,802,-278,-586,-535,-1000,1000,26,996,1000,536,505,37,1000,495,1000,-693,72,-324}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00447() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(org.apache.commons.lang.text.StrMatcher,int):int",
            new int[]{689,-66,-541,184,153,788,-1000,-49,-675,216,-1000,230,-386,-411,-689,1000,-1000,1000,-91,1000,-308,-390,300,355,-275,669,1000,-1000,537,-1000,-1000,1000,1000,13,469,-955,226,-1000,-960,-1000,1000,-154,-127,-843,204,-99,-197,818,36,-903,-493,1000,14,-528,-977,-327,330,1000,-443,-44,-357,1000,486,896}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00448() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(org.apache.commons.lang.text.StrMatcher,int):int",
            new int[]{-481,-1000,-690,-1000,-486,1000,814,-95,582,213,-1000,638,-1000,481,27,-538,792,1000,19,555,19,1000,1000,-1000,510,1000,1000,-186,1000,1000,-1000,881,-1000,30,1000,-1000,-560,199,-962,-321,211,-312,498,-1000,631,588,693,-292,-400,4,-789,-424,9,-819,1000,36,836,1000,1000,-459,323,-1000,1000,-44}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00449() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(org.apache.commons.lang.text.StrMatcher,int):int",
            new int[]{949,505,404,-704,-866,-56,208,1000,1000,723,-445,-696,-1000,-128,195,-680,791,1000,119,125,-717,-104,893,-798,352,422,706,-884,344,1000,885,-1000,-1000,600,879,494,-1000,-501,116,540,-177,1000,-1000,-243,227,927,972,208,-627,-570,-1000,-708,397,-543,889,-909,288,-195,361,-750,1000,-1000,525,-153}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00450() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(org.apache.commons.lang.text.StrMatcher,int):int",
            new int[]{840,-1000,-996,-878,-735,-40,-196,-759,-71,1000,474,696,146,204,313,1000,-298,138,-1000,1000,-1000,-912,500,-265,-1000,-87,643,-717,-140,-313,516,767,60,501,241,449,-868,-526,-454,-717,-1000,-458,-506,-225,-196,808,254,-278,-659,-470,-1000,804,317,64,168,-96,288,150,528,495,1000,-114,-103,-107}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00451() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "indexOf(org.apache.commons.lang.text.StrMatcher,int):int",
            new int[]{438,-1000,-368,-1000,-638,-71,663,-365,445,349,897,1000,188,1000,-66,283,881,-1000,480,-1000,-212,-708,-588,-136,-609,-1000,-1000,155,-1000,1000,699,430,-18,-360,44,643,-1000,925,976,1000,-1000,1000,576,1000,-524,1000,736,-1000,417,313,-978,-707,-664,470,0,798,-812,-1000,694,755,1000,-1000,-686,-864}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00452() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,boolean):org.apache.commons.lang.text.StrBuilder",
            new int[]{-964,-1000,1000,-480,718,759,148,791,511,-62,-709,22,77,-361,-371,-1000,-1000,-200,1000,-929,443,1000,-52,-437,-1000,833,-1000,-163,317,-70,329,888,-50,365,435,251,-39,645,380,748,326,439,-658,440,-898,-367,-1000,-571,-755,817,-235,-285,-1000,583,-1000,-1000,-35,186,-1000,-744,-1000,-386,185,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00453() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,boolean):org.apache.commons.lang.text.StrBuilder",
            new int[]{180,-630,79,650,651,-589,-982,567,753,-882,1000,-506,-364,-531,-131,1000,1000,772,1000,498,302,1000,-133,-902,272,-87,-291,-32,931,-633,537,-492,864,-268,979,1000,-39,33,-127,320,477,42,788,497,356,935,1000,-1000,-1000,8,162,1000,-1000,366,-981,-76,-330,-625,-96,1000,1000,-593,-34,-154}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00454() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,boolean):org.apache.commons.lang.text.StrBuilder",
            new int[]{-11,94,-59,214,-716,-823,-874,-472,931,-1000,1000,-728,237,-519,-828,1000,1000,456,828,-55,1000,-589,-1000,-1000,-451,-129,1000,419,439,-1000,1000,-281,-118,555,558,-297,-1000,101,-1000,-544,-359,-484,433,-311,224,1000,1000,-772,-14,-294,117,-274,511,-259,-863,949,-837,-383,-238,227,536,-311,-724,-513}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00455() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,boolean):org.apache.commons.lang.text.StrBuilder",
            new int[]{-317,-1000,1000,482,1000,261,-101,-639,215,-1000,-1000,269,-1000,634,-922,-713,-1000,299,800,-1000,-1000,1000,-1000,380,290,1000,-1000,819,889,-532,351,945,1000,-1000,1000,1000,1000,-163,147,-40,1000,1000,50,747,-682,31,-1000,-621,-1000,411,18,780,-1000,1000,-1000,-1000,625,449,-893,871,164,-495,671,-310}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00456() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,boolean):org.apache.commons.lang.text.StrBuilder",
            new int[]{-477,-1000,321,-452,804,-687,389,641,1000,-1000,-60,-924,-691,182,-437,-122,-320,1000,681,1000,-231,-20,-582,560,-36,181,400,970,721,-876,475,834,1000,158,838,347,1000,-1000,-1000,161,-218,234,124,-167,-646,-328,-263,-283,-937,231,1000,-1,-210,551,-456,-297,-934,-1000,-60,1000,1000,-259,619,-491}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00457() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,boolean):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-1000,912,699,409,36,-768,980,610,-1000,565,-659,-462,160,-507,220,-256,637,814,483,967,702,-760,-672,-238,556,-1000,862,647,-688,550,377,1000,-848,208,1000,4,159,626,-244,333,638,126,794,-646,636,-52,-317,-1000,-443,-132,1000,-1000,1000,-1000,-297,224,-596,-937,1000,660,114,187,-491}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00458() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,boolean):org.apache.commons.lang.text.StrBuilder",
            new int[]{241,-1000,782,1000,267,135,-449,-667,-124,-1000,993,247,-565,312,-814,769,462,476,734,589,-1000,633,-313,-925,-1000,605,-984,910,974,-1000,939,87,1000,-1000,1000,680,255,222,-68,-929,836,765,1000,-1000,-1000,954,820,-324,-1000,-1000,-134,1000,-1000,845,-901,-508,754,1000,-522,1000,620,-974,-341,-283}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00459() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,boolean):org.apache.commons.lang.text.StrBuilder",
            new int[]{-960,-1000,1000,-1000,1000,614,732,-54,115,80,-535,-43,-1000,-947,-487,-1000,-1000,203,427,349,-431,-193,-461,242,-1000,1000,-346,1000,200,-1000,1000,926,39,-323,633,-191,909,-1000,961,26,-415,1000,-362,-1000,-1000,-942,-1000,892,19,-1000,1000,-633,299,1000,-868,-712,-312,-848,-535,-212,-486,375,-362,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00460() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-611,-1000,55,1000,343,663,204,-364,686,784,-513,404,22,657,-347,-567,-302,91,445,-885,-773,-45,451,-189,-58,-443,-365,-75,-1000,-42,462,-804,-348,703,-1000,1000,-1000,889,-480,-1000,100,403,24,1000,-597,-237,878,626,139,-177,-75,-573,-796,592,-1000,-196,-207,2,1000,-493,518,-1000,-292,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00461() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{207,-750,-462,-360,-409,410,-911,-600,-601,-464,-6,1000,999,193,-639,-564,1000,795,-1000,-128,24,755,1000,-897,-1000,-265,-750,-1000,-544,-78,1000,-622,-123,152,469,-1000,-546,1000,1000,60,-583,955,644,-1000,520,1000,-188,478,608,-815,-1000,-134,393,539,728,270,117,1000,62,-232,270,90,794,-84}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00462() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-612,47,-874,-842,-353,1000,-177,321,-422,490,-449,117,-476,-383,263,600,600,-1000,544,-46,1000,431,322,575,999,1000,449,1000,819,1000,523,399,-1000,-193,-642,233,-181,-490,1000,622,285,-571,-281,-361,395,113,-198,365,-597,-75,873,-225,-744,141,-92,-177,-285,556,864,-464,-699,1000,-825,122}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00463() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-735,1000,316,509,34,576,-436,-1000,162,568,327,490,-340,959,-1000,1000,1000,61,-763,-694,-173,-979,-851,-150,-151,852,-1000,-1000,-311,-1000,602,558,-152,-169,-397,1000,-796,-32,1000,-729,-1000,-1000,-625,-400,1000,844,-713,1000,944,-1000,-481,-53,1000,-119,1000,1000,596,964,592,-550,-565,428,335,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00464() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-473,164,433,223,-811,-506,-465,-15,-604,24,1000,606,489,481,870,256,-422,-92,-488,75,-594,620,-186,-12,-255,-473,232,552,608,-494,990,56,-983,-833,340,-1000,825,20,43,1000,-161,-435,-226,-619,-117,328,-34,-40,-253,113,779,-1000,152,-674,240,744,545,426,693,-531,-254,-62,1000,-146}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00465() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-1000,1000,-83,-815,-963,-276,-269,256,1000,1000,606,1000,-918,-1000,1000,239,558,-1000,-575,-594,-75,-749,433,-1000,-792,-1000,90,181,-1000,1000,56,-177,-883,-24,-1000,469,-228,408,-510,148,-430,9,-721,-2,1000,705,1000,1000,-1000,-1000,-1000,1000,-443,497,1000,1000,1000,-372,-1000,253,-1000,317,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00466() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-969,-1000,304,-162,-385,-251,365,300,186,833,-4,189,926,-205,-125,-595,213,798,-160,8,-1000,-188,152,-837,-499,-1000,-392,426,-651,281,918,-561,-1000,136,321,1000,541,1000,-49,-400,1000,751,400,235,-466,732,980,-180,-695,-438,-356,-1000,-1000,80,-750,-145,-103,1000,1000,-574,703,-1000,1000,-68}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00467() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,char[]):org.apache.commons.lang.text.StrBuilder",
            new int[]{79,-673,104,-409,-511,-299,809,278,-13,294,462,683,-652,48,-237,-933,476,-194,804,-702,823,946,411,-890,-625,33,195,411,922,582,-740,708,117,-569,189,-715,903,460,935,174,295,433,541,144,-780,596,-760,-72,-870,-688,-592,768,-541,-479,-897,-53,-369,83,458,465,296,167,-919,-743}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00468() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,char[]):org.apache.commons.lang.text.StrBuilder",
            new int[]{806,948,354,414,-856,753,13,-864,-909,-424,868,311,685,-253,-625,64,-838,-740,-277,-283,924,725,-653,-529,81,-868,-216,-807,786,278,856,643,429,-842,-180,-925,772,-180,154,-484,569,-740,933,231,-114,-254,-627,891,-622,669,46,-219,-879,452,541,-970,-762,-613,852,-734,526,-681,705,-606}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00469() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,char[]):org.apache.commons.lang.text.StrBuilder",
            new int[]{-244,1000,672,115,-767,611,-1000,-966,-960,1000,-101,-831,429,914,-1000,495,7,948,-295,-173,524,-532,-1000,120,1000,449,381,-444,-164,347,-1000,174,-1000,1000,613,-308,-783,378,-393,696,-692,-1000,1000,-699,-617,-1000,940,131,-605,1000,363,-40,1000,-373,935,-544,-196,-452,233,-524,809,-993,-936,360}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00470() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,char[]):org.apache.commons.lang.text.StrBuilder",
            new int[]{710,-1000,-807,-431,-321,-83,-928,161,-546,366,514,759,704,876,-873,182,451,712,-562,-913,359,1000,1000,416,1000,-224,-328,518,-168,-93,32,-286,1000,-1000,51,34,286,596,632,1000,498,-836,1000,-384,1000,295,708,1000,-326,-1000,-1000,1000,-63,-62,265,-1000,325,-198,-1000,-567,1000,947,735,913}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00471() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,char[]):org.apache.commons.lang.text.StrBuilder",
            new int[]{454,-1000,-415,580,-673,-246,1000,557,187,-773,880,-133,-1000,119,-249,-197,116,353,827,268,1000,638,1000,-1000,178,-340,-787,1000,141,990,1000,1000,1000,-98,-726,360,1000,499,687,190,158,-228,-1000,1000,-760,867,-213,316,-1000,-115,-1000,-78,-398,902,-1000,134,-395,-1000,227,208,114,-174,-1000,304}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00472() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,char[]):org.apache.commons.lang.text.StrBuilder",
            new int[]{657,-1000,633,-1000,-228,-273,114,651,60,1000,-687,162,-371,612,-236,-197,959,-677,424,-1000,-90,228,57,835,-1000,-121,1000,1000,-423,-155,1000,-607,1000,-212,1000,-882,-406,419,-35,625,-121,755,526,-1000,-18,-143,-20,-513,55,-149,-462,1000,246,-1000,1000,-683,1000,1000,693,639,1000,463,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00473() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,char[]):org.apache.commons.lang.text.StrBuilder",
            new int[]{235,-1000,-882,1000,-1000,-377,441,316,239,-326,1000,328,-923,322,454,223,-155,1000,270,-224,1000,523,1000,-1000,542,-135,-834,1000,669,328,-887,728,0,-392,-534,406,838,428,-175,209,204,-1000,-414,1000,-40,570,222,587,-624,13,-1000,625,242,1000,-917,674,-126,-978,-517,-115,179,-886,480,795}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00474() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,char[]):org.apache.commons.lang.text.StrBuilder",
            new int[]{142,-25,944,-585,-676,-704,-1000,529,-306,-951,-76,-706,763,1000,40,-1000,690,1000,-562,-1000,1000,1000,1000,-1000,916,174,-792,622,-747,-199,95,477,-116,302,-101,462,-623,659,758,-713,226,-580,1000,-917,-389,-3,190,1000,-1000,288,-1000,1000,1000,-64,16,381,1000,-564,605,-1000,1000,-644,326,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00475() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,char[],int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-147,263,806,-406,-727,-95,169,368,205,458,2,-1000,-679,978,-738,-229,-853,825,-253,986,-151,-795,840,-609,828,277,-114,1000,566,-322,354,-211,-61,102,-1000,656,-36,752,-177,636,-890,-849,-638,932,-111,-23,-678,420,957,245,174,522,1000,-190,774,-103,-1000,-195,356,-831,-285,404,-956,404}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00476() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,char[],int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{679,957,554,482,-115,-773,-928,-931,-239,435,-358,-79,-550,-236,-251,1000,267,-748,857,480,-182,41,11,1000,602,-915,425,-593,669,-418,-740,-1000,-806,-381,263,239,105,805,-1000,-118,-645,-78,658,373,702,1000,747,144,92,-12,-36,-589,-321,-695,112,807,-227,588,-1000,680,-382,540,142,-312}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00477() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,char[],int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-420,-166,-699,627,-1000,-140,-340,-891,-582,945,-638,-131,-1000,-1000,-371,1000,457,-1000,-290,64,-98,331,427,1000,-1000,29,-1000,920,-587,-226,-286,268,226,-37,307,-1000,221,884,-1000,-620,-609,833,1000,-374,-1000,983,1000,351,696,28,1000,-1000,349,-17,-576,242,-540,1000,-462,-1000,-1000,-765,-54,636}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00478() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,char[],int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-322,-1000,-316,-64,-727,974,314,-466,219,322,-216,282,28,-622,678,512,315,72,-588,-149,238,527,-850,1000,121,-251,245,-462,-535,-637,-619,-17,-570,-400,-76,-56,203,645,427,183,-62,-582,-198,-769,-897,16,842,91,-407,9,-400,-502,-694,-387,418,-119,-686,143,267,-34,-301,-346,248,400}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00479() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,char[],int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{927,-359,-58,1000,209,-339,11,-834,-1000,386,-1000,-247,-1000,1000,677,949,732,-1000,-233,-339,-778,-1000,1000,493,-744,-1000,-1000,983,-1000,-20,541,1000,0,1000,673,-76,-893,136,502,-1000,-331,570,1000,-521,-1000,581,-165,915,-52,1000,1000,-1000,647,300,-827,175,115,1000,585,-162,396,-1000,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00480() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,char[],int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-357,39,479,2,1000,577,-1000,-727,-145,1000,-419,-384,-1000,587,-867,-553,833,778,277,236,-345,-1000,-1000,-75,-221,551,-1000,1000,-791,-898,871,858,1000,-1000,-270,-475,749,1000,489,292,-596,-357,-875,-615,953,1000,-656,-448,-509,353,-1000,119,-199,-165,-1000,-179,-808,-127,183,-1000,-1000,244,-471,968}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00481() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,char[],int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-222,-112,560,551,493,-78,918,487,304,-824,-492,39,-517,-67,-504,-732,857,233,-734,97,-847,-460,349,115,260,78,-647,370,-346,478,372,-500,-545,-215,-600,-895,101,-15,777,-468,-536,233,-620,-579,-600,-271,-626,286,-850,795,672,-825,838,-850,-41,14,334,548,120,-357,-773,68,213,-271}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00482() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,char[],int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-199,-127,557,518,788,1000,-1000,-1000,-354,1000,-855,-255,-1000,1000,-979,-1000,1000,-1000,222,1000,-955,-1000,-1000,942,35,1000,-1000,639,-1000,-544,969,1000,1000,-1000,-984,-429,-718,1000,9,18,-810,255,-1000,-165,796,1000,81,-450,-389,453,-1000,234,1000,-436,-1000,702,-589,-128,765,-1000,-1000,-141,-558,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00483() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,double):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-919,-548,346,1000,277,114,-648,123,959,246,-612,1000,-225,-269,-626,608,-660,772,-168,-1000,757,229,189,-237,-70,-167,-43,-537,232,1000,560,616,471,381,-998,380,475,599,453,-1000,-381,-191,-123,161,1000,-701,-103,-175,-746,-951,574,-893,1000,-369,-1000,-518,-376,-135,194,485,-890,-65,-507}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00484() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,double):org.apache.commons.lang.text.StrBuilder",
            new int[]{438,-597,134,-766,1000,1000,721,395,-861,158,-1000,499,-1000,-1000,298,857,-189,1000,638,782,-709,1000,497,-1000,-39,-126,-480,-1000,-154,-1000,605,606,-908,-1000,-90,-772,-1000,-1000,231,829,1000,-58,86,-1000,-1000,1000,18,-1000,739,661,-330,1000,-469,-774,-381,-111,834,-927,1000,410,-1000,814,1000,-646}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00485() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,double):org.apache.commons.lang.text.StrBuilder",
            new int[]{299,-159,224,307,65,-275,107,533,721,832,1000,1000,1000,-46,316,-1000,306,-1000,198,-1000,-592,989,-15,-155,-179,-216,400,-72,359,-126,303,142,99,1000,-214,-997,978,952,161,99,-517,-763,155,289,-37,127,-206,266,287,-485,178,-970,-387,1000,-645,96,-434,-10,476,-131,816,-593,-485,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00486() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,double):org.apache.commons.lang.text.StrBuilder",
            new int[]{818,-1000,-47,650,-1000,-356,-1000,899,-192,377,-116,639,439,571,575,-1000,-65,-389,-1000,-1000,164,-393,108,1000,270,539,-812,795,-1000,1000,424,-1000,1000,874,354,428,1000,978,-1000,428,-1000,-1000,937,1000,1000,58,1000,998,-1000,-850,-523,-1000,-1000,506,-721,564,717,188,-1000,761,-93,-622,-1000,-628}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00487() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,double):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-1000,1000,1000,-1000,-908,-891,-156,-1000,1000,-500,-150,854,795,-520,-1000,-1000,3,-1000,-1000,-1000,163,801,1000,751,493,-861,235,-1000,1000,-255,279,1000,88,-12,982,299,250,179,1000,-1000,-1000,408,1000,414,-588,1000,1000,-710,-14,405,-1000,-569,328,-755,1000,59,74,24,749,-459,-395,-333,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00488() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,double):org.apache.commons.lang.text.StrBuilder",
            new int[]{681,-1000,205,984,1000,295,-183,654,279,-275,450,561,593,1000,-91,-761,-310,557,1000,-1000,-617,-324,-896,257,52,1000,-441,317,1000,643,793,-819,1000,-980,899,-120,108,1000,-84,-1000,-984,-689,1000,316,-24,-1000,1000,607,-38,-667,-699,448,-877,194,-713,-1000,-589,-41,-142,928,-840,-747,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00489() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,double):org.apache.commons.lang.text.StrBuilder",
            new int[]{804,811,-243,-379,842,-33,107,-950,721,239,561,138,845,-659,199,-878,480,-281,861,58,-592,542,393,-500,196,448,668,-471,668,489,-53,807,170,814,-499,-997,370,353,795,119,-517,2,-10,-933,58,599,-955,-817,762,-590,-730,250,-45,740,-166,-900,-732,-207,427,-103,909,-3,54,770}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00490() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,double):org.apache.commons.lang.text.StrBuilder",
            new int[]{617,-1000,208,1000,-277,-347,-736,1000,937,-442,-950,785,462,668,274,-371,-356,518,773,-1000,-36,-329,-732,257,-153,-42,-383,61,348,1000,503,-1000,1000,-84,1000,586,108,1000,-762,-803,-358,-406,1000,619,-161,1000,1000,-12,443,-385,119,-373,-700,-154,-556,-1000,-302,-789,-142,676,-823,-689,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00491() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,float):org.apache.commons.lang.text.StrBuilder",
            new int[]{-144,-925,-1000,611,1000,-1000,368,-63,661,371,1000,712,1000,-1000,-1000,108,1000,1000,531,-561,55,582,1000,1000,-1000,-987,211,141,1000,1000,-437,-580,-348,-100,1000,-332,39,1000,-1000,-556,-893,1000,536,-32,-17,17,250,582,567,547,-695,215,272,443,525,1000,631,1000,-890,1000,738,-787,287,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00492() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,float):org.apache.commons.lang.text.StrBuilder",
            new int[]{196,-408,184,-421,-1000,-848,29,693,-898,-1000,-1000,-914,120,415,1000,-842,-952,-711,-1000,734,338,-550,-916,398,-851,-239,297,80,50,-7,-929,-131,783,474,-933,669,806,-668,-656,1,-174,-608,-660,1000,-1000,-123,-1,-995,350,-1000,519,-1000,-193,1000,-294,-766,1000,127,228,-1000,1000,370,-248,-898}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00493() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,float):org.apache.commons.lang.text.StrBuilder",
            new int[]{530,671,528,96,933,-116,-299,-24,-434,-905,-129,-976,1000,-267,-986,-51,-116,-750,-1000,767,-85,-782,-782,15,226,80,-688,477,-285,-258,-1000,-1000,-52,444,26,442,490,732,-451,815,315,-513,-896,1000,-856,118,413,-268,429,-551,-1000,-1000,64,-845,-968,-824,1000,-577,109,-1000,-223,-700,-67,-867}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00494() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,float):org.apache.commons.lang.text.StrBuilder",
            new int[]{970,-751,-1000,-442,1000,-846,29,896,1000,516,867,-41,810,-8,-1000,-428,1000,787,-621,676,-686,923,1000,947,-1000,-1000,941,-937,-80,400,1000,-712,-230,-469,452,-1000,1000,980,-1000,195,552,179,-793,589,-355,-187,-398,821,716,1000,278,162,330,-166,-294,618,-229,-544,675,563,-276,-150,366,234}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00495() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,float):org.apache.commons.lang.text.StrBuilder",
            new int[]{-740,-899,-756,331,-412,-508,-523,260,588,192,-589,294,387,-469,384,-561,366,383,733,-202,518,-1000,158,415,-357,-872,-291,-131,-396,-1000,350,720,-220,-351,-31,1000,-901,-525,7,-1000,-587,884,101,-1000,321,-467,1000,147,-107,-16,631,296,-385,-455,-397,-191,-250,534,-339,-1000,847,-507,21,431}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00496() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,float):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-826,-831,-1000,-595,-883,189,1000,953,637,261,-771,944,-378,-1000,-563,1000,285,-1000,-1000,-1000,-632,1000,996,-1000,-898,530,-1000,650,-1000,961,-1000,-605,-284,371,-62,-1000,690,-675,1000,-204,547,111,1000,264,-75,324,1000,588,429,429,153,549,-111,73,8,406,755,-1000,-361,-791,878,183,816}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00497() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{128,-79,1000,-933,167,127,514,-950,127,532,-62,616,231,-748,835,490,721,-546,684,765,-216,-589,-900,-1000,-1000,-587,14,1000,35,1000,887,677,94,-626,-718,-459,601,-50,-980,-1000,936,1000,-250,-364,1000,89,-737,-40,-1000,483,-264,597,344,-1000,888,475,908,-840,208,789,-822,-706,-965,390}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00498() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-605,-114,-501,287,-505,1000,56,-252,407,-29,-621,1000,-114,214,653,-322,-401,961,-100,-927,-916,-556,1000,-598,-504,1000,1000,-1000,1000,-179,1000,-156,1000,235,-469,44,-539,1000,1000,1000,-1000,-624,714,1000,517,-1000,1000,-368,1000,153,-140,-545,811,-644,77,212,-228,509,-319,-636,1000,-691,987,836}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00499() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-2,986,684,-1000,-654,-1000,114,-1000,-776,112,-107,109,407,-1000,880,517,89,-540,405,1000,1000,-439,-433,-474,-71,131,-1000,1000,-949,676,1000,730,-1000,628,-1000,-536,133,-899,-1000,-760,397,789,834,-300,1000,1000,-1000,275,-1000,-942,-291,733,-653,-1000,961,698,1000,-1000,-1000,-256,-243,215,-1000,752}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00500() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-766,-409,-137,466,-85,639,698,-369,807,-246,-649,-435,-36,797,-849,143,-592,773,-363,442,-951,201,277,521,-95,-98,689,-762,144,-355,-955,-859,1000,-363,-22,781,-252,468,1000,700,-1000,-254,-607,335,-829,412,413,630,825,525,-508,-384,275,818,158,-302,240,545,598,598,-697,-1000,112,-18}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00501() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-294,317,-1000,-674,1000,-322,952,-4,813,546,834,800,921,-641,602,-1000,947,-173,184,-745,-155,883,184,835,1000,498,1000,-394,-1000,-956,1000,155,502,295,1000,-377,191,-1000,856,346,414,-633,680,1000,586,1000,1000,-1000,71,-49,-1000,-55,-312,371,-814,613,-1000,437,1000,-105,1000,506,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00502() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,469,258,177,-701,840,-1000,-783,-1000,-393,859,-1000,535,-1000,-394,-234,786,-240,867,1000,1000,-983,-1000,-1000,-1000,760,287,1000,35,-258,489,745,-1000,-1000,-166,-459,225,276,-668,-1000,1000,459,36,-978,673,-404,-737,-40,650,378,-163,293,-743,-1000,-154,39,348,-632,56,275,697,-472,-72,-170}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00503() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-86,779,-400,-480,323,-261,525,-1000,-541,-659,-505,-248,-24,-230,-269,172,-459,517,702,798,-513,131,95,754,290,396,-859,516,-434,12,195,-65,-861,332,-208,192,-63,-336,983,138,-928,86,499,173,839,-237,-330,128,-454,-783,-699,-4,-117,-591,550,-214,464,-862,-560,-2,-217,-192,335,559}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00504() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,java.lang.Object):org.apache.commons.lang.text.StrBuilder",
            new int[]{-814,5,-401,-1000,-510,876,-204,259,-673,83,265,662,246,311,-549,-497,-514,-768,-119,910,-488,-900,-1000,-389,413,109,-911,-166,241,-284,-251,-313,-579,427,-1,-211,-279,-366,-391,448,1000,-364,-1000,798,-723,-821,-194,573,363,1000,643,-729,-1000,-271,750,-258,1000,124,751,-1000,-13,1000,1000,277}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00505() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,java.lang.Object):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-897,-551,993,279,233,-557,-263,1000,1000,86,401,474,516,-1000,507,-510,612,14,889,888,112,295,800,-632,583,-592,504,-345,-1000,407,1000,-1000,479,395,-1000,-1000,-1000,991,886,184,1000,-1000,1000,93,606,777,278,-1000,-765,1000,1000,248,-1000,-1000,-107,845,-766,-971,465,-707,-454,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00506() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,java.lang.Object):org.apache.commons.lang.text.StrBuilder",
            new int[]{334,-715,790,655,-207,-255,-191,104,-1000,334,6,375,776,-1000,240,568,-168,-37,-677,-150,-536,325,-580,797,-497,297,290,31,-1000,662,907,-432,-514,-718,813,59,67,1000,-545,532,-48,-681,20,246,272,-12,-878,42,-382,-140,369,-109,-120,429,83,730,-400,-721,-444,466,-485,-762,151,29}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00507() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,java.lang.Object):org.apache.commons.lang.text.StrBuilder",
            new int[]{-156,1000,-515,-255,-521,-24,-744,-281,-725,796,898,821,-1000,764,-479,1000,-849,717,659,711,-125,-740,-621,141,-773,-168,-106,728,1000,-968,-462,870,-310,1000,-622,-394,-644,-770,582,-1000,-385,1000,-625,139,-1000,370,-1000,594,-592,-786,718,640,1000,-1000,466,-986,128,584,626,549,47,-931,889,505}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00508() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,java.lang.Object):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-1000,464,1000,367,-919,604,-304,-387,-1000,-1000,-1000,474,360,-466,584,-1000,21,1000,885,679,-121,-181,1000,-20,-692,708,1000,-514,1000,-15,-554,273,644,136,234,1000,150,953,993,220,-379,999,413,741,441,-209,-1000,242,-944,-594,607,-116,1000,-210,-609,-1000,-517,-388,-1000,-711,462,-634,731}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00509() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,java.lang.Object):org.apache.commons.lang.text.StrBuilder",
            new int[]{-875,-688,-644,-90,263,100,-106,65,-203,299,-102,768,580,1000,-1000,-944,-55,-754,422,1000,-737,118,-1000,-61,715,-837,551,1000,565,-572,209,-903,-1000,1000,144,1000,-931,252,1000,957,-447,1000,-1000,-105,658,-960,-1000,77,1000,1000,-1000,-513,-848,1000,-61,-1000,1000,-353,446,1000,-406,-87,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00510() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-370,-160,1000,63,878,866,493,787,-263,774,-613,2,-191,-642,1000,-706,608,212,948,42,-730,929,-155,1000,-541,783,417,-1000,-1000,1000,-1000,294,-524,250,236,-697,-412,-11,61,107,233,80,352,-9,310,435,-1000,811,-1000,321,145,-822,-974,871,1000,-376,451,108,219,-622,-185,-491,231,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00511() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{979,-414,619,7,-206,-101,-521,810,-51,28,-888,128,-178,-169,-14,454,-432,-647,135,-339,856,-92,54,1000,-339,280,545,149,118,533,381,-114,1000,1000,-448,-155,-727,1000,-686,477,-1000,922,1000,-589,903,-1000,-25,520,-829,-1000,577,-1000,-6,1000,1000,-1000,26,119,-415,-236,-442,-285,-453,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00512() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{289,1000,9,-507,208,-624,-566,-1000,1000,-1000,-448,1000,-973,-52,89,-1000,1000,118,349,155,984,1000,-1000,-773,-1000,735,736,-1000,56,-805,-717,-96,-488,464,-521,772,140,-1000,411,-405,-785,525,1000,302,1000,472,767,-803,29,93,-776,20,-1000,-507,211,-1000,7,4,-1000,411,453,179,-332,-727}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00513() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-248,-316,-678,867,-866,-1000,458,942,-320,-485,-85,-68,283,850,103,-494,-730,-546,-428,-335,64,282,1000,122,823,220,677,461,416,-882,910,-1000,458,112,217,-1000,-104,1000,124,174,-1000,-609,-696,1000,-4,-62,381,-1000,-1000,-313,-832,281,1000,155,1000,258,854,-574,412,-268,-1000,-1000,398,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00514() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-205,464,-411,1000,-47,-682,391,-1000,103,-238,-378,-902,-876,-836,324,667,1000,947,-1000,209,1000,-394,184,-708,1000,1000,-1000,-994,-401,-710,-1000,-1000,308,-180,-280,807,-917,1000,-764,81,-491,-564,86,296,1000,-574,286,-990,180,-522,534,501,-505,1000,0,644,1000,963,-591,-341,-949,258,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00515() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{920,-1000,165,-53,-1000,-992,-72,-418,-688,547,-373,778,502,-609,253,-287,-409,-226,1000,408,-436,414,-9,697,981,406,475,954,-880,948,1000,839,-60,1000,-381,-696,-157,1000,-342,110,-548,-545,-397,290,-1000,-840,-35,-170,-425,-458,377,-353,-682,138,198,-493,-547,-224,610,754,-1000,-511,-899,-696}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00516() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{175,-412,-163,410,1000,-1000,-53,787,-1000,-280,-161,53,-120,188,843,-85,-384,1000,-10,-1000,177,1000,472,40,58,1000,1000,-557,69,-881,410,-1000,-578,285,-185,-1000,485,131,1000,-191,-608,-422,-851,997,209,1000,209,-1000,-962,-231,1000,432,-367,-1000,1000,258,854,595,894,-422,-630,-1000,103,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00517() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{756,159,264,559,688,218,409,1000,-898,450,367,-526,-285,-318,1000,353,415,-160,-891,-513,1000,-228,416,-650,321,668,463,97,698,729,-689,-287,371,-77,403,-1000,-651,-855,212,-489,-634,832,-417,-623,-138,941,261,-359,-241,498,249,649,262,-1000,1000,573,1000,224,536,-818,-536,45,430,332}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00518() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,long):org.apache.commons.lang.text.StrBuilder",
            new int[]{240,-1000,1000,-377,56,384,49,-276,1000,1000,1000,93,-1000,643,-532,-785,203,-481,-538,543,1000,-688,-474,-1000,-1000,431,-118,1000,-1000,-999,1000,964,-1000,993,-1000,-474,-1000,-251,551,-1000,1000,80,87,991,-1000,32,162,-596,1000,469,-403,1000,1000,268,1000,340,1000,-314,641,746,922,-1000,-491,-725}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00519() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,long):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,177,-6,216,764,-942,-1000,-463,1000,-434,167,45,-1000,754,-1000,600,1000,14,1000,858,-689,407,-88,1000,-1000,507,-108,-358,-634,803,1,231,499,1000,551,103,-570,1000,1000,-634,154,8,-146,313,-1000,1000,232,-1000,245,362,1000,1000,-966,-507,-833,-1000,1000,1000,-78,-788,991,165,1000,460}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00520() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,long):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,1000,-796,947,884,746,-11,1000,962,624,739,-462,-307,-278,-1000,-74,-696,-959,1000,-445,355,1000,-628,1000,-1000,-1000,-1000,1000,-292,-721,-338,467,-422,714,-1000,-10,-1000,-137,574,-1000,1000,779,-796,590,51,458,-179,-1000,560,-18,-703,-1000,629,-342,452,-1000,-15,1000,-150,-865,-491,-1000,1000,-769}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00521() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,long):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,575,49,918,669,384,835,-276,-298,547,1000,-760,697,-438,-354,-133,349,590,800,202,-851,-780,-929,935,203,1000,-118,1000,-954,1000,1000,1000,-4,-122,-872,247,787,-251,1000,-1000,591,688,109,-661,-1000,1000,-546,-257,-1000,236,477,1000,-362,-443,-795,-317,1000,1000,412,-1000,653,-1000,-754,-107}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00522() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,long):org.apache.commons.lang.text.StrBuilder",
            new int[]{-641,-1000,1000,-405,317,-287,268,-669,-18,781,355,-376,-816,1000,-104,-1000,1000,63,130,574,512,-793,-161,-351,-1000,1000,-720,1000,-1000,-12,1000,1000,-946,1000,-1000,62,-1000,266,-1000,-1000,1000,-232,-750,881,21,1000,1000,269,560,721,7,1000,370,-649,-185,514,1000,-12,422,-421,1000,-1000,430,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00523() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,long):org.apache.commons.lang.text.StrBuilder",
            new int[]{-928,-1000,80,152,393,-276,-932,-842,-537,-773,-1000,-261,-930,1000,587,-400,1000,-512,-227,-224,-715,1000,317,774,-963,-257,-1000,1000,1000,577,382,220,1000,427,-889,1000,-1000,27,262,1000,384,165,-550,-283,511,786,-351,1000,1000,-213,-264,747,-766,-160,-780,-87,1000,-359,-195,-337,599,-828,-729,-305}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00524() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "insert(int,long):org.apache.commons.lang.text.StrBuilder",
            new int[]{-854,-598,-65,-933,-932,-403,275,158,691,-119,-932,577,-763,-141,240,-927,1000,-169,-373,-43,1000,-1000,822,-665,20,-696,96,-1000,19,112,133,82,-555,351,-942,330,973,-1000,-217,779,-554,-1000,-497,-1000,-551,-14,-51,-661,1000,-202,-588,82,-557,707,-806,-113,-575,-523,577,681,-56,481,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00525() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "isEmpty():boolean",
            new int[]{-644,98,395,-809,761,318,274,892,-876,-913,695,979,883,-568,538,762,409,673,749,-793,515,210,-606,-659,811,159,-933,45,-870,636,768,-818,-928,-643,484,-630,-417,675,819,-305,369,173,242,-808,-3,-528,786,-978,-487,98,-649,-81,-430,865,176,-283,-788,550,477,536,-313,413,-207,565}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00526() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "isEmpty():boolean",
            new int[]{694,-36,269,592,-49,7,-94,-898,388,-837,-1000,-914,-701,-1000,240,-1000,832,-1000,102,671,-272,-253,1000,-711,23,-1000,55,263,1000,505,-1000,1000,235,-565,-774,-258,-1000,-915,1000,647,-1000,-333,-798,325,1000,497,699,-1000,-511,-1000,858,1000,1000,-612,-1000,-307,674,-1000,1000,-1000,945,-35,706,-745}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00527() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "isEmpty():boolean",
            new int[]{-132,-1000,833,237,-1000,-186,566,1000,-617,-75,-657,211,6,-93,340,-508,444,-421,224,-337,126,-935,-120,-1000,-688,-124,122,766,-69,231,-872,-241,637,-660,-454,-13,400,965,-241,197,-42,-258,-182,965,-174,-69,1000,159,1000,-129,-602,-188,8,102,-620,15,-368,110,930,400,153,849,360,527}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00528() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "isEmpty():boolean",
            new int[]{605,-515,939,-946,-241,-498,126,-642,-986,-211,-526,-722,1000,-682,275,264,929,-1000,-974,-989,1000,-190,1000,-754,799,-1000,-722,1000,-1000,1000,-578,-585,-29,-1000,-1000,-917,-1000,643,939,-1000,102,-226,658,-38,165,-1000,-1000,-780,457,-755,-486,999,590,1000,-1000,-598,-1000,-1000,1000,-574,436,1000,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00529() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "isEmpty():boolean",
            new int[]{384,-496,203,-198,-113,729,-307,-901,-1000,-859,-875,-530,-53,-654,331,-299,-56,-179,-490,605,-143,-437,720,294,-656,-763,152,68,575,683,-1000,553,-180,-369,-558,95,-585,-458,901,-797,-802,-929,-1000,-301,1000,155,-554,-774,782,-976,178,1000,-987,-188,-705,126,665,-841,910,-1000,470,-531,442,-893}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00530() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "isEmpty():boolean",
            new int[]{753,-688,665,1000,785,-544,-821,-684,-737,931,-1000,-654,-400,-501,-1000,465,929,294,-1000,411,-248,-751,-1000,-476,-1000,-962,-259,1000,400,1000,-1000,1000,145,-556,502,71,77,-529,460,-278,-1000,-994,1000,1000,1000,400,-544,598,706,-817,488,1000,1000,-400,-176,-179,82,-1000,1000,1000,343,225,494,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00531() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "isEmpty():boolean",
            new int[]{-347,-36,163,1000,-376,928,346,-24,-823,-1000,-539,394,-1000,-656,248,-592,729,-952,1000,663,-775,-363,-24,-883,235,-1000,425,-268,1000,-895,-557,1000,101,-375,267,259,-147,-1000,326,-753,-690,283,-484,349,17,1000,-1000,177,720,-462,939,924,1000,-1000,-662,-108,1000,-958,1000,-1000,156,-37,121,-181}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00532() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "isEmpty():boolean",
            new int[]{-303,-889,320,650,994,493,-316,73,-986,-51,332,72,-504,-270,-273,780,660,-993,-746,-250,642,-856,-276,-510,-540,-149,-140,-500,-81,-597,-422,638,640,-987,934,53,294,-114,737,-140,-1000,-541,63,325,887,931,-845,360,811,-716,-486,834,379,-294,408,-598,-427,563,456,-656,526,901,464,-748}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00533() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(char):int",
            new int[]{-316,539,-1000,237,570,-350,-422,-418,613,-830,432,-357,525,6,771,604,-192,154,-418,146,-103,-163,741,-248,974,223,833,319,-1000,-556,272,735,-1000,932,182,463,464,765,132,-235,-788,777,612,-645,-30,-68,-455,-342,208,161,-202,380,147,-772,838,-348,-278,-94,-450,-60,-768,399,400,872}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00534() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(char):int",
            new int[]{-170,9,-801,802,706,-914,-216,-397,304,165,1000,-12,-1000,-1000,716,759,-519,479,-1000,-286,-493,-568,116,-1000,988,946,667,1000,-793,-1000,-723,476,-1000,-15,501,321,-21,-112,-56,-8,-961,616,-1000,-228,-506,-1000,-1000,-439,1000,53,-266,1000,494,-235,975,-302,-297,-13,-1000,-994,-574,333,-991,-838}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00535() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(char):int",
            new int[]{-581,1000,-518,1000,83,-978,1000,-258,-739,-110,-524,-1000,-984,953,-114,1000,608,232,-457,-281,-693,-457,776,-798,1000,-171,897,-178,-118,-616,-722,1000,-1000,443,-324,861,-664,760,-196,705,-375,80,-1000,-1000,321,-767,-1000,-631,-87,1000,-631,-88,-683,-1000,-78,-518,-192,1000,-385,-1000,75,-843,-366,-348}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00536() {
        org.junit.Assert.assertEquals("java.lang.Integer:MQ==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(char):int",
            new int[]{-481,-757,25,-129,-1000,718,56,-539,-742,-720,-1000,-334,840,557,-1000,-813,374,-554,-114,96,244,725,317,180,-1000,-859,-524,-1000,1000,-151,188,-614,-467,-312,-599,-525,524,643,-97,172,122,1000,372,-386,27,380,-7,-242,180,690,486,-297,-467,-195,-1000,866,-207,1000,2,530,738,-499,984,592}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00537() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(char):int",
            new int[]{-48,812,639,416,1000,-797,-194,400,754,-721,235,200,554,-655,1000,838,-323,758,-350,520,152,-330,1000,94,974,832,597,96,-156,-746,202,681,-1000,1000,-5,306,-107,258,278,-231,-538,758,378,-964,-391,-994,53,-798,18,488,419,199,535,-734,352,-813,395,-409,-617,-280,-813,-117,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00538() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(char):int",
            new int[]{-686,-817,529,-909,825,783,-222,412,598,-629,-701,477,91,-229,-46,714,352,-2,380,891,891,-316,725,-59,-610,858,-399,-68,-788,-311,171,468,-719,-26,-480,-193,244,-521,463,-722,61,-984,861,-811,-833,-886,119,-621,155,519,53,-221,-407,378,-394,-72,11,-53,-26,-764,374,-74,636,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00539() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(char):int",
            new int[]{-601,122,-488,632,12,-980,2,-599,863,88,25,-903,402,-863,-672,440,298,915,-670,833,116,-755,555,-913,143,-489,287,134,-19,-973,-461,412,-865,-38,-387,603,153,850,599,-267,-860,451,-994,-789,426,-237,-629,-615,4,283,-808,372,9,-683,-187,-481,-79,66,-17,-301,-526,-507,-266,-155}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00540() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(char):int",
            new int[]{-540,-1000,164,208,-724,-39,264,-416,170,-187,-1000,-716,722,557,-1000,-107,711,-127,415,402,599,408,458,-244,-498,-56,-120,-710,555,-382,-196,78,-467,-820,-948,261,186,787,492,-316,110,-80,-166,-1000,110,279,235,-642,275,651,-400,-297,-834,-386,115,140,244,542,45,190,21,454,413,594}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00541() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(char):int",
            new int[]{17,-1000,-192,-1000,-1000,-247,-863,-572,1000,959,-890,304,1000,-551,-424,-713,-376,504,457,797,948,175,663,-23,-945,997,-1000,-95,112,744,934,-328,1000,-1000,-813,-706,-8,329,894,-903,1000,-1000,572,-439,9,788,1000,-644,-315,-302,-84,446,-172,-598,-1000,-979,1000,-558,-312,1000,-1000,188,-1000,-396}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00542() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(char,int):int",
            new int[]{-351,-1000,-868,-791,-428,978,319,87,1000,-936,-388,-249,-775,-346,583,12,-1000,212,1000,395,-69,1000,-1000,472,-904,-323,1000,966,-274,-402,307,-327,-250,400,-396,-336,176,-983,589,981,20,-1000,303,448,-2,1000,-1000,-1000,24,527,-643,368,1000,680,1000,434,-29,-74,857,-51,211,1000,739,-44}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00543() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(char,int):int",
            new int[]{-453,123,984,-77,645,-450,930,-54,-323,-739,11,361,-396,-334,777,-337,-39,-34,299,963,760,-122,525,-552,615,724,81,944,-690,-297,-664,243,969,698,-817,232,-273,679,-644,559,-600,899,395,-473,35,451,349,-742,-621,493,-790,-233,383,437,703,501,616,784,553,179,132,885,647,-699}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00544() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(char,int):int",
            new int[]{-1000,992,830,686,1000,1000,214,-31,-608,-516,-36,1000,-144,1000,216,-463,1000,236,-447,82,1000,-501,1000,-1000,913,1000,-833,709,-135,-1000,1000,1000,1000,1000,-1000,1000,-1000,1000,-1000,-1000,22,900,-502,-1000,-792,-861,1000,-535,-1000,-84,431,-779,-55,1000,-162,-417,-405,-47,294,158,-223,-669,-728,244}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00545() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(char,int):int",
            new int[]{-681,-464,593,221,-271,731,-220,234,361,-998,-935,-1000,7,-232,523,-817,-455,992,460,95,1000,341,728,-799,-629,-311,-461,-504,414,-392,-1000,360,-909,560,-552,758,75,1000,-1000,-853,-1000,-370,-413,578,675,-211,262,-1000,-1000,1000,-1000,1000,-626,498,-997,116,94,-325,389,-1000,475,196,210,-806}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00546() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(char,int):int",
            new int[]{-1000,584,1000,-11,41,356,568,141,810,-168,731,129,-995,-626,-275,220,-841,178,-1000,854,431,-738,1000,-104,-642,45,-108,-1000,504,-223,1000,859,885,1000,51,1000,-863,-687,-1000,-1000,73,-420,835,-1000,-458,191,1000,277,27,1000,1000,1000,-598,438,-343,-872,346,-756,-13,70,-664,-1000,-1000,-598}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00547() {
        org.junit.Assert.assertEquals("java.lang.Integer:MQ==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(char,int):int",
            new int[]{286,-1000,-411,208,-394,821,166,462,1000,-373,946,-1000,-791,-929,-514,-426,-1000,-416,1000,82,-282,-169,1000,1000,-884,-1000,194,-434,-825,56,602,72,552,400,401,-1000,499,-827,555,829,-1000,-54,304,-50,-211,-1000,-580,-996,350,740,-512,618,41,258,143,898,-424,-722,877,762,482,-189,-79,-187}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00548() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(char,int):int",
            new int[]{-362,-202,967,166,-946,178,-181,33,-400,46,629,104,-527,11,-647,-378,-833,-1000,486,211,-948,-769,1000,1000,52,389,-762,-1000,454,-163,-573,440,308,-470,393,-1000,-1,-175,1000,1000,-943,-175,-178,512,75,1000,-620,400,17,-511,-15,-270,1000,97,1000,1000,-389,-362,462,1000,284,-389,780,427}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00549() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(char,int):int",
            new int[]{941,-1000,-400,-116,-823,284,-655,743,93,-695,-1000,-583,1000,-1000,718,-692,-812,892,1000,-308,739,678,-774,-16,-373,-190,-433,-80,369,56,-1000,-1000,-998,-341,-1000,-1000,639,-357,1000,-834,-232,-680,-329,1000,1000,1000,-1000,-1000,-1000,332,-1000,1000,610,-501,493,1000,-92,-705,936,-1000,1000,1000,1000,-335}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00550() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(java.lang.String):int",
            new int[]{334,407,-88,-1000,-134,584,154,36,1000,-578,308,179,1000,-261,-426,288,517,1000,-313,993,453,-1000,632,730,-853,-94,524,160,564,-94,511,-37,-683,264,-555,1000,-36,-850,749,-1000,-696,936,834,-110,-600,-672,-283,-167,159,-138,981,1000,927,-591,-350,-208,341,598,-75,429,465,693,344,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00551() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(java.lang.String):int",
            new int[]{-1000,-1000,213,-863,444,420,-957,-598,-15,-362,516,627,470,-198,186,251,-599,370,738,546,-243,756,702,41,-583,1000,-922,1000,748,-1000,503,-712,110,779,-965,564,-925,-465,645,-945,1,225,805,-562,1000,-878,-328,1000,90,-1000,553,76,467,-231,1000,527,804,257,233,1000,-119,963,-1000,137}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00552() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(java.lang.String):int",
            new int[]{-914,36,364,-988,-1000,-726,-523,-392,1000,-156,383,-575,-858,-62,1000,1000,1000,124,-1000,-371,248,-1000,-1000,63,798,328,354,-860,641,1000,-1000,456,-1000,3,-1000,-871,131,529,581,1000,-1000,1000,834,1000,32,-823,1000,1000,1000,294,608,-491,-1000,417,814,1000,-1000,-635,-46,-950,-1000,-1000,-209,753}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00553() {
        org.junit.Assert.assertEquals("java.lang.Integer:NTU=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(java.lang.String):int",
            new int[]{534,-1000,-1000,-302,-432,-1000,-167,-233,568,10,-546,0,-252,1000,-16,479,-314,679,-386,-98,0,-535,-903,171,558,-646,309,-426,185,525,378,589,-714,-289,-825,-69,1000,66,747,-113,-17,314,-797,-962,-455,-105,403,425,108,217,1000,727,-866,45,-620,511,382,785,-352,251,-395,-1000,-993,-514}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00554() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(java.lang.String):int",
            new int[]{836,224,76,1000,-936,-1000,-778,-38,290,613,-402,45,476,958,231,-286,-767,396,-1000,-172,189,-505,1000,597,-1000,-68,161,-1000,1000,-230,-51,11,-1000,-955,-625,-335,935,1000,836,-819,-620,-371,-395,106,-1000,-6,1000,886,-587,-1000,379,1000,84,122,-1000,339,-459,1000,453,462,274,18,-877,95}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00555() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(java.lang.String):int",
            new int[]{1000,-181,-325,1000,1000,430,454,-314,83,-951,758,104,422,-150,-690,-286,-194,396,261,1000,669,-469,1000,-280,-1000,-677,-486,-882,1000,605,-84,1000,-1000,-955,-1000,1000,-583,-1000,352,-1000,284,315,-357,-604,1000,-505,-1000,886,-699,-1000,1000,-914,1000,341,-36,-203,834,729,-1000,748,-794,2,-393,-563}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00556() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(java.lang.String):int",
            new int[]{537,433,697,-836,-158,-603,140,-398,-492,-678,214,-1000,-944,216,-1000,-1000,-474,139,779,-46,316,-264,721,-511,-110,1000,358,1000,36,944,405,395,-1000,-317,-1000,326,-1000,-1000,65,392,46,-855,-1000,-499,655,500,646,-108,-328,-1000,-682,102,-291,-440,1000,-3,365,-142,-1000,204,-1000,-613,-539,117}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00557() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(java.lang.String):int",
            new int[]{416,-1000,-649,-1000,-152,-177,167,-1000,312,-553,284,-349,-877,-805,163,502,1000,-646,81,-26,-113,-1000,-369,-162,294,-56,-913,-86,-107,181,730,631,-92,961,-846,1000,-884,65,-294,845,117,-152,1000,396,1000,-702,181,518,-888,911,422,-320,-78,913,944,-522,-82,-567,-241,-566,-290,-349,-539,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00558() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(java.lang.String):int",
            new int[]{-298,-1000,-1000,-1000,1000,-289,301,-216,641,-993,836,855,1000,-693,-817,4,759,-1000,919,1000,-109,1000,1000,-94,-707,-105,-1000,1000,436,420,1000,-1000,418,1000,245,1000,-1000,-1000,866,-1000,325,762,1000,-1000,1000,-1000,-1000,-812,149,-583,-304,-1000,1000,-846,1000,596,373,-548,335,1000,1000,1000,-1000,-936}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00559() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(java.lang.String):int",
            new int[]{407,479,-766,-1000,-182,1000,210,-561,243,-1000,-52,797,-508,-1000,-512,299,-440,1000,909,513,-119,1000,-676,-338,-46,-966,-369,423,233,1000,-1000,755,-776,1000,-949,1000,-1000,-373,-1000,-256,448,1000,1000,870,1000,432,624,945,689,-295,758,-1000,-636,962,1000,1000,-1000,-1000,690,-262,-1000,-742,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00560() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(java.lang.String):int",
            new int[]{1000,968,-480,-679,-764,799,-1000,-196,917,-97,1000,554,591,942,-641,282,-1000,421,-817,1000,780,398,-136,126,-1000,-1000,-556,-988,1000,133,-1000,1000,-1000,-769,-984,627,34,-980,-1000,-1000,189,-286,988,-70,-1000,950,-1000,1000,414,-1000,936,861,1000,260,-894,934,-1000,974,-1000,1000,889,538,1000,909}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00561() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(java.lang.String,int):int",
            new int[]{-1000,-1000,985,1000,-259,415,-683,400,512,1000,755,1000,-1000,-138,95,373,430,1000,581,-743,-1000,-1000,-931,-400,1000,1000,1000,-798,1000,954,45,734,-1000,151,1000,-646,1000,867,-450,-470,86,1000,193,-958,-628,698,-722,1000,1000,-554,900,688,-1000,-1000,-393,-275,1000,-1000,-1000,-158,-235,-553,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00562() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(java.lang.String,int):int",
            new int[]{-499,-1000,1000,-811,-1000,100,-646,-379,1000,1000,157,587,-396,-142,-532,1000,1000,1000,-218,-106,-435,914,329,-1000,130,-496,-1000,-1000,-1000,-258,149,33,-1000,-396,1000,-1000,583,-1000,-1000,-1000,-382,-629,-1000,709,-57,-267,194,-274,1000,1000,14,1000,-297,-1000,1000,-638,435,1000,398,353,-775,-518,355,411}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00563() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(java.lang.String,int):int",
            new int[]{-850,282,414,-239,-291,-179,-355,399,-862,-301,572,589,-464,-803,-332,-264,-219,-994,428,-18,347,-580,94,-51,-558,-649,-732,-368,-469,305,-973,-427,922,-366,-951,224,-239,-844,-792,640,-465,522,120,-467,-39,-402,-793,80,-988,583,-40,897,752,554,-665,-916,-362,724,-563,-635,995,-182,-994,-2}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00564() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(java.lang.String,int):int",
            new int[]{-551,-1000,-302,1000,-521,-202,601,-1000,36,431,-346,452,1000,-437,409,-637,-34,1000,346,-65,-597,-1000,324,1000,186,-398,-896,59,542,880,705,182,-1000,-770,491,468,784,197,76,-1000,937,131,744,803,-441,541,-155,1000,914,1000,619,-105,-711,-518,-473,753,1000,-230,-794,-535,-1000,-127,-1000,-821}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00565() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(java.lang.String,int):int",
            new int[]{-148,-1000,1000,-889,935,111,169,-555,1000,252,1000,598,-742,1000,860,1000,1000,206,691,-306,-1000,-1000,487,-1000,-54,221,-339,259,620,-77,545,1000,-200,-340,1000,-1000,1000,1000,310,-1000,-1000,1000,-914,-496,-1000,1000,1000,787,1000,-1000,1000,1000,340,-883,-757,233,1000,963,-1000,-1000,-1000,-95,-486,-633}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00566() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(java.lang.String,int):int",
            new int[]{-112,-1000,-808,1000,-60,571,-1000,1000,-388,784,1000,-365,-1000,-1000,-1000,-678,1000,-459,1000,-92,647,1000,-85,-1000,178,1000,119,-1000,-615,-1000,-1000,-1000,302,812,-930,489,-1000,-1000,947,-1000,1000,507,-93,76,1000,-1000,1000,-926,-1000,855,900,821,1000,-667,1000,-995,-382,-1000,1000,97,1000,-1000,857,890}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00567() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(java.lang.String,int):int",
            new int[]{-228,-1000,-866,932,-342,603,-440,205,-571,834,609,-960,-1000,-1000,-1000,-892,857,-483,752,135,682,1000,948,-704,370,400,393,-1000,-233,-1000,-659,-425,70,196,-1000,629,-1000,533,572,-900,942,146,-344,360,1000,-659,542,-642,-1000,143,760,481,974,-755,216,-396,-332,-913,1000,229,-212,-897,777,939}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00568() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(java.lang.String,int):int",
            new int[]{-380,-1000,138,-168,-445,40,-878,-360,1000,1000,354,226,-1000,-674,146,998,-538,525,854,184,-288,682,1000,163,107,788,236,-118,136,-884,-208,469,-581,482,778,-18,-143,25,-1000,-774,-30,535,-1000,92,1000,-211,-813,-602,395,-400,449,1000,-752,-1000,528,-201,580,157,-402,298,-849,-246,-1000,-368}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00569() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(java.lang.String,int):int",
            new int[]{-118,-1000,1000,-1000,670,249,237,-188,1000,252,784,598,-1000,1000,-824,746,1000,333,61,-777,-45,1000,366,-435,66,-24,227,-606,-398,-850,942,1000,-425,319,1000,-1000,126,706,783,-620,-811,-85,-1000,-496,321,1000,365,-989,-939,-1000,828,1000,-23,1000,-375,233,-573,369,17,-135,-323,-879,-486,-633}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00570() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(java.lang.String,int):int",
            new int[]{-696,-1000,993,-237,-1000,249,-242,-555,325,1000,-172,597,-705,-924,-1000,-146,1000,514,-1000,349,-39,1000,-189,-706,271,-1000,-1000,482,-1000,-553,19,-488,-1000,-277,1000,-1000,291,-1000,-1000,-1000,582,-1000,-1000,675,-19,-1000,-105,-661,1000,1000,-675,847,-881,-1000,1000,-771,312,477,1000,111,-1000,-1000,652,781}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00571() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(java.lang.String,int):int",
            new int[]{-739,-185,-93,468,339,-268,247,-1000,765,400,1,-737,954,470,614,-294,441,292,-555,-269,-512,24,915,246,139,898,300,491,-365,485,-38,-430,-449,711,-715,357,83,501,-203,-524,361,154,-114,-1000,-1000,1000,561,852,358,-552,-1000,-1000,637,255,-1000,564,-361,1000,0,302,-183,-214,70,107}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00572() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(java.lang.String,int):int",
            new int[]{-1000,-382,-928,1000,-657,79,1000,-890,-554,2,-364,139,769,-754,835,-1000,-1000,-24,-51,534,-249,-468,-182,1000,745,-158,-287,-759,306,1000,-37,235,-343,-795,23,-399,-628,1000,-1000,17,1000,863,1000,-643,4,621,-313,1000,609,12,-547,-908,-728,222,-1000,1000,1000,-1000,-1000,666,-183,-608,-1000,553}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00573() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(org.apache.commons.lang.text.StrMatcher):int",
            new int[]{118,749,966,-144,-227,-556,383,-794,326,734,817,-733,160,-26,-984,-33,-247,-635,66,-536,-702,133,804,317,795,-279,432,-149,575,-642,-953,638,-643,704,-557,-932,-409,-356,776,-773,147,787,450,-535,166,-284,943,388,-684,-374,-806,-656,604,637,-370,-99,404,-228,-15,-687,435,-670,-405,496}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00574() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(org.apache.commons.lang.text.StrMatcher):int",
            new int[]{526,-816,254,339,244,1000,1000,-283,810,1000,-21,791,160,-1000,202,1000,486,-635,740,-536,152,-1000,28,-580,-611,708,-1000,762,-1000,-642,-1000,-1000,417,-426,1000,510,-528,-1000,1000,-1000,-62,1000,-700,1000,220,-605,1000,881,-684,-1000,853,508,727,-404,1000,1000,-2,1000,-632,-1000,1000,-383,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00575() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(org.apache.commons.lang.text.StrMatcher):int",
            new int[]{137,1000,903,-427,528,-1000,-838,896,-37,-664,-789,-881,899,900,-380,-1000,-1000,1000,719,-1000,654,-288,-627,-50,1000,-703,868,-277,333,107,1000,-51,-1000,-88,-1000,-1000,-1000,-62,849,1000,530,-129,1000,-1000,-1000,377,-962,-354,-145,61,411,139,-577,639,-1000,-1000,-935,153,1000,1000,-626,-761,-1000,-344}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00576() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(org.apache.commons.lang.text.StrMatcher):int",
            new int[]{812,-243,94,418,-970,-421,552,-920,-561,553,-1000,870,689,-316,-704,792,1000,-304,-1000,-192,-1000,-683,1000,1000,-1000,-5,-135,-276,-340,-745,-561,-228,903,-533,919,-344,-382,-1000,1000,-123,-1000,-14,-1000,920,1000,-595,-77,485,-473,-1000,-712,-465,1000,-395,205,-254,-500,-144,-1000,-214,669,153,-57,767}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00577() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(org.apache.commons.lang.text.StrMatcher):int",
            new int[]{422,533,378,663,-587,-406,551,-100,221,-204,53,-502,1000,-164,384,166,971,491,-852,-68,-1000,-455,286,-415,-956,253,1000,-95,-704,-1000,-373,-502,-1000,-509,326,-1000,-118,-1000,581,302,-957,169,-133,-113,808,-484,-882,511,-64,-775,-1000,162,488,-345,-854,-206,-168,1000,-1000,350,561,-727,-772,402}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00578() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(org.apache.commons.lang.text.StrMatcher):int",
            new int[]{1000,-70,542,-244,-910,-83,820,-1000,900,1000,91,-434,-361,-749,243,264,526,-1000,-226,239,194,-1000,697,702,354,-385,-1000,-983,-1000,-478,-1000,-1000,1000,-309,1000,-197,1000,-1000,1000,-1000,-1000,1000,-855,621,100,-381,1000,229,-1000,1000,963,638,385,360,1000,-45,-175,1000,128,399,607,1000,696,622}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00579() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(org.apache.commons.lang.text.StrMatcher):int",
            new int[]{373,875,976,-123,-429,464,222,-846,294,921,272,-213,386,-318,-496,-72,127,-745,-24,-710,-791,-207,106,315,256,-497,175,-295,103,-696,-967,146,-150,-876,-90,-867,-529,-549,843,-841,-197,1000,-120,-74,1000,-370,871,572,-942,-562,-265,25,723,631,-990,231,-155,129,-643,-781,604,-769,16,280}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00580() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(org.apache.commons.lang.text.StrMatcher):int",
            new int[]{1000,299,863,335,132,1000,77,1000,-529,-139,-1000,1000,-598,-660,-103,1000,1000,-123,-758,313,-1000,-523,83,271,-1000,-371,431,1000,449,294,55,-217,-733,-756,1000,589,1000,-239,-973,-442,-927,-58,-171,677,-562,46,-1000,747,21,-1000,971,-396,-351,-754,844,1000,-691,31,-1000,-1000,683,-1000,1000,380}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00581() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(org.apache.commons.lang.text.StrMatcher,int):int",
            new int[]{-405,308,-499,-184,-259,-785,688,-822,1000,-415,31,-198,-92,-1000,-1000,-1000,257,-289,384,13,67,-626,1000,367,-279,529,1000,724,-78,-798,-1000,590,-66,637,446,1000,291,-259,1000,502,248,-146,-98,636,193,486,-157,1000,143,-540,226,629,-402,172,580,-1000,560,653,20,1000,-965,-921,-553,-56}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00582() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(org.apache.commons.lang.text.StrMatcher,int):int",
            new int[]{-1000,-210,304,-338,-120,976,-278,736,852,406,-440,751,1000,-1000,823,741,-542,1000,471,-194,-213,-1000,-955,-583,1000,330,-1000,-1000,-1000,1000,1000,-119,-295,-584,1000,-1000,-999,1000,-614,1000,424,-428,-316,1000,-19,478,-569,-1000,-1000,642,-1000,-98,-755,770,1000,693,-597,827,-621,-1000,-604,255,-108,-723}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00583() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(org.apache.commons.lang.text.StrMatcher,int):int",
            new int[]{1000,559,-551,-827,708,-308,713,-937,678,1000,240,120,106,-574,-100,1000,323,-1000,903,-55,1000,-671,-672,-422,-60,-583,-361,-487,-343,379,1000,862,-129,-348,701,296,778,1000,980,102,8,-10,-347,434,1000,813,272,-778,403,952,-362,-753,-143,921,1000,189,-1000,-256,-1000,318,-1000,-407,311,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00584() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(org.apache.commons.lang.text.StrMatcher,int):int",
            new int[]{-945,248,220,120,-265,587,-161,-664,4,-744,-334,567,577,602,-332,-823,-812,-11,-414,229,673,-520,-211,-254,-472,641,-75,586,-569,-550,-543,211,371,-428,557,455,-736,-944,416,708,253,-106,550,-140,217,-167,-627,821,-522,-701,974,450,-849,-600,-164,-660,-863,-427,27,53,386,-367,333,-880}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00585() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(org.apache.commons.lang.text.StrMatcher,int):int",
            new int[]{-907,163,369,-219,-946,1000,326,-1000,313,-565,-696,416,1000,43,-732,-1000,-1000,-568,-3,213,444,-1000,-1000,-950,-1000,1000,573,-982,-42,-234,760,552,559,-1000,1000,1000,-98,-905,1000,1000,581,-173,121,-398,-332,-309,-1000,1000,-853,-1000,877,1000,-885,-482,-979,-762,-768,-547,-654,368,685,-1000,494,-869}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00586() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(org.apache.commons.lang.text.StrMatcher,int):int",
            new int[]{770,386,-287,-460,125,-101,249,-947,547,653,462,713,333,43,-200,595,-184,-1000,473,170,-618,-659,-120,-243,-743,-703,-118,53,-42,132,760,310,-216,-764,1000,697,410,335,1000,395,359,-669,121,-365,-414,167,12,-236,117,762,877,-446,-885,-199,694,-133,400,823,-1000,613,-1000,-22,264,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00587() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(org.apache.commons.lang.text.StrMatcher,int):int",
            new int[]{-373,-475,297,34,305,447,-507,-453,-825,-508,439,898,-827,-631,142,595,-647,290,-75,-152,229,667,63,199,426,668,-893,53,224,-286,-922,-490,-216,325,172,-266,-956,-519,-891,395,620,-933,-121,664,361,916,246,-323,663,-554,90,-533,-885,-35,439,890,-387,-655,866,-701,681,-53,-190,-607}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00588() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "lastIndexOf(org.apache.commons.lang.text.StrMatcher,int):int",
            new int[]{-833,371,-368,-536,-6,-871,782,-368,-437,-1000,781,887,-1000,-1000,-972,-449,728,734,-707,357,42,-722,926,-84,603,1000,-289,-1000,709,179,-1000,-889,-242,122,24,1000,13,-188,92,340,219,-913,-95,838,88,1000,598,-628,1000,897,-1000,-1000,-350,155,431,1000,791,501,1000,107,-622,-456,8,979}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00589() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "leftString(int):java.lang.String",
            new int[]{-1000,-1000,-1000,-1000,-328,215,-776,274,-1000,-1000,-1000,-981,247,435,474,-423,1000,-191,-134,1000,-1000,-350,-79,-183,470,-376,816,-1000,1000,-1000,-1000,-1000,-1000,-479,1000,124,-713,733,-1000,-1000,1000,529,183,372,-628,-756,483,-420,938,-1000,-985,1000,-1000,1000,-405,-1000,-662,1000,1000,588,573,491,-1000,486}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00590() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "leftString(int):java.lang.String",
            new int[]{-247,333,-211,358,922,903,910,600,-603,877,-824,217,102,750,-620,-220,744,-752,442,402,961,750,465,-314,-240,107,613,-918,-171,-334,970,681,140,667,974,-191,850,808,-638,-743,-991,-248,-393,-88,-192,620,799,705,175,104,616,293,-569,725,577,-295,-596,-11,142,-706,-111,716,-641,762}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00591() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "leftString(int):java.lang.String",
            new int[]{-436,-1000,321,-1000,353,448,-641,-463,-776,-1000,-849,-400,-985,-1000,912,-784,499,-508,611,442,-1000,400,-1000,-1000,-712,-626,-14,330,1000,-1000,-726,-1000,561,28,-931,1000,-1000,1000,-522,183,1000,906,-339,544,-823,-1000,812,480,-109,-1000,-37,778,-616,304,-493,-1000,54,1000,1000,1000,1000,1000,-1000,-96}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00592() {
        org.junit.Assert.assertEquals("java.lang.String:GA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "leftString(int):java.lang.String",
            new int[]{167,-1000,410,179,-527,-376,-91,696,84,-27,-705,-458,-722,-172,-639,-624,19,792,-428,926,507,-291,-215,663,159,173,1000,-388,-1000,-1000,-92,-522,11,30,-400,1000,-599,618,1000,784,-970,676,-139,-640,-907,-219,-33,-476,-48,-794,323,298,-996,884,-1000,150,472,-838,187,1000,521,-798,786,-57}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00593() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "leftString(int):java.lang.String",
            new int[]{64,-1000,596,-1000,40,41,-603,997,-446,-802,125,542,-177,-1000,402,-314,-182,-818,492,649,-532,-452,-815,-440,-1000,-148,-541,1000,631,-459,-689,-3,380,151,-487,-345,-989,-598,-397,773,429,632,-496,-139,-192,-963,265,-594,620,-1000,-587,213,602,1000,1,-797,128,574,667,-320,221,-784,444,-454}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00594() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "leftString(int):java.lang.String",
            new int[]{-667,-500,-1000,-132,324,432,-876,-239,-159,-1000,-1000,-1000,1000,674,474,-1000,901,-191,652,767,-1000,-198,-79,-1000,1000,-1000,-555,-1000,-170,-1000,0,-1000,-444,-472,1000,-177,-990,1000,-1000,-1000,1000,-68,-235,300,496,97,590,365,161,-356,-1000,1000,-1000,1000,-675,-642,-443,961,1000,1000,321,491,-1000,939}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00595() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "leftString(int):java.lang.String",
            new int[]{1000,-286,-30,813,289,579,-703,341,1000,-536,384,1000,934,1000,-1000,-664,-1000,-1000,2,-1000,-638,-492,957,-727,-803,-875,40,1000,-1000,-60,196,-491,-373,1000,657,-1000,-847,201,1000,644,-112,-1000,-761,-602,863,950,548,-248,-379,471,-769,-264,-370,492,222,1000,1000,334,581,655,-1000,-1000,1000,203}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00596() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "leftString(int):java.lang.String",
            new int[]{-880,-1000,832,-1000,-1000,-126,-1000,462,-607,-1000,826,392,-559,-1000,148,743,601,-890,-649,356,-952,-905,-939,315,-1000,462,-1000,279,-265,28,-1000,453,-359,-713,-377,379,-1000,583,-13,651,891,245,392,1000,-1000,-1000,-729,630,1000,-1000,-468,1000,343,80,-351,-1000,914,1000,414,632,1000,-858,-567,466}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00597() {
        org.junit.Assert.assertEquals("java.lang.Integer:MTAwMA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "length():int",
            new int[]{-216,-664,-574,226,138,594,104,-36,-388,938,329,632,1000,765,-163,1000,11,-217,-1000,-204,1000,-405,-105,689,18,-910,447,-326,-7,-363,456,-636,-643,1000,1000,753,-655,1000,33,-680,-344,842,1000,-356,1000,879,-753,-538,-631,334,464,-543,-11,1000,796,177,-87,680,1000,220,774,13,45,517}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00598() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "length():int",
            new int[]{-724,-243,319,995,-1000,-223,-136,-84,61,1000,-33,156,815,50,-475,-1000,-49,-636,-490,-970,469,450,-1000,1000,-1000,1000,-237,-463,1000,-23,-1000,602,-226,422,-1000,1000,359,1000,615,-54,717,27,754,-511,378,888,-349,-700,-376,494,1000,1000,1000,-97,-915,541,-207,712,1000,65,915,-127,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00599() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "length():int",
            new int[]{-1000,-1000,817,527,242,494,1000,34,97,1000,-463,-409,1000,1000,185,389,-42,-931,263,522,-252,-173,-1000,1000,1000,-1000,1000,-1000,4,801,530,-1000,-1000,-1000,403,968,838,814,-679,-450,524,-6,466,2,1000,1000,-1000,-398,-1000,1000,-175,-1000,1000,1000,663,1000,-165,1000,1000,-49,1000,-1000,-100,493}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00600() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "length():int",
            new int[]{243,574,-405,-420,59,282,44,584,710,1000,64,864,924,952,677,-816,124,471,-746,-1000,1000,1000,-1000,966,-1000,899,-485,-1000,238,-738,-680,-507,-614,315,-527,1000,-204,906,1000,-986,1000,356,237,510,1000,1000,-356,-911,-446,992,750,-130,1000,213,-641,655,193,-122,344,946,214,442,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00601() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "length():int",
            new int[]{-948,-1000,1000,-993,-62,480,44,507,261,235,-394,236,-19,-934,362,363,-157,-580,-317,1000,-837,-1000,-1000,130,377,-45,469,-1000,1000,1000,-999,-442,-613,-400,-161,184,318,954,-1000,1000,-1000,81,111,-644,-509,945,-1000,-735,-7,-833,508,-130,1000,631,372,655,-713,942,1000,-959,849,-312,177,571}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00602() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "length():int",
            new int[]{-1000,-1000,214,215,-62,472,519,-954,239,235,492,-424,658,-842,18,1000,842,-1000,-990,666,-393,-883,-1000,-681,1000,-988,1000,-950,1000,862,-1000,-337,-613,-490,-161,1000,683,960,-649,206,-570,92,651,-553,675,1000,-1000,-692,-7,-360,78,-188,220,1000,622,568,-749,1000,1000,-959,1000,-874,177,-743}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00603() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "length():int",
            new int[]{-1000,-1000,80,-23,612,804,675,599,531,992,-677,885,880,-979,147,-130,868,-881,-337,144,76,199,-466,970,539,-503,445,-1000,305,352,676,388,-1000,-347,-250,1000,-430,972,-404,-604,290,1000,-654,159,956,1000,-1000,-667,-1000,493,1000,-766,1000,943,204,1000,-864,960,670,-633,-322,-436,-260,847}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00604() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "midString(int,int):java.lang.String",
            new int[]{319,419,-466,907,-555,-285,-137,207,155,825,453,-806,304,-941,-589,228,468,284,683,400,-456,613,-84,-341,-222,1000,-598,-724,695,-883,763,83,-1000,-1000,-779,1000,1000,399,-1000,1000,-1000,492,1000,-86,-769,-974,-297,1000,-1000,78,-112,-235,-1000,-1000,-455,-4,-170,-465,-628,-1000,-727,-181,-1000,900}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00605() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "midString(int,int):java.lang.String",
            new int[]{-357,-828,-441,915,342,92,-858,-194,928,973,-1000,49,-1000,-1000,-505,-2,26,1000,-987,-203,-924,298,-291,-281,950,-1000,-1000,1000,-104,82,-1000,1000,1000,1000,-716,-1000,-1000,1000,-237,88,-797,-59,649,-223,-1000,-995,83,-492,205,-296,1000,-410,-1000,1000,-956,1000,-643,-630,-322,-1000,521,-38,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00606() {
        org.junit.Assert.assertEquals("java.lang.String:AA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "midString(int,int):java.lang.String",
            new int[]{-1000,-851,-476,-831,-376,-566,-336,21,-1000,229,-122,1000,781,-550,-678,-234,-868,-363,419,-23,-924,539,1000,-1000,151,1000,-504,-1000,960,39,934,400,-1000,-395,634,1000,168,-496,-1000,-290,-113,-400,1000,141,-645,509,-289,1000,-137,391,-452,-73,651,59,-853,-79,-34,-536,307,1000,-1000,162,855,-994}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00607() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "midString(int,int):java.lang.String",
            new int[]{-1000,-1000,-403,239,-180,-1000,-496,-1000,121,-805,-270,1000,-974,-685,-663,-1000,-242,1000,517,-1000,69,136,400,-1000,704,-992,-1000,-65,1000,-1000,-400,182,-138,1000,1000,375,-541,-1000,-1000,-799,-400,254,720,-414,287,81,-303,209,400,618,1000,-453,83,254,-969,1000,65,-261,-1000,-1000,1000,789,-1000,-614}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00608() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "midString(int,int):java.lang.String",
            new int[]{-247,-1000,-822,551,461,29,209,-356,-161,659,357,77,402,30,-638,-722,-154,116,667,-795,-590,898,-664,-284,873,110,369,-616,242,292,736,-658,-395,-300,564,-207,-861,-604,97,312,738,1000,-498,595,49,1000,-999,206,-94,-273,365,-115,913,-749,437,-426,443,-88,613,-104,-533,639,-35,-735}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00609() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "midString(int,int):java.lang.String",
            new int[]{154,-769,453,992,-27,116,743,-376,-911,638,-965,-273,1000,52,-721,-709,121,-269,1000,-857,-1000,1000,-793,-571,159,1000,870,-1000,553,-765,1000,-1000,-1000,-1000,1000,598,1000,-993,-402,-178,908,1000,464,1000,11,408,-1000,1000,261,-590,-415,412,1000,-1000,780,-1000,810,-360,1000,897,-1000,657,1000,-842}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00610() {
        org.junit.Assert.assertEquals("java.lang.String:AA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "midString(int,int):java.lang.String",
            new int[]{-1000,-691,-672,-615,-798,-914,-793,-27,457,347,-348,1000,-338,-261,-546,-110,-1000,440,-490,296,144,-534,1000,-632,266,-863,-1000,63,-32,1000,-1000,1000,400,400,899,-292,-173,247,-807,-136,-1000,1000,765,-1000,-1000,211,-1000,248,204,794,116,-868,1000,1000,-1000,1000,-1000,-616,-1000,-328,400,-410,-608,-49}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00611() {
        org.junit.Assert.assertEquals("java.lang.String:Mw==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "midString(int,int):java.lang.String",
            new int[]{-1000,-1000,-781,834,-74,-869,291,411,-1000,-957,1000,853,658,-743,-1000,-1000,-1000,127,972,-1000,-1000,966,-6,-902,186,404,39,-1000,27,-169,1000,-1000,-498,-1000,947,-575,-1000,-1000,-1000,-217,943,1000,690,766,-1000,-54,-1000,720,-219,-771,696,193,1000,-1000,4,801,221,-616,1000,1000,-1000,1000,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00612() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "minimizeCapacity():org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-1000,841,292,-1000,403,649,1000,-85,-111,-1000,1000,788,-383,-853,273,-37,-1000,-1000,-1000,-8,-425,-285,1000,-1000,98,-1000,365,-197,-1000,-1000,-1000,-173,589,456,-1000,983,229,1000,819,-481,600,1000,63,1000,-241,-1000,-760,-70,1000,-1000,504,1000,1000,1000,-1000,-614,517,497,687,1000,1000,424,265}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00613() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "minimizeCapacity():org.apache.commons.lang.text.StrBuilder",
            new int[]{993,885,-976,-949,744,-74,-676,406,-409,737,706,67,-50,-448,-181,257,208,-615,-599,-947,-957,117,-889,-97,652,-952,-33,-716,-340,-257,276,183,-973,-838,-652,-573,-930,62,-943,991,912,-570,360,-613,-898,324,236,981,-70,-96,218,670,58,670,656,713,493,965,-807,-254,-384,652,-496,971}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00614() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "minimizeCapacity():org.apache.commons.lang.text.StrBuilder",
            new int[]{-98,-391,370,1000,-1000,-156,414,399,969,637,236,698,953,233,-1000,-448,-1000,1000,-762,-102,-836,-1000,912,-451,-300,222,-1000,604,-262,407,-1000,-492,649,182,744,-1000,-466,950,-1000,-561,-1000,725,45,-299,-394,-1000,-440,-1000,36,-358,-394,-119,289,-535,-1000,-713,-1000,732,-818,-996,-66,667,622,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00615() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "minimizeCapacity():org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-128,-107,239,958,-477,286,-1000,680,-1000,-146,-1000,575,-993,663,-658,-358,0,0,588,-593,-563,-609,8,279,-765,-812,622,0,479,1000,1000,581,-663,0,269,191,60,-388,642,-1000,-608,0,105,-343,940,-642,-25,-278,-492,343,65,-331,0,0,991,-1000,-519,20,473,-458,-557,0,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00616() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "minimizeCapacity():org.apache.commons.lang.text.StrBuilder",
            new int[]{-135,-1000,304,-31,469,-138,334,576,438,-78,-1000,1000,50,-1000,-1000,300,22,-1000,-388,-17,9,-1000,-597,1000,-1000,-237,-1000,-324,142,-717,118,-1000,-546,-718,-325,-190,81,193,1000,-229,-930,95,978,589,266,297,-830,79,-369,444,-611,-439,733,915,369,487,-220,82,-20,53,1000,121,546,-154}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00617() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "minimizeCapacity():org.apache.commons.lang.text.StrBuilder",
            new int[]{-416,-1000,557,1000,-403,1000,-596,562,359,-433,-886,417,-131,-1000,-555,-782,-228,-297,-756,637,-65,-651,-186,-108,-1000,-138,-467,1000,-159,472,364,-473,-1000,-38,378,1000,1000,79,-488,191,-177,396,-228,-339,-754,-234,-577,-765,-1,71,394,-246,-152,92,938,-509,-1000,-855,329,487,478,499,327,-773}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00618() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "minimizeCapacity():org.apache.commons.lang.text.StrBuilder",
            new int[]{-37,-169,779,226,-494,-114,-311,73,425,-787,281,1000,623,540,621,743,-409,861,-654,-774,108,-411,228,-907,-130,-1000,-745,961,-337,745,-761,758,409,-108,703,-699,274,597,-473,-682,-62,960,694,-683,-260,-409,-664,-333,718,16,884,775,-1000,-717,-443,-173,63,364,439,752,-662,599,743,-654}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00619() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replace(int,int,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-678,-1000,-667,619,500,-360,-551,767,1000,-1000,497,1000,86,511,-1000,923,-130,939,-1000,1000,126,883,-1000,-647,1000,-280,238,1000,385,-1000,-1000,112,878,1000,-774,722,1000,-1000,-618,-59,-100,-1000,252,143,-1000,940,-616,1000,-351,280,694,975,1000,-1000,-2,1000,-656,-123,1000,26,-63,254,271,-103}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00620() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replace(int,int,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{507,1000,-527,301,-156,918,1000,-1000,-1000,179,-1000,-633,-926,-659,306,-652,469,275,482,-606,-17,126,190,-546,206,-87,-1000,-812,-370,-336,-360,-1000,140,323,-153,-21,50,-765,-1000,994,592,82,202,16,300,-304,745,613,-138,-816,-363,-487,241,-838,-1000,245,728,-435,347,-1000,520,-788,-499,595}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00621() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replace(int,int,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{340,534,-708,312,385,594,684,-143,113,-142,-482,1000,-1000,126,-699,-40,452,17,-709,686,756,-845,-740,5,94,225,-1000,310,-122,-587,-260,901,-49,770,-446,-373,-132,-510,-33,594,384,112,41,866,-1000,167,-466,658,-567,-1000,-77,30,160,-852,-1000,1000,-46,637,1000,-782,-30,-191,-473,403}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00622() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replace(int,int,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{77,704,558,9,865,-195,756,60,-250,-198,-651,-466,-483,816,-444,-917,-180,6,-9,-769,454,-864,-576,-843,-88,-514,-927,259,75,-1000,-1000,-1000,856,-481,-581,-222,-300,527,-820,358,993,-379,-8,-318,460,-771,1000,158,-5,138,-1000,-23,-854,-298,149,-151,521,806,475,-657,917,-1000,-1000,475}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00623() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replace(int,int,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-426,491,817,-761,407,-28,221,997,-38,-685,-472,-343,-478,1000,-432,-839,187,-936,-300,-544,1000,216,-992,-529,263,-235,-386,1000,75,-1000,-1000,-675,966,-927,-1000,-564,-174,336,-211,206,979,-885,-473,-549,-303,-828,120,-73,478,474,298,382,-166,555,190,-612,620,288,-587,689,47,-141,-408,-4}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00624() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replace(int,int,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{162,1000,-90,-43,-777,932,1000,25,-399,-891,-624,591,-1000,1000,243,-1000,645,-1000,269,202,-96,-901,48,-109,-715,895,-1000,413,-799,-933,-924,-1000,-654,410,-1000,823,-296,419,-1000,1000,1000,145,47,1000,1000,-489,161,313,147,-1000,971,-1000,-6,631,-550,41,950,1000,-27,-1000,224,472,-520,439}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00625() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replace(int,int,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{25,-1000,-432,504,869,817,-1000,-523,1000,95,1000,1000,1000,-15,-674,1000,467,918,-1000,-31,-447,1000,-419,-909,667,-629,1000,831,460,218,-110,566,-989,938,492,696,-399,-1000,232,-690,-762,-1000,-21,-333,-1000,2,-24,1000,-123,645,-1000,-24,122,-1000,-716,867,-1000,-1000,1000,533,757,-170,349,805}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00626() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replace(org.apache.commons.lang.text.StrMatcher,java.lang.String,int,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{590,614,-193,473,-461,30,-59,-1000,1000,809,-1000,-261,-720,153,-668,511,-81,832,-46,352,-93,1000,-890,207,-258,117,871,-611,-528,32,712,36,-944,150,475,684,-910,725,-1000,610,1000,207,280,-93,-878,105,684,373,585,-85,430,-17,-1000,1000,269,-653,-502,-447,1000,1000,-111,420,-639,329}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00627() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replace(org.apache.commons.lang.text.StrMatcher,java.lang.String,int,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-356,24,797,341,640,111,-1000,-93,-529,-345,20,1000,470,-840,198,-662,25,245,-582,-16,-1000,-821,-221,952,649,607,-287,79,-392,-1000,615,-500,-403,-1000,-633,-1000,-1000,806,400,1000,-1000,-101,-12,471,-1000,401,-713,454,705,302,328,61,1000,-355,-1000,-218,1000,504,904,-224,-1000,640,-606,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00628() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replace(org.apache.commons.lang.text.StrMatcher,java.lang.String,int,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{206,202,212,246,219,-599,-188,-992,443,-301,-767,1000,-558,932,591,102,-858,1000,301,1000,-884,744,-581,235,1000,444,784,-132,-1000,-984,131,-757,-1000,-1000,207,117,-879,1000,-1000,1000,1000,71,227,525,-19,1000,-398,907,419,-929,856,-109,2,972,847,-937,-651,412,915,133,-297,655,-687,-204}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00629() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replace(org.apache.commons.lang.text.StrMatcher,java.lang.String,int,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-436,-472,-554,-712,-379,705,-52,974,1000,-635,27,-1000,-803,153,582,1000,-1000,-679,-46,-1000,-1000,-948,-958,1000,834,734,-253,917,314,400,-1000,933,133,180,-1000,1000,760,-368,627,160,1000,1000,63,827,-878,169,-847,-1000,1000,-1000,-851,-87,-647,185,-924,1000,-10,-656,-448,-492,-8,420,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00630() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replace(org.apache.commons.lang.text.StrMatcher,java.lang.String,int,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{560,-607,312,-284,-576,-696,-538,177,-379,-415,741,970,613,1000,650,-1000,-586,459,991,493,552,-800,131,213,-53,379,-569,251,-379,-268,41,-540,-931,-449,-280,-1000,111,16,27,625,-1000,-868,-77,209,192,-437,-1000,-84,665,312,-19,-440,743,-462,-389,237,920,473,-561,-799,521,513,-208,-490}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00631() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replace(org.apache.commons.lang.text.StrMatcher,java.lang.String,int,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-306,65,-1000,-662,-461,-595,738,-241,64,47,-687,-410,-414,349,897,1000,-730,357,-90,1000,245,744,-890,-59,1000,117,-715,512,-1000,32,-1000,293,-48,371,475,1000,521,14,-706,135,1000,90,318,605,349,105,-604,348,585,-979,245,-17,-175,738,847,-171,-1000,-447,-433,378,622,-485,438,366}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00632() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replace(org.apache.commons.lang.text.StrMatcher,java.lang.String,int,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{3,-1000,-817,-1000,-194,-1000,458,962,-123,-986,1000,-151,-349,1000,708,-218,-361,-941,813,-907,595,463,-469,-260,1000,-437,-1000,1000,280,-268,-1000,585,7,-285,1000,-74,1000,-1000,1000,1000,400,-799,898,28,1000,209,-934,-949,778,-610,1000,-1000,-64,-1000,-730,1000,370,-851,-1000,97,953,-887,1000,-43}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00633() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replace(org.apache.commons.lang.text.StrMatcher,java.lang.String,int,int,int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-632,-322,704,-501,-920,19,-695,537,-173,-150,483,205,-145,431,387,414,-768,-603,-500,228,-981,896,-904,526,727,21,290,174,-589,-853,-733,481,377,-593,510,239,-85,503,990,526,741,359,182,645,904,659,-510,40,792,-739,236,-135,575,-348,-329,-22,-78,-831,-300,574,-830,-478,915,422}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00634() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceAll(char,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-719,-1000,-821,-1000,503,-412,417,-318,890,419,-721,-595,-904,-613,178,-588,-1000,55,-591,705,-1000,-970,-1000,-1000,1000,-830,1000,-1000,-1000,-1000,-526,284,-1000,951,1000,727,-1000,1000,613,-1000,-1000,1000,-760,588,-285,440,423,11,1000,-47,350,385,249,-852,304,-328,963,828,1000,1000,-691,-932,1000,-155}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00635() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceAll(char,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-631,132,-26,-170,156,-260,640,577,-533,162,138,-217,1000,-1000,518,1000,630,-247,-1000,-183,-147,-252,-70,400,483,-600,275,239,205,489,207,-26,180,-159,-46,474,484,595,236,253,282,-454,-818,479,52,754,1000,-1000,-360,-65,171,-1000,372,63,669,-80,-813,441,-465,224,32,573,-59,-411}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00636() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceAll(char,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-150,-1000,422,376,-474,612,-726,-114,-532,-791,138,166,-251,-1000,486,27,-1000,221,-663,-808,-122,959,-828,-441,-12,-860,632,-78,-808,-550,133,33,-705,1000,-73,749,-581,276,532,-427,-248,291,-195,492,-500,1000,-568,-38,1000,39,171,-824,516,-897,-273,557,821,1000,638,192,-676,-1000,1000,70}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00637() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceAll(char,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-1000,-943,-12,377,-434,-846,637,-1000,166,1000,100,612,-1000,-371,1000,-1000,1000,-1000,408,-1000,-94,-1000,1000,1000,-1000,1000,614,-1000,-223,-177,-1000,-267,706,415,1000,-1000,1000,88,-918,289,1000,-1000,1000,-966,1000,1000,257,1000,-152,1000,-1000,1000,-1000,-310,1000,146,471,226,-323,-1000,-682,1000,580}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00638() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceAll(char,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{62,-491,143,-252,-211,-356,196,-256,1000,430,304,874,198,-506,-101,288,-127,-830,-926,95,-172,-608,-648,-1000,-721,-568,1000,326,-314,400,-450,-567,-663,338,172,736,-80,138,250,-368,-283,-215,-731,-316,-28,-180,249,1000,310,237,506,712,644,893,-941,-196,1000,275,144,359,-874,140,-738,-245}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00639() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceAll(char,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-668,-1000,-1000,-567,324,-400,-286,277,-1000,456,734,234,-512,-1000,614,771,-1000,500,-674,826,-1000,-181,-894,184,1000,-651,550,-1000,-1000,-258,428,-1000,-148,473,-54,830,177,1000,282,-489,98,630,-457,1000,901,1000,388,938,1000,-621,1000,-1000,703,-1000,-885,1000,312,-707,114,-583,-1000,-1000,1000,507}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00640() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceAll(char,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-396,-1000,-1000,451,894,1000,-528,677,461,45,-91,-711,-1000,-807,879,-341,-1000,-886,-964,1000,-638,-1000,-502,-342,1000,486,1000,-405,-1000,-1000,572,-656,-1000,-482,663,371,-362,1000,1000,-423,-1000,785,-1000,1000,234,-9,193,1000,1000,-621,330,497,661,-241,-397,98,1000,-746,57,1000,-867,-984,1000,-338}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00641() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceAll(char,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-870,-685,-144,-432,1000,9,220,1000,404,947,304,1000,383,-818,750,158,-1000,-312,-1000,63,431,90,-14,-634,325,690,405,-213,658,98,1000,-501,-606,-593,-2,139,-129,290,1000,562,-144,665,-1000,1000,-1000,1000,1000,1000,1000,-1000,-120,-413,739,-837,-507,723,-194,276,-920,340,-1000,-1000,714,-578}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00642() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceAll(java.lang.String,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-97,285,745,862,-794,-7,965,1000,1000,37,-197,-670,-754,-223,-58,-874,1000,927,22,-113,843,55,-1000,1000,787,111,-509,-880,683,1000,-1000,332,152,-373,87,-754,-1000,-173,1000,263,-413,-608,-714,-42,274,-701,367,1000,290,-499,363,184,328,-916,881,-802,1000,-1000,-640,-614,-33,282,132}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00643() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceAll(java.lang.String,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-301,955,-227,691,-738,497,354,334,504,-388,1000,208,206,-131,584,-529,362,143,1000,1000,893,1000,-844,-619,623,-131,894,-471,-469,963,707,-507,650,337,-359,-921,278,47,445,678,-783,-876,-443,76,-464,239,38,-21,882,98,516,-302,828,-8,17,421,-1000,580,1000,626,-918,192,523,-437}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00644() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceAll(java.lang.String,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,39,314,779,-47,-735,-1000,-659,-491,204,-770,1000,-757,-162,858,-4,-244,550,-1000,148,684,629,-613,1000,-1000,-994,99,-154,807,-782,974,362,-885,92,-220,-935,-315,-437,1000,250,337,512,112,-404,1000,415,255,110,186,-694,-723,247,704,-1000,-50,-282,1000,-507,1000,66,-840,955,-274,-319}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00645() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceAll(java.lang.String,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-1000,1000,1000,157,949,-558,391,1000,312,1000,-568,-947,-949,-816,-529,-429,-372,1000,1000,834,858,-493,-1000,847,720,1000,-759,-890,203,129,-76,1000,446,-591,44,-30,-324,133,1000,303,-1000,-1000,-699,-1000,1000,92,1000,1000,98,201,329,-653,-1000,482,1000,-1000,910,956,-774,-333,-475,505,-73}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00646() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceAll(java.lang.String,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-1000,1000,1000,1000,-965,-724,219,1000,583,326,-567,440,-967,-1000,-247,-539,1000,747,-274,-3,-733,-833,-304,1000,1000,1000,-536,-213,341,1000,-1000,1000,773,-1000,1000,-626,-1000,-99,1000,1000,-240,-1000,514,-1000,1000,-1000,1000,823,1000,739,1000,1000,-129,162,976,-1000,1000,-16,-1000,-360,-692,1000,217}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00647() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceAll(java.lang.String,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{308,497,-410,1000,620,-424,-72,572,732,32,911,-606,-974,-557,109,186,-7,966,1000,-121,599,983,-416,-819,863,92,13,-545,-919,402,699,-1000,1000,375,-129,-549,-960,47,-287,883,-106,-843,-1000,-74,-460,-344,-665,-261,1000,551,-291,216,154,517,-33,378,-837,1000,230,35,-1000,334,183,296}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00648() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceAll(java.lang.String,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{992,-58,-691,916,-396,671,993,-903,-557,-240,278,-798,-398,-522,691,323,33,-445,-757,-421,886,522,-215,78,67,-696,558,-457,652,-400,-995,961,-53,135,-80,-808,291,961,-966,-407,6,-371,-722,400,-700,-714,-890,-127,380,-454,-456,10,-449,291,816,-974,-335,523,985,727,-94,794,-823,397}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00649() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceAll(java.lang.String,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{319,-1000,-1000,-1000,294,-174,-1000,1000,-663,-1000,1000,-275,1000,-339,-1000,-101,-1000,-1000,1000,-1000,1000,-1000,120,686,1000,1000,230,-868,-193,1000,-103,182,1000,737,881,1000,-168,-177,1000,786,-207,-1000,-854,572,196,824,-575,1000,423,99,-121,1000,-238,-1000,625,-584,-1000,-254,-70,-739,1000,-1000,-619,659}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00650() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceAll(java.lang.String,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{610,-850,-358,41,-738,-312,-301,851,389,92,497,-993,206,-911,144,961,-439,143,1000,-1000,893,1000,-844,-564,1000,50,-542,-42,-635,963,101,328,1000,596,-30,-265,-785,-306,445,1000,-783,-876,-1000,38,-464,-393,70,67,882,310,-489,543,-662,49,67,-211,-539,287,505,-327,150,-174,152,250}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00651() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceAll(java.lang.String,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{383,572,-735,-1000,-886,-356,134,-605,248,-967,165,-116,1000,-872,641,1000,-198,-348,19,-572,-640,796,-596,816,-28,-930,-628,264,1000,41,217,-283,940,561,-666,-286,227,1000,1000,415,-27,-823,182,-571,164,401,529,603,-19,-382,-274,-696,-105,-120,-162,-38,-69,-1000,-646,-909,709,-478,406,-385}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00652() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceAll(java.lang.String,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{393,-70,128,179,620,609,-622,-143,769,1000,288,1000,130,-77,993,-283,966,894,80,-1000,273,434,-745,514,-1000,168,763,692,-617,-25,694,-340,-139,879,-771,-880,1000,75,-1000,-338,609,451,221,-55,-952,947,627,-262,110,-490,625,-95,318,432,501,65,-705,402,1000,-880,-420,61,639,-521}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00653() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceAll(org.apache.commons.lang.text.StrMatcher,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-1000,1000,-294,1000,638,-36,-776,1000,370,-814,-1000,96,-415,-1000,730,607,-1000,-438,1000,340,958,1000,-976,1000,-954,-124,1000,-711,259,-591,1000,-563,1000,-804,-1000,-81,1000,-1000,-1000,269,78,-1000,-1000,853,1000,-1000,-1000,-348,1000,-606,1000,-54,-853,212,-652,1000,619,-1000,357,1000,1000,684,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00654() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceAll(org.apache.commons.lang.text.StrMatcher,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{340,84,108,-311,680,-61,-717,510,182,1000,346,-179,-1000,113,1000,-618,-151,-722,-146,752,460,1000,400,-254,-434,328,-1000,-387,-271,1000,-830,-668,-237,527,184,-298,1000,-402,-170,1000,-17,-51,302,-740,-53,-433,-235,-400,693,-68,330,-11,-1000,768,-600,1000,-618,900,-1000,1000,-912,-80,342,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00655() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceAll(org.apache.commons.lang.text.StrMatcher,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-257,241,-74,-545,534,771,771,-901,537,-1000,312,-1000,-25,-378,-1000,684,63,-378,309,417,-622,612,688,-166,901,354,645,990,-392,182,66,1000,87,-248,-845,-235,-331,-833,56,-945,516,-265,-659,-371,-118,1000,-556,-437,-548,962,-43,387,381,-910,449,-1000,161,723,46,-564,556,-244,-253,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00656() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceAll(org.apache.commons.lang.text.StrMatcher,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-639,-766,667,-567,-717,362,239,-886,-799,-819,-458,-472,-443,726,-819,317,-877,-227,-892,-875,494,694,-503,826,341,-63,556,-543,73,799,-509,-162,764,-543,-652,660,-606,-24,932,156,-204,452,-401,-620,-975,329,-647,598,321,480,-595,-686,-709,676,-921,60,518,-302,-164,244,-612,-438,10,-955}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00657() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceAll(org.apache.commons.lang.text.StrMatcher,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-1000,-428,682,389,-181,504,1000,938,-27,589,801,-220,-585,1000,883,1000,982,-208,-624,739,912,1000,119,-850,1000,-393,285,-867,-741,-107,849,-104,-707,559,-584,1000,-1000,-796,-606,357,1000,588,943,666,-897,-294,-339,-22,91,968,1000,826,-140,135,771,826,-46,-797,90,422,290,834,-796}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00658() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceAll(org.apache.commons.lang.text.StrMatcher,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-140,-1000,-483,-345,-1000,1000,743,1000,-489,-417,190,1000,9,-239,271,-395,1000,1000,754,-1000,1000,586,-1000,348,983,417,886,-1000,-1000,-1000,-1000,-1000,1000,-1000,802,935,278,-674,1000,743,-759,713,1000,1000,400,-803,788,1000,268,-144,1000,-752,1000,894,-1000,-80,-211,-1000,1000,117,182,-738,119,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00659() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceAll(org.apache.commons.lang.text.StrMatcher,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-43,-415,16,-769,894,-117,-447,-323,218,-980,17,-139,-816,-694,-400,191,-188,326,-134,-29,-338,924,776,-675,1000,-99,574,-76,-504,257,-186,613,-611,8,-535,-320,-309,424,-852,-1000,667,943,-362,-404,517,507,-873,-347,-131,696,-359,323,270,-485,596,155,933,1000,-184,-14,328,138,-451,806}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00660() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceFirst(char,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{982,-1000,122,479,-67,139,379,369,609,1000,-1000,401,-42,206,-1000,-933,556,25,-613,-251,218,-176,26,1000,690,110,373,1000,352,-909,-196,156,900,-218,-1000,291,-285,-1000,-1000,469,-1000,-1000,668,-1000,-436,7,194,429,512,-1000,-143,1000,0,-506,-400,15,-180,-1000,-109,311,1000,-618,743,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00661() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceFirst(char,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{644,324,859,-344,-1000,-1000,745,18,656,-468,-870,-736,1000,924,-1000,1000,77,-951,263,-62,258,149,187,773,-894,909,-391,-590,812,935,-426,438,-569,371,1000,1000,-201,1000,-535,-844,-724,-11,177,-809,-294,-184,-556,18,1000,592,-691,-334,703,451,-400,586,-896,194,399,169,-322,61,595,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00662() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceFirst(char,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{502,1000,-347,-17,-541,-1000,112,410,874,84,-912,226,-309,-643,523,-417,1000,-1000,476,1000,-144,229,863,239,-716,-292,504,72,-334,1000,1000,485,115,571,-330,-1000,-53,87,-1000,482,426,-251,161,354,-1000,295,692,-81,194,-173,-615,-130,-566,-664,-932,750,431,-534,598,-587,427,-980,268,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00663() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceFirst(char,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-89,-133,-975,-863,-54,469,-113,-81,-432,-713,-54,-1000,-39,313,-120,-760,-728,1000,667,238,466,367,213,-445,-753,915,-1000,-140,563,-434,-497,1000,-430,-135,-110,-1000,413,428,412,68,652,-281,88,579,13,-519,692,465,1000,279,137,-244,875,1000,1000,234,-234,775,215,616,-1000,-61,749,567}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00664() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceFirst(char,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-581,-1000,400,-1000,907,1000,1000,1000,697,135,1000,-1000,1000,1000,1000,-909,-222,219,-351,-1000,1000,-1000,-823,-144,-344,1000,-1000,-1000,-330,-1000,470,-1000,400,-1000,376,339,1000,1000,1000,210,1000,1000,-1000,396,113,-779,-515,632,1000,539,-1000,-1000,-341,-155,125,5,-1000,-1000,-1000,1000,-648,-1000,964,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00665() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceFirst(char,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-472,1000,-1000,-720,-587,-221,107,690,-1000,-309,-623,1000,891,-718,749,554,126,859,918,1000,61,153,-220,-1000,1000,-682,-284,66,1000,1000,975,-124,959,447,1000,263,1000,1000,-500,-607,643,46,-604,1000,-463,-239,676,1000,-522,-558,-48,828,-195,-1000,1000,-851,1000,505,496,34,-434,728,-144}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00666() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceFirst(char,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-1000,745,-447,-1000,480,-122,-63,-334,-191,-341,236,849,1000,-864,178,792,534,-404,-314,1000,-952,-170,-705,-179,491,-309,-158,490,142,752,712,719,553,323,1000,950,1000,1000,-891,-84,24,-1000,-887,488,-807,77,-329,149,-46,-87,319,992,548,-1000,1000,-433,-316,-823,971,-875,-689,1000,-77}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00667() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceFirst(char,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-859,1000,-232,-1000,-1000,310,56,886,-902,-793,163,1000,1000,427,748,1000,30,92,1000,1000,882,98,695,-894,823,82,-512,-762,1000,849,441,161,236,885,1000,1000,1000,725,-1000,-455,702,-92,-653,725,827,-1000,148,1000,-160,-1000,27,-235,-1000,-665,1000,-729,-191,639,176,492,-451,785,-478}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00668() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceFirst(java.lang.String,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-1000,1000,1000,1000,488,600,1000,-2,1000,-15,-1000,-207,-1000,1000,-1000,-361,-296,498,-510,-1000,-391,-846,-1000,603,902,-413,-1000,726,1000,-83,592,-340,1000,100,-13,926,886,-1000,968,432,489,1000,82,758,384,392,-742,235,353,-117,-1000,578,-1000,1000,-253,445,-497,1000,1000,-600,-711,-1000,-290}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00669() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceFirst(java.lang.String,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{138,798,352,7,591,767,-758,-477,-299,710,-17,560,233,1000,-573,-339,-1000,-616,1000,-772,-1000,1000,166,517,-131,-978,-711,1000,-789,-212,309,-568,563,-966,-540,44,773,-1000,-582,785,262,322,20,944,61,535,1000,327,1000,-1000,567,-563,382,-1000,1000,-241,-135,777,503,-518,540,266,-350,191}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00670() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceFirst(java.lang.String,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{656,-430,-107,-1000,-399,-155,203,-888,-431,-735,-279,1000,829,-250,-777,814,-83,124,560,830,548,-1000,257,667,169,-428,183,95,-191,-974,-201,361,-372,1000,86,-88,-832,-19,916,-1000,538,-1000,1000,-87,191,215,1000,-626,-59,955,1000,276,-175,1000,39,599,-1000,751,-724,272,-344,-5,117,-638}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00671() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceFirst(java.lang.String,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{412,723,-576,-566,-461,-1000,-805,496,-926,-1000,-276,566,-446,1000,-723,-1000,98,-497,350,364,110,1000,-724,507,-1000,-592,-939,-447,449,156,-356,-1000,-481,-1000,-533,1000,1000,-1000,222,-1000,129,-347,960,1000,560,-1000,554,1000,462,710,-823,452,-1000,-59,185,-435,-9,245,684,-38,-1000,-60,824,-908}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00672() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceFirst(java.lang.String,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{640,-1000,593,10,1000,89,1000,1000,35,298,72,98,365,212,176,-1000,-580,-187,772,-869,496,-424,-286,140,-33,-30,-1000,457,1000,638,-849,-136,164,586,-194,1000,832,91,-1000,1000,485,-272,570,365,1000,1000,1000,70,967,325,155,211,864,-1000,104,1000,-802,-227,-76,823,750,-972,-527,-204}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00673() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceFirst(java.lang.String,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{125,-1000,285,-878,76,-461,32,394,-959,-1000,193,661,776,537,-658,-517,-238,207,555,545,448,-288,344,658,-147,-556,286,-694,-31,-999,-353,-550,459,-760,188,482,53,-234,241,245,674,-145,534,693,678,691,1000,828,-114,620,367,-155,139,331,-742,153,-930,244,-696,548,634,-159,-913,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00674() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceFirst(java.lang.String,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-5,502,-1000,-114,-766,-338,-351,-940,689,81,-276,504,533,883,-219,-766,911,-708,-49,-261,-22,620,-724,133,101,-193,401,-196,798,549,142,-284,257,-310,-1000,126,692,-257,505,-1000,-1000,933,-8,-140,476,648,-1000,1000,680,753,-1000,-254,-1000,457,-380,-557,-130,405,-993,-1000,92,848,-537,-67}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00675() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceFirst(java.lang.String,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-1000,1000,637,1000,855,1000,1000,1000,1000,-135,337,-72,-270,361,-828,-998,70,1000,-1000,-832,-1000,244,-292,689,872,-1000,95,1000,831,-849,-205,381,1000,416,355,237,719,-1000,1000,1000,-1000,1000,-669,1000,1000,1000,-975,64,340,1000,-20,1000,-1000,39,1000,1000,-95,988,1000,753,-1000,-727,-397}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00676() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceFirst(java.lang.String,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-304,-1000,1000,1000,1000,-80,-1000,1000,-1000,1000,-400,1000,239,-1000,1000,-1000,103,-759,-888,14,-1000,-48,-1000,-1000,1000,1000,904,1000,18,1000,-728,1000,-1000,1000,-77,-643,-137,1000,-212,663,-356,1000,-422,1000,-450,803,-1000,-1000,336,675,-1000,-1000,-1000,783,-1000,-891,1000,-89,1000,1000,1000,735,708,28}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00677() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceFirst(java.lang.String,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-784,-792,-1000,-1000,407,679,-844,1000,-1000,-246,227,794,715,-1000,767,101,-329,1000,-124,-624,-914,484,1000,-447,-507,370,-1000,-683,-604,1000,-1000,710,-1000,196,-106,-123,197,891,-83,847,1000,1000,-752,-533,-1000,91,-551,-767,33,540,-1000,262,900,-1000,-564,-113,1000,-405,766,-1000,-283,446,-92}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00678() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceFirst(java.lang.String,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-430,-64,-1000,-1000,428,44,-1000,-1000,-371,-536,-314,1000,380,-1000,-1000,-491,396,937,437,579,-657,-765,1000,1000,-703,133,-962,-383,1000,-1000,-505,502,-1000,536,125,131,217,1000,72,957,775,1000,-557,225,-216,-133,-1000,-241,469,120,-623,-10,969,-1000,-278,249,1000,-114,570,-1000,-125,191,-293}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00679() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceFirst(java.lang.String,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{565,1000,38,28,238,-169,-855,-1000,-1000,-229,-328,727,970,-181,-544,1000,-60,597,-864,638,237,124,823,540,1000,-549,334,410,-1000,647,744,131,929,-354,266,-996,263,348,1000,-270,-551,1000,-523,26,-1000,-801,-1000,993,47,331,-68,-1000,-964,811,1000,-586,-337,664,190,-575,324,449,615,539}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00680() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceFirst(org.apache.commons.lang.text.StrMatcher,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-932,74,162,1,1000,364,-622,-957,-131,-1000,817,1000,-302,1000,784,-1000,533,112,702,-1000,-771,1000,322,910,808,645,1000,1000,-510,-36,-841,-879,-1000,757,-1000,-1000,146,-435,-418,-6,112,-443,161,-1000,-488,3,-592,-285,1000,-1000,1000,337,-255,-364,488,1000,-1000,929,-1000,-399,640,-975,259,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00681() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceFirst(org.apache.commons.lang.text.StrMatcher,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-552,-552,-861,642,786,368,-279,-353,72,449,-636,-125,425,-575,817,-83,-226,-3,588,168,-800,-919,897,-575,890,-67,-642,-91,-358,383,562,-923,536,38,29,170,-199,-714,114,289,203,-789,-661,-993,317,116,-607,-28,947,-765,-466,807,-337,-538,528,711,-89,417,-609,589,502,-982,195,-695}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00682() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceFirst(org.apache.commons.lang.text.StrMatcher,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{480,368,572,50,-1000,365,-28,-104,-208,738,262,-953,58,-926,-40,971,133,599,906,-1000,-242,69,-637,284,-199,-1000,-390,-101,-281,485,504,-1000,-142,-1000,-3,-914,168,641,285,-37,-621,-936,-185,1000,547,-141,-452,-735,1000,162,-1000,323,594,-502,-855,-470,-976,-123,213,-1000,-265,-793,381,-488}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00683() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceFirst(org.apache.commons.lang.text.StrMatcher,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{294,-135,184,-416,-1000,756,1000,260,5,772,1000,-954,-474,-500,449,224,-545,445,-108,-418,-613,-467,-709,-120,-191,537,-377,-352,243,34,256,-54,914,-204,1000,662,-510,531,-81,-682,-669,317,-77,395,1000,50,-642,-1000,-363,-75,-233,685,-140,-18,-670,-461,368,106,-562,-435,49,-964,-411,187}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00684() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceFirst(org.apache.commons.lang.text.StrMatcher,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-586,-1000,305,1000,677,269,542,-613,830,1000,129,-831,-85,85,1000,-111,-1000,1000,1000,811,-1000,-1000,119,-602,-735,102,-1000,-398,1000,102,1000,47,1000,1000,-253,667,-1000,-1000,-403,-124,-296,714,-1000,-758,1000,1000,-556,-685,-499,467,-6,1000,979,-320,709,875,-217,1000,-1000,955,1000,-1000,-818,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00685() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceFirst(org.apache.commons.lang.text.StrMatcher,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-152,-1000,-550,774,-497,-751,1000,1000,968,1000,1000,-1000,-371,449,720,-65,445,-1000,-1000,-836,-625,1000,1000,-1000,-139,27,-1000,-1000,-443,208,-685,184,-149,1000,-995,-1000,-565,-214,457,1000,1000,865,-1000,1000,981,1000,-1000,282,1000,1000,648,505,380,-1000,-440,591,261,-590,-402,-930,-357,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00686() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "replaceFirst(org.apache.commons.lang.text.StrMatcher,java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-520,-442,400,-1000,692,233,-356,-616,-1000,-315,618,352,-89,482,417,-994,1000,-257,1000,-495,639,-213,1000,1000,-113,636,1000,713,-994,-199,172,-1000,-244,-1000,-452,-902,526,132,-5,548,1000,-144,-47,-1000,-33,615,140,-859,391,-1000,578,1000,-468,662,357,1000,-937,422,-1000,627,-570,-1000,-814,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00687() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "reverse():org.apache.commons.lang.text.StrBuilder",
            new int[]{-113,-1000,-556,-536,581,-972,484,25,-97,551,-71,236,-487,-183,-120,-348,1000,803,401,420,-343,189,-537,-66,-641,995,-412,757,-711,1000,-322,-1000,739,-371,1000,451,634,661,-298,1000,394,-888,809,-108,-475,-1000,157,-77,1000,-215,0,-450,-129,295,657,-1000,-1000,440,373,572,-749,378,348,546}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00688() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "reverse():org.apache.commons.lang.text.StrBuilder",
            new int[]{-122,-84,104,-308,-265,-320,587,62,-252,639,69,601,-70,-102,658,-789,1000,887,602,110,-741,49,221,5,-628,632,-839,863,-548,1000,340,37,353,-64,-203,-322,1000,1000,-486,592,890,-713,727,879,156,-1000,-507,814,-786,1000,-50,198,1000,444,538,-964,-408,697,1000,-691,676,919,580,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00689() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "reverse():org.apache.commons.lang.text.StrBuilder",
            new int[]{263,-433,-756,-601,-530,983,-131,-27,778,550,824,-834,505,-269,-859,-514,892,851,452,-118,-195,529,-318,-292,-934,-494,-503,976,-57,-481,-360,-612,256,-631,901,994,-670,68,884,-988,602,-936,964,338,-945,-60,863,-424,-136,686,-872,46,-344,676,466,155,576,-183,366,-240,34,991,-278,702}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00690() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "reverse():org.apache.commons.lang.text.StrBuilder",
            new int[]{-603,-455,-1000,-744,289,-536,621,252,902,100,-603,1000,-1000,-1000,487,-891,1000,1000,-863,831,-1000,1000,-1000,-826,-928,1000,-506,1000,-1000,784,-238,-505,1000,-796,1000,632,-90,1000,-958,417,293,-952,1000,-525,-655,-1000,513,198,-120,-747,324,-1000,389,100,593,-1000,-955,1000,13,1000,-1000,712,1000,360}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00691() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "reverse():org.apache.commons.lang.text.StrBuilder",
            new int[]{263,-433,-756,-601,-530,-1000,-131,434,778,550,824,-329,851,-269,-859,-514,892,1000,452,-118,529,529,1000,-292,-934,-1000,-503,976,-57,-18,-360,-612,256,-1000,901,800,1000,68,394,1000,602,-936,964,309,-945,-60,863,-424,-136,565,-749,46,-344,449,466,155,259,-183,366,-240,34,958,-278,702}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00692() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "reverse():org.apache.commons.lang.text.StrBuilder",
            new int[]{-57,308,-1000,-910,316,-476,723,849,608,-50,950,703,-485,-687,-115,-437,39,648,-860,664,-623,392,-894,-288,-840,203,-254,883,202,-93,-298,-371,793,-424,788,744,-322,351,356,376,102,-925,877,-1000,-659,-1000,627,445,-581,-311,-723,-995,146,966,218,-488,-1000,904,178,1000,-826,-1000,1000,-374}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00693() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "reverse():org.apache.commons.lang.text.StrBuilder",
            new int[]{400,-1000,272,-983,1000,-657,14,-222,-1000,1000,97,700,-1000,-820,-1000,-304,1000,1000,-18,676,-118,235,-145,1000,-886,574,-682,960,-1000,967,-1000,-400,1000,-216,-1000,438,1000,585,400,1000,544,-858,-433,551,-543,-596,-341,-401,1000,-203,-156,422,341,694,1000,-1000,-378,542,99,-645,1000,567,77,632}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00694() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "rightString(int):java.lang.String",
            new int[]{-46,-1000,482,-1000,543,-441,-543,731,-998,139,-1000,18,334,-857,-393,-595,1000,1000,581,-7,-909,360,225,1000,1000,477,-201,42,-801,-1000,-1000,1000,-70,58,-734,1000,1,-820,633,540,778,-455,-31,1000,1000,711,-1000,374,1000,-1000,1000,1000,369,747,-170,-648,-616,322,-622,640,80,-1000,-472,328}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00695() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "rightString(int):java.lang.String",
            new int[]{-433,-735,344,-743,-115,-410,-24,558,-11,-110,-563,328,186,-734,311,1000,-1,1000,116,472,-8,1000,-653,940,172,839,122,1000,1000,-775,-1000,1000,-1000,1000,-412,229,278,-797,1000,482,-1000,650,-1000,426,1000,-118,-538,1000,1000,-1000,1000,310,550,1000,-109,-891,-1000,1000,794,-715,-169,-1000,-835,911}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00696() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "rightString(int):java.lang.String",
            new int[]{-1000,-602,1000,-934,293,-142,-327,465,1000,1000,-856,893,-151,-1000,-1000,-1000,728,1000,1000,-1000,-1000,-294,-1000,1000,1000,-172,1000,1000,501,-1000,-1000,1000,-1000,1000,-1000,940,905,-1000,1000,413,398,1000,-1000,1000,1000,-1000,-278,984,1000,-1000,999,1000,-767,1000,1000,-164,-601,-14,1000,1000,808,-1000,1000,-480}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00697() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "rightString(int):java.lang.String",
            new int[]{-1000,488,402,-857,40,717,-113,623,-114,599,-32,505,-448,-1000,-1000,-1000,728,-14,1000,-108,143,-294,-28,1000,1000,-216,1000,-658,501,-538,-1000,235,235,-187,-671,183,434,-1000,174,272,1000,558,54,-338,92,-425,501,-50,400,-44,460,324,712,21,-657,565,752,-692,-196,-23,204,-453,1000,-618}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00698() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "rightString(int):java.lang.String",
            new int[]{544,-1000,61,361,656,-1000,379,-1000,-528,-599,-551,176,462,301,203,-180,1000,1000,40,-899,-1000,117,392,564,85,-1000,-1000,319,-24,-118,-670,475,-1000,-132,-514,486,443,686,-180,-559,472,-52,-319,938,665,384,-1000,164,448,249,169,503,-196,-1000,-135,-712,-850,341,471,918,-632,-1000,-593,275}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00699() {
        org.junit.Assert.assertEquals("java.lang.String:LzE5Zg==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "rightString(int):java.lang.String",
            new int[]{142,-241,137,19,-542,954,-446,-1,204,-890,-447,1000,-943,-324,1000,-504,221,492,559,162,1000,1000,422,287,671,-606,-1000,-487,1000,850,-711,494,409,-897,-264,-900,-441,573,366,-244,-817,417,-53,630,92,-425,-365,123,159,1000,-807,184,826,-257,-237,629,-520,820,-178,-810,399,-48,-772,588}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00700() {
        org.junit.Assert.assertEquals("java.lang.String:AA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "rightString(int):java.lang.String",
            new int[]{72,-520,528,-1000,-181,-431,-1000,600,1000,797,-1000,-623,-12,-933,-526,1000,1000,1000,-177,1000,793,552,117,1000,460,745,-816,100,1000,-1000,-1000,1000,-349,1000,324,-457,-725,-1000,743,781,-1000,-617,-321,-846,1000,322,97,1000,1000,37,748,1000,419,1000,174,-1000,-946,1000,-920,1000,1000,-256,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00701() {
        org.junit.Assert.assertEquals("java.lang.String:IA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "rightString(int):java.lang.String",
            new int[]{411,-1000,74,-1000,806,-429,-849,-347,141,-397,-1000,-443,-373,-258,73,422,745,1000,126,942,-578,201,227,205,757,109,-979,-354,1000,-1000,-1000,1000,-70,1000,-711,910,-492,-460,631,149,71,-698,410,1000,1000,965,-1000,774,1000,906,-145,1000,170,1000,77,-782,-710,664,-622,580,990,-692,-987,848}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00702() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "setCharAt(int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-1000,1000,-1000,273,-251,-27,-914,641,-1000,584,742,739,-44,112,1000,-362,-22,209,-739,789,882,918,146,220,937,223,52,-739,403,1000,102,-323,466,419,532,-410,-437,-223,-529,-756,17,585,752,-554,320,1000,-778,-686,222,-177,611,70,-587,-982,274,106,115,1000,-207,202,-574,536,-519}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00703() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "setCharAt(int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{422,988,80,96,-366,-907,-495,-970,-407,-911,-7,230,-445,268,807,476,251,70,-560,-396,377,-344,-293,902,-970,-206,901,-883,-28,472,230,-317,-120,-254,-636,-489,151,-785,812,-772,697,-794,-944,-884,254,252,908,124,-836,804,-619,-629,-654,203,-480,290,218,927,-891,-802,690,865,-71,486}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00704() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "setCharAt(int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-933,654,-473,-123,160,895,981,593,-693,711,-512,543,-726,172,519,-736,-45,-732,496,328,-375,-542,-960,467,927,-521,-495,532,-868,163,-849,760,-620,121,-147,533,89,-974,163,-650,-451,-91,-245,-899,-183,431,-198,-107,482,-632,-323,647,590,714,-482,-511,90,-246,-345,-453,532,-815,-310,-789}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00705() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "setCharAt(int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{699,-1000,406,-647,97,-452,343,-601,239,-810,-1000,1000,132,563,198,133,-553,639,-542,-1000,1000,-1000,-479,-138,13,862,758,1000,-1000,383,463,-508,-652,-183,-164,187,238,-176,277,1000,392,-725,798,665,399,765,1000,31,-733,296,216,728,-1000,-49,280,501,507,887,1000,232,699,-403,-22,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00706() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "setCharAt(int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-257,392,-614,-15,-461,-996,884,-1000,-599,400,382,854,312,-394,-271,-1000,-593,1000,-373,-476,-546,59,305,-169,13,808,1000,-1000,-1000,1000,204,-733,-998,389,24,-892,366,-836,35,-881,188,251,-105,-242,551,321,363,-158,-703,185,124,-140,-562,-1000,-1000,1000,1000,620,-937,-629,1000,306,-820,40}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00707() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "setCharAt(int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,-1000,896,154,350,-383,458,-338,313,-779,515,182,803,-201,14,-790,-45,-345,-861,-961,-464,-677,1000,73,765,402,137,-95,145,613,-170,836,481,-429,589,-179,843,127,-393,-915,-805,587,-34,1000,-189,-490,-915,670,411,-120,-374,258,959,-155,-1000,400,659,-593,776,109,266,422,28,-788}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00708() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "setCharAt(int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{-802,-1000,-33,425,119,-69,1000,1000,-1000,-358,-474,927,304,-611,7,655,-516,160,679,-48,-1000,-657,319,15,1000,473,124,1000,-1000,-282,-1000,368,-1000,1000,-200,100,-595,1000,-176,1000,-1000,-1,1000,-267,1000,597,571,271,783,275,272,1000,1000,-380,-355,525,-58,163,1000,593,602,-424,-668,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00709() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "setCharAt(int,char):org.apache.commons.lang.text.StrBuilder",
            new int[]{738,86,543,-123,776,-375,-816,-185,-693,-1000,778,1000,739,-317,529,-119,677,428,396,-446,181,-679,987,-40,641,660,70,752,-755,-846,809,-968,126,635,130,267,-771,-1000,-970,-650,-1000,493,129,243,-183,164,1000,-251,1000,550,-323,-255,1000,-582,-482,528,349,-1000,-179,1000,23,-85,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00710() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "setLength(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-823,-1000,-155,-1000,-913,70,517,867,641,-416,249,-1000,54,-295,295,947,23,-508,-170,730,1000,-1000,-249,-173,512,501,1000,124,714,-767,-328,-220,-148,1000,-73,421,-494,-130,-240,-1000,-689,320,482,690,-1000,147,49,-243,-1000,-655,789,-143,-1000,-659,667,-940,326,1000,85,1000,-1000,434,-91,377}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00711() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "setLength(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,795,-956,271,-144,-432,-1000,-298,60,-125,-994,-360,706,-269,-717,-153,-1000,0,1000,-593,-477,-729,994,187,181,-467,427,-200,110,778,142,1000,-169,1000,389,-4,-580,-21,1000,-1000,-1000,-333,-1000,961,595,512,780,-768,1000,362,659,201,-433,730,464,-268,1000,-347,657,1000,-684,-548,-547,18}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00712() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "setLength(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-449,-1000,544,-912,-798,-618,-346,192,698,21,-895,312,353,-890,1000,1000,-1000,-1000,721,-105,62,1000,-400,529,485,1000,22,653,321,-128,-1000,-400,498,-1000,625,448,363,-1000,1000,-526,-818,641,-1000,-672,1000,-206,-113,-33,407,-460,1000,-465,-955,371,1000,-1000,245,-722,-425,-309,-118,-1000,-847,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00713() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "setLength(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,806,-596,1000,323,-546,323,24,-801,105,-94,1000,964,855,-889,48,-89,108,-908,-680,635,283,-495,-772,1000,397,977,-495,-1000,680,234,651,678,-711,240,180,571,305,1000,-420,263,603,-830,1000,1000,-373,-145,767,-55,401,-359,-1000,553,-347,-527,612,1000,-196,1000,31,1000,-833,-1000,-637}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00714() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "setLength(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{936,1000,-1000,1000,-646,-690,-478,99,-337,-19,-1000,-691,620,304,-76,1000,-1000,35,1000,-1000,-616,36,1000,-517,343,-353,1000,119,-430,67,-107,1000,1000,-711,87,-775,284,-61,1000,-1000,-45,735,-1000,1000,706,431,-1000,275,1000,185,-1000,-351,-501,875,742,1000,789,313,140,-890,624,-560,-1000,-547}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00715() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "setLength(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-250,-676,-587,488,-821,350,474,-778,696,-1000,381,-1000,276,397,53,10,281,192,-1000,-448,-788,-811,-457,22,-1000,-178,434,386,1000,-1000,-457,-220,-135,1000,-411,644,528,53,803,-1000,-238,657,229,468,-1000,-83,-735,193,-1000,-794,563,-40,-948,-935,130,1000,393,535,-810,1000,-666,648,411,497}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00716() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "setLength(int):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-361,494,111,-285,1000,33,422,492,-1000,-735,-749,-802,-1000,340,-964,1000,1000,-960,976,1000,-1000,1000,426,561,-955,-589,-855,1000,-263,1000,403,-1000,859,1000,1000,399,1000,-1000,-163,655,-24,1000,-47,-1000,-446,-668,-321,-857,-980,-267,-291,1000,-601,-1000,713,254,792,1000,1000,-1000,74,1000,998}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00717() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "setNewLineText(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{712,281,-468,894,884,310,-187,808,473,1000,-982,-744,-1000,712,979,-818,-339,556,-295,-1000,585,-1000,-819,-1000,1000,109,663,-146,-615,1000,-907,-337,928,365,-491,-1000,698,466,-1000,806,-1000,-1000,-387,1000,1000,-516,1000,838,625,1000,711,1000,1000,1000,-214,1000,-1000,842,-430,426,1000,-1000,-1000,819}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00718() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "setNewLineText(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-521,780,-606,479,-1000,759,525,598,746,-329,604,1000,26,918,-474,1000,-771,-820,-898,-1000,-426,361,796,456,879,-7,-1000,-1000,-1000,948,1000,-39,-1000,291,649,-92,-904,1000,175,369,376,-9,19,1000,-773,1000,-722,640,-212,699,184,-180,-1000,756,-636,-518,-159,-410,699,188,1000,-680,536,348}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00719() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "setNewLineText(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{763,-1000,-130,-329,636,-1000,908,242,-948,191,-564,-1000,76,-331,244,-180,-330,1000,1000,-754,-121,436,321,-477,-784,-1000,-256,523,187,-177,-207,634,1000,1000,-363,218,1000,191,-893,996,316,1000,665,-1000,835,-924,-580,996,764,-1000,1000,388,1000,-589,1000,-639,-571,-388,-375,-37,-600,204,-1000,-228}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00720() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "setNewLineText(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-685,31,-462,1000,214,647,-367,7,-341,-496,-973,194,-580,-27,-997,382,-968,-1000,-32,380,523,115,-535,-1000,-28,228,581,-1000,-1000,-25,387,-741,7,380,1000,227,-773,131,81,1000,922,543,411,592,-887,158,457,-437,-123,661,-707,-895,-1000,762,-1000,190,-1000,642,688,1000,-310,-1000,-354,482}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00721() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "setNewLineText(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{271,-247,-130,1000,636,-38,1000,483,-60,559,-868,-1000,-909,359,633,-264,-45,412,-32,-569,664,-797,-22,-888,543,-126,639,323,-826,849,-822,335,1000,479,-470,-787,568,191,-1000,1000,-878,-1000,665,927,1000,-924,1000,996,764,1000,825,171,1000,469,-843,368,-1000,1000,-236,-297,891,-978,-557,492}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00722() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "setNewLineText(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-1000,192,11,-747,762,892,212,-206,-831,-85,1000,-272,1000,1000,41,-799,-358,407,1000,-159,627,975,87,190,-552,-800,-55,255,158,672,716,1000,-335,367,-314,-1000,679,135,-24,-204,811,1000,1000,202,939,-763,680,811,1000,582,-703,413,419,-1000,270,1000,-410,-842,-942,-28,1000,-72,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00723() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "setNullText(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-784,-1000,-28,-1000,-257,833,567,532,-109,-177,-626,1000,-317,-878,538,-349,221,-740,1000,316,-23,374,-946,-847,325,416,-16,-441,-1000,-126,750,1000,-397,-283,-603,766,1000,827,-14,-490,659,172,-419,632,-986,830,-46,299,1000,1000,849,-300,-1000,815,9,-458,-346,-255,-963,-678,118,46,509,-343}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00724() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "setNullText(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{392,589,-46,-562,-281,116,423,-126,-254,-147,-64,391,137,-708,773,-113,-103,-538,1000,1000,532,-53,92,80,-825,933,930,545,-245,98,195,463,316,848,-64,-351,-343,3,384,740,36,-344,-910,-446,-1000,-27,923,1000,-607,1000,-224,216,-903,-153,67,-700,-257,-1000,-773,-680,456,-659,440,-230}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00725() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "setNullText(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{621,114,622,737,1000,-369,714,-192,574,-1000,-4,-223,526,1000,-1000,336,1000,553,574,873,1000,-175,1000,622,-601,294,245,-1000,1000,-1000,828,-1000,341,452,-79,865,-1000,-517,-29,-1000,528,218,-209,-972,965,-894,1000,-1000,1000,408,90,1000,-650,722,512,-282,-46,-261,-256,-785,354,-952,896,280}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00726() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "setNullText(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{365,590,363,-606,207,176,-422,122,915,-587,-277,431,1000,743,47,542,602,-403,801,29,177,-504,222,-688,762,1000,327,-316,367,-785,-298,857,-267,-860,-692,206,-274,-424,-370,907,566,745,8,-334,-1000,401,990,-750,687,470,-499,1000,-713,150,575,-246,165,755,-923,-563,791,419,149,-899}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00727() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "setNullText(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-534,-1000,-319,-592,-68,-571,1000,411,-734,46,19,352,-400,-282,534,-248,-427,110,911,279,-798,237,-540,-236,-834,508,396,108,-918,46,967,-135,187,349,267,324,54,921,-473,-160,-448,-1000,-764,337,-564,583,-552,1000,836,147,-258,-1000,-496,681,16,1000,120,255,-166,276,2,-590,-295,-131}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00728() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "setNullText(java.lang.String):org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-1000,-400,-1000,-869,974,21,870,-657,-290,-182,1000,967,-181,181,-903,602,-1000,401,-1000,-545,-504,322,-689,1000,812,327,354,-1000,-785,989,732,-330,-384,147,980,322,704,-967,841,223,-1000,-245,1000,-1000,1000,1000,843,1000,1000,-539,-400,-1000,1000,269,-1000,721,1000,-1000,-563,419,-474,315,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00729() {
        org.junit.Assert.assertEquals("java.lang.Integer:MQ==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "size():int",
            new int[]{277,-1000,370,1000,-770,-652,-103,-92,-269,239,-330,-412,-1000,887,-388,-976,-11,1000,999,-1000,-400,63,-351,-11,-732,600,-931,-540,243,-543,347,354,-1000,951,-1000,67,5,7,-106,-1000,1000,762,276,-775,500,-480,777,-278,706,787,648,-1000,-1000,-322,-675,791,-59,-865,-671,-915,-301,-356,639,-733}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00730() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "size():int",
            new int[]{-6,183,939,1000,402,306,-6,799,-369,-1000,-1000,-300,831,-680,875,650,1000,-672,-215,-1000,278,-178,1000,1000,-609,-1000,85,-5,-937,1000,754,1000,-1000,311,431,-895,618,-558,787,464,-363,-832,413,-922,199,861,123,1000,-1000,-846,-945,25,407,-553,-1000,399,378,-529,1000,-750,-1000,1000,189,190}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00731() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "size():int",
            new int[]{591,-674,368,-222,-631,-1000,676,237,930,454,978,-1000,-1000,1000,-1000,697,-339,1000,-758,911,58,360,927,-1000,-847,888,103,-592,871,-1000,1000,-869,-823,-713,-1000,-26,-345,438,-1000,-81,917,1000,693,-581,1000,-758,-2,-1000,268,-406,-1000,-256,-468,710,-256,-606,-1000,-872,-1000,-225,-928,572,123,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00732() {
        org.junit.Assert.assertEquals("java.lang.Integer:MzA=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "size():int",
            new int[]{973,314,961,-71,-247,9,-443,758,18,377,302,-158,-569,291,252,-940,-59,-525,371,-649,689,-396,-783,116,-551,774,-771,-754,-76,-586,-223,244,-993,224,461,-820,520,-690,63,-415,-129,333,-970,-177,-424,178,378,942,641,-566,-460,-406,-540,-194,-195,181,37,-554,720,-910,-887,185,145,-400}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00733() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "size():int",
            new int[]{572,-727,1000,-224,-149,-657,172,317,1000,622,585,-1000,-1000,1000,-695,378,-655,1000,-439,417,-159,-281,11,-793,-533,773,66,-911,-369,-809,1000,2,-1000,-220,-1000,-430,176,-1000,-1000,-335,1000,831,-686,-76,730,-507,1000,262,16,-1000,-945,-596,-598,-27,-559,-62,-914,-845,-857,-543,-1000,315,336,-761}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00734() {
        org.junit.Assert.assertEquals("java.lang.Integer:MTI=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "size():int",
            new int[]{-294,-703,-1000,-32,464,-71,-731,578,-173,533,-762,863,-957,-707,735,-171,-784,-540,-814,-766,-17,-1000,864,146,893,-252,-499,1000,-512,628,1000,-988,-6,-688,-785,-307,-860,846,749,855,718,381,993,441,697,440,-88,187,388,723,1000,430,-1000,324,-914,-768,490,306,-566,66,1000,969,-356,452}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00735() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "size():int",
            new int[]{1000,662,-400,-324,-745,-797,89,1000,-1000,-479,301,-199,420,226,-901,-740,366,71,-43,-789,957,797,1000,-938,-934,-1000,843,36,-742,516,-12,-162,-332,-1000,897,-1000,1000,-280,25,-673,-400,797,1000,255,12,222,-758,-113,-456,82,-984,1000,-171,692,-364,-348,-265,-975,1000,-526,-237,1000,139,-928}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00736() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "startsWith(java.lang.String):boolean",
            new int[]{-336,-988,884,-580,-176,-658,514,779,-174,-1000,-130,-513,1000,911,12,104,797,-495,182,-688,-925,-159,-157,10,-72,603,405,-608,-458,749,-92,481,-1000,867,-648,213,524,-1000,352,840,406,204,558,-1000,-213,1000,-1000,-975,781,507,-578,124,-183,-29,-1000,-46,1000,-1000,127,-799,875,1000,-1000,-606}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00737() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "startsWith(java.lang.String):boolean",
            new int[]{-343,-141,884,-843,875,612,1000,286,-66,-241,-243,-517,767,911,-304,923,-452,284,182,-62,410,-159,-39,-584,-604,219,719,418,57,-208,-136,184,686,-1000,-407,681,-15,-781,-813,104,1000,-102,400,-949,582,-94,543,-975,-387,347,-1000,238,-1000,-321,-1000,-477,-133,675,-586,-713,792,1000,-1000,157}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00738() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "startsWith(java.lang.String):boolean",
            new int[]{899,208,-189,682,874,601,-199,198,-806,367,501,-238,-546,-1000,-52,-1000,-253,-382,328,-314,1000,-1000,472,850,1000,-252,-757,-689,-219,-1000,821,90,510,658,-599,-643,-311,-206,-170,-10,-721,65,925,798,379,11,680,507,-291,138,575,1000,74,-476,799,-560,-134,1000,-108,881,622,-907,589,391}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00739() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "startsWith(java.lang.String):boolean",
            new int[]{-313,155,-958,1000,969,192,421,-711,-378,-96,564,160,719,-951,-280,-726,-818,-613,-460,611,-213,-1000,-914,1000,380,-812,-308,-839,-614,-713,230,-238,85,-1000,-967,-1000,121,-440,1000,833,-852,-436,-461,68,901,-746,-403,-1000,267,531,-1000,101,219,-1000,170,107,419,1000,-220,-173,532,-232,-717,254}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00740() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "startsWith(java.lang.String):boolean",
            new int[]{557,-430,344,-1000,335,28,1000,1000,-431,-265,421,-747,734,908,921,-1000,306,305,-129,-632,-31,-611,114,24,416,-13,517,-1000,-287,-93,751,-742,985,960,-316,448,7,-952,-678,280,-1000,1000,1000,736,1000,593,1000,379,188,205,258,931,340,950,635,-1000,-482,1000,948,101,727,435,-199,-276}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00741() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "startsWith(java.lang.String):boolean",
            new int[]{465,617,-227,-1000,739,0,263,395,-67,585,-1000,-1000,1000,304,-957,-97,-943,-127,777,758,748,-654,-550,-669,161,-813,1000,112,-1000,-778,1000,500,594,1000,-1000,1000,884,-1000,-1000,523,1000,193,-118,-1000,-279,405,98,-593,-222,899,1000,-218,-1000,-454,-1000,687,-249,897,63,-439,1000,227,-1000,815}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00742() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "startsWith(java.lang.String):boolean",
            new int[]{966,1000,-306,432,379,171,-660,-780,-724,1000,203,-359,170,-959,239,-571,-399,-120,-356,768,948,-1000,-1000,-307,1000,-722,-350,-107,-204,-707,999,838,1000,-1000,339,-287,-139,400,-546,-1000,-822,-424,-496,400,-256,-230,1000,1000,-847,83,283,691,-103,-298,737,835,-1000,1000,1000,832,253,-1000,798,512}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00743() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "startsWith(java.lang.String):boolean",
            new int[]{846,410,231,-674,968,-741,-802,313,-522,-586,-331,-793,-196,930,244,-595,-217,-38,161,-627,-319,-475,-42,-930,-141,623,575,-310,687,408,-189,3,592,529,-135,-202,929,-707,988,-757,729,-97,245,321,337,-390,794,954,448,-607,163,-120,104,489,-409,908,-142,960,646,820,485,371,74,-210}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00744() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "startsWith(java.lang.String):boolean",
            new int[]{248,875,832,1000,-641,-141,587,-450,-143,1000,663,-1000,825,212,-1000,595,-102,-426,-680,993,1000,-661,-385,-1000,1000,-1000,-1000,-638,-658,-896,1000,1000,-598,1000,384,1000,182,-476,-1000,-1000,-172,-3,-1000,-993,-1000,175,-34,725,-1000,937,276,85,-760,238,-1000,581,-1000,-561,1000,-48,702,-525,-139,966}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00745() {
        org.junit.Assert.assertEquals("java.lang.String:LTB4ODAwMDAwMDAwMDAwMDAwMA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "substring(int):java.lang.String",
            new int[]{-373,-1000,-1000,637,369,675,-686,-44,725,-201,-1000,-532,665,-1000,-899,-874,177,-684,-399,579,-875,-102,1000,993,194,-17,-817,418,-1000,-713,682,-1000,202,977,-897,-1000,875,327,82,1000,943,-400,559,-43,-1000,161,1000,28,-1000,-826,56,-1000,789,-431,503,1000,328,-1000,1000,682,-544,-415,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00746() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "substring(int):java.lang.String",
            new int[]{16,1000,-30,-548,-436,-220,-773,738,922,-724,-296,919,-98,-1000,-225,1000,-951,956,162,797,738,973,-401,-982,-1000,-477,840,1000,125,792,1000,-356,-1000,1000,-597,-1000,-275,-702,-130,-621,-132,-1000,68,155,393,-413,608,1000,436,480,-5,488,-1000,-180,450,236,86,-596,-1000,676,-405,-344,-624,447}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00747() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "substring(int):java.lang.String",
            new int[]{1000,-1000,63,-403,-146,1000,-752,-143,280,-528,-354,-137,1000,-1000,332,-874,-571,999,203,1000,-875,-410,1000,993,-793,682,-337,604,-248,470,1000,-1000,312,579,-998,-1000,1000,-62,660,1000,403,-1000,-625,-1000,-1000,-628,1000,-1000,195,-545,-1000,-320,258,-1000,-93,837,-1000,521,1000,-239,-1000,-1000,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00748() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "substring(int):java.lang.String",
            new int[]{125,78,357,164,1,328,679,-569,-528,-201,-744,797,-119,-544,462,-1000,-380,-362,-1000,-221,-1000,945,-263,1000,-329,119,-1000,179,484,-40,966,462,1000,-1000,760,744,829,825,-869,989,-387,591,-145,839,-1000,-353,716,-1000,-296,645,-570,304,-251,344,873,-1000,1000,150,-71,594,873,1000,144,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00749() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "substring(int):java.lang.String",
            new int[]{-424,-1000,-179,-772,358,26,426,-786,123,920,-1000,-196,-498,-818,-73,-648,-233,213,-871,-519,-649,515,-258,981,-690,407,-74,-619,452,181,544,674,789,-798,263,557,650,901,-292,512,-222,809,-527,178,-476,-554,433,-939,122,582,-556,463,207,-434,270,-127,-430,-363,-2,592,949,988,829,-91}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00750() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "substring(int):java.lang.String",
            new int[]{-380,503,-179,123,-84,26,-272,794,554,-659,-428,195,293,-736,-40,925,-518,301,-891,154,-478,747,-188,-600,-529,-746,250,656,-37,-68,541,-331,-652,37,-433,-426,96,-50,-292,-214,-222,-398,-142,178,493,-402,567,481,-159,832,-556,31,-876,-127,146,52,-173,-216,-656,383,-547,107,-878,714}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00751() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "substring(int):java.lang.String",
            new int[]{-380,656,480,88,-14,227,251,265,554,-820,117,455,263,-1000,-1000,1000,-831,495,-891,-944,-478,747,-1000,-600,-202,-746,1000,443,-37,348,934,110,-684,37,-1000,-527,96,-511,-678,1000,514,-738,-21,437,916,-536,87,271,-159,772,-729,244,-619,291,-534,52,175,-598,-1000,590,28,255,927,714}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00752() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "substring(int,int):java.lang.String",
            new int[]{929,-1000,-1000,543,684,-682,-944,387,1000,-74,130,-906,-865,-317,424,640,655,980,-460,-533,-277,398,-6,-219,871,1000,-894,293,-360,720,-316,229,-63,1000,1000,-298,-11,-819,-298,610,804,1000,924,-162,1000,-603,-291,-971,1000,-680,-977,1000,-1000,1000,795,-805,915,-205,-727,-1000,1000,-978,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00753() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "substring(int,int):java.lang.String",
            new int[]{-196,634,544,37,-576,1000,-284,46,-56,-414,-763,953,76,-321,-1000,-1000,349,-1000,73,423,-468,589,-373,668,-568,-1000,1000,-569,-39,11,360,-1000,644,-1000,-638,-597,610,899,-63,-1000,-1000,-748,753,415,924,1000,19,-381,1000,-645,13,-163,1000,837,-33,-398,1000,-48,-486,838,-200,-1000,1000,-229}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00754() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "substring(int,int):java.lang.String",
            new int[]{-318,-813,-661,268,838,-302,-721,581,277,-56,1000,931,-636,-976,660,934,431,187,455,-1000,623,701,-889,-699,606,521,-1000,-144,-1000,1000,-99,-463,812,424,1000,-490,239,-1000,771,60,1000,719,1000,-398,834,-1000,33,-1000,839,-715,134,1000,-778,891,736,-1000,1000,-565,299,-342,668,-1000,-493,-590}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00755() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "substring(int,int):java.lang.String",
            new int[]{-629,-1000,-1000,1000,-1000,1000,163,402,1000,1000,601,-1000,97,-123,872,100,955,854,1000,1000,-1000,-305,-1000,-1000,-1000,-1000,-853,-1000,-1000,629,-1000,1000,1000,-1000,1000,-1000,1000,-1000,-1000,-964,633,1000,1000,-981,243,-1000,-1000,1000,852,-672,-484,1000,40,1000,-301,-1000,1000,-1000,135,-534,-1000,-1000,-659,-897}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00756() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "substring(int,int):java.lang.String",
            new int[]{-3,-203,-559,1000,-697,857,508,163,1000,66,86,-1000,-364,876,980,-969,1000,1000,257,1000,-1000,217,-1000,-1000,-1000,-799,-704,-1000,-1000,-131,-604,459,-232,-822,847,-1000,707,469,-153,-1000,1000,-582,75,-615,-274,119,-996,205,421,-691,-1000,1000,1000,1000,-308,-1000,-34,-1000,-295,1000,-1000,-1000,-557,424}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00757() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "substring(int,int):java.lang.String",
            new int[]{893,-442,47,-921,400,300,-921,-961,170,-540,-858,400,206,161,-143,-436,-129,-1000,585,516,-23,895,182,703,698,-265,-48,531,189,-8,563,-36,277,400,790,-300,308,102,231,-687,39,600,-370,165,1000,-555,400,-218,671,302,-423,184,762,401,611,-300,-392,118,-996,-122,-240,-370,1000,535}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00758() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "substring(int,int):java.lang.String",
            new int[]{99,-112,-403,72,-297,-135,-1000,899,1000,-438,510,-281,-935,-916,-934,1000,333,-922,-670,1000,-328,164,789,368,-462,218,-1000,1000,-209,-986,-133,-723,-336,882,289,787,-672,373,-1000,-671,-895,1000,-145,1000,157,-703,309,-630,-677,53,-748,1000,-168,828,260,495,869,1000,-850,-1000,929,-425,275,-92}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00759() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "substring(int,int):java.lang.String",
            new int[]{185,-1000,-80,1000,-919,689,843,-451,1000,792,-1000,852,1000,250,740,-575,719,1000,-155,1000,-1000,-560,-447,-194,-1000,-1000,118,-315,-1000,897,-1000,850,308,-941,634,-302,1000,259,350,-832,1000,653,248,-1000,806,165,-1000,-1000,705,862,-1000,381,937,277,1000,-824,605,-1000,-1000,489,-1000,-1000,-731,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00760() {
        org.junit.Assert.assertEquals("ARRAY:[C:1:24:java.lang.Character:AA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "toCharArray():char[]",
            new int[]{-315,-1000,502,168,-1000,-622,759,-996,61,-1000,-543,1000,-839,-753,398,-1000,1000,-98,737,-35,-178,-1000,-202,366,241,-731,570,-130,690,-1000,824,208,-741,158,-769,5,-206,932,103,-1000,211,-220,-542,472,1000,1000,325,171,108,-85,1000,889,397,950,1000,-740,602,-858,-1000,427,33,1000,1000,714}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00761() {
        org.junit.Assert.assertEquals("ARRAY:[C:0", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "toCharArray():char[]",
            new int[]{-376,-744,714,98,-338,599,-275,-483,659,544,-255,-529,427,-505,1000,-798,339,-869,-1000,114,1000,-197,-283,-674,-216,727,-678,1000,-893,-174,1000,614,-446,1000,-343,-124,-50,-1000,1000,-1000,-484,-323,-156,775,850,146,-787,-819,567,-615,-41,1000,505,803,123,99,-291,535,-975,263,-1000,1000,1000,354}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00762() {
        org.junit.Assert.assertEquals("ARRAY:[C:0", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "toCharArray():char[]",
            new int[]{-418,-1000,1000,66,-795,-1000,-511,-624,1000,-109,968,-153,-445,-936,267,-768,-101,-580,773,-1000,1000,-434,-286,-1000,471,804,-874,-511,-666,-539,-407,-1000,-210,876,314,1000,-1000,44,1000,-106,-1000,1000,-1000,-135,6,675,813,-1000,1000,-1000,934,746,-962,-458,-391,-1000,-1000,1000,-761,-1000,1000,606,692,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00763() {
        org.junit.Assert.assertEquals("ARRAY:[C:79:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==:24:java.lang.Character:AA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "toCharArray():char[]",
            new int[]{-223,-1000,656,325,-1000,-42,119,420,409,-583,-1000,332,790,-734,777,-1000,1000,-506,408,-791,60,-958,-953,-436,-52,-282,377,1000,383,-1000,341,-1000,-1000,334,-1000,-620,-305,-301,471,347,-1000,-1000,-203,283,614,32,-993,390,158,-66,1000,1000,446,354,1000,-341,-401,404,-1000,-333,-788,673,712,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00764() {
        org.junit.Assert.assertEquals("ARRAY:[C:0", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "toCharArray():char[]",
            new int[]{-281,-230,391,701,-511,824,528,-1000,-76,-492,-1000,-87,-309,-472,-1000,-660,948,239,196,-58,-273,150,-531,374,-191,81,352,-47,-67,-24,-2,-1000,976,-844,564,143,-100,-484,-878,1000,-1000,60,-336,-507,-573,385,-1000,-266,471,-248,326,1000,-763,-52,-1000,-289,-670,192,-930,-489,460,470,-773,410}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00765() {
        org.junit.Assert.assertEquals("ARRAY:[C:1:24:java.lang.Character:AQ==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "toCharArray():char[]",
            new int[]{1000,-231,-51,338,-1000,360,554,1000,776,-729,-854,654,287,-614,-47,-99,436,-606,257,-1000,-1000,444,-555,-171,-729,-51,-78,-600,4,-126,-1000,-1000,613,-335,-857,296,-53,-419,280,1000,-7,-1000,479,-657,297,-339,217,-853,-252,-241,808,602,-728,-1000,-668,218,-746,1000,-817,-599,-500,1000,-334,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00766() {
        org.junit.Assert.assertEquals("ARRAY:[C:0", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "toCharArray():char[]",
            new int[]{-678,-1000,145,-538,730,-311,2,1000,1000,819,-600,-1000,-1000,-180,-284,-1000,-913,-217,358,-214,678,1000,108,-1000,-933,-36,-1000,-354,-116,1000,-175,-1000,-678,-421,-200,1000,-1000,-369,-1000,858,-971,14,-11,6,128,1000,-487,273,29,-1000,-41,352,177,550,701,-1000,-604,1000,-596,-508,752,-952,-461,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00767() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "toCharArray(int,int):char[]",
            new int[]{110,-1000,-1000,595,-333,-553,64,-778,646,73,-646,-702,-877,659,-734,-508,479,-780,-388,642,-529,-1000,-1000,97,-429,-1000,-238,392,-133,-286,-389,213,609,532,203,457,959,-695,616,710,1000,-715,-24,825,-608,-422,780,-562,529,-344,-541,-612,-1000,-305,-755,108,274,13,101,618,-353,1000,300,968}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00768() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "toCharArray(int,int):char[]",
            new int[]{405,9,664,-478,701,498,-238,20,441,463,36,-323,-980,-948,-321,584,-38,-998,-256,-480,985,140,-971,366,994,-134,827,-943,102,825,-375,-221,-116,741,-559,-336,-301,208,-338,855,-925,-859,931,-529,-74,-470,940,754,-312,-832,-162,470,-679,96,-657,495,574,661,638,-540,910,-725,-331,-721}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00769() {
        org.junit.Assert.assertEquals("ARRAY:[C:0", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "toCharArray(int,int):char[]",
            new int[]{-1000,-1000,-1000,1000,-1000,191,-606,-268,31,-1000,101,-1000,-1000,844,475,297,-505,-582,-273,739,-456,-192,-578,-40,772,-335,356,326,144,577,-32,-339,374,1000,-1000,1000,729,128,-51,1000,-112,-1000,1000,1000,-14,-1000,-797,371,960,457,1000,1000,-1000,-1000,465,482,-343,802,-1000,290,1000,724,1000,-476}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00770() {
        org.junit.Assert.assertEquals("ARRAY:[C:4:24:java.lang.Character:Yg==:24:java.lang.Character:MA==:24:java.lang.Character:eA==:24:java.lang.Character:OA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "toCharArray(int,int):char[]",
            new int[]{110,-1000,-1000,961,-846,-1000,13,-458,887,-524,-726,-1000,-1000,659,-714,-139,-59,-780,-798,1000,-749,162,-1000,97,23,-1000,632,1000,-197,-968,-822,1000,300,-930,-309,892,1000,-802,1000,640,1000,-1000,-24,733,-123,-59,1000,-422,529,-1000,-500,-914,-1000,-1000,-729,84,1000,13,-110,1000,-213,562,1000,501}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00771() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "toCharArray(int,int):char[]",
            new int[]{-260,-526,400,-276,211,-166,-49,455,263,74,229,-367,-1000,-459,-174,-592,-235,326,5,-1000,268,-74,823,483,754,-576,-1000,-1000,-817,535,13,-923,666,948,-577,-187,438,344,-1000,1000,122,372,805,443,102,-1000,516,1000,835,-605,-520,640,831,567,-400,926,517,-1000,-73,-1000,1000,-501,-182,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00772() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "toCharArray(int,int):char[]",
            new int[]{789,-968,-1000,470,-47,890,1000,187,31,83,708,-1000,574,-207,-677,-386,-83,2,-591,809,1000,575,-1000,-784,-565,-780,940,1000,839,116,-288,1000,-403,-704,1000,-1000,-371,-1000,329,-557,-1000,-378,-964,-634,1000,1000,-425,-766,-1000,-304,15,-1000,1000,-1000,1000,1000,774,1000,1000,374,-718,1000,-1000,774}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00773() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "toCharArray(int,int):char[]",
            new int[]{879,-853,-52,0,19,0,394,227,-1000,-352,716,-793,989,-118,-800,-209,1000,0,-1000,-88,1000,575,-934,-578,-925,-55,-137,850,205,-25,-803,282,0,-1000,1000,-532,-1000,280,104,679,-842,313,-560,511,-426,806,236,-39,-19,-206,-89,-687,591,563,1000,826,-279,36,1000,-1000,134,340,-1000,859}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00774() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "toCharArray(int,int):char[]",
            new int[]{301,-916,-1000,200,-860,-1000,-713,-880,-126,-624,-1000,-504,-358,-260,701,808,1000,-828,-69,-661,-23,400,-1000,103,1000,-705,248,12,787,-98,212,-124,-650,284,191,-20,418,-460,295,909,411,-379,419,90,-739,-1000,-599,-1000,776,639,722,-616,-1000,316,388,-9,-361,-552,-660,-589,-871,1000,-536,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00775() {
        org.junit.Assert.assertEquals("java.lang.String:AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "toString():java.lang.String",
            new int[]{1000,-1000,1000,960,1000,277,463,362,1000,-1000,1000,-108,1000,611,-765,-1000,-415,-1000,-1000,1000,172,-1000,-444,10,-999,1000,1000,1000,-569,971,-1000,-261,680,929,-584,801,1000,1000,-1000,1000,-1000,-155,535,807,1000,-1000,223,-1000,178,638,1000,-1000,946,-1000,-477,-1000,615,1000,1000,-1000,-1000,1000,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00776() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "toString():java.lang.String",
            new int[]{970,-903,-851,-751,35,-739,-188,-1000,462,-1000,1000,261,1000,147,-1000,-1000,-1000,1000,-968,-400,524,1000,84,245,-719,-1000,157,980,-393,714,-511,216,-1000,-67,-132,1000,595,-88,-928,1000,-1000,-743,1000,1000,1000,31,-412,-1000,585,75,1000,-618,235,-1000,-414,-1000,-637,1000,-58,1,103,-299,-370,-225}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00777() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "toString():java.lang.String",
            new int[]{1000,-1000,-208,491,1000,23,684,-95,465,1000,286,84,401,1000,313,-325,-500,-94,-840,-82,242,1000,549,668,484,814,341,1000,-809,-157,-984,-851,613,-161,361,-901,928,1000,-1000,415,-803,-301,-283,52,-297,1000,437,-855,303,677,489,-820,477,-1000,-895,-1000,-385,40,744,369,-541,1000,35,546}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00778() {
        org.junit.Assert.assertEquals("java.lang.String:MA==", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "toString():java.lang.String",
            new int[]{992,-1000,-1000,1000,1000,-1000,69,421,417,85,841,-886,395,597,-509,-715,97,1000,-947,33,80,1000,-752,1000,1000,342,605,525,-882,676,-1000,-524,-6,268,-385,57,872,1000,-891,969,-501,-933,56,615,98,892,-165,-1000,1000,997,11,-227,-58,400,518,-680,150,721,276,-475,1000,488,577,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00779() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "toString():java.lang.String",
            new int[]{1000,-1000,701,-21,1000,1000,-322,529,1000,-389,776,807,1000,837,760,-678,-854,-1000,-674,90,-1000,339,816,-895,1000,-200,1000,1000,717,625,-811,121,-1000,-168,187,151,985,514,-1000,-794,-494,476,1000,1000,814,-1000,1000,-1000,165,249,258,-611,1000,-1000,1000,677,214,-90,952,83,-1000,-418,-1000,185}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00780() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "toString():java.lang.String",
            new int[]{1000,-1000,534,1000,-1000,314,799,722,1000,-450,1000,124,864,957,-116,-1000,67,-775,-1000,1000,-637,-1000,-520,332,664,-1000,1000,-151,167,-157,-1000,-578,490,-195,74,-724,-1000,1000,-1000,983,-740,222,611,1000,496,-1000,1000,-1000,517,1000,649,-1000,1000,-145,803,588,145,933,1000,-1000,-1000,1000,628,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00781() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "toString():java.lang.String",
            new int[]{-374,526,-323,-260,308,-23,370,-647,397,358,-1000,0,-584,-326,-509,-216,483,-1000,-593,-1000,579,-584,608,813,-321,156,-648,-293,-814,-540,540,294,1000,-674,-600,422,-656,435,1000,783,1000,777,-33,-776,-434,152,292,9,122,-433,-655,89,-85,1000,-167,1000,-463,-783,694,46,-873,-172,653,127}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00782() {
        org.junit.Assert.assertEquals("TYPE:java.lang.StringBuffer", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "toStringBuffer():java.lang.StringBuffer",
            new int[]{1000,215,-446,-155,-1000,934,-1000,1000,-891,-1000,163,224,-439,-863,1000,490,-660,-532,-1000,214,-275,-224,-780,-847,-1000,-916,-162,-477,-1000,861,-1000,611,891,-6,1000,367,844,1,556,858,-538,361,408,-124,1000,-1000,-433,-973,756,-926,471,-408,1000,293,-248,-469,260,4,-845,-113,1000,-439,1000,477}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00783() {
        org.junit.Assert.assertEquals("TYPE:java.lang.StringBuffer", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "toStringBuffer():java.lang.StringBuffer",
            new int[]{171,867,-191,-478,-282,719,962,164,534,984,-555,-697,702,10,821,-643,-499,645,376,314,225,697,-31,839,581,758,677,598,-191,-965,-938,-598,-323,34,420,774,57,-787,461,572,921,-963,-452,-563,-708,-725,804,984,-80,-162,-769,-86,277,-58,-720,-502,-139,-981,-737,271,690,363,426,-816}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00784() {
        org.junit.Assert.assertEquals("TYPE:java.lang.StringBuffer", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "toStringBuffer():java.lang.StringBuffer",
            new int[]{-450,188,-686,-888,265,-356,-659,146,-1000,312,-549,9,-50,71,1000,328,285,1000,-1000,1000,21,-1000,-476,-69,-8,-128,-90,263,-700,-772,-256,-1000,-921,51,-483,226,-332,976,508,588,-1000,189,-1000,90,-930,-1000,-138,165,-76,-543,-1000,-1000,773,990,-1000,-175,298,-957,585,554,-421,144,97,491}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00785() {
        org.junit.Assert.assertEquals("TYPE:java.lang.StringBuffer", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "toStringBuffer():java.lang.StringBuffer",
            new int[]{-912,-1000,20,1000,-1000,318,-68,-308,-438,1000,194,-703,-37,608,1000,1000,467,-1000,-950,1000,1000,1000,282,848,-122,333,1000,363,1000,-1000,-290,-596,306,482,821,207,1000,984,1000,-1000,-1000,943,507,1000,-34,-680,-1000,-458,-511,-961,-1000,1000,397,664,15,-1000,503,318,-1000,-763,112,-1000,439,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00786() {
        org.junit.Assert.assertEquals("TYPE:java.lang.StringBuffer", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "toStringBuffer():java.lang.StringBuffer",
            new int[]{-1000,1000,653,271,874,-659,-413,1000,-78,-554,65,-109,-268,511,-666,233,680,334,-736,1000,-579,-1000,1000,-368,1000,-1000,1000,-1000,-1000,-1000,1000,-1000,-1000,-175,-1000,-1000,-142,-811,-1000,427,-829,58,-919,-1000,-323,354,170,-774,-298,-505,-650,-1000,-16,-275,150,-39,153,-338,-171,477,-769,698,-554,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00787() {
        org.junit.Assert.assertEquals("TYPE:java.lang.StringBuffer", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "toStringBuffer():java.lang.StringBuffer",
            new int[]{-1000,-1000,-866,-760,-3,-1000,-956,718,562,-893,-211,51,891,-1000,888,498,-1000,1000,-902,792,702,679,-174,-320,-961,-806,-261,1000,-408,476,411,-979,416,680,-277,-559,-520,994,631,470,17,-1000,402,857,791,-1000,1000,-999,839,221,-111,-1000,962,921,-188,26,-70,-679,-1000,718,1000,-500,1000,813}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00788() {
        org.junit.Assert.assertEquals("TYPE:java.lang.StringBuffer", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "toStringBuffer():java.lang.StringBuffer",
            new int[]{-1000,-790,-464,1000,-737,-496,-797,241,107,1000,810,-693,34,547,252,457,-1000,-1000,-1000,342,1000,937,928,78,148,348,1000,915,700,-1000,-710,-322,-605,-16,374,-504,1000,446,663,-1000,-838,1000,-38,768,640,86,-389,-647,-696,-1000,-1000,1000,1000,601,303,-1000,528,1000,-522,6,1000,-453,515,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00789() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "trim():org.apache.commons.lang.text.StrBuilder",
            new int[]{-26,179,595,460,998,-141,394,-1000,225,515,-148,-344,-1000,-74,492,-1000,232,-141,-107,595,-1000,-581,-101,-580,-114,64,1000,-140,657,-570,-291,60,-1000,1000,1000,465,270,986,464,265,-327,345,-203,-1000,121,-1000,172,-829,364,-1000,-607,1000,687,-517,819,1000,-1000,607,-666,465,466,274,-461,542}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00790() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "trim():org.apache.commons.lang.text.StrBuilder",
            new int[]{132,-4,775,-25,634,748,412,-572,-782,-307,-648,834,1000,-501,-169,289,-144,-222,610,56,-1,747,-165,-292,-46,336,32,-164,354,-107,-569,-353,-511,-765,-1000,-393,636,-139,-447,378,142,-408,-164,321,901,-140,-1000,541,-694,764,235,-56,225,694,-363,825,847,-576,13,416,168,608,1000,116}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00791() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "trim():org.apache.commons.lang.text.StrBuilder",
            new int[]{1000,387,-103,362,998,-661,7,-1000,715,1000,-94,-33,-666,757,-880,-1000,243,-141,-107,986,-1000,-1000,1000,491,-540,-402,1000,-263,1,855,-965,-1000,-1000,1000,1000,258,270,1000,662,-142,-782,554,464,-581,121,-520,43,-1000,-56,-1000,295,1000,997,-1000,-1000,-83,-764,1000,214,839,-131,317,-324,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00792() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "trim():org.apache.commons.lang.text.StrBuilder",
            new int[]{383,-934,826,214,156,-358,-263,-1000,-1000,-21,-1000,59,679,991,-510,-1000,119,741,1000,1000,349,-1000,-971,487,36,460,1000,-340,-248,701,-1000,390,536,1000,186,-80,1000,843,1000,689,-1000,609,598,-752,1000,616,-679,-1000,-210,1000,-846,1000,-36,1000,844,1000,-1000,1000,434,50,818,780,668,833}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00793() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "trim():org.apache.commons.lang.text.StrBuilder",
            new int[]{-1000,-173,1000,102,314,317,48,365,359,1000,109,-107,1000,-998,125,60,-696,-255,994,-815,-82,184,-387,277,9,-297,-399,1000,-284,866,332,962,-8,-400,-339,105,437,-762,-707,-414,703,-976,-796,145,505,596,164,376,223,-398,518,-546,236,780,5,1000,226,-61,-1000,596,304,42,538,637}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00794() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "trim():org.apache.commons.lang.text.StrBuilder",
            new int[]{214,-478,1000,-80,-1000,-486,629,-89,-1000,-1000,-473,-141,1000,544,-958,-1000,-107,610,1000,174,-776,-192,126,99,-863,372,952,206,-413,1000,-783,659,-1000,-639,168,-1000,193,-634,771,1000,-938,-429,116,816,-19,33,-1000,-822,-784,757,-779,-132,-339,-469,-379,762,132,855,1000,-1000,1000,1000,-1000,-390}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00795() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "trim():org.apache.commons.lang.text.StrBuilder",
            new int[]{967,-922,269,-1000,627,1000,544,83,-482,719,-45,-136,611,-1000,741,129,-366,-817,951,-1000,-1000,-475,-933,-788,604,1000,-1000,407,-696,265,1000,964,660,-935,-1000,-503,94,-955,214,-147,1000,-1000,-753,-631,682,185,-658,-14,1000,1000,1000,-1000,-767,1000,1000,175,157,-1000,-1000,-825,932,578,-139,-483}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00796() {
        org.junit.Assert.assertEquals("TYPE:org.apache.commons.lang.text.StrBuilder", DEReplay.run(
            "org.apache.commons.lang.text.StrBuilder", "org.apache.commons.lang.text.StrBuilder", "trim():org.apache.commons.lang.text.StrBuilder",
            new int[]{777,-1000,-992,-65,751,-463,466,-794,-232,-523,-141,-1000,-559,743,-918,-172,-681,881,-608,-1000,-419,-957,-237,-83,-322,428,1000,157,-248,-94,386,1000,-54,-14,1000,-897,-1000,-1000,277,-145,298,-1000,-326,244,483,592,1000,-373,691,1000,-600,-652,657,-901,1000,-1000,-203,-324,471,-407,313,352,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00797() {
        org.junit.Assert.assertEquals("java.lang.String:QA==", DEReplay.run(
            "org.apache.commons.lang.text.StrSubstitutor", "org.apache.commons.lang.text.StrSubstitutor", "replace(char[]):java.lang.String",
            new int[]{-337,410,-774,878,100,493,-914,633,528,736,871,-971,38,-312,-604,846,893,-880,952,-259,-405,-94,633,265,-727,186,-90,638,833,535,995,810,-511,-900,-45,97,-477,-513,77,-948,-565,-443,566,-870,-14,240,-714,-833,-913,-59,-31,-251,-64,235,81,-891,401,114,-630,-606,211,-710,-993,-187}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00798() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrSubstitutor", "org.apache.commons.lang.text.StrSubstitutor", "replace(char[]):java.lang.String",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00799() {
        org.junit.Assert.assertEquals("java.lang.String:NA==", DEReplay.run(
            "org.apache.commons.lang.text.StrSubstitutor", "org.apache.commons.lang.text.StrSubstitutor", "replace(char[],int,int):java.lang.String",
            new int[]{-386,176,1000,-1000,1000,-460,-35,-1000,48,394,-161,563,-179,-1000,-268,575,-624,1000,-413,-751,-1000,-1000,1000,658,189,1000,-26,-1000,842,1000,-903,-507,982,847,666,-442,-281,-362,-670,-325,249,1000,-68,1000,220,10,1000,-1000,127,-782,485,555,-1000,-269,-836,-298,538,-327,-917,-1000,701,-62,555,-256}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00800() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrSubstitutor", "org.apache.commons.lang.text.StrSubstitutor", "replace(char[],int,int):java.lang.String",
            new int[]{-252,528,35,434,-896,-479,852,-355,106,206,-9,331,-546,-656,996,-449,542,896,135,-239,-99,445,-172,-38,-966,71,-692,-602,-29,-625,-941,-816,-724,209,84,372,198,-396,995,180,210,-641,-464,-633,-742,-186,237,-920,711,-561,614,870,223,-956,553,-946,-504,-355,-634,97,274,335,352,-720}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00801() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrSubstitutor", "org.apache.commons.lang.text.StrSubstitutor", "replace(char[],int,int):java.lang.String",
            new int[]{-560,-63,931,-298,973,-482,-443,-768,305,246,-237,60,219,-662,-174,453,-71,902,-66,243,-928,-629,-821,569,39,992,-431,-347,697,835,-613,-241,-14,632,666,-428,-143,-331,-433,-505,510,965,-31,569,34,2,-238,-881,173,-618,-25,555,-820,-20,-834,-738,508,-635,-738,-992,413,-405,478,-130}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00802() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.lang.text.StrSubstitutor", "org.apache.commons.lang.text.StrSubstitutor", "replace(char[],int,int):java.lang.String",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00803() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrSubstitutor", "org.apache.commons.lang.text.StrSubstitutor", "replace(char[],int,int):java.lang.String",
            new int[]{334,-506,275,-304,225,-421,-584,-226,-1000,476,-538,-1000,184,1000,-706,9,-1000,-200,656,775,-431,287,142,-930,865,-540,306,1000,-51,221,1000,380,451,-851,185,-825,-825,1000,397,222,-715,665,673,-553,-116,598,-910,840,440,-571,728,-1000,155,-597,-478,-340,-3,-147,916,716,-224,-475,370,-365}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00804() {
        org.junit.Assert.assertEquals("THROW:java.lang.StringIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.lang.text.StrSubstitutor", "org.apache.commons.lang.text.StrSubstitutor", "replace(char[],int,int):java.lang.String",
            new int[]{474,826,-168,-638,494,623,291,-912,-724,-681,-331,83,-619,-658,-14,-228,-887,-973,-790,-578,702,-879,73,871,-47,884,909,-628,-545,552,-585,-550,866,-272,-393,820,-244,-774,-711,-392,-980,871,-102,414,-30,-195,725,-960,-112,956,-818,145,-985,-483,72,514,751,493,-403,-846,196,704,232,16}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00805() {
        org.junit.Assert.assertEquals("java.lang.String:b2JqZWN0MA==", DEReplay.run(
            "org.apache.commons.lang.text.StrSubstitutor", "org.apache.commons.lang.text.StrSubstitutor", "replace(java.lang.Object):java.lang.String",
            new int[]{-851,-188,-48,-907,-629,387,31,109,-49,-959,513,-914,-289,-330,-801,-111,-345,-253,818,-977,-902,120,-483,-704,-440,991,803,305,379,576,681,418,-456,354,503,-321,-294,-565,610,153,530,647,218,-351,611,169,-764,440,-991,-780,-337,655,140,213,76,339,239,-970,330,824,888,-363,-943,-972}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00806() {
        org.junit.Assert.assertEquals("java.lang.String:b2JqZWN0Mg==", DEReplay.run(
            "org.apache.commons.lang.text.StrSubstitutor", "", "replace(java.lang.Object,java.util.Map):java.lang.String",
            new int[]{-317,847,437,-607,-486,25,114,186,-958,-660,568,-585,849,925,-555,785,-178,-843,815,-294,-986,-929,-664,410,587,-620,849,-440,812,-873,716,-293,981,915,-242,-291,783,-128,997,363,-792,13,572,-59,366,528,-812,44,-258,-346,229,-729,350,-738,-701,540,16,-939,-672,-394,595,-587,-344,-708}));
    }
}
