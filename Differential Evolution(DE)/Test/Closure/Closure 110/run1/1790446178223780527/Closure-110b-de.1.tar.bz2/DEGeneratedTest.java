import java.lang.reflect.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Deterministic test-program decoder. Used unchanged during search and JUnit replay. */
final class DEReplay {
    public static final int DIMENSIONS = 64;
    /** Local generic bean used to create stable reflection Type and Field values. */
    public static final class GenericInput {
        public String text;
        public java.util.List<String> names;
        public java.util.Map<String, Integer> counts;
        public java.util.List<java.util.Map<String, Long>> nested;
        public int[] numbers;
        public String[] words;
    }
    static final class Genes {
        final int[] values; int at; Field lastField;
        Object jacksonBean, jacksonProvider, jacksonGenerator;
        StringWriter jacksonOutput;
        Genes(int[] values) { this.values = values; }
        int next() { return values[(at++) % values.length]; }
        int pick(int n) { return Math.floorMod(next(), n); }
    }
    public static final class Observation {
        public String token, error, generatedSource;
        public boolean reachedTarget;
        public int setupCalls, setupFailures, nullFallbacks;
    }
    public static String signature(Method m) {
        StringJoiner params = new StringJoiner(",");
        for (Class<?> t : m.getParameterTypes()) params.add(t.getTypeName());
        return m.getName() + "(" + params + "):" + m.getReturnType().getTypeName();
    }
    static Class<?> load(String name) throws ClassNotFoundException {
        return Class.forName(name, true, Thread.currentThread().getContextClassLoader());
    }
    static Method method(String target, String signature) throws Exception {
        for (Method m : load(target).getDeclaredMethods())
            if (signature(m).equals(signature)) {
                // Public methods on package-private Defects4J classes (for
                // example Gson's TypeInfoFactory) are not reflectively
                // accessible until opened on the unnamed application module.
                if (!m.isAccessible()) m.setAccessible(true);
                return m;
            }
        throw new NoSuchMethodException(signature);
    }
    static List<Constructor<?>> constructors(Class<?> type) {
        List<Constructor<?>> out = new ArrayList();
        if (!Modifier.isAbstract(type.getModifiers()) && Modifier.isPublic(type.getModifiers()))
            for (Constructor<?> c : type.getConstructors())
                if (c.getParameterTypes().length <= 6) out.add(c);
        Collections.sort(out, new Comparator<Constructor<?>>() {
            public int compare(Constructor<?> a, Constructor<?> b) {
                int byArity = a.getParameterTypes().length - b.getParameterTypes().length;
                return byArity != 0 ? byArity : a.toString().compareTo(b.toString());
            }
        });
        return out;
    }
    private static Object[] arguments(Class<?>[] types, Genes g, int depth,
                                      Observation report) throws Exception {
        Object[] args = new Object[types.length];
        for (int i = 0; i < types.length; i++) args[i] = value(types[i], g, depth, report);
        return args;
    }
    private static Object[] arguments(Method method, Genes g, int depth,
                                      Observation report) throws Exception {
        Class<?>[] types = method.getParameterTypes();
        Object[] args = new Object[types.length];
        boolean closureCompile = method.getDeclaringClass().getName().equals("com.google.javascript.jscomp.Compiler")
            && method.getName().equals("compile");
        Type[] generic = method.getGenericParameterTypes();
        boolean jacksonSerialization = method.getDeclaringClass().getName().equals(
            "com.fasterxml.jackson.databind.ser.BeanPropertyWriter")
            && method.getName().startsWith("serializeAs")
            && types.length == 3 && types[0] == Object.class;
        for (int i = 0; i < types.length; i++) {
            if (jacksonSerialization && g.jacksonBean != null) {
                if (i == 0) args[i] = g.jacksonBean;
                else if (i == 1) args[i] = g.jacksonGenerator;
                else args[i] = g.jacksonProvider;
                continue;
            }
            if (closureCompile && (List.class.isAssignableFrom(types[i])
                    || (types[i].isArray() && load("com.google.javascript.jscomp.SourceFile")
                        .isAssignableFrom(types[i].getComponentType())))) {
                // Compiler.compile takes externs and inputs in either Lists or
                // arrays depending on Closure version. Keep externs empty and
                // supply a nonempty, gene-selected input program.
                if (i == 0) args[i] = types[i].isArray()
                    ? Array.newInstance(types[i].getComponentType(), 0) : new ArrayList();
                else {
                    Object sourceFile = value(load("com.google.javascript.jscomp.SourceFile"),
                        g, depth + 1, report);
                    if (types[i].isArray()) {
                        Object files = Array.newInstance(types[i].getComponentType(), 1);
                        Array.set(files, 0, sourceFile); args[i] = files;
                    } else args[i] = new ArrayList(Collections.singletonList(sourceFile));
                }
            } else args[i] = value(types[i], g, depth, report);
        }
        return args;
    }
    private static Number number(Genes g) {
        int n = g.next();
        switch (g.pick(12)) {
            case 0: return 0; case 1: return 1; case 2: return -1;
            case 3: return Integer.MAX_VALUE; case 4: return Integer.MIN_VALUE;
            case 5: return Long.MAX_VALUE; case 6: return Long.MIN_VALUE;
            case 7: return Double.NaN; case 8: return Double.POSITIVE_INFINITY;
            case 9: return Double.NEGATIVE_INFINITY; case 10: return n / 10.0;
            default: return n;
        }
    }
    private static String string(Genes g) {
        int mode = g.pick(16), n = g.next();
        String digits = Long.toString(Math.abs((long)n));
        String sign = new String[]{"", "-", "+", "--"}[g.pick(4)];
        switch (mode) {
            case 0: return null; case 1: return ""; case 2: return " ";
            case 3: return Integer.toString(n);
            case 4: return sign + digits;
            case 5: return sign + digits + "." + g.pick(1000);
            case 6: return sign + digits + "e" + g.next();
            case 7: return sign + "0x" + Long.toHexString(Math.abs((long)n));
            case 8: return sign + "0x8" + "0".repeat(g.pick(20));
            case 9: return sign + digits + "fFdDlL".charAt(g.pick(6));
            case 10: return " " + sign + digits + " ";
            case 11: return new String[]{"true", "false", "null", "NaN", "Infinity"}[g.pick(5)];
            case 12: return "a".repeat(g.pick(25));
            default:
                String alphabet = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ+-._ /\\\t\n";
                StringBuilder s = new StringBuilder();
                int length = g.pick(25);
                for (int i = 0; i < length; i++) s.append(alphabet.charAt(g.pick(alphabet.length())));
                return s.toString();
        }
    }
    private static Object value(Class<?> t, Genes g, int depth, Observation report) throws Exception {
        if (t == String.class || t == CharSequence.class) return string(g);
        if (t == Comparable.class) return "key" + g.pick(5);
        if (t == boolean.class || t == Boolean.class) return g.pick(2) == 0;
        if (t == char.class || t == Character.class) return (char)g.pick(128);
        if (t == byte.class || t == Byte.class) return number(g).byteValue();
        if (t == short.class || t == Short.class) return number(g).shortValue();
        if (t == int.class || t == Integer.class) return number(g).intValue();
        if (t == long.class || t == Long.class) return number(g).longValue();
        if (t == float.class || t == Float.class) return number(g).floatValue();
        if (t == double.class || t == Double.class || t == Number.class) return number(g).doubleValue();
        if (t.isEnum()) {
            Object[] constants = t.getEnumConstants();
            return constants.length == 0 ? null : constants[g.pick(constants.length)];
        }
        if (t == Object.class) return g.pick(3) == 0 ? null : "object" + g.pick(5);
        if (depth >= 3) { report.nullFallbacks++; return null; }
        if (t.isArray()) {
            int length = g.pick(6);
            Object array = Array.newInstance(t.getComponentType(), length);
            for (int i = 0; i < length; i++) Array.set(array, i, value(t.getComponentType(), g, depth + 1, report));
            return array;
        }
        if (t == List.class || t == Collection.class || t == Iterable.class || t == Set.class) {
            Collection<Object> items = t == Set.class ? new LinkedHashSet() : new ArrayList();
            int size = g.pick(5);
            for (int i = 0; i < size; i++) items.add("item" + g.pick(5));
            return items;
        }
        if (t == Map.class) {
            Map<Object, Object> items = new LinkedHashMap();
            int size = g.pick(5);
            for (int i = 0; i < size; i++) items.put("key" + g.pick(5), number(g));
            return items;
        }
        if (t == java.util.Date.class) return new java.util.Date(g.next() * 86400000L);
        if (t == Class.class) return String.class;
        if (t == java.lang.reflect.Field.class) {
            Field[] fields = GenericInput.class.getFields();
            g.lastField = fields[g.pick(fields.length)];
            return g.lastField;
        }
        if (t == java.lang.reflect.Type.class) {
            if (g.lastField != null && g.pick(3) == 0)
                return g.lastField.getDeclaringClass();
            Field[] fields = GenericInput.class.getFields();
            return fields[g.pick(fields.length)].getGenericType();
        }
        if (t == java.io.Reader.class || t == java.io.BufferedReader.class
                || t == java.io.StringReader.class) {
            String content = "header,value\n" + string(g) + "," + number(g) + "\n"
                + "alpha,beta\n";
            StringReader reader = new StringReader(content);
            return t == java.io.BufferedReader.class ? new BufferedReader(reader) : reader;
        }
        if (t.getName().equals("org.apache.commons.csv.CSVFormat")) {
            Class<?> format = load("org.apache.commons.csv.CSVFormat");
            for (String fieldName : new String[]{"DEFAULT", "RFC4180", "EXCEL"}) try {
                Object result = format.getField(fieldName).get(null);
                if (t.isInstance(result)) return result;
            } catch (ReflectiveOperationException ignored) { }
            for (Method factory : format.getMethods())
                if (Modifier.isStatic(factory.getModifiers()) && factory.getParameterTypes().length == 0
                        && t.isAssignableFrom(factory.getReturnType())) try {
                    return factory.invoke(null);
                } catch (ReflectiveOperationException ignored) { }
        }
        if (t.getName().equals("com.google.javascript.jscomp.SourceFile")) {
            Class<?> source = load("com.google.javascript.jscomp.SourceFile");
            for (Method factory : source.getMethods())
                if (Modifier.isStatic(factory.getModifiers()) && factory.getName().equals("fromCode")
                        && factory.getParameterTypes().length == 2 && factory.getParameterTypes()[0] == String.class
                        && factory.getParameterTypes()[1] == String.class) {
                    String replaySource = System.getProperty("de.generated.source");
                    if (replaySource != null) {
                        try {
                            report.generatedSource = replaySource;
                            return factory.invoke(null, "de-input.js", replaySource);
                        } catch (ReflectiveOperationException ignored) { }
                    }
                    String[] unusedParameterScripts = {
                        "window.f = function(a) {};",
                        "window.f = function(a, b) { return b; };",
                        "window.f = function(a, b) { var used = b; return used; };",
                        "window['f'] = function(unused) {};",
                        "window.f = function(unused, value) { return value; };",
                        "window['f'] = function(unused, value) { return value; };",
                        "window.f = function(first, unused, last) { return last; };",
                        "window.f = function(unused) { var local = 1; return local; };",
                        "window.f = function(unused, value) { var alias = value; return alias; };",
                        "window.f = function(unused, value) { if (value) { return 1; } return 2; };",
                        "window.f = function(unused, value) { value = value + 1; return value; };",
                        "window.f = function(unused, value) { return function() { return value; }; };",
                        "window.f = function(unused) { function inner() { return 1; } return inner(); };",
                        "window.f = function(a, b, unused) { return a + b; };",
                        "window.f = function(a, unused, b, c) { return a + c; };"
                    };
                    String[] catchDependencyScripts = {
                        "window.f = function() { var saved; try { throw Error('x'); } catch (caught) { saved = caught; } return saved.stack; };",
                        "window.f = function(flag) { var saved; try { if (flag) throw Error('x'); } catch (caught) { saved = caught; } return saved.message; };",
                        "window.f = function() { var saved; try { throw Error('x'); } catch (caught) { saved = caught; } return saved.name; };",
                        "window.f = function() { var saved; try { throw Error('x'); } catch (caught) { saved = caught; } return String(saved); };",
                        "window.f = function(flag) { var saved; try { if (flag) throw Error('x'); } catch (problem) { saved = problem; } return saved.stack; };",
                        "window.f = function() { var saved; try { throw Error('x'); } catch (problem) { saved = problem; } return saved.message; };"
                    };
                    String[] genericScripts = {
                        "function f(unused, used) { var local = 1; return used; } f(1, 2);",
                        "function f() { var unused = 1; var used = 2; return used; } f();",
                        "function f(x) { var first = x; first = 3; return x; } f(2);",
                        "function f() { var unused = 1; } f();",
                        "function keep() { var dead = 1; return 7; } keep();"
                    };
                    String modified = System.getProperty("de.modified.classes", "");
                    String[] scripts;
                    if (modified.contains("RemoveUnusedVars") && modified.contains("FlowSensitiveInlineVariables")) {
                        scripts = new String[unusedParameterScripts.length + catchDependencyScripts.length];
                        System.arraycopy(unusedParameterScripts, 0, scripts, 0, unusedParameterScripts.length);
                        System.arraycopy(catchDependencyScripts, 0, scripts, unusedParameterScripts.length,
                            catchDependencyScripts.length);
                    }
                    else if (modified.contains("FlowSensitiveInlineVariables")) scripts = catchDependencyScripts;
                    else if (modified.contains("RemoveUnusedVars")) scripts = unusedParameterScripts;
                    else scripts = genericScripts;
                    try {
                        String code = scripts[g.pick(scripts.length)];
                        report.generatedSource = code;
                        return factory.invoke(null, "de-input.js", code);
                    }
                    catch (ReflectiveOperationException ignored) { }
                }
        }
        if (t.getName().equals("com.google.javascript.jscomp.CompilerOptions")) {
            try {
                Object options = t.getConstructor().newInstance();
                // In Closure Compiler, unused-variable passes are enabled by
                // CompilationLevel, rather than by a CompilerOptions enum
                // setter. Apply the real public configuration when available.
                try {
                    Class<?> levelType = load("com.google.javascript.jscomp.CompilationLevel");
                    Object advanced = levelType.getField("ADVANCED_OPTIMIZATIONS").get(null);
                    for (Method configure : levelType.getMethods())
                        if (configure.getName().equals("setOptionsForCompilationLevel")
                                && configure.getParameterTypes().length == 1
                                && configure.getParameterTypes()[0].isInstance(options)) {
                            configure.invoke(advanced, options); break;
                        }
                } catch (ReflectiveOperationException ignored) { }
                // Also set the relevant options directly for Closure releases
                // whose compilation-level helper no longer enables this pass.
                for (Class<?> current = t; current != null; current = current.getSuperclass())
                    for (Field field : current.getDeclaredFields()) {
                        String name = field.getName().toLowerCase(Locale.ROOT);
                        if (field.getType() == boolean.class && name.equals("removeglobals")) try {
                            // Closure-1 specifically guards argument removal
                            // when globals are preserved. Keep the optimization
                            // pass enabled while exercising that configuration.
                            field.setAccessible(true); field.setBoolean(options, false);
                        } catch (Exception ignored) { }
                        if (field.getType() == boolean.class
                                && (name.contains("removeunusedvar") || name.contains("removeunusedlocal"))) try {
                            field.setAccessible(true); field.setBoolean(options, true);
                        } catch (Exception ignored) { }
                    }
                for (Method setter : t.getMethods()) {
                    if (!Modifier.isPublic(setter.getModifiers()) || !setter.getName().startsWith("set")
                            || setter.getParameterTypes().length != 1) continue;
                    String name = setter.getName().toLowerCase(Locale.ROOT);
                    if (setter.getParameterTypes()[0] == boolean.class && name.contains("removeglobals")) {
                        try { setter.invoke(options, false); } catch (ReflectiveOperationException ignored) { }
                    } else if (setter.getParameterTypes()[0] == boolean.class
                            && (name.contains("removeunusedvar") || name.contains("removeunusedlocal"))) {
                        try { setter.invoke(options, true); } catch (ReflectiveOperationException ignored) { }
                    } else if (name.contains("optimizationlevel")
                            && setter.getParameterTypes()[0].isEnum()) {
                        Object[] values = setter.getParameterTypes()[0].getEnumConstants();
                        for (Object value : values) if (String.valueOf(value).contains("ADVANCED"))
                            try { setter.invoke(options, value); } catch (ReflectiveOperationException ignored) { }
                    }
                }
                return options;
            } catch (ReflectiveOperationException ignored) { }
        }
        if (t.getName().equals("com.google.javascript.rhino.Node")) {
            try {
                Class<?> ir = load("com.google.javascript.rhino.IR");
                for (String factoryName : new String[]{"script", "root", "name", "string"})
                    for (Method factory : ir.getMethods())
                        if (Modifier.isStatic(factory.getModifiers()) && factory.getName().equals(factoryName)
                                && factory.getParameterTypes().length == 0 && t.isAssignableFrom(factory.getReturnType()))
                            return factory.invoke(null);
            } catch (ReflectiveOperationException ignored) { }
        }
        if (t.getName().equals("com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser")) {
            Object parser = xmlParser(g, report);
            if (parser != null && t.isInstance(parser)) return parser;
        }
        if (t.getName().equals("com.fasterxml.jackson.databind.ser.BeanPropertyWriter")
                || t.getName().equals("com.fasterxml.jackson.databind.ser.impl.UnwrappingBeanPropertyWriter")) {
            Object writer = jacksonWriter(t, g, report);
            if (writer != null && t.isInstance(writer)) return writer;
        }
        if (t == java.awt.Graphics2D.class || t == java.awt.Graphics.class)
            return new java.awt.image.BufferedImage(80, 80, java.awt.image.BufferedImage.TYPE_INT_ARGB).createGraphics();
        if (java.awt.Paint.class.isAssignableFrom(t)) {
            java.awt.Color c = new java.awt.Color(g.pick(256), g.pick(256), g.pick(256));
            if (t.isInstance(c)) return c;
        }
        if (java.awt.Stroke.class.isAssignableFrom(t)) {
            java.awt.BasicStroke s = new java.awt.BasicStroke(g.pick(10) / 2.0f);
            if (t.isInstance(s)) return s;
        }
        if (java.awt.Shape.class.isAssignableFrom(t)) {
            java.awt.Shape s = new java.awt.geom.Rectangle2D.Double(g.next(), g.next(), g.pick(80), g.pick(80));
            if (t.isInstance(s)) return s;
        }
        if (t == java.awt.geom.Point2D.class) return new java.awt.geom.Point2D.Double(g.next(), g.next());
        if (t.getName().equals("org.apache.commons.cli.CommandLine"))
            return commandLine(g, report);
        Object domain = chart(t, g, report);
        if (domain != null) return domain;
        Object language = language(t, g, report);
        if (language != null) return language;
        List<Constructor<?>> ctors = constructors(t);
        // Older Java libraries often use public singleton constants in place of enums.
        if (ctors.isEmpty()) {
            List<Field> constants = new ArrayList();
            for (Field field : t.getFields())
                if (Modifier.isStatic(field.getModifiers()) && Modifier.isFinal(field.getModifiers())
                        && t.isAssignableFrom(field.getType())) constants.add(field);
            Collections.sort(constants, new Comparator<Field>() {
                public int compare(Field a, Field b) { return a.getName().compareTo(b.getName()); }
            });
            if (!constants.isEmpty()) {
                Object constant = constants.get(g.pick(constants.size())).get(null);
                if (constant != null) return constant;
            }
        }
        if (!ctors.isEmpty()) {
            Constructor<?> ctor = ctors.get(g.pick(ctors.size()));
            try { return ctor.newInstance(arguments(ctor.getParameterTypes(), g, depth + 1, report)); }
            catch (Exception ignored) { }
        }
        report.nullFallbacks++;
        return null;
    }
    private static Object language(Class<?> t, Genes g, Observation report) {
        if (!t.getName().equals("org.apache.commons.lang3.time.FastDateFormat")) return null;
        try {
            Method factory = t.getMethod("getInstance", String.class, java.util.TimeZone.class,
                java.util.Locale.class);
            String[] patterns = {"yyyy-MM-dd", "MM/dd/yy HH:mm:ss", "EEE, d MMM yyyy HH:mm:ss Z"};
            return factory.invoke(null, patterns[g.pick(patterns.length)],
                java.util.TimeZone.getTimeZone("UTC"), java.util.Locale.US);
        } catch (ReflectiveOperationException ignored) { }
        try { return t.getMethod("getInstance", String.class).invoke(null, "yyyy-MM-dd"); }
        catch (ReflectiveOperationException ignored) { return null; }
    }
    private static Object xmlParser(Genes g, Observation report) {
        try {
            Class<?> factoryType = load("com.fasterxml.jackson.dataformat.xml.XmlFactory");
            Object factory = factoryType.getConstructor().newInstance();
            String[] docs = {"<root><value>1</value><name>x</name></root>",
                "<root value=\"42\"><item>a</item><item>b</item></root>",
                "<root/>"};
            String xml = docs[g.pick(docs.length)];
            for (Method method : factoryType.getMethods()) {
                if (!method.getName().equals("createParser") || method.getParameterTypes().length != 1) continue;
                Class<?> p = method.getParameterTypes()[0];
                Object input = p == String.class ? xml : p == Reader.class ? new StringReader(xml)
                    : p == InputStream.class ? new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8)) : null;
                if (input == null) continue;
                try {
                    Object parser = method.invoke(factory, input);
                    if (parser != null) {
                        int advance = g.pick(4);
                        Method next = parser.getClass().getMethod("nextToken");
                        for (int i = 0; i < advance; i++) if (next.invoke(parser) == null) break;
                        return parser;
                    }
                } catch (ReflectiveOperationException ignored) { }
            }
        } catch (Throwable ignored) { }
        return null;
    }
    private static Object jacksonWriter(Class<?> requested, Genes g, Observation report) {
        try {
            Class<?> mapperType = load("com.fasterxml.jackson.databind.ObjectMapper");
            Object mapper = mapperType.getConstructor().newInstance();
            Object bean = new GenericInput();
            Class<?> javaTypeType = load("com.fasterxml.jackson.databind.JavaType");
            Object javaType = mapperType.getMethod("constructType", Type.class).invoke(mapper, bean.getClass());
            // Jackson 2.6 (used by this Defects4J project) exposes a provider
            // blueprint from ObjectMapper. Create a configured provider via
            // DefaultSerializerProvider, the supported API used by ObjectMapper.
            Object providerBlueprint = mapperType.getMethod("getSerializerProvider").invoke(mapper);
            Class<?> serializationConfigType = load("com.fasterxml.jackson.databind.SerializationConfig");
            Class<?> serializerFactoryType = load("com.fasterxml.jackson.databind.ser.SerializerFactory");
            Object config = mapperType.getMethod("getSerializationConfig").invoke(mapper);
            Object factory = mapperType.getMethod("getSerializerFactory").invoke(mapper);
            Class<?> defaultProviderType = load("com.fasterxml.jackson.databind.ser.DefaultSerializerProvider");
            Method createProvider = defaultProviderType.getMethod("createInstance",
                serializationConfigType, serializerFactoryType);
            Object provider = createProvider.invoke(providerBlueprint, config, factory);
            g.jacksonBean = bean;
            g.jacksonProvider = provider;
            g.jacksonOutput = new StringWriter();
            Object jsonFactory = mapperType.getMethod("getFactory").invoke(mapper);
            for (String factoryMethod : new String[]{"createGenerator", "createJsonGenerator"}) {
                try {
                    Method createGenerator = jsonFactory.getClass().getMethod(factoryMethod, Writer.class);
                    g.jacksonGenerator = createGenerator.invoke(jsonFactory, g.jacksonOutput);
                    break;
                } catch (NoSuchMethodException ignored) { }
            }
            if (g.jacksonGenerator == null)
                throw new NoSuchMethodException("JsonFactory.createGenerator(Writer) or createJsonGenerator(Writer)");
            Class<?> providerType = load("com.fasterxml.jackson.databind.SerializerProvider");
            Class<?> beanPropertyType = load("com.fasterxml.jackson.databind.BeanProperty");
            Method find = providerType.getMethod("findValueSerializer", javaTypeType, beanPropertyType);
            Object serializer = find.invoke(provider, new Object[]{javaType, null});
            List<Object> writers = new ArrayList();
            try {
                // Available on Jackson 2.6 and newer.
                Class<?> serializerType = load("com.fasterxml.jackson.databind.JsonSerializer");
                Method properties = serializerType.getMethod("properties");
                Iterator<?> it = (Iterator<?>)properties.invoke(serializer);
                while (it.hasNext()) {
                    Object item = it.next();
                    if (item != null && item.getClass().getName().endsWith("BeanPropertyWriter"))
                        writers.add(item);
                }
            } catch (NoSuchMethodException oldJackson) {
                // JacksonDatabind-1 predates JsonSerializer.properties(). Its
                // BeanSerializerBase stores writers in the protected _props
                // array; read that array only for these old releases.
                Class<?> base = load("com.fasterxml.jackson.databind.ser.std.BeanSerializerBase");
                if (!base.isInstance(serializer))
                    throw new IllegalStateException("Expected BeanSerializerBase, got "
                        + serializer.getClass().getName(), oldJackson);
                Field props = base.getDeclaredField("_props");
                props.setAccessible(true);
                Object array = props.get(serializer);
                for (int i = 0; i < Array.getLength(array); i++) {
                    Object item = Array.get(array, i);
                    if (item != null && item.getClass().getName().endsWith("BeanPropertyWriter"))
                        writers.add(item);
                }
            }
            if (writers.isEmpty())
                throw new IllegalStateException("ObjectMapper produced no bean property writers for DEReplay.GenericInput");
            Object writer = writers.get(g.pick(writers.size()));
            boolean requireUnwrapping = requested.getName().equals(
                "com.fasterxml.jackson.databind.ser.impl.UnwrappingBeanPropertyWriter");
            if (!requireUnwrapping && g.pick(2) == 0 && requested.isInstance(writer)) return writer;
            Class<?> transformerType = load("com.fasterxml.jackson.databind.util.NameTransformer");
            Object nop = transformerType.getField("NOP").get(null);
            for (Method m : writer.getClass().getMethods())
                if (m.getName().equals("unwrappingWriter") && m.getParameterTypes().length == 1
                        && m.getParameterTypes()[0].isInstance(nop)) {
                    Object unwrapped = m.invoke(writer, nop);
                    if (requested.isInstance(unwrapped)) return unwrapped;
                }
            if (requested.isInstance(writer)) return writer;
            throw new IllegalStateException("Generated Jackson property writer is not " + requested.getName());
        } catch (Throwable failure) {
            throw new IllegalStateException("Cannot construct Jackson BeanPropertyWriter: " + failure, failure);
        }
    }
    /** Build the non-constructible Commons CLI result through its public Parser API. */
    private static Object commandLine(Genes g, Observation report) throws Exception {
        Class<?> optionsClass = load("org.apache.commons.cli.Options");
        Class<?> optionClass = load("org.apache.commons.cli.Option");
        Class<?> parserClass = load("org.apache.commons.cli.PosixParser");
        Object options = optionsClass.getConstructor().newInstance();
        Method addOption = optionsClass.getMethod("addOption", optionClass);
        int numberOfOptions = 1 + g.pick(3);
        List<String> spellings = new ArrayList();
        for (int i = 0; i < numberOfOptions; i++) {
            String shortName = String.valueOf((char)('a' + i));
            String longName = "de-option-" + i;
            boolean hasArgument = g.pick(2) == 0;
            Object option = null;
            try {
                option = optionClass.getConstructor(String.class, String.class, boolean.class, String.class)
                    .newInstance(shortName, longName, hasArgument, "DE-generated option");
            } catch (NoSuchMethodException ignored) { }
            if (option == null) try {
                option = optionClass.getConstructor(String.class, boolean.class, String.class)
                    .newInstance(shortName, hasArgument, "DE-generated option");
            } catch (NoSuchMethodException ignored) { }
            if (option == null) throw new NoSuchMethodException("No supported Commons CLI Option constructor");
            addOption.invoke(options, option);
            spellings.add("-" + shortName);
            if (hasArgument) spellings.add("value-" + Math.abs((long)g.next()));
        }
        String[] argv = spellings.toArray(new String[0]);
        Object parser = parserClass.getConstructor().newInstance();
        List<Method> parseMethods = new ArrayList();
        for (Method candidate : parserClass.getMethods()) {
            Class<?>[] p = candidate.getParameterTypes();
            if (candidate.getName().equals("parse") && p.length >= 2 && p[0] == optionsClass
                    && p[1] == String[].class && candidate.getReturnType() == load("org.apache.commons.cli.CommandLine"))
                parseMethods.add(candidate);
        }
        Collections.sort(parseMethods, new Comparator<Method>() {
            public int compare(Method a, Method b) {
                return a.getParameterTypes().length - b.getParameterTypes().length;
            }
        });
        for (Method parse : parseMethods) {
            Object[] args = new Object[parse.getParameterTypes().length];
            Class<?>[] p = parse.getParameterTypes();
            args[0] = options; args[1] = argv;
            for (int i = 2; i < p.length; i++) {
                if (p[i] == boolean.class || p[i] == Boolean.class) args[i] = g.pick(2) == 0;
                else if (p[i] == java.util.Properties.class) args[i] = new java.util.Properties();
                else args[i] = value(p[i], g, 1, report);
            }
            try { return parse.invoke(parser, args); }
            catch (InvocationTargetException ignored) { }
        }
        throw new NoSuchMethodException("No successful public PosixParser.parse(Options,String[])");
    }
    /** Optional type recipes, shared across bugs; none contains a bug-specific expected answer. */
    private static Object chart(Class<?> t, Genes g, Observation report) throws Exception {
        String n = t.getName();
        if (!n.startsWith("org.jfree.")) return null;
        if (n.equals("org.jfree.data.Range")) {
            double a = g.next(), b = g.next();
            return t.getConstructor(double.class, double.class).newInstance(Math.min(a, b), Math.max(a, b));
        }
        if (n.equals("org.jfree.data.time.RegularTimePeriod"))
            return load("org.jfree.data.time.Day").getConstructor(int.class, int.class, int.class)
                .newInstance(1 + g.pick(28), 1 + g.pick(12), 1990 + g.pick(40));
        if (n.equals("org.jfree.data.time.TimeSeries")) {
            Object series = t.getConstructor(Comparable.class).newInstance("DE");
            Class<?> period = load("org.jfree.data.time.RegularTimePeriod");
            Constructor<?> day = load("org.jfree.data.time.Day")
                .getConstructor(int.class, int.class, int.class);
            Method add = t.getMethod("add", period, double.class);
            int count = 2 + g.pick(4), year = 1990 + g.pick(40);
            for (int i = 0; i < count; i++)
                add.invoke(series, day.newInstance(i + 1, 1, year), g.next() / 10.0);
            return series;
        }
        if (n.equals("org.jfree.data.category.CategoryDataset")
                || n.equals("org.jfree.data.category.DefaultCategoryDataset")) {
            Class<?> c = load("org.jfree.data.category.DefaultCategoryDataset");
            Object data = c.getConstructor().newInstance();
            Method add = c.getMethod("addValue", Number.class, Comparable.class, Comparable.class);
            int rows = 1 + g.pick(3), columns = 1 + g.pick(3);
            for (int r = 0; r < rows; r++) for (int col = 0; col < columns; col++)
                add.invoke(data, Double.valueOf(g.next() / 10.0), "R" + r, "C" + col);
            return data;
        }
        if (n.equals("org.jfree.data.xy.XYDataset") || n.equals("org.jfree.data.xy.XYSeriesCollection")) {
            Class<?> seriesClass = load("org.jfree.data.xy.XYSeries");
            Object series = seriesClass.getConstructor(Comparable.class).newInstance("DE");
            int count = 1 + g.pick(5);
            for (int i = 0; i < count; i++) seriesClass.getMethod("add", double.class, double.class)
                .invoke(series, (double)i, g.next() / 10.0);
            Class<?> c = load("org.jfree.data.xy.XYSeriesCollection");
            Object data = c.getConstructor().newInstance();
            c.getMethod("addSeries", seriesClass).invoke(data, series);
            return data;
        }
        if (n.equals("org.jfree.data.general.PieDataset") || n.equals("org.jfree.data.general.DefaultPieDataset")) {
            Class<?> c = load("org.jfree.data.general.DefaultPieDataset");
            Object data = c.getConstructor().newInstance();
            int count = 1 + g.pick(5);
            for (int i = 0; i < count; i++) c.getMethod("setValue", Comparable.class, Number.class)
                .invoke(data, "K" + i, Double.valueOf(g.next() / 10.0));
            return data;
        }
        return null;
    }
    static List<Method> setupMethods(Class<?> receiver) {
        List<Method> methods = new ArrayList();
        for (Method m : receiver.getMethods()) {
            String n = m.getName();
            if (!Modifier.isStatic(m.getModifiers()) && !m.isSynthetic()
                    && m.getParameterTypes().length <= 3 && !n.contains("Listener")
                    && (n.startsWith("set") || n.startsWith("add") || n.startsWith("update")
                        || n.startsWith("remove") || n.equals("clear"))) methods.add(m);
        }
        Collections.sort(methods, new Comparator<Method>() {
            public int compare(Method a, Method b) {
                return signature(a).compareTo(signature(b));
            }
        });
        return methods;
    }
    public static Observation execute(String target, String receivers, String signature, int[] genes) {
        Observation out = new Observation();
        try {
            Genes g = new Genes(genes);
            Method m = method(target, signature);
            Object receiver = null;
            if (!Modifier.isStatic(m.getModifiers())) {
                String[] choices = receivers.split(",");
                Class<?> receiverType = load(choices[g.pick(choices.length)]);
                receiver = value(receiverType, g, 0, out);
                if (receiver == null) throw new IllegalArgumentException("Receiver construction failed");
                // Compiler.compile owns a strict initialization sequence.
                // Random calls to its mutators before compilation can corrupt
                // state or spend the search budget on irrelevant setup.
                if (!receiverType.getName().equals("com.google.javascript.jscomp.Compiler")) {
                    List<Method> setup = setupMethods(receiverType);
                    int count = g.pick(5);
                    for (int i = 0; i < count && !setup.isEmpty(); i++) {
                        Method s = setup.get(g.pick(setup.size()));
                        try { s.invoke(receiver, arguments(s.getParameterTypes(), g, 0, out)); out.setupCalls++; }
                        catch (Exception e) { out.setupFailures++; }
                    }
                }
            }
            Object[] args = arguments(m, g, 0, out);
            out.reachedTarget = true;
            try {
                boolean jacksonSerialization = m.getDeclaringClass().getName().equals(
                    "com.fasterxml.jackson.databind.ser.BeanPropertyWriter")
                    && m.getName().startsWith("serializeAs") && g.jacksonGenerator != null;
                boolean arrayShape = m.getName().contains("Column")
                    || m.getName().contains("Element") || m.getName().contains("Placeholder");
                if (jacksonSerialization)
                    g.jacksonGenerator.getClass().getMethod(arrayShape
                        ? "writeStartArray" : "writeStartObject").invoke(g.jacksonGenerator);
                Object result = m.invoke(receiver, args);
                boolean closureCompile = m.getDeclaringClass().getName().equals(
                    "com.google.javascript.jscomp.Compiler") && m.getName().equals("compile");
                if (closureCompile) {
                    // Result is only a status object; the compiled JavaScript is
                    // the behavioral output that reveals whether an argument
                    // was removed from a globally exposed function.
                    Object js = receiver.getClass().getMethod("toSource").invoke(receiver);
                    out.token = "CLOSURE_SOURCE:" + stable(js, 0);
                } else if (jacksonSerialization) {
                    g.jacksonGenerator.getClass().getMethod(arrayShape
                        ? "writeEndArray" : "writeEndObject").invoke(g.jacksonGenerator);
                    g.jacksonGenerator.getClass().getMethod("flush").invoke(g.jacksonGenerator);
                    out.token = "JSON:" + Base64.getEncoder().encodeToString(
                        g.jacksonOutput.toString().getBytes(StandardCharsets.UTF_8));
                } else out.token = m.getReturnType() == void.class
                    ? state(receiver, m.getName()) : stable(result, 0);
            } catch (InvocationTargetException e) {
                if (e.getCause() instanceof VirtualMachineError || e.getCause() instanceof LinkageError
                        || e.getCause() instanceof ThreadDeath) throw e;
                out.token = "THROW:" + e.getCause().getClass().getName();
            }
        } catch (Throwable e) {
            out.token = "HARNESS_ERROR";
            out.error = e.getClass().getName() + ":" + String.valueOf(e.getMessage());
        }
        return out;
    }
    public static String run(String target, String receivers, String signature, int[] genes) {
        Observation o = execute(target, receivers, signature, genes);
        if (!o.reachedTarget || o.token.equals("HARNESS_ERROR"))
            throw new AssertionError("Cannot replay test: " + o.error);
        return o.token;
    }
    private static String state(Object receiver, String method) {
        if (receiver == null) return "VOID";
        List<String> getters = new ArrayList();
        if (method.startsWith("set") && method.length() > 3) {
            getters.add("get" + method.substring(3)); getters.add("is" + method.substring(3));
        }
        getters.addAll(Arrays.asList("getItemCount", "getRowCount", "getColumnCount", "getSeriesCount"));
        StringBuilder s = new StringBuilder("VOID");
        for (String name : getters) {
            try {
                Method getter = receiver.getClass().getMethod(name);
                if (getter.getReturnType().isPrimitive() || getter.getReturnType() == String.class)
                    s.append('|').append(name).append('=').append(stable(getter.invoke(receiver), 0));
            } catch (ReflectiveOperationException ignored) { }
        }
        return s.toString();
    }
    /** Only whitelisted value types are rendered. Never use arbitrary object toString(). */
    static String stable(Object value, int depth) {
        if (value == null) return "NULL";
        Class<?> t = value.getClass();
        if (value instanceof String || value instanceof Boolean || value instanceof Character
                || value instanceof Byte || value instanceof Short || value instanceof Integer
                || value instanceof Long || value instanceof Float || value instanceof Double
                || value instanceof java.math.BigInteger || value instanceof java.math.BigDecimal)
            return t.getName() + ":" + Base64.getEncoder().encodeToString(value.toString().getBytes(StandardCharsets.UTF_8));
        if (value instanceof Enum) return "ENUM:" + t.getName() + ":" + ((Enum<?>)value).name();
        if (t.isArray() && depth < 3) {
            StringBuilder s = new StringBuilder("ARRAY:" + t.getName() + ":" + Array.getLength(value));
            for (int i = 0; i < Math.min(64, Array.getLength(value)); i++) {
                String item = stable(Array.get(value, i), depth + 1);
                s.append(':').append(item.length()).append(':').append(item);
            }
            return s.toString();
        }
        if (value instanceof java.awt.Color) return "COLOR:" + ((java.awt.Color)value).getRGB();
        // Observe safe scalar properties of returned objects. This catches
        // changes to value caches and state while avoiding identity-based toString().
        StringBuilder observed = new StringBuilder("STATE:" + t.getName());
        int properties = 0;
        for (String name : Arrays.asList("getItemCount", "getMinY", "getMaxY",
                "getRowCount", "getColumnCount", "getSeriesCount")) {
            try {
                Method getter = t.getMethod(name);
                Class<?> r = getter.getReturnType();
                if (!r.isPrimitive() && r != String.class && !Number.class.isAssignableFrom(r))
                    continue;
                if (r == void.class) continue;
                Object result = getter.invoke(value);
                String token = stable(result, depth + 1);
                observed.append('|').append(name).append('=').append(token.length())
                    .append(':').append(token);
                properties++;
            } catch (Exception ignored) { }
        }
        return properties == 0 ? "TYPE:" + t.getName() : observed.toString();
    }
    public static void main(String[] args) {
        if (args.length > 4) {
            String source = new String(Base64.getDecoder().decode(args[4]), StandardCharsets.UTF_8);
            System.setProperty("de.generated.source", source);
        }
        String[] encodedGenes = args[3].split(",");
        int[] genes = new int[encodedGenes.length];
        for (int i = 0; i < encodedGenes.length; i++) genes[i] = Integer.parseInt(encodedGenes[i]);
        boolean closureCompile = args[0].equals("com.google.javascript.jscomp.Compiler")
            && args[2].startsWith("compile(");
        // Compiler.compile is an expensive whole-program operation. Fixed-side
        // suites are still executed twice by the runner, so capture its oracle
        // once here instead of launching three compilations just to check the
        // same deterministic source output.
        int repetitions = closureCompile ? 1 : 3;
        for (int i = 0; i < repetitions; i++) {
            Observation out = execute(args[0], args[1], args[2], genes);
            System.out.println("DE_TOKEN:" + Base64.getEncoder().encodeToString(out.token.getBytes(StandardCharsets.UTF_8)));
        }
    }
}

public class DEGeneratedTest {
    @org.junit.Test(timeout=60000L)
    public void testDE00000() {
        org.junit.Assert.assertEquals("THROW:java.lang.NullPointerException", DEReplay.run(
            "com.google.javascript.jscomp.Compiler", "com.google.javascript.jscomp.Compiler", "addNewScript(com.google.javascript.jscomp.JsAst):void",
            new int[]{935,-678,-397,-335,585,431,619,53,992,704,460,604,-889,-740,330,455,-276,-610,-322,-948,-338,-446,369,799,-10,-812,-420,793,-278,-775,-87,-299,-207,-963,274,-163,-514,110,-572,198,-728,179,-181,-149,120,-239,263,393,-260,105,393,-550,908,-622,-613,148,79,620,407,345,-176,462,467,42}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00001() {
        org.junit.Assert.assertEquals("THROW:java.lang.NullPointerException", DEReplay.run(
            "com.google.javascript.jscomp.Compiler", "com.google.javascript.jscomp.Compiler", "replaceScript(com.google.javascript.jscomp.JsAst):void",
            new int[]{453,936,-763,930,-304,748,-857,156,132,738,248,-734,478,-357,629,-300,-744,774,495,281,537,616,814,-669,-358,-803,-477,487,581,344,78,-127,-578,657,-325,-581,-978,-10,860,494,559,-422,443,-260,208,520,-372,-983,925,-695,-883,-289,-191,280,560,304,785,-471,-820,-935,478,503,-341,-995}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00002() {
        org.junit.Assert.assertEquals("TYPE:java.util.LinkedList", DEReplay.run(
            "com.google.javascript.jscomp.JsMessageExtractor", "com.google.javascript.jscomp.JsMessageExtractor", "extractMessages(com.google.javascript.jscomp.SourceFile[]):java.util.Collection",
            new int[]{-1000,-1000,215,1000,-707,692,1000,-892,-1000,31,-182,576,16,-1000,228,507,-428,-1000,726,-1000,-83,604,-1000,-616,630,892,979,-496,648,-832,599,179,1000,-673,-874,-1000,-575,784,307,1000,1000,-350,-711,-166,85,-1000,-1000,1000,-313,-946,-532,-1000,-612,-981,-425,-794,-651,909,-1000,-100,1000,-762,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00003() {
        org.junit.Assert.assertEquals("THROW:java.lang.RuntimeException", DEReplay.run(
            "com.google.javascript.jscomp.JsMessageExtractor", "com.google.javascript.jscomp.JsMessageExtractor", "extractMessages(com.google.javascript.jscomp.SourceFile[]):java.util.Collection",
            new int[]{27,407,-381,-50,442,-310,-588,-617,866,-299,507,919,-253,-351,-189,516,157,376,-242,-907,937,-773,-120,481,233,233,-580,-267,141,-131,126,-691,284,-942,213,-921,-742,-942,-568,122,116,399,-862,-169,-686,139,326,988,-135,-626,695,131,858,131,989,824,943,585,-914,-767,893,-126,-375,772}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00004() {
        org.junit.Assert.assertEquals("THROW:java.lang.RuntimeException", DEReplay.run(
            "com.google.javascript.jscomp.JsMessageExtractor", "com.google.javascript.jscomp.JsMessageExtractor", "extractMessages(com.google.javascript.jscomp.SourceFile[]):java.util.Collection",
            new int[]{-834,-413,72,956,-626,551,482,-377,79,-548,142,110,243,-680,-322,813,451,-878,834,-163,250,195,-980,647,290,-334,644,-806,-100,-735,755,687,802,-625,-568,-374,-155,93,-789,-277,-202,-361,891,866,-448,-459,-922,467,-618,-336,-73,157,-679,402,-254,99,-831,105,347,-22,-855,-822,-688,98}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00005() {
        org.junit.Assert.assertEquals("THROW:java.lang.RuntimeException", DEReplay.run(
            "com.google.javascript.jscomp.JsMessageExtractor", "com.google.javascript.jscomp.JsMessageExtractor", "extractMessages(com.google.javascript.jscomp.SourceFile[]):java.util.Collection",
            new int[]{-60,-171,-597,-775,1000,654,-285,-663,995,11,159,30,-628,834,-137,671,-187,23,-567,1000,1000,270,982,1000,263,-162,653,845,-1000,305,1000,1000,-684,244,-575,-213,355,-869,-595,-830,-475,237,310,1000,-1000,885,550,-802,-432,527,676,-364,-1000,537,-1000,1000,-1000,-793,-180,257,70,114,-642,-826}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00006() {
        org.junit.Assert.assertEquals("THROW:java.lang.RuntimeException", DEReplay.run(
            "com.google.javascript.jscomp.JsMessageExtractor", "com.google.javascript.jscomp.JsMessageExtractor", "extractMessages(com.google.javascript.jscomp.SourceFile[]):java.util.Collection",
            new int[]{-295,1000,-1000,-285,809,-1000,-452,63,-388,978,-800,-970,139,-1000,1000,-156,-1000,-1000,-460,-355,-986,636,-77,-435,568,135,-80,158,1000,430,-757,215,1000,-460,-231,996,-518,273,794,-1000,-93,7,481,-781,-1000,-447,-505,-485,483,323,147,-1000,-1000,-225,-481,-254,527,-4,1000,-264,-1000,-1000,-279,-87}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00007() {
        org.junit.Assert.assertEquals("TYPE:java.util.LinkedList", DEReplay.run(
            "com.google.javascript.jscomp.JsMessageExtractor", "com.google.javascript.jscomp.JsMessageExtractor", "extractMessages(java.lang.Iterable):java.util.Collection",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00008() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildAfter(com.google.javascript.rhino.Node,com.google.javascript.rhino.Node):void",
            new int[]{513,-876,-662,-98,419,-997,255,311,402,-27,88,368,-1000,390,-346,-431,-441,556,55,372,138,699,69,226,-626,813,951,-198,1000,-48,-464,734,814,-402,-206,483,950,-268,1000,-948,-15,-30,438,614,31,85,530,891,24,-511,-570,314,-579,-358,147,-1000,255,1000,1000,41,359,442,525,-980}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00009() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildAfter(com.google.javascript.rhino.Node,com.google.javascript.rhino.Node):void",
            new int[]{-651,-396,331,392,79,915,547,-804,1000,-1000,1000,757,-493,1000,-1000,806,633,-462,-1000,-1000,-352,332,134,477,-137,322,113,599,-522,653,-1000,880,1000,-1000,1000,-1000,966,-1000,808,-1000,-221,1000,-714,-765,0,720,1000,-1000,453,-912,1000,-1000,-1000,-1000,-1000,873,92,-554,1000,-1000,-659,1000,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00010() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildAfter(com.google.javascript.rhino.Node,com.google.javascript.rhino.Node):void",
            new int[]{1000,-551,939,184,82,-1000,671,492,-850,1000,838,337,-986,-197,-253,1000,-761,980,-1000,586,1000,1000,-534,1000,-764,1000,299,-1000,1000,-1000,834,-583,-461,904,332,740,-240,819,-147,741,-1000,1000,-1000,633,-1000,458,-954,515,1000,375,-590,1000,-120,277,994,-1000,-433,-774,-439,-200,-1000,-663,-292,-631}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00011() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildAfter(com.google.javascript.rhino.Node,com.google.javascript.rhino.Node):void",
            new int[]{-1000,-547,816,811,848,-543,-6,1000,-460,1000,-902,1000,-812,-68,1000,428,-291,-175,487,829,-447,222,442,123,-1000,-345,-974,-279,-991,-785,-302,-497,-1000,-323,-516,1000,850,-1000,-393,-86,-728,155,771,-790,373,450,587,-461,-1000,160,438,118,-281,1000,233,363,-214,-1000,-175,-213,917,-1000,-371,-636}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00012() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildAfter(com.google.javascript.rhino.Node,com.google.javascript.rhino.Node):void",
            new int[]{-957,599,983,-55,-287,-556,-204,-175,750,156,238,256,-1000,582,1000,-475,-554,-1000,-445,144,578,-225,-69,364,-840,671,-966,-688,840,97,-745,-374,-210,135,723,666,193,-273,-1000,-1000,-260,705,178,-890,-713,836,-579,-990,251,-610,-1000,-119,-706,-112,113,-79,-288,-1000,-638,-188,-1000,-148,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00013() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildAfter(com.google.javascript.rhino.Node,com.google.javascript.rhino.Node):void",
            new int[]{1000,499,1000,632,413,-61,1000,1000,-1000,920,227,-64,-812,-581,912,1000,-1000,1000,-167,889,-126,431,-119,49,566,334,-403,-1000,97,-817,567,1000,-1000,928,-360,740,-635,1000,-1000,-1000,-1000,-399,-74,518,234,1000,-58,658,-1000,-344,-594,217,-554,955,1000,-1000,275,716,-913,193,-331,-798,-1000,-645}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00014() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildAfter(com.google.javascript.rhino.Node,com.google.javascript.rhino.Node):void",
            new int[]{-1000,-876,-673,-854,750,-739,-912,184,293,-1000,629,-405,490,1000,-109,220,1000,-168,405,-756,1000,-332,713,-790,-957,-148,-514,1000,1000,-48,-1000,1000,412,-1000,1000,-390,950,354,-305,-286,695,1000,1000,614,-1000,-347,633,-1000,-361,771,-769,-99,-579,-275,-77,1000,-644,-1000,265,882,359,101,-132,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00015() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildAfter(com.google.javascript.rhino.Node,com.google.javascript.rhino.Node):void",
            new int[]{268,-456,1000,468,451,-4,489,840,-582,802,1000,1000,-821,997,-1000,1000,-1000,475,-1000,-1000,1000,175,-242,492,-368,482,113,-820,798,-1000,-1000,-811,-941,1000,335,532,-388,1000,-1000,1000,-1000,1000,-1000,-130,-1000,-13,-676,-324,1000,484,-1000,767,-428,506,1000,873,-934,-1000,-1000,-1000,-949,-1000,-1000,386}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00016() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildAfter(com.google.javascript.rhino.Node,com.google.javascript.rhino.Node):void",
            new int[]{220,599,-1000,-55,764,403,-589,-441,488,-77,-949,-126,-1000,-709,899,-1000,346,-30,1000,372,-825,-186,-69,-933,747,-428,672,666,-400,97,-745,1000,606,-1000,-271,60,133,-494,990,-1000,208,-1000,823,614,670,-304,932,487,-321,-472,366,-119,-725,-136,55,-79,1000,1000,1000,720,1000,855,567,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00017() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildAfter(com.google.javascript.rhino.Node,com.google.javascript.rhino.Node):void",
            new int[]{-93,54,983,17,-174,1000,-204,-590,718,170,371,-602,355,-1000,1000,-1000,259,-533,1000,-1000,-888,-1000,-69,364,198,-1000,-903,-158,-1000,660,-1000,-295,-151,-1000,929,-111,-1000,741,94,-409,231,-316,-1000,-890,-1000,112,-1000,-720,474,921,1000,-1000,314,333,12,881,540,-292,-638,909,1000,-148,74,843}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00018() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildAfter(com.google.javascript.rhino.Node,com.google.javascript.rhino.Node):void",
            new int[]{-280,-411,886,-83,-310,-1000,-151,232,229,856,1000,619,-1000,573,-464,-170,404,-181,-1000,-483,839,-68,-1000,358,-1000,-23,-555,-161,532,-616,-335,-15,490,293,-54,1000,-686,425,-243,-987,-748,0,-1000,203,-1000,149,-1000,-497,1000,0,-65,665,-1000,-485,1000,-648,-255,-44,197,-519,-318,-1000,-367,974}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00019() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildAfter(com.google.javascript.rhino.Node,com.google.javascript.rhino.Node):void",
            new int[]{582,729,-106,-171,-135,1000,-870,429,-1000,1000,-1000,-613,-371,-1000,1000,-1000,-86,-1000,1000,1000,-1000,-830,-1000,398,1000,-1000,61,-287,-1000,1000,380,255,-1000,690,-1000,924,22,1000,-212,-102,-681,-1000,-1000,1000,78,250,-1000,1000,1000,1000,148,432,860,1000,869,-461,651,102,-1000,1000,1000,-784,-477,-243}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00020() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildAfter(com.google.javascript.rhino.Node,com.google.javascript.rhino.Node):void",
            new int[]{-615,53,983,36,-73,-556,446,-7,750,156,238,602,-1000,-29,634,-431,-906,-986,-981,786,465,-158,104,379,-840,671,-235,-688,840,789,-427,-405,-272,135,399,666,298,-273,1000,-819,-260,-324,178,-692,-713,903,-622,-583,251,-850,-1000,-340,-800,-138,113,-79,-439,-986,-591,-488,-1000,-148,359,594}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00021() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildAfter(com.google.javascript.rhino.Node,com.google.javascript.rhino.Node):void",
            new int[]{620,434,924,655,648,-39,382,-362,-895,873,-432,152,-152,338,1000,-133,-390,-16,157,766,-124,-127,-284,244,130,-427,-23,-1000,304,-375,415,-1000,8,443,-322,1000,-209,1000,-292,1000,-1000,-398,-1000,1000,1000,549,-1000,207,522,-201,280,98,1000,650,817,-1000,-85,75,-912,661,396,-97,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00022() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildAfter(com.google.javascript.rhino.Node,com.google.javascript.rhino.Node):void",
            new int[]{623,53,597,811,72,382,657,210,-460,-825,-553,685,-660,-68,377,-162,-448,198,487,829,-58,574,-922,563,89,-381,619,-600,-991,-527,-302,-437,-468,-212,977,-424,-526,-400,-5,491,-728,158,-533,500,130,393,285,-461,-10,716,809,968,652,127,233,-932,249,262,-175,-856,917,-105,-327,-636}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00023() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildAfter(com.google.javascript.rhino.Node,com.google.javascript.rhino.Node):void",
            new int[]{-1000,298,-1000,-1000,709,795,671,-145,1000,-785,679,167,-284,566,-729,-359,215,-830,-97,586,1000,-745,-1000,1000,-19,-518,-479,-1000,449,423,-1000,1000,475,-954,332,-1000,-51,-168,-513,-1000,-1000,1000,-669,-1000,-1000,-1000,-954,-1000,32,-207,38,281,-1000,-356,130,1000,-154,-535,701,-168,662,-163,-542,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00024() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildBefore(com.google.javascript.rhino.Node,com.google.javascript.rhino.Node):void",
            new int[]{-617,-96,120,-649,525,-367,-383,-264,390,-26,-255,36,-320,988,125,108,120,-199,-265,424,-130,-564,1000,246,456,-984,-42,-667,-181,-148,-1000,40,-873,-100,-258,-170,298,-123,338,355,1000,-200,324,-46,-22,-117,-373,-1000,295,330,1000,437,224,-1000,-281,-223,261,293,282,-243,-468,-159,200,-3}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00025() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildBefore(com.google.javascript.rhino.Node,com.google.javascript.rhino.Node):void",
            new int[]{-1000,-366,473,802,-188,228,1000,950,1000,1000,314,-678,-863,546,1000,-458,15,625,-750,-610,-882,766,1000,496,241,-734,-739,-894,587,-664,1000,5,-888,-787,-795,-453,556,1000,-276,-235,-1000,-290,1000,-479,-724,1000,-1000,1000,159,-1000,-821,637,305,419,-431,530,456,423,538,860,-796,-1000,-665,-236}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00026() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildBefore(com.google.javascript.rhino.Node,com.google.javascript.rhino.Node):void",
            new int[]{-890,-751,558,-279,-978,-637,169,-697,-409,452,341,-620,-815,-558,-878,600,-601,-453,936,-84,462,810,370,577,-888,536,-523,-322,-702,-265,547,-663,530,467,-439,359,-778,346,-193,-342,943,331,529,612,137,457,-120,-940,581,-867,952,689,611,-719,201,195,-9,713,-815,807,163,878,-763,482}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00027() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildBefore(com.google.javascript.rhino.Node,com.google.javascript.rhino.Node):void",
            new int[]{-172,-317,808,-210,636,373,400,604,-993,-130,-513,-1000,-267,-1000,-1000,-273,1000,159,735,-609,-706,-314,-1000,1000,1000,-823,-279,999,-1000,-583,1000,393,-1000,442,-1000,-1000,136,-217,845,-480,-1000,302,1000,-1000,-1000,1000,-780,0,36,-1000,-1000,822,1000,575,-221,169,1000,-1000,-347,990,-1000,-1000,-422,-735}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00028() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildBefore(com.google.javascript.rhino.Node,com.google.javascript.rhino.Node):void",
            new int[]{-436,54,333,-196,-538,-1000,-1000,-203,-1000,-129,1000,379,-693,-704,-1000,617,413,569,1000,-301,874,939,-963,-231,-1000,668,-236,824,-695,-641,1000,-589,1000,1000,114,-1000,-1000,8,-205,-163,894,1000,-142,-956,1000,413,-556,-1000,929,-509,2,-739,706,-1000,411,-425,75,1000,-1000,676,-23,999,-1000,365}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00029() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildBefore(com.google.javascript.rhino.Node,com.google.javascript.rhino.Node):void",
            new int[]{-925,-721,524,-936,465,-1000,-1000,-1,-815,235,-112,6,602,-911,-1000,-493,983,-649,-1000,-301,-558,-583,-861,1000,850,98,-236,280,-1000,140,1000,-354,-662,40,-893,-716,304,8,1000,-486,-959,269,690,-720,-241,439,-208,169,-720,-509,-876,-1000,500,-433,-663,522,560,-1000,-729,-276,-1000,999,-956,-234}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00030() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildBefore(com.google.javascript.rhino.Node,com.google.javascript.rhino.Node):void",
            new int[]{-348,278,-7,491,168,-1000,459,136,-158,-82,952,591,437,-1000,-122,910,976,147,-238,723,-488,538,-464,-653,-291,1000,-386,406,369,-615,-316,-1000,250,934,109,-800,-478,-394,300,-837,57,634,384,-315,980,1000,-982,149,-450,-43,488,-581,350,1000,-1000,-69,500,-447,-701,-523,-674,343,-442,881}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00031() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildBefore(com.google.javascript.rhino.Node,com.google.javascript.rhino.Node):void",
            new int[]{-50,614,119,-654,-591,-662,303,-186,498,-632,197,119,330,988,802,852,-364,-1000,323,208,-86,-665,909,-730,-89,98,-1,-1000,-24,-157,-808,-940,-34,-284,120,-35,504,-865,470,925,850,-474,-214,-127,-45,-326,-1,67,-9,142,1000,-1000,469,-464,-1000,225,488,666,-114,-274,174,480,-92,643}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00032() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildBefore(com.google.javascript.rhino.Node,com.google.javascript.rhino.Node):void",
            new int[]{-711,399,507,-516,-695,228,-580,-206,381,-675,-1000,-851,78,-818,-398,-429,-606,-423,-509,-615,-79,-681,536,1000,677,1000,381,-514,-885,-538,1000,608,-622,-940,-1000,-420,-672,318,921,1000,-799,-436,402,-323,-432,-144,97,540,452,-1000,-345,-203,748,984,892,627,971,-758,211,-109,-1000,-1000,398,-79}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00033() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildBefore(com.google.javascript.rhino.Node,com.google.javascript.rhino.Node):void",
            new int[]{-592,-552,604,702,810,-579,-101,-384,-954,-11,449,-1000,-510,-704,-710,-150,205,-19,226,-196,99,947,-1000,433,-767,939,256,407,-627,-320,1000,-699,964,502,-333,-943,-503,99,-54,-360,416,785,-23,-1000,-382,413,-166,-505,1000,-1000,-610,-414,1000,-802,-882,157,223,512,-1000,1000,-33,877,1000,783}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00034() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildBefore(com.google.javascript.rhino.Node,com.google.javascript.rhino.Node):void",
            new int[]{-578,-532,-414,-430,-299,530,-58,-340,-43,-878,-753,690,-159,322,-643,-534,-686,-68,-997,-454,916,-761,-521,393,168,-744,-68,320,-199,344,532,91,-54,-58,-974,875,925,456,485,619,-109,-726,-577,831,-827,-664,-134,-703,925,-268,465,-708,-598,-601,275,484,-931,-882,443,924,-421,-219,-279,-752}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00035() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildBefore(com.google.javascript.rhino.Node,com.google.javascript.rhino.Node):void",
            new int[]{-1000,-96,1000,118,525,418,1000,-264,1000,13,-255,-1000,-144,-1000,1000,1000,120,-1000,-265,-802,-1000,-288,1000,1000,258,-984,-1000,-1000,-77,-492,1000,-190,-576,-1000,-258,-21,1000,699,-306,380,-1000,-200,1000,-836,-256,1000,118,-1000,792,-615,-335,1000,1000,975,554,901,1000,525,-265,259,-288,-1000,875,854}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00036() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildBefore(com.google.javascript.rhino.Node,com.google.javascript.rhino.Node):void",
            new int[]{-1000,54,975,179,-538,894,-1000,679,571,1000,-1000,-1000,91,-431,1000,-697,-898,569,-1000,-216,-1000,-946,-963,-231,-1000,668,-414,-1000,-267,-245,726,-589,-1000,-1000,-1000,-385,1000,984,-205,61,-1000,-362,1000,-885,-1000,774,398,1000,-515,-717,-545,465,500,-166,-735,1000,507,-527,568,406,-895,-1000,815,365}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00037() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildBefore(com.google.javascript.rhino.Node,com.google.javascript.rhino.Node):void",
            new int[]{-690,-1,-304,246,602,-1000,-521,657,-23,486,197,80,175,-1000,-949,-170,626,305,-264,169,-340,-745,-88,323,700,-176,-421,466,17,-605,-316,-250,-818,1000,-557,-586,94,167,535,-430,114,149,478,204,20,909,-1000,-31,74,104,466,-514,-67,727,240,-48,280,-796,336,-466,-715,-467,9,-398}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00038() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildBefore(com.google.javascript.rhino.Node,com.google.javascript.rhino.Node):void",
            new int[]{-832,919,729,450,551,-1000,-400,681,86,-1000,-66,400,-774,-1000,-426,655,16,611,1000,-747,340,-256,292,336,-432,-501,-42,319,-655,-1000,558,-203,-79,-515,-38,-1000,-515,331,147,79,-100,936,881,-619,1000,1000,39,-588,1000,166,176,129,666,777,1000,-824,786,1000,-483,-50,-1000,-707,415,547}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00039() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildBefore(com.google.javascript.rhino.Node,com.google.javascript.rhino.Node):void",
            new int[]{-1000,-142,591,267,-521,671,1000,587,1000,859,77,-1000,-387,635,1000,-676,61,-1000,-1000,-519,-1000,-590,1000,1000,573,-734,-652,-1000,-29,-438,609,151,-926,-1000,-1000,-372,1000,802,198,314,-1000,-533,1000,-836,-975,813,-1000,1000,-110,-606,-821,337,650,234,-277,1000,682,-46,500,787,-790,-1000,1000,-462}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00040() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildToBack(com.google.javascript.rhino.Node):void",
            new int[]{1000,659,151,-1000,-1000,-561,968,-649,551,-1000,169,-156,162,965,660,-526,352,1000,1000,806,-1000,418,1000,-1000,-1000,72,347,260,-831,683,1000,-871,-364,1000,1000,-1000,-815,-859,1000,733,-523,199,-1000,693,71,112,-957,1000,72,-309,-843,210,978,1000,-293,1000,-1000,663,-1000,-378,442,3,1000,12}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00041() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildToBack(com.google.javascript.rhino.Node):void",
            new int[]{1000,-126,378,-1000,-1000,-659,1000,-835,1000,-1000,1000,-1000,428,582,-315,-1000,-82,1000,852,1000,-1000,382,474,987,-1000,-496,-41,-123,431,262,903,-136,-141,1000,1000,-1000,923,1000,748,-350,83,-119,-744,484,-253,-133,-1000,1000,-312,167,-980,811,857,1000,993,87,-65,751,-451,73,865,-1000,-434,899}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00042() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildToBack(com.google.javascript.rhino.Node):void",
            new int[]{1000,-771,-220,316,696,1000,1000,-757,1000,-312,392,774,-152,-358,-729,-957,944,1000,1000,378,-1000,-1000,794,-1000,396,-567,-701,-211,-568,-467,-594,1000,376,141,-408,-308,335,-1000,1000,289,-766,225,388,-511,330,-437,383,365,1000,173,-736,-179,841,1000,-313,397,-792,1000,-648,-1000,-773,-935,929,357}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00043() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildToBack(com.google.javascript.rhino.Node):void",
            new int[]{176,594,529,-666,-994,-142,804,104,407,-312,-41,-622,-55,-1000,-196,-661,-122,256,826,429,-603,642,852,906,-1000,-641,714,110,-301,-9,1000,-600,-592,785,254,36,378,182,737,-498,-769,46,120,693,-871,-85,-475,-242,587,-696,1000,969,550,-769,-619,422,-1000,-574,628,-56,306,576,688,-361}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00044() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildToBack(com.google.javascript.rhino.Node):void",
            new int[]{95,284,380,434,-382,214,133,-511,45,-223,-96,468,39,161,1000,15,1000,1000,209,285,-931,-692,-64,-147,292,-851,-234,192,-522,-4,680,-149,942,970,-144,992,-146,-541,403,400,-418,306,-1000,334,234,-87,169,211,-51,150,25,-179,-500,-202,497,285,258,-463,-361,-352,65,-11,1000,-213}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00045() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildToBack(com.google.javascript.rhino.Node):void",
            new int[]{300,-97,-718,-1000,-1000,-287,998,-448,500,-590,657,-15,-161,697,-772,762,-85,-231,906,137,-939,417,-81,254,-300,-957,1000,532,570,142,12,-911,266,1000,232,-242,-511,306,67,181,912,342,-37,1000,-380,1000,-1000,781,-358,457,-371,473,972,499,-1000,-781,-554,857,-552,822,-49,230,-527,672}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00046() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildToBack(com.google.javascript.rhino.Node):void",
            new int[]{840,724,331,434,801,-344,133,641,-545,-312,-562,750,717,563,951,-1000,-122,753,-1000,-52,396,-253,360,1000,920,1000,-479,-298,-472,-13,892,-166,389,635,169,946,603,174,174,-1000,-216,-738,-681,-123,-567,-437,753,-365,43,-696,1000,-179,-769,1000,497,627,1000,-463,885,159,1000,-569,820,-213}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00047() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildToBack(com.google.javascript.rhino.Node):void",
            new int[]{16,-386,-546,-1000,1000,-645,972,922,1000,-229,313,152,-472,3,-592,-545,-574,-1000,642,-673,1000,72,172,482,251,-1000,932,297,-200,812,-28,-1000,-230,293,-994,-402,-7,108,849,0,88,-311,191,1000,-465,887,-365,93,637,429,1000,1000,1000,24,289,167,-469,868,-160,-251,-1000,-1000,-823,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00048() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildToBack(com.google.javascript.rhino.Node):void",
            new int[]{-399,804,-98,-496,-53,-797,617,-251,201,52,-573,-910,71,-445,246,297,-292,158,378,-673,1000,651,182,556,54,-1000,520,726,-93,135,719,-1000,-379,322,295,897,-531,1,849,-311,-24,-20,-565,1000,-664,-7,-108,-794,-538,939,-131,739,796,-220,-396,-57,-570,673,-402,677,273,397,814,-169}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00049() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildToBack(com.google.javascript.rhino.Node):void",
            new int[]{127,-46,-57,-1000,-837,-404,1000,-930,1000,-937,387,-379,-208,-166,951,-67,881,1000,1000,560,-1000,277,624,-325,-1000,-970,794,620,789,640,555,-759,280,678,876,-1000,-575,-770,605,733,-172,402,-907,1000,57,458,-1000,681,-152,835,-1000,611,1000,894,252,449,-922,931,-1000,-117,-535,-75,959,469}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00050() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildToBack(com.google.javascript.rhino.Node):void",
            new int[]{1000,94,-50,-308,-144,420,289,-630,-927,-804,190,138,204,751,-626,-890,-320,159,855,613,-771,-466,490,-1000,162,588,-208,-202,-1000,650,318,301,-475,869,364,-423,593,-594,1000,476,-183,157,68,-76,-200,430,-335,154,545,-1000,-603,-24,618,660,-1000,379,813,513,-416,-449,343,-418,75,80}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00051() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildToBack(com.google.javascript.rhino.Node):void",
            new int[]{176,-771,-1000,-312,-202,26,518,-159,18,7,872,1000,347,-82,238,449,402,231,-872,378,1000,360,-619,-193,1000,971,754,-424,-1000,-898,387,1000,674,687,-961,337,1000,962,-197,579,814,225,1000,-606,-281,-114,-613,365,-416,498,-980,703,-559,1000,-833,-1000,85,1000,777,1000,-354,-1000,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00052() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildToBack(com.google.javascript.rhino.Node):void",
            new int[]{1000,824,-119,734,623,-404,283,-936,-1000,-1000,-534,-379,811,882,-1000,-1000,-1000,-239,63,408,-1000,277,986,1000,1000,504,-642,-323,-228,480,555,1000,-760,350,1000,-56,512,-53,223,-1000,-56,-638,864,-546,-1000,-325,449,286,-16,-1000,-511,-274,-96,419,-1000,-524,1000,801,640,-117,933,-1000,959,695}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00053() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildToBack(com.google.javascript.rhino.Node):void",
            new int[]{243,-361,-1000,84,314,496,311,-681,-659,134,293,813,312,-138,-1000,1000,-1000,-672,-587,-335,538,513,-297,1000,518,411,568,-68,-317,-1000,42,909,-146,822,-383,-97,1000,1000,-1000,-631,1000,-202,843,-460,-913,-102,1000,-484,-547,290,-731,1000,-206,431,-1000,-1000,905,196,874,1000,-1000,-745,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00054() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildToBack(com.google.javascript.rhino.Node):void",
            new int[]{1000,9,-864,-907,-657,-856,422,887,-441,-587,-76,676,-56,1000,-803,-737,-1000,-616,-94,806,1000,436,1000,1000,-128,489,696,182,-831,631,683,-709,-730,1000,782,-1000,-129,936,1000,-1000,-523,-344,-10,750,-787,258,-124,828,53,-1000,762,1000,679,299,-730,342,608,462,382,318,180,-295,-185,642}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00055() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildToBack(com.google.javascript.rhino.Node):void",
            new int[]{96,608,324,-886,-1000,-823,802,-405,928,-229,-688,-877,-493,3,1000,-545,374,1000,1000,-422,217,222,1000,558,-1000,-1000,399,1000,1000,997,818,-1000,-348,993,986,-20,-1000,-17,536,-63,-512,-311,-1000,1000,-163,754,-177,468,287,391,-357,662,1000,329,-492,167,-928,165,-1000,-164,145,1000,460,60}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00056() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildToFront(com.google.javascript.rhino.Node):void",
            new int[]{734,-92,-685,930,217,-10,887,-742,1000,996,-1000,1000,-220,190,-272,-1000,-651,-1000,-871,612,237,-833,306,1000,-187,873,-1000,-875,886,938,-399,444,-604,915,986,-868,-645,637,318,994,-895,655,820,-1000,795,802,332,-508,-1000,207,1000,1000,-263,623,1000,739,-897,-1000,-1000,142,424,279,558,652}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00057() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildToFront(com.google.javascript.rhino.Node):void",
            new int[]{516,-821,-169,-807,687,-730,-1000,-363,745,0,-311,-311,1000,493,-767,1000,0,1000,317,-192,824,429,-1000,-490,843,-374,-533,1000,896,1000,480,618,929,-1000,-1000,-263,291,-1000,-986,49,-717,444,1000,1000,661,-37,1000,-1000,-216,1000,-902,639,189,428,1000,1000,512,-1000,-54,249,-422,1000,1000,499}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00058() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildToFront(com.google.javascript.rhino.Node):void",
            new int[]{0,-821,0,-807,130,-861,697,-94,-669,0,616,221,-693,-625,249,-740,0,97,317,375,-1000,-38,-1000,0,1000,1000,-533,-604,331,-1000,-307,1000,929,1000,53,-249,936,1000,-536,-514,-717,-250,1000,472,91,316,0,-1000,-216,186,-902,136,-973,-183,581,-740,958,344,0,249,-1000,519,1000,-875}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00059() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildToFront(com.google.javascript.rhino.Node):void",
            new int[]{240,-311,321,436,-626,1000,-199,-42,230,1000,-180,221,-693,625,1000,-1000,-1000,-275,-398,-999,-801,-38,-716,-624,-1000,-581,-873,87,709,1000,-858,-612,929,498,1000,262,-169,-6,556,-514,-717,145,799,-1000,-821,-794,-116,868,-484,-599,165,-400,243,959,145,-551,-1000,-583,-615,-260,33,955,523,-875}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00060() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildToFront(com.google.javascript.rhino.Node):void",
            new int[]{1000,-371,-1000,216,1000,317,1000,-188,444,-290,-131,590,-416,-430,-1000,818,266,-741,169,819,-134,-499,30,1000,169,114,-657,-643,380,663,228,611,-255,610,1000,-1000,-804,1000,-402,56,875,602,659,-30,60,610,544,-655,-251,608,1000,1000,272,318,330,35,-298,-270,-60,622,-3,608,691,69}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00061() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildToFront(com.google.javascript.rhino.Node):void",
            new int[]{-1000,-77,775,-775,-44,572,-87,1000,-378,-1000,1000,340,-1000,-1000,1000,-554,-83,597,55,566,-1000,1000,-1000,-724,847,-145,190,44,-110,-421,425,-942,637,-451,-1000,-427,1000,531,-1000,-385,-172,-469,599,714,88,-1000,-959,417,-47,-852,-528,-803,-934,-952,-683,-1000,250,1000,-236,-269,-774,944,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00062() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildToFront(com.google.javascript.rhino.Node):void",
            new int[]{141,-671,52,-974,-272,-86,519,272,-405,-433,731,1000,-879,-126,892,1000,559,627,-1000,263,-1000,1000,415,383,554,294,751,-723,-53,97,120,-1000,434,1000,547,-1000,226,272,-237,-796,-1000,-1000,1000,465,-185,-563,-479,-264,531,-1000,-255,-655,-244,-1000,4,-415,600,1000,-1000,-351,904,84,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00063() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildToFront(com.google.javascript.rhino.Node):void",
            new int[]{1000,-671,-169,673,-42,-287,316,-1000,807,1000,-1000,770,1000,978,576,-1000,-464,-319,-958,503,1000,-519,869,-167,-280,1000,-170,808,656,1000,459,876,-873,-925,904,-842,-512,1000,411,1000,-1000,322,820,860,1000,548,-182,-1000,-1000,-1000,-400,24,384,-148,1000,1000,-765,-737,-1000,-238,689,-867,-116,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00064() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildToFront(com.google.javascript.rhino.Node):void",
            new int[]{186,-981,666,-1000,-302,-1000,-109,-275,-1000,-184,1000,-284,899,-249,621,646,399,1000,226,828,-1000,379,-514,-667,555,659,806,84,-260,-1000,494,822,1000,-1000,-279,-341,1000,-146,-868,-1000,-790,-1000,1000,1000,-297,-377,-119,-1000,-136,-551,-1000,-1000,-1000,-1000,143,-557,1000,1000,0,-256,-1000,205,351,462}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00065() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildToFront(com.google.javascript.rhino.Node):void",
            new int[]{-424,-811,478,-1000,-585,336,-570,1000,-720,-684,1000,746,-382,-450,1000,1000,1000,1000,-874,-756,-1000,1000,220,-744,224,-337,1000,501,-404,-72,137,-1000,912,1000,-781,-1000,837,-1000,-1000,-1000,-911,-1000,729,1000,-422,-1000,-384,129,1000,-916,-255,-1000,-392,-1000,-1000,-848,859,1000,-1000,-896,671,662,291,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00066() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildToFront(com.google.javascript.rhino.Node):void",
            new int[]{-134,-626,503,-820,512,-78,-266,51,-318,203,157,340,-1000,-242,375,934,285,493,119,133,-694,184,-1000,300,264,-48,-75,-1000,404,-737,-339,121,637,-438,-381,-427,551,-63,-603,-60,77,125,135,-302,147,-235,-175,-453,111,65,993,-276,-825,-76,618,-412,414,27,359,-157,-644,632,853,-298}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00067() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildToFront(com.google.javascript.rhino.Node):void",
            new int[]{-443,-206,104,-226,-52,1000,-7,910,616,-781,554,1000,-747,53,1000,1000,384,439,-1000,400,-786,1000,919,366,-27,-507,1000,238,-116,1000,57,-1000,-716,-273,-56,-1000,-594,-220,-443,36,-365,-32,251,824,258,-1000,-1000,727,921,-1000,938,-889,308,-1000,-675,-313,-740,1000,-1000,-813,-1000,-102,897,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00068() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildToFront(com.google.javascript.rhino.Node):void",
            new int[]{566,-707,-197,216,1000,324,-54,-472,850,901,-974,885,-416,512,-13,818,118,-275,-394,137,706,-163,23,1000,559,-48,-377,-643,754,663,67,121,-714,-805,-79,-952,-804,63,-5,1000,439,1000,-535,-30,783,244,-92,-453,499,151,1000,329,-75,318,911,806,-792,-891,-936,-299,534,-58,390,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00069() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildToFront(com.google.javascript.rhino.Node):void",
            new int[]{-552,-671,1000,-920,591,943,-1000,-426,-761,768,224,1000,-497,681,708,990,660,1000,-984,1000,-377,1000,-58,969,1000,-1000,638,248,-19,-566,-363,-958,1000,104,931,951,1000,1000,-1000,1000,453,-201,-254,-158,-1000,-1000,-627,608,643,-1000,510,-1000,-1000,-185,-200,1000,792,456,775,41,-622,687,-650,59}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00070() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildToFront(com.google.javascript.rhino.Node):void",
            new int[]{-699,528,268,-1000,206,884,4,697,-1000,-1000,1000,-135,-729,-394,1000,517,1000,885,-227,-826,-1000,1000,751,-524,1000,-1000,847,344,-1000,-1000,579,-1000,1000,670,-525,-566,777,-811,-1000,-713,1000,72,919,1000,-636,-1000,-1000,891,1000,-836,-24,-1000,-960,-246,-1000,-1000,1000,1000,640,338,-482,972,-138,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00071() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildToFront(com.google.javascript.rhino.Node):void",
            new int[]{-1000,458,-308,-1000,1000,-705,19,646,-262,-1000,392,45,-400,-840,-830,636,69,106,1000,845,-872,-866,-1000,709,-87,107,-171,-886,115,-956,25,1000,226,243,-1000,-566,347,-1000,-1000,-670,1000,1000,-242,-578,788,90,235,-794,-22,593,1000,481,-671,534,-462,-1000,-120,671,640,-240,-933,930,-266,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00072() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildrenAfter(com.google.javascript.rhino.Node,com.google.javascript.rhino.Node):void",
            new int[]{42,-181,503,-154,-439,-469,781,-728,-89,628,-150,-963,351,-132,-555,122,-1000,452,421,278,804,-1000,-715,-1000,-937,1000,238,429,474,648,-388,1000,1000,-320,560,-393,-653,-826,822,-755,235,-186,817,1000,475,-887,486,-452,509,-97,-3,1000,20,-953,1000,-338,-647,1000,1000,146,660,-1000,-288,-497}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00073() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildrenAfter(com.google.javascript.rhino.Node,com.google.javascript.rhino.Node):void",
            new int[]{-1000,-926,399,-637,-689,462,179,-83,-239,950,-637,-1000,-1000,-1000,-666,1000,-1000,729,-506,-916,245,-451,58,-493,-821,-1000,243,1000,-749,1000,-1000,1000,1000,-1000,130,329,-828,408,508,-426,-122,-1000,1000,567,-33,-898,-1000,141,692,-1000,636,1000,1000,-739,-77,485,250,188,1000,1000,1000,-884,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00074() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildrenAfter(com.google.javascript.rhino.Node,com.google.javascript.rhino.Node):void",
            new int[]{427,-306,3,-939,802,668,272,723,-453,1000,-418,178,-790,350,-973,504,1000,-1000,1000,-9,-1000,-509,604,-190,-956,-773,321,506,-473,684,-813,107,1000,438,455,1000,-474,-503,-1000,1000,958,1000,-1000,-942,1000,-1000,-143,-411,-729,531,-69,753,-1000,787,806,20,104,1000,412,175,-502,-501,165,-100}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00075() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildrenAfter(com.google.javascript.rhino.Node,com.google.javascript.rhino.Node):void",
            new int[]{993,644,962,-497,412,-1000,1000,-985,-255,-270,-740,-299,871,-1000,-1000,23,537,-523,1000,1000,771,-1000,1000,-862,-939,818,934,-1000,940,-749,1000,1000,976,876,1000,-97,-45,-1000,1000,-423,209,1000,-1000,-56,1000,-1000,-571,-880,369,1000,-247,1000,-754,-515,1000,-1000,-1000,1000,1000,-1000,-922,-1000,445,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00076() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildrenAfter(com.google.javascript.rhino.Node,com.google.javascript.rhino.Node):void",
            new int[]{-468,-671,797,-1000,-423,541,-122,-402,562,-22,-1000,-238,566,1000,-480,-284,1000,-761,-616,749,-701,362,-639,-937,259,-201,-566,768,-1000,-600,226,224,733,612,207,874,-1000,1000,365,-58,1000,-672,1000,-434,390,729,-283,82,-409,1000,-1000,260,-1000,177,443,-309,386,-316,-35,906,-1000,-365,-143,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00077() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildrenAfter(com.google.javascript.rhino.Node,com.google.javascript.rhino.Node):void",
            new int[]{-20,459,983,613,-12,-258,526,-1000,-175,82,-334,-57,13,-190,-1000,912,-1000,1000,835,826,1000,-945,1000,-1000,695,1000,-1000,143,587,1000,-488,856,1000,-246,1000,-1000,-560,-836,1000,-365,-38,-1000,502,1000,501,-1000,-1000,532,1000,-88,-129,660,-535,-1000,-174,445,-179,202,1000,-825,-653,-1000,-1000,-936}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00078() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildrenAfter(com.google.javascript.rhino.Node,com.google.javascript.rhino.Node):void",
            new int[]{-853,-11,1000,-1000,-69,1000,48,-120,760,-1000,-740,-299,1000,495,-1000,-764,1000,-907,-440,665,-540,564,-142,-906,-220,-1000,-212,153,-1000,-772,-361,116,976,455,-449,864,-739,389,823,-836,209,131,-34,-56,1000,-148,-700,801,369,1000,-1000,1000,4,-199,-1000,946,10,4,-922,-363,-922,5,-61,576}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00079() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildrenAfter(com.google.javascript.rhino.Node,com.google.javascript.rhino.Node):void",
            new int[]{-1000,-247,661,-350,909,1000,290,219,-544,-417,-1000,-712,39,313,101,1000,-1000,1000,-825,-1000,1000,-1000,-781,6,-283,-446,-80,1000,-461,-1000,-1000,667,844,-1000,89,-1000,-1000,1000,804,-1000,510,-1000,1000,1000,755,-1000,-683,741,92,-95,1000,-1000,1000,-1000,-1000,1000,-440,1000,312,559,903,-943,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00080() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildrenAfter(com.google.javascript.rhino.Node,com.google.javascript.rhino.Node):void",
            new int[]{-468,68,519,172,-205,690,-1000,361,839,779,-74,-1,-322,1000,-962,745,105,339,228,82,-569,-511,-448,-680,1000,-70,-1000,1000,-1000,837,-1000,650,563,278,851,192,-928,934,8,-286,799,-1000,911,416,-500,-795,-236,495,-761,478,-926,466,-462,-1000,-985,787,1000,343,508,814,-444,-402,-937,-913}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00081() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildrenAfter(com.google.javascript.rhino.Node,com.google.javascript.rhino.Node):void",
            new int[]{170,124,829,-698,1000,390,790,-1000,-112,-687,-173,-363,844,1000,-689,1000,537,-523,350,870,1000,-562,397,-398,-157,766,891,-1000,661,-749,-400,653,674,542,706,-97,-213,400,487,-505,1000,1000,-1000,-434,1000,-1000,-966,-447,-376,1000,-622,1000,6,-1000,-661,-684,-723,645,564,-1000,-1000,-1000,603,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00082() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildrenAfter(com.google.javascript.rhino.Node,com.google.javascript.rhino.Node):void",
            new int[]{-698,-351,566,52,-223,50,389,-275,-80,58,-69,-1000,-440,-213,-628,-1000,-110,-329,-120,458,245,-574,-822,-319,-774,-374,682,977,-651,1000,-868,882,1000,-1000,360,-777,-1000,-203,676,-334,843,-575,615,944,317,-1000,-225,616,348,-195,812,1000,752,-458,-675,705,-541,188,1000,462,1000,-884,-579,-319}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00083() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildrenAfter(com.google.javascript.rhino.Node,com.google.javascript.rhino.Node):void",
            new int[]{-763,428,603,-380,-733,-936,201,46,-37,290,-493,-790,959,-443,-402,-449,763,-676,-1000,-336,-247,-803,1000,124,222,-175,144,-275,-464,-765,653,845,1000,1000,928,1000,-119,6,446,-374,1000,-898,-909,263,526,-866,-273,489,1000,669,-1000,894,-1000,477,543,-225,99,1000,683,-88,-362,-500,358,-205}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00084() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildrenAfter(com.google.javascript.rhino.Node,com.google.javascript.rhino.Node):void",
            new int[]{755,149,711,868,354,-1000,1000,-153,565,527,1000,21,196,-323,-1000,237,616,-376,1000,1000,-492,-713,1000,721,825,1000,365,-567,527,-538,-824,1000,571,278,1000,1000,-1000,925,211,1000,-970,1000,-1000,-819,-1000,-1000,-1000,-1000,1000,-133,-681,1000,400,1000,469,-1000,-1000,-345,1000,-1000,-1000,-746,219,735}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00085() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildrenAfter(com.google.javascript.rhino.Node,com.google.javascript.rhino.Node):void",
            new int[]{177,58,816,-712,-244,-159,1000,-761,332,-405,159,-554,1000,-935,-479,-1000,1000,-1000,-72,1000,187,-881,468,-803,-904,-642,1000,-165,-512,-1000,1000,599,921,469,851,1000,-619,-1000,911,-462,962,322,-1000,-64,1000,-756,-181,295,297,1000,-274,922,-424,-230,863,350,-514,617,759,-613,-851,-881,341,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00086() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildrenAfter(com.google.javascript.rhino.Node,com.google.javascript.rhino.Node):void",
            new int[]{-773,-58,894,-437,-4,666,624,-2,-195,-856,79,-631,828,-92,1000,134,-114,326,-144,-534,651,-265,609,-347,-1000,-606,445,315,-229,348,-839,660,662,-673,-124,1000,-302,-400,911,-1000,322,-99,-34,766,1000,-1000,-382,668,80,222,188,-84,1000,-1000,-610,1000,-343,926,759,-297,1000,-439,-661,-824}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00087() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildrenAfter(com.google.javascript.rhino.Node,com.google.javascript.rhino.Node):void",
            new int[]{0,93,1000,-1000,-1000,681,1000,-403,690,-1000,-882,-781,1000,-839,784,-1000,989,-1000,-1000,3,-648,-142,-130,-1000,-994,-1000,1000,-579,-1000,-1000,1000,510,814,438,38,1000,-294,-211,1000,-812,1000,-842,-644,90,1000,116,358,923,888,1000,-161,200,197,-1000,-1000,941,117,140,-390,605,326,-194,662,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00088() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildrenToBack(com.google.javascript.rhino.Node):void",
            new int[]{-229,99,-367,420,1000,-168,-1000,-20,-1000,-501,346,-458,26,-391,291,-401,535,25,266,727,-1000,418,-800,-165,137,-621,-392,404,-89,-428,-607,1000,-574,-743,-799,610,-870,-321,292,-628,1000,-644,1000,225,64,-828,920,1000,-391,-352,-161,810,-456,637,-33,-15,92,-1000,-271,-548,-693,-927,246,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00089() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildrenToBack(com.google.javascript.rhino.Node):void",
            new int[]{-767,569,531,1000,431,-312,-396,620,199,-620,15,-213,-596,35,314,-349,-1000,1000,712,-866,648,-674,-85,-66,-1000,-781,-334,-387,1000,351,347,-270,-597,513,850,647,-1000,-159,-591,424,-95,-228,89,-259,-257,-400,245,-67,49,113,-721,-463,-394,-241,-39,-723,395,-585,-120,920,765,276,627,-199}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00090() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildrenToBack(com.google.javascript.rhino.Node):void",
            new int[]{999,-407,352,-188,-925,1000,-377,-120,271,-101,636,811,107,-505,1000,-868,836,-326,1000,95,-555,-1000,-922,794,1000,432,-198,1000,-1000,1000,-1000,-208,-113,168,711,-858,706,177,746,-1000,-700,-1000,1000,1000,-767,-1000,60,-976,-976,82,-1000,-29,-155,-551,-582,400,498,-972,-1000,-27,-515,-506,112,845}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00091() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildrenToBack(com.google.javascript.rhino.Node):void",
            new int[]{1000,-306,-1000,445,-486,-1000,-353,209,334,-10,375,-670,-1000,-474,-1000,404,-646,427,1000,136,994,955,-31,-1000,1000,-693,-1000,-479,614,-1000,1000,340,-1000,-1000,975,1000,-997,252,1000,-361,1000,-292,-545,-406,818,869,-324,190,878,-507,839,692,-216,-375,484,-70,-448,-1000,-1000,433,71,-817,116,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00092() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildrenToBack(com.google.javascript.rhino.Node):void",
            new int[]{750,-331,913,728,-781,-379,-210,-245,351,791,328,1000,-385,228,696,114,263,-1000,1000,769,990,-996,-411,151,-892,1000,257,1000,-445,-33,-1000,-62,-915,-960,-857,-1000,-59,-150,-488,-1000,514,-1000,401,-167,-781,-931,48,-802,-867,-741,-428,469,-872,46,154,964,269,-1000,552,70,-238,-1000,165,-887}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00093() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildrenToBack(com.google.javascript.rhino.Node):void",
            new int[]{140,-351,558,-353,896,439,79,-314,-614,-34,-58,1000,-142,-601,903,19,1000,-405,1000,-165,-1000,423,-1000,-71,-625,134,-430,682,-493,-215,-1000,-672,-804,-1000,-975,149,67,-326,-290,-798,6,-569,730,1000,-174,-745,92,1000,-112,-448,-413,1000,-613,187,-565,-984,906,-240,662,1000,-1000,1000,244,-660}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00094() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildrenToBack(com.google.javascript.rhino.Node):void",
            new int[]{75,-886,344,477,-742,786,1000,377,-1000,941,-768,-200,-265,-1000,696,588,-387,-634,-1000,634,-670,-126,595,242,-331,989,833,-586,770,-152,-197,-688,-300,666,1000,-374,-416,-1000,-1000,770,-352,1000,597,-878,-1000,578,1000,179,538,1000,-1000,-352,756,-622,-153,-297,1000,-769,469,-14,-816,1000,-282,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00095() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildrenToBack(com.google.javascript.rhino.Node):void",
            new int[]{68,-388,-42,725,260,31,-1000,-1000,-616,-850,1000,563,570,-385,-264,883,-754,347,986,184,-910,365,-535,158,-663,166,614,803,403,-304,-1000,1000,-160,-578,-565,29,-411,-581,405,-979,370,-525,1000,306,-764,-1000,1000,-142,84,-600,-147,939,-880,384,-275,-34,-453,-1000,-296,314,-166,-685,621,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00096() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildrenToBack(com.google.javascript.rhino.Node):void",
            new int[]{837,569,748,804,-1000,792,745,-1000,-928,998,-890,-644,-521,-762,761,485,-1000,-143,-87,460,-115,-517,-180,1000,-1000,601,1000,-248,-163,233,-454,-203,269,631,-312,-1000,-256,-520,-217,-396,-100,23,349,-1000,-1000,0,169,-799,-310,381,-1000,-463,-247,456,47,-82,1000,-1000,1000,-293,-101,1000,698,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00097() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildrenToBack(com.google.javascript.rhino.Node):void",
            new int[]{-85,509,-111,367,-1000,-846,-338,-1000,1000,1000,-269,549,-556,1000,294,250,-180,-791,1000,67,1000,-767,-139,-320,-1000,972,67,567,389,-687,-981,1000,-214,-291,-1000,-1000,-582,-16,884,-1000,965,99,-558,659,-1000,-1000,398,-1000,-1000,-1000,770,1000,-1000,1000,-807,1000,122,-260,1000,-601,-727,-1000,-306,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00098() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildrenToBack(com.google.javascript.rhino.Node):void",
            new int[]{1000,-821,559,-266,-326,1000,79,143,-136,-187,879,1000,107,-572,857,-1000,839,-258,1000,-8,-962,-1000,-894,1000,-1000,843,319,1000,-896,1000,-1000,-208,-204,-228,712,-1000,752,-249,746,-1000,-941,9,1000,1000,-955,-1000,664,-303,-493,-252,-1000,107,518,-1000,-18,469,356,-789,1000,-309,-962,556,-389,420}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00099() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildrenToBack(com.google.javascript.rhino.Node):void",
            new int[]{-1000,203,-119,502,-64,-1000,316,-1000,-159,976,-1000,-1000,-958,482,-397,1000,-1000,-237,-810,270,984,384,237,-314,719,-212,-620,-796,148,-1000,1000,691,-310,-170,-757,1000,-678,424,857,742,1000,-575,-252,-1000,-91,818,-641,-887,43,-504,1000,-13,-781,711,124,492,226,-289,-1000,-181,-7,-1000,621,-172}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00100() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildrenToBack(com.google.javascript.rhino.Node):void",
            new int[]{196,-421,322,-2,297,-172,-1000,-759,-192,-59,469,970,-987,371,-169,283,187,-140,535,621,532,-88,151,90,208,-492,-248,191,882,192,81,740,-1000,-500,1000,-307,-532,-557,835,499,-244,708,-96,-108,-84,-131,562,-265,662,567,-478,182,-646,239,733,-292,372,-270,-211,253,268,-230,-235,-856}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00101() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildrenToBack(com.google.javascript.rhino.Node):void",
            new int[]{-1000,534,863,-304,-23,-842,-1000,-543,883,-232,-106,-851,293,655,-62,-341,73,63,-583,231,195,162,-1000,-872,692,-722,-474,-73,-886,-515,487,1000,-991,302,124,1000,-756,1000,962,-101,527,-1000,1000,465,435,-141,-554,107,-623,-845,931,1000,290,1000,-402,-138,-23,-1000,-148,-601,-513,-30,810,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00102() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildrenToBack(com.google.javascript.rhino.Node):void",
            new int[]{810,-78,762,607,-254,582,967,-1000,-334,-1000,-652,1000,76,-507,593,-911,1000,-165,1000,387,-917,676,277,827,-1000,-13,608,1000,5,328,-1000,-356,-215,-148,-596,-666,6,-185,64,-1000,-400,-702,1000,588,-915,-1000,964,-971,-421,-123,-715,-466,-1000,729,3,-254,-136,-1000,-822,-584,332,-1000,1000,186}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00103() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildrenToBack(com.google.javascript.rhino.Node):void",
            new int[]{313,-853,507,952,885,510,-824,-824,-949,-249,752,518,106,-959,-769,270,539,-165,886,-227,-893,672,-741,542,-472,854,974,484,481,-921,-829,-88,-46,-853,-830,-118,-198,-98,-570,-784,873,-238,-196,-499,-972,-647,644,-633,-55,-954,390,361,-248,-455,-46,859,-820,-980,-598,-350,-768,-210,266,-981}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00104() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildrenToFront(com.google.javascript.rhino.Node):void",
            new int[]{-132,-131,-797,497,655,90,721,472,205,30,-20,-403,-744,742,-785,729,-861,-959,-997,987,937,410,-150,-463,-500,-429,738,-620,-175,-309,-503,268,-333,-229,-223,-770,208,388,-126,-390,98,710,-318,-984,-747,408,-342,-883,-582,990,-176,-155,701,-90,-426,-781,-981,-192,304,-230,731,219,779,-689}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00105() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildrenToFront(com.google.javascript.rhino.Node):void",
            new int[]{1000,-382,616,-1000,-422,130,-410,-660,809,448,-650,39,-50,651,244,-105,-526,-428,-681,603,39,-419,888,800,-466,394,737,1000,-178,1000,118,-657,440,-177,1000,-25,220,-238,456,-1000,617,1000,-597,494,-711,1000,-704,164,638,997,881,-1000,775,-1000,500,-363,-738,850,136,494,-366,836,67,-221}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00106() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildrenToFront(com.google.javascript.rhino.Node):void",
            new int[]{-828,-641,910,982,120,355,559,-319,-309,191,435,1000,-892,1000,429,139,-971,-1000,-942,-119,956,-1000,1000,295,-1000,35,-58,-734,-999,603,1000,419,-165,302,1000,-958,76,-832,-1000,-511,1000,800,-1000,-206,-871,1000,-165,-1000,-199,1000,-314,-1000,1000,-778,-1000,519,-1000,727,809,825,1000,1000,1000,7}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00107() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildrenToFront(com.google.javascript.rhino.Node):void",
            new int[]{-40,-781,-229,-468,-871,-574,537,244,-667,1000,241,168,-347,697,109,-1000,-84,894,-987,-63,-1000,-1000,1000,753,-383,261,-440,-714,-1000,270,1000,496,236,-167,261,296,-188,772,184,-1000,638,146,370,-502,170,1000,-723,289,-53,-235,244,-411,-468,539,-454,452,28,-381,-235,161,-268,-50,-481,-427}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00108() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildrenToFront(com.google.javascript.rhino.Node):void",
            new int[]{1000,-781,-161,-930,236,-872,-15,-1000,1000,593,-464,150,-108,470,110,-314,-538,969,-205,686,-1000,7,571,439,-1000,820,475,308,-123,426,1000,-580,-72,-253,1000,-374,-258,134,559,-485,-142,800,157,263,-229,716,-227,496,-325,1000,1000,-923,-109,-1000,1000,-254,-843,734,563,126,-1000,134,-894,-54}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00109() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildrenToFront(com.google.javascript.rhino.Node):void",
            new int[]{-290,-286,-1000,550,834,13,-1000,368,617,-119,-202,-338,-1000,950,-1000,1000,-1000,-1000,-1000,1000,1000,854,-14,-654,-1000,-294,1000,-1000,224,-232,-393,24,-792,891,35,-955,179,489,-232,617,325,1000,-920,-1000,-1000,690,-380,-1000,-872,1000,-184,-89,1000,-185,-388,-1000,-1000,-89,784,-54,930,343,1000,-894}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00110() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildrenToFront(com.google.javascript.rhino.Node):void",
            new int[]{-846,572,5,466,-195,1000,156,-172,1000,-500,-6,724,-59,-157,505,1000,-1000,-823,-922,156,1000,615,-339,-100,-683,452,98,854,1000,1000,-1000,-352,-411,1000,-1000,-496,23,1000,-545,-453,-584,1000,-565,-660,-23,1000,156,69,-995,808,-177,139,130,-1000,1000,-203,-147,1000,1000,204,125,-110,-23,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00111() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildrenToFront(com.google.javascript.rhino.Node):void",
            new int[]{-1000,523,-209,-29,-970,-494,-1000,726,1000,-1000,-449,354,322,1000,1000,410,-1000,-524,-1000,585,162,1000,-251,-563,-1000,1000,1000,693,595,-789,694,-1000,84,1000,-23,552,86,1000,550,1000,-973,1000,59,-487,468,665,363,1000,-901,1000,-662,592,281,-1000,1000,-481,-1000,750,-422,-1000,796,-755,-801,185}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00112() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildrenToFront(com.google.javascript.rhino.Node):void",
            new int[]{962,-641,-917,-655,589,-1000,721,281,-19,840,235,379,-354,559,-192,504,-589,-147,-499,555,-1000,423,296,218,-554,451,58,-456,-85,-1000,1000,-112,-887,-1000,-270,-717,-322,587,-507,-1000,47,446,-597,247,-575,498,-829,315,518,995,1000,-118,687,-413,-872,-107,-1000,-172,319,37,-814,-17,-925,-275}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00113() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildrenToFront(com.google.javascript.rhino.Node):void",
            new int[]{-392,298,-711,-22,195,97,205,-134,388,-279,-322,-105,26,739,-485,-434,-574,-903,-651,564,-1000,587,277,-142,-1000,-67,640,-374,313,-813,-631,-112,-110,140,113,-675,297,572,-620,27,193,797,-739,-541,-784,704,-125,-433,-502,993,68,-492,714,-328,410,-697,-1000,-459,-151,-347,812,497,709,-457}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00114() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildrenToFront(com.google.javascript.rhino.Node):void",
            new int[]{-576,-926,132,954,-429,-998,-1000,51,144,-741,-406,-17,-146,1000,566,85,-574,765,-1000,1000,-1000,-216,156,-59,-1000,578,1000,358,-1000,268,1000,-1000,169,1000,144,1000,-510,1000,1000,1000,-503,-360,687,-615,987,-707,-542,1000,-705,277,76,515,-166,349,-840,215,1000,-618,-1000,-1000,-1000,-1000,-1000,414}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00115() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildrenToFront(com.google.javascript.rhino.Node):void",
            new int[]{67,14,38,-622,318,1000,648,1,919,179,250,-139,-583,-157,-509,580,-822,-33,-199,687,737,-136,759,368,-10,346,220,644,141,-964,-996,263,-457,600,-483,-345,11,401,-955,-127,626,953,91,-979,-206,363,-309,-439,-1000,448,397,-19,-79,-878,527,551,-99,825,-490,-499,933,-162,116,-466}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00116() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildrenToFront(com.google.javascript.rhino.Node):void",
            new int[]{174,-816,58,-1000,81,-588,403,-825,1000,-196,-1000,566,-288,48,612,573,-1000,-977,1000,-213,802,-827,421,289,485,270,434,1000,1000,-408,-951,-263,555,894,468,-493,553,-237,1000,219,796,1000,-998,-56,-521,1000,-104,-541,200,1000,444,-349,239,-1000,1000,552,-552,1000,815,-118,849,456,126,-522}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00117() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildrenToFront(com.google.javascript.rhino.Node):void",
            new int[]{-1000,-131,858,550,-1000,949,-1000,-425,313,30,-465,-407,-10,1000,-256,-41,-488,-300,-997,242,764,-1000,782,-296,-731,101,980,619,-477,1000,-1000,-614,156,1000,440,616,-234,137,245,-156,98,1000,612,-986,508,1000,191,615,-1000,-210,-1000,-450,701,-11,910,-781,1000,-291,-872,-643,1000,-64,658,-689}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00118() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildrenToFront(com.google.javascript.rhino.Node):void",
            new int[]{-542,184,892,-508,-218,583,-309,-1000,1000,-643,-1000,94,-439,190,360,768,-1000,-207,1000,-514,1000,-810,494,203,1000,559,594,730,948,467,-1000,-299,-243,1000,1000,-987,603,-508,655,602,86,904,-295,-480,-289,541,232,-706,-449,999,182,-499,710,-949,1000,1000,-126,509,695,6,1000,483,770,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00119() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addChildrenToFront(com.google.javascript.rhino.Node):void",
            new int[]{563,-926,729,-1000,-429,-1000,-1000,51,641,450,-406,848,26,739,807,-434,-574,766,-651,471,-1000,-216,832,475,-1000,930,74,99,433,385,1000,-710,691,-177,1000,1000,-510,-28,456,-1000,193,714,-502,510,102,932,-125,815,463,1000,858,-876,-166,-1000,410,215,-715,168,190,-330,-713,103,-1000,399}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00120() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addSuppression(java.lang.String):void",
            new int[]{-451,478,-817,186,471,-591,1000,-835,-691,-723,1000,746,171,260,110,510,-729,1000,114,342,-411,293,-20,-1000,131,571,494,1000,97,-355,159,215,499,1000,293,-512,1000,592,-181,289,739,280,99,-298,-133,-412,-574,-888,803,161,-418,594,-776,658,369,282,236,48,676,754,-763,-332,328,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00121() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addSuppression(java.lang.String):void",
            new int[]{297,764,892,-766,194,-1000,-873,862,1000,-84,-69,-284,336,179,752,-408,1000,-39,325,207,1000,1000,248,756,-236,-156,11,-535,-65,384,-464,-349,-1000,-778,-561,1000,-725,1000,259,-253,-949,1000,493,-1000,933,412,-895,1000,-692,-1000,558,633,-1000,266,543,-274,461,313,360,-408,-824,280,-381,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00122() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addSuppression(java.lang.String):void",
            new int[]{-58,629,146,-101,703,-483,16,-692,-1000,-1000,224,1000,-34,979,869,71,89,-506,-1000,202,742,91,-454,-999,-27,788,232,1000,-585,-1000,-564,-770,401,183,-736,-197,566,-665,-400,-292,-5,489,347,777,-973,1000,385,-1000,303,-949,-1000,810,-460,-880,-115,244,-80,1000,-1000,-926,-175,-1000,513,194}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00123() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addSuppression(java.lang.String):void",
            new int[]{-841,414,851,-736,207,168,-183,-1000,232,804,478,-1000,-1000,-377,757,-414,920,41,-194,-84,-1000,195,-1000,271,-1000,1000,-1000,389,-406,-101,747,329,941,-1000,576,-325,731,1000,-313,495,-327,954,-1000,-406,1000,-1000,-659,685,-666,-757,903,-439,-267,1000,314,-739,-273,-1000,-20,-36,304,395,-1000,692}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00124() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addSuppression(java.lang.String):void",
            new int[]{-58,253,-474,-1000,218,-990,-510,-266,1000,763,-22,-905,76,249,1000,-209,-271,-596,254,118,-8,-153,-530,936,961,-1000,280,-1000,-345,1000,-695,-542,-1000,-390,3,1000,-635,842,128,989,1000,1000,-1000,-566,845,11,349,1000,90,1000,1000,825,-237,-327,7,-910,771,-1000,-117,-98,381,344,1000,700}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00125() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addSuppression(java.lang.String):void",
            new int[]{-222,249,-313,-262,1000,-650,185,-1000,221,-1000,1000,783,-544,341,839,1000,-1000,1000,252,329,190,437,-880,756,408,33,1000,26,-893,-181,-326,242,1000,516,274,-131,897,428,-282,357,1000,563,-573,-263,29,-75,571,-68,1000,1000,562,1000,-274,701,312,35,913,-16,901,1000,458,141,1000,942}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00126() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addSuppression(java.lang.String):void",
            new int[]{219,-306,38,-60,508,264,1000,95,183,-1000,584,1000,-818,-1000,-178,641,-963,-1000,-194,570,126,-236,-95,-866,388,-746,-523,288,689,-70,-1000,-333,-830,-704,169,-887,191,-1000,1000,-678,-122,284,-746,479,-825,616,1000,1000,1000,1000,-1000,168,-645,-60,754,-552,-791,616,1000,1000,921,334,394,-86}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00127() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addSuppression(java.lang.String):void",
            new int[]{-357,509,-134,895,426,390,1000,-1000,-656,-806,1000,331,-947,-464,-535,322,-700,284,254,-12,-698,-223,-613,-450,-190,-538,-776,1000,-177,-514,700,489,926,-13,842,-1000,1000,237,1000,8,180,489,-509,217,-372,-804,-108,-1000,1000,309,-593,-371,-207,900,213,686,-376,394,1000,-78,358,245,-537,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00128() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addSuppression(java.lang.String):void",
            new int[]{468,188,-945,-992,166,-320,801,862,511,62,-721,166,175,-98,413,-66,-1000,-1000,-292,891,233,-465,1000,-86,974,-983,-48,-773,182,856,-465,-491,-657,928,719,305,-918,-972,197,440,498,1000,315,-515,-245,325,531,1000,-95,1000,-369,661,-1000,-934,1000,-754,-481,-557,-937,351,-387,-91,1000,942}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00129() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addSuppression(java.lang.String):void",
            new int[]{766,384,-434,-1000,1000,-728,112,862,518,1000,-284,-962,14,527,1000,-728,198,-642,-238,199,1000,-509,-562,756,597,-843,128,-344,-65,856,-174,-557,-517,224,274,1000,42,-34,-282,1000,1000,1000,-573,-157,933,-102,-255,1000,-185,837,1000,633,-274,-643,-337,-274,509,-1000,-937,-886,34,-436,899,942}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00130() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addSuppression(java.lang.String):void",
            new int[]{1000,-141,-302,-549,1000,-1000,1000,825,401,1000,-1000,162,520,317,50,-321,-1000,-1000,-295,365,759,287,1000,-1000,384,-1000,-236,-623,-1000,1000,-1000,-644,285,-410,755,330,-849,-1000,1000,1000,22,954,34,-406,128,1000,1000,-167,-641,1000,-369,-612,-515,-1000,740,-845,-1000,-1000,-1000,29,-817,-698,421,-223}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00131() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addSuppression(java.lang.String):void",
            new int[]{1000,274,-814,-736,510,-487,801,825,401,343,-805,-27,242,133,50,-297,-1000,-1000,-194,570,323,-626,1000,-866,767,-988,-122,-623,-1000,476,-380,-477,285,950,726,330,-812,-972,-64,608,174,954,-94,-406,-115,186,1000,-167,-266,1000,-369,620,-267,-954,943,-664,-847,-1000,-20,-36,-500,-364,451,-86}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00132() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addSuppression(java.lang.String):void",
            new int[]{-1000,-331,-345,798,-1000,122,-50,-438,890,1000,-278,-1000,-394,-1000,-1000,-345,-404,266,767,-1000,-571,-80,-867,953,484,406,75,-685,-85,-633,416,-293,-313,-220,1000,110,329,516,158,1000,606,-1000,32,-204,-213,-1000,278,909,-518,24,1000,141,1000,-784,-1000,-190,-143,342,89,204,393,-41,-85,-139}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00133() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addSuppression(java.lang.String):void",
            new int[]{1000,-786,20,-971,452,322,1000,269,232,1000,-1000,-1000,-1000,-1000,1000,-1000,-989,-1000,1000,846,-259,-779,1000,-406,103,-182,-1000,-534,-645,-39,-838,-564,191,806,1000,805,-389,136,1000,1000,865,718,-264,-365,1000,-577,46,811,-957,-662,1000,-917,-268,-428,259,-1000,-1000,-1000,788,-1000,-774,844,-43,-593}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00134() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addSuppression(java.lang.String):void",
            new int[]{82,538,-741,-130,259,-398,280,-171,34,-825,792,-654,-198,-520,1000,-144,-328,878,1000,205,-3,192,661,673,152,389,-368,70,1000,108,801,679,166,587,1000,19,296,1000,-705,551,287,823,-58,-1000,410,-1000,-1000,-358,87,-744,982,621,-1000,1000,819,-832,128,51,545,-460,-1000,889,-653,841}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00135() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "addSuppression(java.lang.String):void",
            new int[]{92,953,-211,-360,-424,213,-1000,1000,1000,-519,92,-1000,-540,-690,1000,-728,1000,-702,1000,669,-412,1000,358,-58,521,1000,-611,-1000,1000,-1000,825,-52,-1000,-915,564,1000,-947,1000,-1000,-70,-115,1000,-38,-1000,-19,-1000,-1000,1000,-464,-1000,1000,1000,-645,729,802,-742,873,-580,1000,-966,-547,1000,-287,-779}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00136() {
        org.junit.Assert.assertEquals("THROW:java.lang.NullPointerException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "appendStringTree(java.lang.Appendable):void",
            new int[]{133,-761,-615,-787,-723,-679,1000,-835,-999,-457,-673,-647,222,782,-207,781,-809,-161,-795,73,-274,-300,-1000,1000,882,-678,-1000,-269,-1000,444,-191,-156,903,915,-986,-198,418,-152,535,-429,1000,-587,-490,-883,-481,409,1000,173,166,189,115,417,272,297,-305,-469,844,-266,-1000,-748,-1000,-1000,788,-501}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00137() {
        org.junit.Assert.assertEquals("THROW:java.lang.NullPointerException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "appendStringTree(java.lang.Appendable):void",
            new int[]{-1000,244,-115,-1000,1000,-973,1000,-1000,-357,-269,-427,-921,-964,-767,1000,594,-258,-451,-669,-160,-266,-1000,137,284,-55,-319,-1000,-722,-277,-1000,269,-1000,28,-1000,-185,-710,-1000,908,462,623,-200,-403,1000,-809,-404,-455,120,-1000,-935,1000,302,268,484,-928,595,-1000,995,816,-1000,529,-943,-281,14,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00138() {
        org.junit.Assert.assertEquals("THROW:java.lang.NullPointerException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "appendStringTree(java.lang.Appendable):void",
            new int[]{924,114,37,-955,-929,-798,-52,733,451,722,-706,1000,516,-87,-121,-484,-286,-363,-770,-244,912,1000,-1000,-616,-1000,-602,231,1000,-770,-1000,-1000,-732,835,82,-766,1000,-685,-973,-914,102,1000,-644,-223,866,656,377,620,718,833,-1000,-342,-1000,-231,1000,-535,-657,544,-10,-1000,-4,944,953,130,-793}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00139() {
        org.junit.Assert.assertEquals("THROW:java.lang.NullPointerException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "appendStringTree(java.lang.Appendable):void",
            new int[]{879,34,175,1000,286,-690,346,-407,332,748,340,-110,349,-268,605,-104,-183,-726,-368,111,-780,-512,728,152,460,-975,555,878,41,334,-652,-254,285,-315,722,1000,1000,-721,-1000,35,-173,-804,64,-48,1000,688,-271,1000,210,-58,-842,-1000,-1000,1000,-1000,-1000,761,1000,-344,-1000,1000,913,13,-937}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00140() {
        org.junit.Assert.assertEquals("THROW:java.lang.NullPointerException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "appendStringTree(java.lang.Appendable):void",
            new int[]{-775,149,-1000,505,526,-662,583,-134,-382,-10,652,664,1000,338,102,1000,1000,-219,-1000,-768,26,477,-381,1000,1000,-652,-935,-1000,-1000,-627,-298,-1000,-836,486,-198,-380,1000,-554,1000,-2,151,-732,-862,-1000,-798,-451,835,1000,1000,460,-363,-1000,-1000,-1000,-30,809,1000,-1000,684,1000,-1000,-1000,957,-143}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00141() {
        org.junit.Assert.assertEquals("THROW:java.lang.NullPointerException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "appendStringTree(java.lang.Appendable):void",
            new int[]{-259,-716,-1000,901,-260,-904,153,277,-75,293,648,1000,1000,533,-661,512,1000,-449,-940,-572,128,656,-302,1000,1000,-1000,-782,-1000,-790,-850,-508,-1000,-790,1000,259,-148,477,-994,1000,-11,-157,-1000,-849,-950,-526,-46,627,1000,1000,-25,-456,393,1000,1000,1000,516,755,-1000,990,1000,-837,-849,939,476}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00142() {
        org.junit.Assert.assertEquals("THROW:java.lang.NullPointerException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "appendStringTree(java.lang.Appendable):void",
            new int[]{-544,4,-884,25,254,-819,522,-921,-657,-951,143,761,-325,-939,-454,954,25,-816,-411,-747,-967,-643,-986,663,706,-40,-956,-875,-465,517,611,-529,-854,122,592,-61,769,368,859,933,708,-93,850,-612,-544,-789,897,-230,-845,591,-404,545,675,47,131,744,755,187,-326,-823,-631,-925,698,783}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00143() {
        org.junit.Assert.assertEquals("THROW:java.lang.NullPointerException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "appendStringTree(java.lang.Appendable):void",
            new int[]{-791,-711,-1000,25,-701,-1000,942,-1000,-286,-886,419,713,14,-1000,-437,408,431,-891,-298,-1000,-692,-357,-449,213,-694,635,-209,-1000,-366,1000,1000,-1000,-1000,324,-633,457,-107,158,136,1000,-438,-955,1000,356,-338,-989,673,-230,-915,591,-897,102,1000,1000,727,1000,679,390,-247,-1000,515,-1000,572,437}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00144() {
        org.junit.Assert.assertEquals("THROW:java.lang.NullPointerException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "appendStringTree(java.lang.Appendable):void",
            new int[]{-466,-201,-1000,532,427,-472,-285,-546,-173,193,-498,742,1000,609,703,1000,728,-925,-707,-453,359,-523,351,432,1000,-943,-1000,-1000,-824,-1000,-866,-709,-730,430,1000,-1000,122,170,1000,-286,260,-590,511,723,-479,1000,-30,-410,85,1000,375,-140,-463,-1000,678,-1000,1000,-359,444,-877,-1000,343,-310,-70}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00145() {
        org.junit.Assert.assertEquals("THROW:java.lang.NullPointerException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "appendStringTree(java.lang.Appendable):void",
            new int[]{-33,-156,-500,228,326,-309,-587,-505,-353,821,-252,179,158,170,598,286,-225,-161,-864,-38,-274,-382,-1000,1000,675,-512,-656,-72,-550,-303,-454,-809,903,40,295,-490,400,-22,842,249,96,-527,461,-434,-500,-497,-79,-356,-630,544,115,-269,199,-465,533,217,895,-235,539,-748,-298,-171,631,-188}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00146() {
        org.junit.Assert.assertEquals("THROW:java.lang.NullPointerException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "appendStringTree(java.lang.Appendable):void",
            new int[]{-38,-232,-731,-453,-287,-57,1000,-1000,-820,155,16,-784,456,520,1000,1000,-637,-706,242,-548,-1000,-820,-455,284,660,-775,-87,-217,-267,970,-363,-10,499,-443,128,-321,959,14,-1000,-261,364,-711,626,769,1000,1000,636,421,416,765,-89,46,-973,-516,-1000,-1000,1000,1000,-1000,-1000,264,-1000,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00147() {
        org.junit.Assert.assertEquals("THROW:java.lang.NullPointerException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "appendStringTree(java.lang.Appendable):void",
            new int[]{-1000,628,-1000,621,-1000,-753,1000,-1000,-564,-237,-673,636,27,-127,1000,781,1000,-182,-1000,-1000,653,377,-1000,1000,882,-751,-797,-1000,-1000,-176,-270,-1000,-571,-704,-986,-1000,-800,-663,1000,-218,-163,-1000,-47,-1000,-421,-348,288,193,317,1000,499,1000,1000,-1000,763,650,1000,-790,-127,977,-1000,-1000,930,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00148() {
        org.junit.Assert.assertEquals("THROW:java.lang.NullPointerException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "appendStringTree(java.lang.Appendable):void",
            new int[]{1000,484,66,-482,-444,1000,179,-1000,167,654,1000,1000,1000,337,1000,-482,1000,-1000,-953,80,-816,1000,243,-1000,447,-1000,1000,-864,-80,-1000,-1000,-1000,-651,1000,1000,1000,-335,-1000,-1000,-616,1000,-1000,680,-557,1000,-229,-1000,140,-148,-28,-14,-152,1000,-942,-371,-1000,1000,-1000,-893,-198,1000,1000,-760,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00149() {
        org.junit.Assert.assertEquals("THROW:java.lang.NullPointerException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "appendStringTree(java.lang.Appendable):void",
            new int[]{-24,74,-126,383,-524,-973,-423,-515,336,1000,-912,440,-1000,-389,473,-489,526,-1000,-790,-193,761,-164,637,-711,-271,-240,-186,-175,-403,-896,-787,-1000,-196,-1000,794,2,-1000,147,-14,850,-717,-471,1000,-1000,37,-1000,-865,-525,-1000,323,-353,-1000,15,-205,454,582,984,-1000,973,1000,-618,933,1000,-146}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00150() {
        org.junit.Assert.assertEquals("THROW:java.lang.NullPointerException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "appendStringTree(java.lang.Appendable):void",
            new int[]{-710,414,-1000,-446,659,-511,1000,-1000,-994,-951,-182,-96,996,-538,-661,1000,-389,-1000,-638,-1000,-1000,-1000,-581,1000,-360,51,-932,-1000,-542,-1000,-431,-929,-1000,-210,119,133,1000,1000,307,1000,422,-1000,1000,-1000,-791,-123,987,737,-60,383,-1000,557,420,138,1000,737,880,-405,957,-718,-1000,-1000,-914,312}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00151() {
        org.junit.Assert.assertEquals("THROW:java.lang.NullPointerException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "appendStringTree(java.lang.Appendable):void",
            new int[]{383,-692,668,-846,-1000,-926,372,143,181,1000,503,-799,-976,124,1000,-119,1000,263,-546,400,1000,117,629,392,-82,-1000,148,-325,-490,-415,-1000,-794,856,-486,-965,318,-1000,-1000,-470,43,668,-357,-796,-377,553,-95,-502,-110,-161,-519,-381,-588,-192,-127,-40,-642,650,764,-474,249,354,275,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00152() {
        org.junit.Assert.assertEquals("java.lang.String:Tm9kZSB0cmVlIGluZXF1YWxpdHk6ClRyZWUxOgpTQ1JJUFQgW2pzZG9jX2luZm86IEpTRG9jSW5mb10gW2xlbmd0aDogMjE0NzQ4MzY0N10KICAgIFNDUklQVAogICAgU0NSSVBUCgoKVHJlZTI6ClNDUklQVAoKClN1YnRyZWUxOiBTQ1JJUFQgW2pzZG9jX2luZm86IEpTRG9jSW5mb10gW2xlbmd0aDogMjE0NzQ4MzY0N10KICAgIFNDUklQVAogICAgU0NSSVBUCgoKU3VidHJlZTI6IFNDUklQVAo=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "checkTreeEquals(com.google.javascript.rhino.Node):java.lang.String",
            new int[]{623,14,213,-471,-628,-100,-784,-619,-616,-523,679,619,-925,-1000,799,406,-376,-71,-211,236,920,937,562,-1000,1000,426,706,588,609,-808,-1000,400,-16,1000,-106,398,567,-1000,-588,346,55,1000,-476,-107,623,-199,1000,1000,1000,228,-890,-551,-69,-410,-649,1000,-484,-1000,1000,-782,400,-1000,-820,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00153() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "checkTreeEquals(com.google.javascript.rhino.Node):java.lang.String",
            new int[]{835,39,-519,186,-203,-642,-929,-921,-1000,437,-533,1000,-1000,-1000,365,888,868,358,-405,-78,50,206,-213,-514,1000,-956,1000,142,-160,-236,-1000,-366,-247,1000,-515,-511,-1000,-141,312,-281,339,1000,1000,-317,751,79,294,1000,944,467,-835,173,-567,418,-729,400,-842,-811,-533,-94,903,-276,-348,305}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00154() {
        org.junit.Assert.assertEquals("java.lang.String:Tm9kZSB0cmVlIGluZXF1YWxpdHk6ClRyZWUxOgpTQ1JJUFQgNTI0Mjg3IFtkaXJlY3RpdmVzOiBbaXRlbTQsIGl0ZW0wLCBpdGVtMV1dCiAgICBTQ1JJUFQgNTI0Mjg3CgoKVHJlZTI6ClNDUklQVAoKClN1YnRyZWUxOiBTQ1JJUFQgNTI0Mjg3IFtkaXJlY3RpdmVzOiBbaXRlbTQsIGl0ZW0wLCBpdGVtMV1dCiAgICBTQ1JJUFQgNTI0Mjg3CgoKU3VidHJlZTI6IFNDUklQVAo=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "checkTreeEquals(com.google.javascript.rhino.Node):java.lang.String",
            new int[]{-35,59,-450,-1000,-706,-31,-650,-214,-476,139,125,868,-1000,-1000,958,1000,389,919,-217,-1000,12,1000,994,-1000,1000,562,768,-615,638,-119,-580,905,605,581,-482,-64,-1000,-1000,-288,-1000,226,1000,411,-2,1000,133,1000,89,1000,-78,-607,-1000,-349,-37,-336,1000,-1000,-1000,-856,-202,138,-1000,-508,30}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00155() {
        org.junit.Assert.assertEquals("java.lang.String:Tm9kZSB0cmVlIGluZXF1YWxpdHk6ClRyZWUxOgpTQ1JJUFQgW29wdF9hcmc6IDFdCiAgICBTQ1JJUFQKCgpUcmVlMjoKU0NSSVBUCgoKU3VidHJlZTE6IFNDUklQVCBbb3B0X2FyZzogMV0KICAgIFNDUklQVAoKClN1YnRyZWUyOiBTQ1JJUFQK", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "checkTreeEquals(com.google.javascript.rhino.Node):java.lang.String",
            new int[]{203,254,-943,-642,392,10,248,970,-821,741,-134,77,-183,-1000,-725,-124,1000,1000,800,-305,1000,765,876,-1000,1000,-335,707,-123,1000,175,-328,827,-746,536,-104,673,-1000,-956,-50,339,-932,1000,-993,-859,614,312,402,-20,1000,-225,-617,-185,-914,-292,125,297,-471,-807,859,-548,0,-407,771,7}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00156() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "checkTreeEquals(com.google.javascript.rhino.Node):java.lang.String",
            new int[]{-1000,-371,-1000,1000,127,-522,-267,-1000,-1000,-950,-678,1000,610,151,528,1000,138,-105,-701,1000,46,551,561,873,1000,264,-300,539,525,-700,-713,-1000,-889,754,1000,445,192,787,-884,814,-537,592,-151,-649,-1000,418,240,-452,1000,78,-229,1000,687,-110,1000,266,-209,-818,613,-1000,-657,-163,-640,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00157() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "checkTreeEquals(com.google.javascript.rhino.Node):java.lang.String",
            new int[]{-256,224,381,-825,363,805,-166,660,-990,1000,-778,-203,-908,-635,-758,385,41,1000,407,128,190,475,1000,-388,319,-1000,140,754,309,-155,633,846,-157,-717,128,-355,-89,-839,-993,383,-201,650,-574,-943,1000,-14,-873,-195,1000,-1000,-615,-724,-237,-1000,-348,-326,-951,-1000,792,-111,-353,929,1000,476}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00158() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalStateException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "checkTreeEquals(com.google.javascript.rhino.Node):java.lang.String",
            new int[]{-772,-321,-982,-1000,-143,1000,345,834,-76,1000,-1000,-700,272,400,-604,-652,563,1000,-571,-466,-1000,69,138,400,538,124,365,344,341,-254,1000,20,1000,-1000,41,-89,-697,286,118,-832,-196,-400,33,-321,80,840,-318,-196,-400,-690,708,-203,-551,-415,754,-668,-785,400,382,-395,-124,400,896,-751}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00159() {
        org.junit.Assert.assertEquals("java.lang.String:Tm9kZSB0cmVlIGluZXF1YWxpdHk6ClRyZWUxOgpTQ1JJUFQgW2lucHV0X2lkOiBJbnB1dElkOiAweDgwMDAwMDAwMDBdCiAgICBTQ1JJUFQKCgpUcmVlMjoKU0NSSVBUCgoKU3VidHJlZTE6IFNDUklQVCBbaW5wdXRfaWQ6IElucHV0SWQ6IDB4ODAwMDAwMDAwMF0KICAgIFNDUklQVAoKClN1YnRyZWUyOiBTQ1JJUFQK", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "checkTreeEquals(com.google.javascript.rhino.Node):java.lang.String",
            new int[]{-317,44,-438,292,-1000,-954,-162,461,352,437,-723,-632,112,-1000,-751,-97,601,716,544,-994,-1000,1000,1000,-403,435,-1000,-488,918,1000,-1000,529,406,719,-8,-1000,46,-1000,-697,761,-792,-932,11,963,2,48,1000,432,-196,354,403,-950,-19,-53,-194,-752,400,-1000,97,1000,-1000,98,-646,-56,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00160() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "checkTreeEquals(com.google.javascript.rhino.Node):java.lang.String",
            new int[]{848,-861,-1000,471,529,952,-153,-173,-38,1000,-1000,-1000,1000,1000,-1000,-410,-926,-201,-256,980,-1000,826,1000,1000,-1000,-1000,-1000,1000,871,842,265,-1000,-128,-1000,866,-1000,1000,416,981,-1000,-1000,-1000,871,-219,-792,1000,-1000,479,-77,-181,-443,1000,69,263,-1000,-1000,-810,1000,1000,-347,-500,1000,1000,141}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00161() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "checkTreeEquals(com.google.javascript.rhino.Node):java.lang.String",
            new int[]{710,-96,412,1000,1000,-724,-989,-1000,-1000,771,-1000,961,-209,400,-77,-140,-10,671,-773,721,-1000,-1000,-333,1000,68,-1000,457,943,-731,747,-1000,-1000,-364,633,-739,-1000,-174,770,-1000,-502,1000,3,1000,-454,506,219,-1000,1000,190,621,-261,1000,-642,1000,-885,-1000,33,809,-1000,547,1000,1000,1000,-990}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00162() {
        org.junit.Assert.assertEquals("java.lang.String:Tm9kZSB0cmVlIGluZXF1YWxpdHk6ClRyZWUxOgpTQ1JJUFQgW2NoYW5nZV90aW1lOiAtMjE0NzQ4MzY0OF0KICAgIFNDUklQVAogICAgU0NSSVBUCgoKVHJlZTI6ClNDUklQVAoKClN1YnRyZWUxOiBTQ1JJUFQgW2NoYW5nZV90aW1lOiAtMjE0NzQ4MzY0OF0KICAgIFNDUklQVAogICAgU0NSSVBUCgoKU3VidHJlZTI6IFNDUklQVAo=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "checkTreeEquals(com.google.javascript.rhino.Node):java.lang.String",
            new int[]{31,634,-197,-181,-723,283,9,248,229,1000,-1000,-394,-1000,24,-550,-790,-93,423,-491,701,-231,20,358,387,336,-880,-584,760,127,-104,-1000,-432,1000,182,907,-137,372,268,-410,622,1000,-586,599,-129,57,899,-775,1000,-233,109,-89,-189,-239,-69,-322,-423,-75,218,902,-734,6,-120,959,-154}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00163() {
        org.junit.Assert.assertEquals("java.lang.String:Tm9kZSB0cmVlIGluZXF1YWxpdHk6ClRyZWUxOgpTQ1JJUFQgW2VtcHR5X2Jsb2NrOiAxXSBbZGlyZWN0aXZlczogW2l0ZW00XV0KICAgIFNDUklQVAoKClRyZWUyOgpTQ1JJUFQKCgpTdWJ0cmVlMTogU0NSSVBUIFtlbXB0eV9ibG9jazogMV0gW2RpcmVjdGl2ZXM6IFtpdGVtNF1dCiAgICBTQ1JJUFQKCgpTdWJ0cmVlMjogU0NSSVBUCg==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "checkTreeEquals(com.google.javascript.rhino.Node):java.lang.String",
            new int[]{1000,-386,-488,-246,-628,-21,-1000,-809,-1000,-33,94,619,-1000,-1000,440,180,-376,588,-350,-926,500,805,761,-1000,1000,616,1000,-603,469,-924,-1000,-3,238,1000,-307,-52,-1000,-860,-1000,-150,55,1000,851,3,853,144,1000,1000,1000,610,-1000,-337,-303,11,-1000,1000,-902,-1000,-333,-782,656,-1000,-508,874}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00164() {
        org.junit.Assert.assertEquals("java.lang.String:Tm9kZSB0cmVlIGluZXF1YWxpdHk6ClRyZWUxOgpTQ1JJUFQgW2RpcmVjdGl2ZXM6IFtpdGVtMiwgaXRlbTQsIGl0ZW0wXV0KICAgIFNDUklQVAogICAgU0NSSVBUCgoKVHJlZTI6ClNDUklQVAoKClN1YnRyZWUxOiBTQ1JJUFQgW2RpcmVjdGl2ZXM6IFtpdGVtMiwgaXRlbTQsIGl0ZW0wXV0KICAgIFNDUklQVAogICAgU0NSSVBUCgoKU3VidHJlZTI6IFNDUklQVAo=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "checkTreeEquals(com.google.javascript.rhino.Node):java.lang.String",
            new int[]{1000,-911,-11,-30,-1000,518,-738,-701,-1000,562,-763,-870,893,1000,-1000,-1000,-1000,-49,-116,1000,-70,323,772,1000,-1000,-950,-371,539,803,-1000,481,-1000,305,790,259,-1000,1000,936,-768,-539,-1000,-1000,1000,204,-339,889,-177,350,-1000,1000,-1000,1000,231,-593,-777,-826,-339,1000,500,-1000,605,1000,179,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00165() {
        org.junit.Assert.assertEquals("java.lang.String:Tm9kZSB0cmVlIGluZXF1YWxpdHk6ClRyZWUxOgpTQ1JJUFQgW2pzZG9jX2luZm86IEpTRG9jSW5mb10gW2xlbmd0aDogMjE0NzQ4MzY0N10KICAgIFNDUklQVAoKClRyZWUyOgpTQ1JJUFQKCgpTdWJ0cmVlMTogU0NSSVBUIFtqc2RvY19pbmZvOiBKU0RvY0luZm9dIFtsZW5ndGg6IDIxNDc0ODM2NDddCiAgICBTQ1JJUFQKCgpTdWJ0cmVlMjogU0NSSVBUCg==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "checkTreeEquals(com.google.javascript.rhino.Node):java.lang.String",
            new int[]{299,-696,-220,693,653,-235,371,-197,-1000,562,-658,-83,-117,-31,58,-1000,275,570,929,1000,501,597,290,672,-176,-323,221,638,325,920,82,-434,-1000,790,-141,-1000,-421,1000,762,-1000,619,153,326,-610,-626,491,-452,1000,-10,545,-166,1000,62,-529,-777,-1000,-41,1000,1000,-830,73,464,1000,375}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00166() {
        org.junit.Assert.assertEquals("java.lang.String:Tm9kZSB0cmVlIGluZXF1YWxpdHk6ClRyZWUxOgpTQ1JJUFQgNTI0Mjg4IFtpbnB1dF9pZDogSW5wdXRJZDogIF0KICAgIFNDUklQVAoKClRyZWUyOgpTQ1JJUFQKCgpTdWJ0cmVlMTogU0NSSVBUIDUyNDI4OCBbaW5wdXRfaWQ6IElucHV0SWQ6ICBdCiAgICBTQ1JJUFQKCgpTdWJ0cmVlMjogU0NSSVBUCg==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "checkTreeEquals(com.google.javascript.rhino.Node):java.lang.String",
            new int[]{321,-521,-883,-103,1000,-928,746,834,-1000,582,-52,309,108,-1000,-627,-573,1000,1000,1000,232,1000,974,760,-728,1000,132,1000,-73,894,1000,-847,845,-1000,1000,-914,171,-1000,-369,328,-590,-734,1000,-1000,-1000,202,147,394,463,1000,154,-484,786,-958,-653,623,-92,-329,279,902,-579,121,-102,896,216}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00167() {
        org.junit.Assert.assertEquals("java.lang.String:Tm9kZSB0cmVlIGluZXF1YWxpdHk6ClRyZWUxOgpTQ1JJUFQgW2RpcmVjdGl2ZXM6IFtpdGVtNCwgaXRlbTBdXSBbc291cmNlX2ZpbGU6IDB4OF0KICAgIFNDUklQVAoKClRyZWUyOgpTQ1JJUFQKCgpTdWJ0cmVlMTogU0NSSVBUIFtkaXJlY3RpdmVzOiBbaXRlbTQsIGl0ZW0wXV0gW3NvdXJjZV9maWxlOiAweDhdCiAgICBTQ1JJUFQKCgpTdWJ0cmVlMjogU0NSSVBUCg==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "checkTreeEquals(com.google.javascript.rhino.Node):java.lang.String",
            new int[]{471,-362,-204,134,1000,-55,-932,-1000,-1000,362,-696,1000,-503,-856,253,-315,-612,1000,-98,584,-981,45,105,323,-770,-129,1000,618,-490,206,-351,-407,-159,1000,-730,-1000,-70,328,-1000,342,1000,807,1000,-838,1000,113,-806,747,330,3,-1000,47,61,819,-1000,-678,-398,-998,-1000,-106,414,402,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00168() {
        org.junit.Assert.assertEquals("TYPE:java.util.Collections$EmptySet", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "children():java.lang.Iterable",
            new int[]{438,819,-508,-170,-347,86,1000,-1000,-778,1000,1000,217,-1000,346,489,1000,436,273,-118,-330,303,641,1000,-936,-513,412,-411,1000,800,65,286,55,-514,-285,-1000,205,-210,1000,-432,-1000,405,376,-1000,486,532,-1000,-352,640,224,-523,-986,1000,687,227,-215,958,949,-1000,50,-1000,29,247,69,651}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00169() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node$SiblingNodeIterable", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "children():java.lang.Iterable",
            new int[]{610,344,329,-32,-1000,705,-522,531,449,199,-136,815,1000,-432,-162,417,1000,-957,1000,-135,1000,-483,-1000,638,180,-301,373,-1000,781,1000,1000,-1000,-12,-1000,248,1000,574,-1000,374,-119,-1000,1000,86,-1000,-1000,104,-861,-1000,-1000,-1000,1000,-715,-467,-353,939,652,-653,222,-12,1000,530,-400,-210,630}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00170() {
        org.junit.Assert.assertEquals("TYPE:java.util.Collections$EmptySet", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "children():java.lang.Iterable",
            new int[]{512,519,-919,53,-14,279,1000,-1000,-1000,559,1000,409,-1000,1000,759,949,1000,1000,-292,48,-296,1000,1000,-634,-232,422,-675,1000,932,-826,-765,870,207,1000,-1000,-234,-174,1000,-1000,-1000,1000,376,-1000,144,856,-486,-560,876,1000,-164,-1000,1000,1000,662,1000,601,1000,-1000,-59,-1000,-358,-108,-434,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00171() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node$SiblingNodeIterable", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "children():java.lang.Iterable",
            new int[]{1000,544,388,519,-457,361,1000,-641,-427,936,1000,309,-1000,-226,-832,1000,1000,-287,269,-31,1000,406,409,-817,-1000,555,-520,721,969,398,1000,-597,-458,-902,-61,709,189,781,120,-321,-537,883,-459,178,-1000,-1000,-563,551,-349,35,-741,523,890,378,-4,966,395,-874,-629,-1000,257,-664,219,684}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00172() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node$SiblingNodeIterable", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "children():java.lang.Iterable",
            new int[]{671,869,477,550,-1000,881,744,-747,-883,-383,208,643,689,-258,829,-959,4,304,1000,906,1000,-780,248,1000,832,-739,1000,-772,1000,669,-565,-113,679,-715,-264,888,586,-1000,1000,-602,296,942,-293,-1000,1000,24,-1000,11,-1000,-1000,-64,667,445,-833,22,-689,-157,-804,-513,951,649,-642,-750,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00173() {
        org.junit.Assert.assertEquals("TYPE:java.util.Collections$EmptySet", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "children():java.lang.Iterable",
            new int[]{237,-11,-323,108,-316,702,476,-280,941,10,-160,-694,-892,804,-35,-176,-1000,239,589,-158,-169,-276,403,-46,851,-735,837,143,1000,213,-1000,48,425,868,-814,-57,323,-154,-769,-461,953,-525,-819,915,-12,371,-1000,594,547,-702,-12,725,-35,-497,-857,-2,643,-406,-275,-108,-180,111,-795,877}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00174() {
        org.junit.Assert.assertEquals("TYPE:java.util.Collections$EmptySet", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "children():java.lang.Iterable",
            new int[]{892,463,99,424,-17,374,-218,391,-409,213,-513,-62,-626,430,-1000,1000,-589,-634,341,-1000,339,320,134,-1000,-594,-626,562,949,-616,182,-480,-807,-886,189,-454,332,50,439,-959,-935,305,-326,-911,1000,1000,-123,213,1000,443,441,-422,-877,118,-332,-1000,111,-508,549,-1000,-107,-226,52,-429,-438}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00175() {
        org.junit.Assert.assertEquals("TYPE:java.util.Collections$EmptySet", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "children():java.lang.Iterable",
            new int[]{69,-496,274,-395,-855,0,-51,-144,561,448,-675,140,-168,83,-726,-91,-381,-174,589,-651,811,-74,229,394,317,-992,1000,-234,-49,1000,-1000,-778,-526,-400,587,1000,-192,-1000,-47,-1000,1000,-798,-497,275,-417,38,-387,622,-266,-1000,272,-678,-1000,-1000,-440,420,400,680,-381,469,312,45,-488,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00176() {
        org.junit.Assert.assertEquals("TYPE:java.util.Collections$EmptySet", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "children():java.lang.Iterable",
            new int[]{682,819,-320,-330,-812,966,928,-780,-334,-189,152,-349,1000,140,921,880,957,-43,1000,-1000,830,80,-534,202,304,-292,234,-463,978,570,1000,-350,506,-399,209,1000,697,671,604,158,-656,1000,-47,561,-711,229,-1000,-213,-324,-601,513,1000,-361,-347,836,1000,1000,-1000,630,676,146,1000,-773,819}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00177() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node$SiblingNodeIterable", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "children():java.lang.Iterable",
            new int[]{-581,529,401,81,-275,-310,-668,-526,1000,988,-129,-1000,-1000,1000,266,-96,-1000,-327,-1000,-926,-1000,1000,-1000,-1000,1000,-1000,-776,1000,-1000,-978,-1000,1000,-287,1000,-1000,-956,612,1000,-1000,-256,1000,167,-1000,828,-842,149,1000,1000,1000,-818,97,1000,-1000,-1000,-1000,-600,-505,-1000,-181,-1000,-1000,997,-1000,-428}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00178() {
        org.junit.Assert.assertEquals("TYPE:java.util.Collections$EmptySet", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "children():java.lang.Iterable",
            new int[]{1000,-441,230,-14,-1000,412,688,710,836,-36,-939,841,774,294,-37,442,-880,-13,1000,98,-113,-739,640,944,304,-891,1000,293,928,-93,-479,-685,683,-1000,-380,-239,35,-569,-36,-908,704,-65,-1000,561,-366,917,-240,-1000,-614,-208,-360,-53,294,-656,-218,-12,1000,25,673,1000,136,490,-866,70}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00179() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node$SiblingNodeIterable", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "children():java.lang.Iterable",
            new int[]{456,-496,356,4,5,52,-517,693,571,-203,-854,-360,-551,616,-1000,-497,-1000,-582,1000,-951,-284,-351,-365,-178,412,-991,20,282,-875,242,-1000,-778,-275,34,103,185,297,-319,-889,-481,513,-798,-1000,1000,-1000,840,342,780,648,-487,362,495,-994,-805,-930,-446,1000,964,-280,-439,-430,240,-717,709}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00180() {
        org.junit.Assert.assertEquals("TYPE:java.util.Collections$EmptySet", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "children():java.lang.Iterable",
            new int[]{-345,754,468,1000,400,1,-1000,172,1000,755,-1000,-1000,-1000,613,-974,-1000,-1000,1000,-107,-1000,-682,-300,-430,-535,226,-1000,-93,325,-1000,-283,-1000,-39,-796,356,-424,-211,227,-240,-1000,-155,673,57,-1000,1000,-699,677,950,1000,872,-558,362,-487,-383,-1000,-1000,-739,-39,1000,-1000,-313,-564,65,-731,858}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00181() {
        org.junit.Assert.assertEquals("TYPE:java.util.Collections$EmptySet", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "children():java.lang.Iterable",
            new int[]{-1000,-551,508,-1000,-754,-417,-586,331,263,1000,-1000,404,-471,-228,776,-1000,-633,101,863,-1000,-302,578,-1000,-969,570,-1000,1000,769,-104,1000,-1000,-1000,-1000,-932,398,152,-806,-149,-10,-1000,-416,-1000,-822,1000,-1000,134,964,1000,624,-1000,678,-1000,-1000,-1000,-871,25,-139,1000,132,436,133,1000,-350,75}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00182() {
        org.junit.Assert.assertEquals("TYPE:java.util.Collections$EmptySet", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "children():java.lang.Iterable",
            new int[]{682,-807,-952,445,-474,-223,-6,937,-273,-130,-1000,435,-1000,1000,-780,-1000,-1000,-814,986,-1000,-659,-771,151,65,357,-1000,376,563,-1000,-383,-1000,-652,-123,65,-1000,-671,139,-720,-1000,-1000,1000,-1000,-1000,561,-700,1000,996,573,-455,-274,718,-877,-1000,-1000,-1000,-1000,-490,374,-542,1000,-1000,-306,-1000,329}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00183() {
        org.junit.Assert.assertEquals("TYPE:java.util.Collections$EmptySet", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "children():java.lang.Iterable",
            new int[]{1000,754,-10,379,447,1000,888,-457,-1000,-234,82,634,-1000,1000,427,-108,-1000,1000,246,-294,665,855,175,134,-603,-273,-1000,-1000,-295,-131,-411,1000,1000,1000,-582,144,1000,-1000,-104,-819,1000,1000,-713,232,-116,311,-1000,861,-355,-263,181,1000,795,-1000,-840,131,741,-1000,-1000,-290,-270,241,-880,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00184() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "cloneNode():com.google.javascript.rhino.Node",
            new int[]{793,919,-456,496,1000,941,326,276,-1000,-250,322,-816,1000,-352,561,-51,-234,-1000,-1000,-645,-89,-183,-697,-698,103,949,1000,-1000,-481,-336,631,1000,-985,352,900,156,1000,669,-417,-763,399,407,1000,-54,430,-865,-868,-1000,-1000,1000,312,447,614,-1000,-1000,-310,-808,497,-1000,1000,1000,-649,599,515}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00185() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "cloneNode():com.google.javascript.rhino.Node",
            new int[]{250,-491,250,-254,-1000,1000,-477,-21,-191,605,607,1000,-223,380,-50,421,-1000,1000,840,1000,-51,1000,-1000,1000,-736,-618,-1000,1000,-1000,-1000,-202,-663,199,-14,-1000,-285,-1000,932,397,413,-607,-871,580,-1000,-104,-908,194,1000,446,-255,-854,-53,-805,1000,-1000,-754,1000,-818,1000,143,77,201,-130,-888}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00186() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "cloneNode():com.google.javascript.rhino.Node",
            new int[]{953,-501,-404,-108,-545,-208,629,1000,321,582,-1000,618,-52,1000,-90,535,-1000,920,-620,348,-322,-112,-135,54,628,132,306,457,-341,-141,-157,-245,597,-13,656,399,-34,138,-608,1000,400,1000,1000,-396,124,-1000,478,-773,-809,1000,-792,-61,-269,339,376,-906,89,-118,-319,477,462,-338,296,-252}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00187() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "cloneNode():com.google.javascript.rhino.Node",
            new int[]{-228,629,-437,-1000,-1000,-161,87,401,893,-281,-17,-313,859,629,218,-242,-94,571,345,-291,-796,-405,-659,663,499,-381,-429,1000,-266,-851,-253,656,35,459,-341,-111,247,821,438,203,-234,336,-349,-400,-194,366,15,489,-125,-980,-509,-565,-641,605,-565,-8,660,232,-1000,-739,-126,631,-500,-650}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00188() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "cloneNode():com.google.javascript.rhino.Node",
            new int[]{1000,569,945,1000,-993,149,1000,-187,604,1000,-485,1000,-466,1000,372,429,434,554,1000,908,-412,-483,-466,226,1000,499,-363,1000,-1000,-258,631,-127,303,-120,312,-509,1000,-9,-304,806,-52,366,929,-873,-442,-102,127,347,559,387,-71,-126,-382,1000,-250,-308,432,387,1000,-407,-73,-426,-651,-306}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00189() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "cloneNode():com.google.javascript.rhino.Node",
            new int[]{1000,94,-417,1000,-100,-311,-598,-94,604,731,-28,908,-1000,1000,510,-1000,1000,554,15,436,-506,-483,622,-77,1000,809,36,1000,-981,-291,631,13,-534,512,331,-509,1000,-9,688,342,245,1000,929,-815,-1000,168,916,-78,-400,-1000,193,-681,-299,1000,900,-223,125,850,754,272,567,777,-42,404}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00190() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "cloneNode():com.google.javascript.rhino.Node",
            new int[]{1000,689,736,666,-234,-322,585,1000,1000,274,588,1000,799,279,882,491,-94,1000,-882,84,-824,355,53,838,923,-449,-1000,1000,-1000,-396,-485,502,819,-959,773,1000,370,862,-1000,787,661,1000,-700,-393,1000,-1000,926,259,-157,-1000,-64,-117,-762,1000,229,-77,305,-1000,1000,-11,-260,-844,-610,-946}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00191() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "cloneNode():com.google.javascript.rhino.Node",
            new int[]{692,-536,1000,130,-611,1000,-306,-1000,-539,635,401,1000,-596,380,-197,1000,-1000,973,375,1000,-421,390,-965,447,-1000,375,-1000,1000,-1000,-399,603,-564,-438,542,-205,-1000,911,466,-169,-63,594,-1000,1000,-353,-41,-559,-71,1000,-676,151,-397,-272,-1000,681,-975,-132,1000,-218,1000,1000,603,357,-1000,-208}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00192() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "cloneNode():com.google.javascript.rhino.Node",
            new int[]{-471,9,724,-285,-640,-488,349,512,1000,984,-1000,1000,-1000,1000,-150,131,-192,1000,1000,1000,-362,-349,236,-444,-524,667,-1000,563,-1000,-801,564,-1000,-652,-310,-932,-319,-1000,-625,-495,797,-1000,1000,347,-1000,616,1000,20,1000,959,-1000,708,-1000,739,1000,1000,210,134,1000,1000,-29,425,745,-617,680}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00193() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "cloneNode():com.google.javascript.rhino.Node",
            new int[]{-221,-501,-307,496,908,334,-22,68,-1000,-516,504,-816,1000,314,767,-51,-1000,-1000,-1000,-645,-322,230,-1000,-270,628,949,-400,-659,-1000,-336,631,1000,-785,383,-500,642,854,1000,63,-46,399,160,1000,-456,430,-1000,-574,-323,-1000,1000,-336,829,170,-1000,-1000,-310,89,-582,-868,477,1000,-805,599,-350}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00194() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "cloneNode():com.google.javascript.rhino.Node",
            new int[]{-187,364,1000,-975,-1000,133,251,210,1000,833,-457,1000,-1000,1000,-778,-926,-931,1000,1000,1000,-522,490,-709,1000,257,-900,-1000,1000,149,-1000,-640,-1000,300,-509,-1000,872,191,686,-120,1000,-1000,740,-790,-1000,-1000,-562,802,-573,1000,-1000,-675,-453,-178,1000,443,-438,1000,-31,1000,-1000,-452,1000,-1000,-495}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00195() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "cloneNode():com.google.javascript.rhino.Node",
            new int[]{572,874,637,-975,-865,-1000,261,1000,1000,54,423,87,-729,814,-77,-1000,1000,1000,1000,826,-55,646,597,776,1000,-1000,-9,1000,-1000,-849,-1000,-980,635,-1000,-547,528,-1000,313,-83,1000,-1000,1000,-1000,-371,-1000,-679,1000,1000,1000,-1000,565,-1000,1000,1000,507,-1000,732,-294,-179,-1000,-333,1000,-902,91}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00196() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "cloneNode():com.google.javascript.rhino.Node",
            new int[]{-55,-216,-196,-1000,238,-1000,846,-412,-539,506,-1000,263,-1000,1000,-565,-986,122,128,1000,429,-1000,-493,622,-591,60,112,232,5,1000,-1000,-11,-1000,-803,634,-1000,872,-1000,738,-436,613,-1000,701,-1000,-1000,-1000,269,257,-973,217,-1000,-131,-1000,918,1000,311,719,732,1000,178,-663,679,1000,130,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00197() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "cloneNode():com.google.javascript.rhino.Node",
            new int[]{953,894,598,979,812,-208,-113,443,321,-707,1000,-724,1000,-352,520,-328,1000,-567,-322,-378,341,-76,313,-930,-20,460,668,-659,-1000,-783,2,752,-1000,172,-70,-56,465,385,-1000,-1000,-129,407,848,-457,778,-1000,-1000,400,-421,177,1000,-226,1000,-1000,-1000,-740,-388,1000,-854,477,462,422,-359,274}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00198() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "cloneNode():com.google.javascript.rhino.Node",
            new int[]{847,358,-636,639,1000,1000,289,-858,-1000,-496,1000,-157,1000,49,410,1000,373,-1000,-1000,-456,-177,-172,178,-679,-1000,1000,-684,-368,-174,-1000,622,914,-1000,845,1000,-192,-1000,374,-1000,-865,1000,-857,-1000,1000,455,-1000,-527,-486,-1000,1000,1000,-337,32,-1000,-1000,-396,-884,102,-515,1000,-628,191,701,245}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00199() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "cloneNode():com.google.javascript.rhino.Node",
            new int[]{1000,-217,-719,949,-152,559,4,-538,434,937,-857,869,-251,1000,472,1000,-1000,363,-407,444,-1000,-4,-1000,334,581,1000,-935,1000,-973,59,1000,-16,84,508,942,-481,1000,138,141,784,870,1000,1000,29,-238,-525,632,-540,-1000,981,-1000,154,-904,813,337,-56,132,-147,561,817,1000,-912,368,-196}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00200() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalStateException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "clonePropsFrom(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{-317,4,-181,-250,-716,893,-226,406,20,921,-89,-521,-14,-958,-1000,437,-542,-800,1000,-168,715,80,734,1000,-1000,-106,13,639,608,-265,468,20,1000,-391,740,-320,69,611,481,81,-53,39,23,8,358,-840,-443,-20,674,135,-31,1000,754,1000,576,645,-134,203,1000,-472,-180,-839,1000,-670}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00201() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalStateException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "clonePropsFrom(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{952,159,-588,823,96,-1000,-345,-506,400,-444,-1000,-315,-400,-664,699,-400,1000,-676,-157,517,-388,-1000,-1000,-498,480,1000,-807,-119,-257,-953,1000,400,324,-930,-5,-1000,-808,551,-564,-432,1000,-393,-63,302,-182,426,32,-400,1000,-713,-11,117,405,-126,794,4,-510,171,1000,856,400,826,-1000,277}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00202() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "clonePropsFrom(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{-591,-436,562,-9,-747,695,-812,926,-1000,1000,167,-643,800,-652,-798,589,-1000,200,400,141,326,1000,-49,1000,-40,-157,472,83,469,1000,394,-319,621,-266,386,279,268,-7,1000,1000,-1000,983,-945,404,958,-230,-899,434,-544,-273,59,633,271,1000,148,-1000,1000,-754,-357,-1000,-582,-364,1000,-270}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00203() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalStateException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "clonePropsFrom(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{1000,-776,-475,730,-182,397,-1000,181,-865,-840,-165,113,-489,68,-1000,-700,-397,350,569,-616,1000,-321,27,-207,-836,868,896,399,5,677,-718,1000,433,547,-221,127,-873,999,-702,715,746,708,-827,-551,-666,174,-27,-1000,322,-1000,246,185,-727,362,-786,-704,-393,651,576,-302,640,91,-590,-778}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00204() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "clonePropsFrom(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{-878,109,-137,-59,-713,-508,396,-717,589,327,350,-1000,1000,-1000,330,857,114,-552,726,-1000,744,-763,-869,424,-179,-343,119,-698,1000,-459,1000,-400,1000,-157,814,-1000,-418,1000,-542,-1000,-151,471,395,-590,-954,-1000,-1000,272,1000,802,224,1000,1000,-223,1000,-1000,-75,-486,977,385,-858,719,-879,-287}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00205() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalStateException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "clonePropsFrom(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{483,-106,-713,-567,-1000,485,-194,-122,-470,-228,345,-183,430,-691,-939,-111,176,-995,893,-1000,-812,379,697,250,-990,-53,-98,860,139,193,372,-734,1000,180,-23,326,-631,1000,303,1000,911,746,709,-458,166,-324,-580,-10,352,-619,-533,966,529,406,-351,383,-286,1000,-163,80,-1000,-1000,706,-361}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00206() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "clonePropsFrom(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{-1000,14,573,574,-990,-140,-524,101,-195,-288,134,-212,106,-729,284,301,-612,411,885,-238,-438,272,-155,105,-856,-210,390,-412,1000,864,587,-319,850,236,246,-315,246,734,133,307,-336,993,222,85,126,-540,-158,-398,674,-121,404,332,106,-47,4,-388,-8,-674,1000,203,-440,-396,23,-721}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00207() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalStateException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "clonePropsFrom(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{-1000,-171,858,-25,-1000,1000,-246,654,-195,972,787,-707,-83,-729,208,589,-1000,761,1000,-1000,720,1000,-379,1000,-26,-967,1000,-435,1000,1000,921,-319,648,-930,386,-1000,1000,551,838,584,-931,993,316,91,-182,-662,-899,-159,-373,-713,380,560,354,140,585,4,1000,-921,691,-679,-582,535,1000,-721}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00208() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalStateException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "clonePropsFrom(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{-1000,-556,293,242,-1000,507,639,-165,-1000,286,929,-999,811,-1000,900,1000,-1000,383,429,-608,447,585,-1000,119,814,-1000,943,-1000,1000,1000,1000,-1000,798,-682,1000,-1000,655,570,-295,-156,-1000,1000,-273,-993,-935,-1000,-1000,817,-46,849,34,439,568,-501,827,-1000,951,46,7,117,-1000,400,544,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00209() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalStateException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "clonePropsFrom(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{1000,-346,-747,1000,-1000,-192,-194,285,-470,-548,-1000,-344,541,-1000,-1000,-556,207,-845,106,-632,-812,-1000,697,623,721,1000,-1000,1000,-392,-828,606,773,1000,-1000,570,-1000,-980,-348,-984,1000,751,-554,-761,468,-109,-786,-307,-1000,1000,-765,228,826,-1000,680,1000,383,-112,373,784,1000,926,-111,-1000,-394}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00210() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalStateException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "clonePropsFrom(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{1000,-36,-1000,145,566,-100,-1000,583,1000,63,-1000,42,-1000,-444,-1000,-1000,794,-1000,1000,-1000,1000,-1000,-1000,1000,-1000,1000,-593,1000,-1000,-1000,1000,1000,1000,-356,-436,-475,-1000,1000,250,-184,1000,-1000,988,1000,1000,44,475,-1000,674,-1000,-531,1000,217,1000,427,1000,-1000,409,1000,141,1000,699,-548,824}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00211() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalStateException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "clonePropsFrom(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{1000,-631,-108,148,-1000,937,1000,-920,-1000,-291,711,-846,1000,-856,-479,1000,-715,-795,830,-600,-281,555,-1000,-917,-312,-1000,-144,-544,1000,1000,1000,-1000,978,-356,1000,-475,-263,842,-459,-145,-567,1000,-188,-1000,1000,-914,-1000,1000,534,451,-1000,852,215,-188,834,-464,1000,409,-343,580,1000,-1000,547,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00212() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "clonePropsFrom(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{461,193,-517,339,51,-376,-752,138,1000,248,-1000,-87,-796,-777,-1000,-543,722,-810,568,-1000,337,-1000,503,1000,-1000,1000,-469,702,-129,-1000,468,1000,932,-594,36,-747,-457,1000,-55,-259,1000,-929,225,695,348,-94,-10,-1000,1000,-493,288,798,640,828,627,952,-919,150,1000,141,800,439,-163,224}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00213() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "clonePropsFrom(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{767,64,655,661,-141,-531,329,780,318,589,475,-1000,1000,-681,275,400,-921,-162,-1000,1000,-199,-1000,-400,-400,983,163,-770,224,524,-493,155,-400,323,-1000,414,-318,-252,417,-231,248,-400,400,-1000,-400,-400,-162,-400,809,-264,-79,785,607,756,170,444,-1000,46,442,528,-166,-760,-498,141,-361}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00214() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalStateException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "clonePropsFrom(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{668,-596,-261,452,-630,-599,525,-438,-1000,-214,504,-1000,975,-1000,689,1000,-284,198,-647,789,-178,-818,-1000,-1000,891,-196,200,-1000,330,817,247,-1000,182,-589,1000,-884,-53,168,-759,-440,-1000,1000,-946,-1000,-1000,-899,-1000,1000,-400,315,-274,-153,651,-186,257,-1000,469,1000,-610,208,-1000,-283,-288,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00215() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalStateException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "clonePropsFrom(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{-557,-46,546,70,-638,629,-740,731,150,765,302,-583,-302,-613,-299,413,-1000,738,356,58,211,1000,-113,578,-310,-149,587,-193,532,864,134,-27,-32,-28,123,33,894,-212,859,616,-902,990,-103,549,609,-416,-856,-395,-866,-210,221,20,346,729,-88,-126,565,-382,367,-930,-402,-91,1000,-601}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00216() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "cloneTree():com.google.javascript.rhino.Node",
            new int[]{35,-177,-658,-466,-173,113,157,142,-433,105,-527,917,214,-976,-399,464,-249,871,169,-726,273,105,-191,-852,-451,-191,-940,-955,477,-691,411,961,220,-480,747,-949,-311,672,442,823,-445,465,-191,976,937,-788,-296,162,-410,57,694,855,-496,987,408,337,-408,-985,-586,806,-597,-342,301,625}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00217() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "cloneTree():com.google.javascript.rhino.Node",
            new int[]{-527,-296,635,763,-510,890,967,636,110,931,189,-785,805,-690,-142,614,1000,-1000,769,-59,776,-306,365,116,282,-79,213,598,-763,681,558,-647,-770,105,67,336,426,437,-57,-1000,87,35,237,-993,-864,414,532,-1000,534,-1000,-1000,-567,205,-1000,460,-413,375,-935,1000,301,-171,364,-148,-336}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00218() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "cloneTree():com.google.javascript.rhino.Node",
            new int[]{1000,674,111,-234,873,-804,-41,910,-726,105,444,-400,367,726,-178,1000,-144,-210,169,-143,-485,643,1000,400,-1000,-417,460,400,100,335,793,475,497,920,-926,-239,129,602,673,1000,411,1000,1000,283,1000,-234,-885,162,-287,-595,-1000,-178,-496,1000,1000,-1000,-3,-1000,-409,572,-4,71,-43,-598}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00219() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "cloneTree():com.google.javascript.rhino.Node",
            new int[]{-168,619,-803,633,-1000,1000,-1000,1000,-373,713,-106,-452,1000,-140,663,1000,-464,-124,-1000,-381,-848,1000,1000,1000,-530,958,-162,285,-586,220,1000,572,-1000,497,373,-1000,556,574,1000,-179,22,767,-398,465,1000,-147,-516,-619,989,-19,-962,30,-495,846,314,-1000,1000,-363,-1000,-1000,-951,-191,289,-661}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00220() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "cloneTree():com.google.javascript.rhino.Node",
            new int[]{-1000,-421,-717,-537,-25,760,-378,-1000,-1000,83,-928,-4,-472,-1000,-581,-155,-824,-343,-30,-1000,-816,1000,-585,-1000,-1000,1000,-1000,-1000,-169,-1000,349,1000,-885,133,1000,-1000,592,993,-165,-1000,-1000,-1000,1000,-67,1000,-810,-851,-898,120,885,-669,1000,-1000,87,567,105,489,-1000,-317,-763,-1000,-1000,1000,263}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00221() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "cloneTree():com.google.javascript.rhino.Node",
            new int[]{603,559,-735,-633,-294,-705,-104,43,-12,-48,-511,1000,63,-245,-449,456,-968,1000,-497,-644,327,-259,-632,-568,-262,-603,-778,-1000,488,283,447,935,500,-477,1000,-949,-187,685,497,1000,-124,546,1000,-1000,1000,-788,-148,1000,-404,-41,916,876,-459,1000,237,143,-539,-32,-1000,1000,-415,-257,36,557}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00222() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "cloneTree():com.google.javascript.rhino.Node",
            new int[]{587,244,-393,-63,326,-228,553,10,197,73,66,-1000,-108,-216,-110,755,468,-79,-481,-535,364,-324,-285,-287,-1000,141,480,792,-99,-531,191,-189,-418,981,805,-658,-174,1000,-326,-1000,-324,513,365,-132,380,-997,-980,-1000,153,-1000,-664,442,-360,-420,1000,-790,-1000,-884,1000,-130,391,-331,-232,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00223() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "cloneTree():com.google.javascript.rhino.Node",
            new int[]{-1000,-291,478,179,-159,1000,-281,-635,-212,737,-342,-23,321,-1000,88,-625,1000,-1000,-503,-1000,125,317,378,-178,-1000,1000,-802,-40,-852,136,405,-404,-1000,-683,111,-1000,-48,789,55,-1000,-1000,-1000,1000,-1000,-411,820,81,-1000,-763,267,-1000,-158,-1000,-1000,-516,-73,1000,-846,698,-1000,-1000,-852,1000,-69}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00224() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "cloneTree():com.google.javascript.rhino.Node",
            new int[]{-375,84,66,-25,-1000,-443,-382,-742,-401,-117,78,879,-540,-1000,-1000,-295,165,540,917,-1000,-958,494,89,-1000,-175,-417,-452,-703,-52,-260,434,-457,-538,-606,-127,543,-555,1000,244,660,-1000,-138,546,399,-632,352,14,415,-920,-189,-23,1000,-553,-424,238,315,256,-346,-1000,436,-782,-259,735,-108}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00225() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "cloneTree():com.google.javascript.rhino.Node",
            new int[]{-1000,559,932,981,79,852,314,-528,197,791,-643,-205,-393,-1000,-449,-588,-1000,-193,774,-1000,-608,844,-98,-1000,-1000,534,-778,-91,-545,283,813,-672,-1000,163,-577,-425,-244,868,-421,-1000,-1000,-1000,1000,-1000,-723,-1000,-79,32,-497,-440,-316,31,-517,-1000,-337,648,706,-855,1000,566,717,628,-330,369}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00226() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "cloneTree():com.google.javascript.rhino.Node",
            new int[]{-410,337,881,425,-612,902,324,-98,-297,590,-837,836,782,558,-94,-372,-774,-119,431,-153,923,-48,453,5,862,420,-814,896,-628,783,230,-791,707,-973,-901,-228,766,-923,-269,370,236,253,832,825,-526,391,977,-224,19,-125,990,420,821,390,-642,394,962,-86,-858,896,935,203,-805,204}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00227() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "cloneTree():com.google.javascript.rhino.Node",
            new int[]{-1000,264,-1000,852,967,1000,535,-877,-1000,855,-825,-1000,-694,-1000,-258,131,-1000,-1000,597,-1000,-681,1000,1000,-1000,862,760,-892,905,339,-1000,454,875,-1000,1000,-671,-1000,-1000,1000,-79,-1000,-1000,-780,1000,-1000,627,-1000,-1000,-1000,103,141,-1000,369,-1000,-840,92,-124,-832,-1000,1000,-809,575,1000,-1000,840}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00228() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "cloneTree():com.google.javascript.rhino.Node",
            new int[]{906,-922,-991,-1000,-363,-638,-216,696,-925,-718,382,47,-178,-115,-534,1000,-1000,1000,5,-324,-308,-115,-92,-1000,524,-955,-561,-1000,711,-1000,292,1000,1000,-662,1000,-949,-762,847,249,1000,162,1000,-858,1000,1000,-684,-493,240,-428,-959,554,1000,100,1000,1000,-935,-543,789,-1000,779,-548,-535,-395,245}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00229() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "cloneTree():com.google.javascript.rhino.Node",
            new int[]{1000,149,-1000,-1000,-421,-233,-131,950,-353,-673,-281,556,-156,647,150,868,-941,129,-590,81,-68,239,359,-324,109,414,-1000,-19,382,-790,507,588,148,-74,79,-1000,-425,353,-747,832,128,1000,-604,746,868,422,-426,1000,-145,-785,1000,1000,138,1000,763,312,-99,-559,-1000,-157,-946,-851,-382,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00230() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "cloneTree():com.google.javascript.rhino.Node",
            new int[]{399,-532,331,-1000,-575,-767,-620,-477,-1000,-791,54,1000,-975,-188,-155,326,525,1000,-46,-1000,-449,263,-191,-1000,-1000,-38,-817,-1000,755,-1000,204,1000,1000,-180,-7,-1000,-1000,1000,111,760,-638,481,-600,1000,1000,-676,-824,903,-1000,33,935,1000,-474,970,1000,-264,261,-1000,-1000,657,-1000,-1000,1000,199}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00231() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "cloneTree():com.google.javascript.rhino.Node",
            new int[]{-1000,-992,-266,-583,420,1000,328,-780,-1000,311,-393,921,104,-1000,-492,-565,1000,-1000,-444,-1000,426,704,218,-1000,-764,1000,-940,-1000,183,-965,326,969,-642,-342,189,-1000,-965,559,19,-1000,-1000,465,1000,230,425,-888,-581,-1000,-368,637,-161,627,-1000,-266,26,863,330,-836,437,-168,-1000,-1000,1000,782}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00232() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "copyInformationFrom(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{-250,-431,462,-57,-926,-164,-78,131,-630,-124,-461,-604,-526,-386,-190,-847,380,699,-123,270,-450,404,-920,-79,348,-5,-1000,682,-900,-125,-314,-1000,284,737,-271,415,-927,27,49,-1000,-259,232,-209,675,-1000,-246,427,387,197,-202,369,1000,-1000,-200,1000,345,-2,654,800,848,-769,-433,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00233() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "copyInformationFrom(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{421,-911,251,127,559,-254,-197,534,168,658,-735,896,713,-1000,-759,-1000,122,1000,370,998,888,1000,-1000,467,800,158,-1000,-198,-109,-1000,-1000,956,474,381,-390,-805,-163,-613,-246,-202,-540,272,-1000,264,1000,1000,8,516,1000,85,195,863,282,525,321,-447,-849,-163,940,128,94,260,379,666}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00234() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "copyInformationFrom(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{-1000,-466,215,935,607,-706,-755,39,-256,533,-738,-1000,-2,-199,51,-234,916,-39,-696,1000,725,1000,-1000,108,-139,-980,-5,-274,509,-596,240,-438,759,637,-84,310,3,446,452,-206,-1000,1000,-702,-474,1000,-879,1000,-111,832,-1000,950,-1000,-230,401,260,385,-1000,728,1000,1000,754,520,-125,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00235() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "copyInformationFrom(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{424,-286,507,-522,-723,-473,148,644,-438,-1000,272,106,-600,561,-228,110,-726,-232,44,170,70,-550,-733,552,-323,273,1000,353,-1000,-707,754,346,451,221,420,-310,-12,12,553,326,-98,1000,656,-83,-359,-195,225,-619,-22,522,872,-964,1000,729,100,578,272,659,-173,379,-535,-114,-8,348}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00236() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "copyInformationFrom(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{-132,-916,807,-791,249,335,-459,1000,-1000,1000,-1000,22,294,589,-549,-362,908,-68,-396,1000,796,1000,-1000,-422,627,-844,346,196,129,-831,197,1000,-593,133,-491,-361,-1000,-653,258,-1000,-1000,1000,-1000,-789,1000,802,1000,718,1000,262,-478,-1000,-217,566,1000,-510,-1000,-887,-174,1000,759,1000,-25,325}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00237() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "copyInformationFrom(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{179,219,-658,30,-69,-936,592,43,40,-557,1000,-140,-567,94,-73,-284,126,428,709,-665,-1000,-840,1000,-665,-337,-68,323,-48,21,515,-156,-787,1000,575,622,132,657,301,714,-235,120,-243,520,1000,-48,-194,-212,-887,-442,-300,972,857,-956,920,557,129,956,-654,1000,-304,-873,-1000,168,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00238() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "copyInformationFrom(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{-1000,834,-134,-60,-773,-1000,1000,-1000,-268,-1000,1000,-86,973,1000,-42,395,-1000,-1000,776,717,1000,-1000,-549,-1000,-372,-606,1000,-995,-1000,-31,1000,-1000,-353,76,595,-161,-793,-149,649,-755,-355,554,594,-1000,300,-1000,78,-633,-927,-759,-931,1000,115,1000,1000,-984,-102,410,-552,1000,1000,-1000,1000,587}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00239() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "copyInformationFrom(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{71,-976,525,-787,-169,209,500,46,-474,807,-738,911,1000,-82,-274,-505,478,661,263,700,1000,1000,-895,-282,975,-46,-727,468,288,-1000,-1000,1000,-73,-1000,626,-47,-468,-921,-742,-1000,-468,-392,-1000,-117,-201,781,993,1000,-155,66,-444,596,-734,-521,1000,-655,-938,-913,850,495,669,1000,820,624}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00240() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "copyInformationFrom(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{-1000,-226,1000,736,-496,-926,169,-213,-366,608,57,-969,512,707,1000,-730,-1000,-435,-782,978,1000,-869,-1000,-344,66,-637,-45,-779,391,438,-404,-730,-302,1000,326,937,-1000,-191,-524,-1000,-87,712,-331,-1000,662,-1000,-621,493,311,-1000,-268,143,-1000,-1000,897,-190,-1000,345,212,1000,1000,1000,470,708}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00241() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "copyInformationFrom(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{-324,527,-177,-536,-4,-865,-1000,-202,-18,557,-439,356,1000,-244,656,622,-126,645,323,355,1000,-239,-664,-427,455,-1000,490,-123,-400,-634,174,464,-956,-899,831,609,111,-195,36,289,-1000,-512,-877,-1000,48,-585,-412,271,-74,-723,-744,-284,-91,-213,166,-785,-150,64,903,1000,966,-363,671,-763}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00242() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "copyInformationFrom(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{-3,-141,-256,-835,-1000,1000,845,-540,463,-17,945,134,1000,-1000,464,-398,-1000,1000,187,582,1000,287,-767,-427,-158,-978,161,585,-1000,1000,-810,172,-6,338,199,1000,-56,33,-551,-15,-470,-1000,464,-411,-1000,-981,41,859,-1000,260,312,-1000,-1000,-1000,-312,-462,970,421,-187,526,1000,108,-48,179}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00243() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "copyInformationFrom(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{-1000,-736,890,1000,358,-664,-789,432,-579,-254,-1000,975,-738,-709,-214,-588,1000,417,-789,1000,-290,1000,-1000,-19,-595,-844,-1000,244,239,-831,-627,-1000,1000,1000,-769,692,-737,1000,69,-1000,-678,379,-531,699,397,-1000,1000,206,914,-1000,1000,63,-1000,566,844,971,-81,1000,1000,894,-301,-483,-25,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00244() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "copyInformationFrom(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{-1000,253,-879,537,-75,-1000,-1000,-215,95,122,-638,790,-16,-41,343,284,438,-214,-210,914,476,-239,-851,-313,-662,-1000,-305,-652,468,-869,-475,-648,444,501,-2,370,-397,636,-265,-853,-879,454,260,1000,578,-1000,1000,-52,-1000,-1000,-17,-256,-439,-19,730,164,771,410,1000,1000,89,-38,-949,589}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00245() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "copyInformationFrom(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{1000,-936,-714,-239,145,359,-338,-501,-17,-340,-460,363,229,-626,-70,-254,1000,1000,154,148,39,1000,176,740,438,-456,-1000,695,-879,-1000,-723,617,581,-1000,711,-217,638,-353,-40,177,-399,-757,-878,778,-890,1000,1000,500,-870,-84,240,560,-474,165,268,-114,-181,-308,1000,-539,-183,-400,529,632}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00246() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "copyInformationFrom(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{-1000,58,915,226,578,-773,128,-483,-580,296,-754,75,311,691,269,146,492,-933,-16,650,347,160,-767,-761,-700,-1000,291,-36,-547,-545,91,-1000,226,834,-312,425,-890,555,291,-885,-696,687,-574,-400,890,-808,1000,-247,600,-749,-30,63,-651,143,920,-201,-194,-123,-340,894,610,555,444,754}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00247() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "copyInformationFrom(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{-597,-416,225,85,567,-747,-862,678,-416,-1000,-572,709,1000,-709,-274,-465,1000,99,-395,181,-1000,994,213,128,-1000,-112,-1000,-390,239,115,-1000,-1000,1000,1000,-1000,692,-92,-500,617,-742,-241,393,-379,1000,-8,-1000,355,-507,395,-857,1000,397,-888,1000,1000,1000,194,1000,1000,-33,-1000,-1000,168,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00248() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "copyInformationFromForTree(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{-300,814,567,-1000,-280,-1000,700,-1000,762,-1000,1000,696,1000,1000,-605,-866,-1000,-1000,902,-396,-793,939,-1000,-10,-1000,1000,-851,-54,-10,-205,-307,503,1000,-336,-911,226,-3,5,-857,-1000,1000,-1000,824,336,-1000,127,-35,458,1000,927,-1000,-1000,1000,1000,-951,1000,1000,-309,-42,1000,-1000,198,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00249() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "copyInformationFromForTree(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{-2,254,71,-640,1000,-65,3,-851,-7,-582,-378,1000,438,-619,92,-791,-107,-497,-781,87,-729,810,-446,-742,-141,695,-34,-637,-1000,-1000,-429,786,657,199,-358,217,-727,-593,-358,-911,618,-227,796,602,-609,539,-469,936,970,422,-963,-44,413,678,-219,1000,-103,-2,-928,749,-1000,-579,776,277}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00250() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "copyInformationFromForTree(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{1000,174,29,1000,86,-375,-992,161,-483,268,197,824,-410,877,697,36,1000,1000,198,-233,612,-1000,1000,-284,1000,-978,1000,1000,803,-920,-226,230,-1000,-1000,-550,-366,-221,-156,1000,674,1000,960,-225,1000,1000,-553,-635,496,-386,-1000,-1000,524,-295,-419,705,1000,-15,586,-207,140,1000,702,1000,321}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00251() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "copyInformationFromForTree(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{541,449,-393,376,-201,613,-939,114,-239,409,438,-366,780,714,92,1000,1000,-115,-799,-169,1000,623,1000,-704,449,-1000,1000,857,-474,-1000,-395,17,-1000,652,-1000,57,401,936,624,324,-488,1000,-527,1000,1000,-1000,-194,-557,-1000,-830,-259,-16,-1000,-1000,1000,-382,1000,1000,-695,568,929,693,-892,-359}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00252() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "copyInformationFromForTree(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{105,-502,-207,-432,158,-59,-1000,-1000,889,591,-101,1000,-303,-827,379,63,41,-462,1000,-1000,1000,1000,565,-1000,-255,-456,419,-241,-464,-1000,-1000,1000,173,951,594,1000,1000,380,-564,-350,-677,-616,1000,610,362,1000,1000,68,72,744,-1000,-1000,34,834,426,-94,168,-50,-1000,-159,-1000,-525,-351,-656}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00253() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "copyInformationFromForTree(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{20,828,97,-1000,1000,-89,327,-804,442,-1000,-200,1000,256,-1000,-1000,-1000,-1000,-1000,-1000,-58,-757,1000,-1000,-1000,-1000,1000,-405,-1000,-267,-941,-588,1000,923,310,300,315,-311,-385,-1000,-1000,855,-322,899,181,-1000,1000,-209,903,1000,1000,-1000,-426,452,782,-319,643,-446,-531,-1000,1000,-1000,-1000,1000,928}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00254() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "copyInformationFromForTree(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{-1000,-156,413,-1000,-543,-1000,-64,110,493,495,1000,-400,665,736,-436,443,-189,-337,640,-132,832,912,-488,-489,-1000,1000,94,60,28,-374,-1000,-464,18,1000,-836,910,1000,-809,-359,-855,-201,88,900,299,-222,-196,473,122,534,40,-1000,-842,860,472,-1000,163,468,264,-832,792,899,120,1000,553}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00255() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "copyInformationFromForTree(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{111,-416,430,-1000,650,-600,-175,-1000,1000,-1000,635,1000,965,-292,-1000,142,-1000,-1000,340,-1000,-169,1000,-839,4,-1000,931,-400,-1000,-964,-841,-836,1000,845,345,287,1000,1000,-1000,-1000,-1000,470,-1000,1000,589,-98,1000,352,-46,1000,1000,-1000,-1000,1000,1000,635,539,188,-861,-864,697,-1000,-239,1000,634}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00256() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "copyInformationFromForTree(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{-580,78,668,714,1000,1000,463,-210,621,62,-610,734,766,-239,-824,-23,44,62,799,757,-170,689,-1000,-1000,673,-969,768,728,-906,-908,-1000,608,758,1000,1000,988,644,1000,-650,769,-1000,-1000,147,674,-1000,1000,-392,99,-826,506,232,-374,72,-283,849,-1000,853,-51,-950,-85,-1000,-1000,-1000,456}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00257() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "copyInformationFromForTree(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{765,454,-248,33,-44,-456,-271,60,475,658,197,-1000,22,-36,-599,-1000,46,-140,200,-353,677,-1000,-911,-1000,242,50,50,6,1000,-787,-1000,1000,532,-18,506,919,428,-23,-317,-350,-1000,-1000,621,-239,-946,626,283,569,877,-99,-313,-406,34,-50,-1000,-94,168,-74,-563,876,901,-1000,-383,-195}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00258() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "copyInformationFromForTree(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{1000,579,554,-1000,-493,-1000,-634,-1000,560,-1000,738,670,902,242,-355,-134,-1000,-668,1000,16,-117,379,-618,285,-638,1000,-1000,359,1000,201,-397,-8,916,-990,239,289,-3,-949,-307,-1000,1000,-1000,366,503,-754,-52,293,574,959,-102,-433,-615,1000,1000,-955,400,-39,194,-855,1000,-126,-85,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00259() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "copyInformationFromForTree(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{646,-106,29,-357,595,-885,3,136,876,298,208,267,1000,1000,-767,-712,-395,526,-800,923,421,996,-837,-219,-255,138,-1000,-1000,-314,-570,-515,103,647,256,-193,502,1000,559,-698,1,1000,-835,541,540,-528,731,-498,-53,-258,86,-509,-1000,1000,812,307,117,780,514,-412,160,-578,-585,-118,721}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00260() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "copyInformationFromForTree(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{628,789,756,30,245,344,140,-254,-300,250,173,-556,542,299,-247,474,-387,229,-600,978,-397,-291,422,784,97,821,-832,-192,-216,613,747,-313,428,-244,-293,-662,41,-691,419,683,773,-805,-870,870,1,-907,-979,-27,-729,-853,966,387,893,157,171,-98,221,709,359,798,971,98,780,203}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00261() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "copyInformationFromForTree(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{-1000,509,-98,1000,435,810,-31,-549,190,875,339,697,707,-21,-627,399,-839,-1000,-400,109,-995,800,-1000,-1000,-450,176,-1000,-625,68,-471,-1000,89,-135,1000,259,887,-181,215,640,225,-1000,-1000,385,132,-493,184,-432,-12,344,571,-155,-100,603,333,658,-400,692,-518,-977,675,-998,-127,54,719}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00262() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "copyInformationFromForTree(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{242,-172,-57,-1000,621,-1000,-425,5,963,217,208,1000,601,1000,-886,-712,245,859,-498,-313,976,754,-371,-434,225,1000,158,-186,348,-1000,-767,606,-219,83,-193,604,1000,274,-985,-145,1000,-673,876,691,-997,731,104,-64,191,189,-752,-1000,1000,497,-1000,117,932,254,-474,38,-529,-275,-351,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00263() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "copyInformationFromForTree(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{851,358,845,37,160,-982,-556,-957,-2,-112,1000,754,1000,1000,-231,-822,-437,-644,-84,250,-117,1000,633,1000,-1000,1000,-251,-28,-1000,-24,502,327,1000,-1000,-1000,-667,615,-1000,-425,-1000,1000,160,216,1000,-780,-472,-1000,154,446,360,-1000,-1000,702,756,578,-1000,460,800,347,-114,424,1000,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00264() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "detachChildren():void",
            new int[]{-59,-836,-456,298,-354,259,178,-490,-487,-1000,-556,995,-423,-445,1000,-408,263,-480,526,-435,1000,-432,826,1000,-961,-684,-277,108,-1000,96,-362,-801,1000,-1000,-309,-273,210,351,-665,-770,-1000,345,-487,-28,336,153,1000,-396,540,-962,-731,-104,-557,1000,-624,360,-349,-121,84,248,580,669,300,276}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00265() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "detachChildren():void",
            new int[]{164,974,31,-1000,-26,-1000,-60,178,-870,637,-209,27,255,932,791,-401,-631,-1000,-380,-36,-302,-747,-440,924,398,-579,398,-1000,-196,1000,930,-588,-95,-871,-59,-256,-522,-1000,289,1000,612,-546,667,-1000,68,683,1000,1000,-375,-1000,593,-1000,-123,-708,663,-932,826,-384,-581,668,1000,-116,-596,-576}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00266() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "detachChildren():void",
            new int[]{-632,-246,-282,-226,286,273,-204,296,372,-637,724,85,-486,20,454,1000,986,-147,445,141,-265,122,-197,-925,-403,127,630,-945,1000,-285,620,852,1000,-22,116,-1000,-578,-791,-769,474,-924,-159,89,286,97,537,1000,589,366,718,-871,-458,-304,744,-678,-88,-313,-58,-645,-207,-534,-379,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00267() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "detachChildren():void",
            new int[]{-59,789,-138,-514,-41,-945,307,238,-584,202,-1000,574,638,221,476,-820,-1000,-1000,-351,-728,1000,-1000,216,1000,-442,-32,-277,400,-559,1000,-187,-362,397,-787,-711,972,41,-636,-405,-221,-1000,345,489,-974,95,405,637,-396,416,-1000,566,-1000,-700,-361,839,-373,168,-121,-100,341,1000,669,-1000,390}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00268() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "detachChildren():void",
            new int[]{845,293,-990,-916,1000,-945,1000,1000,445,509,1000,-92,1000,1000,1000,-553,-1000,-906,-783,-260,-875,-1000,360,1000,-135,-49,522,-1000,-1000,1000,-228,1000,-921,-1000,-1000,1000,-532,-1000,-632,-62,1000,-494,-16,-1000,23,995,1000,-328,987,-1000,1000,-1000,-462,-652,1000,-250,-80,-531,-222,-69,330,-392,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00269() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "detachChildren():void",
            new int[]{1000,-657,-1000,-1000,-588,-856,-268,594,1000,-1000,-949,1000,1000,-1000,718,1000,1000,-771,-1000,-1000,564,-1000,665,1000,513,-735,-1000,1000,-1000,664,-1000,-1000,1000,-593,-509,807,1000,718,-1000,-1000,-1000,-108,-1000,378,-164,28,-336,1000,-152,-541,441,-526,669,288,-841,351,980,-125,502,-749,1000,1000,1000,-611}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00270() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "detachChildren():void",
            new int[]{620,719,398,-824,-367,-515,-30,-708,-1000,-545,-1000,1000,203,-445,871,-1000,-466,-579,130,-784,946,-1000,961,1000,-1000,-1000,-79,557,-1000,470,-75,-1000,1000,-1000,-429,78,223,-158,-1000,-824,-871,729,-292,-28,724,135,616,-336,110,-1000,-731,-241,-935,239,-574,-346,-116,237,-524,804,1000,938,475,-130}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00271() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "detachChildren():void",
            new int[]{682,664,-962,59,759,-915,521,80,-574,94,175,93,1000,1000,-1000,-1000,-818,-932,-87,-1000,-551,421,-1000,1000,1000,156,1000,-558,-1000,565,770,456,-254,-1000,-594,227,805,-1000,-407,1000,-1000,-1000,-479,18,-774,676,1000,-667,-1000,-1000,40,-901,604,-1000,1000,-1000,-1000,753,-1000,731,-1000,201,-925,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00272() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "detachChildren():void",
            new int[]{1000,-651,-211,-306,-48,-603,211,-196,-591,-739,-1000,1000,245,-170,550,-1000,-1000,-1000,-121,-1000,1000,-975,1000,1000,-1000,-21,-1000,1000,-946,1000,-595,-114,1000,-749,-546,754,237,-334,-671,-1000,-830,1000,-276,-963,394,216,482,-845,755,-1000,-84,-1000,-683,240,197,287,-64,423,106,533,1000,1000,-1000,687}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00273() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "detachChildren():void",
            new int[]{1000,-307,-1000,-856,-167,-1000,266,534,836,-308,-173,972,1000,-528,426,536,-1000,-196,-1000,-1000,87,-1000,370,1000,-1000,-378,-1000,1000,-1000,1000,-1000,-750,865,-586,-296,613,391,-174,-163,-500,-735,978,-1000,-389,-203,184,1000,460,-52,-290,-1000,-886,390,-234,-340,-284,880,-128,261,1000,1000,1000,-1000,728}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00274() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "detachChildren():void",
            new int[]{609,-7,996,103,1000,-454,323,1000,592,-394,-896,-86,135,768,-561,-122,-859,-841,-368,89,-997,-447,-212,846,670,108,-527,388,-611,528,-1000,641,-1000,-753,-1000,1000,-820,-1000,-852,-5,965,445,763,-402,-395,774,1000,266,1000,-987,715,-709,-880,-225,1000,-187,-576,-167,-183,-181,706,-657,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00275() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "detachChildren():void",
            new int[]{-1000,-716,429,880,397,335,-59,-62,-65,-435,283,-254,-1000,892,1000,149,757,-441,575,914,-516,398,-565,-938,930,-729,578,-1000,738,467,209,831,-1000,-774,320,-707,-1000,-171,605,366,5,-715,1000,-1000,47,742,951,259,1000,-349,940,-660,-407,774,32,350,1000,-922,-116,257,-1000,-803,630,778}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00276() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "detachChildren():void",
            new int[]{259,-502,-784,53,-752,276,302,467,1000,-1000,-1000,1000,180,32,426,950,-116,-429,-215,-1000,87,-603,250,1000,-1000,-558,-745,1000,-448,367,-554,-1000,865,-586,-227,-997,631,772,-415,-675,-1000,908,-1000,292,-341,156,1000,883,167,-313,-1000,-472,-240,623,-1000,-255,1000,-60,911,474,854,1000,-90,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00277() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "detachChildren():void",
            new int[]{-151,502,-292,1000,-299,573,250,-363,152,-1000,-1000,1000,-59,1000,-1000,479,-124,-978,80,-1000,-613,206,7,-4,-987,-403,-375,-1000,-848,-368,-673,-1000,1000,1000,-184,132,1000,1000,-615,-570,-1000,459,-988,-58,-381,343,-1000,-266,-359,-557,-1000,-330,-71,1000,-180,-387,-961,968,438,-428,-137,1000,123,670}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00278() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "detachChildren():void",
            new int[]{-830,-816,-1000,-535,983,-445,-155,818,484,1000,-231,-989,1000,-731,-99,-563,-972,315,722,-875,108,-10,912,-271,-600,-338,-620,-1000,1000,1000,-829,-48,234,596,-1000,-946,-84,-854,-963,814,-478,220,536,791,-543,429,1000,-566,-655,-681,960,466,266,832,412,15,68,287,-1000,-878,-504,48,1000,-915}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00279() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "detachChildren():void",
            new int[]{-796,874,641,-624,830,23,666,1000,619,-937,786,-539,297,-410,730,584,672,-561,759,1000,-1000,461,-1000,-125,-1000,123,956,-1000,-7,-772,-533,251,-1000,579,-155,-591,-1000,-1000,-1000,1000,-110,-1000,640,1000,-1000,126,38,59,-954,-894,-117,-474,76,277,230,-1000,-1000,397,-1000,158,921,1000,266,4}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00280() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalStateException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "detachFromParent():com.google.javascript.rhino.Node",
            new int[]{-213,454,-16,-1000,-879,720,1000,-833,473,-380,549,1000,-1000,-561,137,1000,-1000,692,-937,-1000,227,-898,-717,-459,777,82,-1000,-622,-390,589,1000,397,841,-1000,38,644,500,-52,234,50,-1000,87,189,-1000,-326,1000,145,1000,114,-442,-552,1000,1000,92,-292,647,-1000,-761,592,-1000,-217,-46,-430,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00281() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalStateException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "detachFromParent():com.google.javascript.rhino.Node",
            new int[]{-555,-376,178,740,391,-876,18,215,607,-956,-408,880,891,767,160,150,587,683,618,851,323,626,496,857,505,-999,986,918,-981,434,-620,135,-186,-13,-465,924,830,-820,-195,-87,-915,-603,253,-278,621,-419,908,-734,-497,-434,304,906,-911,-117,638,-454,383,-592,491,-402,442,-148,249,642}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00282() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalStateException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "detachFromParent():com.google.javascript.rhino.Node",
            new int[]{-843,209,760,1000,462,691,-274,-643,-1000,-13,-1000,-204,1000,1000,-1000,-1000,1000,-813,-1000,1000,-501,1000,1000,381,541,220,-1000,-185,-632,389,-621,-944,-1000,1000,-330,1000,301,-1000,-393,1000,1000,-1000,-1000,-1000,528,-379,-567,-1000,-1000,1000,-1000,59,-1000,-293,361,351,1000,-1000,775,-17,671,74,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00283() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalStateException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "detachFromParent():com.google.javascript.rhino.Node",
            new int[]{-432,-301,-107,8,754,-400,908,5,45,-495,-329,1000,-376,1000,-816,491,1000,608,-753,-321,-724,-782,579,267,-773,743,-8,161,-1000,-34,-524,459,1000,-590,-1000,-589,-65,1000,-515,-243,-1000,211,-315,1000,274,1000,275,1000,243,-867,323,840,1000,665,-678,-995,-1000,67,231,45,-1000,-1000,-690,-762}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00284() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalStateException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "detachFromParent():com.google.javascript.rhino.Node",
            new int[]{377,674,-199,-819,-879,-260,948,-147,-146,-804,-271,187,-986,12,770,776,-1000,785,-937,144,227,-706,-1000,-1000,37,81,-1000,-962,-390,1000,1000,597,542,-1000,-687,1000,697,-299,-383,925,-371,547,1000,-897,-619,111,480,1000,-35,-288,-493,1000,555,-1000,-1000,1000,-1000,-36,913,-1000,-474,789,-430,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00285() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalStateException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "detachFromParent():com.google.javascript.rhino.Node",
            new int[]{817,-281,-490,372,880,-546,468,749,1000,395,1000,-786,-167,286,199,649,-367,320,-1000,-1000,1000,-942,-377,566,-956,220,-467,358,370,1000,674,338,960,-1000,-227,-238,-420,1000,-243,250,-1000,-82,691,1000,-1000,-703,1000,976,-63,-852,-9,270,1000,-1000,1000,-1000,1000,-172,-135,-510,-1000,305,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00286() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalStateException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "detachFromParent():com.google.javascript.rhino.Node",
            new int[]{-205,384,-158,464,-1000,20,-1000,310,-301,1000,-420,37,1000,1000,-470,-1000,391,-19,1000,1000,-1000,-25,39,33,-354,-1000,282,979,-981,-670,354,-215,-1000,927,-592,1000,10,-543,-193,-272,1000,-667,257,-1000,180,-651,398,-1000,-721,1000,-171,698,-1000,-71,185,26,1000,182,-156,333,743,23,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00287() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalStateException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "detachFromParent():com.google.javascript.rhino.Node",
            new int[]{789,418,-839,740,-200,-876,813,-275,71,280,-37,-263,-168,1000,1000,-61,-277,-1000,1000,759,-530,-1000,1000,408,-699,-690,-515,-598,-981,1000,0,-1000,-1000,-13,611,1000,830,-1000,838,1000,551,-1000,253,-1000,74,-1000,-1000,-598,-489,-255,-1000,78,-497,-249,-533,618,1000,-41,-775,178,439,848,1000,-34}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00288() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalStateException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "detachFromParent():com.google.javascript.rhino.Node",
            new int[]{-608,503,-666,-186,-684,1000,-158,-292,942,318,1000,356,-139,-194,-157,-489,-1000,-603,1000,1000,-1000,-337,211,-160,123,-290,1000,-154,895,-435,645,50,-782,1000,591,56,-854,6,639,-681,1000,-703,-654,-1000,269,388,-77,-868,275,429,305,-604,-1000,951,363,993,767,-347,-351,485,1000,306,1000,451}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00289() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalStateException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "detachFromParent():com.google.javascript.rhino.Node",
            new int[]{-68,569,-812,-848,-1000,429,-780,-331,-901,447,590,-707,-1000,473,-369,-11,-1000,53,68,-144,-885,-476,-1000,-1000,-553,285,-805,-465,1000,1000,1000,1000,97,1000,-742,289,-709,993,1000,-628,-522,400,1000,-49,217,-709,521,13,91,962,564,228,-485,191,640,1000,245,476,-575,-797,712,543,525,842}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00290() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalStateException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "detachFromParent():com.google.javascript.rhino.Node",
            new int[]{-1000,484,554,791,-214,-607,147,-1000,-147,-1000,-1000,523,-311,1000,1000,886,-319,361,1000,1000,852,-208,-166,1000,-43,-1000,521,-1000,173,1000,332,-564,-831,-1000,1000,1000,1000,-1000,1000,1000,248,-718,-133,-929,259,-1000,599,-996,-1000,1000,-1000,1000,-1000,-925,-1000,474,947,-1000,-992,-1000,677,1000,677,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00291() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalStateException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "detachFromParent():com.google.javascript.rhino.Node",
            new int[]{-647,572,-415,218,-777,-459,-1000,622,-611,148,-861,-1,1000,1000,-187,-1000,-660,-249,1000,1000,-1000,1000,-184,-567,-180,-909,407,821,1000,-709,562,1000,-1000,-581,-432,1000,-163,-1000,457,-713,1000,-885,615,-1000,185,336,317,-1000,-664,1000,153,986,-1000,781,-203,-43,1000,385,-252,162,1000,594,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00292() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalStateException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "detachFromParent():com.google.javascript.rhino.Node",
            new int[]{261,83,-247,-92,-29,66,586,-110,851,157,1000,-112,-1000,50,-194,611,-418,337,-1000,-1000,340,-370,-447,381,-77,220,-1000,-231,850,725,140,1000,960,-1000,-38,-238,-172,1000,-393,-790,-1000,-82,-101,1000,-608,386,1000,976,-63,-210,-594,59,1000,-1000,1000,-325,-982,-560,-18,-899,-1000,-46,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00293() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalStateException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "detachFromParent():com.google.javascript.rhino.Node",
            new int[]{-323,719,-70,939,1000,665,-342,33,-426,163,-356,-707,451,1000,106,-712,1000,-508,909,1000,-504,547,701,1000,-221,209,837,-441,771,671,-1000,-116,-662,882,-489,1000,-54,502,104,-199,700,-960,-1000,-413,451,-404,1000,-1000,-862,1000,-939,722,-1000,-649,845,-389,629,-712,128,-299,-118,1000,185,391}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00294() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalStateException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "detachFromParent():com.google.javascript.rhino.Node",
            new int[]{-382,24,-582,-819,-1000,-459,318,-933,1000,-116,394,904,-986,-364,1000,776,-1000,560,-506,-634,-773,-1000,-133,-1000,104,-909,714,-321,784,136,569,1000,542,-581,823,-1000,-1,362,381,-713,-371,972,827,63,571,336,597,321,464,5,932,464,555,1000,552,1000,-573,490,-734,-109,733,208,-430,46}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00295() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalStateException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "detachFromParent():com.google.javascript.rhino.Node",
            new int[]{-117,359,-494,574,-756,1000,-769,-292,1000,318,1000,234,26,417,138,-325,-1000,-513,1000,1000,-205,249,-103,681,-405,-999,1000,63,1000,-159,694,-864,-900,454,1000,56,-789,6,639,-934,1000,-900,-337,-1000,-142,-819,496,-1000,2,661,221,39,-1000,1000,1000,716,1000,-232,-1000,529,1000,306,774,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00296() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getAncestor(int):com.google.javascript.rhino.Node",
            new int[]{596,-686,821,-199,681,-133,-326,1000,-1000,-53,-1000,1000,468,128,689,-649,1000,579,209,-1000,-596,309,-864,-1000,535,711,378,-944,-936,432,-99,-305,1000,-1000,-29,-386,-452,970,-726,1000,115,1000,979,815,358,220,540,-1000,155,270,-917,315,-992,1000,-1000,-370,987,-444,-206,968,507,-1000,135,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00297() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getAncestor(int):com.google.javascript.rhino.Node",
            new int[]{-1000,644,-171,293,-374,-999,-278,-345,142,-1000,850,1000,-298,-1000,1000,194,530,712,231,-277,-321,625,1000,11,-85,180,-458,53,-82,-1000,-748,-717,441,1000,-1000,1000,386,-571,-224,-1000,-944,264,-757,824,871,527,909,-269,510,-31,714,-544,524,639,1000,-999,250,890,548,1000,604,172,-1000,-895}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00298() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getAncestor(int):com.google.javascript.rhino.Node",
            new int[]{-220,-891,283,1000,146,-981,-1000,-1000,-1000,-1000,970,213,-880,-843,285,179,1000,1000,-126,-855,-318,-1000,1000,-1000,-1000,1000,-1000,-439,-897,-1000,-1000,-839,-645,144,-1000,921,724,830,-80,-572,-600,-476,751,-463,-641,1000,-680,-1000,52,700,1000,-1000,139,708,1000,-227,-1000,1000,1000,282,-1000,406,-1000,-209}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00299() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getAncestor(int):com.google.javascript.rhino.Node",
            new int[]{-172,489,-234,50,-1000,-1000,-30,-640,502,-722,900,1000,-772,-1000,910,1000,446,-86,73,732,23,-690,274,785,553,-336,-49,-287,492,-1000,-350,11,-863,666,-1000,-287,776,-1000,791,-1000,-430,58,532,-1000,611,267,141,-109,671,-584,1000,494,1000,-204,-258,28,111,264,238,861,205,643,57,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00300() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getAncestor(int):com.google.javascript.rhino.Node",
            new int[]{787,-342,-187,-282,652,-1000,233,275,1000,692,-1000,-436,729,669,-1000,-489,-29,-43,201,-400,-265,412,-1000,-36,-121,-1000,393,645,436,720,-890,1000,45,-1000,265,8,-193,-1000,251,1000,409,510,824,-498,-142,-81,-1000,162,-308,-118,-230,876,-377,-64,-1000,591,-377,499,-495,-1000,171,-623,855,663}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00301() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getAncestor(int):com.google.javascript.rhino.Node",
            new int[]{392,-397,168,1000,-734,-588,-721,1000,-1000,-1000,-266,1000,-1000,-837,1000,-678,1000,1000,-247,-740,-1000,-68,937,-1000,69,1000,-727,-957,-927,432,452,-1000,1000,-457,-168,-513,-532,698,81,728,467,342,530,170,1000,1000,1000,-1000,1000,665,-381,-700,-487,251,999,-154,981,566,292,973,-178,-213,-1000,131}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00302() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getAncestor(int):com.google.javascript.rhino.Node",
            new int[]{-788,259,-8,266,-540,-1000,-329,-332,-459,-880,77,-334,73,125,294,1000,1000,827,310,699,343,-1000,533,617,-720,381,138,751,649,-796,-1000,910,57,687,-1000,1000,1000,-845,-305,-1000,-1000,321,-845,154,366,744,830,266,176,-440,1000,324,996,850,-480,-193,-1000,775,427,836,-310,801,225,235}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00303() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getAncestor(int):com.google.javascript.rhino.Node",
            new int[]{1000,-41,942,1000,1000,180,-187,-741,67,221,-1000,1000,136,796,-80,-1000,-379,1000,-649,-640,-752,1000,171,-415,-1000,658,-732,-152,497,1000,944,-145,1000,-796,99,53,-1000,307,29,1000,1000,184,881,-1000,600,-1000,785,-314,-254,73,249,-373,-586,249,865,377,1000,-857,-644,929,272,-297,-1000,-111}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00304() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getAncestor(int):com.google.javascript.rhino.Node",
            new int[]{-424,-522,107,-1000,1000,45,127,871,-225,-426,77,97,-300,-135,-357,38,-1000,327,1000,-939,-270,551,-1000,98,472,-474,1000,-882,266,592,287,-269,100,1000,-715,506,180,-1000,-995,893,-721,627,686,66,165,-702,-58,206,-748,-1000,-835,1000,-284,510,-1000,-708,401,-202,2,566,676,-463,-72,115}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00305() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getAncestor(int):com.google.javascript.rhino.Node",
            new int[]{31,284,-1000,-1000,-259,-1000,1000,-323,670,-284,960,-70,-825,-331,1000,1000,-61,-1000,986,1000,243,-1000,299,1000,1000,-1000,772,-894,1000,-830,87,-128,-1000,1000,-396,-281,-885,-1000,-302,-1000,-201,-1000,-917,50,818,720,-75,1000,-203,-902,670,1000,913,466,281,977,1000,-751,-616,162,641,1000,-179,115}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00306() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getAncestor(int):com.google.javascript.rhino.Node",
            new int[]{-815,492,-980,-629,575,503,-46,742,-874,269,306,996,-822,-159,843,-271,-898,301,-5,-138,683,411,-979,-278,-41,-635,-519,-33,-380,287,-474,-780,169,-485,-632,780,140,-310,-761,711,943,180,-879,-770,-894,506,567,416,58,-955,-922,-57,971,553,624,825,-352,-210,198,934,-68,924,-482,-535}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00307() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getAncestor(int):com.google.javascript.rhino.Node",
            new int[]{-161,-891,-772,8,251,922,724,299,-551,-8,-1000,-297,-965,-806,8,-503,991,280,132,716,-787,-167,-205,321,-341,-389,-186,-392,-355,-634,225,251,-645,-209,-383,325,-707,-424,-1000,-601,38,-1000,-1000,489,-15,-523,206,975,-355,-418,-229,128,1000,-55,1000,134,820,-274,-149,-250,1000,1000,125,205}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00308() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getAncestor(int):com.google.javascript.rhino.Node",
            new int[]{-744,18,-951,-1000,684,-1000,1000,86,1000,-545,793,1000,-117,-848,910,1000,145,-573,378,746,-80,-676,365,1000,727,-1000,414,-1000,1000,-1000,-522,172,-863,1000,-1000,1000,246,-1000,-695,-1000,-1000,-400,-818,793,611,471,425,598,80,-703,589,494,400,513,-28,-408,1000,-109,244,606,1000,467,-157,-39}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00309() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getAncestor(int):com.google.javascript.rhino.Node",
            new int[]{220,-13,244,-1000,-789,-256,981,1000,1000,824,-609,483,399,460,285,250,-946,-960,769,499,344,1000,-1000,947,604,-730,1000,-370,1000,1000,364,879,60,1000,-128,920,477,-1000,-999,-306,-140,505,1000,-674,663,667,-709,1000,-1000,-338,242,1000,394,972,-99,86,83,-110,-918,302,984,25,212,783}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00310() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getAncestor(int):com.google.javascript.rhino.Node",
            new int[]{-79,-726,195,-859,283,-488,-682,586,655,139,77,703,-806,-957,451,199,153,827,839,-749,-659,-180,-605,-921,940,730,641,-916,-811,-772,-228,-404,525,149,-63,-264,-94,-995,-305,854,-721,981,841,632,366,744,830,-995,333,-5,-835,797,-745,-39,-746,-833,763,775,510,836,-221,-945,-253,380}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00311() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getAncestor(int):com.google.javascript.rhino.Node",
            new int[]{551,368,164,792,-1000,-1000,1000,-971,823,-830,-709,-1000,948,1000,-56,276,1000,-1000,311,873,-334,1000,-72,1000,765,108,129,1000,1000,1000,77,-408,-331,-1000,259,-1000,-899,417,-32,674,1000,-20,259,-628,-216,792,-1000,1000,-525,-896,1000,1000,-203,445,64,1000,1000,-927,-1000,581,-929,-472,521,-223}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00312() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node$AncestorIterable", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getAncestors():com.google.javascript.rhino.Node$AncestorIterable",
            new int[]{-133,-276,-553,-25,13,1000,828,1000,-474,464,-247,-893,-155,471,513,-237,-20,131,434,-341,-705,811,283,1000,-560,-146,-184,212,89,905,-590,-980,-509,118,680,317,161,-989,-184,-549,175,-355,484,-743,-99,-316,-359,-20,-17,-414,723,-1000,-1,-1000,384,93,230,-101,-226,360,-309,668,509,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00313() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node$AncestorIterable", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getAncestors():com.google.javascript.rhino.Node$AncestorIterable",
            new int[]{1000,838,527,-304,-345,1000,18,275,-987,1000,-182,-370,1000,1000,423,-483,940,113,-114,-1000,541,618,1000,669,243,814,-403,-866,-408,340,856,-563,-1000,-428,743,-582,1000,1000,199,-1000,-126,0,261,429,-1000,-422,1000,-566,1000,-758,-60,247,1000,-1000,1000,1000,-637,985,-1000,-1000,1000,113,-350,-982}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00314() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node$AncestorIterable", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getAncestors():com.google.javascript.rhino.Node$AncestorIterable",
            new int[]{-378,-881,127,-314,-597,-230,107,1000,-427,-49,1000,1000,-1000,-652,641,-414,-676,-469,-444,1000,-899,91,88,-581,708,1000,-1000,441,-330,-697,677,-1000,1000,738,689,-414,207,96,-39,443,-524,-555,71,154,845,270,-242,188,-352,308,1000,-514,-672,-639,-868,-30,1000,-25,-15,1000,-588,311,523,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00315() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node$AncestorIterable", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getAncestors():com.google.javascript.rhino.Node$AncestorIterable",
            new int[]{935,-216,-812,704,779,225,-1000,676,130,965,-288,934,-281,-1000,490,1000,-574,-271,-292,-163,-330,-164,616,73,-564,-779,443,-352,150,512,-37,-1000,-1000,799,-1000,70,439,-853,-1000,895,-258,1000,1000,-882,1000,-347,435,258,732,1000,435,1000,-589,-445,-339,313,1000,-637,-1000,-417,-985,1000,819,707}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00316() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node$AncestorIterable", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getAncestors():com.google.javascript.rhino.Node$AncestorIterable",
            new int[]{-462,-382,415,566,521,279,1000,-627,-555,123,-1000,-1000,-169,1000,692,273,-264,958,1000,-703,928,-559,-405,908,-433,397,1000,-333,-226,1000,-597,-142,-1000,-1000,455,699,-1000,-1000,-651,-169,590,261,-425,304,-153,-219,1000,-938,0,100,-1000,-1000,-753,169,400,1000,46,-797,573,-1000,-46,908,358,192}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00317() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node$AncestorIterable", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getAncestors():com.google.javascript.rhino.Node$AncestorIterable",
            new int[]{-511,-676,453,-388,-332,36,1000,-627,-283,123,-161,-985,-1000,-899,779,852,-958,455,614,-593,-635,-300,151,-263,-1000,770,1000,712,-226,758,-474,-765,266,-637,455,541,-709,-660,-549,518,447,237,821,304,1000,-48,564,-143,-827,683,-336,-1000,-1000,169,-655,536,1000,-1000,560,862,-627,601,741,339}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00318() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node$AncestorIterable", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getAncestors():com.google.javascript.rhino.Node$AncestorIterable",
            new int[]{754,919,517,-1000,-761,-187,-1000,-774,-264,1000,182,-363,162,-92,572,960,49,572,-69,-1000,-589,1000,1000,-736,-758,-231,-760,17,-346,57,917,-1000,94,163,197,-436,1000,866,657,713,-103,80,1000,-1000,-1000,-502,915,1000,-218,1000,248,1000,560,-851,-612,702,1000,-53,-643,-600,-268,272,1000,365}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00319() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node$AncestorIterable", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getAncestors():com.google.javascript.rhino.Node$AncestorIterable",
            new int[]{566,874,-874,-929,-1000,-320,-651,1000,-1000,489,1000,1000,-187,190,171,128,-54,7,-662,231,-390,1000,1000,-1000,629,486,-1000,-802,109,194,-939,-348,-19,489,-186,-1000,1000,560,901,363,1000,-1000,829,-618,-1000,-1000,-1000,1000,753,518,-217,1000,816,-771,-1000,-1000,495,1000,348,92,-513,24,-157,154}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00320() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node$AncestorIterable", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getAncestors():com.google.javascript.rhino.Node$AncestorIterable",
            new int[]{138,-892,-873,-1000,-922,-1000,1000,622,-620,181,436,732,-1000,34,389,1000,-1000,231,-168,802,-214,-816,1000,-780,339,1000,-257,21,-524,1000,-745,-588,-553,-559,821,-299,-361,-1000,-903,1000,258,-1000,-1000,-97,1000,298,-183,1000,-629,1000,438,-1000,-1000,235,-1000,-147,-166,-671,740,1000,-1000,1000,-105,945}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00321() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node$AncestorIterable", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getAncestors():com.google.javascript.rhino.Node$AncestorIterable",
            new int[]{-499,-496,191,-1000,-1000,-897,1000,1000,-560,1000,796,748,-1000,-134,536,-414,-784,7,-292,865,-719,-429,1000,-648,-206,786,-1000,401,-685,-13,677,-1000,683,-210,1000,-207,504,-341,-69,957,-171,-663,-546,-192,1000,-343,458,1000,-957,1000,330,-1000,-761,114,-868,141,1000,-950,34,1000,-588,1000,257,-36}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00322() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node$AncestorIterable", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getAncestors():com.google.javascript.rhino.Node$AncestorIterable",
            new int[]{-58,-967,-621,-746,-526,-691,321,296,-1000,674,741,1000,-1000,-430,945,1000,-405,112,841,-1000,374,665,402,-1000,-200,704,-625,-636,696,-1000,292,-1000,-1000,933,-204,-753,547,1000,1000,630,1000,-1000,994,158,-614,-801,-298,707,-165,1000,-300,236,297,345,-1000,-418,-1000,525,966,677,-1000,-79,19,-39}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00323() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node$AncestorIterable", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getAncestors():com.google.javascript.rhino.Node$AncestorIterable",
            new int[]{-1000,653,579,1000,-730,5,1000,-975,102,176,-413,-1000,-1000,-1000,909,391,-1000,276,1000,-483,298,395,1000,-817,84,1000,-157,214,-177,168,-1000,-800,-594,604,94,372,-1000,-578,-1000,1000,1000,-681,701,1000,868,-269,2,1000,-597,1000,-633,-1000,-926,-796,-1000,-900,-228,-1000,1000,1000,-753,659,328,-631}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00324() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node$AncestorIterable", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getAncestors():com.google.javascript.rhino.Node$AncestorIterable",
            new int[]{1000,-881,379,-1000,-1000,478,-265,1000,-249,1000,1000,1000,968,-547,594,-547,-935,-1000,-1000,-157,101,-263,1000,-1000,1000,1000,-920,-1000,-695,-899,461,-636,1000,372,627,-1000,1000,1000,1000,63,617,-983,761,-328,-801,-960,-300,845,1000,180,-9,1000,1000,-255,-384,-410,912,1000,-399,132,645,-26,-1000,-799}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00325() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node$AncestorIterable", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getAncestors():com.google.javascript.rhino.Node$AncestorIterable",
            new int[]{766,-241,-633,-6,641,-390,-1000,364,-1000,1000,354,341,-354,-91,890,1000,-2,-214,-559,-1000,1000,141,-79,-578,-802,-460,-450,-414,175,-1000,170,-1000,-564,868,101,-939,1000,18,1000,1000,-179,-402,1000,-541,202,-671,-412,744,212,197,1000,941,-1000,715,-1000,-506,1000,525,263,559,-1000,165,727,979}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00326() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node$AncestorIterable", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getAncestors():com.google.javascript.rhino.Node$AncestorIterable",
            new int[]{-579,-866,-543,1000,-362,1000,-57,1000,-879,-1000,777,825,-872,-1000,491,8,-574,-561,239,1000,1000,811,-1000,99,1000,936,358,-1000,806,-595,-1000,293,239,886,-258,-763,-866,1000,-652,-841,651,-993,484,1000,-685,-1000,-1000,-1000,1000,-1000,470,321,-1000,-551,-376,-724,-717,787,1000,736,-506,-289,-122,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00327() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node$AncestorIterable", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getAncestors():com.google.javascript.rhino.Node$AncestorIterable",
            new int[]{-193,-276,-459,246,13,104,276,-412,-337,145,-513,44,-244,864,706,282,-792,826,929,43,298,-91,-333,-779,-560,-1000,1000,-330,-95,302,340,4,-361,123,680,43,161,-649,-868,-549,353,204,64,651,153,-1000,-359,-627,251,1000,-69,-475,-1000,-1000,384,501,-883,-661,572,360,-649,1000,652,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00328() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getBooleanProp(int):boolean",
            new int[]{1000,329,139,96,-334,578,-551,601,309,227,-892,-1000,295,-126,1000,1000,-362,-255,174,-41,383,-470,-653,129,-490,-55,435,246,412,361,-880,141,199,-102,-81,150,509,-902,657,158,1000,189,-443,-972,-477,739,636,529,49,545,718,724,1000,-648,472,-1000,-877,298,1000,-768,-449,1000,-1000,350}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00329() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getBooleanProp(int):boolean",
            new int[]{1000,364,-623,-839,43,-69,895,881,845,431,-23,-932,-650,-88,596,267,-918,278,-537,-276,640,-968,-381,-203,576,-383,347,533,563,877,-1000,379,1000,37,-81,-606,526,-1000,400,1000,800,280,570,-103,-1000,35,-407,1000,1000,1000,463,1000,997,-201,-540,110,163,1000,-1000,-532,-1000,-262,-1000,-731}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00330() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getBooleanProp(int):boolean",
            new int[]{596,224,457,273,517,-1000,1000,490,-39,-1000,-403,-504,-10,826,-892,-368,1000,-789,606,-1000,136,-1000,395,1000,-744,-753,853,-1000,-259,-137,334,1000,476,-1000,-631,214,328,-518,-715,136,76,238,384,-1000,1000,795,-1000,318,-1000,-646,736,254,391,-386,-476,-156,-106,-181,199,1000,243,732,-142,618}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00331() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getBooleanProp(int):boolean",
            new int[]{-414,-151,515,460,-24,-1000,785,-896,644,-194,-375,1000,-432,-69,-94,-59,980,-583,915,321,340,-393,648,675,-311,102,1000,-482,29,338,-54,854,-612,-1000,435,340,104,-109,-464,-16,811,1000,962,7,913,372,-583,228,-819,-6,823,-74,-529,245,990,870,-746,466,1000,971,-364,636,1000,658}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00332() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getBooleanProp(int):boolean",
            new int[]{619,-221,-39,96,142,-342,-1000,-126,309,-1000,-1000,-896,372,711,787,-660,-479,-1000,-829,205,379,278,-690,161,-490,428,1000,248,-274,703,-1000,2,-386,401,-1000,528,1000,-557,-63,97,1000,1000,-678,-317,1000,574,-108,-603,-837,707,-20,67,152,-920,-438,-238,-35,-266,1000,-58,-210,1000,-921,-435}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00333() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getBooleanProp(int):boolean",
            new int[]{1000,-261,963,263,-308,-118,79,484,318,-197,-549,-960,-901,656,731,513,184,341,1000,-506,1000,-420,-1000,1000,699,-398,246,1000,400,488,-1000,1000,293,-911,-784,-1000,156,-354,1000,1000,396,-50,268,-836,-1000,479,394,657,982,430,1000,741,980,-904,82,1000,282,809,-358,-281,-1000,581,-809,-391}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00334() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getBooleanProp(int):boolean",
            new int[]{520,364,-1000,-553,35,-1000,-790,301,-511,-4,-223,-1000,-120,-88,419,841,24,-1000,-942,-276,572,-999,432,-560,-771,107,347,274,-1000,-302,-1000,497,416,37,-81,-117,1000,-1000,-248,622,749,1000,534,10,845,1000,-365,290,-137,1000,718,846,-381,275,229,-1000,-366,1000,575,208,-449,288,-299,-676}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00335() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getBooleanProp(int):boolean",
            new int[]{-133,299,-558,-629,708,639,-51,529,-553,-82,-891,6,464,896,134,566,-201,-320,142,-157,159,985,258,506,-534,-659,-638,-475,513,182,671,-283,966,778,132,-930,-593,144,-731,-9,443,-356,552,-409,-40,-104,640,-604,570,720,-118,463,975,-594,-608,-231,-436,376,-316,-30,-138,408,-647,-857}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00336() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getBooleanProp(int):boolean",
            new int[]{-69,-446,859,-1000,-1000,1000,628,59,-296,507,1000,-895,1000,-836,-811,-552,483,-92,424,365,809,1000,1000,612,159,30,-74,503,1000,-233,576,698,-1000,406,770,-256,344,539,1000,67,-79,-377,103,293,947,-497,1000,-148,907,216,419,-244,-1000,1000,583,-1000,903,545,932,245,-209,-1000,125,472}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00337() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getBooleanProp(int):boolean",
            new int[]{240,-631,-458,169,1000,-550,307,363,1000,447,617,306,-1000,89,1000,1000,-639,631,-1000,116,664,374,39,-109,711,-501,1000,804,-1000,-1000,-944,606,373,1000,50,1000,627,9,-400,80,-217,464,-822,1000,767,370,-1000,-416,-559,1000,-229,1000,1000,-79,68,285,-1000,84,363,1000,-658,708,239,-136}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00338() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getBooleanProp(int):boolean",
            new int[]{130,533,83,-403,645,-119,-185,382,646,11,402,-577,-537,308,851,407,-1000,29,104,1000,941,127,-557,506,1000,-914,-418,718,559,1000,-126,798,-1000,612,-409,-968,129,-174,724,1000,1000,-762,-592,-217,-768,-228,747,-75,1000,1000,-31,785,289,60,-860,569,11,648,-532,659,-646,-183,-756,472}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00339() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getBooleanProp(int):boolean",
            new int[]{924,-921,-352,-292,-4,-339,-358,-96,13,408,-846,-687,474,-485,1000,1000,-509,-559,-1000,-30,1000,-98,-396,-491,228,-2,157,70,-983,-582,-621,629,-508,-340,157,326,342,-198,420,-16,1000,805,-204,-881,-454,20,218,302,752,1000,246,136,999,-497,564,178,-903,799,696,246,-120,1000,-729,246}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00340() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getBooleanProp(int):boolean",
            new int[]{-811,-982,-146,18,736,-392,-430,-469,1000,-510,-19,273,-125,398,502,585,-912,-585,-648,1000,710,1000,-637,534,715,-201,144,71,-175,922,-490,259,-737,1000,-578,-42,539,280,-257,101,1000,-3,-714,651,809,-580,174,-785,645,821,-764,-371,-345,-258,-202,-282,722,-85,-2,926,-394,172,-627,145}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00341() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getBooleanProp(int):boolean",
            new int[]{684,-176,-212,680,95,-284,-845,217,1000,317,-1000,-372,1000,-269,1000,93,-162,-1000,-763,285,415,-902,-453,523,-742,-227,853,-1000,-1000,221,-1000,-777,294,-72,93,1000,982,-553,-1000,-1000,1000,1000,-1000,79,-736,1000,526,-200,97,417,892,-71,1000,-1000,926,-216,-1000,402,1000,-822,241,1000,-1000,-252}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00342() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getBooleanProp(int):boolean",
            new int[]{125,364,1000,112,-283,742,-42,301,591,15,-147,12,672,466,-594,-880,655,-1000,1000,652,808,981,-575,598,418,247,-522,-160,1000,1000,338,-615,-367,-648,-189,62,-955,1000,-126,-289,-309,-562,-161,104,-586,-925,1000,136,372,-410,-888,-429,-155,-543,229,492,-366,223,-241,-708,-634,288,-64,-208}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00343() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getBooleanProp(int):boolean",
            new int[]{1000,-172,-264,217,-145,-458,-791,306,688,-444,-947,-1000,-429,880,1000,493,46,-220,-135,-4,861,-1000,-1000,-759,240,141,631,1000,-1000,-1000,-1000,934,1000,-344,-1000,-818,850,-1000,1000,1000,668,738,24,-230,-676,1000,-1000,295,482,557,956,1000,1000,-1000,136,1000,-99,576,79,-756,-1000,669,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00344() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChangeTime():int",
            new int[]{-620,-376,38,-1000,12,-477,703,5,121,117,-172,106,-18,131,1000,-231,683,-526,71,-154,1000,525,290,-53,-750,-587,266,313,335,404,1000,747,496,-592,-556,-151,-666,1000,-694,-598,671,471,337,362,1000,-863,-895,-303,-244,-897,1000,-16,1000,54,423,315,-664,321,-186,-762,196,411,-933,148}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00345() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChangeTime():int",
            new int[]{1000,-681,-1000,532,281,337,-981,-392,-335,325,357,191,-709,-541,-411,-28,907,882,-597,698,1000,434,-1000,-1000,-899,195,232,504,308,175,1000,1000,46,69,398,1000,162,-484,983,-641,-1000,1000,-279,-909,773,349,848,-849,-1000,-1000,-1000,612,813,1000,1000,-1000,-1000,299,-1000,-155,-526,-1000,1000,-872}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00346() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChangeTime():int",
            new int[]{609,-16,-134,-567,-754,-1000,979,785,-1000,225,420,1000,-634,-1000,350,1000,529,102,1000,1000,-747,349,779,985,-999,-669,171,-1000,1000,1000,1000,245,-408,-3,-1000,788,-759,973,-379,-1000,1000,-132,-962,1000,1000,-1000,-749,-44,1000,-1000,1000,-616,-553,-689,935,-719,-764,826,-1000,-1000,-744,35,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00347() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChangeTime():int",
            new int[]{-109,-376,232,-480,705,-1000,1000,340,-1000,-1000,1000,-574,-47,1000,1000,-400,871,776,1000,-420,-1000,-90,244,46,-613,221,-254,176,100,-869,1000,-1000,150,-151,-1000,-1000,-633,1000,-1000,315,-1000,-490,234,487,1000,-375,-1000,1000,-199,484,1000,389,332,-1000,510,1000,-887,127,-685,-263,-479,-360,-1000,947}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00348() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChangeTime():int",
            new int[]{231,974,-520,-969,-54,1000,813,1000,-1000,475,1000,1000,233,632,1000,-467,-1000,3,1000,980,-634,303,155,287,-1000,-1000,1000,-229,1000,1000,1000,-1000,300,812,344,-922,1000,-1000,-1000,-1000,1000,-1000,516,212,-919,-1000,-1000,-1000,1000,1000,528,-438,-1000,-1000,-1000,362,975,1000,596,-72,-1000,-576,-631,577}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00349() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChangeTime():int",
            new int[]{195,-486,-421,238,833,-465,-436,97,-335,-302,-494,285,-748,301,301,-139,1000,928,162,-690,88,154,-1000,-1000,-229,1000,-981,1000,190,-647,909,-232,1000,-159,398,512,-225,978,544,275,-1000,980,487,-324,554,-648,423,-476,-1000,-365,-750,1000,356,1000,1000,193,-810,-1000,-680,759,1000,-947,753,616}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00350() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChangeTime():int",
            new int[]{1000,-376,-576,-1000,-145,220,560,730,-1000,1000,1000,1000,-957,-1000,-1000,1000,683,1000,812,849,183,-1000,-1000,-138,-1000,274,-490,-1000,1000,-61,1000,1000,-806,293,-1000,1000,776,141,-213,-1000,-1000,-17,-1000,112,1000,-1000,-331,490,903,-1000,-400,1000,847,-268,1000,315,-1000,-88,-1000,-1000,19,-1000,-263,65}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00351() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChangeTime():int",
            new int[]{1000,-521,508,636,-649,228,1000,527,-1000,-756,398,277,914,739,1000,-953,-390,703,955,263,-531,662,1000,1000,-735,-1000,734,-532,797,892,955,-1000,542,1000,-483,-752,-146,-155,-1000,-1000,1000,142,698,1000,-1000,-866,-1000,-1000,902,1000,1000,-577,-1000,-1000,-465,987,475,455,-490,-1000,-1000,191,329,811}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00352() {
        org.junit.Assert.assertEquals("java.lang.Integer:MQ==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChangeTime():int",
            new int[]{-671,-201,316,204,796,1000,-913,1000,965,748,904,-179,1000,1000,399,-1000,-382,-327,-214,505,-473,205,-164,-559,429,-527,646,-1000,236,705,864,-1000,-326,1000,537,-732,1000,-400,-854,-795,-272,-870,-120,1000,-1000,-742,-252,366,383,-119,-676,-378,-1000,-1000,-299,-1000,414,1000,1000,1000,-1000,71,-880,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00353() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChangeTime():int",
            new int[]{-81,-486,482,1000,-1000,-753,1000,-221,-1000,-1000,256,-573,1000,1000,1000,-1000,1000,703,770,127,-985,762,-1000,-1000,46,-1000,962,-252,190,1000,944,-1000,963,1000,-776,-1000,-1000,845,544,275,1000,129,840,1000,-1000,-1000,-1000,-1000,-127,1000,1000,-1000,-1000,-976,101,1000,1000,396,-597,-1000,-914,951,-336,722}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00354() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChangeTime():int",
            new int[]{1000,568,-671,27,111,222,670,56,-1000,321,506,3,571,1000,435,-738,453,1000,-418,-1000,-1000,-45,-79,729,-1000,-1000,882,616,103,-1000,923,-1000,866,1000,398,-969,-136,1000,-1000,400,372,44,771,299,-1000,833,-1000,-1000,-217,820,205,712,-1000,-731,-92,896,-70,713,318,-298,-339,-717,150,-752}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00355() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChangeTime():int",
            new int[]{159,649,-171,636,78,-1000,1000,526,-1000,-302,1000,-103,933,301,1000,-671,1000,1000,542,-1000,88,-731,-495,-117,-797,-464,276,-102,-40,-255,905,-1000,373,286,-1000,-1000,-310,309,-1000,275,1000,-165,424,1000,635,-324,-1000,813,172,680,926,279,-360,-1000,706,1000,-870,-477,-680,-139,-461,-399,-1000,436}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00356() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChangeTime():int",
            new int[]{1000,-191,19,-912,-493,590,-67,270,-725,731,950,829,-245,-932,-765,-619,1000,716,-429,257,1000,-515,-1000,-861,-750,820,-622,-272,-175,298,955,296,-69,922,-539,1000,619,13,-327,-592,-1000,809,-603,420,479,-852,-400,-908,260,-1000,265,1000,-499,-183,1000,-609,-1000,-649,-989,-679,-39,-800,-250,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00357() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChangeTime():int",
            new int[]{343,194,20,933,-768,731,660,669,-955,121,-365,-341,-180,-537,982,-467,85,179,-335,-356,1000,1000,78,-670,-762,-1000,925,569,600,-126,975,-1000,812,437,398,-701,549,859,-1000,-1000,1000,-259,999,1000,-1000,1000,-1000,-7,299,1000,-294,90,-1000,-1000,-1000,908,-75,61,632,-1000,-457,1000,643,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00358() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChangeTime():int",
            new int[]{893,-376,-64,-480,419,13,-564,-155,-607,361,240,331,-1000,-164,-808,-400,1000,976,281,1000,172,301,-863,-957,-642,734,-824,623,49,-326,1000,195,83,202,-341,1000,-117,1000,209,-139,-1000,639,-321,-385,1000,-804,16,-419,-674,-1000,-66,1000,540,781,1000,-442,-1000,-186,-753,-525,434,-360,192,-161}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00359() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChangeTime():int",
            new int[]{1000,-166,-10,1000,-306,-258,901,47,-1000,-908,84,-503,84,1000,1000,-1000,-455,792,498,-252,-1000,465,928,1000,-815,-1000,1000,404,471,-498,936,-1000,977,1000,-218,-1000,-816,1000,-1000,400,1000,191,1000,790,-1000,-17,-1000,-1000,37,1000,762,-121,-1000,-731,-552,1000,963,483,-538,797,-716,117,415,427}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00360() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getCharno():int",
            new int[]{1000,584,-1000,-349,-515,-962,-312,-1000,722,290,7,-914,608,641,513,-1000,248,-884,-958,685,880,129,-705,230,-639,-351,-254,208,533,-1000,950,298,-339,378,-672,-504,24,436,1000,131,1000,-908,-821,1000,-719,660,-36,-1000,-185,596,1000,-255,915,1000,675,1000,-1000,-452,-177,-896,234,-962,451,320}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00361() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getCharno():int",
            new int[]{-230,324,145,-343,608,215,-140,201,812,-651,-246,-495,402,-1000,914,-965,655,196,-122,599,449,549,244,-527,-836,-238,-1000,-151,777,-201,788,931,634,349,1000,-3,122,-3,980,763,932,-425,-1000,787,-667,855,197,-197,161,489,-309,605,-292,481,-90,501,-475,-336,-725,-732,-173,-885,-532,635}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00362() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getCharno():int",
            new int[]{1000,264,-1000,-161,-1000,-612,-1000,-879,356,-242,-340,661,-5,-503,674,-875,-368,1000,-971,69,1000,1000,-976,1000,-276,579,552,-213,225,-905,-798,-636,-807,970,-974,-318,1000,282,-142,-720,-200,-728,464,825,-44,756,-448,-650,1000,443,-168,-1000,1000,-215,357,-1000,343,1000,45,-1000,38,-1000,617,-480}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00363() {
        org.junit.Assert.assertEquals("java.lang.Integer:MzA5Ng==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getCharno():int",
            new int[]{1000,584,658,-1000,-1,-1000,-754,-859,722,-256,-196,-914,1000,1000,804,-1000,301,-474,-435,894,1000,130,-1000,1000,-1000,-909,-1000,-1000,1000,1000,1000,915,-990,385,-1000,-952,-283,-473,804,342,1000,-1000,-1000,850,414,1000,-1000,100,1000,-651,1000,54,210,415,1000,1000,-1000,647,336,-435,361,-1000,-666,257}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00364() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getCharno():int",
            new int[]{542,-246,861,-530,-1000,-908,-910,416,-1000,72,-264,618,-297,-252,729,1000,-274,49,67,790,414,-582,-355,856,21,622,343,-583,94,1000,-384,-197,-898,-1000,-470,-1000,-410,155,-556,-1000,-1000,-184,949,-826,129,-486,-551,1000,901,-1000,20,-887,-1000,-1000,449,-285,255,753,578,-1000,206,211,-343,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00365() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getCharno():int",
            new int[]{330,-366,-172,993,-982,-2,-832,205,-794,382,65,-234,-1000,925,912,1000,130,154,-865,554,1000,-19,-637,1000,810,1000,1000,1000,898,1000,-967,259,370,-1000,-103,-202,189,1000,-1000,-1000,-1000,574,1000,-870,-343,-596,225,-791,485,-1000,74,-1000,-1000,-1000,324,-1000,653,-375,98,-835,-977,986,389,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00366() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getCharno():int",
            new int[]{676,209,-151,475,-721,412,267,235,83,734,-806,841,618,-948,362,-514,-590,37,222,-448,24,-931,475,-774,997,838,-215,695,-651,-113,481,-243,-480,-50,272,517,309,-364,728,826,-353,-271,-383,-871,925,184,-954,480,961,739,-199,586,695,28,286,13,-782,15,25,-122,-168,-342,810,-253}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00367() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getCharno():int",
            new int[]{1000,-621,-1000,205,375,-1000,-909,-929,-706,927,-441,-1000,-194,1000,754,571,-315,70,-1000,5,1000,-237,548,-602,631,-11,122,1000,561,337,-7,579,-450,-851,410,-839,581,435,135,44,259,110,-195,565,-1000,-113,91,145,-1000,-737,-573,-982,-156,1000,1000,827,-1000,-1000,97,-680,-82,804,-78,83}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00368() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getCharno():int",
            new int[]{1000,-677,-573,1000,-1000,425,-520,439,-1000,849,958,-267,-942,513,-68,1000,-93,-378,-861,87,-463,941,-1000,-409,1000,1000,1000,1000,-183,1000,-1000,53,-569,-1000,957,722,706,-374,-1000,123,-1000,1000,1000,-1000,-130,-1000,1,1000,-199,-1000,-1000,-1000,-656,-1000,-262,-1000,1000,566,-877,-970,-355,82,-791,-548}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00369() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getCharno():int",
            new int[]{1000,-846,34,34,-37,-1000,241,-1000,-341,1000,-129,-1000,190,1000,400,75,-431,-972,-1000,269,1000,-421,-187,-122,-620,-193,386,1000,382,-417,1000,52,-615,-462,-242,-944,-611,742,408,-269,529,-533,-1000,845,-952,149,-110,-626,-998,-401,1000,598,99,1000,1000,1000,-1000,-1000,399,-776,298,292,493,-66}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00370() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getCharno():int",
            new int[]{-230,-516,-137,448,1000,-272,-360,113,601,-99,-997,-613,-145,-894,1000,-449,295,491,-122,528,1000,-317,1000,-1000,-205,-945,-1000,656,921,367,1000,1000,612,-947,1000,-333,-136,-399,1000,476,1000,-53,-1000,483,-1000,276,394,605,-761,27,-695,-858,-468,847,61,-628,-608,-1000,-902,-648,-654,378,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00371() {
        org.junit.Assert.assertEquals("java.lang.Integer:MTA=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getCharno():int",
            new int[]{-230,-126,1000,902,100,766,-444,-557,1000,-788,119,-495,317,-989,1000,1000,1000,786,-122,1000,552,1000,-515,258,-1000,87,-883,-216,1000,219,659,1000,1000,301,1000,766,-408,425,756,1000,821,-260,-209,606,-779,-1000,966,-148,634,1000,-895,-394,-838,-1000,-90,-245,-956,-388,-514,-707,-89,-1000,-383,-103}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00372() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getCharno():int",
            new int[]{1000,844,16,529,-472,-774,-1000,-915,-1000,-800,-397,-505,-913,224,872,-1000,-52,1000,27,-102,-316,846,-147,722,-1000,1000,1000,1000,710,1000,-1000,928,108,-896,-1000,-451,1000,905,1000,-140,-922,584,1000,186,-642,56,535,622,87,-811,-1000,-1000,-865,149,937,-1000,-60,-113,747,-728,-135,766,208,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00373() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getCharno():int",
            new int[]{940,-151,702,-1000,526,-1000,951,752,643,982,-20,729,1000,701,1000,-1000,-653,829,-913,1000,1000,801,-1000,-636,5,-26,8,-328,1000,176,342,460,1000,1000,-970,565,84,378,-1000,371,1000,-1000,-895,1000,-312,1000,1000,-1000,-489,815,-698,1000,-1000,1000,2,-247,168,-625,-107,-542,-747,-773,21,516}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00374() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getCharno():int",
            new int[]{1000,-451,433,591,-202,-426,-1000,-234,-1000,1000,-341,-768,-1000,656,626,1000,-105,1000,-1000,498,-58,1000,228,578,1000,1000,1000,1000,270,1000,-1000,289,-913,-1000,10,-253,1000,1000,-1000,-49,-1000,792,1000,-898,-513,-649,580,1000,-969,-1000,-1000,-1000,-1000,-400,-7,-1000,-539,-807,931,-658,-679,1000,58,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00375() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getCharno():int",
            new int[]{1000,584,-1000,-349,-515,766,-312,-243,722,290,7,-69,608,641,513,-1000,248,-508,-958,685,31,-274,-705,230,78,-351,-254,208,533,-1000,700,298,-339,-65,-672,530,24,-888,1000,131,1000,339,279,1000,-719,660,-36,-1000,355,596,905,-255,-826,-1000,-735,1000,1000,-452,-177,-896,234,-962,-947,320}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00376() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChildAtIndex(int):com.google.javascript.rhino.Node",
            new int[]{-1000,114,77,855,-832,-259,173,380,661,400,640,-380,-818,-553,201,290,1000,27,515,452,281,172,986,1000,-904,-1000,334,418,-401,66,-797,995,-387,209,102,1000,-286,-60,340,-388,-871,-151,0,834,250,631,-109,-793,211,-680,1000,-548,933,-1000,-461,-84,1000,207,769,-479,1000,-406,1000,400}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00377() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChildAtIndex(int):com.google.javascript.rhino.Node",
            new int[]{-544,-357,25,136,-975,-480,1000,-876,1000,572,389,862,-946,-261,0,41,923,-14,562,559,254,-365,130,278,29,-6,1000,1000,-339,-884,2,-460,641,25,645,-71,-763,-23,218,223,-686,-783,466,838,428,920,461,-182,-586,336,1000,-390,-149,-106,-412,1000,996,625,-114,-1000,-680,1000,1000,451}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00378() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChildAtIndex(int):com.google.javascript.rhino.Node",
            new int[]{-790,-226,-172,-525,-882,1000,145,708,641,-187,-548,50,-1000,-1000,-65,-252,1000,-468,261,339,1000,-757,169,183,-710,149,938,-98,-666,-1000,-408,465,-1000,77,-347,1000,-307,258,932,531,-1000,-769,-226,1000,-903,634,1000,-86,-111,-147,1000,-199,-538,-382,-423,865,1000,1000,-359,-1000,-691,231,614,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00379() {
        org.junit.Assert.assertEquals("THROW:java.lang.NullPointerException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChildAtIndex(int):com.google.javascript.rhino.Node",
            new int[]{97,48,-1000,696,-558,489,151,-834,741,339,-761,651,679,-527,1000,-1000,976,671,864,1000,552,1000,-828,-363,-1000,1000,-1000,-658,-689,776,-446,-273,1000,415,-71,-1000,527,-410,731,1000,-182,-568,-46,275,-1000,-11,1000,726,-400,-288,-438,420,716,1000,-538,-236,1000,-865,-959,-297,-115,955,231,124}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00380() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChildAtIndex(int):com.google.javascript.rhino.Node",
            new int[]{61,259,-790,-1000,-917,-545,712,-1000,567,-1000,-196,696,-846,-340,664,-937,895,-1000,-206,1000,1000,626,-1000,868,-527,1000,456,618,-646,-256,-284,-1000,571,484,1000,64,-301,660,1000,1000,91,-271,52,-479,-1000,764,1000,224,183,391,1000,756,531,319,-883,1000,575,1000,-1000,53,-884,369,453,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00381() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChildAtIndex(int):com.google.javascript.rhino.Node",
            new int[]{-456,799,-835,396,-1000,1000,427,584,472,158,-726,531,-394,-171,210,-316,972,-126,1000,111,536,-875,319,-70,-221,940,-394,-620,-418,-84,-16,141,-218,358,-661,965,-731,1000,235,927,-141,-650,-1000,532,-572,1000,460,967,60,-189,1000,-784,-735,-384,-392,281,992,295,-898,606,-420,978,416,-948}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00382() {
        org.junit.Assert.assertEquals("THROW:java.lang.NullPointerException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChildAtIndex(int):com.google.javascript.rhino.Node",
            new int[]{-735,-257,-753,-81,-104,791,-607,-1000,-68,-157,-1000,693,-194,99,731,-429,-75,-710,-1000,781,435,1000,-1000,-469,-1000,994,-1000,-974,-471,1000,51,197,83,1000,136,32,-1000,-1000,840,640,339,467,606,-782,-1000,-578,208,-870,684,-1000,-661,-1000,1000,295,-537,1000,1000,-482,-592,1000,712,-198,-190,-653}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00383() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChildAtIndex(int):com.google.javascript.rhino.Node",
            new int[]{-1000,29,-229,-187,-832,759,310,293,661,-1000,1000,9,-1000,-1000,743,-555,1000,-1000,-109,1000,1000,999,114,870,-1000,-215,405,418,-1000,-387,-788,68,-1000,247,1000,1000,-11,-60,1000,330,-1000,-66,106,1000,-1000,477,1000,-552,448,-493,1000,388,1000,-541,-927,808,1000,1000,-84,-899,1000,-651,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00384() {
        org.junit.Assert.assertEquals("THROW:java.lang.NullPointerException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChildAtIndex(int):com.google.javascript.rhino.Node",
            new int[]{-159,829,-463,1000,391,-1000,736,574,979,1000,-1000,476,705,-657,541,-25,533,-48,792,-1000,-1000,157,300,600,1000,-821,-743,934,574,347,786,379,501,1000,156,-768,886,687,-599,-517,842,-816,-230,-1000,949,667,-398,-927,-404,-160,120,-746,-681,-714,-139,-1000,575,-276,789,-18,-281,187,94,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00385() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChildAtIndex(int):com.google.javascript.rhino.Node",
            new int[]{-299,-147,-852,-150,106,1000,1000,-320,459,396,-939,348,420,-421,537,-586,1000,360,734,407,300,-1000,-958,-1000,-282,982,101,274,-564,76,432,-1000,604,306,-1000,-842,-300,-1000,519,777,-333,-198,-185,552,211,669,-187,1000,323,-429,-262,-840,-375,179,-438,103,997,-923,220,635,118,1000,591,57}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00386() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChildAtIndex(int):com.google.javascript.rhino.Node",
            new int[]{-999,-431,764,188,-832,-623,180,521,982,-939,324,139,-1000,-865,113,271,930,-1000,-134,1000,620,390,114,1000,-615,-1000,208,1000,-581,-1000,-1000,447,-680,613,1000,1000,488,983,538,234,-1000,-654,919,1000,-335,-65,1000,-1000,-901,133,1000,489,953,-1000,-796,-7,1000,1000,198,-1000,220,-558,1000,-46}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00387() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChildAtIndex(int):com.google.javascript.rhino.Node",
            new int[]{-404,-22,-518,-918,-672,-323,662,596,161,-441,997,106,-719,-495,-930,-96,332,990,568,-93,896,-607,821,970,-301,-138,78,960,311,-805,-338,-158,758,285,-145,-582,-296,902,591,834,-381,764,-110,464,-276,185,278,373,380,-53,458,-788,83,-560,-78,-923,254,634,319,-341,-398,975,980,830}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00388() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChildAtIndex(int):com.google.javascript.rhino.Node",
            new int[]{-1000,914,-399,-325,-1000,-1000,712,1000,1000,-166,415,1000,290,-746,-594,-764,964,-1000,591,167,1000,-367,1000,1000,309,-402,1000,527,-432,776,-1000,-596,725,-108,1000,-298,-62,1000,900,1000,-1000,-239,92,955,-692,818,967,459,77,477,1000,-58,719,-86,-883,-1000,264,1000,-631,-1000,-1000,-391,1000,534}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00389() {
        org.junit.Assert.assertEquals("THROW:java.lang.NullPointerException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChildAtIndex(int):com.google.javascript.rhino.Node",
            new int[]{-914,739,121,533,310,-207,333,-792,786,-4,306,200,-69,615,956,-110,926,-401,-205,1000,348,657,-414,293,-573,1000,-497,-283,-409,66,326,-1000,160,1000,221,-87,-511,819,439,-557,-540,163,-488,29,-5,773,813,-430,565,-320,223,48,605,283,-257,-194,703,-166,-237,711,205,130,592,437}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00390() {
        org.junit.Assert.assertEquals("THROW:java.lang.NullPointerException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChildAtIndex(int):com.google.javascript.rhino.Node",
            new int[]{-456,-191,-687,-791,-1000,681,628,-197,263,-187,-548,743,-931,-362,-297,-564,1000,-447,-305,339,1000,-756,328,273,-710,1000,189,-1000,-666,-500,-389,-64,132,201,-609,1000,-1000,1000,932,1000,-587,-646,-1000,1000,-903,1000,1000,1000,-656,224,1000,-662,-538,239,-474,1000,1000,1000,-1000,289,-1000,1000,614,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00391() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChildAtIndex(int):com.google.javascript.rhino.Node",
            new int[]{-1000,319,155,663,-832,1000,173,127,890,339,-300,96,-1000,-553,1000,-196,1000,-506,-28,1000,281,1000,-283,-118,-1000,-172,509,418,-901,61,-41,488,-1000,189,507,842,-663,-60,609,-291,-939,-578,403,874,-257,531,313,-798,944,-856,1000,101,647,-542,-879,1000,1000,202,313,-645,1000,-446,1000,-756}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00392() {
        org.junit.Assert.assertEquals("THROW:java.lang.RuntimeException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChildBefore(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{1000,684,-275,-1000,-945,-262,203,751,-829,409,223,1000,16,-1000,774,-634,178,-1000,851,815,719,1000,820,-1000,-634,435,-753,-891,-1000,542,1000,746,-1000,-1000,876,1000,136,780,-465,1000,-954,1000,502,-447,1000,-650,441,4,1,-131,-378,-257,103,-1000,-312,-385,572,496,734,-1000,333,-1000,522,364}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00393() {
        org.junit.Assert.assertEquals("THROW:java.lang.RuntimeException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChildBefore(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{1000,684,217,-531,-313,-273,-997,1000,-900,1000,223,-58,-1000,601,1000,-809,-790,-310,727,815,743,-1000,1000,1000,328,-905,-414,1000,-1000,1000,1000,106,-183,371,876,-665,-1000,789,-1000,650,-328,360,660,748,1000,115,848,342,1000,938,-1000,-257,-1000,-532,-1000,178,908,-279,310,-804,1000,-1000,522,701}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00394() {
        org.junit.Assert.assertEquals("THROW:java.lang.RuntimeException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChildBefore(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{732,549,-74,-202,244,-244,-445,-382,824,815,-77,157,16,-552,-1,-117,1000,471,-401,-235,-147,474,43,-528,-222,313,322,-715,378,399,1000,590,-34,58,-1000,400,714,159,600,110,-46,671,-208,-465,1000,-1000,344,-666,32,199,183,-574,676,-1000,1000,-346,-345,192,-789,-1000,1000,743,528,438}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00395() {
        org.junit.Assert.assertEquals("THROW:java.lang.RuntimeException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChildBefore(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{829,-297,971,-888,252,352,5,-28,460,299,-856,732,499,979,527,-520,-358,438,576,-670,309,-924,811,981,-845,217,-387,397,-986,383,-812,-332,-666,-56,817,33,-132,-736,-664,445,-495,413,687,-930,-667,58,395,703,308,-768,-128,165,-798,344,-454,471,-65,-972,988,805,820,170,475,-869}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00396() {
        org.junit.Assert.assertEquals("THROW:java.lang.RuntimeException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChildBefore(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{-400,-117,-783,-11,-945,197,36,182,-829,-436,516,160,114,-421,-532,-549,78,-189,243,321,358,1000,-337,291,47,151,-90,-1000,124,346,-114,862,-1000,-1000,179,-168,-191,780,253,697,195,108,285,-1000,580,-211,444,205,459,-473,44,594,103,72,603,-643,572,826,-537,-941,218,-1000,-877,-172}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00397() {
        org.junit.Assert.assertEquals("THROW:java.lang.RuntimeException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChildBefore(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{-1000,-746,-1000,1000,-561,724,-1000,201,-739,815,82,-1000,-1000,1000,-110,-1000,-515,409,-251,-381,950,474,66,1000,-222,-109,-190,260,1000,1000,183,1000,-311,240,-170,-1000,-1000,1000,-1000,-1000,814,-987,1000,224,580,256,529,1000,1000,-1000,462,1000,-1000,-1000,-832,-291,-345,878,-103,-804,1000,-1000,-1000,-896}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00398() {
        org.junit.Assert.assertEquals("THROW:java.lang.RuntimeException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChildBefore(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{-773,409,-1000,352,-1000,-740,-833,1000,-1000,1000,147,-185,-1000,-320,689,-927,1000,-1000,-110,-147,1000,-168,980,-904,790,-804,130,943,286,1000,1000,1000,-883,66,-171,168,-673,1000,-892,369,557,-415,817,1000,1000,-535,60,124,352,-229,-573,114,-921,-1000,-779,-439,1000,1000,514,-1000,385,-1000,348,483}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00399() {
        org.junit.Assert.assertEquals("THROW:java.lang.RuntimeException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChildBefore(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{-601,-281,263,-400,-455,-230,153,769,-676,-320,-37,-340,-861,143,-334,95,-32,85,-442,504,91,-179,-211,-904,991,-1000,159,-57,-400,923,-1000,705,-1000,-468,-667,-933,-309,399,-444,1000,1000,-331,13,-818,399,-103,-659,149,-267,1000,21,482,-528,1000,34,571,811,1000,-827,-661,-44,-1000,-390,872}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00400() {
        org.junit.Assert.assertEquals("THROW:java.lang.RuntimeException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChildBefore(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{1000,674,373,-460,-248,-155,-1000,633,80,1000,-1000,-117,-1000,-485,1000,-1000,334,-680,494,271,821,-490,1000,-518,-166,-1000,-630,-788,-637,1000,1000,962,-1000,-259,-1000,315,-1,598,-1000,589,-1000,608,366,-263,1000,-927,446,417,552,378,-777,-1000,-1000,-1000,-987,165,487,-4,884,-804,1000,-950,1000,549}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00401() {
        org.junit.Assert.assertEquals("THROW:java.lang.RuntimeException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChildBefore(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{1000,-801,468,-1000,-844,-481,555,696,923,1000,-812,1000,96,952,1000,-334,16,135,1000,100,184,-945,1000,472,-1000,606,-806,374,-1000,410,1000,-918,-845,66,1000,195,983,-967,-1000,1000,-641,1000,235,-20,1000,299,-235,-757,-679,-71,-1000,779,-321,-1000,-1000,1000,-507,-1000,1000,609,1000,-1000,1000,-246}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00402() {
        org.junit.Assert.assertEquals("THROW:java.lang.RuntimeException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChildBefore(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{21,-381,-193,383,128,265,-1000,-314,-168,887,-16,-322,-1000,923,627,-1000,70,580,313,-186,755,-161,996,425,-475,1000,-541,412,641,968,892,885,-518,-694,-937,-580,-815,923,189,-503,-46,539,1000,-544,1000,-380,890,634,1000,-531,589,751,-1000,-1000,110,35,952,332,-831,-1000,240,116,493,32}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00403() {
        org.junit.Assert.assertEquals("THROW:java.lang.RuntimeException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChildBefore(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{-812,64,-469,1000,-979,309,-740,-8,-768,996,1000,-345,-801,-417,-934,-1000,-81,318,95,-508,-164,539,-508,1000,1000,-853,339,1000,495,988,311,1000,-1000,-190,-699,-953,-1000,71,-534,-426,1000,-739,-246,626,989,86,11,617,955,-248,206,766,-1000,-225,501,-112,1000,244,-454,-627,-44,-1000,-1000,-590}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00404() {
        org.junit.Assert.assertEquals("THROW:java.lang.RuntimeException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChildBefore(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{323,-571,797,444,343,111,-624,-363,696,1000,100,-769,-1000,854,-112,-417,-61,1000,78,-508,-903,-833,0,1000,981,-1000,277,1000,495,851,894,-59,-289,-190,753,-1000,-1000,-1000,-1000,-1000,1000,-492,-838,198,882,-154,-167,147,583,838,-630,-172,-1000,-225,73,-112,569,-1000,493,-627,1000,-1000,-893,-111}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00405() {
        org.junit.Assert.assertEquals("THROW:java.lang.RuntimeException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChildBefore(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{-1000,-687,-157,-1000,-194,-1000,1000,317,-28,-76,1000,455,354,-354,-227,1000,1000,453,-592,806,-319,301,39,-1000,55,29,736,-260,1000,240,1000,873,-1000,-363,465,-1000,777,-29,820,1000,553,541,88,1000,1000,-703,-355,-1000,-1000,913,-890,940,1000,-1000,808,261,-213,160,203,-1000,34,672,91,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00406() {
        org.junit.Assert.assertEquals("THROW:java.lang.RuntimeException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChildBefore(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{-431,-876,804,-1000,335,-688,648,1000,-19,1000,870,-480,-1000,1000,913,242,-16,202,-294,681,126,-1000,1000,494,987,-1000,-510,1000,-1000,890,1000,415,-453,1000,306,-905,-12,141,-1000,1000,1000,804,406,1000,1000,-444,-1000,-473,-1000,1000,-187,494,105,-1000,-751,759,351,1000,14,-916,1000,-1000,-132,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00407() {
        org.junit.Assert.assertEquals("THROW:java.lang.RuntimeException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChildBefore(com.google.javascript.rhino.Node):com.google.javascript.rhino.Node",
            new int[]{-824,562,-327,-1000,-844,612,-327,912,-530,1000,-271,179,-1000,106,927,-26,-1000,-1000,1000,-164,1000,-73,980,555,515,-157,-1000,357,-1000,996,1000,276,-1000,-615,-1000,-20,-573,986,-1000,1000,1000,1000,-237,850,1000,-507,182,1000,63,520,-1000,-1000,-1000,-1000,-1000,-883,890,140,415,-1000,381,-1000,-67,36}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00408() {
        org.junit.Assert.assertEquals("java.lang.Integer:MQ==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChildCount():int",
            new int[]{-294,649,-961,1000,961,-1000,632,1000,-800,-1000,-536,546,-1000,1000,964,-943,-79,676,-1000,-1000,1000,-1000,866,1000,-24,1000,-442,106,-1000,-352,-1000,449,1000,-117,-768,1000,-684,-179,-132,-369,1000,582,-1000,844,698,-1000,291,1000,-755,232,10,1000,-400,-891,-536,1000,230,-582,-802,-471,-451,-423,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00409() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChildCount():int",
            new int[]{-1000,684,293,-1000,-490,-604,-369,-187,287,-577,438,600,-1000,-594,-1000,-794,898,1000,-1000,-57,-248,161,1000,-688,-1000,-371,-76,-1000,149,-1000,-1000,107,805,-1000,214,680,-851,578,1000,-184,1000,-1000,-393,-21,238,-186,-257,440,-1000,-437,1000,-84,1000,252,-1000,936,-458,-864,525,536,-1000,834,-93,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00410() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChildCount():int",
            new int[]{-303,-546,23,-7,178,11,610,198,-71,16,271,502,-509,299,-154,2,-994,-992,154,1000,591,-695,-424,-963,-520,303,-901,107,1000,842,200,-863,563,-1000,-792,590,594,57,-1000,1000,1000,-31,-1000,-890,-958,-186,-1000,1000,1000,-235,762,-109,535,-287,1000,1000,-622,-97,-534,184,609,375,220,390}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00411() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChildCount():int",
            new int[]{-769,124,839,280,-911,-14,-328,-988,403,224,87,-478,815,-555,-726,617,13,-836,-412,-277,-259,547,-501,55,-863,-509,6,721,390,784,766,34,-435,650,22,-946,-284,310,-490,830,-119,-629,-34,-810,419,845,593,-982,287,-641,911,-65,-671,753,-213,-956,421,661,101,-22,379,-99,519,867}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00412() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChildCount():int",
            new int[]{345,649,-869,-1000,1000,290,1000,1000,1000,196,395,221,-1000,1000,1000,-1000,36,1000,0,1000,506,-1000,1000,-1000,-934,1000,1000,-1000,10,-1000,112,-1000,1000,-1000,-803,262,158,-361,215,-1000,-745,824,1000,296,-1000,-1000,-1000,834,-1000,451,88,-911,1000,280,528,1000,671,-1000,1000,-1000,-1000,-1000,-568,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00413() {
        org.junit.Assert.assertEquals("java.lang.Integer:MQ==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChildCount():int",
            new int[]{844,-791,-718,-591,-478,-955,-96,-418,-447,-1000,181,-280,286,-881,-127,40,345,380,-1000,-1000,612,18,106,581,346,483,833,-26,-687,1000,-999,-178,-113,413,-70,548,124,-763,-174,345,-780,-978,687,1000,-955,-426,676,333,566,-258,844,1000,977,830,-846,-9,-543,-28,-1000,-959,-645,228,390,-848}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00414() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChildCount():int",
            new int[]{-251,129,-508,1000,1000,43,-1000,1000,-745,-810,203,362,-1000,1000,1000,-749,-1000,-946,-291,377,1000,-621,-792,332,462,-16,-1000,873,428,1000,-853,-180,1000,-1000,226,-375,-239,-504,869,1000,1000,432,-1000,-522,1000,-1000,-18,1000,622,3,614,1000,-396,-1000,873,1000,-664,-1000,-1000,764,687,57,-114,-250}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00415() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChildCount():int",
            new int[]{-294,-206,-1000,-660,816,-294,1000,1000,680,-647,148,652,-446,-125,119,-1000,1000,676,-282,9,1000,-655,1000,-360,400,633,-351,-1000,539,-747,-933,461,1000,-117,-412,1000,-485,-737,-132,-1000,175,24,699,844,-155,-893,291,1000,-1000,-405,327,-217,592,-276,-948,1000,73,-710,842,200,-1000,-697,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00416() {
        org.junit.Assert.assertEquals("java.lang.Integer:Mg==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChildCount():int",
            new int[]{-178,564,919,706,493,-245,-638,-1000,533,-1000,371,-525,853,521,384,-1000,178,-742,-1000,-1000,-464,-480,-466,253,-619,171,775,-186,74,300,-397,-568,282,1000,-634,805,-654,-69,445,433,343,1000,-645,-58,307,-1000,-103,59,816,-543,606,1000,1000,-6,95,777,165,148,-736,604,411,446,462,65}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00417() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChildCount():int",
            new int[]{-431,-117,608,-747,-1000,121,223,-1000,205,-184,-3,29,1000,-1000,-1000,219,915,172,-847,-573,-108,1000,-859,-162,-1000,-648,1000,354,-725,837,980,934,-1000,977,-1000,-975,-758,-37,233,-570,-1000,-932,1000,421,129,741,718,-1000,-230,-258,1000,280,-277,1000,-1000,-1000,363,974,448,806,-873,-291,443,269}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00418() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChildCount():int",
            new int[]{-199,-791,911,-111,320,361,317,766,173,559,-241,468,-780,-43,203,646,243,412,169,-275,6,-91,-66,-948,-111,618,-489,-29,-363,-546,67,192,112,-382,-243,241,-434,-54,-59,-439,159,-197,-345,132,-255,-35,125,470,652,49,359,-508,842,245,-469,-336,833,506,276,-369,-525,-791,-388,77}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00419() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChildCount():int",
            new int[]{-303,473,967,1000,721,121,-699,702,430,-386,271,-271,-509,1000,787,-432,-426,-1000,-380,146,-362,-695,-824,66,-135,183,-483,107,699,145,200,-863,563,421,-792,-428,-106,-8,-164,1000,848,1000,-1000,-758,351,-852,-134,53,784,-545,37,837,-1000,-202,795,763,131,-97,-637,1000,978,375,411,390}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00420() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChildCount():int",
            new int[]{-567,879,857,-195,-395,738,377,134,33,822,998,987,480,731,-474,178,586,-692,993,-129,-928,-402,747,-790,471,-205,-471,628,515,637,980,830,-728,209,837,114,-710,489,195,224,559,141,-368,-747,926,-971,769,226,-235,-287,849,-34,132,-191,326,600,464,493,-878,-390,907,660,197,-235}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00421() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChildCount():int",
            new int[]{987,-392,929,1000,357,-118,-1000,540,-441,-701,236,-740,-976,808,1000,255,345,-1000,-538,-503,-220,-569,-1000,882,807,526,226,691,-449,603,119,-697,-216,1000,-647,-381,350,-282,345,1000,4,-978,-644,-545,-43,-942,726,-414,1000,223,887,218,-979,387,868,171,-540,230,-1000,-371,1000,587,1000,-848}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00422() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChildCount():int",
            new int[]{-16,-1,-614,695,296,-1000,-429,914,-714,-1000,-665,486,-1000,336,424,-211,-836,-287,-1000,-1000,1000,-1000,-189,548,-1000,908,-550,449,17,369,420,-698,1000,-1000,-921,584,-206,57,-174,234,783,-479,-989,442,-426,-19,94,1000,454,-464,881,1000,709,159,12,606,-115,-630,-878,403,-112,-59,-530,-475}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00423() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getChildCount():int",
            new int[]{-294,649,-817,68,871,0,879,1000,201,1000,190,221,-1000,1000,1000,-869,183,592,0,-711,1000,-756,1000,438,-98,882,-759,-192,-544,-1000,176,-85,558,-455,-707,1000,-419,189,116,-239,0,0,-572,-406,0,-1000,0,982,-1000,105,0,667,667,2,0,897,703,-781,60,26,-529,-1000,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00424() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getDirectives():java.util.Set",
            new int[]{1000,-1,-238,-588,-808,-242,-634,-213,-1000,395,791,1000,655,-75,379,-812,-739,190,276,271,-174,225,-1000,80,-897,1000,537,168,-783,-5,298,1000,330,313,193,-1000,79,-888,952,-532,630,281,-650,575,166,186,797,-128,-506,-854,-203,852,-509,344,643,-497,145,-406,-255,1000,-303,824,1000,771}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00425() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getDirectives():java.util.Set",
            new int[]{847,-216,-624,-822,-42,-339,-478,257,-116,136,862,576,415,-528,-63,-915,-266,479,250,621,194,514,-677,933,324,573,-565,647,-182,483,284,451,901,88,-15,-550,-364,-839,-469,-706,511,-232,-865,393,940,-192,710,-611,-812,-457,-843,855,-298,63,95,-838,-222,-151,-793,405,-888,864,469,-629}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00426() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getDirectives():java.util.Set",
            new int[]{119,-857,425,517,388,-174,973,296,820,-345,-590,933,-672,-138,-351,976,982,305,324,941,-342,910,93,1000,-1000,957,649,205,-471,372,-321,88,507,622,-458,1000,-339,243,509,1000,291,1000,110,-1000,-84,-861,303,-48,169,429,855,-61,-901,599,561,337,-546,294,51,834,921,-1000,-443,-784}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00427() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getDirectives():java.util.Set",
            new int[]{277,238,-280,162,-4,-900,-382,160,383,1000,-300,-90,1000,-331,1000,-712,-649,-191,251,880,156,1000,-39,915,-1000,-176,-1000,1000,1000,527,-198,1000,1000,-9,651,-1000,-845,-416,-1000,-790,498,-299,-206,783,131,-1000,1000,-1000,-1000,-1000,-1000,752,580,-371,-584,-649,1000,1000,-493,-1000,-1000,1000,-327,-653}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00428() {
        org.junit.Assert.assertEquals("TYPE:java.util.LinkedHashSet", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getDirectives():java.util.Set",
            new int[]{925,369,-558,-1000,-815,-138,-240,-376,-479,-376,932,951,145,545,-1000,-1000,-610,-651,45,940,-270,413,-678,-937,1000,397,169,339,584,-114,230,-812,-789,-162,-280,-570,1000,199,6,1000,687,-350,-1000,660,346,1000,858,-75,-1000,-561,-55,1000,-231,-670,-364,435,-310,-707,142,852,-675,-47,262,828}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00429() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getDirectives():java.util.Set",
            new int[]{680,269,-339,-321,-480,715,-109,310,745,343,896,555,-82,-711,-213,703,1000,371,933,576,636,857,499,569,-215,1000,365,378,-1000,-397,-829,-633,112,940,887,193,-515,-1000,-1000,-1000,362,1000,513,798,648,785,1000,1000,-240,666,695,-1000,-1000,407,1000,-44,1000,-552,-934,651,977,377,-539,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00430() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getDirectives():java.util.Set",
            new int[]{-386,84,-918,-200,668,206,-1000,-846,-1000,1000,1000,329,1000,1000,960,-1000,-780,-414,234,748,254,-160,-857,-1000,-1000,-422,64,930,360,-1000,533,-1000,-648,136,-185,-1000,996,604,1000,311,482,-648,-1000,-313,1000,597,211,-973,-27,-116,972,-310,275,-207,-176,300,553,-988,1000,-779,129,-83,1000,246}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00431() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getDirectives():java.util.Set",
            new int[]{373,-662,-559,688,519,-888,227,194,434,433,505,704,674,-729,515,-670,11,434,479,229,244,887,-1000,1000,656,475,-787,1000,-231,1000,613,-1000,1000,102,14,-305,-907,-848,-1000,-790,-33,160,-140,-151,1000,-228,1000,1000,-868,-805,-1000,857,-245,5,351,-1000,370,707,1000,-43,-417,933,592,-741}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00432() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getDirectives():java.util.Set",
            new int[]{598,-216,288,-129,-1,22,-369,-831,1000,-1000,1000,-625,226,-511,-200,-67,75,735,211,941,225,1000,291,509,-655,1000,-520,1000,684,110,706,949,187,617,113,313,573,-809,239,657,-348,273,468,50,1000,-422,-80,-748,-28,-1000,-587,660,-218,-133,-253,241,141,1000,401,1000,-978,1000,-836,-249}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00433() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getDirectives():java.util.Set",
            new int[]{-242,-372,277,-1000,535,-317,-594,-722,130,235,1000,-522,-494,1000,-535,-1000,-1000,-629,-551,941,-342,1000,687,-808,-5,-765,-1000,1000,1000,406,932,1000,-51,-832,-1000,-90,1000,1000,1000,1000,-22,-1000,468,-650,226,-867,-1000,-1000,879,-1000,-1000,1000,1000,-1000,-1000,893,-1000,1000,1000,-371,-1000,678,-199,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00434() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getDirectives():java.util.Set",
            new int[]{104,-381,-624,1000,-834,-445,-182,-1000,-688,-1000,102,1000,241,490,343,-858,-617,-176,-282,-407,-261,313,-1000,-768,-32,1000,624,70,351,-136,257,-615,-740,271,-362,-291,809,114,555,431,165,-105,-1000,393,-460,746,-196,95,555,548,25,193,-132,-503,39,-278,10,-46,-3,1000,-522,-163,523,568}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00435() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getDirectives():java.util.Set",
            new int[]{277,799,-831,116,-4,656,-634,-1000,-263,343,631,-366,832,774,107,43,311,453,251,-357,318,473,451,-980,-1000,-164,450,321,190,-1000,137,-1000,-1000,462,651,-811,1000,-952,-1000,1000,327,176,-895,1000,-1000,1000,936,799,-34,768,1000,-27,-1000,1000,596,941,809,-1000,1000,-561,144,1000,699,-789}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00436() {
        org.junit.Assert.assertEquals("TYPE:java.util.LinkedHashSet", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getDirectives():java.util.Set",
            new int[]{616,414,213,-292,-544,715,-792,-379,746,705,918,-647,376,-352,-589,385,393,377,323,973,636,857,499,-589,-929,462,349,914,-283,-886,-720,-451,-343,288,758,274,852,-252,239,809,196,868,518,798,584,377,875,535,644,-521,813,-639,-809,407,149,796,523,-291,758,-576,169,806,-638,-372}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00437() {
        org.junit.Assert.assertEquals("TYPE:java.util.LinkedHashSet", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getDirectives():java.util.Set",
            new int[]{357,-121,120,-1000,-182,-156,7,502,1000,943,932,-351,-676,816,-453,-398,269,608,412,420,219,1000,-51,645,-416,1000,-949,740,759,-118,-1000,884,-58,-255,-434,-267,90,-367,-363,37,-426,-410,270,234,1000,-216,219,-900,-139,-1000,-679,-1000,-294,-97,-230,487,554,1000,231,-856,-517,1000,-1000,-463}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00438() {
        org.junit.Assert.assertEquals("TYPE:java.util.LinkedHashSet", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getDirectives():java.util.Set",
            new int[]{1000,-676,-1000,-335,-544,-544,-634,-379,-443,338,1000,1000,841,-1000,788,-339,606,331,362,940,1000,362,-1000,1000,-101,1000,274,962,-933,870,194,-199,-326,1000,952,-685,-1000,-1000,6,-1000,687,1000,364,573,1000,510,1000,274,-1000,-561,-401,-997,-1000,1000,1000,-1000,801,-1000,-1000,1000,169,905,776,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00439() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getDirectives():java.util.Set",
            new int[]{431,-173,134,-902,320,127,-249,369,1000,1000,1000,-449,-903,626,-217,98,309,796,434,606,499,1000,49,664,-747,256,-823,1000,358,-140,-781,695,-9,-27,-222,104,-87,-446,-363,-107,-186,-420,-77,215,1000,-401,361,-574,-231,-1000,-575,301,-295,110,0,408,176,1000,231,-707,-517,1000,-746,-645}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00440() {
        org.junit.Assert.assertEquals("THROW:java.lang.UnsupportedOperationException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getDouble():double",
            new int[]{-285,474,-107,620,-223,-517,912,-380,-261,-415,578,557,-136,-1000,688,-297,470,474,-311,-237,116,-554,240,167,380,-733,-497,832,-308,540,-601,375,-301,-18,-706,433,-465,-163,549,780,-14,-229,-771,-724,-951,-558,-140,334,681,-484,-390,-464,-398,-291,512,326,972,685,-602,-712,468,97,-850,-586}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00441() {
        org.junit.Assert.assertEquals("THROW:java.lang.UnsupportedOperationException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getDouble():double",
            new int[]{-408,-336,-733,-379,-567,-614,-794,-853,49,-682,286,-630,-1000,-1000,131,-647,-1000,126,-1000,-1000,707,150,-588,59,-593,820,-284,-1000,-16,476,-209,-501,1000,719,481,-213,-92,713,-1000,581,612,-1000,-838,-717,-87,535,-424,-392,1000,-1000,-1000,-890,-105,337,-1000,-357,128,661,675,-704,-922,-934,-133,-52}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00442() {
        org.junit.Assert.assertEquals("THROW:java.lang.UnsupportedOperationException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getDouble():double",
            new int[]{-355,-161,182,1000,42,-410,-60,-1000,-279,415,-786,-269,1000,1000,-650,552,190,-1000,1000,300,1000,756,-453,-1000,242,121,-749,374,801,1000,-38,497,378,-82,33,-1000,-432,402,960,942,-488,698,388,-931,1000,1000,-871,811,-1000,768,-763,583,-291,-1000,1000,-1000,-1000,-901,726,518,-151,-962,1000,804}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00443() {
        org.junit.Assert.assertEquals("THROW:java.lang.UnsupportedOperationException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getDouble():double",
            new int[]{-730,-301,-714,-545,-301,353,-83,357,487,-850,472,503,-227,-1000,1000,-1000,496,1000,-1000,-976,-1000,-1000,240,-25,-394,-1000,680,1000,-996,463,-832,704,148,312,-1000,1000,342,-574,-248,64,392,-1000,-1000,-487,-1000,-631,12,-81,759,-1000,-390,-1000,-78,-317,-228,1000,1000,685,-1000,-1000,606,1000,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00444() {
        org.junit.Assert.assertEquals("THROW:java.lang.UnsupportedOperationException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getDouble():double",
            new int[]{-59,74,-757,-562,-1000,527,-962,-170,256,542,263,-1000,802,-1000,-312,-949,-54,1000,-161,-1000,-188,-162,423,237,-312,-259,48,1000,316,-525,234,-339,387,-267,490,184,-90,1000,-1000,-472,-959,-506,-1000,-1000,-121,850,884,-40,1000,-1000,621,-1000,568,917,456,-528,148,-650,396,-224,-1000,-302,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00445() {
        org.junit.Assert.assertEquals("THROW:java.lang.UnsupportedOperationException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getDouble():double",
            new int[]{600,404,129,157,4,777,-1000,-399,834,-700,-741,-1000,610,150,-969,49,-1000,-738,-1000,-316,501,-735,1000,244,-80,-373,1000,-698,31,1000,-309,-1000,109,-28,1000,-1000,-51,-55,-213,157,-94,634,-1000,514,-714,1000,89,1000,563,-362,377,-628,630,141,196,-106,-964,-576,-867,-612,-1000,584,-146,-873}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00446() {
        org.junit.Assert.assertEquals("THROW:java.lang.UnsupportedOperationException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getDouble():double",
            new int[]{-54,643,660,675,-177,-519,11,-558,262,-498,109,619,301,-413,-554,398,349,-38,-515,-989,1000,-175,-240,-170,257,-638,-1000,417,0,606,-404,-757,185,-226,1000,-591,-789,-153,266,595,-154,-182,-41,-165,-302,460,658,578,192,-112,-190,-159,-77,-133,246,-366,491,62,675,-411,-36,-166,-200,-126}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00447() {
        org.junit.Assert.assertEquals("THROW:java.lang.UnsupportedOperationException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getDouble():double",
            new int[]{-486,894,-393,855,63,-1000,-324,-1000,670,-657,1000,-807,-909,1000,-1000,1000,-374,522,357,1000,1000,1000,-161,-1000,-851,-324,-185,-939,1000,622,-784,503,-145,87,-556,-400,-995,1000,85,405,186,-834,171,-1000,626,100,-942,580,-461,1000,-939,-160,115,-1000,71,-400,-456,-540,14,132,451,1000,638,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00448() {
        org.junit.Assert.assertEquals("THROW:java.lang.UnsupportedOperationException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getDouble():double",
            new int[]{-469,649,-561,620,1000,-874,266,-1000,-806,1000,-371,-1000,-136,405,-278,1000,-215,-1000,1000,-17,1000,1000,-1000,-540,-520,910,-458,-78,1000,1000,468,375,412,675,-450,-1000,198,738,730,760,30,239,1000,-1000,1000,967,-1000,-4,681,1000,-1000,-26,-88,276,512,-1000,-938,-1000,253,790,535,-936,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00449() {
        org.junit.Assert.assertEquals("THROW:java.lang.UnsupportedOperationException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getDouble():double",
            new int[]{-151,279,-557,-293,224,83,950,-407,-656,149,847,-93,-519,-1000,1000,-329,16,741,-406,-586,-426,-719,-541,736,37,-631,-143,1000,-24,341,-151,705,-951,293,-1000,881,183,331,142,255,-162,-257,-297,-823,-1000,-760,-324,35,1000,-152,-603,-1000,-49,880,138,806,1000,544,-1000,-570,233,751,-1000,-842}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00450() {
        org.junit.Assert.assertEquals("THROW:java.lang.UnsupportedOperationException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getDouble():double",
            new int[]{-190,-472,-1000,1000,-572,906,-616,288,150,-3,1000,-472,-1000,-1000,1000,-1000,-989,-1000,-1000,-1000,-1000,1000,-256,1000,-1000,-346,1000,-526,42,-662,261,-56,-735,679,-298,100,782,1000,393,-1000,423,-174,-669,-1000,-1000,-615,676,206,1000,-768,72,-1000,267,1000,-1000,1000,1000,53,-1000,-900,-1000,-962,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00451() {
        org.junit.Assert.assertEquals("THROW:java.lang.UnsupportedOperationException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getDouble():double",
            new int[]{-236,-121,451,767,1000,1000,-560,-946,-862,-277,-294,-1000,824,-1000,-727,461,-203,685,-1000,-445,712,-523,-229,1000,1000,-551,-85,1000,484,927,-205,-295,-1000,191,303,-511,266,388,602,-749,-891,454,-224,323,-1000,-268,-745,1000,1000,-393,-964,-1000,645,1000,1000,181,642,-221,-1000,-342,-614,1000,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00452() {
        org.junit.Assert.assertEquals("THROW:java.lang.UnsupportedOperationException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getDouble():double",
            new int[]{-151,279,-473,-293,224,1000,774,-239,-1000,1000,-208,-93,74,-1000,1000,-329,-1000,329,-1000,-1000,-378,-978,-1000,1000,-1000,1000,636,-560,-23,997,-151,357,-431,1000,-928,283,17,212,508,-749,-162,-489,753,-823,-125,-319,-1000,-725,1000,1000,-970,-1000,914,1000,-801,645,110,-193,-391,-492,477,709,801,-447}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00453() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalStateException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getDouble():double",
            new int[]{-857,39,-563,93,1000,209,143,-527,426,641,-848,-631,92,-1000,917,-1000,-735,-477,-126,-261,-106,-186,-1000,-403,-707,296,1000,-644,497,1000,2,830,-280,1000,-92,172,786,37,819,311,726,-89,446,-661,-215,382,-1000,-84,-570,813,-1000,-41,-132,139,-154,670,-25,-800,-964,-230,1000,538,448,492}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00454() {
        org.junit.Assert.assertEquals("THROW:java.lang.UnsupportedOperationException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getDouble():double",
            new int[]{-360,564,-133,1000,1000,-243,421,-1000,-953,1000,-920,-588,668,1000,-431,799,-165,-1000,1000,56,1000,444,-1000,-882,106,875,-681,242,1000,1000,-317,-1000,358,291,-497,-151,75,624,984,820,-412,204,1000,-763,1000,1000,-1000,-11,-1000,1000,-1000,208,17,-266,986,-1000,-1000,-1000,448,877,645,-962,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00455() {
        org.junit.Assert.assertEquals("THROW:java.lang.UnsupportedOperationException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getDouble():double",
            new int[]{274,64,-790,1000,1000,593,186,-1000,-875,1000,-1000,-1000,1000,339,-669,384,-549,-1000,1000,-650,1000,1000,-562,-16,56,1000,-1000,453,1000,1000,693,-1000,343,-256,547,-722,8,1000,562,-65,-1000,398,1000,-961,215,1000,-2,213,-1000,765,134,208,-256,438,1000,-1000,-1000,-1000,1000,1000,-755,-1000,1000,780}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00456() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalStateException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getExistingIntProp(int):int",
            new int[]{986,-191,-105,158,1000,556,372,-1000,-583,668,126,-52,774,-128,-145,-546,62,-206,615,-151,-613,80,1000,-339,-95,-225,1000,1000,-1000,508,748,-721,406,608,396,-605,122,-289,-252,280,469,267,-699,-980,-45,-649,817,146,-598,475,-373,114,546,88,-295,-882,327,-464,881,-627,195,300,-428,-277}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00457() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalStateException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getExistingIntProp(int):int",
            new int[]{-360,-376,40,776,-360,-1000,-935,1000,1000,810,-1000,-1000,-695,-1000,-285,-1000,-1000,-1000,-1000,-238,-761,97,-929,1000,-1000,-457,-1000,1000,932,170,-914,939,-555,1000,1000,898,573,-1000,128,703,-1000,-1000,-1000,-733,-1000,918,-325,-487,1000,-1000,706,661,-766,843,1000,-904,-838,289,-1000,985,435,269,792,-413}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00458() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalStateException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getExistingIntProp(int):int",
            new int[]{809,-216,-455,-720,-711,-878,416,-1000,291,182,885,-405,816,511,-895,931,829,321,749,1000,590,-669,-475,-877,-1000,-1000,1000,-688,425,-608,717,1000,-247,547,390,-209,-552,389,1000,-1000,1000,1000,392,1000,1000,-1000,-1000,-249,536,1000,-90,558,-1000,-259,627,822,1000,-788,-675,-107,-465,-745,1000,-238}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00459() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalStateException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getExistingIntProp(int):int",
            new int[]{905,999,40,-450,186,-823,349,263,1000,810,-743,-421,-1000,-1000,-285,567,-1000,-1000,269,-777,-1000,996,-332,1000,-1000,-1000,-563,936,933,1000,-422,939,-1000,246,1000,1000,-291,-882,607,223,-840,-1000,-1000,-1000,-883,-921,311,-1000,961,173,1000,-969,-225,912,425,-1000,723,1000,-1000,1000,435,-763,681,-195}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00460() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalStateException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getExistingIntProp(int):int",
            new int[]{341,509,-230,-1000,-943,-1000,416,-1000,617,-351,181,-1000,1000,-1000,-385,-213,824,493,-1000,-242,1000,-355,-353,-748,-630,100,343,-1000,934,-1000,109,11,-698,2,586,205,-552,40,1000,-705,-224,1000,398,913,-873,107,-469,102,1000,165,898,1000,-1000,-317,759,243,842,-1000,-598,104,-619,-568,-1000,-238}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00461() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalStateException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getExistingIntProp(int):int",
            new int[]{624,-372,-497,-395,368,-24,276,-1000,276,58,850,-308,1000,177,58,-994,720,287,79,-470,-195,-246,1000,-376,76,-230,599,-66,-442,-579,592,-219,588,1000,-391,-111,270,-570,553,-1000,623,553,433,-1000,380,136,830,214,-205,594,636,929,-1000,-466,301,-662,571,-944,1000,-675,10,-206,-1000,-958}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00462() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalStateException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getExistingIntProp(int):int",
            new int[]{-226,-431,-1000,236,-415,-540,366,-37,293,-526,-585,-977,447,-182,1000,-302,-157,-295,-1000,83,674,-672,-872,-374,719,-206,13,-752,-537,-263,80,488,-581,704,1000,-960,4,320,714,389,-479,851,-666,-424,-864,523,-1000,82,680,-749,-165,1000,-1000,197,208,854,242,-1000,-825,-442,-1000,542,-10,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00463() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalStateException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getExistingIntProp(int):int",
            new int[]{625,-166,240,-69,796,298,-266,-974,-386,925,-396,-430,-1,-294,-455,-317,-772,-640,19,-376,-291,354,53,-727,-596,-657,1000,627,-430,383,889,-506,-189,308,814,-922,-598,57,-211,794,-372,553,-1000,-747,-246,-585,-136,-26,-79,272,-471,148,785,2,-103,-318,554,-355,-270,-95,-383,453,62,227}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00464() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalStateException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getExistingIntProp(int):int",
            new int[]{598,229,-79,-95,689,-8,509,12,-266,239,1000,364,-319,948,-60,564,261,1000,746,483,1000,-1000,579,392,652,997,27,194,35,254,105,328,168,-1000,-1000,376,-40,1000,-933,-497,1000,356,1000,576,1000,1000,-573,-326,-930,-97,-1000,-670,211,-169,-922,1000,477,-1000,397,-250,470,574,818,-435}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00465() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalStateException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getExistingIntProp(int):int",
            new int[]{969,122,667,253,560,-419,244,-989,507,1000,938,-285,-351,367,-781,-92,-968,-1000,125,-540,-1000,-301,477,-37,-1000,-1000,911,1000,-1000,462,604,-473,-477,919,1000,-300,-771,-1000,-322,484,-317,240,-249,-1000,-530,-1000,-779,436,460,637,637,114,-858,456,-20,-934,916,-316,-270,133,60,-295,380,-937}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00466() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalStateException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getExistingIntProp(int):int",
            new int[]{228,-856,406,-855,-10,-54,253,-328,81,-414,777,-875,1000,-839,523,-1000,-299,-150,-991,374,59,-690,-243,298,1000,-112,-249,539,-567,-224,-268,-158,310,1000,1000,343,499,-150,-286,280,-57,-129,-636,-279,-1000,1000,-80,337,375,-884,-805,1000,-743,300,33,1000,-1000,-1000,-132,-265,-629,474,-372,-586}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00467() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalStateException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getExistingIntProp(int):int",
            new int[]{1000,373,548,716,1000,-319,954,-88,-31,-209,885,631,-127,511,-520,311,-396,711,749,1000,349,-669,1000,678,210,770,-225,-688,-367,1000,-453,-184,-247,-1000,-659,417,-525,456,308,400,1000,-157,308,-548,1000,945,-449,-277,-1000,120,-986,-1000,1000,248,-1000,111,435,973,313,-126,589,562,1000,72}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00468() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalStateException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getExistingIntProp(int):int",
            new int[]{848,-197,1000,313,670,101,1000,-347,982,239,873,746,470,-513,-950,454,-489,155,-92,888,627,-371,-826,1000,-444,278,129,194,-635,1000,-978,-442,-651,-1000,1000,568,-526,286,658,289,987,-111,-129,-1000,671,-491,-817,-433,-378,-231,-700,-1000,1000,889,-1000,394,1000,928,-793,-170,530,86,1000,-672}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00469() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalStateException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getExistingIntProp(int):int",
            new int[]{-1000,-396,-214,-135,556,-78,-886,678,-369,-171,-456,-434,258,-274,512,58,-383,-295,-400,-242,172,-882,69,-1000,1000,-641,429,-89,-1000,-557,-158,-55,1000,832,-1000,-798,303,392,122,-231,898,20,-834,-249,-389,1000,-400,602,789,-1000,371,705,-1000,205,537,796,-205,-1000,-60,228,-1000,1000,-688,-400}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00470() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalStateException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getExistingIntProp(int):int",
            new int[]{-403,344,777,-560,1000,711,-1000,-219,-1000,239,-891,-1000,-1000,656,-271,-83,-1000,-862,-65,-300,708,-415,-1000,-458,-280,-435,78,-140,-382,193,265,-350,-151,-1000,935,-865,-1000,1000,-1000,1000,-1000,234,-1000,1000,-958,1000,575,-209,933,-1000,-562,618,1000,188,-976,1000,370,-735,-1000,168,-1000,744,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00471() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalStateException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getExistingIntProp(int):int",
            new int[]{-255,409,816,-1000,670,101,-1000,-347,-294,239,-256,-1000,-319,327,-271,-852,-1000,-753,-1000,16,478,-289,-826,-145,-280,-435,27,194,-273,-93,105,-310,-150,-72,1000,-408,-1000,338,-933,868,-241,-58,-992,85,-1000,1000,1000,7,1000,-1000,411,1000,748,77,-526,30,370,-1000,-891,127,-1000,411,597,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00472() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getFirstChild():com.google.javascript.rhino.Node",
            new int[]{-56,764,-175,392,114,1000,301,800,156,-294,228,228,-138,97,-106,-70,-26,157,-538,658,1000,232,978,610,340,-412,424,485,428,657,544,-1000,770,635,-70,660,613,-836,-130,1000,-618,-437,-212,183,1000,-859,30,225,-237,307,334,-373,-824,-363,319,156,-739,-161,-389,144,-58,59,808,-456}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00473() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getFirstChild():com.google.javascript.rhino.Node",
            new int[]{809,-671,775,-429,357,745,-106,827,909,898,453,186,1000,-1000,-1000,772,242,942,-190,-932,1000,-95,-860,-920,1000,-251,884,668,1000,-704,732,633,810,-223,-1000,1000,969,-1000,-689,533,-1000,-554,84,734,943,-271,24,1000,-879,-1000,-269,-4,-378,-1000,552,1000,218,-77,-1000,402,883,-578,178,912}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00474() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getFirstChild():com.google.javascript.rhino.Node",
            new int[]{-3,929,445,239,337,-1000,606,-379,-697,-1000,-1000,675,157,1000,898,-924,-1000,393,306,904,-1000,1000,1000,1000,-244,1000,274,235,-893,-14,537,-875,-247,-399,-13,-951,-1000,-236,427,-1000,1000,-24,785,-339,-926,-895,324,-568,1000,1000,1000,-818,1000,1000,53,-795,505,-1000,847,-162,-858,607,1000,-399}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00475() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getFirstChild():com.google.javascript.rhino.Node",
            new int[]{89,-356,412,-416,84,877,661,935,6,219,604,-114,799,-152,-660,44,553,634,-96,468,707,-216,-86,499,365,-571,224,700,751,802,810,222,733,136,-760,896,222,-607,-715,867,-728,-493,-479,-286,745,-59,64,612,-493,65,-2,-633,-686,-905,514,876,-234,159,-725,979,10,436,112,-488}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00476() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getFirstChild():com.google.javascript.rhino.Node",
            new int[]{1000,9,-930,13,581,-779,37,658,-259,-216,-504,354,561,-440,-960,-902,-699,677,1000,-367,-656,-153,-390,-228,-102,-187,7,825,444,-268,-252,437,331,-1000,168,385,-585,-565,404,-1000,-664,-98,-188,129,-545,-835,1000,673,-309,-376,444,11,65,1000,1000,792,282,633,565,172,-47,-36,157,66}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00477() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getFirstChild():com.google.javascript.rhino.Node",
            new int[]{426,389,-3,-417,-232,363,261,589,-196,-44,29,-188,-180,437,-250,-279,-485,-30,-538,1000,720,577,-498,1000,297,-298,632,705,-107,899,1000,-1000,989,630,199,280,316,-483,-47,536,-204,-530,-432,-525,204,-742,-151,478,193,556,600,-816,-455,-370,346,423,-328,-752,-111,771,-475,814,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00478() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getFirstChild():com.google.javascript.rhino.Node",
            new int[]{1000,563,121,-835,-98,-729,431,1000,-1000,446,-1000,107,985,384,-1000,-964,377,1000,1000,426,-178,747,-1000,-575,-766,102,-15,1000,32,-208,436,982,-245,-1000,688,-545,-961,179,633,-327,-846,-645,-48,-416,-970,-882,707,-335,-506,-266,1000,-260,189,726,1000,1000,418,540,-387,719,-1000,1000,274,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00479() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getFirstChild():com.google.javascript.rhino.Node",
            new int[]{1000,-291,41,395,1000,362,144,1000,893,481,-81,604,-170,-1000,-1000,561,-200,930,866,-1000,-582,-86,-885,-1000,431,299,485,511,1000,538,-495,1000,435,-714,-1000,1000,217,-1000,-111,-408,-1000,-96,706,1000,983,-726,257,1000,-1000,-1000,-138,578,-187,601,1000,857,91,767,-1000,-586,1000,-1000,-767,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00480() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getFirstChild():com.google.javascript.rhino.Node",
            new int[]{-579,848,-401,526,-117,598,-109,-1000,-149,-1000,-336,0,-1000,1000,1000,-371,-879,-345,-256,1000,702,1000,511,1000,276,-147,242,455,-407,216,678,-1000,770,-153,1000,-828,760,-765,-94,1000,566,-459,-127,53,616,-859,1000,-1000,1000,1000,1000,-688,-645,195,-657,-1000,-904,-500,531,-177,-461,327,808,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00481() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getFirstChild():com.google.javascript.rhino.Node",
            new int[]{-312,229,71,-764,-361,103,244,499,-422,-128,-56,-366,-62,582,-312,-369,44,723,1000,1000,425,1000,265,1000,279,-249,440,1000,-24,757,1000,-313,970,-10,314,116,188,-332,-328,468,-315,-674,-526,-828,-115,-334,342,415,377,663,755,-1000,-321,-373,514,537,-151,-432,-1000,1000,-638,1000,-434,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00482() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getFirstChild():com.google.javascript.rhino.Node",
            new int[]{1000,-671,775,-264,766,236,740,1000,178,327,124,186,1000,-1000,-1000,134,242,1000,1000,-932,-579,-937,-1000,-920,-122,69,14,671,1000,456,-229,1000,381,-791,-1000,1000,-458,-629,-409,-430,-1000,-106,211,310,566,-360,345,1000,-1000,-1000,-82,-4,-224,-170,1000,1000,135,1000,-1000,224,693,-377,-685,924}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00483() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getFirstChild():com.google.javascript.rhino.Node",
            new int[]{-537,224,728,1000,-138,-1000,0,-92,560,-668,-258,-2,-1000,634,1000,-929,-218,748,-255,142,0,490,-45,-785,-920,-2,-872,599,-322,311,-169,-772,-42,503,536,-1000,108,0,1000,-54,354,639,264,1000,805,558,-1000,-961,1000,782,-705,205,-372,0,-1000,-1000,297,108,-695,-549,246,877,-7,200}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00484() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getFirstChild():com.google.javascript.rhino.Node",
            new int[]{1000,-671,775,-847,-474,-1000,467,1000,-625,1000,500,-612,1000,-464,-1000,-201,1000,937,233,470,195,-891,-889,-477,-122,-1000,-420,790,1000,36,1000,500,365,-270,-932,730,-865,-482,-258,-302,-330,-106,-803,-1000,-416,79,598,1000,-527,-398,-37,-541,215,-1000,660,1000,1000,819,-96,1000,-628,1000,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00485() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getFirstChild():com.google.javascript.rhino.Node",
            new int[]{228,-731,424,-391,262,445,999,734,66,-122,130,-599,856,-254,-362,275,231,681,233,-210,187,421,-1000,255,255,-248,-131,1000,220,732,1000,168,486,-419,-697,384,349,-407,-302,307,-635,-726,35,-306,559,-607,951,-109,-71,829,298,-604,-496,-743,660,430,-207,-450,-1000,295,-163,426,349,-20}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00486() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getFirstChild():com.google.javascript.rhino.Node",
            new int[]{-27,744,-693,-70,-238,-223,823,-83,-1000,-836,-525,-76,-1000,854,38,-892,-265,308,1000,1000,-1000,16,572,591,-1000,163,-241,656,-75,-248,20,-93,138,-347,714,-500,-884,136,238,-329,1,-85,-145,-727,-159,-638,592,-776,206,567,1000,-693,-237,1000,946,-32,-473,513,431,268,-1000,843,129,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00487() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getFirstChild():com.google.javascript.rhino.Node",
            new int[]{416,853,-368,-1000,1000,335,-657,-241,-62,-323,-445,547,1000,10,-1000,-923,582,-1000,-687,-965,-765,627,-857,-567,434,794,714,-518,-45,-72,829,-547,-868,-1000,314,-39,-922,445,-763,49,-422,-1000,-1000,514,379,1000,30,562,-242,-361,293,-499,-839,-274,-844,287,855,-31,-622,901,439,-955,1000,960}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00488() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getIndexOfChild(com.google.javascript.rhino.Node):int",
            new int[]{-626,-616,-1000,-736,-1000,-457,948,1000,-275,-109,1000,-389,782,-2,-195,-516,394,-823,193,-1000,618,-642,292,744,-174,334,-408,-1000,-599,813,-1000,-637,319,423,874,-1000,-383,7,-566,396,-799,-373,735,994,-366,532,400,-34,315,34,6,-371,626,-1000,914,1000,1000,570,-870,-801,220,280,-759,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00489() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getIndexOfChild(com.google.javascript.rhino.Node):int",
            new int[]{329,-301,422,-378,282,1000,213,-332,364,-1000,874,601,566,1000,734,844,-793,-1000,-271,467,-131,-264,-1000,-753,-706,-433,-262,716,-215,-519,-1000,1000,-941,452,-762,-943,-770,271,-838,-542,168,-1000,659,-838,1000,-228,830,1000,552,1000,1000,-312,-1000,994,334,404,-592,442,-1000,362,-375,-663,718,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00490() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getIndexOfChild(com.google.javascript.rhino.Node):int",
            new int[]{1000,-26,269,410,-518,-210,92,-1000,501,-1000,878,18,461,-142,773,1000,342,-823,132,110,155,-343,-569,-735,-174,269,-113,117,-555,-426,-1000,621,-46,229,-44,-616,-710,85,-420,-598,-609,-777,277,-12,939,-441,505,645,311,922,472,-710,-843,1000,656,-186,-470,339,-842,735,-535,-63,-32,593}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00491() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getIndexOfChild(com.google.javascript.rhino.Node):int",
            new int[]{329,-111,366,-844,230,457,798,-708,359,-137,790,343,1000,-5,831,680,-84,-1000,-1000,-61,-1000,-526,-83,-528,-1000,967,648,494,-120,178,-476,637,-810,60,-1000,-1000,-78,440,528,-281,548,-848,523,-833,806,-336,-570,315,-134,34,225,-312,-138,664,-793,1000,980,190,-1000,-166,-966,18,235,830}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00492() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getIndexOfChild(com.google.javascript.rhino.Node):int",
            new int[]{-837,-71,212,-281,359,921,-1000,-1000,635,-987,497,728,21,954,108,363,-548,-461,-1000,688,-350,-5,-433,-479,7,-1000,-270,700,1000,-728,-1000,955,310,233,-792,-459,-517,524,118,-756,-1000,-976,735,-193,97,-370,807,661,-51,1000,737,534,-940,985,740,-885,-461,-237,-1000,877,-43,-292,619,910}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00493() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getIndexOfChild(com.google.javascript.rhino.Node):int",
            new int[]{370,629,881,-594,-260,579,1000,-1000,635,-1000,1000,-522,-314,-368,1000,1000,688,-1000,-365,-639,-920,-291,-1000,-868,-200,-307,1000,582,-1000,-1000,-1000,866,412,703,-297,-330,-1000,-808,-38,-792,-553,-878,206,29,924,-486,-246,1000,327,-884,69,-608,-1000,1000,425,-269,-1000,-1000,-1000,-196,110,628,-229,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00494() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getIndexOfChild(com.google.javascript.rhino.Node):int",
            new int[]{-518,-776,-617,-834,-423,-1000,1000,926,-542,-115,1000,-1000,706,-1000,-477,-691,709,-564,568,-1000,60,-1000,1000,1000,-412,-165,-1000,-1000,-108,1000,63,-1000,900,1000,1000,-1000,553,508,617,1000,1000,-379,-30,1000,-1000,1000,77,-280,338,-331,12,-108,1000,-1000,-92,1000,1000,464,567,-790,700,240,-1000,-95}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00495() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getIndexOfChild(com.google.javascript.rhino.Node):int",
            new int[]{-712,54,-1000,-803,-821,-1000,132,1000,-150,121,739,-235,387,-1000,73,-834,1000,18,-153,-677,-1000,-827,1000,1000,-1000,1000,301,-438,1000,1000,1000,-1000,399,-730,395,-428,410,132,1000,744,284,447,-1000,1000,-366,332,-1000,-1000,-984,-380,-1000,3,1000,-1000,-627,1000,1000,1000,196,-1000,155,703,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00496() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getIndexOfChild(com.google.javascript.rhino.Node):int",
            new int[]{1000,699,422,-733,325,1000,-1000,-332,364,-786,-251,1000,384,1000,1000,1000,-305,-1000,-1000,100,-1000,522,-720,-1000,-1000,970,788,1000,-120,295,-1000,1000,-499,1000,-1000,-918,-37,407,124,-1000,-1000,-1000,653,-1000,1000,-800,830,1000,552,631,1000,-53,-1000,1000,-177,787,-592,174,-1000,-192,-814,-1000,235,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00497() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getIndexOfChild(com.google.javascript.rhino.Node):int",
            new int[]{450,-507,-5,-327,1000,441,-226,-765,409,-609,912,1000,1000,-653,742,1000,242,414,-875,1000,-5,-364,71,47,-903,33,1000,1000,32,-679,989,872,-831,-58,-682,396,-39,854,-1000,-983,-392,-971,-247,-883,-140,-598,-699,-1000,-205,1000,61,-1000,-170,1000,1000,55,-542,416,-718,-346,-957,385,-437,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00498() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getIndexOfChild(com.google.javascript.rhino.Node):int",
            new int[]{1000,803,-562,-346,-859,-33,-1000,122,-863,-49,-345,404,-420,-440,917,363,684,-1000,-1000,-447,-1000,-5,748,-1000,-1000,922,-151,900,1000,1000,-866,13,732,1000,-476,-503,898,624,39,-1000,-404,-649,-815,-562,1000,-331,-161,-209,-126,-31,66,710,391,1000,-414,602,585,709,-204,-405,365,-845,-1000,-404}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00499() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getIndexOfChild(com.google.javascript.rhino.Node):int",
            new int[]{127,-672,422,320,667,1000,-505,-332,507,-1000,890,-417,330,1000,620,934,-972,-975,537,1000,1000,-180,-1000,-753,-1000,-1000,-1000,609,-369,-1000,837,1000,-813,262,-831,-21,-1000,776,-1000,-412,151,-791,659,-838,1000,1000,1000,1000,1000,1000,1000,49,-1000,994,1000,-257,1000,504,977,1000,821,-886,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00500() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getIndexOfChild(com.google.javascript.rhino.Node):int",
            new int[]{-329,-767,-720,-794,1000,-506,-575,-1000,-1000,-1000,1000,1000,966,-127,1000,1000,1000,500,-1000,-26,-16,-430,-844,-132,-1000,-763,691,845,400,275,-1000,-273,-954,25,-886,144,49,798,1000,-825,330,-449,-585,40,240,836,-1000,127,-945,1000,-523,-759,447,1000,224,238,845,312,-601,-566,-148,-38,-287,619}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00501() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getIndexOfChild(com.google.javascript.rhino.Node):int",
            new int[]{-362,803,298,-446,171,702,1000,-368,35,-441,-30,-744,-329,-310,710,399,296,134,-817,-447,-927,-266,599,-868,-267,1000,1000,643,-1000,99,341,-287,389,494,-195,-149,665,-221,39,-1000,-849,-257,1000,-596,692,-331,-350,738,919,-195,-223,-242,391,1000,-212,-237,-369,170,-1000,-405,-554,-81,-919,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00502() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getIndexOfChild(com.google.javascript.rhino.Node):int",
            new int[]{-206,279,-617,-231,-867,-765,-293,86,-1000,-721,22,775,-1000,-1000,242,-399,1000,-1000,354,-538,-775,-790,1000,738,-1000,-298,-988,-436,1000,348,1000,-923,1000,1000,753,334,1000,1000,1000,1000,1000,280,-163,304,303,554,-1000,-879,-237,452,-213,1000,-921,136,-980,551,-155,459,1000,102,1000,-444,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00503() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getIndexOfChild(com.google.javascript.rhino.Node):int",
            new int[]{-885,-756,-617,-504,-867,-1000,764,926,-782,-356,1000,-417,-309,-1000,-302,-691,1000,-649,1000,-1000,357,-716,657,1000,-1000,-889,-1000,-1000,1000,833,837,-1000,889,645,1000,49,398,673,617,1000,847,249,-1000,1000,-203,1000,-1000,-631,288,497,-522,340,1000,-1000,-92,906,1000,504,977,-367,821,349,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00504() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getInputId():com.google.javascript.rhino.InputId",
            new int[]{-808,-777,497,-1000,-1000,-91,139,-187,286,576,-196,1000,547,647,-148,-1000,-169,-722,-460,-139,-1000,-646,515,887,-65,689,-648,108,871,1000,-199,-1000,431,932,1000,584,1000,-519,237,-559,-1000,-221,1000,862,-623,315,-961,151,-668,-518,668,361,-548,-1000,-467,116,534,361,-1000,-1000,142,-147,-1000,-714}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00505() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getInputId():com.google.javascript.rhino.InputId",
            new int[]{341,569,-498,1000,-345,-599,958,-980,119,143,244,103,1000,743,578,-1000,-741,827,-97,-879,1000,1000,-831,1000,709,-1000,1000,61,-65,-794,962,208,-1000,-382,74,350,567,-567,-31,-769,140,1000,-797,47,565,-172,1000,-1000,708,-633,1000,-131,1000,-338,-232,-940,-1000,1000,-186,95,-81,-28,326,758}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00506() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getInputId():com.google.javascript.rhino.InputId",
            new int[]{-473,-431,1000,-713,1000,-249,-742,838,-267,-640,-464,344,-1000,765,-1000,-1000,951,415,1000,-1000,-1000,1000,-1000,265,84,1000,-710,459,-692,-596,457,693,113,-32,-896,487,408,1000,1000,261,920,348,-281,-92,427,662,-974,98,391,-1000,22,-597,-575,-221,630,-301,-1000,-880,-294,274,1000,-1000,-686,-642}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00507() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getInputId():com.google.javascript.rhino.InputId",
            new int[]{-1000,594,108,-1000,-613,-265,111,999,-793,-1000,-183,-1000,-584,540,-599,-479,31,777,1000,313,701,-292,848,-274,974,-149,121,-1000,-904,-1000,410,-493,616,-370,-1000,-11,-1000,-618,751,-239,630,-799,-227,-1000,-357,-851,425,448,-175,53,-929,679,-899,1000,-225,953,-1000,-586,-299,1000,-71,815,108,658}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00508() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getInputId():com.google.javascript.rhino.InputId",
            new int[]{-782,-356,666,64,1000,-1000,55,167,286,576,457,477,-130,647,1000,-400,-103,786,612,-206,-644,958,-181,806,436,-598,-696,146,871,-169,351,677,465,198,726,1000,1000,1000,689,-577,-182,263,361,353,-309,-17,-614,1000,236,-811,778,141,-649,1000,942,-683,-271,-982,-43,431,-130,-865,-537,-380}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00509() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getInputId():com.google.javascript.rhino.InputId",
            new int[]{628,673,-896,1000,15,-243,498,-1000,889,97,-1000,-1000,535,624,-278,-122,-182,705,-400,-1000,1000,333,-1000,430,55,-20,1000,249,9,-1000,1000,342,-1000,-971,-624,214,228,-360,154,-437,947,-7,-1000,-48,1000,-723,1000,-1000,527,-4,612,-44,1000,933,-587,-1000,-587,1000,314,1000,-556,819,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00510() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getInputId():com.google.javascript.rhino.InputId",
            new int[]{599,174,-640,1000,53,471,734,-1000,205,-167,-1000,-1000,-142,517,530,-1000,961,862,854,-778,690,1000,-398,723,649,-1000,1000,1000,-359,-1000,277,255,-1000,-1000,-1000,1000,-2,-1000,196,-535,1000,622,-1000,-736,-317,-788,1000,-1000,1000,-445,1000,603,919,-184,-87,-1000,-727,1000,-1000,1000,-837,-377,45,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00511() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.InputId", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getInputId():com.google.javascript.rhino.InputId",
            new int[]{-1000,-226,197,941,1000,-438,284,-365,-157,-727,-302,-160,657,665,1000,-157,1000,1000,1000,-312,-168,1000,-83,802,762,-1000,-1000,920,-1000,-1000,169,1000,-167,-388,395,824,-858,-235,352,-654,600,606,-892,-391,17,-320,9,75,1000,-625,612,370,-302,302,1000,-1000,-1000,49,612,1000,1000,-993,55,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00512() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getInputId():com.google.javascript.rhino.InputId",
            new int[]{-977,2,-485,-95,-936,-969,909,795,-421,23,542,644,9,193,1000,1000,-8,-219,-65,465,-566,333,729,947,1000,-981,-1000,-841,583,496,-472,-1000,1000,864,-1000,823,-1000,-81,-284,-82,784,-237,-716,212,-1000,1000,892,386,-1000,-960,-1000,-660,-272,1000,732,950,-1000,-1000,-1000,1000,-497,222,-635,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00513() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getInputId():com.google.javascript.rhino.InputId",
            new int[]{-1000,-676,68,-1000,-1000,180,-1000,871,-273,-964,-183,-1000,-638,873,-1000,1000,284,170,269,401,-1000,527,789,-329,551,48,294,-612,-481,-822,-77,-1000,589,-404,-927,1000,-1000,-1000,-45,-23,630,-834,-185,-845,-324,-1000,-129,387,-100,289,-929,1000,-689,984,-813,968,-1000,-76,-299,1000,-341,428,-624,798}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00514() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getInputId():com.google.javascript.rhino.InputId",
            new int[]{-1000,-286,492,521,749,-232,-241,48,257,-1000,633,-13,184,966,-419,1000,-169,514,-573,-471,-1000,694,-141,1000,1000,718,-1000,233,-381,670,1000,63,-87,1000,506,1000,-929,77,727,-1000,-1000,-341,767,-1000,-1000,1000,-1000,1000,-962,-1000,915,-272,-1000,148,826,135,-1000,-842,-1000,-828,1000,-1000,45,-888}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00515() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getInputId():com.google.javascript.rhino.InputId",
            new int[]{341,163,107,1000,-100,-1000,172,-400,-228,143,71,746,330,863,578,-1000,-1000,1000,1000,-792,1000,1000,-956,1000,699,-1000,-267,168,-390,-1000,997,430,-1000,1000,33,678,372,-1000,401,-312,140,1000,-1000,803,1000,-509,994,-1000,1000,-374,971,375,923,-690,-116,-1000,-1000,1000,458,889,-81,-708,-592,903}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00516() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getInputId():com.google.javascript.rhino.InputId",
            new int[]{-332,-311,69,-664,-984,-644,707,-607,142,183,-224,-1000,1000,720,-159,753,-1000,-646,-977,-485,147,-505,-122,1000,-66,689,108,-521,1000,1000,362,-1000,-153,733,1000,254,1000,-539,-111,-610,-1000,-1000,894,578,-55,410,-95,-601,-872,-470,397,-65,477,-1000,-1000,31,342,1000,-1000,-1000,141,1000,-804,-357}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00517() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getInputId():com.google.javascript.rhino.InputId",
            new int[]{-346,-777,-217,-1000,-1000,477,904,930,-448,1000,-463,1000,660,198,499,700,-827,-1000,-711,637,-819,-318,1000,1000,504,202,62,-1000,1000,1000,-723,-1000,1000,1000,-614,1000,-61,-68,-444,14,-169,-263,436,1000,-1000,1000,385,440,-1000,-569,-1000,-742,-331,275,-1000,1000,-194,-1000,-1000,-819,-342,611,-1000,433}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00518() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getInputId():com.google.javascript.rhino.InputId",
            new int[]{-1000,-431,-46,-728,-1000,-436,-887,380,641,344,156,-1000,-19,765,227,1000,284,-422,269,301,-1000,-224,789,-159,84,48,-69,-1000,77,-133,-77,-1000,113,-32,-187,737,-1000,-1000,-219,594,920,-557,409,188,482,-1000,-129,101,-318,556,-1000,580,102,78,-813,901,-687,589,457,631,-797,1000,547,345}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00519() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getInputId():com.google.javascript.rhino.InputId",
            new int[]{157,-692,487,1000,952,254,-944,-86,514,-639,-1000,-1000,-785,715,-860,-856,1000,718,642,-527,-1000,699,-832,-506,-552,790,-79,810,-738,-1000,-240,1000,-856,-127,-120,99,143,31,466,-316,-574,-106,126,-263,906,-822,-237,-127,1000,-702,1000,802,54,-370,940,-913,-550,520,563,-28,-400,-316,165,-522}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00520() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getIntProp(int):int",
            new int[]{270,744,42,-618,234,-219,-637,-962,-1000,1000,-214,91,-972,173,-255,1000,850,1000,930,-157,998,908,1000,1000,-363,1000,1000,1000,-1000,-1000,1000,468,825,-180,550,254,-1000,376,1000,-843,1000,-326,-1000,-691,-1000,-1000,-1000,252,75,-493,-146,853,1000,1000,210,389,-662,-1000,225,1000,1000,1000,679,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00521() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getIntProp(int):int",
            new int[]{-453,14,186,868,201,1000,845,-530,1000,-1000,-523,-1000,1000,311,860,-643,139,961,835,-1000,-1000,-1000,593,1000,-56,815,901,-1000,-580,-47,30,648,-1000,-421,785,-1000,126,774,-315,-983,-141,120,608,-1000,909,-1000,244,-1000,137,385,16,-938,-28,-1000,-783,20,1000,582,1000,-74,-1000,-885,-430,-572}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00522() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getIntProp(int):int",
            new int[]{-127,-251,776,-908,506,246,-72,-517,-666,1000,512,-780,831,-394,238,-513,-607,246,1000,-830,-45,-843,-435,-514,-385,-186,774,-758,-664,565,787,-171,-762,331,562,-634,182,-496,923,-619,-205,52,276,-75,371,118,285,-66,1000,-1000,70,843,-495,182,89,-151,663,215,-152,660,-626,1000,-330,-834}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00523() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getIntProp(int):int",
            new int[]{-561,214,-246,799,-95,270,-490,141,-792,-692,-1000,-1000,-119,-623,745,-224,-759,1000,632,-1000,-209,56,352,-1000,-524,857,1000,978,-606,-1000,787,256,-195,1000,1000,-1000,405,1000,570,-446,336,327,-1000,-801,-76,-763,-1000,1000,464,-69,508,815,344,1000,-729,492,-140,-920,650,925,838,-207,1000,-310}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00524() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getIntProp(int):int",
            new int[]{500,299,-483,373,-91,-423,-357,652,-855,288,-312,-1000,-891,195,575,294,-1000,1000,-516,-597,-80,1000,-203,-772,-981,270,244,881,202,400,170,-47,204,1000,197,461,508,-197,396,1000,594,820,-396,896,-627,310,-175,1000,685,296,-274,717,1000,1000,-887,-664,-1000,-1000,-322,1000,431,168,1000,507}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00525() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getIntProp(int):int",
            new int[]{423,839,-1000,-1000,140,-476,-751,828,-1000,659,-214,974,-651,-152,-12,1000,-415,-221,-915,-122,474,1000,-787,-1000,-514,-368,-819,416,-1000,39,289,367,-344,1000,-231,-572,289,617,552,-6,876,957,579,894,157,26,-655,-599,-638,815,-188,290,-854,1000,-1000,-1000,1000,-216,-563,188,758,226,930,-482}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00526() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getIntProp(int):int",
            new int[]{-1000,219,-1000,-32,-447,-1000,645,-407,-1000,-963,-1000,-604,206,166,-412,-768,-545,-635,462,-1000,446,-1000,631,-99,147,-488,-632,-58,-934,120,-310,-47,-1000,20,632,644,-799,180,29,-730,-937,-324,505,-11,1000,-487,381,-451,693,-602,-58,578,933,-1000,-63,-44,719,947,793,482,292,-234,717,-420}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00527() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getIntProp(int):int",
            new int[]{423,664,776,-193,262,-230,-72,-407,731,-840,646,-877,844,-469,-767,-937,963,-791,1000,-785,-1000,-1000,-1000,1000,-273,1000,774,-1000,-653,-1000,835,-1000,-782,121,162,-634,182,1000,923,-1000,376,52,276,-146,371,118,353,18,1000,-1000,26,-581,94,-915,-344,567,930,496,265,21,-427,426,-708,-130}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00528() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getIntProp(int):int",
            new int[]{-1000,-461,268,-674,-1000,-65,1000,681,67,-1000,-284,-723,-27,-192,17,-453,-1000,710,195,-865,524,-1000,682,231,237,-539,-142,-431,487,203,-261,1000,-1000,861,374,-210,291,852,-572,-244,-1000,803,1000,-314,-355,-1000,-10,-897,-495,270,-199,-434,-1000,-1000,-819,109,804,821,930,24,-1000,-1000,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00529() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getIntProp(int):int",
            new int[]{-123,634,6,-348,-235,-715,-165,69,-1000,623,550,129,88,230,-18,226,224,-35,150,-796,13,137,157,-739,-461,-233,-109,123,-316,-31,-400,367,-718,728,552,439,-1000,-534,318,-1000,89,-218,-1000,622,101,252,-158,-522,418,-434,220,1000,401,573,-661,-519,-587,239,-68,747,519,155,716,-400}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00530() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getIntProp(int):int",
            new int[]{423,664,-967,-13,-807,195,-72,571,731,-840,444,-45,203,-377,403,-639,-506,885,-750,-521,148,-729,-604,262,-322,910,-843,-822,991,720,394,-717,-941,-612,-112,-155,901,794,-39,682,446,998,839,857,915,725,928,904,-32,70,-753,-581,-916,-944,-949,-536,363,649,922,10,-728,-194,-541,431}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00531() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getIntProp(int):int",
            new int[]{-928,-542,-524,-426,-984,-130,885,-407,731,-1000,-354,394,-154,1000,-597,334,-870,926,-502,-731,488,-277,125,497,-145,24,-1000,-668,-71,1000,-324,642,-947,107,-865,-984,182,1000,-497,275,-790,969,1000,244,1000,-1000,353,-57,-84,1000,-218,-248,-6,-915,-1000,-752,231,769,1000,-513,-427,-690,555,-379}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00532() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getIntProp(int):int",
            new int[]{-596,184,-1000,516,564,-891,625,77,-1000,-1000,-1000,-372,-1000,320,480,323,-1000,619,-412,-763,702,53,1000,1000,-665,-488,-990,1000,-1000,806,-194,249,-203,-115,440,1000,-1000,132,-206,360,-500,119,-1000,99,418,-352,-332,3,472,306,-504,712,1000,-176,-328,-313,-254,-564,954,1000,1000,-696,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00533() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getIntProp(int):int",
            new int[]{689,-26,-1000,-1000,829,-866,-1000,556,-1000,-655,1000,377,-1000,-674,-1000,98,-904,-841,-248,66,-145,728,-1000,-1000,-645,-273,-1000,354,388,-20,521,-1000,-152,699,-140,461,870,369,379,1000,36,812,573,1000,853,1000,-815,1000,412,290,-345,903,-511,892,-1000,-1000,-599,324,-349,-45,-58,1000,61,917}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00534() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getIntProp(int):int",
            new int[]{642,-917,-359,-586,393,-743,-233,599,-943,323,354,237,-755,206,436,723,-94,513,107,448,631,894,-512,-536,333,-175,-979,490,999,-519,137,100,-430,902,-734,225,966,352,630,601,751,440,275,208,-987,344,-575,359,-336,328,-650,-343,-472,607,730,-253,-615,-399,-298,509,393,-402,696,141}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00535() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getIntProp(int):int",
            new int[]{-768,-27,77,291,-670,798,139,266,646,-1000,-1000,-1000,439,-785,661,-311,-626,1000,571,-478,-488,-1000,281,1000,-225,502,1000,-414,440,-581,656,842,-1000,549,631,-1000,150,1000,57,-433,16,469,486,-1000,667,-607,-517,-1000,-501,-9,-105,-635,-1000,-716,-376,840,1000,0,738,187,-925,-842,492,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00536() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getJSDocInfo():com.google.javascript.rhino.JSDocInfo",
            new int[]{-496,529,-205,247,-1000,288,-393,842,-1000,331,-660,682,-1000,679,-215,937,812,-366,640,-340,486,809,-1000,726,-684,-633,-197,-1000,-671,359,-82,-356,-214,-252,556,-378,510,10,1000,1000,886,432,-1000,-313,-268,723,998,983,1000,390,238,-544,753,-1000,553,355,-153,-1000,-167,69,-673,3,-283,-711}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00537() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getJSDocInfo():com.google.javascript.rhino.JSDocInfo",
            new int[]{-1000,4,-573,-696,616,655,-678,231,986,110,-421,-775,-724,569,1000,-368,1000,-872,495,442,201,-1000,-17,665,1000,1000,892,-671,-1000,536,1000,-285,1000,-218,1000,-400,-911,1000,1000,-443,-540,-828,-1000,123,-121,115,591,769,1000,1000,-704,-1000,-1000,-1000,-1000,1000,413,546,295,-338,1000,322,427,635}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00538() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.JSDocInfo", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getJSDocInfo():com.google.javascript.rhino.JSDocInfo",
            new int[]{-995,-777,913,-915,392,-276,-667,-358,820,-404,-937,-859,-62,-633,-747,51,719,979,319,590,830,-818,450,449,-835,-737,-774,349,47,-569,-593,-254,-56,475,-93,-826,-456,-115,-354,-807,-31,528,-448,743,-409,-804,334,-197,-597,-153,790,694,249,224,-592,-883,345,657,831,45,441,356,303,-998}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00539() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getJSDocInfo():com.google.javascript.rhino.JSDocInfo",
            new int[]{412,-796,-1000,623,829,-747,72,426,314,-631,325,-129,-182,1000,230,-989,87,-1000,662,-89,-1000,-1000,-517,-86,-883,-362,1000,-449,368,432,-1000,69,232,-1000,1000,-1000,-470,-8,1000,105,-1000,-411,201,-858,-500,685,729,485,13,445,898,-52,-1000,-468,963,457,-793,-1000,-229,-571,1000,761,-739,123}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00540() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getJSDocInfo():com.google.javascript.rhino.JSDocInfo",
            new int[]{1000,-712,-804,562,11,-1000,1000,624,1000,663,290,-922,-159,1000,-871,-777,-1000,-1000,603,978,569,-1000,921,-1000,297,1000,124,1000,-141,-1000,-368,-964,1000,-1000,1000,702,-1000,-692,1000,-214,-810,-1000,1000,-392,-287,799,-904,-1000,-1000,268,538,706,-743,-51,-427,-632,-485,-1000,-1000,-816,1000,191,925,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00541() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getJSDocInfo():com.google.javascript.rhino.JSDocInfo",
            new int[]{1000,-427,-637,634,642,121,-461,804,775,327,567,82,300,553,-222,167,-768,1000,361,1000,-1000,465,486,404,374,-261,-392,-525,-850,247,487,-906,1000,-1000,-197,1000,947,-1000,-771,458,-392,-1000,501,-1000,-432,1000,-577,-765,-1000,-228,1000,616,678,131,31,-594,-931,-1000,-160,-1000,-493,-711,-645,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00542() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getJSDocInfo():com.google.javascript.rhino.JSDocInfo",
            new int[]{1000,-86,-148,696,-1000,-1000,558,-694,-1000,-286,769,1000,-1000,537,-1000,22,-1000,-1000,364,-546,-945,400,-423,-950,-401,-1000,-613,-207,313,-895,-1000,256,-989,-401,310,522,-1000,-96,-636,382,-672,-845,-511,-398,-648,-631,975,-769,-1000,-400,-1000,1000,-45,893,836,-1000,188,-198,-596,-726,-1000,-552,-418,326}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00543() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getJSDocInfo():com.google.javascript.rhino.JSDocInfo",
            new int[]{-218,-91,-765,-566,687,516,-537,20,631,89,892,-694,-82,15,758,-950,1000,141,-878,301,313,-1000,-776,-415,966,870,861,139,-380,486,-1000,557,1000,-1000,976,-1000,95,691,553,-428,-630,123,-883,-135,734,-269,234,554,890,1000,574,-1000,-589,-932,119,784,109,-1000,536,-324,1000,645,-955,-37}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00544() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getJSDocInfo():com.google.javascript.rhino.JSDocInfo",
            new int[]{-571,-811,-354,-561,-330,-723,344,66,353,229,-364,275,-805,311,-532,-563,400,-1000,1000,-99,1000,-1000,-42,-453,-195,-493,338,-1000,-595,-468,-93,-432,711,-786,1000,-400,-1000,184,318,15,-178,-214,-1000,19,147,111,218,867,323,41,-41,130,-562,-499,-70,-388,290,-1000,-712,-527,1000,-51,545,-39}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00545() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.JSDocInfo", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getJSDocInfo():com.google.javascript.rhino.JSDocInfo",
            new int[]{-91,-981,-648,-616,1000,1000,-1000,29,-343,-400,691,-1000,827,99,1000,871,1000,580,-405,543,-819,764,-234,734,-178,967,151,706,-1000,785,196,1000,655,-1000,164,-1000,1000,-421,599,-1000,114,-438,-866,-546,304,519,-339,1000,1000,1000,113,-1000,829,-414,-32,1000,-599,-859,985,613,-504,1000,-1000,-74}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00546() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getJSDocInfo():com.google.javascript.rhino.JSDocInfo",
            new int[]{896,-452,453,-1000,-1000,-1000,626,-1000,-58,1000,1000,543,-476,-257,-1000,-283,203,-42,-157,-568,-1000,1000,-85,-544,-263,-632,-598,953,-314,-906,-1000,1000,-1000,-260,-9,-1000,-32,-152,-1000,-1000,-161,1000,-408,139,649,-614,818,885,25,-1000,193,1000,733,939,730,-788,707,145,-189,-297,-132,428,-561,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00547() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getJSDocInfo():com.google.javascript.rhino.JSDocInfo",
            new int[]{-1000,689,-297,-950,1000,434,-433,-1000,-736,-909,554,-1000,889,-407,1000,565,1000,580,-1000,292,161,105,-492,665,-535,1000,978,1000,-689,-7,-153,1000,1000,-500,353,-1000,576,296,1000,-1000,209,-224,-1000,145,879,-610,253,1000,1000,1000,-707,-1000,201,-325,-281,1000,122,75,957,1000,37,1000,-623,-797}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00548() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getJSDocInfo():com.google.javascript.rhino.JSDocInfo",
            new int[]{1000,-411,-77,302,1000,442,-709,-1000,853,39,204,-1000,34,120,1000,-279,1000,1000,-406,642,-1000,27,-327,666,-120,1000,1000,177,-107,-698,-1000,1000,-711,-140,-75,-1000,684,1000,-542,-1000,-1000,787,1000,325,-1000,-1000,1000,919,-1000,272,-101,-391,-486,1000,792,-944,787,1000,1000,1000,-784,1000,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00549() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getJSDocInfo():com.google.javascript.rhino.JSDocInfo",
            new int[]{224,-518,215,-937,1000,276,626,-1000,967,-120,1000,-1000,1000,-1000,-1000,510,1000,1000,-1000,-568,-99,666,-85,438,625,1000,140,1000,-1000,-886,864,1000,282,22,-1000,-1000,1000,-152,-523,-1000,-161,-702,-1000,16,612,-1000,818,1000,1000,-1000,-648,-1000,688,1000,-1000,1000,277,1000,-189,1000,-476,166,-485,-344}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00550() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getJSDocInfo():com.google.javascript.rhino.JSDocInfo",
            new int[]{-878,892,878,-742,-9,-504,640,1000,-148,265,272,678,-555,-139,165,-1000,59,336,-348,-119,121,-888,1000,173,718,445,-172,-605,47,28,-110,-735,107,-640,458,408,-162,-115,-973,5,279,694,1000,737,-409,-40,367,375,334,33,-22,527,520,-99,-262,-245,-51,507,831,45,-846,313,480,-390}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00551() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getJSDocInfo():com.google.javascript.rhino.JSDocInfo",
            new int[]{-378,-791,-1000,275,-313,-220,673,-73,1000,-423,361,-440,-1000,-1000,-514,-467,741,-836,160,123,-81,-1000,-221,228,976,850,183,299,127,-1000,-1000,1000,656,-1000,1000,-875,-893,1000,1000,-367,-1000,615,-519,518,1000,-136,682,-28,-507,630,-302,-739,-1000,-290,927,1000,71,-1000,-9,-506,1000,512,-111,-653}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00552() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getJSType():com.google.javascript.rhino.jstype.JSType",
            new int[]{782,-236,-1000,-1000,646,-28,-380,-400,-730,-16,1000,-796,281,1000,-53,-832,-496,1000,1000,968,-843,1000,-608,-528,541,-781,213,-1000,531,-145,-1000,-1000,-513,616,-508,-733,-479,-499,-257,-159,-171,1000,-1000,905,-780,196,1000,1000,-536,-288,864,1000,1000,-1000,1000,-126,929,-188,-247,-722,-806,-1000,1000,934}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00553() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getJSType():com.google.javascript.rhino.jstype.JSType",
            new int[]{-742,-731,-658,942,129,936,861,-506,456,21,-418,102,-986,274,595,-25,534,-205,188,-34,-405,-344,745,-134,-383,-179,325,-8,155,197,-247,-568,-771,-449,428,223,-873,525,-519,-746,-236,994,-623,-256,-503,605,635,-226,-917,504,939,545,402,-12,-430,-223,-518,61,858,-10,-585,782,125,-730}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00554() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getJSType():com.google.javascript.rhino.jstype.JSType",
            new int[]{-1000,239,1000,-282,-119,-417,-115,216,-759,86,1000,826,1000,-408,932,1000,-1000,296,1000,-199,373,-130,-214,1000,220,-556,-536,-28,-786,951,-473,325,1000,849,229,-473,-172,-902,80,-1000,-13,-303,-1000,-402,84,-287,-85,971,-251,441,-768,146,-785,108,786,497,-336,-1000,252,590,1000,-1000,-659,-629}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00555() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getJSType():com.google.javascript.rhino.jstype.JSType",
            new int[]{728,229,-1000,1000,-1000,456,-293,-363,-586,961,667,674,-855,495,342,353,-167,652,693,726,-679,433,-360,-900,433,-640,219,82,660,-456,1000,-432,-926,165,-526,657,-450,-419,-724,372,708,887,-708,648,-713,578,650,451,-54,-88,764,386,115,-671,-623,1000,472,111,-302,301,-253,-877,979,153}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00556() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getJSType():com.google.javascript.rhino.jstype.JSType",
            new int[]{-1000,324,329,-578,844,44,488,1000,-987,85,-1000,374,-194,-820,-919,441,375,-1000,-628,1000,-1000,1000,-608,196,1000,-781,-827,1000,-1000,275,-187,932,973,11,-1000,1000,-476,-240,-1000,73,-171,-535,208,-4,1000,-500,-108,1000,-164,-1000,422,-724,550,-195,312,-1000,140,56,-233,-337,654,-17,-377,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00557() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getJSType():com.google.javascript.rhino.jstype.JSType",
            new int[]{-1000,209,-970,622,-455,610,-179,-400,-1000,-172,7,-551,-842,-308,-53,-1000,1000,1000,-492,673,-1000,-762,221,1000,686,-1000,-318,1000,531,-1000,927,482,-514,616,-913,923,-1000,-499,-1000,-507,252,-248,-1000,-20,898,-726,187,-577,600,-660,1000,-1000,1000,-362,-397,-1000,312,-1000,-108,-82,-221,-289,1000,-287}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00558() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getJSType():com.google.javascript.rhino.jstype.JSType",
            new int[]{-1000,-521,-700,-578,1000,178,688,250,-954,-240,-25,-378,172,128,-552,-856,982,-1000,289,882,-1000,1000,-608,-528,862,-781,-593,-310,531,-165,-1000,-150,973,1000,-499,787,-1000,-463,-864,-441,-171,130,-1000,288,882,-709,-25,1000,-750,-1000,1000,272,1000,-1000,1000,-273,717,-210,-220,-1000,708,-434,659,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00559() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getJSType():com.google.javascript.rhino.jstype.JSType",
            new int[]{807,-236,1000,-309,-415,-41,-192,-1000,907,61,1000,742,-130,1000,925,943,-1000,1000,1000,-294,881,116,1000,-1000,-102,71,-200,-364,227,168,-400,-859,-545,616,291,-130,850,196,-415,-197,-58,954,-269,-381,-1000,664,-315,62,-11,1000,-232,1000,-994,540,-770,1000,-899,-106,-247,1000,-806,-674,-294,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00560() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getJSType():com.google.javascript.rhino.jstype.JSType",
            new int[]{-891,-221,-1000,925,637,241,843,646,-489,-759,-1000,-852,-1000,-553,-805,-693,1000,902,-497,820,-1000,-267,-655,531,698,-1000,218,948,603,-486,1000,159,31,74,-527,1000,-1000,-631,-1000,395,777,-142,-297,-96,447,295,441,-243,-376,-896,1000,-855,1000,-1000,-219,-1000,733,337,519,-677,-392,905,356,670}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00561() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getJSType():com.google.javascript.rhino.jstype.JSType",
            new int[]{1000,-631,-1000,-983,275,898,-858,-1000,-250,131,1000,-577,-650,-140,478,1000,-817,1000,1000,-19,-711,790,-879,-1000,-5,-15,1000,-236,1000,496,-1000,-1000,390,1000,898,-1000,-223,9,-1000,192,984,1000,-832,240,-27,892,1000,930,-687,618,743,1000,-67,-810,697,-982,36,734,998,-47,-1000,-1000,675,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00562() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getJSType():com.google.javascript.rhino.jstype.JSType",
            new int[]{15,474,56,223,-415,206,313,-93,362,-162,667,-54,-925,-78,342,295,-585,652,-22,255,170,-685,1000,-409,-102,-192,-935,525,-132,-256,1000,-102,-1000,-633,-594,657,212,196,-797,-83,-58,623,367,316,-263,492,-5,-830,185,594,249,386,-856,540,-770,-43,-148,-107,-932,612,665,-373,158,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00563() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getJSType():com.google.javascript.rhino.jstype.JSType",
            new int[]{-236,449,987,-417,71,-316,171,-683,-148,59,922,1000,622,-241,875,798,-669,667,1000,-287,928,-938,381,48,735,-220,-238,-163,-692,33,-1000,415,841,471,892,-298,-172,-589,-221,-1000,359,308,-953,-760,-567,159,-158,-26,-81,561,-855,-151,-96,254,246,662,-702,-1000,1000,654,687,-129,-533,-975}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00564() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getJSType():com.google.javascript.rhino.jstype.JSType",
            new int[]{590,659,-998,55,-410,524,169,-506,391,-172,839,-1000,-1000,274,178,-397,-870,1000,238,761,-374,4,745,-1000,-423,-179,325,-305,826,197,1000,-1000,-1000,-1000,-1000,80,234,363,-658,200,-236,1000,3,-256,-867,605,1000,-109,-25,671,264,785,-1000,-12,-770,-404,573,293,858,-10,150,-620,1000,-727}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00565() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getJSType():com.google.javascript.rhino.jstype.JSType",
            new int[]{348,-51,-1000,-653,1000,-503,427,1000,-478,-1000,-352,-991,-168,-486,-1000,-342,652,682,-539,1000,-703,1000,-1000,-1000,1000,-882,-448,187,-447,-479,473,-654,811,1000,-1000,1000,-361,-238,-1000,1000,1000,-584,672,-423,410,332,465,704,237,-1000,227,147,1000,-1000,1000,-47,1000,753,-983,-1000,723,-305,147,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00566() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getJSType():com.google.javascript.rhino.jstype.JSType",
            new int[]{-1000,888,-1000,-444,1000,-493,1000,1000,-997,-1000,1000,-628,-112,-1000,-1000,-1000,1000,-1000,-1000,1000,-1000,-1000,-682,492,1000,439,-1000,1000,-412,776,347,959,1000,1000,-1000,1000,-1000,-1000,-1000,569,198,-1000,400,397,1000,-745,-384,-298,423,-1000,1000,-1000,1000,-1000,1000,-1000,1000,-234,-1000,-1000,1000,-374,85,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00567() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getJSType():com.google.javascript.rhino.jstype.JSType",
            new int[]{-18,-146,1000,-181,275,201,329,-614,622,115,1000,617,-650,182,1000,785,-1000,1000,-22,-219,370,-685,1000,-300,-544,382,-650,-366,-132,496,-1000,-528,-796,-1000,365,-1000,468,651,-24,-630,-447,623,535,-234,-357,492,64,-830,-345,1000,128,1000,-1000,730,697,183,-787,86,-416,-47,312,-233,-172,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00568() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node$FileLevelJsDocBuilder", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getJsDocBuilderForNode():com.google.javascript.rhino.Node$FileLevelJsDocBuilder",
            new int[]{883,299,-776,194,-546,-134,-1000,-931,-568,499,197,376,836,-54,-44,-1000,-391,-699,-785,246,186,400,1000,-9,-581,27,-798,-588,-12,400,-579,-310,400,1000,-537,-214,29,-16,295,727,82,-260,53,291,-527,212,106,-896,574,636,-802,-309,225,-153,598,1000,-328,261,-463,-676,609,-1000,-1000,-800}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00569() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node$FileLevelJsDocBuilder", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getJsDocBuilderForNode():com.google.javascript.rhino.Node$FileLevelJsDocBuilder",
            new int[]{-522,-266,390,-255,1000,-65,-52,-1000,1000,-1000,483,1000,-1000,1000,-1000,-298,141,1000,-458,-305,1000,-1000,963,-1000,-1000,711,-473,609,555,-856,892,1000,-1000,-1000,1000,1000,754,-1000,1000,-1000,-255,-1000,1000,-304,864,-1000,1000,1000,-747,1000,1000,-331,1000,906,-1000,879,463,402,-138,336,-580,-239,37,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00570() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node$FileLevelJsDocBuilder", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getJsDocBuilderForNode():com.google.javascript.rhino.Node$FileLevelJsDocBuilder",
            new int[]{-790,-912,-239,658,-677,990,506,626,596,784,514,-1000,-189,-373,-823,111,-603,-1000,960,-217,-1000,138,-1000,-737,1000,-682,-1000,-572,-457,980,-695,274,828,830,-318,-182,309,-586,-489,-900,-782,1000,255,714,7,-928,1000,1000,-227,-1000,468,-839,-773,-260,344,-606,-14,-1000,397,-691,1000,1000,388,-29}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00571() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node$FileLevelJsDocBuilder", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getJsDocBuilderForNode():com.google.javascript.rhino.Node$FileLevelJsDocBuilder",
            new int[]{-850,429,718,-421,756,1000,609,-931,1000,-388,952,816,-532,1000,-1000,37,-353,187,-154,200,1000,-1000,-669,-1000,-730,-269,-9,-345,88,809,720,-1000,300,-968,1000,588,610,-1000,653,-364,-842,-260,1000,212,-237,-1000,1000,1000,122,750,667,-309,225,-183,-1000,1000,604,-163,748,-676,355,49,331,211}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00572() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node$FileLevelJsDocBuilder", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getJsDocBuilderForNode():com.google.javascript.rhino.Node$FileLevelJsDocBuilder",
            new int[]{-1000,-281,-937,722,-1000,1000,493,1000,376,-296,393,-1000,817,-113,-1000,1000,-1000,-984,-290,-859,-895,1000,-1000,204,723,-838,-649,-1000,-901,1000,-816,-607,1000,1000,-443,-750,657,-1000,32,1000,-1000,999,-78,1000,615,-1000,1000,-1000,-442,-787,-369,-880,-685,-175,1000,826,855,-1000,-627,-1000,1000,577,232,-310}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00573() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node$FileLevelJsDocBuilder", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getJsDocBuilderForNode():com.google.javascript.rhino.Node$FileLevelJsDocBuilder",
            new int[]{-1000,598,-243,-585,-948,1000,404,1000,459,132,359,-402,507,780,-1000,-626,-1000,-181,-950,1000,395,609,-770,-783,-488,-655,-1000,-1000,-225,1000,99,-1000,1000,1000,132,-88,384,-1000,871,1000,-1000,290,444,1000,364,-1000,1000,787,1000,174,-230,-397,-384,-45,237,1000,843,-1000,-381,-1000,1000,-89,69,-396}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00574() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node$FileLevelJsDocBuilder", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getJsDocBuilderForNode():com.google.javascript.rhino.Node$FileLevelJsDocBuilder",
            new int[]{-1000,207,-134,816,-1000,1000,1000,1000,-251,1000,268,-1000,1000,-1000,-1000,1000,-266,-1000,398,-125,-1000,1000,-1000,229,1000,-1000,-906,-1000,-821,1000,-898,1000,1000,1000,-1000,-828,149,453,-1000,872,-1000,1000,-934,1000,-198,346,172,-908,131,-1000,-747,-1000,-1000,-931,1000,-363,-778,-581,-385,-1000,646,1000,114,-983}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00575() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node$FileLevelJsDocBuilder", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getJsDocBuilderForNode():com.google.javascript.rhino.Node$FileLevelJsDocBuilder",
            new int[]{-1000,138,280,-699,-75,-928,260,-684,263,496,1000,1000,-1000,1000,-1000,-1000,1000,-306,-1000,-251,1000,-810,-841,-1000,-1000,538,-30,49,-1000,955,1000,1000,951,496,1000,-273,1000,-1000,1000,191,-1000,-669,113,1000,394,-423,1000,639,498,1000,439,-1000,553,1,434,1000,215,-227,1000,224,1000,-191,-1000,439}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00576() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node$FileLevelJsDocBuilder", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getJsDocBuilderForNode():com.google.javascript.rhino.Node$FileLevelJsDocBuilder",
            new int[]{1000,-56,244,482,1000,-949,-949,-1000,-696,-1000,-759,-980,1000,-548,-502,-15,1000,475,309,-1000,-895,-1000,-86,759,-361,565,-1000,783,1000,-1000,-1000,1000,-1000,53,-179,1000,400,-21,36,-1000,-1000,-539,-544,-639,684,-372,-32,440,-1000,258,817,651,-267,1000,1000,-497,-940,129,-572,399,-1000,479,297,607}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00577() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node$FileLevelJsDocBuilder", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getJsDocBuilderForNode():com.google.javascript.rhino.Node$FileLevelJsDocBuilder",
            new int[]{-422,592,-428,-618,-647,127,-60,-1000,1000,-620,-28,782,-1000,519,-589,-867,266,540,118,767,1000,-176,-104,-308,-1000,-891,117,433,-43,-678,1000,-972,-153,880,221,617,1000,-1000,-52,-1000,-423,79,815,-912,-385,-853,1000,1000,-459,-155,59,-700,78,293,-288,918,1000,423,170,415,-160,-1000,183,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00578() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node$FileLevelJsDocBuilder", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getJsDocBuilderForNode():com.google.javascript.rhino.Node$FileLevelJsDocBuilder",
            new int[]{453,639,285,-779,1000,444,68,-786,568,202,857,1000,-807,1000,-502,-884,53,158,-1000,1000,1000,-888,140,-1000,-1000,712,-87,-450,-963,-971,1000,838,683,-207,1000,45,1000,-1000,1000,191,-821,-1000,478,559,-182,-411,1000,936,465,1000,186,-1000,1000,-75,-18,1000,-113,570,1000,-653,1000,-911,-1000,55}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00579() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node$FileLevelJsDocBuilder", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getJsDocBuilderForNode():com.google.javascript.rhino.Node$FileLevelJsDocBuilder",
            new int[]{-674,-481,683,516,507,422,-904,-1000,-547,-1000,779,374,-1000,663,-1000,-1000,1000,265,-218,272,1000,-1000,-1000,-177,-1000,1000,-584,1000,899,-1000,460,1000,678,511,1000,1000,579,-1000,-871,-1000,342,-1000,1000,490,1000,-1000,559,1000,-1000,-208,1000,-488,1000,1000,-1000,-1000,-987,-200,1000,-467,-594,941,-526,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00580() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node$FileLevelJsDocBuilder", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getJsDocBuilderForNode():com.google.javascript.rhino.Node$FileLevelJsDocBuilder",
            new int[]{-980,359,-1000,-259,-438,206,251,568,-324,203,96,-782,453,853,592,917,-725,-467,-225,-378,-205,160,-419,-138,-870,224,-1000,-307,-1000,371,264,-500,146,1000,-244,-951,1000,-185,184,483,310,110,12,556,774,-505,465,-292,-300,785,-62,-963,361,353,156,686,450,-1000,166,-334,-31,-577,-703,621}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00581() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node$FileLevelJsDocBuilder", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getJsDocBuilderForNode():com.google.javascript.rhino.Node$FileLevelJsDocBuilder",
            new int[]{-1000,629,-1000,120,-1000,1000,-333,1000,-401,907,393,-273,180,509,-774,90,-716,-638,-1000,-243,-449,1000,-136,-146,-420,-188,-1000,-922,-986,1000,295,-1000,977,1000,-298,-1000,657,-185,-38,1000,-1000,166,12,1000,290,-505,431,-1000,693,264,-296,-880,-204,106,1000,1000,405,-1000,-205,-826,963,-577,-813,-109}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00582() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node$FileLevelJsDocBuilder", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getJsDocBuilderForNode():com.google.javascript.rhino.Node$FileLevelJsDocBuilder",
            new int[]{437,473,-364,-517,681,-1000,-179,-1000,-229,909,1000,1000,-1000,614,592,-806,418,-467,-225,1000,-205,-441,-1000,-90,-633,398,1000,492,-1000,-648,1000,-500,-346,-1000,385,-715,1000,307,-346,-787,310,-437,383,-280,-343,418,-460,439,-580,880,572,-1000,481,32,89,-345,-23,413,1000,265,-31,-648,-929,621}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00583() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node$FileLevelJsDocBuilder", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getJsDocBuilderForNode():com.google.javascript.rhino.Node$FileLevelJsDocBuilder",
            new int[]{516,-116,-1000,-483,-540,-350,-329,568,-281,366,210,-183,760,385,-20,-337,-1000,-352,-867,356,715,160,850,-276,-943,22,-649,-429,-675,371,-248,376,169,1000,-684,-749,187,104,-489,711,-388,-335,255,237,-369,311,118,-639,129,1000,-979,-833,1000,-400,295,1000,-188,-47,-267,-666,36,-1000,-1000,-991}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00584() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLastChild():com.google.javascript.rhino.Node",
            new int[]{-1000,-441,567,-560,-607,-1000,241,-1000,427,-93,-835,-582,22,-232,-110,-572,-390,216,-294,320,339,802,58,1000,-1000,1000,-407,-669,-487,-432,54,-658,234,1000,409,243,595,-362,-616,-362,-204,1000,-1000,182,-149,-73,583,970,-1000,973,-1000,-94,-966,-499,-613,396,-304,118,-589,-166,671,-1000,-416,215}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00585() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLastChild():com.google.javascript.rhino.Node",
            new int[]{-1000,-16,-65,-68,-266,82,-195,-184,109,-66,-630,-459,-963,-1000,-997,-969,1000,-1000,29,-432,-73,245,394,946,159,-654,1000,66,-137,1000,231,-165,164,729,317,-959,-75,182,811,1000,140,-1000,431,-763,1000,566,358,384,329,509,174,505,49,-363,31,995,-1000,-34,685,935,-1000,1000,1000,783}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00586() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLastChild():com.google.javascript.rhino.Node",
            new int[]{-647,-562,-274,-244,-672,528,1000,731,-393,441,-222,-626,-77,360,1000,-363,1000,-289,425,154,-13,-674,503,152,30,-790,436,284,-72,-155,-814,24,484,1000,460,-341,-7,207,-438,-1000,-226,-1000,1000,-926,738,-622,-265,-274,-305,-192,143,111,439,-1000,-1000,26,-725,-623,-205,913,834,818,-1000,483}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00587() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLastChild():com.google.javascript.rhino.Node",
            new int[]{-1000,-171,-1000,-778,1000,773,-693,1000,-1000,-828,488,-347,-1000,-422,-93,-1000,1000,-1000,29,-124,-678,-80,292,630,-1000,-162,-171,744,1000,1000,-1000,-164,-315,-292,415,-1000,859,-1000,472,1000,1000,400,189,1000,1000,-1000,312,34,73,185,1000,349,-532,1000,466,353,1000,1000,-1000,-74,-1000,686,1000,-407}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00588() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLastChild():com.google.javascript.rhino.Node",
            new int[]{320,-11,-684,110,-541,-537,-526,244,438,906,-348,1000,-530,-228,-1000,-140,989,616,850,-37,-536,261,1000,1000,483,469,-123,495,37,-525,746,-900,670,455,-737,629,1000,463,753,643,834,1000,-1000,-1000,-1000,-739,-885,21,-1000,-878,1000,761,-167,-755,9,-349,603,-831,744,-361,920,203,-551,64}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00589() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLastChild():com.google.javascript.rhino.Node",
            new int[]{-1000,228,-1000,-542,-44,392,-1000,665,-608,147,-1000,981,274,186,1000,-895,-699,55,-764,744,1000,-153,-793,966,-1000,824,-739,-1000,-130,552,900,275,-1000,-339,922,-266,-480,-896,-1000,-413,205,300,-1000,1000,-1000,229,1000,-549,-122,591,-654,1000,-934,-308,-813,333,-909,791,-711,-1000,-16,-626,-406,523}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00590() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLastChild():com.google.javascript.rhino.Node",
            new int[]{-810,-17,-870,-715,186,1000,-1000,-250,1000,1000,629,1000,127,1000,1000,-568,-1000,1000,114,1000,532,-1000,-740,-750,-209,502,868,-1000,-1000,458,-32,1000,-494,0,-615,1000,-1000,641,-94,-1000,663,-1000,-255,1000,-1000,882,629,-1000,1000,1000,-1000,1000,-303,-328,-1000,178,-1000,978,769,-1000,716,435,-809,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00591() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLastChild():com.google.javascript.rhino.Node",
            new int[]{196,-571,-708,-252,-269,-337,292,847,164,86,-680,-613,291,-524,-1000,-431,524,100,-37,182,260,65,439,474,69,806,-167,13,-233,85,1000,-975,584,-725,-51,-57,492,-157,882,133,745,1000,1000,-603,422,-671,-51,-136,-1000,-305,475,1000,-703,-778,-254,45,391,628,-115,-1000,426,-738,-504,340}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00592() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLastChild():com.google.javascript.rhino.Node",
            new int[]{176,-901,-765,-760,-376,-249,-1000,-1000,-149,1000,305,1000,1000,997,1000,-501,-1000,1000,-20,1000,529,-1000,-613,-1000,-959,1000,624,-1000,-1000,871,-19,607,611,-514,519,1000,-1000,-628,-526,-1000,-63,-334,-686,1000,-1000,961,799,85,-325,1000,-953,1000,17,-926,-1000,478,-1000,662,665,-1000,1000,-575,-299,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00593() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLastChild():com.google.javascript.rhino.Node",
            new int[]{-976,-667,-601,-177,688,-375,-891,6,851,641,685,222,267,230,-546,-924,387,75,86,-885,-241,-1000,1000,-498,260,-533,134,-229,-793,136,-896,1000,-429,1000,597,-303,-377,-9,72,959,291,-1000,790,-676,-125,-251,275,172,1000,-263,-345,-536,-119,381,-74,180,79,-371,-430,-1000,-849,1000,802,-239}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00594() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLastChild():com.google.javascript.rhino.Node",
            new int[]{227,569,-255,23,-1000,242,-150,-486,-94,768,-1000,1000,599,502,540,-194,-1000,828,256,-34,1000,-618,37,796,-881,529,-209,-1000,-452,-1000,822,1000,-1000,437,623,1000,537,773,-1000,-794,-1000,-1000,-189,1000,-901,1000,198,-155,218,214,-1000,777,-331,-383,-816,356,-1000,-655,455,365,617,-808,-1000,307}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00595() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLastChild():com.google.javascript.rhino.Node",
            new int[]{796,-452,-834,417,-44,-249,848,324,-149,-298,-861,-541,-1000,-334,-1000,-319,1000,-183,1000,-968,-1000,229,1000,632,641,-36,713,1000,321,-438,20,-252,675,-125,-610,47,1000,588,621,1000,537,211,226,-1000,1000,-916,-1000,626,-645,-1000,921,631,-45,400,383,-85,907,-913,106,1000,6,70,233,-415}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00596() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLastChild():com.google.javascript.rhino.Node",
            new int[]{-1000,-316,-889,-611,989,-36,-87,437,-973,337,-877,-924,-14,-1000,-1000,-799,918,-917,-538,545,1000,-600,-154,1000,-1000,1000,-1000,9,520,1000,-165,-1000,157,-1000,726,-625,537,-916,845,-146,1000,1000,-1000,-765,618,-952,444,-599,-1000,218,1000,1000,-706,-383,-98,777,454,414,-1000,-534,186,-1000,-87,613}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00597() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLastChild():com.google.javascript.rhino.Node",
            new int[]{-1000,-472,-28,-68,-266,-249,1000,167,99,100,-188,-1000,-1000,-706,-616,-611,1000,-887,66,-254,-73,-361,559,981,136,-715,-184,7,-313,756,900,-558,-110,600,-83,-350,-3,182,1000,811,140,-1000,495,-780,983,-441,-228,-457,-797,311,174,505,-106,-588,116,1000,-223,-1000,-164,379,-1000,1000,451,429}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00598() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLastChild():com.google.javascript.rhino.Node",
            new int[]{-709,-166,-621,-1000,-1000,-927,-752,-1000,645,1000,-1000,-635,1000,-301,377,-452,-1000,1000,-1000,1000,1000,-621,664,1000,-1000,1000,-995,-1000,291,1000,1000,-1000,273,-1000,554,763,-276,-935,453,-1000,422,-1000,819,1000,-1000,30,-129,-1000,-435,1000,262,1000,-767,-1000,-1000,365,-617,492,-664,-1000,1000,-1000,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00599() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLastChild():com.google.javascript.rhino.Node",
            new int[]{-1000,-382,507,-443,128,-104,-1000,110,-824,-317,128,-1000,-1000,-224,-653,-682,1000,-804,-655,-413,219,-98,519,-158,-700,-631,209,1000,114,473,-1000,565,-61,674,1000,-1000,-1000,-88,380,1000,201,-1000,350,-1000,-121,-545,534,-399,326,277,-114,-197,276,772,132,901,-21,151,-158,916,-1000,-526,765,-38}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00600() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLastSibling():com.google.javascript.rhino.Node",
            new int[]{-999,-776,-472,878,-1000,486,-612,-229,-449,535,-374,-317,318,-1000,1000,83,-503,1000,660,-166,-481,-1000,511,752,270,721,-458,-1000,-346,-580,-186,658,-130,-484,-463,1000,81,-612,-609,-188,-592,360,-282,1000,-808,-749,-795,689,-937,-257,-1000,-603,-1000,-1000,735,1000,590,-138,540,122,722,1000,-1000,55}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00601() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLastSibling():com.google.javascript.rhino.Node",
            new int[]{525,974,467,-1000,-212,-518,-1000,50,-780,887,-624,-112,1000,-921,-653,362,-338,1000,-90,-66,1000,1000,67,424,1000,1000,-1000,556,608,469,-10,-707,764,-1000,-558,956,226,1000,826,-1000,-384,-388,-340,-964,-182,1000,-285,1000,609,-934,618,72,-37,-1000,1000,503,-1000,-333,-1000,-18,1000,916,-1000,-480}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00602() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLastSibling():com.google.javascript.rhino.Node",
            new int[]{-321,-306,81,530,-293,48,-1000,613,-983,378,-68,-243,99,347,-400,-931,886,396,-1000,558,178,400,711,412,763,78,-907,400,12,400,127,478,-404,1000,526,626,1000,503,181,-325,-615,319,-114,-1000,-23,626,325,101,935,-221,1000,1000,741,310,254,401,-1000,-1000,-1000,-388,-443,1000,-264,60}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00603() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLastSibling():com.google.javascript.rhino.Node",
            new int[]{-480,348,-391,-1000,274,-995,-922,590,-885,1000,-166,11,-202,-597,-1000,-1000,1000,101,-250,3,1000,1000,555,1000,1000,1000,-2,660,-221,1000,-722,-741,233,885,-747,474,307,1000,1000,135,-365,245,-407,-1000,274,1000,-1000,541,509,771,-618,1000,645,21,1000,-98,-1000,-121,-1000,-860,647,416,-666,253}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00604() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLastSibling():com.google.javascript.rhino.Node",
            new int[]{-1000,-521,283,-398,-187,-192,806,-313,-356,747,-932,-694,1000,-1000,895,-190,-764,-234,61,346,182,-1000,349,-1000,976,711,516,-1000,-1000,-1000,1000,-92,404,-1000,-644,841,-1000,-412,-1000,603,258,1000,-609,495,42,-39,609,-874,-722,5,-1000,-30,-301,599,61,-155,553,-317,-874,1000,973,-631,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00605() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLastSibling():com.google.javascript.rhino.Node",
            new int[]{-85,974,273,-1000,136,-824,264,1000,-313,566,-35,1000,646,21,878,61,-1000,272,-126,62,710,1000,508,1000,1000,1000,-914,1000,-229,770,-512,-515,352,1000,-282,1000,598,819,461,1000,-340,-141,558,-957,-886,554,-794,683,406,-1000,756,-24,-95,-1000,1000,499,-1000,-457,-1000,-1000,1000,156,-1000,-358}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00606() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLastSibling():com.google.javascript.rhino.Node",
            new int[]{-321,-516,312,-27,-450,-966,155,-229,153,725,1000,-317,-1000,2,225,1000,-717,1000,660,-732,-3,-20,115,-82,270,-1000,-776,-366,302,339,-499,-500,142,285,-463,326,469,-1000,-526,1000,-1000,835,1000,909,203,-623,-215,-556,-937,-55,53,-845,-987,1000,-209,-159,701,-675,560,-464,-115,130,-1000,576}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00607() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLastSibling():com.google.javascript.rhino.Node",
            new int[]{-1000,-381,-1000,-298,-1000,610,-741,-1000,-449,400,-544,-599,831,-916,1000,165,-706,1000,702,763,-478,-1000,369,976,240,473,-1000,-1000,-346,-1000,415,805,503,-173,-463,1000,-61,-612,-1000,-142,25,1000,-282,1000,-808,-1000,-795,374,-1000,-486,-422,-1000,-1000,-806,591,925,619,-138,-278,428,647,916,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00608() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLastSibling():com.google.javascript.rhino.Node",
            new int[]{257,-71,318,192,-1000,217,-1000,-1000,-173,167,-673,-1000,393,-1000,1000,200,-405,1000,615,688,-573,-1000,145,474,74,158,-1000,-1000,-478,-1000,628,-623,558,-1000,-226,603,-487,-1000,-1000,318,-236,-247,-370,1000,-1000,-721,1000,894,-439,-818,168,-1000,-263,-821,-564,1000,-137,-1000,668,758,1000,1000,-1000,-798}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00609() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLastSibling():com.google.javascript.rhino.Node",
            new int[]{-1000,29,190,740,718,-1000,1000,-1000,1000,1000,1000,-51,-1000,-904,-671,1000,-792,-573,-274,156,-694,-1000,-628,965,-406,-862,-589,-1000,12,1000,-1000,478,991,-1000,121,-990,-1000,-912,-752,1000,-549,417,1000,1000,1000,-42,1000,-1000,-101,-63,-1000,-1000,-814,1000,-1000,-1000,1000,1000,1000,502,1000,880,-1000,544}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00610() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLastSibling():com.google.javascript.rhino.Node",
            new int[]{-1000,459,-864,38,523,66,220,1000,786,1000,-455,-450,-207,-801,-756,171,309,-326,307,12,-121,-106,-55,-988,527,-217,-363,-543,104,930,-415,-1000,-789,303,-989,468,-1000,229,290,-797,-298,217,976,-659,-183,656,698,-109,-58,564,-933,-878,309,-8,-191,-284,420,486,-274,420,-316,-1000,-934,727}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00611() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLastSibling():com.google.javascript.rhino.Node",
            new int[]{999,964,530,-1000,312,-402,465,460,-458,555,865,862,-877,1000,-1000,-23,293,88,-158,156,-530,1000,1000,1000,-256,-283,-473,1000,122,-242,-931,-550,-828,-677,447,162,244,-1000,-752,20,-506,30,873,-1000,-944,551,750,-154,732,27,1000,470,1000,527,146,643,-832,-1000,-396,-1000,-684,350,12,257}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00612() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLastSibling():com.google.javascript.rhino.Node",
            new int[]{-550,764,-422,-864,402,2,806,1000,107,373,296,1000,27,1000,-776,1000,-229,447,-264,195,-767,1000,1000,1000,347,1000,-610,1000,-552,671,-302,59,-491,964,405,1000,1000,1000,54,-1000,-57,130,1000,-938,-693,181,-414,-199,152,-630,941,567,150,-243,1000,378,-1000,-1000,-1000,-1000,444,-206,-927,-83}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00613() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLastSibling():com.google.javascript.rhino.Node",
            new int[]{1000,28,616,-469,10,-249,-1000,1000,-324,811,1000,164,-1000,916,-1000,460,27,137,-1000,-595,-353,1000,1000,160,-664,-742,-646,1000,1000,1000,-1000,-543,-1000,267,1000,466,1000,1000,824,839,-1000,-688,1000,-1000,121,818,893,-175,1000,562,929,859,420,824,169,145,-686,-915,388,-1000,-656,1000,-398,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00614() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLastSibling():com.google.javascript.rhino.Node",
            new int[]{-999,-456,-1000,-637,-1000,389,-801,-1000,-899,535,-957,-1000,969,-758,625,-721,-503,1000,1000,763,-26,-1000,369,1000,404,721,-458,-1000,-738,-951,12,-109,437,-445,-1000,786,-61,-485,-537,-385,25,256,-983,1000,-1000,-89,-1000,1000,-724,-587,-889,-598,-314,-897,341,1000,590,-269,654,428,441,916,-1000,-43}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00615() {
        org.junit.Assert.assertEquals("TYPE:com.google.javascript.rhino.Node", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLastSibling():com.google.javascript.rhino.Node",
            new int[]{-85,99,912,-289,-704,-841,-306,559,162,753,577,-298,-416,501,816,306,-1000,1000,-441,-415,-595,-1000,181,-362,196,268,-157,782,24,646,355,-473,645,-88,-241,627,-808,-75,-39,650,-730,650,748,965,-716,-706,864,36,-147,-281,269,-828,816,45,559,819,-611,-168,13,-1000,79,-97,-398,544}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00616() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLength():int",
            new int[]{-444,914,-1000,-721,1000,-363,177,377,2,-684,-885,-1000,431,-1000,-566,719,259,371,-1000,-519,615,-266,85,592,-254,-433,-333,572,697,357,-762,116,-448,551,-224,-75,75,215,-686,-107,-335,-639,-192,-715,439,-248,462,-745,806,-793,-889,950,465,916,-400,107,-457,-493,275,858,-1000,-261,166,-671}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00617() {
        org.junit.Assert.assertEquals("java.lang.Integer:MjE0NzQ4MzY0Nw==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLength():int",
            new int[]{-402,-121,5,-84,1000,440,-38,-215,733,-992,464,-751,-708,-410,-17,1000,813,818,-69,152,-400,-436,1000,244,399,-2,328,820,298,-756,769,5,186,211,106,-413,-256,977,808,1000,-148,1000,-1000,-693,-92,-1000,1000,146,-346,-400,172,362,707,445,-1000,1000,399,-930,-554,1000,338,312,176,-277}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00618() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLength():int",
            new int[]{443,-1,-1000,324,-844,-516,989,-499,-63,-1000,-641,170,-242,-1000,405,910,1000,1000,-137,474,-1000,-506,641,-282,-158,1000,-548,-116,880,1000,1000,210,496,1000,-675,218,-69,742,-188,-516,398,-1000,-367,127,633,128,1000,-1000,371,293,430,533,-297,117,655,-476,-479,312,-333,1000,-1000,-722,876,-186}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00619() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLength():int",
            new int[]{-1000,179,-818,-1000,252,-754,-87,-156,-771,-778,-325,-186,-94,158,-696,547,-605,686,288,-74,730,-487,308,-390,-407,-866,432,406,-238,-356,-1000,175,-709,718,-195,-406,352,114,-180,-1000,95,100,-64,726,548,-178,-673,-1000,-25,-265,-93,433,-461,-123,675,375,-894,-166,-376,1000,-1000,319,-93,-525}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00620() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLength():int",
            new int[]{-1000,-403,-309,-637,1000,785,-1000,1000,-294,1000,1000,-754,-1000,1000,405,743,-1000,1000,-296,1000,-1000,1000,613,586,-572,-1000,1000,802,-1000,-1000,-1000,278,496,-1000,580,-365,-794,-473,-560,-599,-640,659,-1000,526,-467,-1000,-1000,1000,103,-1000,-1000,-631,-47,-739,363,1000,-654,-611,-719,652,1000,-726,-32,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00621() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLength():int",
            new int[]{5,-96,-857,25,523,855,-441,458,948,213,143,-425,482,-462,135,551,-21,985,-817,1000,156,351,249,55,9,1000,1000,-117,226,-86,600,711,252,978,325,-655,-28,961,901,120,-413,7,-545,-935,-245,648,621,-241,-937,-345,-173,-2,-9,644,1000,905,79,-339,858,-622,1000,-653,1000,-561}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00622() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLength():int",
            new int[]{-219,169,-623,434,979,-350,-111,-561,-218,-1000,-1000,339,-629,-600,-937,710,678,651,669,-333,530,-815,1000,1000,10,29,41,541,478,-460,-57,-1000,-923,506,-504,-95,1000,265,618,224,791,189,-964,160,902,-381,1000,-521,894,864,492,-894,-193,141,-749,784,-383,-467,905,-32,-614,609,-197,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00623() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLength():int",
            new int[]{-393,629,-1000,-559,1000,-320,586,1000,266,325,416,96,777,583,-598,-700,747,1000,17,974,92,982,459,-280,-489,1000,701,821,105,-445,-873,-926,-1000,25,-429,-527,1000,528,5,-936,958,-767,-875,-1000,644,-558,666,-23,462,-135,-845,-517,-465,-83,442,646,-1000,317,1000,-628,801,-429,455,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00624() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLength():int",
            new int[]{-393,589,-623,-601,684,-867,1000,-914,-290,-1000,-283,404,391,-974,-1000,1000,1000,641,1000,-554,1000,-1000,1000,-861,371,1000,-346,1000,1000,-247,484,-1000,-903,496,-1000,288,1000,285,-430,1000,1000,664,-1000,784,955,-1000,1000,-611,766,1000,919,-45,57,570,-1000,1000,138,73,1000,596,-117,857,-392,-642}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00625() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLength():int",
            new int[]{-186,-981,781,258,-627,-380,43,-982,128,-667,-199,600,-915,-734,-168,969,-523,364,958,911,417,-371,-253,-812,-166,-455,459,118,-313,-858,452,-329,684,458,358,737,225,335,753,478,168,464,844,887,128,384,-316,-454,-482,747,856,-601,-721,-435,-799,-104,362,399,-801,-758,424,484,885,714}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00626() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLength():int",
            new int[]{302,483,-914,557,231,407,-793,340,1000,-181,4,113,-484,-1000,338,1000,626,176,-591,377,-316,-12,-1000,444,-481,-226,-220,-264,69,781,1000,1000,294,236,347,-347,-305,794,301,593,930,650,1000,-422,-496,314,978,516,-1000,-333,-257,1000,822,1000,-565,-51,315,-357,103,-1000,-262,-1000,548,672}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00627() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLength():int",
            new int[]{-980,748,-928,-6,1000,127,-38,1000,804,1000,-220,259,1000,-302,65,1000,813,861,-1000,238,-178,690,-145,69,399,687,671,819,-232,548,-183,-444,101,-584,679,-1000,-30,-429,-1000,-311,-1000,-1000,-178,-693,-12,-916,1000,811,682,-938,-1000,-423,569,146,195,-217,-514,378,802,-404,1000,-1000,489,-831}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00628() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLength():int",
            new int[]{23,74,-831,-43,226,-659,630,-251,-251,-867,1000,1000,76,-835,-683,1000,-158,679,1000,613,1000,-251,-133,-1000,-267,1000,315,679,217,-1000,999,-583,-1000,953,-1000,348,1000,801,939,-201,920,831,200,508,565,81,979,-1000,-1000,1000,672,-3,-510,-148,-457,671,-206,470,1000,-467,-131,52,811,-185}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00629() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLength():int",
            new int[]{-164,-553,-812,-933,703,197,303,-198,70,-140,171,255,-8,-446,-591,696,728,809,42,48,541,-651,936,-727,418,719,-10,53,-632,350,631,295,-44,717,-402,-467,264,196,-167,-290,482,-118,13,380,678,-178,718,603,546,-834,-42,634,-54,-761,-1000,151,-224,421,467,283,250,-233,663,-501}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00630() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLength():int",
            new int[]{23,-251,-488,-487,226,-810,383,-251,-78,-1000,963,649,-88,-859,-1000,951,1000,818,1000,383,1000,-377,1000,-901,-6,1000,332,1000,425,-368,332,-890,-861,953,-1000,54,1000,270,591,353,1000,813,-1000,544,935,-797,874,-391,178,1000,672,-443,-306,-337,-613,1000,-163,470,649,-3,612,204,-29,-459}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00631() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLength():int",
            new int[]{-980,154,-798,411,-168,762,-1000,738,1000,182,1000,-1000,487,296,717,1000,649,509,-1000,238,-1000,664,266,1000,-1000,687,671,-203,1000,1000,936,-937,415,451,679,-899,-1000,1000,505,-85,-1000,1000,-551,-1000,-959,-1000,-104,459,-666,-1000,-1000,166,1000,1000,-758,672,226,-1000,802,366,196,-801,430,41}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00632() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLineno():int",
            new int[]{-1000,-516,684,-881,416,1000,-1000,-356,472,880,915,163,1000,-1000,242,1000,423,1000,1000,-126,171,-648,365,858,296,-759,1000,-237,823,1000,-733,-272,1000,-674,-103,211,1000,1000,-1000,703,423,-1000,647,1000,148,-290,1000,927,-649,-1000,324,152,-845,-354,340,230,492,-359,-420,-475,-51,1000,647,-182}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00633() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLineno():int",
            new int[]{-1000,179,489,127,-1000,11,156,252,-901,964,-1000,-1000,-297,-1000,415,1000,243,-1000,722,12,317,-204,1000,30,-1000,-603,-154,94,358,1000,-1000,-1000,653,210,-889,1000,-637,274,-1000,-367,-815,387,935,929,1000,1000,1000,393,527,-1000,933,1000,1000,-865,215,841,-900,992,-70,-1000,1000,-20,1000,-204}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00634() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLineno():int",
            new int[]{289,-101,685,512,-418,77,-439,208,-643,-274,666,-213,136,-144,9,187,-135,-1000,200,842,-802,-26,-47,-66,283,-536,365,-231,889,600,-538,547,880,1000,-299,110,369,-978,105,757,785,1000,454,1000,-220,-483,680,267,-353,-816,-79,121,-1000,-875,-280,1000,241,-777,-299,-641,380,74,165,-205}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00635() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLineno():int",
            new int[]{-460,639,86,323,-567,-767,901,-184,-967,352,-471,-332,63,-313,-647,672,417,-146,-222,493,616,138,694,255,-713,618,-672,-443,362,704,468,-657,675,-507,-792,-236,-436,-109,-602,186,-333,445,785,857,661,25,-519,366,921,-910,-169,19,216,-890,-981,-483,-545,921,824,-91,-757,-726,-189,-303}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00636() {
        org.junit.Assert.assertEquals("java.lang.Integer:NTI0Mjg3", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLineno():int",
            new int[]{-689,-186,1000,-410,903,687,-1000,821,-154,-677,1000,687,1000,-118,1000,-534,-1000,203,-507,-229,211,141,-192,-572,739,-1000,940,417,-431,853,-1000,1000,585,-1000,591,37,871,-208,2,170,925,-1000,-388,636,-1000,-216,-55,250,-915,-1000,1000,-309,-1000,77,1000,239,778,-249,-716,-103,63,1000,213,316}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00637() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLineno():int",
            new int[]{-1000,73,-551,-592,151,1000,-675,443,-144,1000,740,-369,1000,1000,-523,602,781,-506,1000,1000,876,-840,-1000,142,-399,680,160,-957,993,793,-1000,-1000,800,-1000,-126,-141,-124,510,16,363,-743,1000,1000,-1000,1000,-552,1000,709,-440,-380,50,-205,1000,-747,-1000,153,-938,476,159,-1000,-554,-1000,642,-661}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00638() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLineno():int",
            new int[]{-1000,424,576,22,169,-1000,51,-958,577,-692,296,917,1000,1000,-1000,1000,574,86,-1000,-155,-520,103,-1000,1000,775,593,70,-1000,1000,1000,1000,560,1000,-97,-576,-1000,1000,590,-537,1000,1000,-199,109,16,-396,-2,-887,520,-51,-931,-635,-1000,-649,-1000,-286,542,723,-1000,1000,1000,1000,934,-1000,-909}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00639() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLineno():int",
            new int[]{-941,-942,-290,720,560,504,-156,-904,1000,29,1000,-188,-194,1000,-507,-277,416,1000,-124,-98,-133,-247,-1000,-39,1000,-1000,774,-1000,86,675,860,1000,1000,473,366,-479,1000,-510,667,959,1000,-792,449,-687,-503,313,97,1000,-1000,-170,-288,-1000,-110,-669,396,1000,1000,-697,663,1000,1000,234,-1000,292}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00640() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLineno():int",
            new int[]{14,-801,621,723,-1000,338,156,463,-824,1000,-706,-1000,-918,-546,256,-94,-480,-1000,171,621,-753,-16,510,-588,1000,-653,-862,242,442,976,-910,670,653,1000,-536,645,-502,-1000,108,-310,858,1000,573,183,988,1000,937,436,867,159,729,540,273,-605,-58,1000,-1000,766,755,-1000,50,-293,20,718}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00641() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLineno():int",
            new int[]{-46,-921,-594,-623,363,1000,-1000,-59,757,756,1000,345,431,614,-263,-458,260,400,181,458,-1000,-734,-953,342,452,-246,-11,-882,1000,965,-1000,393,1000,902,-56,1000,989,-30,863,290,962,1000,494,-168,319,-33,1000,975,336,372,-122,-1000,-39,-362,143,1000,-1000,-716,1000,-419,-357,9,-483,-178}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00642() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLineno():int",
            new int[]{-22,799,827,621,-234,-1000,698,-4,-1000,-507,-574,-485,-586,-83,-610,-78,-7,-1000,-451,541,123,212,295,418,-518,585,-734,-70,600,479,258,25,653,-92,-724,-735,-28,-354,-83,299,24,14,360,668,230,68,-677,-11,567,-697,23,516,-373,-843,-1000,-484,-314,1000,49,264,45,-778,-75,-243}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00643() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLineno():int",
            new int[]{832,19,-276,464,915,185,1000,-356,-471,880,-36,598,251,836,-1000,-843,-182,863,-1000,1000,140,12,-1000,-496,305,-759,-182,-1000,219,805,31,-296,993,346,158,-44,303,-320,581,53,-785,640,-195,-1000,-166,-290,135,521,-303,560,-645,-1000,635,-354,42,230,-70,-359,-167,1000,-51,-1000,-758,-68}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00644() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLineno():int",
            new int[]{-822,-61,-240,-74,-133,50,17,72,-377,511,238,-289,579,81,-753,170,176,-1000,67,445,647,-111,186,478,-519,732,-404,-610,553,804,-492,-162,753,-1000,-584,809,-28,224,577,363,289,413,909,300,762,28,676,556,567,-697,-188,-287,451,-1000,-1000,-38,-314,595,876,-182,-554,-1000,-432,127}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00645() {
        org.junit.Assert.assertEquals("java.lang.Integer:NTI0Mjg4", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLineno():int",
            new int[]{468,733,-778,-1000,1000,-1000,-887,-205,990,597,296,1000,-579,-204,-1000,-117,1000,888,420,1000,828,-256,-1000,1000,366,393,1000,-881,941,1000,-1000,-64,983,-846,-392,1000,965,1000,800,315,-890,851,1000,210,25,313,-400,735,-31,-361,-181,-267,-412,903,504,1000,-782,-634,-1000,843,-793,-838,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00646() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLineno():int",
            new int[]{156,-101,-1000,-1000,-418,77,-1000,499,1000,1000,697,587,-569,412,-755,-1000,763,1000,200,490,-802,-1000,-240,1000,-183,209,1000,-911,826,914,-1000,-998,943,-592,-104,110,975,-978,380,-235,-101,1000,951,-481,903,179,1000,829,336,81,-114,121,537,278,372,1000,-1000,-772,-258,708,-1000,-1000,-122,-287}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00647() {
        org.junit.Assert.assertEquals("java.lang.Integer:MTA0ODU3NQ==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getLineno():int",
            new int[]{81,-521,711,908,1000,1000,-573,-490,836,78,1000,318,386,793,633,-197,-972,-334,-706,257,590,1000,-291,-1000,1000,-1000,621,175,-1000,-27,-312,1000,1000,-733,883,-971,159,-409,348,508,1000,-1000,-849,83,-928,-1000,-216,739,-1000,-1000,-232,-609,-743,687,464,1000,1000,-1000,-189,-318,1000,359,-116,823}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00648() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getNext():com.google.javascript.rhino.Node",
            new int[]{-845,564,-36,701,-203,-556,711,952,-444,-509,107,232,735,500,-504,280,203,-1000,-276,-241,-495,-826,235,-160,-204,672,-520,-58,676,-311,-1000,1000,-1000,177,984,-677,-981,4,729,-1000,361,186,-703,-738,706,-816,-1000,-879,183,1000,237,700,-242,240,-178,-290,475,-142,-82,185,585,-400,463,19}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00649() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getNext():com.google.javascript.rhino.Node",
            new int[]{156,-101,-258,-2,77,5,-400,-402,-1000,400,55,676,-23,898,-270,-964,-119,130,868,1000,-978,5,227,-512,-64,-1000,-73,211,588,714,400,-159,1000,190,1000,-335,187,-220,197,658,949,-1000,-677,-532,-42,-549,176,545,-877,-149,20,-1000,-6,-885,152,848,104,-605,-925,558,1000,-724,1000,343}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00650() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getNext():com.google.javascript.rhino.Node",
            new int[]{394,669,-1000,-1000,-203,497,711,11,-335,72,449,232,-659,733,-1000,-733,-619,-1000,-430,-521,17,-45,1000,-534,-1000,884,-610,-1000,-1000,765,-1000,-298,-1000,-435,-1000,872,-463,707,-995,661,144,186,25,-1000,275,-123,-58,-590,-1000,161,1000,-1000,1000,459,665,400,949,-291,548,1000,793,400,-118,758}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00651() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getNext():com.google.javascript.rhino.Node",
            new int[]{891,-741,420,-686,-1000,1000,480,250,30,-104,881,-1000,987,93,-1000,306,1000,-198,-337,716,903,809,1000,-218,629,-1000,-1000,-1000,-128,1000,103,-1000,853,-356,-1000,-221,-1000,1000,-241,805,-1000,1000,150,-1000,-407,350,1000,739,396,-1000,-1000,-608,-459,-703,55,588,1000,-641,415,1000,1000,1000,890,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00652() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getNext():com.google.javascript.rhino.Node",
            new int[]{847,-671,-389,-1000,-562,1000,886,-132,-417,-345,-98,-927,-412,74,-601,735,-1000,-743,-403,697,1000,377,1000,-846,794,-1000,-1000,-345,-932,1000,-1000,-1000,899,-151,-1000,824,-1000,1000,592,961,-1000,1000,-1000,483,21,624,1000,445,1000,-907,-940,-603,117,-468,-357,-14,1000,246,1000,1000,227,1000,-378,156}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00653() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getNext():com.google.javascript.rhino.Node",
            new int[]{202,774,447,-894,1000,-127,561,-282,-492,-422,681,1000,-356,1000,805,501,634,-475,451,1000,835,-131,-789,-934,528,-900,508,1000,-133,-1000,-679,613,1000,1000,-132,-303,1000,-1000,750,716,161,670,-933,1000,153,-203,632,405,584,-213,-494,536,91,-143,-372,360,-482,-183,-397,29,-1000,-123,-633,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00654() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getNext():com.google.javascript.rhino.Node",
            new int[]{-1000,634,494,142,-305,645,467,-623,-1000,941,1000,1000,-365,1000,528,-568,-392,-816,597,1000,-1000,-69,-680,-1000,607,-763,-867,175,-397,357,-1000,-385,1000,1000,-572,351,24,-166,1000,-568,1000,1000,-1000,895,-524,342,354,274,1000,22,-1000,549,615,-909,-87,1000,114,-1000,-197,1000,92,722,-1000,-248}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00655() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getNext():com.google.javascript.rhino.Node",
            new int[]{525,769,50,-849,484,822,1000,-1000,-1000,-1000,223,63,-16,603,57,-1000,9,1000,1000,801,-366,1000,1000,-1000,-822,-1000,282,-734,946,1000,-1000,-1000,-107,-114,-1000,106,-1000,547,-1000,483,-419,1000,-6,-1000,-1000,350,-249,-230,10,-724,98,-752,191,-1000,1,840,594,-235,-397,1000,998,1000,-1000,832}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00656() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getNext():com.google.javascript.rhino.Node",
            new int[]{152,-676,633,316,-1000,149,-900,52,-723,624,-169,-39,705,50,-1000,-359,-139,-214,677,557,-138,-623,951,-303,-344,-1000,-209,558,-402,1000,516,-117,170,706,509,-481,-1000,655,1000,-192,-125,95,-925,-1000,1000,-1000,45,922,604,62,-206,941,-900,-833,-93,1000,372,-1000,-614,474,1000,67,-41,669}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00657() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getNext():com.google.javascript.rhino.Node",
            new int[]{1000,-6,-156,-1000,669,729,470,-282,-822,-346,681,826,-341,1000,-39,-1000,9,-231,871,1000,197,445,796,-1000,-875,-1000,-46,399,5,611,-1000,-789,-4,190,-871,-303,-866,203,-45,716,161,1000,-1000,-693,42,-589,1000,1000,81,-213,278,-586,83,-973,-372,1000,414,-367,-1000,999,165,1000,-332,-39}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00658() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getNext():com.google.javascript.rhino.Node",
            new int[]{-1000,484,-247,-160,-143,-195,377,-154,-346,-672,-98,494,395,462,-331,1000,-243,767,-422,785,-207,1000,-561,-1000,964,-763,310,-200,897,-1000,135,338,628,771,121,-267,-283,-389,1000,-917,124,25,-294,-68,99,714,-118,-452,535,185,593,166,621,548,-609,-1000,148,1000,448,531,419,437,157,24}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00659() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getNext():com.google.javascript.rhino.Node",
            new int[]{696,-676,-682,-1000,-551,720,127,-1000,-1000,689,911,-39,705,644,70,-359,132,-1000,1000,1000,581,-1000,-225,-1000,545,-1000,-420,1000,-902,1000,-1000,-139,1000,906,-474,464,-1000,-220,1000,-552,1000,95,-1000,393,-42,106,348,1000,1000,-141,-1000,1000,372,-1000,-516,1000,816,-545,-614,1000,862,232,-1000,100}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00660() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getNext():com.google.javascript.rhino.Node",
            new int[]{846,547,269,-362,804,-283,275,-700,-1000,-75,241,1000,-253,1000,281,-1000,848,220,1000,1000,26,831,-113,-799,-348,-1000,532,889,1000,47,-519,-425,878,639,-416,-272,442,-497,268,361,1000,499,-592,-125,330,-367,322,468,633,386,-167,-69,-158,-953,-90,1000,-338,-557,-1000,771,-123,-347,-798,-189}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00661() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getNext():com.google.javascript.rhino.Node",
            new int[]{-305,-218,-421,388,226,-821,-1000,1000,184,1000,408,1000,1000,911,-1000,1000,-445,-1000,-641,-23,1000,-581,297,206,579,-1000,-211,158,-1000,240,739,872,-1000,1000,639,507,1000,666,1000,227,-623,-212,-1000,790,1000,-1000,-1000,-81,1000,1000,-1000,1000,-1000,-160,-1000,-126,1000,-127,149,-332,-555,-884,616,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00662() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getNext():com.google.javascript.rhino.Node",
            new int[]{748,314,215,142,-744,-373,1000,-1000,-1000,1000,115,1000,327,922,743,-1000,1000,-1000,-1000,798,794,-1000,-368,-1000,-752,-834,303,1000,-1000,-295,-1000,368,420,872,-1000,54,-882,-951,440,-455,1000,-138,-1000,385,1000,229,-864,312,1000,314,105,652,1000,-763,111,1000,-560,-484,507,883,512,-531,-1000,592}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00663() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getNext():com.google.javascript.rhino.Node",
            new int[]{-1000,39,-17,820,-1000,-195,-570,23,-1000,245,-460,-2,253,2,-341,386,-273,325,-354,595,-1000,-750,82,-881,-294,-308,-614,703,646,383,-703,343,-501,-249,546,119,-922,1000,240,-393,-331,-164,-678,-603,-239,58,-743,-756,-447,38,98,-527,35,-117,-93,-892,894,493,507,734,1000,-387,-942,794}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00664() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getParent():com.google.javascript.rhino.Node",
            new int[]{-981,364,-949,698,-313,-1000,-413,1000,-745,928,-651,391,646,421,-632,1000,423,685,874,372,1000,867,501,-3,-184,1000,-84,-507,410,-1000,-1000,408,-1000,-574,-396,-898,1000,1000,292,1000,1000,-694,-238,750,497,-1000,1000,-1000,-1000,-313,-1000,-1000,-1000,390,723,88,973,1000,50,-473,95,983,-262,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00665() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getParent():com.google.javascript.rhino.Node",
            new int[]{-380,-201,610,-1000,-590,-658,595,401,-56,174,604,-26,737,10,686,12,-392,-1000,31,191,-1000,-743,-214,556,411,-1000,970,1000,282,496,1000,-1000,54,1000,-1000,717,-169,763,128,-1000,-449,-573,366,1000,658,-112,628,42,-632,89,938,626,373,-296,-665,-1000,267,-730,624,-660,901,991,1000,335}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00666() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getParent():com.google.javascript.rhino.Node",
            new int[]{1000,-591,73,850,766,1000,846,-523,373,-315,1000,-303,-23,1000,507,-623,213,-429,-1000,347,334,-8,554,-885,-1000,-755,-1000,-464,70,312,367,760,20,813,-546,762,-770,-493,677,514,-193,206,-595,181,511,430,-958,241,999,87,-1000,1000,680,-845,-1000,-343,-999,-624,-1000,609,-871,-1000,400,580}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00667() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getParent():com.google.javascript.rhino.Node",
            new int[]{-61,234,-1000,-1000,-406,912,-249,-605,-415,-566,-834,-636,-314,965,-701,701,1000,36,-954,705,107,-922,433,-480,1000,-876,-856,-140,767,-1000,-994,804,-1000,564,-789,-104,84,241,-590,1000,688,-92,-621,104,463,1000,507,-1000,9,-472,-203,410,1000,-176,516,-462,-208,194,-1000,-840,-113,738,-168,-74}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00668() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getParent():com.google.javascript.rhino.Node",
            new int[]{-944,278,57,1000,743,401,-988,-274,575,751,-240,835,-151,-1000,25,-1000,197,592,1000,1000,1000,820,-782,86,-588,559,-1000,-85,-399,291,-357,1000,376,-15,-137,-82,715,588,934,744,-459,72,252,-791,-674,-789,-707,-533,-850,-414,-368,-738,-776,-706,159,346,-178,-510,-18,-610,508,894,-246,-448}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00669() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getParent():com.google.javascript.rhino.Node",
            new int[]{-1000,-481,588,1000,414,876,-757,-1000,1000,1000,-352,1000,-125,-1000,378,-1000,-171,95,752,313,672,1000,-93,496,-1000,20,-701,1000,-1000,1000,378,-305,376,236,-789,-610,1000,-1000,881,-487,-400,-250,476,1000,-308,-647,-165,457,919,-401,-379,-1000,-663,-910,-182,-433,95,-1000,-247,-836,280,99,-394,334}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00670() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getParent():com.google.javascript.rhino.Node",
            new int[]{-486,54,954,-1000,-740,-658,846,580,52,60,1000,-456,882,-496,255,-603,-761,-1000,896,-177,-1000,-1000,-544,1000,866,-1000,1000,1000,443,978,899,-1000,775,1000,-1000,634,-643,1000,277,-1000,-745,-311,227,1000,1000,-32,949,-262,-773,-614,511,1000,1000,-841,-331,-1000,840,-1000,1000,-282,1000,993,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00671() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getParent():com.google.javascript.rhino.Node",
            new int[]{472,-296,1000,7,-289,52,-218,-52,-272,-734,774,-262,-960,581,169,-1000,-198,817,-203,720,-998,514,-910,-198,-764,-881,-247,883,186,970,268,660,947,-119,23,473,-708,-165,287,-831,-954,1000,-525,-189,370,432,-538,-266,137,-517,-73,1000,195,-1000,-322,-865,-52,-1000,-77,-20,-410,86,624,400}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00672() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getParent():com.google.javascript.rhino.Node",
            new int[]{-1000,-526,-213,589,1000,332,-1000,-605,1000,1000,-394,815,-138,-677,655,-991,774,-580,322,923,1000,569,616,581,-584,146,-856,-664,-382,1000,29,230,-374,1000,-460,-377,841,-431,1000,-197,349,997,434,720,-330,-725,-1000,-300,1000,-553,-150,-759,-1000,-424,-411,-428,-208,-1000,-982,-840,-243,632,386,905}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00673() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getParent():com.google.javascript.rhino.Node",
            new int[]{-681,824,438,-1000,-1000,-1000,-408,1000,-1000,416,589,-1000,23,-462,-1000,-842,-545,413,1000,-149,325,152,-614,456,114,1000,581,-658,360,-663,-532,1000,716,16,-746,-780,-24,1000,699,158,-720,-939,-179,1000,1000,-867,756,-1000,-832,-1000,313,-243,-1000,-899,742,-228,1000,374,988,-354,231,1000,654,-640}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00674() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getParent():com.google.javascript.rhino.Node",
            new int[]{-125,284,486,286,-952,-109,-1000,-64,-958,-262,445,215,-85,1000,-627,-1000,-304,1000,170,1000,374,761,-1000,-775,-808,105,-1000,126,167,-24,-446,797,896,-809,248,298,193,407,295,726,-757,1000,-442,590,540,-434,23,-728,-827,-539,-645,657,-74,-1000,47,-841,-116,91,359,-968,312,1000,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00675() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getParent():com.google.javascript.rhino.Node",
            new int[]{791,-667,-1000,363,1000,507,478,816,-482,-1000,819,-469,755,-769,873,-362,-312,-153,-964,-113,-699,-1000,-383,33,333,-286,-554,-255,872,-398,38,-513,293,-66,-1000,970,-108,895,62,-768,334,664,-913,199,-1000,1000,1000,150,-18,235,112,927,1000,-135,-404,-1000,-46,439,-171,492,212,-280,533,642}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00676() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getParent():com.google.javascript.rhino.Node",
            new int[]{-890,-72,-49,1000,1000,401,-1000,-577,785,1000,-236,1000,-1000,-701,164,-1000,-68,592,861,1000,1000,1000,-648,-224,-1000,559,-1000,-85,-582,548,-357,1000,376,191,-139,-151,803,-476,1000,625,-440,111,379,-791,-599,-1000,-968,-318,60,-198,-412,-1000,-1000,-682,-309,346,-502,-686,-281,-1000,439,888,-246,-52}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00677() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getParent():com.google.javascript.rhino.Node",
            new int[]{-248,559,462,1000,-751,-1000,368,-177,-207,235,1000,-211,1000,1000,873,-601,-1000,-946,122,-232,462,-171,-353,284,-930,-1000,520,1000,179,431,-848,-840,1000,572,-621,493,200,677,541,688,-671,-170,-112,1000,738,-330,235,-1000,-1000,-513,13,668,1000,-1000,-297,-1000,404,101,1000,-1000,-1000,1000,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00678() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getParent():com.google.javascript.rhino.Node",
            new int[]{-680,-76,-291,-1000,346,-1000,-102,633,287,1000,-917,-642,558,1000,-1000,-438,-537,989,312,165,1000,-432,617,229,1000,-1000,-483,1000,217,97,818,-16,400,705,-265,-1000,-548,-90,930,1000,-440,-793,-93,400,1000,-1000,-1000,-1000,583,-1000,-332,-801,-1000,-1000,184,984,416,-1000,-785,-424,-255,921,580,760}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00679() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getParent():com.google.javascript.rhino.Node",
            new int[]{-680,-76,855,-1000,-691,-897,-173,633,-159,308,498,-881,-1000,-701,-286,-715,-439,-181,1000,118,-837,-432,-912,1000,1000,-1000,867,1000,217,548,-357,-1000,716,705,-972,-237,-24,1000,644,-831,-440,20,379,1000,790,-391,-15,-995,-42,-981,899,558,-194,-822,112,-502,1000,-668,1000,300,439,888,580,760}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00680() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getProp(int):java.lang.Object",
            new int[]{-350,739,-986,-250,1000,-612,160,-316,-1000,506,240,777,38,-888,376,-753,1000,-754,1000,520,91,1000,-391,-513,-443,617,-1000,-1000,497,1000,-400,-245,394,-810,-133,641,-201,-580,549,-514,331,-515,-1000,175,-315,-348,898,211,362,364,602,-150,-70,604,-677,966,-469,189,-743,161,903,86,672,594}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00681() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getProp(int):java.lang.Object",
            new int[]{-1000,-471,-642,386,917,-406,240,297,-170,-150,-52,-192,-237,-663,614,-1000,129,-957,1000,594,412,-236,-3,431,-407,394,337,296,1000,1000,161,392,615,-454,1000,365,-471,-313,494,-38,-637,1000,962,466,-850,-46,1000,225,-159,916,197,428,-421,-680,-1000,1000,-291,-13,-383,378,906,-904,500,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00682() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getProp(int):java.lang.Object",
            new int[]{-750,-786,-602,-94,31,-774,-41,886,-597,805,1000,-102,815,1000,750,-1000,474,-544,966,946,-724,-814,677,-678,-173,253,-1000,-1000,867,-606,1000,-410,640,-1000,508,400,-697,-392,-1000,482,-1000,307,-1000,-230,-709,126,-895,433,-890,1000,-247,-327,195,-283,-739,753,-962,967,-559,-199,-86,-1000,571,231}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00683() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getProp(int):java.lang.Object",
            new int[]{-1000,394,391,67,-557,1000,-264,521,-480,-375,730,-1000,825,-417,262,-846,73,-284,-699,17,225,-1000,-1000,432,1000,355,496,864,59,660,580,273,-152,-260,393,-839,-347,-63,-1000,306,-231,307,1000,728,129,537,20,388,-303,1000,-1000,138,67,-723,559,-86,-635,-1000,-11,19,-991,-810,-155,483}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00684() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getProp(int):java.lang.Object",
            new int[]{-1000,-576,-1000,-736,-1000,997,1000,-1000,998,-164,-53,276,536,429,-369,1000,-1000,469,-583,-1000,922,1000,187,1000,860,-774,1000,137,-1000,-536,-1000,207,1000,1000,-1000,1000,1000,-1000,-135,-425,745,-181,-1000,684,673,-1000,-1000,-626,280,-374,-364,-287,-54,1000,426,136,-1000,302,-983,74,720,1000,-1000,-156}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00685() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getProp(int):java.lang.Object",
            new int[]{223,-797,322,647,-361,351,337,-331,670,-211,945,960,-275,-430,-560,721,423,-636,-390,-767,45,-320,-50,723,500,355,452,-498,322,-606,524,911,-547,456,-511,766,-321,914,861,-486,446,307,116,-900,472,-804,-953,-330,109,989,-55,-327,-295,117,-159,650,-632,-890,820,-917,-528,566,-978,24}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00686() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getProp(int):java.lang.Object",
            new int[]{-27,463,250,-430,983,-417,-1000,851,-1000,-356,483,400,-339,621,642,-441,833,-1000,-390,1000,-46,-1000,-32,-1000,-905,1000,351,-422,556,944,1000,-1000,0,193,693,400,-720,175,287,-71,-1000,310,946,-1000,-437,918,1000,1000,-61,908,820,307,287,103,-999,1000,-632,313,180,561,558,-1000,1000,24}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00687() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getProp(int):java.lang.Object",
            new int[]{-354,-667,425,37,810,-256,379,-503,-100,59,-300,-336,566,-342,627,608,130,1000,-80,956,-284,579,1000,269,517,686,-843,517,-1000,114,-25,783,-169,-1000,-378,-263,-624,-135,-253,669,-128,-985,-1000,-248,962,-257,855,-775,1000,-149,-547,703,-294,24,831,-162,-44,454,211,-1000,-1000,639,287,31}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00688() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getProp(int):java.lang.Object",
            new int[]{-366,928,412,400,1000,-600,574,818,-709,-148,-240,-382,137,-116,-560,251,267,-355,-390,-345,-279,-311,716,-1000,177,842,-200,599,1000,1000,831,-1000,1000,-1000,1000,-400,-969,-293,48,306,461,803,1000,517,-1000,1000,1000,-376,-604,444,-281,-502,-1000,-580,-1000,1000,-285,239,263,1000,-528,-1000,138,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00689() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getProp(int):java.lang.Object",
            new int[]{-593,-306,-1000,-1000,733,-357,602,743,-409,1000,226,1000,156,1000,-498,-1000,1000,-719,-26,820,-268,111,-261,-31,-968,301,-1000,-1000,518,189,1000,265,1000,-578,-672,1000,-57,57,-253,-85,-195,-267,-928,-604,975,-1000,462,1000,1000,706,1000,295,864,627,-546,-380,-1000,462,-424,1000,3,208,1000,-668}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00690() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getProp(int):java.lang.Object",
            new int[]{-1000,-107,-30,203,-849,-217,-1000,556,-1000,723,-676,-508,198,-1000,-233,-398,364,-886,475,682,-1000,111,669,-470,71,1000,327,-402,-149,751,486,-627,1000,-286,1000,-979,-193,-369,-531,-375,413,1000,-585,695,145,-303,855,-1000,-745,964,-736,-140,-616,-891,1000,-1000,-1000,1000,-266,69,-1000,-901,1000,-711}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00691() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getProp(int):java.lang.Object",
            new int[]{-279,739,-668,-1000,930,-489,400,-429,604,142,542,852,-176,939,745,1000,457,-401,1000,520,431,1000,-445,-261,-337,995,-160,-214,497,1000,-400,-1000,220,-632,-133,1000,-8,-648,998,-888,-268,230,331,301,-315,-348,855,19,136,247,352,-129,24,604,-436,982,-96,-78,-544,693,1000,-294,572,596}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00692() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getProp(int):java.lang.Object",
            new int[]{-984,-462,-554,253,-665,-466,301,-428,-256,236,1000,124,611,803,313,-698,349,-1000,528,883,998,-500,60,325,-570,625,5,117,1000,695,749,-432,541,-454,-400,287,-298,861,-904,-301,-332,109,727,104,-364,59,1000,-156,548,1000,153,-384,223,72,-1000,538,-517,260,-845,408,197,-386,931,-118}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00693() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getProp(int):java.lang.Object",
            new int[]{1000,-572,-574,909,1000,-269,-263,-872,748,-767,-892,-358,-493,-1000,862,401,-365,-635,629,-59,-501,-155,-257,261,1000,645,500,13,599,1000,965,365,-1000,-347,509,421,-927,201,912,-548,415,-1000,922,-623,-271,-613,1000,513,-409,-1000,331,336,-902,-793,-136,1000,-817,-940,1000,177,-626,199,-21,-260}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00694() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getProp(int):java.lang.Object",
            new int[]{-809,-413,293,-329,993,254,760,228,-64,-832,119,-492,732,-422,585,-476,663,-695,-45,926,50,-412,-217,-486,838,225,-1000,821,1000,737,180,-479,334,-865,431,-492,-425,611,277,95,-427,-851,621,575,534,363,701,253,751,229,-501,33,109,-1000,-467,101,933,-1000,-451,34,-1000,-360,616,437}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00695() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getProp(int):java.lang.Object",
            new int[]{-899,143,542,1000,337,254,301,838,-953,-334,-116,-894,473,-546,752,-1000,337,-773,1000,1000,-15,-873,659,-640,47,28,5,615,1000,1000,1000,-1000,392,-745,1000,-1000,-684,207,-358,662,42,499,746,634,-1000,1000,687,158,-95,584,-571,-520,-865,-1000,-395,778,-429,-222,279,-199,-385,-885,380,995}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00696() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getQualifiedName():java.lang.String",
            new int[]{-360,-937,139,-484,-354,582,-19,-726,825,-483,300,-390,-424,-947,957,-974,958,-241,189,-763,381,788,-821,-613,-491,503,-548,157,906,-264,-670,-822,-828,-768,-220,640,-158,-13,-559,-668,-853,-813,-654,490,-89,-781,-87,-260,-709,856,149,226,867,117,-291,564,670,-462,406,-361,118,623,-874,482}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00697() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getQualifiedName():java.lang.String",
            new int[]{1000,679,847,813,1000,362,-149,1000,-800,620,1000,-112,551,-649,242,639,20,744,638,830,-1000,-1000,-624,497,241,946,-525,-420,535,11,-1000,737,1000,1000,1000,-616,-867,-1000,1000,-215,1000,9,1000,-544,-706,-216,6,1000,1000,-1000,77,1000,-1000,-374,-611,225,-117,520,3,1000,-598,-1000,266,-831}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00698() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getQualifiedName():java.lang.String",
            new int[]{1000,664,765,-484,-1000,430,-19,332,-306,951,-167,-390,-30,84,56,179,-764,1000,-597,393,1000,111,758,-613,-491,503,-198,-1000,906,-264,-161,81,561,106,-809,-678,-158,-123,-1000,1000,516,-813,830,490,498,-1000,-1000,-965,2,-1000,109,-586,-369,-237,-478,-1000,-761,-357,-549,-361,462,-176,942,258}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00699() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getQualifiedName():java.lang.String",
            new int[]{-855,-991,213,826,-1000,-31,-51,73,-129,-1000,-508,-1000,-677,64,1000,-1000,-70,917,-346,-1000,769,885,139,240,-786,-132,51,-442,383,-407,460,-283,-678,-1000,-1000,1000,-730,236,-559,455,-1000,-306,-1000,-51,-16,-781,479,-265,-408,856,450,-566,761,739,-417,257,670,-654,179,-1000,-71,623,-1000,31}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00700() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getQualifiedName():java.lang.String",
            new int[]{126,679,223,-1000,-536,416,621,-910,543,266,463,-319,275,-363,-406,1000,672,40,488,759,1000,1000,-606,-205,715,199,-223,-244,-135,608,-1000,-1000,-1000,-389,-817,-559,536,-784,-606,-73,1000,-755,3,267,434,-1000,528,-1000,-297,-278,626,816,-134,-99,-16,533,271,94,188,-574,-1000,-1000,358,-206}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00701() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getQualifiedName():java.lang.String",
            new int[]{-419,639,710,-132,-525,893,-723,731,136,376,954,-396,-678,78,604,-593,-796,-731,968,-515,-792,-620,716,492,-776,-37,347,28,-807,106,-861,152,-716,104,-553,396,-598,308,-879,222,-399,-943,504,-988,131,-577,-434,-383,-688,-950,-898,-744,-796,826,-438,-870,-890,346,130,-512,-605,-857,935,106}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00702() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getQualifiedName():java.lang.String",
            new int[]{486,618,-217,-1000,-400,-4,280,-912,438,-393,-384,-1000,944,-251,770,-1000,855,-865,947,-35,1000,-901,-450,268,1000,-1000,-48,-636,373,-356,-521,-613,-1000,105,-1000,-350,947,805,108,18,146,307,-289,7,-219,-730,587,-1000,1000,-1000,574,611,-1000,1000,-296,1000,-1000,-856,-25,-1000,-596,-1000,-1000,-816}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00703() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getQualifiedName():java.lang.String",
            new int[]{1000,854,908,-1000,-1000,-16,744,-567,99,1000,72,1000,-208,-369,-606,-626,1000,952,524,800,1000,1000,669,-694,-1000,-1000,-1000,-940,-1000,675,-1000,-1000,-166,78,-1000,-919,-125,-701,-1000,389,93,-327,1000,-1,378,434,-236,-1000,-120,-1000,729,-55,-848,-179,-925,-1000,-416,-475,-681,-1000,-1000,-770,788,418}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00704() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getQualifiedName():java.lang.String",
            new int[]{1000,-991,975,-152,402,50,951,448,373,1000,-217,1000,147,-870,-1000,1000,268,825,-1000,1000,401,932,178,-643,-617,-224,-240,-236,-1000,1000,-1000,-33,64,277,-1000,-1000,292,-461,-34,1000,1000,-442,1000,-1000,190,-418,-1000,-912,-8,-1000,569,847,-1000,-1000,891,-1000,-661,1000,-521,662,-745,-519,1000,55}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00705() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getQualifiedName():java.lang.String",
            new int[]{1000,253,-382,-135,-283,-219,781,-786,559,571,189,1000,-884,-745,-1000,102,-315,-1000,77,432,1000,-825,-238,-333,120,307,207,128,323,-488,-1000,35,-1000,-110,124,-249,-297,460,-400,203,438,672,28,-483,1000,848,-214,-329,173,-721,-229,392,307,-91,-690,-556,-1000,-365,-458,363,-534,-133,151,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00706() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getQualifiedName():java.lang.String",
            new int[]{1000,772,868,-226,-356,582,936,534,825,1000,300,621,215,144,-369,821,-441,202,-482,407,559,583,392,-196,-491,-106,-17,157,906,823,-863,-384,-60,344,-542,-678,247,-13,-697,611,535,-256,1000,-1000,47,-781,-449,-260,421,-674,320,737,-1000,-924,729,-1000,-465,872,-644,-361,-942,-754,-874,288}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00707() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getQualifiedName():java.lang.String",
            new int[]{293,243,731,1000,-57,55,-51,644,-762,-244,-193,-613,380,916,1000,176,-469,272,-360,-188,-447,-861,371,584,169,93,-145,-735,-320,-160,1000,694,894,69,-1000,-72,-170,-345,1000,836,630,241,388,-774,-275,-1000,-191,421,595,-1000,132,-131,-1000,225,260,-46,-1000,-4,-57,-200,730,-1000,-233,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00708() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getQualifiedName():java.lang.String",
            new int[]{-360,-937,906,-484,-810,458,735,-726,64,635,300,-390,-424,-947,436,426,958,3,189,-380,381,788,-821,-271,-491,503,-548,157,906,-264,-670,-822,-741,-768,-220,242,-158,-118,-270,-577,516,-650,-557,490,-89,371,-293,-956,-709,856,149,226,555,117,-291,564,670,-462,406,-361,118,-777,-280,482}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00709() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getQualifiedName():java.lang.String",
            new int[]{881,-168,775,-27,-1000,-642,1000,-812,808,767,651,580,556,-1000,-1000,-347,98,-108,-1000,747,1000,1000,-313,-601,-933,-8,380,-305,-261,1000,-1000,-1000,-991,-765,-998,824,1000,430,30,1000,308,153,994,-740,442,1000,800,-1000,1000,-695,492,1000,-895,540,461,-1000,1000,1000,-3,195,-1000,-881,1000,-51}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00710() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getQualifiedName():java.lang.String",
            new int[]{1000,474,763,-1000,902,108,115,1000,1000,618,1000,1000,1000,-1000,-1000,356,1000,917,-379,600,996,1000,-744,-883,-390,1000,-85,-214,1000,1000,-1000,-1000,-369,-921,51,-660,1000,-771,149,-75,1000,-514,994,-450,-786,205,-82,-665,-197,-808,350,932,-935,-468,363,-290,1000,926,1000,1000,-1000,-321,990,-710}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00711() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getQualifiedName():java.lang.String",
            new int[]{1000,-846,500,-479,946,864,505,-565,943,-569,-50,840,1000,-512,1000,-434,646,87,-494,763,-611,803,-1000,-670,-169,1000,-961,-342,1000,87,-747,-384,-71,-251,-213,13,868,469,764,-199,75,-1000,309,86,-897,-778,6,-1000,21,-678,142,1000,409,-214,1000,1000,-231,107,26,248,456,59,-517,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00712() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSideEffectFlags():int",
            new int[]{-454,-21,437,353,-107,-392,-1000,-303,644,171,227,-771,582,576,969,725,76,1000,97,-322,-2,-121,-406,-980,-959,-240,-222,-303,1000,-664,-420,105,223,-373,342,201,-356,-1000,-176,1000,121,-453,-13,143,186,343,153,1000,795,-14,776,-410,-242,1000,30,319,-1000,825,-750,-1000,90,-356,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00713() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSideEffectFlags():int",
            new int[]{-175,384,425,1000,-833,-89,-1000,193,-414,-1000,-34,-1000,553,347,1000,-362,-209,1000,1000,44,-776,-237,-1000,601,-552,-834,-1000,-1000,657,-699,-1000,-1000,-53,-210,737,-129,1000,-659,-1000,-1000,-33,-798,-87,-341,-500,948,820,1000,256,-698,1000,847,-1000,1000,952,1000,1000,765,-117,1000,755,-410,-447,-944}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00714() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSideEffectFlags():int",
            new int[]{14,-116,425,372,-1000,-365,-672,-451,-694,-556,-597,105,413,1000,1000,-207,197,1000,-796,379,384,410,-1000,1000,-320,686,-523,269,155,-593,42,-885,-462,-1000,-900,656,566,-659,-1000,648,-12,838,269,-974,-1000,948,-59,961,1000,-148,1000,-356,32,1000,-82,863,1000,1000,-282,254,263,-1000,1000,829}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00715() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSideEffectFlags():int",
            new int[]{-441,24,400,1000,-202,-277,-724,63,418,282,94,-867,1000,1000,1000,-450,-1000,1000,-91,768,-297,-567,-1000,910,139,1000,-181,559,1000,39,-309,46,-469,-108,600,115,1000,222,-367,1000,-470,-540,267,802,-1000,1000,151,1000,502,1000,1000,677,-1000,988,1000,-97,-549,1000,-247,1000,865,-422,776,727}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00716() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSideEffectFlags():int",
            new int[]{715,-196,-990,339,83,-1000,-384,-1000,278,484,35,-295,352,-568,97,1000,662,-4,60,-378,-225,88,-124,52,115,1000,1000,32,964,-8,85,285,-261,-113,-165,-876,-592,1000,277,-1000,-591,1000,581,-356,392,34,146,-34,-1000,680,14,-514,222,114,464,829,-550,-124,-75,129,-670,-409,-16,-151}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00717() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSideEffectFlags():int",
            new int[]{1000,239,875,-1000,-539,-26,661,-406,-1000,-501,-1000,100,-90,-1000,-978,-208,1000,-296,316,-448,489,-265,584,1000,842,360,578,-1000,-218,-32,1000,-723,-623,119,-368,-719,-207,778,-385,-724,369,810,-1000,-1000,1000,100,-275,-716,-1000,310,-250,467,577,-771,-1000,896,683,-440,-278,1000,-384,197,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00718() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSideEffectFlags():int",
            new int[]{-1000,144,480,816,-47,-61,-936,-528,29,71,501,-21,899,1000,1000,723,1000,-580,-334,-513,-499,416,-1000,-1000,-1000,782,19,747,584,-639,840,891,-1000,-365,-740,946,-456,-1000,1000,1000,-817,258,983,-286,-542,459,-618,943,1000,-306,-407,503,544,956,-593,324,1000,492,-642,935,-806,-630,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00719() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSideEffectFlags():int",
            new int[]{266,699,-387,-1000,422,-655,-1000,-208,302,-28,375,-383,805,-415,857,594,150,295,863,117,308,-622,-676,760,197,-57,-683,-1000,647,-422,-1000,-1000,-36,-84,-177,-1000,1000,914,-1000,-923,-674,214,554,-73,133,231,699,1000,-1000,111,1000,-117,-1000,1000,644,930,718,-1000,-1000,-516,629,63,-376,-838}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00720() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSideEffectFlags():int",
            new int[]{34,-746,-950,313,938,272,-974,483,-379,391,362,206,-866,15,250,551,156,107,39,-766,-796,-792,59,-642,958,25,-954,-658,-244,-426,-252,-885,138,413,837,263,-921,721,870,32,-490,-363,713,816,-359,-395,583,75,-379,-716,641,543,169,-987,-27,956,934,-229,-335,-389,-447,129,-283,560}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00721() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSideEffectFlags():int",
            new int[]{-796,-221,-846,929,-22,1000,-763,-213,373,470,-319,-101,996,1000,1000,185,369,-400,-225,-300,34,1000,-1000,-1000,-950,644,245,1000,487,-720,594,783,1000,-731,1000,94,-263,-845,459,567,94,38,1000,-576,-1000,560,434,800,1000,-291,-92,596,269,839,276,710,851,388,-156,71,-275,-1000,-532,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00722() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSideEffectFlags():int",
            new int[]{613,-902,-694,425,-101,-125,516,-57,233,-73,784,91,-1000,-791,-497,-385,-641,759,-649,99,-306,-822,703,-1000,-75,-163,-379,143,708,83,168,-1000,786,-314,917,-151,-1000,451,1000,968,-628,628,-805,-274,670,280,67,703,-1000,-385,-248,1000,694,-1000,307,-62,1000,581,-462,-602,672,431,436,943}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00723() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSideEffectFlags():int",
            new int[]{-256,-226,-707,-400,1000,-862,1000,1000,92,525,628,1000,-1000,-1000,51,-1000,-672,-1000,723,-355,-1000,-182,151,390,1000,259,-1000,-264,-1000,928,607,-1000,984,841,1000,-554,613,-56,166,67,1000,-589,-570,450,-993,149,-1000,-1000,818,-985,-655,1000,900,-1000,-987,45,1000,-955,1000,316,-880,405,-1000,203}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00724() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSideEffectFlags():int",
            new int[]{-694,439,425,743,484,509,-1000,1000,146,-291,922,-255,1000,-10,1000,419,-55,506,1000,73,-761,-1000,-580,-235,441,-240,-1000,-1000,434,117,-1000,-885,-1,-267,436,-331,861,357,-1000,951,-301,-528,-291,309,807,186,102,605,-605,-265,1000,-413,-1000,903,749,702,1000,502,-707,-805,356,194,601,234}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00725() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSideEffectFlags():int",
            new int[]{-1000,-141,72,787,-1000,1000,-1000,-285,80,-558,-997,-1000,1000,656,1000,-1000,-643,-1000,883,-81,-324,1000,-1000,-1000,-1000,-1000,-1000,865,355,-1000,430,-1000,1000,-1000,1000,1000,1000,-1000,-813,1000,1000,-1000,886,-541,-951,1000,1000,349,573,-1000,1000,984,-159,1000,-39,1000,98,1000,111,-1000,1000,-1000,-648,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00726() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSideEffectFlags():int",
            new int[]{-163,189,756,-680,123,420,816,1000,-1000,-417,-345,273,-1000,-1000,900,-903,-361,439,201,-287,-650,-1000,400,986,279,-332,-1000,-1000,-591,859,220,-1000,-106,1000,448,-363,328,-709,-1000,1000,1000,-1000,-1000,263,480,294,-1000,-868,1000,-586,-305,581,589,-1000,-1000,144,948,-779,44,124,-549,122,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00727() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSideEffectFlags():int",
            new int[]{685,-462,565,342,1000,-578,-91,-203,856,787,-677,1000,-136,308,676,276,538,-391,324,-46,-86,-557,-725,372,1000,1000,25,246,-433,976,478,-739,210,-1000,751,-680,307,1000,117,547,-1000,29,1000,-472,-1000,151,-114,-725,-1000,714,-479,1000,740,-279,1000,-221,1000,-1000,-51,777,-642,124,-689,516}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00728() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSourceFileName():java.lang.String",
            new int[]{170,-746,-448,-639,-1000,579,-1000,407,91,-754,-1000,967,-1000,68,-249,1000,-329,1000,1000,-1000,-140,-924,28,-1000,881,819,-604,-834,556,-748,630,-974,404,-1000,-1000,-1000,-440,-368,-1000,1000,-1000,-831,294,1000,175,-98,1000,-573,888,-609,-326,-1000,455,123,154,-688,-432,1000,-1000,-381,-323,1000,301,-865}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00729() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSourceFileName():java.lang.String",
            new int[]{428,-946,781,-1000,-566,78,-1000,903,-368,-870,-736,1000,-927,657,-430,-631,805,3,535,-723,-438,672,240,214,1000,-540,344,1000,1000,-941,-876,-799,-272,-42,-64,-1000,1000,-874,-1000,-435,1000,-1000,981,-80,509,-373,1000,1000,592,567,308,-460,-400,-447,1000,-250,-453,1000,-325,-1000,-356,986,249,51}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00730() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSourceFileName():java.lang.String",
            new int[]{-21,-541,21,-908,-104,737,-990,460,-584,-129,-1000,665,-61,1000,-558,235,-856,1000,174,33,-1000,42,275,-312,404,541,355,44,349,-748,927,-1000,-386,-1000,-30,-1000,-411,-259,-1000,286,-232,-816,311,1000,391,-129,717,-260,-3,-183,159,-664,-394,761,1000,-408,-318,477,-820,38,-338,126,909,-211}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00731() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSourceFileName():java.lang.String",
            new int[]{-660,809,-818,-1000,495,644,-1000,1000,518,65,212,1000,-17,-364,-915,185,-1000,1000,733,-1000,1000,-982,-39,-752,1000,29,-791,-980,1000,-601,597,-1000,-336,-1000,540,-1000,-182,-282,-1000,-78,1000,-1000,1000,1000,1000,-1000,1000,820,633,-1000,536,-460,-400,262,1000,-1000,1000,862,-1000,-974,-165,570,700,58}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00732() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSourceFileName():java.lang.String",
            new int[]{586,-681,1000,-852,-381,-340,-519,430,-706,-1000,-600,1000,-927,769,454,-978,1000,-1000,-221,322,-1000,1000,197,1000,1000,49,1000,1000,792,296,-1000,-69,-680,-275,355,-268,1000,-1000,-485,-465,1000,-1000,792,-1000,465,415,345,1000,-210,-2,-98,-286,-655,-920,1000,906,-1000,477,868,-965,-853,1000,-622,130}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00733() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSourceFileName():java.lang.String",
            new int[]{116,28,248,-1000,1000,-497,-1000,1000,-370,-377,418,1000,8,1000,-1000,-1000,451,778,861,-431,64,1000,974,28,1000,610,-236,1000,1000,1000,-949,-1000,-281,-1000,235,-1000,1000,-225,-1000,-1000,1000,-1000,1000,167,388,-1000,1000,715,352,156,438,341,-975,1000,1000,-144,377,1000,-1000,-1000,898,-20,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00734() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSourceFileName():java.lang.String",
            new int[]{-181,-336,-1000,-1000,-632,1000,-1000,1000,490,-1000,-875,1000,-1000,-982,-406,1000,2,485,1000,-1000,1000,-1000,434,-1000,1000,96,-326,-1000,1000,-547,963,-1000,31,-1000,-428,-1000,381,-64,-1000,1000,-1000,-1000,660,1000,1000,-1000,1000,-319,1000,-1000,-571,-1000,1000,235,1000,-283,1000,1000,-1000,-1000,-275,1000,1000,842}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00735() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSourceFileName():java.lang.String",
            new int[]{-97,-582,518,-1000,1000,246,-474,1000,-493,-50,1000,215,-209,1000,-1000,-543,-752,633,-467,635,1000,154,748,1000,400,1000,-322,992,1000,1000,-1000,-121,-1000,-643,561,-249,1000,-1000,-835,-1000,1000,-573,633,417,828,-727,470,1000,1000,-239,1000,-31,-419,-99,1000,737,799,-73,-856,-1000,65,-1000,-924,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00736() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSourceFileName():java.lang.String",
            new int[]{406,-636,275,-225,-41,768,-1000,209,88,-735,-796,-303,-1000,-65,668,1000,-654,33,218,-1000,-488,-698,-59,-504,93,64,-303,-873,-835,-1000,475,-1000,-57,-730,-84,1000,-688,-215,-452,1000,-862,431,-183,1000,560,328,-621,-1000,-475,-327,-28,-540,555,-738,992,203,-157,644,-278,-45,23,684,-27,-607}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00737() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSourceFileName():java.lang.String",
            new int[]{-222,799,-306,-1000,-684,1000,-967,804,481,-719,-629,1000,-707,-814,192,1000,-930,1000,1000,-1000,1000,-1000,-307,-968,1000,29,-619,-980,995,-1000,590,-1000,219,-1000,-370,-739,-46,-1000,-1000,1000,-1000,-1000,716,743,1000,-127,1000,661,1000,-1000,-544,-1000,847,-354,1000,-104,1000,1000,-953,-1000,-854,1000,144,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00738() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSourceFileName():java.lang.String",
            new int[]{563,879,-134,-832,-743,1000,-1000,536,162,-1000,-740,1000,-1000,21,-1000,-92,351,505,1000,-147,1000,-620,-529,-435,1000,-360,-336,-106,1000,-849,625,-375,-327,-939,-517,-358,-289,-1000,-1000,649,-140,-1000,1000,-179,990,-131,1000,1000,1000,-479,-532,-572,102,-1000,285,145,1000,706,-933,-683,-1000,1000,-8,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00739() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSourceFileName():java.lang.String",
            new int[]{837,-376,934,-573,-1000,-617,232,111,-866,-1000,-350,87,-1000,1000,1000,-340,-480,71,-132,661,-859,1000,-229,674,-608,778,-891,877,-994,262,998,883,592,242,-1000,-562,349,-821,170,136,303,-466,447,-1000,115,1000,83,1000,-368,1000,-523,-278,319,1000,791,1000,-902,-1000,103,886,-773,170,-1000,189}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00740() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSourceFileName():java.lang.String",
            new int[]{442,-717,548,-754,-422,-266,-404,523,-119,-260,-290,502,-607,1000,-1000,-890,-1000,1000,182,847,462,809,554,-12,438,651,-1000,1000,970,1000,-188,-338,48,-428,-495,-1000,-709,-368,-765,-934,1000,-715,952,590,296,-648,817,448,213,-57,476,99,1,1000,420,-376,92,187,-1000,-476,-213,-62,229,815}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00741() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSourceFileName():java.lang.String",
            new int[]{534,-582,-298,-706,-1000,67,-1000,335,-69,-754,-1000,1000,-1000,-576,-60,1000,146,867,245,-1000,-543,-106,-116,-632,1000,1000,-1000,524,1000,622,254,21,456,-1000,-36,58,-813,-1000,-844,1000,-12,-982,186,451,403,806,1000,92,506,199,-495,-1000,554,-1000,367,-377,-1000,1000,-352,-693,-544,709,-491,-605}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00742() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSourceFileName():java.lang.String",
            new int[]{480,-256,-580,-122,-1000,947,-630,37,346,-1000,-1000,1000,-1000,-336,-75,1000,-314,1000,1000,-251,782,-828,-250,-1000,540,591,-528,-1000,598,-1000,905,-338,347,-455,-1000,-986,-726,-690,-970,1000,-1000,-501,773,578,497,18,929,-232,1000,-1000,-702,-743,649,-278,-777,-375,92,602,-1000,202,-656,694,273,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00743() {
        org.junit.Assert.assertEquals("java.lang.String:MTIyLjA=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSourceFileName():java.lang.String",
            new int[]{60,-827,231,-852,293,401,-1000,1000,-706,-667,122,1000,-1000,435,-1000,-543,1000,633,1000,-211,1000,-556,1000,230,1000,1000,-1000,275,1000,1000,-1000,-894,-65,-1000,-603,-268,693,-1000,-1000,-806,729,-1000,647,1000,874,415,1000,1000,1000,-640,268,-286,-275,-786,728,-445,200,1000,-1000,-965,-174,205,-45,130}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00744() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSourceOffset():int",
            new int[]{1000,929,-1000,645,1000,-660,-809,-660,-1000,995,132,889,1000,249,-54,100,704,-860,1000,-977,-54,1000,-1000,1000,73,656,1000,-493,596,1000,-819,907,1000,898,-1000,-811,-1000,619,283,859,-221,-85,785,-563,846,1000,-435,-1000,-111,667,-884,1000,591,509,93,954,-671,1000,-884,-841,-308,1000,544,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00745() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTIxNDc0Nzk1NTM=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSourceOffset():int",
            new int[]{-209,464,-636,56,67,1000,-709,-148,996,-1000,586,-153,-380,908,1000,1000,-1000,1000,-1000,-1000,272,-1000,1000,-746,-358,388,-877,-558,-757,-432,-159,-570,-12,98,1000,563,432,-661,-43,-1000,-513,18,-87,-241,426,-1000,-628,652,173,480,13,-233,1000,-123,-304,-795,-847,1000,-1000,688,-1000,-254,-470,165}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00746() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSourceOffset():int",
            new int[]{-950,378,143,-182,1000,1000,-141,763,719,-1000,500,1000,555,-1000,-1000,1000,-1000,1000,201,834,-999,789,1000,-1000,-339,-1000,491,1000,273,-158,1000,-359,650,1000,982,1000,1000,-480,-275,-816,89,567,-368,-275,-474,-914,-857,206,-325,-23,368,1000,-182,173,-1000,1000,-1000,182,-1000,-130,-649,1000,234,823}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00747() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSourceOffset():int",
            new int[]{480,459,65,391,358,1000,-463,1000,997,-1000,605,1000,-246,-1000,-1000,1000,-1000,1000,-910,1000,-956,1000,811,-144,-570,275,15,-585,-954,-3,1000,-774,701,229,1000,1000,636,-472,-79,-600,432,-173,-1000,-412,-1000,-1000,-790,930,-776,1000,539,705,96,822,-1000,1000,-310,-56,-598,989,-436,355,35,263}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00748() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSourceOffset():int",
            new int[]{-401,564,-105,-182,516,468,95,796,506,165,822,948,581,-941,-1000,1000,-454,-400,-4,870,-333,1000,461,281,224,387,866,227,44,312,583,10,911,-101,726,266,336,581,-631,232,-234,667,-382,110,-567,-541,-49,-688,-562,1000,-330,1000,-78,628,-1000,1000,188,-90,98,377,-428,-64,-173,199}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00749() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSourceOffset():int",
            new int[]{324,554,-345,-984,-486,500,-622,-407,1000,276,221,-1000,-699,977,1000,363,-1000,764,-604,-1000,-25,-1000,-94,-464,-344,1000,-1000,-1000,-1000,-352,970,-414,-1000,90,725,501,401,-564,-64,-1000,-524,-513,-342,-134,703,-484,-331,135,205,1000,-1000,-153,1000,-112,-384,-987,-235,1000,-964,666,-351,-958,-1000,255}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00750() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSourceOffset():int",
            new int[]{391,49,-30,287,-880,-715,-98,224,1000,765,-1000,533,-1000,409,643,370,1000,-664,-641,546,-655,-144,-462,-1000,-235,1000,-108,-1000,483,-955,-845,-464,-198,-631,-616,1000,-876,28,-3,102,617,-987,-1000,1000,-140,641,-559,22,229,1000,-207,-720,-482,-265,-2,583,484,1000,-565,-1000,-1000,830,-66,-2}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00751() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSourceOffset():int",
            new int[]{921,-631,-1000,-1000,931,-268,914,-971,-1000,407,1000,296,1000,-1000,-1000,-807,475,-1000,616,-615,306,316,720,-648,1000,-234,969,1000,1000,771,-670,-567,618,466,435,151,-884,1000,-693,1000,-796,-1000,429,-1000,414,-594,-204,-1000,1000,-99,-1000,689,-264,-406,-1000,166,1000,-693,-90,1000,233,613,-531,206}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00752() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSourceOffset():int",
            new int[]{-254,694,360,-1000,1000,-82,-1000,422,599,-1000,30,754,745,-654,-695,1000,-840,831,967,370,-325,1000,230,-853,-313,-358,1000,184,224,40,882,-1000,1000,713,93,803,1000,229,-911,-807,1000,760,-278,531,176,388,-407,-851,-141,-235,-416,1000,-373,-8,-1000,1000,-1000,1000,-1000,273,-951,1000,654,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00753() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSourceOffset():int",
            new int[]{208,854,-171,617,1000,-1000,-116,-231,-1000,1000,378,976,1000,-820,-599,875,400,-1000,683,75,409,1000,-1000,1000,724,287,1000,349,1000,212,-883,684,1000,463,-529,-1000,-1000,841,-11,1000,948,-329,392,-97,418,1000,-602,-1000,-242,-76,368,1000,-465,633,501,-224,-207,1000,1000,-1000,-324,1000,1000,829}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00754() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSourceOffset():int",
            new int[]{-228,-461,344,1000,1000,100,990,-97,-1000,627,-728,-643,-489,-540,-848,896,-187,-648,1000,174,616,-1000,699,-607,-56,-1000,-415,1000,1000,-546,140,749,1000,-195,351,-253,-1000,-81,-266,734,611,1000,1000,-137,331,-676,-1000,-1000,731,-1000,1000,-655,-957,-501,1000,-1000,-926,1000,716,393,505,-34,1000,-211}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00755() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSourceOffset():int",
            new int[]{-265,18,-575,-838,775,-342,-415,824,511,-837,1000,-87,-491,-466,-1000,-8,-717,-152,1000,-847,67,-1000,1000,-1000,1000,-1000,-334,1000,1000,-322,152,-725,-244,1000,929,529,961,306,1000,-442,-647,251,91,-736,1000,-1000,-235,-992,221,-816,-593,856,-845,-168,-890,-377,-304,-160,-948,940,-501,418,-645,37}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00756() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSourceOffset():int",
            new int[]{-339,968,-687,1000,1000,240,171,128,-1000,1000,346,1000,1000,-1000,-497,1000,-221,-1000,-63,-130,-505,694,240,831,897,221,991,547,1000,1000,378,556,236,-83,-16,-787,-1000,606,1000,1000,-411,-289,1000,-235,-637,-197,-991,-1000,-137,525,428,600,739,558,793,-610,-745,1000,1000,-521,-600,1000,620,74}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00757() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSourceOffset():int",
            new int[]{-657,388,-892,-649,524,1000,262,1000,10,-367,764,1000,57,-1000,-628,1000,-691,199,-188,475,-869,-416,902,-314,730,-691,815,569,511,1000,-597,-147,-82,134,726,788,162,120,1000,316,-919,89,303,-19,-843,-925,-417,-443,270,512,636,1000,786,14,-710,-399,-1000,1000,61,458,-1000,1000,-303,639}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00758() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSourceOffset():int",
            new int[]{976,254,-771,427,784,-374,-613,-356,-218,886,-644,706,-369,501,336,100,1000,-748,450,-380,1000,1000,-1000,1000,-188,1000,617,-1000,486,365,-1000,312,1000,318,-1000,55,-1000,343,48,484,199,-480,-353,302,592,1000,-415,-1000,53,1000,-751,1000,66,493,-50,1000,1000,1000,-1000,-1000,-499,757,247,666}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00759() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSourceOffset():int",
            new int[]{-924,989,-1000,-838,-456,700,171,476,1000,1000,1000,1000,-514,-1000,688,1000,161,1000,-1000,-322,-1000,-1000,1000,-1000,1000,487,-334,-534,-1000,-125,624,-725,339,908,1000,-784,1000,-1000,675,-1000,-1000,-575,-287,-1000,215,-1000,-1000,776,-196,1000,-503,463,1000,1000,-1000,-598,-1000,176,-845,1000,-699,1000,-1000,380}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00760() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSourcePosition():int",
            new int[]{-495,-696,283,-203,-434,-51,280,-285,958,60,-235,-309,-1000,205,681,-1000,559,-7,-371,356,165,1000,-451,366,505,472,-432,-1000,631,-281,536,-215,-1000,-508,-254,-26,-232,-336,-133,407,1000,545,-165,47,-493,-1000,-919,-291,591,691,273,367,52,452,-755,-461,-183,-637,532,36,-343,-129,-256,147}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00761() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTQwOTY=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSourcePosition():int",
            new int[]{-518,-991,-590,655,-239,-260,-1000,-1000,659,972,-1000,136,-536,652,815,-1000,1000,-97,-590,1000,191,-862,-350,1000,132,242,78,146,-1000,-1000,1000,470,365,-754,-1000,1000,745,1000,-1000,-649,1000,1000,1000,1000,-1000,1000,-713,-610,-800,315,-1000,33,437,-171,-1000,-1000,-280,-710,240,-1000,728,481,1000,-871}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00762() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSourcePosition():int",
            new int[]{-1000,-921,961,-203,1000,881,1000,-427,798,642,403,-1000,-1000,-766,156,-567,-139,1000,1000,-381,-1000,1000,590,1000,1000,346,1000,-301,-511,550,-724,-1000,543,-508,1000,390,-1000,62,-40,-361,-697,-5,27,-800,-702,-81,290,1000,46,-1000,-1000,52,-1000,90,-531,-144,-1000,-1000,1000,1000,-1000,882,-647,-231}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00763() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSourcePosition():int",
            new int[]{-163,-386,807,58,-1000,-1000,-1000,-12,385,-626,-1000,-122,-569,1000,734,-917,637,-1000,-921,1000,1000,880,-1000,430,307,384,-450,215,74,-75,1000,1000,-1000,-9,174,52,1000,974,203,-19,1000,1000,1000,552,396,-930,-1000,-688,973,1000,816,548,133,-398,382,93,792,-45,-678,-1000,1000,-933,249,684}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00764() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSourcePosition():int",
            new int[]{-263,-576,-895,87,-192,7,6,-444,659,620,-226,-176,-424,1000,398,242,1000,378,-451,350,689,-542,87,756,252,-143,644,1000,-986,-461,386,-995,1000,-201,-97,950,894,931,-1000,-1000,458,1000,1000,318,-800,1000,-175,-689,-735,-1,-687,70,-73,-1000,246,-512,1000,175,-1000,-1000,-899,20,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00765() {
        org.junit.Assert.assertEquals("java.lang.Integer:MQ==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSourcePosition():int",
            new int[]{-923,-816,-950,-883,452,1000,-159,388,930,-147,1000,-899,-1000,1000,710,1000,787,478,-775,-1000,-432,-137,1000,518,1000,1000,1000,907,-367,277,-915,594,1000,-677,1000,-117,-814,561,-777,-950,-30,-1000,778,-947,405,1000,7,-1000,454,-858,52,106,1000,-1000,1000,511,-775,-642,-1000,-1000,-455,-722,190,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00766() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSourcePosition():int",
            new int[]{-535,549,-557,780,-490,754,-747,438,1000,1000,-562,1000,-1000,1000,651,-739,1000,926,-354,-435,-132,-601,1000,19,-72,790,1000,-254,387,-571,626,161,-391,-1000,-263,-190,89,1000,-240,-628,1000,1000,-621,1000,-681,852,-958,-1000,-1000,932,-1000,-243,1000,-605,783,-989,48,620,-171,-728,-17,-797,1000,220}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00767() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSourcePosition():int",
            new int[]{-1000,-956,370,-755,701,982,33,-1000,121,1000,396,-710,-789,-14,202,-714,812,1000,765,-199,-854,1000,564,770,735,215,1000,-871,-911,-89,-97,-1000,1000,-546,-296,1000,-751,302,-955,-215,615,158,224,37,-413,1000,12,421,-284,-685,-1000,-202,-774,1000,-913,-1000,-444,-871,769,403,-1000,552,-647,-206}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00768() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSourcePosition():int",
            new int[]{-609,-816,-841,-880,-382,900,402,-91,-112,-151,1000,-532,-487,1000,169,38,985,1000,682,-742,426,-184,818,597,367,455,1000,1000,-950,508,-707,836,1000,-392,828,565,385,-185,-1000,-1000,-65,246,1000,1000,484,1000,7,-1000,-735,-1000,-54,-73,313,-1000,534,306,196,333,-1000,-1000,454,-464,186,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00769() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSourcePosition():int",
            new int[]{-271,-816,355,-415,-382,684,402,1000,-800,-151,852,300,-835,387,242,38,92,484,682,-1000,1000,-321,564,-503,-1000,-136,869,-809,656,257,-921,836,-69,-830,598,-1000,-858,-877,334,435,-429,-1000,-811,901,346,-995,-560,-747,-1000,-847,-54,-410,1000,-300,1000,595,-15,658,-265,153,-406,179,-1000,637}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00770() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSourcePosition():int",
            new int[]{-911,-606,34,-288,-192,689,6,-74,659,857,-430,598,-954,131,437,-840,429,926,-200,79,-761,530,696,260,939,323,644,-252,40,-497,396,-995,345,-651,10,244,-669,900,14,294,673,598,-586,318,-800,901,-498,-689,-735,212,-999,-218,437,505,-50,-747,-280,13,893,319,-899,20,470,846}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00771() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTQwOTY=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSourcePosition():int",
            new int[]{-76,-706,547,635,123,-1000,290,-784,-304,-1000,-454,-925,-589,-530,459,-1000,471,-690,1000,899,1000,770,-1000,335,-76,-1000,-168,-282,-141,-923,673,387,-678,-326,-1000,761,196,275,-133,296,842,-131,-995,-576,-1000,-1000,-150,541,1000,1000,-645,51,-1000,-367,-710,-1000,633,-1000,1000,-70,-64,1000,-298,369}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00772() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSourcePosition():int",
            new int[]{-505,-726,880,-510,-97,600,1000,939,988,265,-11,614,-1000,-346,80,-723,-202,806,-236,-201,-849,894,507,401,1000,1000,60,-254,1000,254,-304,-497,420,-723,-542,-1000,-1000,205,1000,-234,-7,-833,-1000,-268,-381,-895,-634,-483,-561,-98,224,37,1000,775,500,1000,-1000,196,1000,1000,-1000,15,-397,483}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00773() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSourcePosition():int",
            new int[]{-779,528,-477,-1000,81,1000,-39,369,506,1000,912,-421,-598,1000,341,1000,522,1000,-356,-621,-10,35,1000,430,1000,966,1000,762,-263,872,-1000,605,1000,-362,1000,-278,-421,-111,-311,-1000,-552,-286,576,820,629,1000,-88,-1000,-486,-976,402,161,559,-1000,728,907,-508,302,-1000,-1000,-141,-499,-378,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00774() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSourcePosition():int",
            new int[]{-1000,424,-496,-1000,-187,1000,178,977,685,966,396,185,-1000,1000,316,1000,165,1000,-504,-1000,-306,1000,1000,33,1000,1000,1000,767,292,777,-1000,146,962,-546,1000,-807,-789,-181,340,-1000,-593,-567,-211,948,707,1000,-296,421,-1000,-781,403,-27,1000,-982,1000,1000,-827,785,-856,-705,-1000,-1000,-322,-291}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00775() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getSourcePosition():int",
            new int[]{-907,-628,269,639,-809,-347,955,-626,667,165,98,940,-41,793,-115,-548,76,667,-64,167,907,-898,844,263,-940,736,-301,40,10,-996,-98,487,-341,-866,-173,320,-805,-315,546,661,116,351,-239,303,-374,-811,-700,-829,299,759,-866,11,-182,-267,-287,630,908,478,597,-948,148,-177,883,-149}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00776() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getStaticSourceFile():com.google.javascript.rhino.jstype.StaticSourceFile",
            new int[]{-767,-726,733,1000,-90,-1000,171,1000,-1000,-187,-1000,1000,-805,-315,1000,-522,-274,131,-197,1000,1000,332,812,993,247,1000,-167,515,1000,-173,-227,-277,484,363,1000,1000,1000,580,438,-1000,-101,-83,-831,696,-34,-182,-523,517,574,-527,400,427,963,517,1000,1000,1000,-1000,-711,787,819,142,1000,-230}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00777() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getStaticSourceFile():com.google.javascript.rhino.jstype.StaticSourceFile",
            new int[]{281,-376,-345,-659,-1000,-123,1000,-1000,-733,-289,-231,158,-437,737,-42,80,-1000,-1000,-1000,-465,1000,228,-115,947,-170,-1000,1000,-669,1000,-1000,-1000,719,-1000,560,303,-272,-1000,-755,-236,-320,728,-156,-810,-373,649,85,-365,978,146,-489,617,629,646,975,-919,-570,1000,1000,1000,-45,104,-505,-50,-941}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00778() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getStaticSourceFile():com.google.javascript.rhino.jstype.StaticSourceFile",
            new int[]{325,-936,-28,-724,-863,279,572,553,-595,-510,-849,992,-881,493,-1000,-318,956,-593,495,303,1000,-809,-599,463,-540,-420,1000,765,746,-355,-1000,-57,322,1000,1000,1000,1000,-1000,1000,-287,-492,-723,-720,1000,1000,-1000,-208,388,-543,783,-530,-855,-126,1000,-499,1000,-370,473,898,-141,-659,729,-82,-943}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00779() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getStaticSourceFile():com.google.javascript.rhino.jstype.StaticSourceFile",
            new int[]{221,-236,758,-1000,-153,1000,-520,-842,669,-355,1000,-375,-204,-286,-1000,261,685,-1000,712,-866,-1000,528,-1000,-673,-363,-1000,-402,-506,-1000,-183,15,-491,-301,-1000,-973,-750,-1000,-1000,-363,1000,150,465,822,86,418,586,-38,-1000,-88,-134,-196,8,-1000,128,-1000,-1000,-1000,1000,77,67,-191,-1000,-1000,-392}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00780() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getStaticSourceFile():com.google.javascript.rhino.jstype.StaticSourceFile",
            new int[]{-596,-416,694,-1000,-318,1000,-340,-506,788,-425,400,1000,-773,1000,-1000,711,260,-819,476,-648,-400,400,-697,-452,247,-400,665,-280,-603,160,334,135,-635,106,-96,-429,-400,-158,155,-127,180,481,32,42,1000,664,-605,-586,-1000,369,-89,-357,878,798,-716,-99,-400,700,973,798,-929,-698,-1000,-760}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00781() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getStaticSourceFile():com.google.javascript.rhino.jstype.StaticSourceFile",
            new int[]{413,-831,531,473,885,920,432,-427,-339,230,-48,596,-561,440,-312,926,-577,320,-136,412,-702,415,987,717,108,667,-977,-843,844,-902,281,298,341,466,-688,-650,126,802,-389,-986,-792,417,-308,-144,521,629,164,-514,687,-231,882,-93,99,265,908,-799,930,607,84,-579,610,-198,-659,-974}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00782() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getStaticSourceFile():com.google.javascript.rhino.jstype.StaticSourceFile",
            new int[]{-84,-747,784,1000,-163,-920,849,1000,-1000,666,-215,843,-207,-444,565,-1000,-1000,-685,-749,1000,1000,-37,552,1000,-576,-406,353,296,620,-283,244,644,-204,-548,1000,820,752,-616,226,-746,292,-1000,-200,-686,-218,478,-567,-285,-42,-110,338,-49,583,578,-234,1000,971,-231,-776,456,902,625,722,-314}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00783() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getStaticSourceFile():com.google.javascript.rhino.jstype.StaticSourceFile",
            new int[]{-305,-986,-245,-412,-749,-638,-519,-55,-743,-884,-1000,1000,-805,92,477,911,1000,-281,-154,182,1000,-752,-552,-278,553,1000,874,515,-227,14,1000,-1000,-563,26,1000,692,1000,-28,438,-1000,-585,-83,-1000,585,976,-1000,-1000,914,-1000,-527,400,-318,1000,805,-1000,1000,244,-41,156,527,-1000,258,911,-774}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00784() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getStaticSourceFile():com.google.javascript.rhino.jstype.StaticSourceFile",
            new int[]{296,-472,37,145,-40,-30,-301,-68,-325,-727,-802,514,-557,-588,734,-83,248,222,-1000,90,619,181,843,-125,1000,809,-446,276,246,-787,-339,-697,-355,446,-22,607,882,633,246,-648,-140,510,-359,633,186,-615,340,735,35,-527,-552,649,491,622,1000,84,1000,-599,-3,-210,-170,-8,312,-230}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00785() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getStaticSourceFile():com.google.javascript.rhino.jstype.StaticSourceFile",
            new int[]{1000,-831,-1000,78,-505,1000,1000,443,-459,-404,1000,787,-409,63,149,325,495,-159,471,95,1000,-1000,-387,467,1000,1000,555,1000,1000,652,-462,-189,320,1000,1000,722,820,419,815,-505,-1000,-1000,-729,1000,805,827,-177,1000,-88,-822,748,-145,826,359,-841,1000,764,1,-467,-427,-962,784,1000,63}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00786() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getStaticSourceFile():com.google.javascript.rhino.jstype.StaticSourceFile",
            new int[]{413,264,168,473,-1000,-358,782,766,-72,354,-48,-720,524,440,-312,1000,1000,64,-840,412,-674,-647,-820,-822,330,-360,401,580,-933,-902,299,-138,840,87,-134,594,148,-273,-202,1000,-792,-644,353,338,286,-1000,-98,812,-552,1000,-598,-412,-100,265,-1000,-532,-966,607,-832,194,-272,672,97,869}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00787() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getStaticSourceFile():com.google.javascript.rhino.jstype.StaticSourceFile",
            new int[]{108,-541,738,498,-283,313,618,-384,1000,-1000,635,246,792,17,-294,-242,-147,278,539,-159,-634,530,-116,-705,-303,-71,-969,370,-254,903,137,919,488,570,29,33,-377,-398,-1000,111,-674,-451,1000,-851,170,-356,89,-1000,708,725,-876,-382,-417,-91,477,820,-1000,-315,-413,-1000,-534,599,-232,142}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00788() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getStaticSourceFile():com.google.javascript.rhino.jstype.StaticSourceFile",
            new int[]{394,-896,1000,553,-483,-686,-628,903,387,-139,-281,661,489,-45,328,371,-386,-1000,-1000,-435,254,-439,555,-217,663,394,880,511,-330,-487,424,96,-620,998,-59,-1000,461,-454,-1000,690,181,-1000,-452,461,358,-334,-836,-992,386,1000,1000,463,252,724,-591,1000,1000,222,-614,734,-873,-189,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00789() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getStaticSourceFile():com.google.javascript.rhino.jstype.StaticSourceFile",
            new int[]{-1000,-656,892,-1000,-476,1000,-1000,-1000,1000,-179,1000,1000,-154,63,-919,587,306,-1000,471,-1000,-1000,1000,-1000,-912,-1000,-1000,599,-829,-935,652,893,-78,-1000,-427,-566,-1000,-1000,-1000,-1000,16,728,1000,474,-373,1000,827,-1000,-1000,-1000,279,301,-113,826,639,-594,-570,-1000,653,1000,1000,-962,-1000,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00790() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getStaticSourceFile():com.google.javascript.rhino.jstype.StaticSourceFile",
            new int[]{-715,-746,880,891,-644,-616,13,627,-753,314,-486,957,-295,-549,211,-274,-515,-37,-1000,873,614,714,613,365,51,500,-41,5,291,573,78,433,-902,381,882,631,978,42,-207,-1000,244,291,403,-328,-159,-625,-423,413,361,54,-199,673,1000,604,242,885,1000,-819,-606,1000,452,409,892,-384}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00791() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getStaticSourceFile():com.google.javascript.rhino.jstype.StaticSourceFile",
            new int[]{12,-502,578,942,856,-1000,-517,849,-662,-455,-365,289,129,-513,1000,-169,-307,-408,-641,535,761,-661,769,502,242,-15,-421,562,-297,-480,638,-1000,90,704,880,593,906,-451,1000,-285,-261,-811,-54,-1000,-27,940,-566,-353,185,-762,322,-223,782,267,224,1000,959,-433,-645,-77,-137,43,309,-85}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00792() {
        org.junit.Assert.assertEquals("THROW:java.lang.UnsupportedOperationException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getString():java.lang.String",
            new int[]{956,-521,-48,186,-1000,707,667,-794,1000,664,-939,-997,-291,-345,245,-400,604,-877,-308,-1000,1000,-501,-986,302,1000,-752,-1000,843,393,-600,-1000,-1000,449,71,-422,-154,1000,1000,1000,648,-253,-541,-735,-274,216,-1000,-1000,-56,-767,-37,1000,-1000,1000,1000,1000,-333,1000,-1000,-251,312,145,-240,-37,150}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00793() {
        org.junit.Assert.assertEquals("THROW:java.lang.UnsupportedOperationException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getString():java.lang.String",
            new int[]{1000,728,775,-794,-527,866,1000,882,298,450,-973,-1000,-718,-1000,51,824,1000,-1000,-817,-1000,1000,-347,890,-523,762,-645,41,1000,380,-1000,173,-1000,22,-1000,-20,146,-662,1000,1000,1000,-760,-646,-618,-1000,-485,255,897,1000,8,1000,1000,-234,1000,1000,-115,546,191,-1000,1000,-362,1000,-947,-667,563}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00794() {
        org.junit.Assert.assertEquals("THROW:java.lang.UnsupportedOperationException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getString():java.lang.String",
            new int[]{-740,124,-28,-1000,1000,728,-1000,213,-1000,-1000,970,1000,310,523,344,1000,488,198,1000,1000,-1000,-686,1000,-645,-534,1000,1000,-499,-2,43,1000,1000,321,384,-654,1000,-701,-1000,-183,-1000,-437,645,1000,926,757,855,-450,-222,1000,-1000,-1000,1000,-1000,-868,278,133,-889,-722,-1000,-943,-264,15,-543,-189}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00795() {
        org.junit.Assert.assertEquals("THROW:java.lang.UnsupportedOperationException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getString():java.lang.String",
            new int[]{514,-141,-196,231,-73,834,671,-134,1000,969,-719,60,-1000,-572,185,893,1000,-359,185,-199,-200,-433,61,-154,593,85,171,685,-728,-845,-357,-1000,424,4,-484,-1000,-891,90,122,-167,-668,-113,431,-336,-217,-1000,725,220,-1000,-1000,629,-9,560,1000,520,-177,658,-902,178,137,-727,75,-289,-90}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00796() {
        org.junit.Assert.assertEquals("THROW:java.lang.UnsupportedOperationException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getString():java.lang.String",
            new int[]{955,-126,-978,320,1000,564,740,-1000,823,1000,-883,198,-670,-640,73,-927,407,-419,480,-5,-238,-367,-796,733,348,924,-718,501,-1000,-998,-1000,995,72,357,208,-874,-271,217,-330,-56,-477,667,-423,-44,-862,-1000,544,219,17,304,-969,45,-689,-179,1000,957,772,-453,-489,-162,-456,1000,-205,7}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00797() {
        org.junit.Assert.assertEquals("THROW:java.lang.UnsupportedOperationException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getString():java.lang.String",
            new int[]{-876,9,554,-1000,1000,838,-692,-227,-436,-706,651,1000,251,788,499,704,1000,274,777,567,-552,-1000,1000,-1000,-684,242,1000,-234,1000,557,1000,342,146,-52,-39,185,-66,-1000,1000,-1000,-343,-5,1000,996,593,108,881,770,-47,-970,99,1000,-998,954,664,588,-939,-1000,-1000,-1000,62,-675,-894,472}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00798() {
        org.junit.Assert.assertEquals("THROW:java.lang.UnsupportedOperationException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getString():java.lang.String",
            new int[]{1000,-266,-69,612,-1000,513,280,-78,963,-653,-967,-6,-1000,-1000,-365,1000,1000,-1000,-1000,-153,-1000,-1000,-1000,476,1000,-1000,191,-603,-1000,372,-337,-1000,607,1000,530,-1000,1000,1000,1000,-1000,-344,-525,258,497,-670,92,-728,-160,-1000,-1000,417,-1000,1000,1000,-710,-1000,-415,-514,-1000,-1000,-760,131,1000,837}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00799() {
        org.junit.Assert.assertEquals("THROW:java.lang.UnsupportedOperationException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getString():java.lang.String",
            new int[]{1000,-156,-60,186,-817,613,-537,-1000,909,698,-1000,-472,-591,-678,-56,-1000,297,-767,-437,-961,1000,-337,-1000,531,1000,-53,-1000,623,304,-1000,-311,-156,37,496,-348,-154,1000,458,979,648,-66,-518,-873,29,598,-1000,-1000,-330,-767,-58,-31,-922,999,1000,1000,365,1000,-1000,-165,898,-53,340,131,437}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00800() {
        org.junit.Assert.assertEquals("THROW:java.lang.UnsupportedOperationException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getString():java.lang.String",
            new int[]{956,913,105,-1000,1000,839,1000,-122,1000,644,-728,-841,-593,-340,-970,-400,604,-1000,-1000,-1000,439,-1000,1000,-1000,357,1000,311,1000,393,-1000,-229,-264,-223,106,-923,581,-808,514,1000,1000,-38,-441,-1000,-948,-373,-1000,676,1000,-1000,113,1000,-130,-464,34,1000,546,686,-1000,615,460,196,-1000,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00801() {
        org.junit.Assert.assertEquals("THROW:java.lang.UnsupportedOperationException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getString():java.lang.String",
            new int[]{451,-391,950,-909,183,681,31,1000,1000,-290,55,-695,231,1000,395,1000,1000,-868,-361,-516,262,-1000,-511,-805,-591,-1000,121,125,1000,846,1000,-1000,-122,-595,469,983,459,518,-254,73,-218,-1000,-400,-632,98,-1000,-15,1000,-1000,-148,1000,-480,287,461,-363,-1000,556,-539,346,-1000,714,-1000,-811,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00802() {
        org.junit.Assert.assertEquals("THROW:java.lang.UnsupportedOperationException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getString():java.lang.String",
            new int[]{512,497,-520,-217,-89,789,571,-929,-197,631,-1000,-6,-887,180,-1000,373,457,119,1000,-18,-675,-536,-798,676,1000,533,-20,290,-1000,-1000,-192,400,583,1000,-771,-450,228,20,172,-372,-296,330,-20,-108,-498,-775,-23,49,373,-994,1000,-196,342,999,815,1000,95,-917,-340,94,-303,715,688,31}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00803() {
        org.junit.Assert.assertEquals("THROW:java.lang.UnsupportedOperationException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getString():java.lang.String",
            new int[]{850,-216,-518,-1000,-1000,754,-1000,-209,21,-423,-406,-553,-160,-26,815,314,591,-548,998,-62,1000,66,105,-1000,1000,-239,670,878,738,298,-216,-801,110,-1000,-774,1000,510,503,1000,1000,-254,7,368,547,1000,-88,-510,120,641,764,1000,52,1000,525,900,947,1000,-1000,-720,623,921,-608,-1000,-819}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00804() {
        org.junit.Assert.assertEquals("THROW:java.lang.UnsupportedOperationException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getString():java.lang.String",
            new int[]{317,714,938,-976,1000,596,967,-928,434,367,-438,-913,-138,3,-525,225,239,366,432,276,-1000,-366,-285,196,-29,1000,-343,780,-1000,-926,-866,388,588,323,-926,-192,-295,-46,-164,-1000,-566,219,348,-158,-1,-1000,730,825,933,156,-584,-527,-1000,1000,560,1000,1000,-257,898,537,-952,1000,-365,-391}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00805() {
        org.junit.Assert.assertEquals("THROW:java.lang.UnsupportedOperationException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getString():java.lang.String",
            new int[]{120,-921,6,-11,-860,187,-537,686,-633,-97,434,1000,-360,-1000,451,132,944,-214,343,951,-94,-86,-416,532,528,-582,-231,-997,-56,266,-144,310,977,1000,160,-229,1000,163,400,183,-473,-218,596,138,1000,1000,-450,-921,-400,-949,-1000,309,370,967,138,1000,1000,-340,-1000,-340,399,-1000,-46,255}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00806() {
        org.junit.Assert.assertEquals("THROW:java.lang.UnsupportedOperationException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getString():java.lang.String",
            new int[]{-348,729,-704,-742,1000,866,341,-666,182,680,-317,1000,-460,-351,-498,-107,561,256,561,237,-1000,-895,736,-814,-355,1000,578,356,666,-995,35,-456,242,720,354,-192,31,-914,969,-1000,-465,-234,-89,29,92,-1000,1000,1000,-440,445,-510,-606,-1000,753,1000,1000,658,-932,28,125,-498,271,-912,882}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00807() {
        org.junit.Assert.assertEquals("THROW:java.lang.UnsupportedOperationException", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getString():java.lang.String",
            new int[]{-611,-81,775,-900,378,694,-298,-99,-56,-283,-414,-71,116,-866,258,-428,769,929,-51,-219,-839,-807,446,-316,-353,396,265,-895,792,669,698,573,-832,-729,582,832,-431,505,-84,-950,35,171,123,-87,-865,-678,-382,650,305,-436,-346,-361,-356,431,930,699,-410,483,329,-549,-879,-342,-661,173}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00808() {
        org.junit.Assert.assertEquals("java.lang.Integer:MTMy", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getType():int",
            new int[]{-250,279,-892,596,-459,819,227,-845,-1000,-163,1000,590,-379,-696,697,-776,66,-422,676,-1000,-900,480,1000,-274,-417,-114,285,91,911,1000,-450,1000,532,412,142,1000,-713,-1000,972,-598,-143,1000,140,451,-1000,-1000,-171,1000,806,-1000,-400,-892,-914,-842,-1000,-259,-179,-1000,-594,-1000,69,1000,-1000,-129}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00809() {
        org.junit.Assert.assertEquals("java.lang.Integer:MTMy", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getType():int",
            new int[]{410,709,725,-1000,530,1000,911,-984,75,-945,-432,-877,-733,569,860,-1000,952,152,809,-787,-167,-571,170,-1000,253,448,750,-265,1000,627,772,655,-48,178,1000,988,-654,-502,1000,419,294,-141,625,296,-1000,446,-171,575,281,-507,-1000,249,-316,-161,-76,-722,-350,-126,395,177,377,828,534,151}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00810() {
        org.junit.Assert.assertEquals("java.lang.Integer:MTMy", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getType():int",
            new int[]{410,709,-767,753,-89,66,1000,-984,-1000,195,917,841,764,-795,428,-313,362,-254,288,-605,-1000,-571,1000,218,-719,110,-43,1000,-696,627,772,1000,-259,178,-733,1000,-398,-723,-84,-876,294,999,-159,882,-271,-728,1000,575,927,-507,-1000,249,-1000,357,-1000,-163,164,-1000,1000,-664,-549,-162,-1000,-231}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00811() {
        org.junit.Assert.assertEquals("java.lang.Integer:MTMy", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getType():int",
            new int[]{-714,-816,238,-1000,816,862,-1000,-427,296,-1000,563,-1000,-213,1000,-875,-621,-208,555,1000,-97,-144,1000,-956,-792,851,-756,455,-328,-639,-101,-787,-1000,1000,-992,162,-381,625,-124,-95,-298,-610,-1000,1000,-1000,243,220,-1000,813,-371,572,1000,-188,226,68,1000,686,380,-920,-1000,1000,436,-84,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00812() {
        org.junit.Assert.assertEquals("java.lang.Integer:MTMy", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getType():int",
            new int[]{-409,509,290,-125,-1000,387,-284,-738,6,-916,-940,485,-1000,-1000,402,-594,-1000,173,141,93,-333,-1000,432,423,284,-458,-282,-1000,-561,384,528,-586,492,-341,93,768,-423,-314,-254,-473,498,-96,-123,1000,434,-633,-193,353,164,129,592,-488,756,-1000,357,-152,199,1000,-437,160,537,-840,209,791}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00813() {
        org.junit.Assert.assertEquals("java.lang.Integer:MTMy", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getType():int",
            new int[]{243,-256,-1000,-1000,227,208,-240,-492,296,443,844,-1000,361,1000,-114,71,1000,576,786,-1000,-511,1000,-555,-1000,728,1000,1000,751,-1000,48,-952,72,8,-188,96,563,142,-258,1000,-91,-35,886,825,-946,-1000,-473,-268,894,-667,-1000,568,1000,-1000,1000,-632,847,-960,-1000,726,503,431,1000,954,-687}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00814() {
        org.junit.Assert.assertEquals("java.lang.Integer:MTMy", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getType():int",
            new int[]{-89,-456,-274,-549,-1000,-1000,-312,-1000,-400,-946,232,-891,-539,-50,-1000,-725,359,1000,-230,-438,-40,91,-578,-1000,1000,1000,-1000,387,69,-314,-109,-215,1000,-488,-1000,-204,842,21,369,-357,1000,1000,-606,-1000,-1000,1000,1000,-408,1000,-597,1000,1000,-1000,1000,-1000,734,-1000,714,-18,-1000,637,-295,546,-522}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00815() {
        org.junit.Assert.assertEquals("java.lang.Integer:MTMy", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getType():int",
            new int[]{-1000,454,62,-562,1000,1000,-934,-949,-487,-1000,-1000,-385,-501,-293,-268,-1000,-651,-372,1000,85,-25,-387,917,-1000,505,-1000,-554,-226,-1000,529,409,904,1000,-480,-1000,-1000,320,322,-127,-859,-868,-1000,333,54,1000,-1000,869,-320,-599,1000,1000,-1000,1000,-385,1000,-789,88,466,-725,1000,702,-1000,1000,440}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00816() {
        org.junit.Assert.assertEquals("java.lang.Integer:MTMy", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getType():int",
            new int[]{-784,-91,-840,-950,1000,943,-55,231,-1000,-729,142,197,1000,941,426,-199,-651,-412,762,-716,-1000,651,642,-618,623,-541,450,-1000,-1000,778,-1000,-424,-102,147,604,-157,-968,-992,793,-52,-1000,-1000,735,273,1000,-880,-1000,869,-1000,154,600,-1000,1000,-1000,1000,-180,471,-780,-372,1000,1000,391,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00817() {
        org.junit.Assert.assertEquals("java.lang.Integer:MTMy", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getType():int",
            new int[]{-933,-816,617,-305,-1000,-517,-1000,-675,1000,-1000,-1000,-357,-734,-1000,-654,-746,-1000,555,1000,479,200,-1000,-207,1000,1000,-371,-440,-1000,-1000,-14,143,-1000,1000,-668,162,-381,-219,164,-95,258,278,-344,-675,-15,243,633,-684,-838,240,1000,1000,265,1000,-1000,357,-88,39,1000,-721,160,1000,-1000,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00818() {
        org.junit.Assert.assertEquals("java.lang.Integer:MTMy", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getType():int",
            new int[]{-709,-496,-298,448,-1000,-1000,-1000,-852,1000,-1000,-66,-438,-949,-1000,-1000,-669,-1000,1000,111,-173,-210,-617,-29,1000,1000,167,-169,-708,-1000,171,-846,-176,1000,-219,-1000,1000,-202,-123,-507,252,-152,645,-858,-823,843,1000,-51,-1000,1000,678,1000,1000,639,-1000,-1000,-100,-167,1000,-475,-1000,1000,-1000,1000,944}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00819() {
        org.junit.Assert.assertEquals("java.lang.Integer:MTMy", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getType():int",
            new int[]{193,-512,-834,-611,816,-905,-1000,-815,296,-1000,-384,-459,-255,562,-875,-621,913,-661,1000,-97,-1000,1000,-875,-792,204,-23,205,-1000,-1000,-217,-787,-1000,1000,-522,-1000,247,972,-290,-743,-1000,-206,211,348,-1000,111,388,-418,-462,771,552,1000,1000,226,101,1000,767,41,-856,-1000,1000,436,-603,1000,-33}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00820() {
        org.junit.Assert.assertEquals("java.lang.Integer:MTMy", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getType():int",
            new int[]{-1000,909,-574,-562,1000,713,-318,-326,-1000,-1000,-236,112,-385,4,-223,-1000,-824,353,1000,-370,-1000,-232,1000,526,1000,-1000,458,1000,-1000,968,-185,-1000,1000,-52,-1000,-157,-179,-198,-203,-656,-1000,-1000,-10,-45,289,-1000,-1000,353,-56,283,1000,-992,1000,-909,1000,-1000,547,933,-325,1000,1000,-840,-446,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00821() {
        org.junit.Assert.assertEquals("java.lang.Integer:MTMy", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getType():int",
            new int[]{-84,89,-587,-461,-40,1000,-1000,-434,-974,-334,-448,-711,-630,-931,540,1000,-1000,-238,-11,-242,-790,-260,833,534,522,-977,-408,-1000,-468,826,-109,-884,1000,-98,105,707,-156,-387,-480,1000,-882,-1000,770,850,1000,-860,-1000,1000,376,378,-807,-1000,1000,-480,1000,-919,1000,-775,-1000,1000,1000,-660,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00822() {
        org.junit.Assert.assertEquals("java.lang.Integer:MTMy", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getType():int",
            new int[]{-361,509,454,-437,-1000,417,182,-738,-851,386,-608,485,-991,-874,402,640,-1000,30,142,454,-458,-1000,310,613,-930,-1000,-861,-483,-945,751,528,-586,492,-1000,731,728,783,304,622,607,498,-885,-79,286,578,-710,-1000,547,1000,129,-960,-1000,75,-1000,1000,-1000,1000,411,-837,-854,899,-371,-18,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00823() {
        org.junit.Assert.assertEquals("java.lang.Integer:MTMy", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "getType():int",
            new int[]{349,-502,632,-675,-700,918,-418,-92,586,204,-774,-269,209,32,322,-238,-502,7,64,-767,45,-27,-289,-112,262,222,-426,-786,734,651,185,581,-44,-898,-1000,639,-984,-484,-1000,-141,562,345,60,140,150,546,362,-470,-291,-215,-173,274,654,303,-906,605,830,1000,10,1000,599,64,108,-134}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00824() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasChild(com.google.javascript.rhino.Node):boolean",
            new int[]{-472,-806,-383,453,-109,-273,927,-624,666,1000,591,-35,-418,-470,-670,-1000,-520,134,-1000,461,262,-577,-459,249,-35,-492,65,35,658,-1000,-856,637,167,719,550,-94,-91,808,-618,504,375,-1000,-913,-712,-33,1000,-1000,614,172,126,243,1000,-232,176,615,-419,364,1000,-660,1000,-1000,842,-309,-510}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00825() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasChild(com.google.javascript.rhino.Node):boolean",
            new int[]{-303,29,431,-1,-37,-434,68,-49,425,502,405,-27,-405,143,1000,1000,404,65,-990,-5,507,11,-131,-106,-354,800,411,1000,14,-124,270,122,312,367,62,-613,-643,417,-629,399,261,268,-526,138,-105,-164,70,474,1000,341,-250,-97,-13,-222,584,0,327,589,638,-462,-185,824,184,347}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00826() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasChild(com.google.javascript.rhino.Node):boolean",
            new int[]{-1000,274,6,-7,-414,377,-101,-1000,306,-372,663,1000,1000,1000,-713,794,78,-420,-680,-406,877,20,205,-1000,1000,147,-459,613,164,-461,-1000,-57,314,1000,-67,-12,-243,-641,569,221,876,-15,1000,-361,637,1000,-225,275,-1000,888,-1000,-50,-162,-560,373,-695,798,-201,201,-287,1000,824,-1000,426}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00827() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasChild(com.google.javascript.rhino.Node):boolean",
            new int[]{-65,739,164,140,-888,559,370,-220,-681,-1000,63,749,-149,274,1000,951,-759,182,-276,739,-619,282,-932,-518,687,688,-1000,-52,-725,87,-883,-488,199,916,-691,400,-266,-592,-510,-728,396,518,731,-453,-126,-1000,6,-115,108,768,-668,-1000,-250,-585,595,678,600,-392,964,-1000,1000,842,-390,258}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00828() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasChild(com.google.javascript.rhino.Node):boolean",
            new int[]{343,474,-900,-122,-508,-146,648,-122,325,322,-787,1000,327,-943,-466,-542,-1000,-912,-525,-223,-1000,-473,-465,-1000,1000,-236,-563,20,1000,-345,-843,-1000,545,1000,523,-860,-437,-1000,-542,1000,1000,-1000,910,-910,-973,848,-655,1000,-686,156,2,-268,-44,383,1000,561,1000,313,-766,-1000,951,1000,-798,-571}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00829() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasChild(com.google.javascript.rhino.Node):boolean",
            new int[]{-1000,19,878,657,934,-1000,204,-1000,-1000,1000,253,819,88,-980,527,-1000,-763,613,-456,1000,1000,-1000,-756,278,1000,1000,-1000,-148,-1000,-103,-996,1000,1000,21,1000,1000,-356,1000,-1000,-635,-1000,-1000,635,178,-72,-1000,579,1000,-1000,1000,234,1000,-1000,1000,835,1000,-182,1000,-187,1000,-493,219,-179,-928}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00830() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasChild(com.google.javascript.rhino.Node):boolean",
            new int[]{-918,-681,-717,-586,-261,-433,766,-859,524,1000,946,541,93,-913,-1000,-1000,-657,44,-222,329,383,-997,-298,249,-44,-634,-249,-493,977,-1000,-937,650,444,719,829,-1000,126,1000,-610,713,310,-1000,-913,-135,-33,798,-1000,752,172,126,475,1000,-618,856,615,44,-154,758,-1000,819,-1000,1000,-527,-743}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00831() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasChild(com.google.javascript.rhino.Node):boolean",
            new int[]{-1000,-521,-446,722,-365,-549,505,-518,1000,1000,766,-859,-636,302,-145,105,549,426,-1000,-385,1000,-730,149,861,-1000,63,1000,1000,686,-1000,123,1000,169,212,469,-1000,-210,1000,-230,419,214,1000,-1000,-310,506,474,-784,741,948,60,-20,812,-32,-22,324,-970,178,881,-811,915,-805,309,63,152}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00832() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasChild(com.google.javascript.rhino.Node):boolean",
            new int[]{-1000,384,-668,1000,-444,457,1000,-762,740,304,-14,289,-701,-149,-161,-1000,-1000,391,-1000,1000,646,-1000,-1000,1000,64,-439,-440,-1000,1000,-1000,-1000,1000,263,551,698,665,551,1000,-665,-121,354,-1000,-1000,-174,1000,-474,-1000,713,1000,-88,558,-812,-888,582,1000,-620,305,-189,-674,-312,346,1000,-508,-739}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00833() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasChild(com.google.javascript.rhino.Node):boolean",
            new int[]{-18,-521,-49,-584,253,-524,65,-216,929,1000,-825,-10,111,-228,98,105,-497,60,-232,154,238,-28,-305,1000,-8,489,274,1000,-152,199,123,-288,51,493,-262,-129,-95,1000,-604,95,114,-912,-79,69,-461,14,487,201,-223,44,-320,812,-211,-65,709,-262,89,881,-1000,-1000,961,37,-131,14}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00834() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasChild(com.google.javascript.rhino.Node):boolean",
            new int[]{-800,909,-103,511,-443,12,387,-585,-1000,-459,755,1000,-754,-1000,1000,813,-1000,-955,-1000,127,-483,-275,-1000,-939,-229,1000,-1000,1000,-161,-580,-373,-935,51,437,998,1000,-392,-865,-1000,611,293,-880,1000,-184,-398,-400,97,934,1000,208,-77,-812,-514,960,23,-1000,-3,525,355,-1000,83,334,-785,-714}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00835() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasChild(com.google.javascript.rhino.Node):boolean",
            new int[]{418,219,-403,750,-564,38,1000,255,151,31,558,1000,-873,-945,658,-346,-1000,-490,-718,379,-838,-247,-1000,-316,1000,327,-376,861,970,-66,-771,-502,350,599,912,1000,-423,-544,-983,1000,478,-1000,507,-869,-34,73,-1000,810,-551,-206,948,-812,295,445,1000,373,1000,656,-175,-915,-383,774,-667,-946}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00836() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasChild(com.google.javascript.rhino.Node):boolean",
            new int[]{45,-681,527,-21,703,-835,618,-1000,-1000,616,-318,1000,299,-1000,-86,-1000,-657,-195,-222,1000,-456,-400,-1000,-676,1000,246,-249,-677,-1000,94,-1000,-3,1000,748,663,1000,-105,-49,-1000,288,-260,-1000,1000,-465,-685,-317,-241,930,-1000,1000,375,1000,-622,854,972,868,517,1000,191,1000,-525,745,-515,-861}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00837() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasChild(com.google.javascript.rhino.Node):boolean",
            new int[]{1000,-462,349,-1000,660,-89,647,-86,-858,-784,-935,237,-182,-556,177,-1000,-863,-143,1000,238,-1000,1000,-1000,-1000,987,76,-687,-480,-1000,634,-774,-1000,-138,1000,-462,1000,-193,-1000,-553,-31,339,777,1000,-1000,-1000,1000,145,-64,-1000,687,-288,1000,343,-546,1000,-175,-30,1000,862,1000,-343,373,-435,-90}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00838() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasChild(com.google.javascript.rhino.Node):boolean",
            new int[]{613,384,236,558,-403,-109,1000,400,-8,-95,878,-150,-1000,28,365,231,-316,-10,-902,152,-729,400,-1000,589,680,585,522,1000,-176,528,486,17,-11,-189,256,1000,-762,294,-611,312,-62,-1000,-744,-122,675,-405,-636,896,-142,-104,906,-400,986,-125,-175,-400,169,989,758,204,-1000,-218,-101,97}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00839() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasChild(com.google.javascript.rhino.Node):boolean",
            new int[]{418,219,-477,750,177,-645,-665,391,-866,942,-1000,1000,-508,-1000,658,-808,465,1000,1000,-195,-1000,1000,-373,1000,-415,-924,-549,-1000,437,772,-53,-1000,608,485,-1000,1000,1000,-1000,-740,-1000,188,-741,507,831,-1000,1000,809,-1000,-694,-703,-32,816,57,445,638,-42,1000,-66,-1000,182,400,73,-256,220}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00840() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasChildren():boolean",
            new int[]{-1000,-136,707,321,443,582,-54,-416,-388,-827,-1000,280,308,579,-253,-631,-1000,1000,-20,1000,-877,277,761,-58,1000,-842,1000,395,115,740,-964,-788,-1000,48,1000,-11,716,-1000,179,-177,324,168,947,1000,-540,-1,1000,-992,-686,-879,-518,-135,-917,1000,-1000,955,-178,533,1000,759,907,970,460,567}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00841() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasChildren():boolean",
            new int[]{970,263,5,868,899,547,361,723,-863,620,763,1000,149,-190,-107,845,-534,162,-116,642,-148,-549,297,725,-744,51,606,-120,-316,1000,1000,483,-908,-619,1000,-468,-1000,-249,-940,-315,1000,-579,-112,1000,142,296,712,746,289,561,-147,-358,-67,293,-1000,-285,-356,974,-282,1000,-191,-807,-111,617}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00842() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasChildren():boolean",
            new int[]{-240,209,-137,-1000,-154,1000,-484,183,179,1000,-1000,279,364,-1000,-230,483,1000,-483,-807,-845,319,-1000,721,-454,-788,-413,-1000,305,161,-922,825,1000,1000,517,-489,967,-1000,314,-853,-603,207,116,-329,-963,1000,-375,-540,932,823,417,867,204,70,513,293,47,1000,-764,-400,-56,-966,1000,583,358}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00843() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasChildren():boolean",
            new int[]{-259,324,862,-861,-16,-104,-747,-802,58,115,-219,-616,-107,362,563,244,77,-229,-983,-178,907,-171,-329,-647,742,202,-12,439,-797,-969,-58,-18,696,746,-596,-342,988,109,47,-8,108,604,-551,-800,723,584,336,-107,325,-350,-476,437,50,610,968,336,756,-928,-401,346,118,-752,-891,179}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00844() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasChildren():boolean",
            new int[]{200,519,-361,60,277,-204,-862,-591,282,-670,66,571,523,379,374,-652,-43,443,-363,1000,-196,-371,597,44,496,-6,601,363,247,-48,-586,-143,-1000,-392,-18,906,-749,-270,1000,889,943,286,606,1000,-537,116,1000,597,756,497,-1000,1000,-281,473,-875,323,-1000,156,710,905,-141,1000,78,780}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00845() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasChildren():boolean",
            new int[]{200,399,168,-435,860,787,-862,642,-444,752,66,734,774,-483,490,782,-378,-2,-722,317,-29,-733,767,343,-925,-111,601,-513,-519,-87,802,725,7,97,883,-489,-211,-407,-470,380,943,-233,-714,240,292,73,974,469,756,-2,-813,647,518,955,-943,323,873,-285,-266,-460,-203,467,-454,42}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00846() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasChildren():boolean",
            new int[]{-241,-26,-890,1000,27,-399,-36,-223,-313,-932,400,1000,-1000,478,116,-754,-145,890,-142,577,-802,415,1000,-199,223,583,-819,-71,879,-609,-1000,-868,-1000,-271,100,977,-567,322,350,-1000,-1000,1000,764,1000,-1000,-1000,1000,-1000,-1000,497,-463,1000,296,623,-422,-532,-299,31,52,683,437,489,738,-716}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00847() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasChildren():boolean",
            new int[]{423,588,-821,-1000,371,942,-1000,611,-7,1000,1000,1000,481,-1000,740,610,1000,-1000,-1000,-714,788,-1000,255,110,-292,631,-743,190,-1000,-1000,860,1000,-175,82,528,19,1000,712,-838,43,-34,638,-1000,-981,1000,801,213,920,1000,-1000,-255,1000,819,147,588,90,1000,-1000,-1000,-297,290,-935,-1000,-268}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00848() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasChildren():boolean",
            new int[]{-21,123,484,-1000,-592,-198,745,-19,335,-547,140,-1000,-463,-632,431,527,1000,-483,-93,1000,564,-371,-290,-634,-547,741,-1000,809,-261,-1000,650,1000,1000,194,-173,125,-1000,996,-1000,1000,-106,-95,-404,-977,1000,-160,-1000,456,712,-903,786,-659,-208,623,658,-371,652,-461,1000,169,-901,-919,-499,623}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00849() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasChildren():boolean",
            new int[]{574,908,-309,-205,548,-214,-124,-134,-713,202,1000,341,1000,781,1000,718,-145,448,286,744,-198,-319,-84,317,86,1000,-576,-23,-1000,437,-294,341,-1000,-1000,100,-159,1000,289,161,1000,-1000,-130,32,745,127,841,1000,-66,-155,46,-1000,1000,1000,239,-813,63,-320,275,976,457,135,1000,-400,371}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00850() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasChildren():boolean",
            new int[]{840,-706,240,1000,-763,-180,1000,-1000,-622,-25,957,-1000,-1000,675,-731,87,789,270,795,-88,87,-237,-1000,-7,349,613,-416,1000,307,1000,616,277,1000,-837,-78,32,833,717,-893,-599,-299,-433,1000,1000,459,-747,-773,-154,71,625,745,-1000,-787,-811,-1000,-725,-1000,1000,-415,-31,106,702,326,632}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00851() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasChildren():boolean",
            new int[]{1000,324,508,1000,-167,156,1000,-1000,-1000,498,1000,-1000,-1000,675,-818,1000,789,1000,542,50,-13,-794,-1000,599,151,-256,920,1000,-534,1000,1000,277,290,-993,551,-1000,-1000,717,-583,-1000,1000,-1000,840,1000,82,-571,599,-350,-380,20,550,-433,-190,-382,-1000,-203,-404,1000,-228,-763,549,1000,-891,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00852() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasChildren():boolean",
            new int[]{-410,189,832,-334,650,820,-685,51,-477,256,-456,355,-56,-33,184,419,-1000,538,-709,310,177,-164,240,-109,717,-437,908,78,-846,-326,338,13,-654,467,864,-698,1000,-716,-557,-847,1000,97,-400,367,356,522,961,-306,463,-947,-446,253,-147,1000,-601,606,1000,-259,153,-47,474,-385,-515,58}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00853() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasChildren():boolean",
            new int[]{841,-26,628,1000,40,-448,1000,-686,-540,-73,777,-1000,-1000,781,-290,334,-145,5,-117,286,736,92,-1000,-101,1000,434,-6,1000,-507,864,1000,-365,-612,-276,100,-312,-1000,335,-624,-1000,490,110,309,1000,26,-212,-39,289,-343,454,-174,-1000,-785,-337,-960,-532,-1000,871,-425,-252,135,489,-400,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00854() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasChildren():boolean",
            new int[]{-137,-641,296,1000,-225,-131,1000,-955,-1000,9,47,-799,1000,957,-264,-186,-1000,1000,1000,1000,-1000,-494,167,380,45,0,318,283,177,1000,-1000,468,-349,-1000,1000,-515,654,-872,-207,-371,-642,-1000,1000,1000,364,-36,1000,-1000,-1000,630,-384,577,475,-29,-1000,825,5,1000,167,575,1000,1000,135,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00855() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasChildren():boolean",
            new int[]{-1000,-1,737,-1000,-223,-342,-116,-1000,147,-968,-1000,-690,256,975,126,423,-1000,1000,-293,1000,-206,-1000,193,-596,1000,-202,-23,755,-500,-485,-1000,-818,118,328,-266,345,705,358,784,662,-568,675,796,587,-173,61,887,-793,-825,-282,-548,48,-720,942,71,685,-422,-136,999,1000,551,602,84,687}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00856() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasMoreThanOneChild():boolean",
            new int[]{1000,-161,-1000,-1000,-2,-1000,517,15,-540,766,209,78,988,-1000,1000,-522,-954,1000,-416,-798,-1000,-1000,940,-160,-1000,171,446,716,1000,380,-1000,-1000,-499,943,1000,860,-540,1000,1000,280,-516,486,-1000,11,397,1000,1000,-62,-625,-166,310,-232,-482,1000,438,-274,461,536,329,927,-107,440,439,-435}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00857() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasMoreThanOneChild():boolean",
            new int[]{1000,154,-503,-83,-812,-485,1000,-200,146,367,548,-761,988,989,-94,-935,271,1000,-512,-726,-493,-769,-343,487,18,618,135,-48,541,283,-812,102,-134,-121,775,-483,782,189,603,405,49,932,-1000,1000,1000,961,565,-508,855,1000,-46,1000,29,-265,-761,-1000,266,186,-789,1000,832,-409,783,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00858() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasMoreThanOneChild():boolean",
            new int[]{734,-596,-208,520,-71,35,217,-285,400,26,324,-678,-816,275,281,-226,-431,1000,-13,-619,-690,193,-371,-424,-746,-201,564,537,759,-46,934,-173,153,-623,-339,251,-760,-1000,902,-216,-222,206,-541,173,584,1000,-304,-360,-87,792,1000,133,-424,531,205,-256,158,377,-238,223,312,-84,-29,-511}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00859() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasMoreThanOneChild():boolean",
            new int[]{414,-486,-459,-133,962,-732,538,-622,-102,951,1000,714,1000,1000,-268,-1000,66,312,-1000,-1000,199,-100,283,1000,-74,120,108,-889,337,288,-576,-38,1000,177,217,149,-1000,548,-135,516,-404,1000,-1000,634,9,1000,438,-311,1000,1000,-98,842,-462,403,-1000,-1000,476,-55,-63,494,1000,-588,-181,-539}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00860() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasMoreThanOneChild():boolean",
            new int[]{780,-186,-780,-866,-945,128,377,-478,-532,134,298,-259,1000,-269,-123,-604,241,906,-556,412,-593,-126,285,701,177,520,-908,-550,345,819,-898,-787,-786,482,973,-405,1000,1000,613,-764,-587,601,-778,565,1000,146,1000,-727,-199,339,-583,344,681,652,-951,-895,-88,197,-776,1000,-630,132,218,-927}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00861() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasMoreThanOneChild():boolean",
            new int[]{195,229,-100,907,-1000,1000,711,-1000,192,-239,-275,-210,859,1000,-1000,-284,-451,935,-1000,-1000,50,1000,-898,1000,660,-482,-1000,-661,-666,1000,484,1000,1000,-864,-634,1000,982,-693,503,1000,-700,1000,-1000,1000,4,826,-856,-892,935,328,339,1000,1000,-386,-785,-1000,782,-887,1000,507,500,-282,307,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00862() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasMoreThanOneChild():boolean",
            new int[]{1000,-41,-573,-1000,-584,-523,133,190,-423,1000,1000,-756,1000,1000,-47,-445,-63,954,-1000,-1000,88,-162,147,-39,-579,1000,879,-374,496,-590,-907,-1000,-942,-1000,1000,-1000,1000,400,473,649,-906,1000,-1000,174,390,533,42,237,500,773,-372,1000,190,70,-471,-1000,-752,-192,-557,524,588,-1000,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00863() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasMoreThanOneChild():boolean",
            new int[]{1000,-311,-1000,-993,10,-990,379,-821,-156,296,537,123,1000,-159,1000,-472,-317,1000,-541,892,-1000,-338,159,597,-1000,21,-2,346,1000,838,526,-1000,-1000,355,1000,-1000,-1000,500,-557,-361,232,1000,-1000,684,1000,266,1000,-109,464,1000,-904,89,-226,685,-1000,-930,556,-985,-968,1000,1000,300,-457,-896}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00864() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasMoreThanOneChild():boolean",
            new int[]{1000,-512,-1000,-1000,876,-1000,472,-1000,-988,921,874,394,1000,-513,1000,-966,-942,1000,-573,1000,-1000,-1000,130,495,-1000,-49,194,-310,1000,-505,-11,-1000,-1000,1000,1000,-1000,-629,722,72,-874,638,1000,-1000,975,1000,385,1000,-423,464,1000,-730,-124,-518,1000,-1000,-1000,648,-343,-1000,1000,-73,534,-246,-170}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00865() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasMoreThanOneChild():boolean",
            new int[]{686,-496,-686,-1000,-1000,-468,577,-674,-543,60,3,58,1000,184,-6,-434,888,988,-491,399,-801,566,-122,1000,42,473,-943,-673,64,1000,83,-902,-694,231,1000,-442,252,727,-133,584,-241,744,-682,514,585,-497,1000,-317,1000,91,-1000,876,1000,342,-1000,-1000,-45,-373,-739,1000,371,15,48,-896}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00866() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasMoreThanOneChild():boolean",
            new int[]{552,-776,34,254,-821,1000,1000,-789,-197,-264,237,-1000,1000,921,-1000,-123,1000,982,-331,-521,-716,924,-1000,242,759,127,-344,-921,-810,1000,367,1000,1000,233,-126,841,924,-504,1000,545,-594,635,-546,757,407,-90,-404,-648,1000,-298,556,1000,1000,210,-452,-1000,80,1000,3,829,-226,127,476,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00867() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasMoreThanOneChild():boolean",
            new int[]{1000,-911,-1000,-763,-1000,-303,601,-963,-149,654,312,-493,1000,807,311,322,307,1000,-1000,-641,-1000,-659,-347,865,-714,631,-1000,-4,996,1000,-106,-878,-437,-568,910,-811,957,898,201,559,-25,1000,-896,468,1000,1000,780,96,-607,642,-376,1000,366,860,-1000,-1000,46,-979,-811,1000,788,-238,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00868() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasMoreThanOneChild():boolean",
            new int[]{916,-21,157,57,613,-181,578,-496,-94,-364,616,-92,396,-74,-9,-866,-682,907,406,-130,-522,109,-108,96,-356,165,735,698,99,343,878,-591,-412,914,-207,-360,-816,-723,-143,-438,-241,900,-979,798,683,632,165,-495,136,674,980,-719,-18,626,-604,-682,550,393,-330,564,870,475,-947,-766}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00869() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasMoreThanOneChild():boolean",
            new int[]{213,343,-1000,370,-722,-1000,-740,285,974,1000,896,-47,1000,810,1000,1000,-538,-121,-985,-1000,293,-1000,1000,-1000,-1000,216,1000,1000,1000,-1000,-804,1000,-1000,-323,877,-1000,-76,1000,-340,545,-833,253,-586,-173,1000,1000,1000,1000,-1000,1000,-347,-535,-137,979,-312,408,-150,-257,-542,829,351,-456,637,127}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00870() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasMoreThanOneChild():boolean",
            new int[]{1000,-776,34,-18,264,-700,602,-816,-201,181,796,413,881,629,628,-7,704,528,-633,-765,-120,-1000,493,918,-232,-245,-1,-983,284,-314,1000,-816,486,557,1000,-964,-325,1000,-153,654,484,395,-1000,1000,1000,820,1000,-648,1000,1000,-695,543,-1000,-60,-338,-1000,172,1000,-579,1000,710,218,128,10}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00871() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasMoreThanOneChild():boolean",
            new int[]{1000,168,-100,-1000,-115,-990,-89,-568,-575,910,744,123,1000,-104,1000,-915,-477,1000,-758,844,-573,-285,159,761,-832,-102,276,291,1000,696,521,-1000,-1000,-317,1000,1000,-946,-225,-557,-42,-53,1000,-1000,678,592,293,582,591,464,-166,-782,89,-382,525,-1000,-930,235,-1000,-622,1000,995,-385,-90,-896}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00872() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasOneChild():boolean",
            new int[]{126,-71,-763,993,-1000,-155,-124,-1000,-985,-827,-435,1000,-708,-195,1000,648,1000,54,-864,-120,698,1000,-360,1000,265,406,1000,909,-44,-1000,869,-576,-285,-1000,-452,-721,-565,-659,-803,185,-340,-69,-1000,-980,-604,84,617,-542,1000,616,-510,-21,-488,-653,-435,306,-112,825,-467,84,-1000,538,275,-700}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00873() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasOneChild():boolean",
            new int[]{-964,754,-487,1000,-1000,-260,-65,-1000,-1000,-1000,-1000,-353,-1000,1000,986,-220,771,-1000,887,66,417,135,-669,1000,-1000,-104,1000,941,-1000,-488,-471,-1000,1000,49,-706,457,-1000,-398,-1000,-1000,885,-1000,-1000,-1000,-798,-541,88,710,1000,123,-1000,-1000,175,-1000,-73,928,970,1000,1000,32,-994,-1000,768,-174}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00874() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasOneChild():boolean",
            new int[]{-371,-132,181,-42,15,429,-116,10,-581,318,-1000,756,-740,732,-252,46,-164,168,-240,370,-513,-400,-340,-139,-1000,256,-305,-28,-481,-894,943,339,-837,-1000,-245,-380,622,-704,-417,-668,41,-70,-1000,-303,400,-1000,-637,-887,365,1000,-379,374,126,-864,-380,445,265,493,-55,567,-960,120,-135,-603}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00875() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasOneChild():boolean",
            new int[]{-192,223,547,493,-153,-570,162,-964,-1000,72,-413,-556,-118,588,-316,-370,828,-847,1000,16,1000,683,-661,400,296,503,-677,339,-853,-505,-1000,-3,1000,-87,-842,57,-948,727,842,-1000,986,-958,-385,-935,197,-879,1000,602,801,-446,-1000,-1000,-1000,-1000,-416,100,-297,-155,-407,658,-337,-546,53,-410}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00876() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasOneChild():boolean",
            new int[]{-351,674,-717,1000,387,193,-320,105,41,-928,-701,-473,56,1000,501,-269,452,-503,-359,-87,-55,329,661,1000,1000,403,-699,962,5,-521,150,-938,498,370,-275,-683,-1000,-806,1000,-1000,-597,-1000,-1000,613,174,-626,1000,444,1000,-222,155,-320,-435,3,-336,703,-150,-309,-401,-327,573,166,325,45}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00877() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasOneChild():boolean",
            new int[]{-594,317,-905,746,-776,1000,-471,-357,-1000,-931,881,514,-1000,-355,932,-160,1000,-505,-269,61,-209,804,317,801,665,68,665,986,-132,-1000,1000,-284,540,-798,-997,-192,-644,-646,448,586,-588,-512,-1000,-412,-1000,-239,-223,193,-546,-351,45,405,365,-1000,-482,795,1000,1000,-178,150,-51,995,-42,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00878() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasOneChild():boolean",
            new int[]{154,-426,484,1000,-706,-1000,-97,-469,938,365,630,401,-277,-1000,-508,320,1000,-259,515,149,-265,-544,-779,168,965,818,-521,842,-773,719,-847,561,608,236,-26,-877,-849,696,-1000,-622,596,-580,-230,-1000,1000,-390,741,325,-353,-127,-953,-957,-478,-144,488,13,-1000,912,556,562,500,-351,-94,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00879() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasOneChild():boolean",
            new int[]{346,29,311,126,184,1000,638,25,242,139,-231,635,-768,118,-823,-1000,-54,236,721,371,-861,-884,-188,-491,-211,226,-676,726,-972,-1000,-310,-2,-19,-338,-865,-286,953,541,717,-799,388,-812,261,317,1000,-931,-828,-417,-1000,-915,-108,-404,235,-897,-698,101,187,684,556,163,-816,443,-665,896}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00880() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasOneChild():boolean",
            new int[]{-1000,93,461,-515,359,275,-209,73,474,-49,-585,214,1000,1000,-1000,-825,828,-750,808,473,1000,269,-395,-397,-77,583,400,339,-1000,-431,-1000,434,361,499,207,-586,-1000,731,-360,-1000,1000,-1000,-385,-1000,709,-312,-10,226,1000,-82,21,-624,-743,337,129,-300,448,1000,1000,-194,-518,-1000,115,936}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00881() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasOneChild():boolean",
            new int[]{-598,29,211,-142,35,-215,998,-595,47,689,-111,-81,334,221,556,474,-62,275,-41,-186,358,360,124,-661,-959,-179,-676,-38,-469,-874,-603,-929,-247,-210,-829,-90,953,-344,-668,398,-85,931,-566,-441,272,639,-779,-417,944,954,-63,-159,-958,261,892,101,955,731,196,-333,713,701,252,-816}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00882() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasOneChild():boolean",
            new int[]{-564,294,-753,1000,387,503,-209,105,-337,-806,-592,-473,261,1000,501,-509,513,-236,-570,133,151,485,581,1000,729,210,605,898,-23,-521,430,-776,6,168,-87,-487,-1000,218,1000,-1000,-558,-988,-1000,83,-212,133,1000,-31,1000,38,334,114,-621,246,-91,801,228,-12,-818,-257,254,692,412,255}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00883() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasOneChild():boolean",
            new int[]{-1000,-77,562,-542,-413,673,-1000,-253,169,300,-857,554,1000,822,-1000,-923,828,-1000,767,589,583,-230,-434,110,417,-257,718,271,-1000,690,-696,195,80,452,491,805,-1000,497,980,-813,1000,-1000,-120,-1000,-261,-331,-926,-533,252,-308,612,-414,-691,-24,381,-434,737,47,-84,-173,21,-1000,2,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00884() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasOneChild():boolean",
            new int[]{-1000,294,-753,-542,153,1000,-241,-299,-1000,-978,-1000,-1000,961,1000,-241,-437,828,-701,-216,374,1000,1000,-242,185,-543,-539,1000,436,-964,-521,82,-473,-243,-340,-87,805,-1000,-320,-222,-517,596,-1000,-923,-1000,-1000,133,-926,-994,1000,503,-12,1,-621,-262,-91,3,1000,-1000,-818,-721,-1000,-1000,225,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00885() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasOneChild():boolean",
            new int[]{-1000,-457,-955,-359,-432,1000,-354,-17,-208,-778,-749,-1000,67,1000,-353,-6,662,105,-316,659,919,972,6,-121,-1000,-1000,1000,563,-472,50,146,-695,-430,-479,963,1000,-457,588,32,-92,218,-549,-196,1,-1000,918,-1000,-523,-50,1000,160,84,-507,310,-840,240,956,1000,175,-83,-1000,-686,28,559}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00886() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasOneChild():boolean",
            new int[]{198,353,-402,1000,-720,-620,-369,-994,1000,-1000,-472,679,665,-696,155,1000,1000,-381,-1000,-34,-482,1000,-1000,662,1000,416,893,1000,-483,-334,262,215,-76,-700,-681,-937,-778,-201,-916,138,416,-104,-917,-1000,-1000,76,-182,486,1000,-582,-743,-152,-915,-178,1000,-1000,-653,123,224,-285,-932,-270,-475,-290}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00887() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "hasOneChild():boolean",
            new int[]{720,54,-877,1000,-190,-533,-471,-1000,-669,-827,-435,1000,-1000,-746,1000,1000,1000,28,-404,-271,331,873,-720,1000,589,597,-538,1000,-60,-1000,112,-284,540,-798,-997,-1000,-491,-166,-1000,-153,-139,-69,-1000,-907,-56,-239,1000,315,716,480,-1000,-407,-232,-1000,-455,471,-624,1000,203,217,-661,731,90,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00888() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAdd():boolean",
            new int[]{-102,-86,-749,860,431,-552,-1000,-270,-159,-701,402,8,1000,191,33,316,370,918,-8,-494,-705,-600,-393,1000,-633,-481,-135,158,-1000,-40,711,516,1000,76,888,550,-194,-747,788,-218,-677,-402,267,471,1000,-360,-1000,-386,-184,338,-488,-586,1000,-81,-374,217,128,920,992,375,1000,-856,-836,-133}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00889() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAdd():boolean",
            new int[]{1000,514,670,921,761,1000,1000,291,24,754,-1000,-107,488,-656,-686,-1000,-1000,-312,-745,-875,1000,-597,1000,337,1000,1000,447,1000,-1000,659,-1000,346,183,1000,855,373,1000,1000,-1000,-1000,-213,-1000,-423,-506,1000,-1000,1000,-1000,1000,-124,-858,-645,911,-119,-1000,-947,-113,1000,-694,1000,-948,999,57,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00890() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAdd():boolean",
            new int[]{-834,-346,-752,1000,127,-1000,-1000,-168,-114,-1000,1000,57,759,57,180,1000,776,-614,283,34,-523,-1000,-404,518,-701,-1000,-286,-828,616,-266,-848,1000,484,459,-693,1000,-254,-1000,1000,619,-513,919,1000,-319,1000,-848,-974,-106,-142,931,866,984,385,456,62,540,227,557,-311,-372,928,-1000,-184,-291}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00891() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAdd():boolean",
            new int[]{-1000,533,-99,308,-248,-1000,325,-1000,-1000,-1000,1000,352,-1000,509,-801,1000,1000,225,1000,778,-681,-212,386,609,-1000,-400,-266,-1000,1000,-1000,-873,-258,-400,-936,-1000,20,-1000,-726,1000,834,98,1000,304,-187,-166,1000,1000,-295,-400,454,1000,23,363,1000,1000,1000,332,-124,-82,-694,-528,-548,147,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00892() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAdd():boolean",
            new int[]{-1000,919,-208,144,-32,380,-214,141,-250,340,1000,1000,2,644,-1000,-667,-437,-90,599,-686,-716,646,-1000,-661,39,182,82,-1000,164,564,1000,-1000,731,-559,59,216,-118,1,-147,-844,-894,-942,-16,1000,-15,-169,108,-477,1000,373,-890,-1000,-207,172,-991,-275,-69,376,-271,222,-1000,155,204,547}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00893() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAdd():boolean",
            new int[]{78,579,-392,-914,222,0,20,-669,265,-440,463,246,19,1000,454,93,94,147,-102,-796,1000,-1000,-594,5,69,-400,-906,-1000,-163,-1000,-133,186,22,443,-151,1000,10,818,590,132,558,400,-564,-20,481,-310,31,-106,-400,519,400,1000,470,490,356,33,-1000,1000,-758,-400,-1000,-977,1000,931}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00894() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAdd():boolean",
            new int[]{-1000,-261,-1000,-221,-270,-42,-1000,358,-638,-505,563,608,31,1000,-1000,35,-212,1000,-1000,-554,-914,55,-641,1000,-638,-683,-256,-122,-55,-225,767,313,479,91,-168,310,-785,-561,1000,-591,-1000,431,185,832,306,-364,-938,-550,1000,927,436,1000,921,585,130,-1000,-590,-59,-538,-436,-1000,13,-243,249}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00895() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAdd():boolean",
            new int[]{-697,519,-67,404,346,-430,-687,-1000,-318,-91,659,587,96,595,-1000,-591,-22,-103,-805,-660,-322,-309,-672,-238,-333,194,-80,-472,-55,725,584,714,434,-119,1000,405,-275,-18,1000,223,388,-364,-23,262,561,-1000,-502,-781,1000,813,-168,796,679,201,-277,-566,-959,607,-239,-646,287,-121,1000,669}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00896() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAdd():boolean",
            new int[]{-595,429,23,-77,561,-899,270,-1000,843,-422,-69,-1000,83,342,604,537,-1000,561,764,-471,666,-1000,82,277,65,-446,-469,-221,-237,-1000,-7,-78,274,417,389,851,-199,1000,285,390,1000,-1000,-1000,-113,174,393,581,-471,-621,-151,222,111,887,-331,862,255,-576,1000,108,-642,-99,-448,323,857}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00897() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAdd():boolean",
            new int[]{-1000,784,-135,-136,180,-1000,-308,64,-443,-580,1000,589,352,1000,-864,123,892,332,685,-911,-133,-1000,-1000,-120,-950,-949,-300,-1000,673,-207,39,557,655,496,-421,1000,-434,-705,878,573,-876,1000,274,-340,1000,-258,-1000,-1000,-482,1000,1000,893,-95,269,117,-208,-454,1000,-255,-530,146,-1000,-401,390}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00898() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAdd():boolean",
            new int[]{78,229,-563,741,354,-473,-999,376,1000,395,816,-46,590,61,-638,-111,-1000,786,620,-382,-492,652,1000,67,222,-480,315,400,-195,766,1000,268,826,-750,819,691,416,-405,-1000,-39,-1000,-247,797,29,-756,421,-598,-1000,859,-237,-1000,-1000,-760,-1000,-774,181,500,226,524,-321,-414,45,-4,740}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00899() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAdd():boolean",
            new int[]{1000,-691,-531,1000,649,1000,-1000,-294,1000,-77,346,-145,1000,662,-344,-1000,-599,1000,27,-1000,1000,-628,-725,812,424,1000,431,-1000,-1000,1000,1000,-116,1000,1000,776,898,481,330,288,-146,-1000,-1000,559,-1000,1000,-1000,-1000,-737,280,531,-1000,-958,1000,-1000,-705,-1000,-130,1000,1000,1000,960,-511,-885,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00900() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAdd():boolean",
            new int[]{39,519,-67,196,213,-285,31,140,719,-71,155,-832,850,60,-159,440,314,312,516,-536,-80,-571,97,410,225,194,34,113,-1000,371,303,113,615,-185,1000,405,511,1000,-33,5,388,-364,-26,-596,561,498,90,-1000,685,-50,-407,-550,646,-412,-277,85,-249,1000,564,310,287,-244,-885,148}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00901() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAdd():boolean",
            new int[]{-1000,744,98,-902,12,-258,977,-690,-483,-314,376,-280,-1000,622,-473,256,312,-753,-651,-535,634,-587,-24,-139,101,-548,-490,-712,1000,-1000,-211,502,-1000,-251,-553,421,-178,638,270,121,733,1000,-300,159,-314,970,743,-1000,-1000,895,1000,1000,-27,407,1000,-198,-692,384,-1000,-1000,-895,-66,1000,-120}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00902() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAdd():boolean",
            new int[]{-1000,-131,664,-1000,-754,-1000,1000,-1000,-1000,-629,1000,-213,31,548,-1000,773,1000,-1000,1000,478,1000,206,303,-459,-941,-1000,-964,-323,1000,-1000,226,-628,-1000,-221,-1000,144,-1000,-885,1000,1000,1000,1000,183,273,-331,-343,-797,-112,-1000,1000,1000,1000,-794,941,1000,314,-401,736,-1000,-1000,-370,-1000,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00903() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAdd():boolean",
            new int[]{33,-261,-27,439,722,31,-44,-1000,657,317,444,348,171,184,-930,-993,-127,-409,1000,-784,916,-615,-703,-567,285,-928,6,-738,235,369,707,483,348,-48,-300,862,416,538,-62,1000,889,-92,-149,-493,-312,165,1,-1000,496,471,-604,-193,50,-214,-329,-674,-35,192,-152,-459,-414,475,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00904() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAnd():boolean",
            new int[]{545,-101,-502,-1000,436,-393,-428,217,-1000,-1000,109,374,751,-64,99,1000,926,-445,-625,-572,363,-952,840,-1000,-879,1000,912,-110,-712,1000,-557,-282,-783,-599,-179,553,-638,665,951,-571,573,-57,-785,523,126,537,-20,-544,-1000,-809,160,-104,478,-434,1000,602,-1000,153,-1000,-567,542,-1000,1000,-965}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00905() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAnd():boolean",
            new int[]{-871,-217,250,606,-389,-513,-712,-526,412,734,-35,-328,-477,650,-712,-110,-134,-142,968,-785,285,-625,712,-905,184,-510,620,814,-140,399,-609,-146,835,-925,-581,522,-625,672,-327,310,-251,-377,745,-396,-218,-502,-576,540,-218,-301,724,-893,-992,-905,-568,889,-483,-170,910,-732,-567,699,163,-664}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00906() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAnd():boolean",
            new int[]{-763,-1,-663,395,-74,1000,-50,-648,-1000,197,-354,-93,-477,-1000,100,192,-699,43,-1000,-113,-8,105,-737,1000,-1000,-529,159,507,-358,-1000,-1000,-785,161,350,273,-981,-1000,-106,498,-512,-167,-676,-814,-60,294,-403,-1000,-496,595,674,1000,-195,116,-231,609,-1000,-1000,-84,-147,-1000,33,-877,-803,594}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00907() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAnd():boolean",
            new int[]{-555,309,-500,146,-36,201,-1000,-324,612,-1000,172,366,1000,8,-302,572,300,-462,-925,-788,-498,-458,-624,20,-690,384,-581,-738,-1000,1000,-783,-169,-588,836,614,-199,-634,771,-486,196,637,-640,-710,-807,865,-617,-20,-1000,-134,563,514,-20,1000,-133,1000,-604,-914,303,-874,-1000,607,-1000,-191,-95}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00908() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAnd():boolean",
            new int[]{-1000,138,213,518,-1000,1000,1000,642,-571,1000,-851,-478,-1000,520,-660,-250,-1000,1000,-824,1000,1000,1000,263,1000,-558,-1000,-926,117,1000,-1000,-1000,-362,1000,-54,-452,-1000,-1000,-623,516,870,-424,344,714,1000,361,-1000,-1000,1000,370,1000,-106,-1000,-620,-202,-400,-111,309,59,813,-909,-706,1000,-1000,833}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00909() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAnd():boolean",
            new int[]{-364,374,-183,117,935,-336,-129,-1000,41,-16,-156,-680,753,155,-838,190,1000,-656,272,-1000,-620,-1000,285,-974,-1000,801,-165,-192,-214,1000,-690,-49,-509,-395,-873,647,-504,675,-113,118,-150,-50,-377,-1000,69,-1000,564,-42,-1000,-1000,623,-153,-94,-615,-176,362,-725,687,-297,-1000,-415,53,205,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00910() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAnd():boolean",
            new int[]{-763,-726,-1000,395,818,-513,482,30,-1000,1000,346,-1000,-408,-1000,-600,166,-846,-193,11,-505,-219,-428,1000,1000,184,-193,709,1000,-143,-332,-1000,-85,-309,-554,-685,-1000,-625,-588,868,-345,30,-410,169,1000,534,-275,-1000,365,1000,720,495,479,620,-88,1000,889,-300,-361,910,-248,-313,-351,-793,342}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00911() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAnd():boolean",
            new int[]{221,709,-111,-1000,-1000,1000,440,-909,231,611,-83,74,-1000,-19,1000,-325,-1000,823,478,1000,375,-3,525,921,-275,-485,1000,940,-165,-1000,-791,-1000,1000,-814,776,-853,-1000,-258,-226,-968,516,-414,-885,1000,-615,532,-635,-470,862,690,1000,-780,-92,-484,368,-160,-1000,-1000,925,-976,1000,-337,-694,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00912() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAnd():boolean",
            new int[]{-1000,-656,-183,1000,-1000,1000,-118,-1000,669,816,177,1000,-1000,-1000,1000,-811,-1000,1000,726,1000,289,364,-940,1000,127,-628,227,-174,-702,-1000,-1000,-1000,1000,142,1000,-1000,-611,-151,-705,-418,172,-1000,-712,-929,-728,-1000,-972,-1000,1000,1000,1000,-797,-1000,-401,-567,-1000,-724,-1000,1000,-1000,937,354,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00913() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAnd():boolean",
            new int[]{-1000,-756,-1000,1000,-19,-69,-570,-108,-1000,-442,-376,799,-1000,654,-220,1000,-875,43,-1000,1000,455,1000,-1000,1000,-896,-940,-1000,-1000,-681,-983,-1000,-611,214,1000,319,-860,-985,-106,-466,1000,1000,-981,922,448,1000,-42,-1000,-556,1000,674,-829,794,116,883,1000,-1000,162,988,-1000,208,318,-1000,59,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00914() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAnd():boolean",
            new int[]{-1000,168,-562,1000,296,-542,-268,199,-252,-20,-43,570,63,1000,-716,298,167,-363,-286,-857,-688,-118,-801,6,-876,-656,-193,-636,-532,651,-907,-366,-84,1000,-228,239,-679,506,-604,1000,298,-50,-18,400,610,-1000,84,-434,-634,-318,271,24,-435,-130,177,-805,-552,682,-450,-1000,-34,-227,322,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00915() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAnd():boolean",
            new int[]{-1000,-392,213,1000,428,1000,247,128,-970,912,-1000,688,-1000,1000,-782,894,-748,367,-988,238,1000,1000,-1000,1000,-1000,-1000,-1000,507,519,-1000,-1000,-435,1000,726,-774,-1000,-1000,-197,101,1000,-258,-95,798,-481,210,-1000,-1000,658,277,891,1000,-1000,-1000,141,-98,-29,364,906,-301,-1000,-901,-877,-739,396}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00916() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAnd():boolean",
            new int[]{-1000,549,919,35,-74,1000,118,-540,601,1000,-154,-529,-1000,-296,-173,-1000,-1000,1000,1000,70,1000,-737,1000,380,461,-1000,644,1000,638,-1000,-1000,-593,1000,-1000,-45,-507,-924,-106,424,-213,-760,-428,-885,13,-806,-701,-1000,1000,-222,-328,1000,-1000,-1000,-1000,-1000,1000,-638,-84,1000,-1000,-389,1000,-1000,-466}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00917() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAnd():boolean",
            new int[]{-677,-851,-1000,1000,606,-892,-755,-298,-1000,-343,65,-1000,921,-356,-549,786,325,-699,-1000,-861,-1000,-1000,-734,-974,-1000,1000,1000,839,-207,1000,-977,-214,139,-721,-189,154,-1000,797,321,-814,-38,-588,-1000,232,322,-182,580,-500,271,-964,191,496,934,-890,726,-223,-1000,253,-519,-120,520,-704,373,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00918() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAnd():boolean",
            new int[]{-866,-466,250,690,493,-1000,-1000,-474,-1000,-1000,241,-328,222,675,-220,1000,400,-1000,-1000,253,-937,942,-1000,99,-896,460,-1000,814,-1000,168,-609,-724,-355,1000,680,540,-648,672,-854,1000,1000,-797,209,-759,1000,341,-385,-1000,666,872,-293,893,-468,706,1000,-1000,-441,988,-1000,-550,814,-1000,1000,603}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00919() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAnd():boolean",
            new int[]{328,-217,250,-128,-973,-513,247,-1000,-1000,848,-383,1000,-199,-1000,-53,-953,-991,-142,-764,-432,-839,-810,558,362,386,-1000,-3,1000,-1000,-1000,-87,-1000,-847,465,738,-58,727,188,376,-787,-1000,25,-756,-396,-731,464,-1000,-1000,-307,636,1000,-388,-66,76,-568,-199,-1000,-711,910,-1000,14,-697,-188,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00920() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isArrayLit():boolean",
            new int[]{1000,83,952,-377,400,-584,1000,-684,0,16,907,1000,1000,510,159,494,614,891,-217,-242,58,-1000,-248,-24,1000,123,965,-301,257,-100,-289,-52,1000,-677,361,-443,-1000,149,594,-135,-955,288,-784,242,-722,984,-398,-104,1000,437,-874,403,-530,284,1000,-1000,777,1000,496,-954,-145,-381,-751,-288}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00921() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isArrayLit():boolean",
            new int[]{-209,-631,950,-993,-492,-1000,-287,656,-515,787,539,-27,621,-855,-1000,982,885,-1000,145,-25,-1000,-1000,45,82,937,475,-288,-157,-433,786,972,-1000,33,1000,-939,1000,868,1000,-285,277,-1000,-1000,882,782,89,-1000,-1000,381,332,195,1000,-382,1000,-106,-864,-439,-1000,-910,-255,693,873,-373,-1000,144}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00922() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isArrayLit():boolean",
            new int[]{720,239,392,422,-899,-521,-567,-694,-990,890,756,394,665,863,935,7,302,-24,-738,690,446,229,-448,-419,1,604,-841,-188,786,164,16,-217,171,-167,52,-280,-124,-210,-946,390,630,946,-838,-962,-585,387,568,670,325,-151,-269,645,-336,-696,396,-766,875,556,-899,240,-908,391,459,103}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00923() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isArrayLit():boolean",
            new int[]{782,-546,563,-199,554,680,-421,17,-591,444,-1000,693,319,-9,625,-689,53,-17,52,757,-413,374,931,82,-980,-1000,-582,-325,689,350,-1000,974,-10,-629,1000,-1000,-400,1000,-94,657,1000,893,-1000,-367,-811,-187,488,-773,67,-146,-495,-97,-761,-924,336,747,816,554,-782,102,-478,970,-1000,721}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00924() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isArrayLit():boolean",
            new int[]{277,843,478,-4,-222,-847,-138,168,-698,1000,1000,629,-73,1000,-639,367,1000,153,-875,-647,-315,-496,-198,-1000,195,-689,-344,-995,531,-1000,-578,-33,1000,31,674,1000,-644,-40,186,470,-1000,1000,-781,-1000,-492,1000,1000,393,558,-153,-458,1000,-512,-1000,530,-909,971,566,-1000,814,-1000,525,-584,-242}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00925() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isArrayLit():boolean",
            new int[]{-119,14,-555,-200,-918,-1000,-156,521,-78,-1000,1000,51,-1000,283,-1000,1000,430,-77,-935,127,-280,-544,-414,-685,1000,473,259,-547,1000,969,1000,-465,-1000,365,-1000,1000,751,-1000,346,436,-1000,-1000,448,917,-185,-608,958,828,-488,1000,176,36,1000,313,-326,228,-1000,-1000,533,-84,-567,-242,-1000,-47}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00926() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isArrayLit():boolean",
            new int[]{-685,-251,993,-1000,-903,-468,224,521,-595,-1000,694,-327,376,-180,863,1000,-285,480,1000,964,1000,-1000,540,608,1000,-548,-482,-289,1000,1000,-92,658,-1000,-1000,20,1000,1000,-1000,636,633,-816,-1000,-1000,1000,-903,-422,-510,1000,-173,-232,-350,812,13,1000,1000,-145,-1000,-1000,-417,92,1000,667,-438,-540}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00927() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isArrayLit():boolean",
            new int[]{131,-631,-1000,602,-553,-1000,-881,502,-1000,-402,1000,-370,1000,-308,-499,658,193,-1000,778,-25,-1000,-125,-142,82,-1000,434,-624,-1000,-1000,836,-1000,800,258,1000,837,321,-663,358,171,1000,-737,1000,-374,-1000,-1000,-1000,-570,-1000,1000,-158,-383,-1000,267,1000,261,1000,-1000,-598,-728,1000,1000,1000,352,144}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00928() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isArrayLit():boolean",
            new int[]{-102,669,-1000,-192,-1000,408,-1000,663,-1000,254,316,-300,1000,-342,620,-1000,-418,-185,-1000,1000,763,1000,1000,374,-733,-279,-1000,110,1000,1000,400,379,-425,-629,153,765,1000,-862,572,1000,664,-101,-71,-367,-463,-313,-292,620,-242,-1000,180,224,115,327,336,213,-1000,-1000,-1000,867,598,1000,104,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00929() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isArrayLit():boolean",
            new int[]{1000,469,1000,-681,-148,320,5,-1000,-123,286,-869,969,-735,1000,1000,57,846,1000,-354,653,1000,636,798,-264,223,30,-226,808,1000,72,109,216,-993,-1000,738,-900,-1000,392,3,652,988,-667,-975,302,-110,1000,114,757,-849,913,-535,1000,-489,-787,1000,-398,1000,1000,-626,-1000,-1000,957,-120,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00930() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isArrayLit():boolean",
            new int[]{303,184,1000,-841,-106,-180,862,-124,550,307,1000,694,-1000,138,150,447,98,1000,485,-356,1000,975,-64,43,176,-20,409,145,1000,387,583,-129,-1000,-1000,-102,839,-308,-95,437,223,-1000,-1000,302,1000,74,225,-636,1000,-651,570,235,678,-643,903,500,-696,364,360,-447,-696,926,288,-295,531}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00931() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isArrayLit():boolean",
            new int[]{-347,-86,-861,862,400,613,179,-228,-128,715,-1000,981,-201,-605,309,-1000,-947,638,-1000,31,133,-1000,-944,887,-703,543,130,843,-1000,640,151,-57,-267,757,607,24,-1000,1000,-1000,-795,-441,236,94,-1000,-1000,-1000,898,-1000,-609,251,-1000,287,-155,-1000,-1000,37,592,426,1000,9,818,150,453,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00932() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isArrayLit():boolean",
            new int[]{733,-858,738,253,-181,-5,-1000,-90,-993,828,-85,381,765,-417,824,-130,554,74,403,1000,533,923,719,756,-32,-422,-1000,227,1000,817,-289,512,-416,-778,833,-218,213,-1,-480,575,1000,622,-529,35,-692,173,-291,332,497,-1000,547,152,-326,539,704,-635,429,311,-1000,481,-516,525,197,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00933() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isArrayLit():boolean",
            new int[]{-119,933,-362,-200,80,-264,447,565,-78,557,830,805,-54,409,-868,-301,-424,-894,-935,-995,-368,-988,-391,-685,-510,-377,-551,-356,-948,274,-636,240,770,170,-552,-879,-683,731,-181,238,194,792,-454,-581,-446,599,958,-735,-186,-274,-838,36,-725,-938,-326,228,870,-173,370,24,-567,-789,-378,-917}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00934() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isArrayLit():boolean",
            new int[]{1000,-36,950,107,1000,-519,-486,79,-411,1000,1000,1000,-201,1000,-1000,-202,958,651,-566,-698,-821,-922,-418,-928,265,-696,99,-539,189,-691,-1000,800,-414,-126,719,-1000,-1000,1000,-548,-54,-304,1000,-166,-1000,-1000,1000,984,-718,623,251,-417,812,-674,-1000,464,-467,1000,980,-1000,234,1000,-780,-623,-692}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00935() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isArrayLit():boolean",
            new int[]{1000,653,752,1000,-1000,-492,-1000,-1000,-708,1000,1000,442,1000,1000,1000,-183,558,1000,-1000,1000,1000,1000,-849,123,194,390,-1000,274,1000,-44,813,-551,84,-1000,380,818,-85,-190,-1000,1000,399,660,-709,-732,-282,1000,1000,1000,-353,-306,358,980,-235,-318,981,-1000,127,1000,-1000,-136,-1000,996,-464,870}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00936() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAssign():boolean",
            new int[]{224,119,-1000,84,174,-460,1000,436,812,-323,1000,601,399,977,-562,147,1000,326,634,-443,795,62,1000,846,-238,-921,1000,-28,961,-44,237,-449,1,-1000,371,345,-1000,-69,-739,729,-297,550,-1000,-1000,-113,-643,-1000,796,-270,-1000,-219,1000,-297,-214,348,521,-299,-150,1000,-106,1000,651,152,-24}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00937() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAssign():boolean",
            new int[]{1000,-381,-649,363,221,215,-360,748,291,-883,1000,720,419,-896,-305,1000,641,178,-345,686,-435,-436,604,-905,-1000,165,1000,-1000,-920,113,-1000,-400,309,203,-113,-1000,-266,635,-323,35,-436,-780,113,-223,-856,547,1000,365,885,619,578,-1000,-447,-133,687,80,-333,1000,135,-1000,-605,217,-412,-230}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00938() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAssign():boolean",
            new int[]{183,-666,-554,-853,-1000,336,94,508,1000,-359,366,512,762,146,539,-140,350,66,-178,671,-584,110,602,363,-1000,-269,515,199,439,972,-19,-179,1000,-957,-733,245,985,-69,-994,908,-438,-399,-38,-761,-35,202,12,485,112,883,149,81,725,-558,-756,430,-241,-118,569,-464,140,-278,-752,419}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00939() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAssign():boolean",
            new int[]{1000,-771,-573,-681,-1000,-393,-88,-1000,-173,833,-552,-1000,-21,149,615,465,-974,452,410,-48,-524,-275,-1000,583,468,-382,-342,1000,882,-121,-333,1000,-27,1000,-564,1000,-688,-217,1000,250,230,35,349,470,1000,-229,-559,633,-952,43,-841,162,-1000,-536,-759,374,-763,-374,-1000,108,-114,-1000,-598,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00940() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAssign():boolean",
            new int[]{1000,-461,-180,983,-115,1000,-237,400,1000,-85,-563,1000,-317,-1000,864,-718,877,-1000,-780,1000,-1000,568,1000,-1000,-700,1000,1000,-938,1000,1000,430,28,364,60,-378,-953,1000,1000,-684,-79,-1000,-1000,1000,-1000,-1000,888,298,951,273,1000,536,-682,-443,-159,-1000,-142,-1000,1000,-624,-1000,-1000,1000,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00941() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAssign():boolean",
            new int[]{183,-221,-266,-579,-1000,452,-1000,144,536,-992,-459,276,102,146,535,-358,209,1000,-1000,671,-871,-499,831,363,-917,-269,515,199,7,37,787,963,1000,-942,-1000,391,1000,-69,-1000,1000,-1000,-444,1000,-618,-35,1000,741,656,601,572,575,-478,580,-151,-726,100,-952,-118,88,-865,-301,-69,-1000,-141}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00942() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAssign():boolean",
            new int[]{-193,299,-1000,1000,1000,147,-1000,-1000,1000,-960,-1000,-1000,-1000,184,-1000,-789,628,566,-394,-1000,520,-1000,464,-543,1000,-726,-1000,199,-286,-579,1000,1000,-132,25,-284,195,-1000,-409,-389,526,-215,579,143,613,283,155,-308,803,733,-1000,654,-58,-1000,-747,-99,456,-1000,378,-390,430,-152,593,269,-502}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00943() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAssign():boolean",
            new int[]{183,299,-945,418,600,-159,-162,-658,887,-359,-296,-1000,-453,146,-1000,136,628,326,-388,-1000,-191,-1000,257,236,212,-985,304,442,961,487,966,516,-61,524,-237,36,-1000,-69,-339,905,-987,127,-101,613,-35,116,12,982,112,-1000,348,-58,-297,-747,-713,1000,-629,711,752,-106,36,341,-452,520}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00944() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAssign():boolean",
            new int[]{377,-706,-290,-243,-471,564,-838,-95,-491,-518,212,-908,238,-746,207,1000,-609,-1000,-970,-550,-1000,-878,187,-346,-887,532,57,477,254,1000,-1000,332,1000,1000,-1000,-462,-75,-631,-197,838,20,-153,635,806,-242,873,988,-373,620,668,637,-678,285,-136,-1000,820,344,142,-573,-424,-772,-601,-569,280}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00945() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAssign():boolean",
            new int[]{-1000,-557,-77,-341,-1000,86,-635,-49,-782,-168,-677,-1000,113,1000,-494,-371,-240,-9,551,-1000,529,-585,-509,380,-419,-1000,-1000,31,-924,-723,325,339,-130,-469,-365,1000,-1000,-1000,621,275,-135,-690,-367,1000,1000,-296,1000,343,50,-1000,-169,-736,324,-905,-175,-116,101,-1000,512,-181,817,-1000,631,929}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00946() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAssign():boolean",
            new int[]{942,-21,-1000,1000,309,1000,-1000,-1000,1000,-99,-730,-915,-65,-1000,634,-1000,388,1000,-460,621,-620,-267,48,-1000,-881,1000,390,-9,318,1000,869,745,-156,1000,-722,-966,76,309,-1000,177,-1000,-892,907,-893,-976,1000,932,390,743,389,953,-1000,-1000,-271,-1000,-768,-1000,1000,-1000,-182,-1000,1000,-1000,-605}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00947() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAssign():boolean",
            new int[]{-221,-656,-729,13,-905,876,531,603,1000,-1000,-617,1000,-676,-236,495,-1000,687,1000,1000,433,-865,-645,1000,-200,-281,1000,918,-1000,1000,-133,920,1000,1000,201,1000,211,1000,1000,953,-540,-931,-1000,36,-937,-1000,-158,-324,1000,-727,1000,-636,-583,-219,-1000,-316,-1000,332,989,943,-1000,-1000,1000,-446,91}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00948() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAssign():boolean",
            new int[]{1000,734,-644,1000,800,1000,-1000,-431,1000,-657,29,-829,-159,-894,-268,-1000,200,726,-1000,-1000,-16,-914,1000,-1000,305,1000,-295,522,189,1000,433,925,859,392,-968,-608,-598,-1000,-1000,1000,-430,780,631,-69,-819,832,761,391,1000,-1000,998,-17,-1000,674,66,379,-1000,470,-1000,173,-1000,1000,-1000,-794}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00949() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAssign():boolean",
            new int[]{-674,-456,-873,2,410,-15,1000,377,-376,1000,390,321,266,1000,-206,100,112,481,1000,-14,-741,808,539,1000,-462,-189,1000,-578,1000,37,-166,-921,491,172,1000,849,938,1000,628,394,464,-1000,-676,-548,-384,-880,-1000,820,-513,955,-990,273,89,-993,-667,-881,-141,340,1000,-1000,9,1000,-11,-207}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00950() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAssign():boolean",
            new int[]{1000,373,475,727,986,-254,-643,748,795,-306,-54,-49,42,-95,-555,145,187,729,-1000,-259,-1000,-731,522,-363,456,400,175,-366,945,-305,393,625,-368,-196,142,-248,-1000,-1000,278,-289,286,362,884,1000,-298,196,12,952,199,-704,210,-81,-741,10,675,91,-1000,934,-170,-637,-611,1000,-343,-816}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00951() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAssign():boolean",
            new int[]{796,-313,58,1000,171,1000,-1000,174,1000,592,-744,514,151,-1000,622,-1000,895,1000,-798,1000,-1000,-26,365,-1000,-482,1000,1000,-1000,307,620,1000,967,-40,200,-269,-1000,655,1000,-506,-909,-1000,-1000,1000,-668,-1000,55,1000,1000,801,1000,860,-711,-1000,-205,-1000,-1000,-1000,1000,-882,-1000,-1000,-108,-1000,-912}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00952() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAssignAdd():boolean",
            new int[]{601,503,719,-433,653,1000,471,-1000,-1000,466,614,894,948,-544,-1000,1000,-495,902,-767,1000,-1000,99,-692,-1000,-1000,433,-1000,-407,-12,554,-424,-1000,-370,407,-734,1000,1000,1000,498,-1000,-440,133,163,1000,-341,-1000,362,617,286,433,715,-651,-516,1000,-1000,-404,747,-107,815,-1000,1000,-261,-1000,729}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00953() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAssignAdd():boolean",
            new int[]{-110,-686,643,-132,318,390,567,-299,1000,-599,314,167,461,-12,-119,-850,228,-1000,-948,-855,-18,-823,-105,-598,308,-1000,-129,109,-1000,-365,1000,832,336,52,-72,1000,1000,-807,1000,966,-1000,295,193,630,-545,652,134,-856,1000,-1000,-28,296,-1000,-830,-48,468,-423,287,523,2,-942,1000,183,-229}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00954() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAssignAdd():boolean",
            new int[]{-1000,-721,986,-1000,-966,964,1000,-1000,-1000,971,909,143,168,-342,-134,1000,-710,-351,-1000,78,-1000,1000,-633,-1000,21,-55,1000,258,-1000,-1000,1000,951,67,1000,-1000,1000,1000,630,-829,897,-279,-1000,-713,-255,-643,-495,1000,280,112,359,564,-1000,-1000,-937,-1000,-401,-330,570,-708,-1000,1000,844,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00955() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAssignAdd():boolean",
            new int[]{1000,394,598,246,-969,1000,-328,-490,-1000,-169,-538,692,657,-53,72,577,-124,1000,479,731,848,-748,-827,-813,-792,714,523,213,409,762,-1000,-214,565,-112,1000,-264,1000,1000,640,-1000,-195,-94,1000,536,18,-797,-814,567,85,745,-357,187,1000,493,-867,-226,1000,319,547,-1000,-131,-772,-1000,-639}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00956() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAssignAdd():boolean",
            new int[]{520,-511,1000,204,124,781,268,-633,-386,6,520,385,1000,-600,27,882,602,-32,-95,318,120,440,355,-797,-1000,1000,971,189,-47,295,573,-388,336,-247,314,174,165,977,302,-591,-261,-258,-609,205,-305,118,-162,58,-155,-430,102,1000,-110,508,-395,230,1000,761,3,-641,624,-872,-657,-173}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00957() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAssignAdd():boolean",
            new int[]{186,144,722,-513,-888,32,188,-133,-103,55,313,-487,-705,-1000,897,278,614,-349,-503,-280,-1000,386,480,-407,247,-486,-198,-1000,-982,-190,1000,441,-180,958,-1000,788,543,546,154,661,-361,-190,-184,-358,-608,-267,105,301,1000,-1000,1000,-1000,-664,100,-134,880,-635,503,-1000,-648,540,1000,725,-66}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00958() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAssignAdd():boolean",
            new int[]{460,54,668,-361,-275,325,-32,-595,-357,-411,1000,-29,22,300,1000,432,-175,185,-1000,-1000,-400,635,1000,-983,126,290,125,-400,-469,-737,-900,86,-727,400,-400,400,1000,1000,407,-349,-838,237,-857,1000,-129,-547,844,7,-288,-180,400,-400,-665,480,659,-517,1000,-780,110,1000,-991,91,1000,500}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00959() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAssignAdd():boolean",
            new int[]{-1000,559,741,-126,-407,-226,-647,489,4,938,-490,-1000,-174,-1000,-504,-474,600,748,-70,-1000,-226,-1000,-574,-204,-158,-19,-712,-770,-639,699,1000,776,-1000,1000,-562,97,278,231,534,99,-352,918,-55,-887,-1000,566,-878,1000,1000,375,987,-751,-175,995,-503,851,-810,888,-1000,886,540,682,943,-744}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00960() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAssignAdd():boolean",
            new int[]{-251,-986,286,248,-62,-411,760,220,-324,13,-72,235,1000,992,1000,-1000,-1000,-116,-294,-579,458,-781,-349,340,370,597,567,262,-1000,-56,175,444,-799,-235,640,-700,1000,1000,794,-1000,-1000,1000,461,716,264,-81,497,-430,-645,-71,-525,378,143,-12,-286,-784,990,216,877,-343,1000,-419,648,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00961() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAssignAdd():boolean",
            new int[]{763,538,937,114,340,-669,-28,733,948,90,-305,668,-738,-802,-48,-689,746,-451,-168,309,652,214,782,802,-587,-367,972,-2,114,-367,233,-312,-869,105,23,-132,-820,649,-499,-427,-25,-304,-637,436,-106,-48,474,774,203,808,74,22,-791,-731,616,149,-752,214,-497,219,374,-27,502,736}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00962() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAssignAdd():boolean",
            new int[]{470,983,33,834,361,760,623,567,741,-821,-32,-182,-10,-992,-223,984,-822,-913,221,332,-725,-385,-853,295,889,611,-332,-949,-561,244,407,-961,-136,-800,-5,-123,944,-31,562,-671,80,12,-84,420,-987,-878,847,-445,-655,-11,581,-373,-6,955,-224,-547,710,-731,678,618,672,-231,33,836}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00963() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAssignAdd():boolean",
            new int[]{23,-511,1000,-140,-66,16,797,-1000,-278,-757,-32,1000,1000,502,284,-772,-157,-857,-1000,165,239,200,-154,-1000,-840,1000,971,1000,-994,508,-60,373,40,-836,483,-655,1000,860,1000,-671,-1000,1000,651,430,878,-11,-65,-1000,-1000,-234,-570,1000,66,231,-569,-462,1000,-418,1000,-1000,383,-708,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00964() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAssignAdd():boolean",
            new int[]{259,584,620,-754,-1000,1000,229,-1000,-1000,190,666,-1000,-956,369,257,1000,-149,351,-893,-1000,-1000,344,-367,-912,295,792,1000,-1000,-37,-1000,1000,627,140,1000,-1000,1000,792,1000,92,-845,-763,-377,-1000,1000,-433,-477,1000,338,-225,433,1000,-1000,-1000,831,-884,-1000,1000,-1000,-541,1000,-559,357,-42,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00965() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAssignAdd():boolean",
            new int[]{-436,649,801,-509,-289,893,546,-842,-938,217,875,-93,642,267,1000,667,-818,692,-1000,-458,-1000,188,886,-1000,-631,377,393,-1000,-581,-1000,1000,-303,-418,1000,-1000,1000,1000,1000,152,12,-768,-90,-1000,1000,-848,-940,1000,386,17,376,1000,-1000,-1000,620,-11,-1000,659,-1000,-215,775,-26,440,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00966() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAssignAdd():boolean",
            new int[]{-1000,234,411,-681,-337,171,579,55,-386,108,297,-1000,-75,784,582,561,-310,-840,-585,-981,-1000,880,468,-809,-343,-880,660,101,-1000,-1000,1000,737,-640,834,-1000,1000,69,-759,-1000,1000,-103,-1000,-657,-784,-490,476,1000,172,1000,-3,1000,-714,-1000,-888,-711,531,-1000,1000,-1000,609,35,1000,1000,931}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00967() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isAssignAdd():boolean",
            new int[]{-573,-166,124,-814,-448,1000,1000,-644,-1000,274,1000,-406,-35,300,925,657,-516,-530,-1000,1000,-1000,1000,76,-1000,-151,454,1000,-170,-625,-1000,1000,594,697,1000,-1000,1000,1000,195,-41,452,-450,-1000,-10,947,-510,-1000,1000,67,-306,-422,252,-4,-1000,-930,-1000,318,-741,449,-1000,-1000,1000,1000,172,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00968() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isBlock():boolean",
            new int[]{1000,358,-1000,-372,-341,408,-306,401,-218,-5,-327,314,-671,-908,-68,648,723,193,159,400,-103,-809,56,400,1000,-717,-597,64,-12,-212,716,753,182,-242,-103,621,-14,-1000,-343,-528,245,565,1000,-296,400,-10,-1000,778,-190,379,1000,-455,-365,-831,758,-36,-457,-879,-557,-515,752,-39,-400,-876}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00969() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isBlock():boolean",
            new int[]{-1000,-252,75,-28,176,-97,-706,828,-789,-739,863,-37,1000,-861,-312,-304,-634,-1000,724,1000,-1000,-462,-192,188,-570,-1000,354,-507,765,1000,-329,1000,-1000,593,-58,-695,1000,838,-544,806,-20,221,-760,-26,-897,1000,1000,-1000,319,-443,1000,555,258,1000,-123,-1000,-680,-53,954,81,-1000,-1000,-499,-479}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00970() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isBlock():boolean",
            new int[]{627,219,-220,758,282,691,-935,-526,693,-336,128,-334,-1000,-1000,-713,-224,-322,205,110,105,-689,237,443,531,1000,-865,-698,-605,-767,335,1000,1000,-946,-171,-329,212,63,444,-678,-1000,940,132,447,-1000,121,-139,-720,7,353,-1000,1000,-1000,-652,-380,1000,-469,-321,-863,-746,-469,456,-925,-583,124}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00971() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isBlock():boolean",
            new int[]{1000,-66,-1000,185,1000,73,932,-519,314,-1000,183,-867,1000,704,525,1000,-984,-788,421,-496,1000,-1000,-623,-36,1000,139,-1000,-1000,-526,-201,519,1000,1000,-798,715,1000,1000,-787,-126,1000,-410,-109,829,-171,-526,235,-394,1000,-700,219,-1000,569,83,1000,-609,1000,1000,-1000,343,-477,1000,1000,1000,-379}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00972() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isBlock():boolean",
            new int[]{-1000,679,-589,1000,54,-190,805,664,-1000,835,46,-496,-951,-277,48,500,168,1000,446,734,501,-1000,986,895,561,7,288,-1000,1000,-641,1000,366,-588,83,-1000,-545,478,425,-864,598,1000,-270,-1000,71,1000,-243,306,-377,193,-172,99,-378,-1000,963,762,-647,-92,-888,1000,652,-708,-1000,-734,-605}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00973() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isBlock():boolean",
            new int[]{-1000,-191,702,-1000,662,1000,451,497,-837,-520,505,1000,-1000,-1000,226,826,-613,-591,1000,575,447,-839,-251,-954,789,212,-708,-340,-36,-996,389,1000,-223,-517,-1000,-336,921,-197,951,755,952,-1000,-1000,370,-906,1000,520,88,-1000,-840,-151,1000,-235,-437,-957,-336,-729,-1000,-448,-515,79,-96,901,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00974() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isBlock():boolean",
            new int[]{557,-41,-567,-955,981,-397,549,-584,-144,-749,179,133,1000,768,523,602,-436,-764,222,-687,1000,-657,-286,-748,508,450,-279,-483,-80,427,-352,553,757,-407,355,238,572,-205,-224,-324,-603,-80,244,11,-642,191,31,350,-37,275,-960,209,207,731,-432,1000,754,-315,-132,-46,877,472,631,-176}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00975() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isBlock():boolean",
            new int[]{-1000,604,-1000,38,257,-190,189,968,-1000,422,46,820,-1000,-914,318,652,648,705,999,1000,501,-494,509,1000,1000,-26,-424,-801,1000,-1000,1000,648,-1000,83,-917,155,887,-201,-864,13,1000,233,-1000,-433,1000,276,-1000,338,-139,54,1000,-749,-1000,-253,539,-481,-92,-826,-57,-307,-708,-299,-1000,-582}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00976() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isBlock():boolean",
            new int[]{-892,454,-137,624,-307,-183,-327,187,-1000,-631,62,810,1000,-427,254,-227,805,755,1000,400,-717,201,568,853,232,-218,674,-29,1000,-127,48,325,-628,460,-953,367,54,141,-498,58,807,-324,-776,-515,798,-84,78,-285,664,-525,1000,-872,-809,115,-249,-1000,-714,58,574,-1000,-1000,-413,-1000,-443}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00977() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isBlock():boolean",
            new int[]{1000,259,-924,305,-228,1000,283,-445,1000,-634,210,-223,-1000,-991,-660,853,11,525,-1000,884,-180,-315,-414,-73,-21,-490,-936,824,-1000,-507,824,1000,754,161,901,1000,-192,-291,-719,-1000,836,253,1000,-308,1000,-1000,-1000,710,-309,781,-1000,1000,-416,263,1000,1000,1000,-1000,-513,-111,1000,-114,257,739}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00978() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isBlock():boolean",
            new int[]{-886,-581,663,-1000,-194,1000,-242,-281,-621,-906,97,937,1000,328,294,218,-366,-1000,1000,575,-604,-462,93,-982,-611,-403,289,522,484,404,-519,1000,231,-301,-690,-637,1000,-160,856,1000,-20,-607,-1000,567,-1000,1000,1000,-304,-491,-331,-173,960,363,52,-874,-155,-680,-106,-219,-1000,-125,-413,901,-817}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00979() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isBlock():boolean",
            new int[]{1000,-227,-998,438,1000,546,906,327,830,-641,576,-758,-75,-198,-319,1000,-708,-372,-138,-685,1000,-617,-402,-727,1000,-525,-1000,-1000,-36,-245,925,659,848,-568,708,951,362,-732,-309,-1000,200,-173,1000,-728,-256,-832,-1000,890,-620,-840,-1000,604,-327,215,251,1000,990,-1000,-831,148,1000,1000,215,579}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00980() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isBlock():boolean",
            new int[]{685,759,-861,-354,398,509,219,311,-76,-1000,-109,-223,337,-48,345,1000,331,-568,-171,-1000,351,-1000,-1000,-271,699,-148,-547,824,87,-717,310,1000,768,161,682,1000,1000,-411,-286,355,-73,687,468,424,-1000,427,-79,997,-212,-91,-162,770,50,-807,-203,1000,308,-1000,-284,-847,962,-21,98,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00981() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isBlock():boolean",
            new int[]{51,13,-559,986,-271,1000,-80,-1000,1000,-288,517,-930,-1000,-991,-660,150,390,371,-1000,1000,-1000,3,52,146,-550,52,-175,-813,-1000,443,-377,618,220,64,1000,739,-133,220,-1000,-1000,410,538,8,-366,1000,-1000,-1000,-97,940,55,-1000,667,-227,992,229,764,1000,-319,252,632,1000,-1000,-660,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00982() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isBlock():boolean",
            new int[]{990,249,-1000,-166,228,154,-313,1000,-612,991,223,319,-1000,-1000,-416,700,781,889,1000,403,446,-852,509,1000,1000,-1000,-1000,-1000,634,-819,1000,648,-614,519,-917,-156,752,-1000,-537,-1000,962,137,-1000,-1000,1000,-46,-804,846,-166,-41,1000,-1000,-1000,-1000,1000,-1000,-1000,-1000,-620,-123,-95,-39,-986,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00983() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isBlock():boolean",
            new int[]{371,-191,167,88,1000,-12,821,-861,121,525,501,106,438,715,6,31,-154,-518,116,-838,523,95,-760,-920,277,-332,-343,-671,410,537,-458,361,648,-5,31,-303,-280,-78,400,-596,-261,55,-280,-49,-601,-909,-74,-513,214,-592,-666,423,173,-604,-533,151,61,-189,534,1000,368,-141,165,-116}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00984() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isBreak():boolean",
            new int[]{-782,124,15,-1000,-389,95,325,-315,-1000,231,-962,-393,513,417,-1000,1000,-167,-1000,-505,-250,-1000,-661,142,168,-423,1000,-43,685,-789,-1000,-292,-1000,-1000,1000,148,743,645,-217,-129,-406,1000,-787,663,-1000,-29,-26,-593,-415,-172,-833,545,-471,-1000,-1000,-73,-46,199,313,-537,572,-1000,316,1000,189}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00985() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isBreak():boolean",
            new int[]{1000,-366,617,-208,508,386,-660,703,-342,-328,221,440,-422,-431,785,-103,-310,408,658,10,-61,542,-324,-1000,771,-798,294,-335,-245,732,1000,194,-187,1000,-148,93,170,1000,1000,-406,-32,819,-1000,879,-820,-803,-312,-839,1000,-387,-172,-821,911,282,-140,275,168,63,404,-118,1000,168,-732,-668}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00986() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isBreak():boolean",
            new int[]{-503,249,718,-1000,345,60,1000,-413,593,-315,-873,-392,1000,206,934,-301,912,-1000,-1000,-1000,188,-421,166,-1000,1000,36,23,1000,442,942,210,890,703,-575,-677,-417,901,723,-688,640,-252,875,-822,820,499,601,840,-223,82,-422,1000,-1000,-144,271,207,505,1000,-768,-627,453,932,-266,-300,-697}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00987() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isBreak():boolean",
            new int[]{326,249,1000,-344,-614,251,838,-252,91,-220,-834,-632,-437,66,858,-255,-873,800,-1000,-343,983,-928,270,1000,163,-46,-761,-98,-137,1000,1000,944,-665,-932,-1000,242,192,1000,-1000,1000,-1000,-600,1000,568,1000,986,364,-1000,81,-778,-374,-1000,-519,400,779,140,1000,-643,571,968,230,-813,293,-396}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00988() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isBreak():boolean",
            new int[]{-522,274,676,-1000,742,334,1000,-1000,186,735,-873,-1000,1000,156,873,-496,425,-545,-1000,-1000,396,-1000,530,-754,1000,-287,296,12,-1,1000,790,1000,371,-1000,-1000,-95,655,1000,-1000,1000,-781,-464,-183,275,370,731,53,-604,-38,-142,986,-1000,-61,520,802,233,1000,-859,-402,231,1000,-115,199,-924}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00989() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isBreak():boolean",
            new int[]{1000,-341,920,-607,458,-210,-543,156,-522,-188,-376,292,-125,363,118,1000,-526,-578,-143,80,182,458,-779,180,-15,-1000,-706,-130,-630,368,22,306,-682,670,-282,850,94,813,-916,-66,565,-196,-236,-116,765,-199,-516,-190,1000,-822,-118,-695,-688,-654,204,-63,400,404,555,978,348,-209,238,-697}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00990() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isBreak():boolean",
            new int[]{506,-782,692,-402,-941,-1000,-729,80,311,702,44,1000,-624,546,-1000,1000,-661,-258,432,1000,-1000,485,-563,-1000,-436,-319,-613,-1000,-977,54,-1000,-80,704,993,975,381,-484,-1000,-1000,-1000,1000,-341,-587,781,906,-1000,-1000,398,1000,-438,-515,568,-1000,227,-135,-848,9,866,-564,1000,139,-69,-509,753}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00991() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isBreak():boolean",
            new int[]{1000,-366,694,-413,140,-190,-660,703,-342,495,663,636,-607,91,-606,1000,-310,-527,658,979,-249,542,-292,-303,-450,-798,508,-455,-960,199,-431,194,-598,1000,116,361,199,824,-680,-406,439,490,-537,879,1000,-803,-1000,120,1000,-387,-172,-391,-802,1000,214,275,-647,809,420,1000,352,-295,-419,-437}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00992() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isBreak():boolean",
            new int[]{343,-276,419,-434,-137,-89,-1000,-160,179,311,-302,150,1000,206,695,1000,1000,-1000,314,1000,-759,1000,-696,-894,1000,597,-952,1000,-304,214,-1000,99,885,1000,1000,-1000,1000,-177,-688,-127,-252,421,-1000,-475,1000,-340,-82,1000,542,-1000,1000,-1000,-293,524,-1000,-729,1000,835,-1000,1000,923,-266,-495,-982}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00993() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isBreak():boolean",
            new int[]{504,-366,-7,90,-2,-269,547,-172,-100,-81,267,-206,-607,828,-267,145,-806,641,-389,-1000,-249,-1000,-741,464,-668,-635,594,-22,-960,268,1000,-1000,-1000,-109,-787,698,199,437,-434,575,-167,-58,1000,740,421,-305,-512,-1000,810,658,-413,617,-195,302,1000,451,90,404,210,529,-1000,182,726,475}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00994() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isBreak():boolean",
            new int[]{-356,-368,-134,-800,-357,-415,878,-342,-690,269,-1000,563,1000,248,180,1000,1000,-1000,1000,-77,-808,-299,-53,-1000,1000,949,-1000,1000,-949,835,-1000,617,578,-20,669,-139,1000,-677,-1000,-186,1000,348,-568,-248,1000,-1000,-87,1000,-361,-1000,1000,-662,-1000,-542,-532,-1000,1000,802,-1000,1000,599,-1000,650,766}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00995() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isBreak():boolean",
            new int[]{270,-47,867,-292,-63,539,1000,74,534,-315,-873,-392,1000,-55,787,421,947,-1000,-598,-1000,-110,-122,-196,-334,1000,-419,436,732,-57,837,-84,950,420,-1000,29,-507,1000,610,-698,640,-252,1000,-1000,260,702,28,269,370,601,-422,916,-927,-52,819,207,540,1000,-832,-350,658,1000,-266,-21,-938}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00996() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isBreak():boolean",
            new int[]{-28,49,328,-292,250,521,-139,-837,-512,339,-758,-1000,1000,-99,336,828,1000,-1000,-256,-64,-635,-20,-327,-710,1000,597,-862,1000,-1000,1000,-199,514,624,313,1000,-322,1000,-13,-568,748,579,756,-708,-846,1000,-165,110,1000,100,-1000,1000,-1000,-266,261,-938,-921,432,841,-972,1000,883,-687,566,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00997() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isBreak():boolean",
            new int[]{546,-417,1000,68,-806,-4,-211,343,1000,471,-142,364,-137,175,-466,542,244,-835,3,400,-759,39,228,-1000,-5,-582,-178,-400,-334,325,-457,474,1000,-723,422,36,493,-513,-688,-688,942,269,-767,820,770,-799,-560,306,861,-395,-60,98,-441,442,-31,511,306,-307,-476,868,702,-108,-349,227}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00998() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isBreak():boolean",
            new int[]{1000,-597,948,-119,-133,-190,-480,262,-299,-57,973,-150,-997,43,785,932,73,-527,842,792,-444,-680,53,-571,-804,-1000,3,-998,-1000,269,1,454,4,835,-204,361,-279,708,-1000,14,820,673,125,-465,1000,-1000,-1000,451,1000,-387,-939,112,-826,939,253,648,-276,1000,312,1000,34,-170,-216,-39}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00999() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isBreak():boolean",
            new int[]{1000,-221,1000,-353,1000,-918,-920,-235,-991,73,47,1000,-1000,1000,486,629,-1000,299,331,543,653,714,-867,778,-763,-949,-1000,-927,432,635,7,558,-514,621,-934,716,49,765,-802,645,-344,-731,-186,1000,813,576,-452,-468,1000,-777,-901,-569,-925,1000,789,111,-664,-424,862,1000,-191,-1000,-1000,259}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01000() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCall():boolean",
            new int[]{780,-686,-509,750,521,581,1000,323,-65,602,-495,-1000,-105,163,-409,-58,787,1000,517,-39,-315,-745,-388,-219,-234,597,-9,701,-219,752,-618,227,-138,-19,-22,123,962,-188,-31,-151,-766,-1000,-121,1000,-170,218,-126,-288,-689,1000,-241,-179,-1000,-233,-1000,250,1000,-881,-157,339,-253,-346,-344,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01001() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCall():boolean",
            new int[]{647,-11,127,1000,-193,699,1000,276,807,-619,-426,-365,153,-186,-1000,-163,628,735,-965,-308,-1000,1000,630,-44,-109,-755,34,151,1000,888,539,179,-148,519,-870,92,1000,-287,-502,-401,-198,778,373,-610,-518,-658,89,-37,-929,-674,-746,-1000,538,-265,-485,-326,799,-1000,379,317,-1000,680,-222,-57}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01002() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCall():boolean",
            new int[]{1000,-641,-729,948,-678,990,741,166,961,-455,-778,-187,1000,401,-1000,-1000,-112,-140,-943,694,-1000,-1000,741,-1000,-673,-1000,1000,1000,136,-1000,-403,768,-168,1000,437,240,795,-107,-378,-596,-393,-1000,429,202,-5,60,10,265,-953,-777,1000,-343,690,-352,-433,-1000,983,858,1000,796,-490,1000,-828,972}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01003() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCall():boolean",
            new int[]{981,184,-803,-356,-146,-723,382,-558,-204,-317,-746,306,-669,778,-515,150,416,815,197,-859,394,-214,-806,416,372,880,350,61,-536,-854,812,-702,864,836,-430,346,-504,-396,-803,793,116,260,-964,-520,-821,-923,982,-134,-482,-194,157,656,-59,478,219,36,231,-126,849,-663,-307,43,-993,112}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01004() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCall():boolean",
            new int[]{94,-736,-1000,1000,-997,-407,506,187,1000,115,1000,924,966,527,-901,-187,-671,1000,-972,-1000,-637,-873,297,-516,-470,-1000,784,-179,-1000,-448,-416,1000,101,1000,519,1000,-859,-237,-1000,-318,1000,-759,1000,-399,-316,112,1000,-103,-103,-110,309,-61,957,276,-505,-143,888,15,469,260,-874,1000,-605,-963}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01005() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCall():boolean",
            new int[]{-7,59,-552,905,-374,378,-1000,480,947,-944,-56,-425,712,-1000,-1000,185,484,801,-1000,907,43,942,-757,350,871,-989,997,-226,1000,371,77,-236,917,264,-408,-677,1000,-842,-246,566,1000,1000,1000,-766,-265,-913,-337,89,-745,-753,-989,-106,1000,419,585,-1000,-653,171,1000,80,-519,662,541,364}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01006() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCall():boolean",
            new int[]{-77,-522,-1000,-71,475,1000,-537,-1000,929,1000,-440,1000,-791,1000,-1000,371,1000,1000,-1000,1000,774,885,-1000,-1000,1000,-197,45,-1000,1000,1000,-21,-236,-580,-885,-1000,-312,1000,-733,-986,-1000,-1000,602,-1000,-742,-1000,12,301,292,-929,-662,-1000,-1000,-1000,-902,1000,944,159,666,-1000,61,-1000,-1000,-667,383}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01007() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCall():boolean",
            new int[]{172,-708,-729,466,539,-156,-662,-177,686,-277,1000,880,-720,401,-414,35,1000,-288,385,-573,204,-549,-157,204,868,733,-605,-59,1000,80,68,346,-369,-456,-1000,-45,795,-474,-358,-308,-1000,767,-902,-1000,-5,-774,10,-564,-953,129,-201,-343,75,-247,791,1000,-699,-1000,-821,-133,-490,-638,-227,972}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01008() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCall():boolean",
            new int[]{-1000,869,1000,-502,830,526,-570,53,591,-424,350,61,-1000,-1000,-1000,289,716,1000,-1000,1000,1000,915,-162,302,1000,-227,1000,742,1000,1000,-1000,-289,1000,-1000,-1000,-1000,1000,-1000,1000,951,-1000,886,-1000,1000,946,22,-1000,64,-528,-571,-1000,-1000,224,303,1000,-1000,-1000,412,72,702,-1000,-531,1000,738}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01009() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCall():boolean",
            new int[]{928,-661,-613,642,175,529,-16,116,783,-929,-353,381,266,144,-878,-959,360,-208,-426,356,-768,-156,732,-410,363,-505,726,871,903,-763,130,65,-216,714,-374,-253,708,-218,-99,-304,-798,-457,-77,-495,421,-529,-414,-127,-933,-148,850,-61,897,-256,-18,-370,625,-609,256,399,-271,607,-401,960}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01010() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCall():boolean",
            new int[]{685,-741,-1000,1000,143,-16,1000,136,1000,-595,-152,-365,595,400,-1000,-164,227,735,-627,-962,-690,-1000,738,-390,613,-932,144,106,-1000,897,539,65,-451,1000,-154,116,1000,-28,-576,-304,294,386,1000,-845,362,-524,419,-137,-636,-647,-985,277,23,24,-485,-69,799,-994,599,202,-313,1000,-424,-403}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01011() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCall():boolean",
            new int[]{-215,504,91,-852,-832,378,-1000,-34,444,856,344,1000,-1000,503,-1000,1000,1000,860,-280,907,1000,965,-757,-745,319,852,-48,-1000,1000,922,-1000,1000,-25,-1000,-1000,-261,1000,-369,371,-566,-1000,1000,-1000,72,-1000,467,-475,272,-1000,-132,-491,-1000,-862,212,1000,-238,-203,1000,-1000,-289,-1000,-1000,115,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01012() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCall():boolean",
            new int[]{-1000,-736,127,-149,37,617,-1000,421,145,610,-249,1000,-1000,-1000,-901,1000,-671,531,-1000,1000,501,1000,297,717,1000,893,178,-1000,1000,1000,-416,-188,1000,-1000,-1000,1000,-859,-1000,57,795,-1000,1000,-1000,627,-1000,112,-418,-130,-1000,-941,309,-1000,752,59,1000,-1000,-515,319,71,309,-1000,-1000,564,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01013() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCall():boolean",
            new int[]{157,-412,-299,642,-621,259,-90,724,165,-1000,54,1000,-235,-1000,102,-1000,-133,484,-1000,372,-159,798,1000,417,-477,-1000,1000,1000,559,-1000,539,228,750,1000,-180,-253,-344,-259,384,909,-101,-748,-742,297,1000,-917,-608,-396,-17,-905,495,925,396,448,-489,-1000,-43,-709,1000,856,-30,1000,543,54}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01014() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCall():boolean",
            new int[]{303,-572,-1000,1000,142,-622,703,187,923,-82,1000,1000,1000,616,-791,-227,733,796,-751,-1000,29,-1000,190,-833,-957,-828,784,-297,-1000,-448,-123,1000,101,-779,-1000,1000,-1000,-807,-1000,-318,1000,-949,1000,-549,-130,298,832,119,-92,57,493,-61,957,276,-646,-1000,975,15,469,404,-1000,763,-728,-963}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01015() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCall():boolean",
            new int[]{1000,153,-1000,25,519,412,-784,-143,647,696,-134,493,-872,872,-901,1000,1000,-58,-321,877,-64,0,-494,-1000,-470,663,-1000,-1000,1000,1000,-999,355,-1000,1000,-1000,183,1000,-293,-341,-1000,-1000,210,-1000,-688,-316,371,-378,672,-103,-617,309,-1000,-1000,-906,-505,495,888,16,-1000,384,-935,-1000,-503,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01016() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCase():boolean",
            new int[]{-6,178,-658,557,-509,-884,-836,-1000,1000,1000,690,-617,1000,-292,-358,891,1000,496,285,764,-769,-1000,-743,771,679,-249,-822,-1000,804,-120,322,989,-745,788,742,-1000,712,-1000,1000,-1000,386,-563,-884,-1000,-1000,641,712,1000,831,1000,-316,628,-179,99,1000,-1000,1000,902,-1000,-127,345,-196,171,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01017() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCase():boolean",
            new int[]{1000,-591,-112,957,-1000,-1000,-557,-582,1000,-805,-625,208,1000,-1000,868,-367,569,-945,-600,-189,-500,1000,-10,161,1000,-473,-1000,161,264,581,-1000,885,49,-1000,644,-1000,517,-1000,473,-470,1000,-604,-1000,-158,1000,715,-161,1000,1000,360,-526,-260,1000,-301,1000,-343,384,-1000,365,-1000,542,326,-733,904}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01018() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCase():boolean",
            new int[]{813,-46,770,375,-1000,-972,-904,516,1000,-462,-792,-1000,1000,-654,339,641,-380,-348,398,1000,-1000,302,1000,364,-619,-95,-1000,-1000,-81,380,-930,951,-814,128,1000,-770,66,1000,752,-996,1000,-338,758,-327,-1000,754,-547,722,73,1000,627,-249,1000,1000,-164,246,256,-1000,-1000,-714,414,-1000,608,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01019() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCase():boolean",
            new int[]{37,588,-487,571,-845,-1000,-657,-669,341,1000,690,-1000,524,-52,-370,817,1000,1000,1000,758,-143,-1000,52,716,-536,-37,-551,-1000,-581,-151,91,-377,-1000,1000,379,41,191,-265,1000,-1000,205,-103,-942,-804,-1000,655,536,432,-255,1000,-110,256,-126,1000,-17,-578,563,407,-488,-27,55,-1000,614,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01020() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCase():boolean",
            new int[]{351,-256,-457,61,-313,-326,-795,-129,429,-203,-722,668,-418,-387,81,-26,350,624,-460,-683,-77,-418,-253,-532,-1000,-668,1000,336,-715,-297,-391,-696,-569,883,-929,790,40,-635,283,1000,34,-520,837,336,-235,239,592,-579,391,-410,-129,-550,268,-188,-764,-151,-62,790,-1000,492,626,39,-28,381}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01021() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCase():boolean",
            new int[]{-992,619,617,400,-511,-1000,-822,1000,1000,363,-1000,1000,-944,56,-1000,-15,1000,-390,-1000,-1000,-549,460,626,-154,881,-1000,289,1000,-1000,410,-1000,-1000,-377,31,-1000,1000,-1000,1000,720,1000,530,-1000,-1000,1000,-250,1000,773,-475,620,-1000,-1000,-1000,663,-39,-494,-1000,-517,1000,1000,1000,956,352,-1000,835}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01022() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCase():boolean",
            new int[]{1000,-287,-398,494,-1000,-599,-121,744,-861,-915,-625,-1000,-443,453,-358,-105,961,595,1000,1000,1000,912,1000,644,-1000,195,-254,-1000,-1000,483,307,-1000,-1000,1000,637,1000,-1000,972,1000,-126,479,1000,-1000,-157,880,471,-832,-588,831,736,261,-1000,983,396,-1000,-534,-359,1000,-1000,-899,-483,-1000,171,954}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01023() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCase():boolean",
            new int[]{1000,274,912,577,-1000,-1000,-1000,-351,1000,539,-1000,1000,565,-1000,13,370,-509,-750,-1000,-1000,-658,1000,-22,-963,1000,-1000,-1000,977,-149,-37,-1000,629,-11,-426,-1000,70,282,-1000,-357,662,1000,-1000,-1000,757,-197,410,559,-386,1000,-447,30,921,1000,-443,481,-1000,451,-1000,1000,846,1000,863,-390,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01024() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCase():boolean",
            new int[]{859,154,21,-1000,-944,-752,-860,2,-812,-520,-1000,489,730,-578,559,42,627,-46,-1000,-329,-473,-116,308,89,267,-662,-504,303,-28,690,-1000,108,-421,281,-430,-522,389,1000,440,-358,365,-1000,862,-273,-590,815,-111,24,561,51,1000,-584,810,-151,-111,86,695,-1000,360,-115,755,188,-257,898}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01025() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCase():boolean",
            new int[]{1000,363,-994,608,-1000,416,-860,-197,1000,977,-667,-34,428,-1000,-745,736,558,719,-244,293,-586,165,337,-333,235,134,-843,-658,-589,-93,-1000,-125,-707,604,106,242,1000,243,1000,-400,735,-564,-962,403,-507,649,575,-141,830,784,-89,-593,1000,606,-868,-445,47,115,175,896,-73,-926,363,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01026() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCase():boolean",
            new int[]{-329,-107,-327,-342,554,-118,305,-940,258,-507,689,-475,-36,38,-546,-180,711,643,824,872,-992,-946,-307,-327,410,654,34,239,-897,-381,743,-193,-377,286,-689,92,-58,465,135,-345,-708,-309,739,232,-605,251,-344,-813,9,-854,347,188,-908,-858,157,669,308,531,-3,-339,71,293,-764,-809}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01027() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCase():boolean",
            new int[]{-528,-307,711,-603,-664,-86,-645,887,729,-754,-548,-399,430,-110,431,-199,448,451,64,365,-750,-36,41,860,-863,-217,-633,-1,-1000,1000,-129,-105,218,-786,396,-721,-623,194,432,-368,665,-1000,-885,-400,-346,1000,-583,1000,633,-52,-138,-1000,630,-515,1000,-438,672,-1000,960,-541,529,845,-393,465}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01028() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCase():boolean",
            new int[]{-123,34,464,-403,-313,697,-707,-300,963,-386,-739,-746,713,56,-516,-76,430,217,315,496,-508,-562,1000,251,-894,-79,154,-533,259,130,776,812,-435,444,268,81,158,-41,376,-276,563,-482,930,-342,-894,1000,-44,722,-267,160,441,-221,1000,325,202,1000,804,-153,-1000,255,251,-32,555,792}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01029() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCase():boolean",
            new int[]{64,-97,614,711,-509,-897,-914,-1000,1000,677,690,-616,1000,-332,351,995,478,-571,285,764,-1000,-321,-525,716,-515,-249,-1000,-695,1000,106,309,1000,-419,-210,742,-1000,361,-1000,395,-1000,1000,-927,-884,-1000,-944,942,403,903,962,-1000,-133,1000,10,-86,1000,-1000,1000,-498,-1000,-121,446,530,9,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01030() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCase():boolean",
            new int[]{-304,298,276,1000,-1000,-1000,-885,-48,1000,815,-465,-133,1000,-1000,-251,1000,-679,905,-745,143,-1000,144,177,-266,212,-882,-1000,-855,-211,-315,-1000,238,-962,759,543,-545,-86,-580,1000,-955,1000,207,-946,207,-124,-2,917,722,503,1000,504,489,1000,516,-73,-1000,243,55,-911,-914,511,-1000,459,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01031() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCase():boolean",
            new int[]{-524,-821,-869,299,-445,322,156,1000,-218,-1000,-126,-301,-977,756,120,-374,585,1000,1000,-564,417,170,-148,1000,-823,-451,1000,1000,-1000,828,-270,-1000,-714,905,-225,-239,327,-584,1000,1000,-550,1000,-554,582,1000,-132,528,503,-1000,461,-1000,-1000,-761,-675,-1000,-1000,-159,1000,545,-1000,-1000,-645,-273,197}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01032() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCast():boolean",
            new int[]{681,-436,9,-728,-354,352,-360,304,479,710,-730,391,-1000,269,442,461,-88,-487,416,-556,-111,466,-403,-72,-622,218,282,966,408,-764,-259,71,-840,381,390,123,-11,-1000,406,-167,326,333,731,216,-505,-102,663,1000,577,-459,-414,-101,-731,873,-885,-477,394,520,-192,-931,585,808,98,408}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01033() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCast():boolean",
            new int[]{585,934,-660,-1000,313,218,-360,-53,-733,23,-730,-673,-201,-738,442,682,479,69,741,-556,75,867,-917,-72,-986,1000,445,-887,-1000,1000,-874,248,-1000,338,-417,-130,-1000,67,-1000,742,630,1000,389,165,-505,-740,-1000,1000,357,1000,75,-213,1000,1000,-584,582,76,47,763,898,1000,656,1000,422}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01034() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCast():boolean",
            new int[]{-987,-781,843,-622,321,605,884,-343,-770,-1000,-149,-840,629,234,-685,-1000,-788,1000,-631,1000,-523,-1000,-250,-398,-200,268,-492,747,-431,1000,-97,-909,-375,-1000,-937,1000,-296,-131,49,385,725,-500,-12,-743,713,415,197,-379,-949,-174,63,-969,-857,-1000,516,-1000,636,-492,952,-175,-286,-667,192,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01035() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCast():boolean",
            new int[]{672,44,-394,-996,-1000,-888,-286,-156,35,687,-1000,-438,-857,499,-120,-534,796,-767,-369,-1000,788,108,-302,-983,-379,-316,753,419,824,100,-227,-982,-1000,346,100,-61,134,-912,1000,154,1000,1000,581,728,92,-261,13,15,435,39,-684,-224,-1000,492,589,-1000,657,732,989,94,1000,458,-353,623}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01036() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCast():boolean",
            new int[]{-820,-436,-1000,-564,-319,-974,256,-1000,-704,280,855,760,1000,-584,-623,-1000,-164,481,192,636,-976,-769,-422,28,133,-1000,-763,633,1000,-881,141,-1000,1000,-856,-1000,473,1000,-1000,1000,-365,-723,-1000,-869,-1000,536,-281,783,374,-1000,-892,-596,69,165,-778,1000,399,-298,-468,44,-1000,-572,-1000,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01037() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCast():boolean",
            new int[]{256,648,-42,746,500,416,617,-282,-1000,-374,310,445,1000,-1000,233,1000,-15,68,316,1000,-457,-142,531,1000,-583,-208,-770,369,339,-321,-431,-346,172,-961,203,535,122,957,612,586,1000,-501,-1000,-461,-1000,456,-964,-823,177,280,563,-47,891,-764,453,1000,-259,-722,-709,398,-72,-685,338,-195}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01038() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCast():boolean",
            new int[]{645,733,784,396,-256,438,33,379,-547,-394,1000,247,918,401,-1000,-743,-1000,405,21,1000,183,-779,-1000,-558,-619,-85,-845,895,1000,-670,624,-428,16,86,1000,1000,31,817,540,1000,-893,125,196,624,-399,-183,-313,867,-290,-1000,-921,-679,-376,-1000,8,-684,84,-381,697,503,1000,-73,-1000,-916}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01039() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCast():boolean",
            new int[]{1000,-461,-209,-309,705,1000,-44,-197,-619,-408,-335,-436,148,-242,-380,513,587,-249,219,-1000,-19,-443,-1000,139,-536,654,-32,-534,748,287,-1000,629,-622,-398,-634,-806,-698,292,-1000,-765,641,231,-12,919,-6,721,71,-874,235,801,85,-393,-650,657,62,917,266,786,-172,-436,-404,695,277,167}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01040() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCast():boolean",
            new int[]{271,-836,274,980,676,1000,914,-282,-1000,-4,-97,1000,-929,554,-1000,1000,184,818,-462,1000,377,-577,1000,1000,-329,-656,-770,793,-1000,-247,-1000,1000,20,-975,269,-76,454,-329,-43,-909,1000,7,-432,700,-1000,266,7,-1000,177,-852,-492,-684,597,398,437,-1000,-259,817,-788,-976,-442,158,1000,17}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01041() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCast():boolean",
            new int[]{361,559,274,-317,-548,342,581,-1000,-1000,-31,310,625,-929,-1000,865,1000,1000,-1000,480,-915,253,-594,171,668,-376,-770,-1000,-723,20,280,-613,-83,-67,-863,-80,-103,-467,1000,862,1000,1000,320,-1000,700,111,413,-1000,-1000,-1000,1000,819,411,1000,775,622,1000,524,-638,-788,461,623,745,59,-723}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01042() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCast():boolean",
            new int[]{-326,689,-648,380,-77,-463,367,-1000,-512,421,468,639,821,-304,-273,-801,154,163,229,756,-692,-81,363,279,-115,-1000,-646,742,1000,-881,9,-989,831,-667,-656,831,950,-1000,966,-300,-378,-1000,-814,-1000,31,-222,-469,-62,-1000,-887,-537,371,-130,-474,1000,244,-71,-143,-230,-1000,-192,-897,-772,-211}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01043() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCast():boolean",
            new int[]{-425,-756,485,684,309,-199,795,-997,-1000,-1000,-456,399,237,151,-220,50,-520,1000,-598,678,670,-1000,107,-48,977,-66,1000,747,-705,1000,-665,-579,-136,-1000,-849,1000,-956,-620,1000,203,1000,25,1000,-245,-327,330,48,-927,-992,-153,-909,-49,-874,-1000,287,-1000,636,63,-358,-1000,-35,-41,-365,-948}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01044() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCast():boolean",
            new int[]{-472,-26,248,-77,-1000,-116,214,-470,787,442,1000,-510,875,1000,-1000,-696,-10,76,570,235,-1000,-420,-1000,328,-245,-485,478,-468,615,-682,1000,-845,-657,850,1000,852,677,1000,-676,747,-1000,-1000,1000,609,1000,-5,-1000,1000,-161,-1000,-1000,-247,861,108,788,-1000,542,1,1000,-493,1000,76,-207,-704}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01045() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCast():boolean",
            new int[]{-1000,-401,-238,-910,286,-480,788,-1000,-911,-267,-448,700,1000,-696,370,1000,759,53,-182,-1000,208,-1000,621,-620,-245,240,-104,-1000,-1000,228,-923,-776,-802,-1000,-905,168,-513,-167,341,15,1000,229,-117,609,544,-120,-393,-1000,-931,1000,517,-251,1000,1000,308,1000,-670,-193,-296,353,687,428,772,-929}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01046() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCast():boolean",
            new int[]{-592,-487,-571,-848,264,-639,-54,-683,348,330,-612,241,-66,-692,-246,598,-78,272,610,-984,1,109,844,-431,-484,-200,959,-323,-245,785,-556,-598,18,-294,-450,-123,209,-585,-636,-295,-66,105,469,-429,143,-246,644,-997,186,-334,110,-729,820,852,622,717,214,216,341,-503,-764,75,888,-347}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01047() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCast():boolean",
            new int[]{-1000,-86,10,-3,-760,564,-30,287,239,479,1000,-611,1000,766,-696,-284,-156,270,485,-59,-1000,-347,-845,101,-1000,-23,507,-412,455,-706,1000,-297,-469,443,1000,927,-18,844,-782,447,-985,-423,1000,-430,1000,584,-677,1000,-810,-943,-757,-441,-1000,12,994,-1000,179,32,842,-622,829,629,-1000,-696}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01048() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCatch():boolean",
            new int[]{1000,-336,-543,1000,558,-518,538,-1000,-170,-230,-199,-684,821,-293,-1000,1000,-842,-113,-1000,-92,-1000,-218,712,-594,1000,1000,756,-448,-1000,307,302,-16,-595,-1000,-37,672,-72,666,579,-677,506,-1000,-1000,481,-1000,142,-461,1000,532,-324,-1000,751,-424,94,408,-1000,-395,1000,116,270,409,-1000,551,475}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01049() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCatch():boolean",
            new int[]{-602,269,-854,433,344,-662,-917,490,873,108,-718,263,-221,-733,205,-682,-889,430,556,647,-476,1000,-363,-716,-800,82,-219,470,-42,660,122,371,-812,17,21,702,-351,399,-1000,544,-640,-353,-114,47,59,542,-1000,64,34,-371,547,-373,-1000,-906,-476,-5,-1000,143,-288,1000,92,79,-190,-280}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01050() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCatch():boolean",
            new int[]{1000,-336,337,1000,727,-518,1000,-1000,357,-547,-443,-530,1000,1000,-369,666,-124,782,-1000,826,-525,-218,1000,-1000,1000,-407,-69,-188,-504,-475,1000,783,429,-197,59,-180,-72,1000,579,-185,850,110,-1000,1000,-1000,-1000,541,311,797,-1000,-1000,-231,553,1000,1000,-693,1000,665,-1000,-1000,-281,-1000,915,442}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01051() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCatch():boolean",
            new int[]{199,269,-1000,752,162,34,-624,-117,473,183,-404,300,56,434,369,272,-320,536,-1000,-1000,-1000,-222,176,167,832,1000,1000,-611,-423,716,-745,2,-966,-835,-10,734,-290,738,130,-720,-211,-312,-123,-150,238,791,-990,1000,230,599,208,1000,471,-468,-849,-68,-685,425,1000,518,848,-851,585,-150}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01052() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCatch():boolean",
            new int[]{1000,-796,25,-894,-597,1000,211,-152,32,90,-497,-299,262,1000,-567,758,-389,1000,140,-908,-81,-890,708,-664,851,-1000,-46,955,418,-570,-921,-436,134,780,59,91,-564,395,185,1000,393,-377,569,911,0,-460,-334,-455,435,-578,-611,799,542,-112,258,224,-463,-69,-594,-339,329,-74,486,-63}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01053() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCatch():boolean",
            new int[]{-144,-501,-196,-1000,-365,591,-1000,912,1000,1,-1000,340,-665,191,1000,-40,-162,330,354,-1000,-316,739,108,-449,-21,-1000,1000,766,1000,-285,-699,1000,67,1000,5,-347,-958,165,-794,938,-689,126,1000,476,935,403,-493,-473,-100,-182,887,-1000,524,-928,-971,697,-432,-735,-277,66,89,372,68,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01054() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCatch():boolean",
            new int[]{-1000,-996,1000,-1000,574,197,-551,1000,920,-908,-1000,179,-1000,-254,611,412,-427,893,-163,101,164,499,291,-827,-1000,-806,995,882,1000,-855,1000,800,865,1000,-264,-1000,-982,-139,-933,145,448,572,912,872,674,518,779,-1000,-69,-1000,1000,-896,-127,-772,-412,-552,1000,-979,-1000,-552,-779,1000,-730,-929}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01055() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCatch():boolean",
            new int[]{576,-296,-741,198,774,-1000,597,-922,1000,3,-649,151,1000,1000,1000,-436,-189,144,-1000,888,-884,-902,909,-710,1000,99,665,-188,-254,252,986,800,-212,-693,21,-203,-868,1000,1000,-185,238,546,-444,170,-936,-487,-184,804,-31,-949,-1000,-373,393,1000,-211,-948,997,496,-1000,-534,-449,-1000,623,-183}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01056() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCatch():boolean",
            new int[]{-1000,-751,-102,-125,269,-1000,-1000,1000,1000,196,-1000,1000,-690,172,1000,-1000,-1000,633,895,705,84,925,-198,-1000,-979,-1000,-48,1000,1000,168,304,1000,-320,1000,-87,-469,-1000,-73,-1000,1000,-540,186,1000,-36,1000,50,-774,-1000,-928,-481,1000,-1000,-983,-1000,-1000,219,-1000,-1000,-1000,1000,-778,740,-400,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01057() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCatch():boolean",
            new int[]{502,384,-794,739,695,-254,385,-531,-106,374,696,952,-766,149,964,-976,242,-444,298,-75,134,135,936,-386,207,483,-513,-666,-753,-429,856,-779,-302,393,422,649,-420,52,-355,-227,-423,-734,163,-772,573,961,-357,330,-4,150,-792,260,-216,-395,-938,-268,527,-30,117,384,-619,894,868,-211}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01058() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCatch():boolean",
            new int[]{-731,-122,-240,-800,506,559,-673,881,886,168,-793,151,-310,10,883,-150,-764,-13,-386,-262,-278,-302,-1000,-481,-717,-639,995,799,725,-62,885,806,-50,791,-146,-533,-794,354,-763,893,-315,105,915,-690,-478,365,228,804,235,-652,439,-931,985,-319,-557,-948,475,-444,-443,-534,-90,437,1000,-675}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01059() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCatch():boolean",
            new int[]{-168,299,-1000,1000,612,-1000,-242,-993,623,733,-512,157,743,-486,321,1000,-1000,-507,-1000,-204,-1000,-537,1000,-1000,680,718,1000,455,-1000,69,433,297,-1000,-1000,221,329,-425,1000,-72,467,449,-1000,-936,-745,-1000,457,-185,1000,392,-167,-809,1000,404,294,-863,-1000,152,1000,-495,900,499,-1000,1000,-104}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01060() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCatch():boolean",
            new int[]{581,-476,832,1000,1000,919,198,738,-526,-368,-100,141,-342,438,513,-854,1000,872,893,-265,755,-321,29,1000,-547,80,269,-373,61,228,1000,-883,-143,1000,-392,-115,1000,-319,434,-771,-121,1000,478,-491,603,622,1000,-891,322,99,663,241,-28,-531,815,-841,-157,-361,-998,-753,406,840,-530,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01061() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCatch():boolean",
            new int[]{477,-991,862,300,-722,768,211,-91,32,477,-13,-22,72,1000,-1000,1000,-882,1000,269,-602,116,184,1000,-1000,456,-1000,-46,1000,418,-931,-729,-63,-37,-1000,-264,-366,-593,356,382,1000,1000,328,-145,201,45,-1000,0,-824,644,-419,-625,878,1000,-162,237,-650,-451,-254,-1000,315,-433,366,-73,-63}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01062() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCatch():boolean",
            new int[]{23,413,-192,624,781,-851,341,290,-529,485,34,-359,513,-964,-560,656,287,-525,-778,63,-665,-839,-501,566,-258,937,-27,-255,-764,475,762,-955,-610,-179,-870,193,516,-131,921,92,328,-642,-637,-185,-758,702,162,639,333,-529,307,248,356,643,848,-786,38,920,-937,-373,841,300,899,404}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01063() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isCatch():boolean",
            new int[]{-1000,-353,28,857,-161,197,-1000,121,1000,1000,-1000,1000,-657,-548,1000,-1000,-390,-820,-388,-834,-600,-213,-1000,706,42,-135,187,1000,117,1000,-172,-336,-1000,-260,-339,266,-476,887,-1000,1000,-1000,1000,1000,-1000,597,995,-158,328,-1000,1000,1000,-99,804,-1000,-1000,-422,853,-47,-1000,1000,472,971,-206,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01064() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isComma():boolean",
            new int[]{-334,124,-98,1000,-1000,1000,888,-932,-243,-979,716,1000,-123,114,472,-456,1000,-425,-622,113,-1000,275,1000,1000,1000,-1000,-373,-807,-217,-792,326,693,269,1000,1000,557,-383,-912,298,-1000,-998,260,-411,23,231,-847,-424,1000,817,-592,-344,-76,-168,-541,-845,470,83,-615,-251,1000,1000,356,69,144}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01065() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isComma():boolean",
            new int[]{213,-486,-484,425,-730,760,595,-493,626,-65,91,816,700,443,-778,750,273,-937,-547,932,-97,318,1000,398,169,-866,1000,723,-275,-688,-424,1000,-1000,-382,1000,-368,1000,-400,-511,-1000,-224,1000,-207,1000,780,983,-1000,-1000,304,726,-844,1000,-1000,519,-580,-183,-331,371,-431,1000,565,-1000,341,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01066() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isComma():boolean",
            new int[]{982,893,-526,1000,-68,133,-639,-76,1000,-1000,-2,-1000,274,-845,-835,147,45,937,-962,-116,-509,1000,-529,385,-519,-820,554,-1000,-912,88,338,-5,-686,-172,-168,-128,-982,1000,899,1000,-572,-194,-599,-216,741,-364,424,519,565,69,400,-1000,-325,46,-299,-359,-681,-990,1000,-351,-202,217,569,854}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01067() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isComma():boolean",
            new int[]{397,719,-1000,247,-418,-405,583,-1000,994,-1000,1000,-1000,-1000,-775,-13,1000,1000,961,-886,-37,-824,1000,-815,277,730,1000,-973,-494,-1000,-1000,1000,276,-298,-733,-168,529,-751,1000,1000,-1000,-1000,700,-1000,-793,1000,444,-185,589,1000,460,-923,588,553,-99,-1000,120,-651,-1000,1000,11,626,-7,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01068() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isComma():boolean",
            new int[]{-656,164,-536,-137,1000,675,300,-1000,-377,-689,1000,-1000,-1000,-906,1000,871,1000,433,-96,-477,-919,1000,-803,1000,1000,551,170,-1000,-1000,-806,751,-1000,616,907,-1000,485,459,823,-132,-600,-468,-293,-378,-1000,201,-798,685,891,801,-1000,-999,-769,132,-1000,-1000,-316,664,434,811,-482,802,1000,-121,463}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01069() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isComma():boolean",
            new int[]{622,929,-508,1000,464,-425,703,-65,447,-653,586,-982,-485,-293,-1000,-101,-440,-38,617,1000,-211,863,973,0,-24,727,1000,-264,225,-779,280,-465,-439,-517,-33,-869,936,-1000,-1000,1000,143,-330,191,-373,-313,1000,-143,232,370,-562,745,363,33,-1000,-447,169,352,238,415,324,-133,953,419,-742}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01070() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isComma():boolean",
            new int[]{712,-381,-891,-1000,737,174,-684,-304,-890,-1000,1000,436,-570,-1000,801,-1000,1000,337,120,47,-796,1000,911,-497,615,1000,323,-1000,-590,-1000,382,-67,-439,140,289,-222,585,-580,-681,748,-913,-416,-280,-963,-451,1000,-565,-60,-85,-903,-458,859,1000,-1000,-471,901,-204,570,-647,795,706,641,254,477}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01071() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isComma():boolean",
            new int[]{978,749,-547,-400,-728,857,839,-372,470,-824,349,-854,1000,-24,-538,1000,531,-699,-1000,414,24,1000,-6,866,217,-1000,-145,-72,-223,-1000,559,263,-1000,-994,1000,-120,-360,1000,1000,-1000,-859,1000,-1000,864,1000,496,37,-309,-68,947,-90,942,68,348,-348,1000,-526,-831,-209,805,778,-583,654,-167}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01072() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isComma():boolean",
            new int[]{920,889,-441,527,177,280,888,34,-376,-979,716,1000,41,-490,-873,1000,-920,-111,-432,717,-171,275,255,-99,-230,197,1000,-218,-217,-500,1000,69,-776,-1000,-926,-1000,900,-574,-180,-688,-998,-488,139,-970,1000,615,458,77,304,707,396,-76,-676,257,-716,-491,491,175,748,-59,-632,389,470,17}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01073() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isComma():boolean",
            new int[]{-647,-322,333,1000,-1000,99,111,-815,-21,-249,311,1000,-699,744,-373,-1000,948,-362,193,-329,-1000,-42,220,734,800,-1000,89,1000,1000,492,-273,251,531,877,513,469,-216,-1000,-298,-32,-172,-743,595,-338,-321,-1000,-292,163,988,6,733,-1000,-453,-138,-810,-410,656,-1000,574,579,602,1000,-82,447}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01074() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isComma():boolean",
            new int[]{258,124,-392,682,705,562,-159,-433,-714,-1000,871,-609,-638,-483,-425,-54,454,-540,-622,-523,-420,860,-652,995,1000,-459,338,-742,43,409,929,-187,-203,-13,-750,303,-543,709,398,1000,-998,-725,-259,-986,231,1000,1000,1000,796,195,570,-138,65,-362,-1000,-915,779,-447,815,-154,184,1000,237,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01075() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isComma():boolean",
            new int[]{677,-486,-484,425,8,1000,603,-1000,915,-1000,874,-239,-16,-1000,774,704,1000,1000,-547,946,-1000,1000,-529,1000,360,496,1000,-886,-1000,-1000,341,212,-1000,-26,1000,947,-448,1000,1000,-537,-972,1000,-1000,1000,633,673,-169,945,304,-567,-1000,72,-827,-649,-1000,1000,-62,-587,471,1000,1000,-1000,955,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01076() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isComma():boolean",
            new int[]{-543,-207,-259,108,766,-318,-86,-960,65,-921,601,841,-841,-13,641,-390,931,-458,475,-795,-842,-876,374,277,446,-222,72,4,624,-208,-770,118,-197,615,634,79,-99,-34,-695,805,-95,-85,826,219,-610,-979,-914,-922,-102,-799,-619,37,651,-133,-648,691,-218,137,-412,482,772,402,-100,-229}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01077() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isComma():boolean",
            new int[]{796,-701,947,-1000,1000,589,51,-683,-1000,-1000,1000,-349,-1000,-1000,1000,1000,-778,1000,875,-1000,-308,1000,-1000,51,108,1000,175,-1000,967,689,-117,-959,1000,255,-1000,146,1000,-1000,-1000,1000,-133,-611,627,-376,-1000,-89,-989,1000,1000,-1000,898,-1000,-247,-1000,-544,-28,1000,1000,-181,-613,-429,-374,-1000,-135}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01078() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isComma():boolean",
            new int[]{516,-161,-710,1000,-1000,793,1000,-138,1000,11,-184,-967,-1000,1000,-1000,1000,521,-961,-1000,894,9,188,1000,667,-12,-1000,482,1000,-254,-1000,-479,1000,-1000,-406,1000,1000,319,580,713,-1000,-608,98,-1000,1000,79,1000,-1000,-1000,-165,1000,-921,1000,-1000,1000,-761,388,-329,-895,34,1000,831,-1000,989,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01079() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isComma():boolean",
            new int[]{101,614,-364,-137,737,811,556,-1000,-377,-1000,1000,-1000,-818,-1000,801,871,1000,-967,-96,47,-259,1000,-1000,938,615,897,11,-1000,-1000,-806,1000,-1000,1000,-665,-1000,-222,527,1000,954,-129,-563,-106,-441,-963,201,261,1000,1000,1000,-366,-890,-915,62,-1000,-1000,-316,718,177,1000,-482,465,1000,254,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01080() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isContinue():boolean",
            new int[]{296,-466,707,1000,-685,-476,-868,121,-384,-910,37,609,-156,481,991,-784,743,-104,-37,-149,-140,1000,167,472,-1000,782,835,364,-765,92,259,-1000,321,-547,-676,794,3,-1000,-52,-950,-943,156,683,229,-650,-1000,469,-660,33,-1000,-602,433,47,-551,763,696,1000,-657,-754,1000,-458,-364,-1000,75}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01081() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isContinue():boolean",
            new int[]{-758,719,320,593,-990,343,-113,-375,1000,1000,-1000,-302,-571,124,8,940,-574,-1000,-267,783,-654,748,901,254,-1000,566,466,-200,-472,-284,-939,-324,183,402,-676,1000,527,-966,-633,-157,-255,672,-338,540,-1000,-1000,-923,608,377,93,-335,305,637,-792,-398,784,-1000,592,-114,1000,468,102,400,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01082() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isContinue():boolean",
            new int[]{-179,-186,-115,-1000,-1000,71,1000,-99,-1000,1000,1000,745,-359,-1000,-1000,-575,196,-201,-253,-420,-1000,912,344,-806,-1000,418,-1000,-32,940,333,994,427,1000,1000,-678,-978,-1000,508,1000,906,1000,-190,-351,323,-885,-531,-1000,359,-1000,-152,-692,938,-1000,-1000,1000,1000,1000,-660,688,464,-1000,516,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01083() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isContinue():boolean",
            new int[]{-158,-581,-421,-400,-977,-804,-192,-1000,741,-93,130,-621,323,148,154,948,-887,-235,239,405,794,104,1000,-9,656,244,68,-545,78,510,-698,-527,47,-578,-929,829,1000,491,-424,-137,-842,-275,1000,62,442,-120,-772,982,399,1000,1000,-469,-591,-640,-1000,891,-1000,471,-676,-1000,537,529,-307,563}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01084() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isContinue():boolean",
            new int[]{-777,-356,111,1000,-949,520,-474,-929,62,-794,-251,-111,257,623,461,559,-604,-84,-457,1000,354,504,596,-151,-307,1000,554,357,-4,-1000,-7,-241,-1000,-294,-1000,373,-233,-965,572,3,-534,824,15,856,232,-1000,156,-141,396,746,-1000,264,-736,-1000,114,954,-931,-517,312,-663,144,-1000,-872,356}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01085() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isContinue():boolean",
            new int[]{965,-756,-1000,-1000,-913,-85,1000,-853,-688,501,-59,-255,350,-1000,-564,-886,-147,44,-37,-1000,-1000,1000,990,-726,260,66,835,482,1000,766,-71,105,1000,-162,-594,292,3,1000,-389,752,-66,-1000,683,-688,-347,-200,-743,926,-1000,679,779,990,-351,-28,304,1000,858,-657,-754,1000,-458,-507,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01086() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isContinue():boolean",
            new int[]{421,-886,-902,-481,-420,24,145,-1000,793,485,-28,466,956,-616,-58,-424,-79,-51,663,-1000,-1000,-1000,496,-856,42,779,-1000,-321,-404,957,179,-747,-326,-911,1000,677,55,985,-1000,-196,-953,-515,-157,-538,-93,-312,-480,-1000,-1000,1000,825,383,1000,-325,414,853,-109,-16,64,654,814,15,656,-388}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01087() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isContinue():boolean",
            new int[]{244,308,-714,1000,-491,-355,804,237,-637,474,615,597,-57,-529,-393,-267,-349,-1000,-204,-400,-1000,1000,561,104,924,-194,-621,598,118,400,195,-541,659,-129,-345,52,-51,400,169,322,760,-194,-1,-40,-599,400,-572,-311,-238,-754,409,793,-134,-383,559,354,1000,-290,336,1000,-1000,204,-914,-400}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01088() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isContinue():boolean",
            new int[]{358,-587,-1000,247,-769,-374,904,-809,563,-129,-1000,163,-359,307,-977,-1000,509,-426,-529,-155,761,594,278,-632,1000,-96,-106,87,-408,147,-332,-656,-279,-518,658,1000,1000,802,-1000,-795,-1000,-970,1000,-1000,-372,-714,-409,-547,-164,1000,729,-75,1000,-1000,-1000,-336,926,29,-945,-846,285,1000,448,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01089() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isContinue():boolean",
            new int[]{965,-706,-817,-676,-984,-746,265,-432,-506,340,-628,269,261,-359,-213,-853,488,-266,-57,-826,-76,129,342,-943,-720,443,-230,238,-240,979,-332,-656,58,-397,291,870,795,802,-722,-459,-735,-367,587,-710,-372,-72,-563,70,-773,534,814,823,599,-353,-577,846,901,-622,-495,519,-10,548,-117,-81}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01090() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isContinue():boolean",
            new int[]{-1000,438,-98,935,-438,1000,-275,-170,763,-221,-43,417,-1000,686,460,1000,-746,-1000,-754,1000,171,483,-46,260,204,98,291,1000,-316,-1000,869,-474,97,1000,-667,-383,-51,-1000,1000,220,174,224,-1000,819,-806,-1000,163,-681,291,-776,-175,-812,21,-1000,167,665,697,-372,696,-88,-1000,812,-193,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01091() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isContinue():boolean",
            new int[]{-1000,-411,-298,-24,-1000,1000,-534,-1000,1000,1000,-448,835,-80,-769,-297,1000,1000,-386,789,328,502,-167,163,181,-1000,785,-413,687,-435,608,997,-193,-367,31,957,-263,-684,-520,-564,905,-1000,986,-165,-61,-1000,224,-604,-1000,-718,789,-950,969,1000,434,-1000,1000,-16,606,718,1000,947,-599,708,-611}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01092() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isContinue():boolean",
            new int[]{-255,-482,850,346,-1000,-1000,322,-482,-737,-304,-131,-59,532,650,-648,208,-1000,1000,809,-1000,-70,1000,1000,404,1000,1000,1000,-389,-732,-311,-1000,-703,-559,-1000,-898,920,-394,626,748,45,13,62,1000,1000,1000,1000,-743,-392,228,938,-49,1000,-1000,-188,28,-697,-397,-980,629,-697,188,-1000,-1000,79}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01093() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isContinue():boolean",
            new int[]{-777,-936,320,124,-397,638,-166,-929,896,864,-114,654,257,-337,-385,561,215,266,655,-759,556,9,539,-151,-380,981,-76,751,-216,252,-171,15,-714,-419,752,235,-914,547,-408,-354,-538,824,621,8,232,998,-604,-997,-920,746,-505,998,313,459,-806,954,-425,-517,821,-31,525,-999,-588,-490}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01094() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isContinue():boolean",
            new int[]{-82,-756,869,1000,-1000,-812,-500,-474,-1000,-766,-523,534,724,217,614,-1000,155,448,344,-149,-532,653,890,-334,-515,848,523,1000,-415,92,-446,-469,71,-888,-676,944,-255,-976,112,-475,-715,237,-417,128,-84,-1000,-121,-656,-390,152,-602,1000,-514,-1000,152,663,600,-1000,-341,415,179,-509,-936,-376}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE01095() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "com.google.javascript.rhino.Node", "com.google.javascript.rhino.Node", "isContinue():boolean",
            new int[]{-1000,-3,-714,46,-769,941,904,-653,1000,781,-103,163,-1000,238,-977,912,-1000,-1000,-335,952,157,-612,338,-632,1000,212,-15,604,-92,-1000,47,452,-622,979,-1000,-274,903,151,1000,1000,918,143,-686,228,-127,-1000,-1000,-140,221,792,-633,-944,-715,-1000,-666,709,32,1000,829,-846,-991,899,288,595}));
    }
}
