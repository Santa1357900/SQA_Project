import java.lang.reflect.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Deterministic test-program decoder. Used unchanged during search and JUnit replay. */
final class DEReplay {
    public static final int DIMENSIONS = 64;
    /** Local generic bean used to create stable reflection Type and Field values. */
    public static final class GenericInput {
        public String text;
        public java.util.List<String> names;
        public java.util.Map<String, Integer> counts;
        public java.util.List<java.util.Map<String, Long>> nested;
        public int[] numbers;
        public String[] words;
    }
    static final class Genes {
        final int[] values; int at; Field lastField;
        Object jacksonBean, jacksonProvider, jacksonGenerator;
        StringWriter jacksonOutput;
        Genes(int[] values) { this.values = values; }
        int next() { return values[(at++) % values.length]; }
        int pick(int n) { return Math.floorMod(next(), n); }
    }
    public static final class Observation {
        public String token, error, generatedSource;
        public boolean reachedTarget;
        public int setupCalls, setupFailures, nullFallbacks;
    }
    public static String signature(Method m) {
        StringJoiner params = new StringJoiner(",");
        for (Class<?> t : m.getParameterTypes()) params.add(t.getTypeName());
        return m.getName() + "(" + params + "):" + m.getReturnType().getTypeName();
    }
    static Class<?> load(String name) throws ClassNotFoundException {
        return Class.forName(name, true, Thread.currentThread().getContextClassLoader());
    }
    static Method method(String target, String signature) throws Exception {
        for (Method m : load(target).getDeclaredMethods())
            if (signature(m).equals(signature)) {
                // Public methods on package-private Defects4J classes (for
                // example Gson's TypeInfoFactory) are not reflectively
                // accessible until opened on the unnamed application module.
                if (!m.isAccessible()) m.setAccessible(true);
                return m;
            }
        throw new NoSuchMethodException(signature);
    }
    static List<Constructor<?>> constructors(Class<?> type) {
        List<Constructor<?>> out = new ArrayList();
        if (!Modifier.isAbstract(type.getModifiers()) && Modifier.isPublic(type.getModifiers()))
            for (Constructor<?> c : type.getConstructors())
                if (c.getParameterTypes().length <= 6) out.add(c);
        Collections.sort(out, new Comparator<Constructor<?>>() {
            public int compare(Constructor<?> a, Constructor<?> b) {
                int byArity = a.getParameterTypes().length - b.getParameterTypes().length;
                return byArity != 0 ? byArity : a.toString().compareTo(b.toString());
            }
        });
        return out;
    }
    private static Object[] arguments(Class<?>[] types, Genes g, int depth,
                                      Observation report) throws Exception {
        Object[] args = new Object[types.length];
        for (int i = 0; i < types.length; i++) args[i] = value(types[i], g, depth, report);
        return args;
    }
    private static Object[] arguments(Method method, Genes g, int depth,
                                      Observation report) throws Exception {
        Class<?>[] types = method.getParameterTypes();
        Object[] args = new Object[types.length];
        boolean closureCompile = method.getDeclaringClass().getName().equals("com.google.javascript.jscomp.Compiler")
            && method.getName().equals("compile");
        Type[] generic = method.getGenericParameterTypes();
        boolean jacksonSerialization = method.getDeclaringClass().getName().equals(
            "com.fasterxml.jackson.databind.ser.BeanPropertyWriter")
            && method.getName().startsWith("serializeAs")
            && types.length == 3 && types[0] == Object.class;
        for (int i = 0; i < types.length; i++) {
            if (jacksonSerialization && g.jacksonBean != null) {
                if (i == 0) args[i] = g.jacksonBean;
                else if (i == 1) args[i] = g.jacksonGenerator;
                else args[i] = g.jacksonProvider;
                continue;
            }
            if (closureCompile && (List.class.isAssignableFrom(types[i])
                    || (types[i].isArray() && load("com.google.javascript.jscomp.SourceFile")
                        .isAssignableFrom(types[i].getComponentType())))) {
                // Compiler.compile takes externs and inputs in either Lists or
                // arrays depending on Closure version. Keep externs empty and
                // supply a nonempty, gene-selected input program.
                if (i == 0) args[i] = types[i].isArray()
                    ? Array.newInstance(types[i].getComponentType(), 0) : new ArrayList();
                else {
                    Object sourceFile = value(load("com.google.javascript.jscomp.SourceFile"),
                        g, depth + 1, report);
                    if (types[i].isArray()) {
                        Object files = Array.newInstance(types[i].getComponentType(), 1);
                        Array.set(files, 0, sourceFile); args[i] = files;
                    } else args[i] = new ArrayList(Collections.singletonList(sourceFile));
                }
            } else args[i] = value(types[i], g, depth, report);
        }
        return args;
    }
    private static Number number(Genes g) {
        int n = g.next();
        switch (g.pick(12)) {
            case 0: return 0; case 1: return 1; case 2: return -1;
            case 3: return Integer.MAX_VALUE; case 4: return Integer.MIN_VALUE;
            case 5: return Long.MAX_VALUE; case 6: return Long.MIN_VALUE;
            case 7: return Double.NaN; case 8: return Double.POSITIVE_INFINITY;
            case 9: return Double.NEGATIVE_INFINITY; case 10: return n / 10.0;
            default: return n;
        }
    }
    private static String string(Genes g) {
        int mode = g.pick(16), n = g.next();
        String digits = Long.toString(Math.abs((long)n));
        String sign = new String[]{"", "-", "+", "--"}[g.pick(4)];
        switch (mode) {
            case 0: return null; case 1: return ""; case 2: return " ";
            case 3: return Integer.toString(n);
            case 4: return sign + digits;
            case 5: return sign + digits + "." + g.pick(1000);
            case 6: return sign + digits + "e" + g.next();
            case 7: return sign + "0x" + Long.toHexString(Math.abs((long)n));
            case 8: return sign + "0x8" + "0".repeat(g.pick(20));
            case 9: return sign + digits + "fFdDlL".charAt(g.pick(6));
            case 10: return " " + sign + digits + " ";
            case 11: return new String[]{"true", "false", "null", "NaN", "Infinity"}[g.pick(5)];
            case 12: return "a".repeat(g.pick(25));
            default:
                String alphabet = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ+-._ /\\\t\n";
                StringBuilder s = new StringBuilder();
                int length = g.pick(25);
                for (int i = 0; i < length; i++) s.append(alphabet.charAt(g.pick(alphabet.length())));
                return s.toString();
        }
    }
    private static Object value(Class<?> t, Genes g, int depth, Observation report) throws Exception {
        if (t == String.class || t == CharSequence.class) return string(g);
        if (t == Comparable.class) return "key" + g.pick(5);
        if (t == boolean.class || t == Boolean.class) return g.pick(2) == 0;
        if (t == char.class || t == Character.class) return (char)g.pick(128);
        if (t == byte.class || t == Byte.class) return number(g).byteValue();
        if (t == short.class || t == Short.class) return number(g).shortValue();
        if (t == int.class || t == Integer.class) return number(g).intValue();
        if (t == long.class || t == Long.class) return number(g).longValue();
        if (t == float.class || t == Float.class) return number(g).floatValue();
        if (t == double.class || t == Double.class || t == Number.class) return number(g).doubleValue();
        if (t.isEnum()) {
            Object[] constants = t.getEnumConstants();
            return constants.length == 0 ? null : constants[g.pick(constants.length)];
        }
        if (t == Object.class) return g.pick(3) == 0 ? null : "object" + g.pick(5);
        if (depth >= 3) { report.nullFallbacks++; return null; }
        if (t.isArray()) {
            int length = g.pick(6);
            Object array = Array.newInstance(t.getComponentType(), length);
            for (int i = 0; i < length; i++) Array.set(array, i, value(t.getComponentType(), g, depth + 1, report));
            return array;
        }
        if (t == List.class || t == Collection.class || t == Iterable.class || t == Set.class) {
            Collection<Object> items = t == Set.class ? new LinkedHashSet() : new ArrayList();
            int size = g.pick(5);
            for (int i = 0; i < size; i++) items.add("item" + g.pick(5));
            return items;
        }
        if (t == Map.class) {
            Map<Object, Object> items = new LinkedHashMap();
            int size = g.pick(5);
            for (int i = 0; i < size; i++) items.put("key" + g.pick(5), number(g));
            return items;
        }
        if (t == java.util.Date.class) return new java.util.Date(g.next() * 86400000L);
        if (t == Class.class) return String.class;
        if (t == java.lang.reflect.Field.class) {
            Field[] fields = GenericInput.class.getFields();
            g.lastField = fields[g.pick(fields.length)];
            return g.lastField;
        }
        if (t == java.lang.reflect.Type.class) {
            if (g.lastField != null && g.pick(3) == 0)
                return g.lastField.getDeclaringClass();
            Field[] fields = GenericInput.class.getFields();
            return fields[g.pick(fields.length)].getGenericType();
        }
        if (t == java.io.Reader.class || t == java.io.BufferedReader.class
                || t == java.io.StringReader.class) {
            String content = "header,value\n" + string(g) + "," + number(g) + "\n"
                + "alpha,beta\n";
            StringReader reader = new StringReader(content);
            return t == java.io.BufferedReader.class ? new BufferedReader(reader) : reader;
        }
        if (t.getName().equals("org.apache.commons.csv.CSVFormat")) {
            Class<?> format = load("org.apache.commons.csv.CSVFormat");
            for (String fieldName : new String[]{"DEFAULT", "RFC4180", "EXCEL"}) try {
                Object result = format.getField(fieldName).get(null);
                if (t.isInstance(result)) return result;
            } catch (ReflectiveOperationException ignored) { }
            for (Method factory : format.getMethods())
                if (Modifier.isStatic(factory.getModifiers()) && factory.getParameterTypes().length == 0
                        && t.isAssignableFrom(factory.getReturnType())) try {
                    return factory.invoke(null);
                } catch (ReflectiveOperationException ignored) { }
        }
        if (t.getName().equals("com.google.javascript.jscomp.SourceFile")) {
            Class<?> source = load("com.google.javascript.jscomp.SourceFile");
            for (Method factory : source.getMethods())
                if (Modifier.isStatic(factory.getModifiers()) && factory.getName().equals("fromCode")
                        && factory.getParameterTypes().length == 2 && factory.getParameterTypes()[0] == String.class
                        && factory.getParameterTypes()[1] == String.class) {
                    String replaySource = System.getProperty("de.generated.source");
                    if (replaySource != null) {
                        try {
                            report.generatedSource = replaySource;
                            return factory.invoke(null, "de-input.js", replaySource);
                        } catch (ReflectiveOperationException ignored) { }
                    }
                    String[] unusedParameterScripts = {
                        "window.f = function(a) {};",
                        "window.f = function(a, b) { return b; };",
                        "window.f = function(a, b) { var used = b; return used; };",
                        "window['f'] = function(unused) {};",
                        "window.f = function(unused, value) { return value; };",
                        "window['f'] = function(unused, value) { return value; };",
                        "window.f = function(first, unused, last) { return last; };",
                        "window.f = function(unused) { var local = 1; return local; };",
                        "window.f = function(unused, value) { var alias = value; return alias; };",
                        "window.f = function(unused, value) { if (value) { return 1; } return 2; };",
                        "window.f = function(unused, value) { value = value + 1; return value; };",
                        "window.f = function(unused, value) { return function() { return value; }; };",
                        "window.f = function(unused) { function inner() { return 1; } return inner(); };",
                        "window.f = function(a, b, unused) { return a + b; };",
                        "window.f = function(a, unused, b, c) { return a + c; };"
                    };
                    String[] catchDependencyScripts = {
                        "window.f = function() { var saved; try { throw Error('x'); } catch (caught) { saved = caught; } return saved.stack; };",
                        "window.f = function(flag) { var saved; try { if (flag) throw Error('x'); } catch (caught) { saved = caught; } return saved.message; };",
                        "window.f = function() { var saved; try { throw Error('x'); } catch (caught) { saved = caught; } return saved.name; };",
                        "window.f = function() { var saved; try { throw Error('x'); } catch (caught) { saved = caught; } return String(saved); };",
                        "window.f = function(flag) { var saved; try { if (flag) throw Error('x'); } catch (problem) { saved = problem; } return saved.stack; };",
                        "window.f = function() { var saved; try { throw Error('x'); } catch (problem) { saved = problem; } return saved.message; };"
                    };
                    String[] genericScripts = {
                        "function f(unused, used) { var local = 1; return used; } f(1, 2);",
                        "function f() { var unused = 1; var used = 2; return used; } f();",
                        "function f(x) { var first = x; first = 3; return x; } f(2);",
                        "function f() { var unused = 1; } f();",
                        "function keep() { var dead = 1; return 7; } keep();"
                    };
                    String modified = System.getProperty("de.modified.classes", "");
                    String[] scripts;
                    if (modified.contains("RemoveUnusedVars") && modified.contains("FlowSensitiveInlineVariables")) {
                        scripts = new String[unusedParameterScripts.length + catchDependencyScripts.length];
                        System.arraycopy(unusedParameterScripts, 0, scripts, 0, unusedParameterScripts.length);
                        System.arraycopy(catchDependencyScripts, 0, scripts, unusedParameterScripts.length,
                            catchDependencyScripts.length);
                    }
                    else if (modified.contains("FlowSensitiveInlineVariables")) scripts = catchDependencyScripts;
                    else if (modified.contains("RemoveUnusedVars")) scripts = unusedParameterScripts;
                    else scripts = genericScripts;
                    try {
                        String code = scripts[g.pick(scripts.length)];
                        report.generatedSource = code;
                        return factory.invoke(null, "de-input.js", code);
                    }
                    catch (ReflectiveOperationException ignored) { }
                }
        }
        if (t.getName().equals("com.google.javascript.jscomp.CompilerOptions")) {
            try {
                Object options = t.getConstructor().newInstance();
                // In Closure Compiler, unused-variable passes are enabled by
                // CompilationLevel, rather than by a CompilerOptions enum
                // setter. Apply the real public configuration when available.
                try {
                    Class<?> levelType = load("com.google.javascript.jscomp.CompilationLevel");
                    Object advanced = levelType.getField("ADVANCED_OPTIMIZATIONS").get(null);
                    for (Method configure : levelType.getMethods())
                        if (configure.getName().equals("setOptionsForCompilationLevel")
                                && configure.getParameterTypes().length == 1
                                && configure.getParameterTypes()[0].isInstance(options)) {
                            configure.invoke(advanced, options); break;
                        }
                } catch (ReflectiveOperationException ignored) { }
                // Also set the relevant options directly for Closure releases
                // whose compilation-level helper no longer enables this pass.
                for (Class<?> current = t; current != null; current = current.getSuperclass())
                    for (Field field : current.getDeclaredFields()) {
                        String name = field.getName().toLowerCase(Locale.ROOT);
                        if (field.getType() == boolean.class && name.equals("removeglobals")) try {
                            // Closure-1 specifically guards argument removal
                            // when globals are preserved. Keep the optimization
                            // pass enabled while exercising that configuration.
                            field.setAccessible(true); field.setBoolean(options, false);
                        } catch (Exception ignored) { }
                        if (field.getType() == boolean.class
                                && (name.contains("removeunusedvar") || name.contains("removeunusedlocal"))) try {
                            field.setAccessible(true); field.setBoolean(options, true);
                        } catch (Exception ignored) { }
                    }
                for (Method setter : t.getMethods()) {
                    if (!Modifier.isPublic(setter.getModifiers()) || !setter.getName().startsWith("set")
                            || setter.getParameterTypes().length != 1) continue;
                    String name = setter.getName().toLowerCase(Locale.ROOT);
                    if (setter.getParameterTypes()[0] == boolean.class && name.contains("removeglobals")) {
                        try { setter.invoke(options, false); } catch (ReflectiveOperationException ignored) { }
                    } else if (setter.getParameterTypes()[0] == boolean.class
                            && (name.contains("removeunusedvar") || name.contains("removeunusedlocal"))) {
                        try { setter.invoke(options, true); } catch (ReflectiveOperationException ignored) { }
                    } else if (name.contains("optimizationlevel")
                            && setter.getParameterTypes()[0].isEnum()) {
                        Object[] values = setter.getParameterTypes()[0].getEnumConstants();
                        for (Object value : values) if (String.valueOf(value).contains("ADVANCED"))
                            try { setter.invoke(options, value); } catch (ReflectiveOperationException ignored) { }
                    }
                }
                return options;
            } catch (ReflectiveOperationException ignored) { }
        }
        if (t.getName().equals("com.google.javascript.rhino.Node")) {
            try {
                Class<?> ir = load("com.google.javascript.rhino.IR");
                for (String factoryName : new String[]{"script", "root", "name", "string"})
                    for (Method factory : ir.getMethods())
                        if (Modifier.isStatic(factory.getModifiers()) && factory.getName().equals(factoryName)
                                && factory.getParameterTypes().length == 0 && t.isAssignableFrom(factory.getReturnType()))
                            return factory.invoke(null);
            } catch (ReflectiveOperationException ignored) { }
        }
        if (t.getName().equals("com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser")) {
            Object parser = xmlParser(g, report);
            if (parser != null && t.isInstance(parser)) return parser;
        }
        if (t.getName().equals("com.fasterxml.jackson.databind.ser.BeanPropertyWriter")
                || t.getName().equals("com.fasterxml.jackson.databind.ser.impl.UnwrappingBeanPropertyWriter")) {
            Object writer = jacksonWriter(t, g, report);
            if (writer != null && t.isInstance(writer)) return writer;
        }
        if (t == java.awt.Graphics2D.class || t == java.awt.Graphics.class)
            return new java.awt.image.BufferedImage(80, 80, java.awt.image.BufferedImage.TYPE_INT_ARGB).createGraphics();
        if (java.awt.Paint.class.isAssignableFrom(t)) {
            java.awt.Color c = new java.awt.Color(g.pick(256), g.pick(256), g.pick(256));
            if (t.isInstance(c)) return c;
        }
        if (java.awt.Stroke.class.isAssignableFrom(t)) {
            java.awt.BasicStroke s = new java.awt.BasicStroke(g.pick(10) / 2.0f);
            if (t.isInstance(s)) return s;
        }
        if (java.awt.Shape.class.isAssignableFrom(t)) {
            java.awt.Shape s = new java.awt.geom.Rectangle2D.Double(g.next(), g.next(), g.pick(80), g.pick(80));
            if (t.isInstance(s)) return s;
        }
        if (t == java.awt.geom.Point2D.class) return new java.awt.geom.Point2D.Double(g.next(), g.next());
        if (t.getName().equals("org.apache.commons.cli.CommandLine"))
            return commandLine(g, report);
        Object domain = chart(t, g, report);
        if (domain != null) return domain;
        Object language = language(t, g, report);
        if (language != null) return language;
        List<Constructor<?>> ctors = constructors(t);
        // Older Java libraries often use public singleton constants in place of enums.
        if (ctors.isEmpty()) {
            List<Field> constants = new ArrayList();
            for (Field field : t.getFields())
                if (Modifier.isStatic(field.getModifiers()) && Modifier.isFinal(field.getModifiers())
                        && t.isAssignableFrom(field.getType())) constants.add(field);
            Collections.sort(constants, new Comparator<Field>() {
                public int compare(Field a, Field b) { return a.getName().compareTo(b.getName()); }
            });
            if (!constants.isEmpty()) {
                Object constant = constants.get(g.pick(constants.size())).get(null);
                if (constant != null) return constant;
            }
        }
        if (!ctors.isEmpty()) {
            Constructor<?> ctor = ctors.get(g.pick(ctors.size()));
            try { return ctor.newInstance(arguments(ctor.getParameterTypes(), g, depth + 1, report)); }
            catch (Exception ignored) { }
        }
        report.nullFallbacks++;
        return null;
    }
    private static Object language(Class<?> t, Genes g, Observation report) {
        if (!t.getName().equals("org.apache.commons.lang3.time.FastDateFormat")) return null;
        try {
            Method factory = t.getMethod("getInstance", String.class, java.util.TimeZone.class,
                java.util.Locale.class);
            String[] patterns = {"yyyy-MM-dd", "MM/dd/yy HH:mm:ss", "EEE, d MMM yyyy HH:mm:ss Z"};
            return factory.invoke(null, patterns[g.pick(patterns.length)],
                java.util.TimeZone.getTimeZone("UTC"), java.util.Locale.US);
        } catch (ReflectiveOperationException ignored) { }
        try { return t.getMethod("getInstance", String.class).invoke(null, "yyyy-MM-dd"); }
        catch (ReflectiveOperationException ignored) { return null; }
    }
    private static Object xmlParser(Genes g, Observation report) {
        try {
            Class<?> factoryType = load("com.fasterxml.jackson.dataformat.xml.XmlFactory");
            Object factory = factoryType.getConstructor().newInstance();
            String[] docs = {"<root><value>1</value><name>x</name></root>",
                "<root value=\"42\"><item>a</item><item>b</item></root>",
                "<root/>"};
            String xml = docs[g.pick(docs.length)];
            for (Method method : factoryType.getMethods()) {
                if (!method.getName().equals("createParser") || method.getParameterTypes().length != 1) continue;
                Class<?> p = method.getParameterTypes()[0];
                Object input = p == String.class ? xml : p == Reader.class ? new StringReader(xml)
                    : p == InputStream.class ? new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8)) : null;
                if (input == null) continue;
                try {
                    Object parser = method.invoke(factory, input);
                    if (parser != null) {
                        int advance = g.pick(4);
                        Method next = parser.getClass().getMethod("nextToken");
                        for (int i = 0; i < advance; i++) if (next.invoke(parser) == null) break;
                        return parser;
                    }
                } catch (ReflectiveOperationException ignored) { }
            }
        } catch (Throwable ignored) { }
        return null;
    }
    private static Object jacksonWriter(Class<?> requested, Genes g, Observation report) {
        try {
            Class<?> mapperType = load("com.fasterxml.jackson.databind.ObjectMapper");
            Object mapper = mapperType.getConstructor().newInstance();
            Object bean = new GenericInput();
            Class<?> javaTypeType = load("com.fasterxml.jackson.databind.JavaType");
            Object javaType = mapperType.getMethod("constructType", Type.class).invoke(mapper, bean.getClass());
            // Jackson 2.6 (used by this Defects4J project) exposes a provider
            // blueprint from ObjectMapper. Create a configured provider via
            // DefaultSerializerProvider, the supported API used by ObjectMapper.
            Object providerBlueprint = mapperType.getMethod("getSerializerProvider").invoke(mapper);
            Class<?> serializationConfigType = load("com.fasterxml.jackson.databind.SerializationConfig");
            Class<?> serializerFactoryType = load("com.fasterxml.jackson.databind.ser.SerializerFactory");
            Object config = mapperType.getMethod("getSerializationConfig").invoke(mapper);
            Object factory = mapperType.getMethod("getSerializerFactory").invoke(mapper);
            Class<?> defaultProviderType = load("com.fasterxml.jackson.databind.ser.DefaultSerializerProvider");
            Method createProvider = defaultProviderType.getMethod("createInstance",
                serializationConfigType, serializerFactoryType);
            Object provider = createProvider.invoke(providerBlueprint, config, factory);
            g.jacksonBean = bean;
            g.jacksonProvider = provider;
            g.jacksonOutput = new StringWriter();
            Object jsonFactory = mapperType.getMethod("getFactory").invoke(mapper);
            for (String factoryMethod : new String[]{"createGenerator", "createJsonGenerator"}) {
                try {
                    Method createGenerator = jsonFactory.getClass().getMethod(factoryMethod, Writer.class);
                    g.jacksonGenerator = createGenerator.invoke(jsonFactory, g.jacksonOutput);
                    break;
                } catch (NoSuchMethodException ignored) { }
            }
            if (g.jacksonGenerator == null)
                throw new NoSuchMethodException("JsonFactory.createGenerator(Writer) or createJsonGenerator(Writer)");
            Class<?> providerType = load("com.fasterxml.jackson.databind.SerializerProvider");
            Class<?> beanPropertyType = load("com.fasterxml.jackson.databind.BeanProperty");
            Method find = providerType.getMethod("findValueSerializer", javaTypeType, beanPropertyType);
            Object serializer = find.invoke(provider, new Object[]{javaType, null});
            List<Object> writers = new ArrayList();
            try {
                // Available on Jackson 2.6 and newer.
                Class<?> serializerType = load("com.fasterxml.jackson.databind.JsonSerializer");
                Method properties = serializerType.getMethod("properties");
                Iterator<?> it = (Iterator<?>)properties.invoke(serializer);
                while (it.hasNext()) {
                    Object item = it.next();
                    if (item != null && item.getClass().getName().endsWith("BeanPropertyWriter"))
                        writers.add(item);
                }
            } catch (NoSuchMethodException oldJackson) {
                // JacksonDatabind-1 predates JsonSerializer.properties(). Its
                // BeanSerializerBase stores writers in the protected _props
                // array; read that array only for these old releases.
                Class<?> base = load("com.fasterxml.jackson.databind.ser.std.BeanSerializerBase");
                if (!base.isInstance(serializer))
                    throw new IllegalStateException("Expected BeanSerializerBase, got "
                        + serializer.getClass().getName(), oldJackson);
                Field props = base.getDeclaredField("_props");
                props.setAccessible(true);
                Object array = props.get(serializer);
                for (int i = 0; i < Array.getLength(array); i++) {
                    Object item = Array.get(array, i);
                    if (item != null && item.getClass().getName().endsWith("BeanPropertyWriter"))
                        writers.add(item);
                }
            }
            if (writers.isEmpty())
                throw new IllegalStateException("ObjectMapper produced no bean property writers for DEReplay.GenericInput");
            Object writer = writers.get(g.pick(writers.size()));
            boolean requireUnwrapping = requested.getName().equals(
                "com.fasterxml.jackson.databind.ser.impl.UnwrappingBeanPropertyWriter");
            if (!requireUnwrapping && g.pick(2) == 0 && requested.isInstance(writer)) return writer;
            Class<?> transformerType = load("com.fasterxml.jackson.databind.util.NameTransformer");
            Object nop = transformerType.getField("NOP").get(null);
            for (Method m : writer.getClass().getMethods())
                if (m.getName().equals("unwrappingWriter") && m.getParameterTypes().length == 1
                        && m.getParameterTypes()[0].isInstance(nop)) {
                    Object unwrapped = m.invoke(writer, nop);
                    if (requested.isInstance(unwrapped)) return unwrapped;
                }
            if (requested.isInstance(writer)) return writer;
            throw new IllegalStateException("Generated Jackson property writer is not " + requested.getName());
        } catch (Throwable failure) {
            throw new IllegalStateException("Cannot construct Jackson BeanPropertyWriter: " + failure, failure);
        }
    }
    /** Build the non-constructible Commons CLI result through its public Parser API. */
    private static Object commandLine(Genes g, Observation report) throws Exception {
        Class<?> optionsClass = load("org.apache.commons.cli.Options");
        Class<?> optionClass = load("org.apache.commons.cli.Option");
        Class<?> parserClass = load("org.apache.commons.cli.PosixParser");
        Object options = optionsClass.getConstructor().newInstance();
        Method addOption = optionsClass.getMethod("addOption", optionClass);
        int numberOfOptions = 1 + g.pick(3);
        List<String> spellings = new ArrayList();
        for (int i = 0; i < numberOfOptions; i++) {
            String shortName = String.valueOf((char)('a' + i));
            String longName = "de-option-" + i;
            boolean hasArgument = g.pick(2) == 0;
            Object option = null;
            try {
                option = optionClass.getConstructor(String.class, String.class, boolean.class, String.class)
                    .newInstance(shortName, longName, hasArgument, "DE-generated option");
            } catch (NoSuchMethodException ignored) { }
            if (option == null) try {
                option = optionClass.getConstructor(String.class, boolean.class, String.class)
                    .newInstance(shortName, hasArgument, "DE-generated option");
            } catch (NoSuchMethodException ignored) { }
            if (option == null) throw new NoSuchMethodException("No supported Commons CLI Option constructor");
            addOption.invoke(options, option);
            spellings.add("-" + shortName);
            if (hasArgument) spellings.add("value-" + Math.abs((long)g.next()));
        }
        String[] argv = spellings.toArray(new String[0]);
        Object parser = parserClass.getConstructor().newInstance();
        List<Method> parseMethods = new ArrayList();
        for (Method candidate : parserClass.getMethods()) {
            Class<?>[] p = candidate.getParameterTypes();
            if (candidate.getName().equals("parse") && p.length >= 2 && p[0] == optionsClass
                    && p[1] == String[].class && candidate.getReturnType() == load("org.apache.commons.cli.CommandLine"))
                parseMethods.add(candidate);
        }
        Collections.sort(parseMethods, new Comparator<Method>() {
            public int compare(Method a, Method b) {
                return a.getParameterTypes().length - b.getParameterTypes().length;
            }
        });
        for (Method parse : parseMethods) {
            Object[] args = new Object[parse.getParameterTypes().length];
            Class<?>[] p = parse.getParameterTypes();
            args[0] = options; args[1] = argv;
            for (int i = 2; i < p.length; i++) {
                if (p[i] == boolean.class || p[i] == Boolean.class) args[i] = g.pick(2) == 0;
                else if (p[i] == java.util.Properties.class) args[i] = new java.util.Properties();
                else args[i] = value(p[i], g, 1, report);
            }
            try { return parse.invoke(parser, args); }
            catch (InvocationTargetException ignored) { }
        }
        throw new NoSuchMethodException("No successful public PosixParser.parse(Options,String[])");
    }
    /** Optional type recipes, shared across bugs; none contains a bug-specific expected answer. */
    private static Object chart(Class<?> t, Genes g, Observation report) throws Exception {
        String n = t.getName();
        if (!n.startsWith("org.jfree.")) return null;
        if (n.equals("org.jfree.data.Range")) {
            double a = g.next(), b = g.next();
            return t.getConstructor(double.class, double.class).newInstance(Math.min(a, b), Math.max(a, b));
        }
        if (n.equals("org.jfree.data.time.RegularTimePeriod"))
            return load("org.jfree.data.time.Day").getConstructor(int.class, int.class, int.class)
                .newInstance(1 + g.pick(28), 1 + g.pick(12), 1990 + g.pick(40));
        if (n.equals("org.jfree.data.time.TimeSeries")) {
            Object series = t.getConstructor(Comparable.class).newInstance("DE");
            Class<?> period = load("org.jfree.data.time.RegularTimePeriod");
            Constructor<?> day = load("org.jfree.data.time.Day")
                .getConstructor(int.class, int.class, int.class);
            Method add = t.getMethod("add", period, double.class);
            int count = 2 + g.pick(4), year = 1990 + g.pick(40);
            for (int i = 0; i < count; i++)
                add.invoke(series, day.newInstance(i + 1, 1, year), g.next() / 10.0);
            return series;
        }
        if (n.equals("org.jfree.data.category.CategoryDataset")
                || n.equals("org.jfree.data.category.DefaultCategoryDataset")) {
            Class<?> c = load("org.jfree.data.category.DefaultCategoryDataset");
            Object data = c.getConstructor().newInstance();
            Method add = c.getMethod("addValue", Number.class, Comparable.class, Comparable.class);
            int rows = 1 + g.pick(3), columns = 1 + g.pick(3);
            for (int r = 0; r < rows; r++) for (int col = 0; col < columns; col++)
                add.invoke(data, Double.valueOf(g.next() / 10.0), "R" + r, "C" + col);
            return data;
        }
        if (n.equals("org.jfree.data.xy.XYDataset") || n.equals("org.jfree.data.xy.XYSeriesCollection")) {
            Class<?> seriesClass = load("org.jfree.data.xy.XYSeries");
            Object series = seriesClass.getConstructor(Comparable.class).newInstance("DE");
            int count = 1 + g.pick(5);
            for (int i = 0; i < count; i++) seriesClass.getMethod("add", double.class, double.class)
                .invoke(series, (double)i, g.next() / 10.0);
            Class<?> c = load("org.jfree.data.xy.XYSeriesCollection");
            Object data = c.getConstructor().newInstance();
            c.getMethod("addSeries", seriesClass).invoke(data, series);
            return data;
        }
        if (n.equals("org.jfree.data.general.PieDataset") || n.equals("org.jfree.data.general.DefaultPieDataset")) {
            Class<?> c = load("org.jfree.data.general.DefaultPieDataset");
            Object data = c.getConstructor().newInstance();
            int count = 1 + g.pick(5);
            for (int i = 0; i < count; i++) c.getMethod("setValue", Comparable.class, Number.class)
                .invoke(data, "K" + i, Double.valueOf(g.next() / 10.0));
            return data;
        }
        return null;
    }
    static List<Method> setupMethods(Class<?> receiver) {
        List<Method> methods = new ArrayList();
        for (Method m : receiver.getMethods()) {
            String n = m.getName();
            if (!Modifier.isStatic(m.getModifiers()) && !m.isSynthetic()
                    && m.getParameterTypes().length <= 3 && !n.contains("Listener")
                    && (n.startsWith("set") || n.startsWith("add") || n.startsWith("update")
                        || n.startsWith("remove") || n.equals("clear"))) methods.add(m);
        }
        Collections.sort(methods, new Comparator<Method>() {
            public int compare(Method a, Method b) {
                return signature(a).compareTo(signature(b));
            }
        });
        return methods;
    }
    public static Observation execute(String target, String receivers, String signature, int[] genes) {
        Observation out = new Observation();
        try {
            Genes g = new Genes(genes);
            Method m = method(target, signature);
            Object receiver = null;
            if (!Modifier.isStatic(m.getModifiers())) {
                String[] choices = receivers.split(",");
                Class<?> receiverType = load(choices[g.pick(choices.length)]);
                receiver = value(receiverType, g, 0, out);
                if (receiver == null) throw new IllegalArgumentException("Receiver construction failed");
                // Compiler.compile owns a strict initialization sequence.
                // Random calls to its mutators before compilation can corrupt
                // state or spend the search budget on irrelevant setup.
                if (!receiverType.getName().equals("com.google.javascript.jscomp.Compiler")) {
                    List<Method> setup = setupMethods(receiverType);
                    int count = g.pick(5);
                    for (int i = 0; i < count && !setup.isEmpty(); i++) {
                        Method s = setup.get(g.pick(setup.size()));
                        try { s.invoke(receiver, arguments(s.getParameterTypes(), g, 0, out)); out.setupCalls++; }
                        catch (Exception e) { out.setupFailures++; }
                    }
                }
            }
            Object[] args = arguments(m, g, 0, out);
            out.reachedTarget = true;
            try {
                boolean jacksonSerialization = m.getDeclaringClass().getName().equals(
                    "com.fasterxml.jackson.databind.ser.BeanPropertyWriter")
                    && m.getName().startsWith("serializeAs") && g.jacksonGenerator != null;
                boolean arrayShape = m.getName().contains("Column")
                    || m.getName().contains("Element") || m.getName().contains("Placeholder");
                if (jacksonSerialization)
                    g.jacksonGenerator.getClass().getMethod(arrayShape
                        ? "writeStartArray" : "writeStartObject").invoke(g.jacksonGenerator);
                Object result = m.invoke(receiver, args);
                boolean closureCompile = m.getDeclaringClass().getName().equals(
                    "com.google.javascript.jscomp.Compiler") && m.getName().equals("compile");
                if (closureCompile) {
                    // Result is only a status object; the compiled JavaScript is
                    // the behavioral output that reveals whether an argument
                    // was removed from a globally exposed function.
                    Object js = receiver.getClass().getMethod("toSource").invoke(receiver);
                    out.token = "CLOSURE_SOURCE:" + stable(js, 0);
                } else if (jacksonSerialization) {
                    g.jacksonGenerator.getClass().getMethod(arrayShape
                        ? "writeEndArray" : "writeEndObject").invoke(g.jacksonGenerator);
                    g.jacksonGenerator.getClass().getMethod("flush").invoke(g.jacksonGenerator);
                    out.token = "JSON:" + Base64.getEncoder().encodeToString(
                        g.jacksonOutput.toString().getBytes(StandardCharsets.UTF_8));
                } else out.token = m.getReturnType() == void.class
                    ? state(receiver, m.getName()) : stable(result, 0);
            } catch (InvocationTargetException e) {
                if (e.getCause() instanceof VirtualMachineError || e.getCause() instanceof LinkageError
                        || e.getCause() instanceof ThreadDeath) throw e;
                out.token = "THROW:" + e.getCause().getClass().getName();
            }
        } catch (Throwable e) {
            out.token = "HARNESS_ERROR";
            out.error = e.getClass().getName() + ":" + String.valueOf(e.getMessage());
        }
        return out;
    }
    public static String run(String target, String receivers, String signature, int[] genes) {
        Observation o = execute(target, receivers, signature, genes);
        if (!o.reachedTarget || o.token.equals("HARNESS_ERROR"))
            throw new AssertionError("Cannot replay test: " + o.error);
        return o.token;
    }
    private static String state(Object receiver, String method) {
        if (receiver == null) return "VOID";
        List<String> getters = new ArrayList();
        if (method.startsWith("set") && method.length() > 3) {
            getters.add("get" + method.substring(3)); getters.add("is" + method.substring(3));
        }
        getters.addAll(Arrays.asList("getItemCount", "getRowCount", "getColumnCount", "getSeriesCount"));
        StringBuilder s = new StringBuilder("VOID");
        for (String name : getters) {
            try {
                Method getter = receiver.getClass().getMethod(name);
                if (getter.getReturnType().isPrimitive() || getter.getReturnType() == String.class)
                    s.append('|').append(name).append('=').append(stable(getter.invoke(receiver), 0));
            } catch (ReflectiveOperationException ignored) { }
        }
        return s.toString();
    }
    /** Only whitelisted value types are rendered. Never use arbitrary object toString(). */
    static String stable(Object value, int depth) {
        if (value == null) return "NULL";
        Class<?> t = value.getClass();
        if (value instanceof String || value instanceof Boolean || value instanceof Character
                || value instanceof Byte || value instanceof Short || value instanceof Integer
                || value instanceof Long || value instanceof Float || value instanceof Double
                || value instanceof java.math.BigInteger || value instanceof java.math.BigDecimal)
            return t.getName() + ":" + Base64.getEncoder().encodeToString(value.toString().getBytes(StandardCharsets.UTF_8));
        if (value instanceof Enum) return "ENUM:" + t.getName() + ":" + ((Enum<?>)value).name();
        if (t.isArray() && depth < 3) {
            StringBuilder s = new StringBuilder("ARRAY:" + t.getName() + ":" + Array.getLength(value));
            for (int i = 0; i < Math.min(64, Array.getLength(value)); i++) {
                String item = stable(Array.get(value, i), depth + 1);
                s.append(':').append(item.length()).append(':').append(item);
            }
            return s.toString();
        }
        if (value instanceof java.awt.Color) return "COLOR:" + ((java.awt.Color)value).getRGB();
        // Observe safe scalar properties of returned objects. This catches
        // changes to value caches and state while avoiding identity-based toString().
        StringBuilder observed = new StringBuilder("STATE:" + t.getName());
        int properties = 0;
        for (String name : Arrays.asList("getItemCount", "getMinY", "getMaxY",
                "getRowCount", "getColumnCount", "getSeriesCount")) {
            try {
                Method getter = t.getMethod(name);
                Class<?> r = getter.getReturnType();
                if (!r.isPrimitive() && r != String.class && !Number.class.isAssignableFrom(r))
                    continue;
                if (r == void.class) continue;
                Object result = getter.invoke(value);
                String token = stable(result, depth + 1);
                observed.append('|').append(name).append('=').append(token.length())
                    .append(':').append(token);
                properties++;
            } catch (Exception ignored) { }
        }
        return properties == 0 ? "TYPE:" + t.getName() : observed.toString();
    }
    public static void main(String[] args) {
        if (args.length > 4) {
            String source = new String(Base64.getDecoder().decode(args[4]), StandardCharsets.UTF_8);
            System.setProperty("de.generated.source", source);
        }
        String[] encodedGenes = args[3].split(",");
        int[] genes = new int[encodedGenes.length];
        for (int i = 0; i < encodedGenes.length; i++) genes[i] = Integer.parseInt(encodedGenes[i]);
        boolean closureCompile = args[0].equals("com.google.javascript.jscomp.Compiler")
            && args[2].startsWith("compile(");
        // Compiler.compile is an expensive whole-program operation. Fixed-side
        // suites are still executed twice by the runner, so capture its oracle
        // once here instead of launching three compilations just to check the
        // same deterministic source output.
        int repetitions = closureCompile ? 1 : 3;
        for (int i = 0; i < repetitions; i++) {
            Observation out = execute(args[0], args[1], args[2], genes);
            System.out.println("DE_TOKEN:" + Base64.getEncoder().encodeToString(out.token.getBytes(StandardCharsets.UTF_8)));
        }
    }
}

public class DEGeneratedTest {
    @org.junit.Test(timeout=60000L)
    public void testDE00000() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "addAnnotation(org.jfree.chart.annotations.CategoryAnnotation):void",
            new int[]{-107,-62,-661,309,-571,639,-1000,1000,-1000,1000,161,-907,-1000,1000,-373,1000,-1000,-953,-1000,-1000,-1000,217,-1000,-765,1000,1000,-1000,1000,152,940,1000,1000,473,-1000,111,991,-21,-142,217,234,-635,-665,1000,-1000,-1000,1000,-704,1000,42,748,-1000,724,-1000,-1000,-1000,424,-1000,1000,1000,-1000,1000,-473,-829,-157}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00001() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "addAnnotation(org.jfree.chart.annotations.CategoryAnnotation):void",
            new int[]{-723,377,-871,-633,-737,673,866,-627,398,-42,-418,1000,1000,-978,204,34,700,-1000,404,-1000,-1000,-914,-13,-506,158,119,-1000,-654,1000,-1000,-869,899,-690,-436,-233,-1000,-1000,-916,1000,371,-1000,-1000,523,-40,876,-313,-1000,16,1000,-326,-708,-1000,-361,-126,-971,-645,-805,269,240,570,625,-594,774,-409}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00002() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "addAnnotation(org.jfree.chart.annotations.CategoryAnnotation):void",
            new int[]{334,917,-413,356,-886,-1000,-882,378,303,-242,-461,-56,-1000,635,347,-890,375,-73,55,539,1000,-273,1000,442,503,554,-512,-7,-99,-1000,-367,15,748,982,-1000,427,-352,-1000,-132,-1000,-282,243,-1000,-378,-674,514,1000,-1000,492,1000,1000,13,1000,-1000,1000,-875,966,-1000,-746,338,-1000,459,1000,542}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00003() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "addAnnotation(org.jfree.chart.annotations.CategoryAnnotation):void",
            new int[]{-85,1000,-952,708,-1000,1000,-8,955,-482,-378,-163,-451,-981,-126,-1000,423,-768,-37,-874,171,-236,360,-938,-183,498,-290,-710,1000,-1000,996,-376,163,540,-1000,564,749,-996,576,237,793,-261,603,937,-70,182,573,261,964,462,-7,-131,523,-748,1000,-990,1000,79,996,1000,-1000,708,-917,-965,-633}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00004() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "addAnnotation(org.jfree.chart.annotations.CategoryAnnotation):void",
            new int[]{-517,504,363,41,-690,992,50,787,-644,-692,485,-209,-1000,1000,-1000,141,-839,266,-1000,398,-422,-681,-523,483,570,1000,134,-372,-1000,300,159,1000,969,449,-1000,1000,81,-1000,-52,-201,-216,-299,361,873,-446,809,-537,863,-1000,-115,157,-984,-118,1000,-1000,1000,987,1000,1000,-308,155,-37,1000,-505}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00005() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "addAnnotation(org.jfree.chart.annotations.CategoryAnnotation):void",
            new int[]{-123,-145,197,85,-298,1000,1000,170,638,-1000,-1000,480,-764,-1000,1000,-474,56,-363,-338,1000,678,-98,-244,623,-266,-406,-459,689,-1000,1000,-1000,176,-770,-1000,1000,619,-1000,-877,435,1000,-88,-231,1000,528,1000,-615,124,964,600,-709,-177,296,-583,1000,-990,1000,1000,996,461,249,-413,1000,1000,-633}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00006() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "addAnnotation(org.jfree.chart.annotations.CategoryAnnotation):void",
            new int[]{-667,-1000,289,259,-737,869,1000,-993,906,-1000,-1000,1000,805,-229,-174,-1000,600,-1000,-630,1000,-1000,-965,1000,-1000,-708,-980,151,641,-856,-46,1000,899,-1000,-917,631,-935,-267,1000,1000,-831,-390,1000,523,-40,1000,494,1000,891,1000,579,-502,-1000,-65,-551,-39,676,-149,847,221,570,206,-1000,-1000,655}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00007() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "addAnnotation(org.jfree.chart.annotations.CategoryAnnotation):void",
            new int[]{-979,522,82,-686,-584,-816,679,-957,117,-134,-249,914,-917,-905,-871,209,427,-911,393,362,-830,307,-886,-36,34,941,-49,-775,825,463,-369,-370,-692,-370,222,118,-623,-294,48,753,-190,-909,93,562,902,33,-186,-34,907,-361,-102,102,-660,33,700,-834,-76,144,-159,-79,264,401,767,501}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00008() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "addAnnotation(org.jfree.chart.annotations.CategoryAnnotation):void",
            new int[]{-1000,1000,-227,88,-1000,-132,-925,73,-246,974,61,154,-1000,138,570,781,-230,-739,-272,-281,306,-1000,364,-153,652,733,-658,-390,-99,-1000,-544,733,1000,333,-1000,136,-720,-744,1000,-662,-667,-203,-1000,-1000,-928,660,-440,472,1000,919,-473,-179,415,-1000,-723,-307,118,367,636,-546,344,-197,729,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00009() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "addAnnotation(org.jfree.chart.annotations.CategoryAnnotation):void",
            new int[]{-1000,-635,363,-501,832,-698,-186,1000,362,-692,-1000,-209,-1000,467,-213,-989,-882,376,-1000,398,-422,269,-59,483,570,1000,-407,965,-1000,-1000,1000,1000,1000,-1000,299,430,388,-223,-799,-479,-454,894,-12,873,-231,-288,539,218,-317,989,-448,-923,980,138,-255,1000,104,500,1000,1000,-479,-787,-1000,768}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00010() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "addAnnotation(org.jfree.chart.annotations.CategoryAnnotation):void",
            new int[]{-1000,-1000,224,823,266,844,219,229,29,-776,-1000,1000,-831,-756,-472,-1000,-50,105,-471,223,-1000,-1000,1000,-466,125,829,-585,729,-571,-322,504,921,-159,-1000,-99,-334,-23,0,601,-234,-783,871,911,0,240,0,539,948,1000,745,-227,-1000,336,-990,-375,138,-367,781,0,1000,61,-616,-349,-367}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00011() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "addAnnotation(org.jfree.chart.annotations.CategoryAnnotation):void",
            new int[]{-760,309,811,-541,-867,-917,317,266,-745,366,-170,-667,746,49,127,861,-545,776,977,-227,817,175,644,806,729,367,324,-782,685,-947,-792,-928,-247,-232,-705,584,881,-754,-38,-291,510,-719,857,819,493,934,-302,-908,-103,511,-789,-913,-527,-684,630,-154,-762,887,-75,822,-55,151,-750,975}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00012() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "addAnnotation(org.jfree.chart.annotations.CategoryAnnotation):void",
            new int[]{-132,-371,776,-307,-934,-167,-243,88,380,793,-656,544,651,-144,872,-71,935,178,914,-429,-64,-83,656,-22,205,-711,-102,-139,520,-809,-930,-725,-825,-617,-979,-679,839,-412,250,-554,106,-711,795,136,-115,-504,-964,-494,395,296,282,-829,664,-393,231,-341,-838,-744,130,551,-511,193,-236,-388}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00013() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "addAnnotation(org.jfree.chart.annotations.CategoryAnnotation):void",
            new int[]{1000,212,-528,-853,-1000,-135,-104,74,-417,418,399,-1000,925,586,-516,-442,-410,586,-847,-656,586,-397,-294,188,1000,-653,178,1000,648,727,165,-918,1000,364,-1000,1000,314,-600,451,1000,-39,-879,573,-1000,-450,372,-1000,1000,-1000,-104,604,472,-828,985,-1000,-564,-199,1000,1000,-206,330,659,565,243}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00014() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "addAnnotation(org.jfree.chart.annotations.CategoryAnnotation,org.jfree.chart.util.Layer):void",
            new int[]{-214,-1000,-316,580,767,-1000,-255,-974,74,-416,557,-680,-57,-234,310,1,1000,38,-798,1000,47,-624,1000,377,587,-1000,990,1000,601,-1000,-1000,557,1000,-1000,-375,57,-487,137,333,-687,-619,167,601,779,-257,-824,1000,1000,644,-315,1000,-381,-717,-1000,-36,765,-466,1000,-494,740,1000,-190,162,108}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00015() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "addAnnotation(org.jfree.chart.annotations.CategoryAnnotation,org.jfree.chart.util.Layer):void",
            new int[]{-459,289,-256,785,-82,-351,780,517,-270,-530,-837,244,347,-136,-131,561,-609,-719,12,-918,479,764,-142,-961,-489,333,33,-1,637,-458,646,893,683,189,-107,-56,-676,402,-668,684,-440,-112,459,251,-839,-22,511,-588,678,-691,427,-661,-686,474,865,103,524,752,795,8,536,-815,-243,-537}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00016() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "addAnnotation(org.jfree.chart.annotations.CategoryAnnotation,org.jfree.chart.util.Layer):void",
            new int[]{-338,-983,616,1000,-724,-1000,499,383,1000,-695,-318,-105,-359,-1000,1000,-709,-314,-1000,-1000,-1000,59,213,103,-454,739,-603,-1000,1000,167,812,-1000,243,-725,-173,-699,1000,347,-738,-734,1000,-1000,-685,1000,1000,-600,536,-589,-1000,-1000,-1000,89,144,-1000,511,998,-92,199,367,930,1000,784,344,-360,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00017() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "addAnnotation(org.jfree.chart.annotations.CategoryAnnotation,org.jfree.chart.util.Layer):void",
            new int[]{54,1000,-926,-808,349,-492,242,-477,-264,-58,-1000,1000,951,572,938,-112,-561,-185,1000,-713,-177,151,-1000,-316,-1000,1000,-610,-1000,-1000,400,1000,-1000,-362,1000,475,-931,339,295,-987,302,1000,352,-26,-1000,1000,-537,616,811,-47,713,-1000,-1000,759,-209,-315,400,-1000,-1000,56,-884,-1000,877,-400,-180}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00018() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "addAnnotation(org.jfree.chart.annotations.CategoryAnnotation,org.jfree.chart.util.Layer):void",
            new int[]{756,-604,693,-932,-473,257,480,-1000,-768,774,1000,841,398,46,-10,-309,-739,1000,1000,530,926,-563,645,450,-371,195,816,-317,735,-565,1000,478,-4,-1000,754,-531,375,954,930,-1000,346,1000,-1000,-691,962,-1000,-409,1000,707,-51,807,-511,1000,-1000,-1000,-516,-1000,-78,-918,-146,1000,-13,-1000,471}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00019() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "addAnnotation(org.jfree.chart.annotations.CategoryAnnotation,org.jfree.chart.util.Layer):void",
            new int[]{1000,98,-251,-1000,-520,-315,-459,-945,911,914,-926,1000,949,-1000,1000,-845,631,192,196,955,-598,-875,423,1000,-675,780,-1000,-1000,-1000,1000,-19,-1000,-330,1000,434,-1000,1000,1000,-1000,-1000,1000,394,1000,1000,1000,-1000,-28,1000,334,355,-235,-459,1000,-1000,-1000,988,-1000,-1000,-322,-1000,-1000,34,-277,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00020() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "addAnnotation(org.jfree.chart.annotations.CategoryAnnotation,org.jfree.chart.util.Layer):void",
            new int[]{117,-24,-316,-1000,-641,516,349,-252,-1000,343,-715,416,577,442,-649,927,-461,1000,607,383,1000,56,397,377,-972,190,1000,-120,1000,-1000,1000,1000,1000,-1000,1000,-901,-510,469,-217,-1000,382,8,-1000,-976,461,-800,1000,1000,644,282,1000,-381,1000,-471,-477,-1000,-1000,1000,-190,56,1000,-1000,358,263}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00021() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "addAnnotation(org.jfree.chart.annotations.CategoryAnnotation,org.jfree.chart.util.Layer):void",
            new int[]{-459,289,398,1000,811,-351,780,517,955,4,-821,25,-618,-233,1000,284,-63,-388,-1000,508,130,733,800,716,46,-708,-154,1000,14,-170,-1000,221,496,90,-233,-105,-217,269,-668,483,-440,-1000,1000,-58,-646,1000,1000,-833,-173,-465,412,817,-1000,988,865,-479,-1000,476,1000,1000,-173,-1000,1000,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00022() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "addAnnotation(org.jfree.chart.annotations.CategoryAnnotation,org.jfree.chart.util.Layer):void",
            new int[]{429,-1000,608,755,-636,-462,-165,-677,990,665,-732,1000,586,240,1000,-1000,85,-609,36,-231,-72,-524,72,672,-26,19,-958,-457,-931,819,-88,-387,-837,483,172,-404,851,988,-1000,-511,52,1000,361,-263,1000,-1000,-493,491,-75,78,-58,-581,-57,-852,-934,442,-1000,-1000,397,-15,-168,404,-1000,582}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00023() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "addAnnotation(org.jfree.chart.annotations.CategoryAnnotation,org.jfree.chart.util.Layer):void",
            new int[]{-814,681,-852,-106,-608,-442,76,-623,-559,29,-763,96,797,-534,46,556,-365,-20,-176,-473,450,852,-776,-892,-797,639,-727,-967,-724,-588,430,-672,182,516,862,-196,474,-525,-192,496,564,-772,292,-870,272,-244,-220,-25,-143,331,-627,-968,-10,124,81,-612,-322,-296,357,-186,-487,80,636,-827}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00024() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "addAnnotation(org.jfree.chart.annotations.CategoryAnnotation,org.jfree.chart.util.Layer):void",
            new int[]{-1000,105,-261,371,229,-1000,288,-428,690,-418,-501,614,523,-493,1000,34,-213,-852,255,-753,57,516,-610,-181,-277,370,-384,790,68,335,-400,-699,-275,434,79,213,-511,-442,-965,302,-161,25,1000,273,108,-19,658,382,-158,204,-831,-432,3,-178,315,358,-735,-450,958,218,-399,818,26,-493}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00025() {
        org.junit.Assert.assertEquals("STATE:org.jfree.chart.renderer.category.BarRenderer|getRowCount=22:java.lang.Integer:MA==|getColumnCount=22:java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "clone():java.lang.Object",
            new int[]{725,-1000,-986,-695,-557,-143,-236,782,-241,626,-218,985,180,-78,433,1000,-1000,326,-459,103,-574,56,1000,-109,-41,800,-1000,1000,1000,-1000,526,22,1000,-796,-213,1000,-1000,-584,-488,1000,-229,1000,-443,1000,1000,402,-555,-1000,798,993,250,698,1000,1000,-931,272,999,962,-693,-392,-1000,173,-42,384}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00026() {
        org.junit.Assert.assertEquals("STATE:org.jfree.chart.renderer.category.BarRenderer|getRowCount=22:java.lang.Integer:MA==|getColumnCount=22:java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "clone():java.lang.Object",
            new int[]{657,1000,209,1000,-799,-210,352,-1000,-1000,-212,-733,1000,1000,-354,-248,1000,-579,19,-1000,-11,1000,-1000,-1,85,1000,-1000,-943,465,-1000,-1000,808,319,1000,-493,388,-1000,-912,-407,-1000,-226,-586,135,-694,626,-1000,-287,-164,433,790,939,1000,367,612,744,-1000,298,855,-1000,-414,-1000,363,1000,558,919}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00027() {
        org.junit.Assert.assertEquals("STATE:org.jfree.chart.renderer.category.BoxAndWhiskerRenderer|getRowCount=22:java.lang.Integer:MA==|getColumnCount=22:java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "clone():java.lang.Object",
            new int[]{803,425,424,196,-367,-453,-117,-217,-813,258,-330,885,-91,-704,-170,1000,180,-27,-628,296,-15,512,877,-474,702,220,-965,-133,-106,-458,598,556,-48,-506,-103,538,-802,-240,-553,28,-392,814,-596,915,726,-162,693,-818,524,912,448,208,971,984,-895,679,899,466,-48,-869,-603,940,220,688}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00028() {
        org.junit.Assert.assertEquals("STATE:org.jfree.chart.renderer.category.BarRenderer3D|getRowCount=22:java.lang.Integer:MA==|getColumnCount=22:java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "clone():java.lang.Object",
            new int[]{870,-277,-821,-127,655,-142,-422,16,110,1000,-517,-186,218,-558,-954,91,1000,-818,-608,169,-1000,1000,-701,153,617,861,96,663,-508,183,-229,788,653,-1000,-653,1000,-477,-1000,474,350,-448,36,-111,254,1000,-1000,1000,1000,1000,737,437,-337,1000,1000,248,1000,1000,-821,39,-1000,6,219,1000,678}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00029() {
        org.junit.Assert.assertEquals("STATE:org.jfree.chart.renderer.category.BarRenderer|getRowCount=22:java.lang.Integer:MA==|getColumnCount=22:java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "clone():java.lang.Object",
            new int[]{641,1000,-6,-249,-54,40,591,-1000,-1000,564,-882,93,994,200,-1000,1000,1000,648,-616,1000,55,-473,532,-851,702,-1000,-1000,-751,-106,-643,736,624,1000,-732,426,2,-1000,-680,-868,1000,246,754,-178,-209,-512,205,-144,-1000,690,1000,339,1000,977,1000,-966,421,912,214,-233,-762,-1000,940,-363,442}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00030() {
        org.junit.Assert.assertEquals("STATE:org.jfree.chart.renderer.category.BarRenderer3D|getRowCount=22:java.lang.Integer:MA==|getColumnCount=22:java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "clone():java.lang.Object",
            new int[]{450,-331,-1000,443,470,-746,-117,-98,-1000,181,-1000,42,-91,-704,-1000,233,-216,-1000,-618,-1000,1000,1000,-687,-768,1000,-905,583,1000,-106,427,161,515,1000,-392,-98,1000,-375,-965,-1000,263,-592,814,764,915,361,-1000,1000,934,958,1000,936,208,416,1000,438,1000,1000,-889,373,549,-603,1000,770,688}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00031() {
        org.junit.Assert.assertEquals("STATE:org.jfree.chart.renderer.category.AreaRenderer|getRowCount=22:java.lang.Integer:MA==|getColumnCount=22:java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "clone():java.lang.Object",
            new int[]{-224,364,-632,518,-514,-210,-110,-831,-889,147,-429,901,383,-704,-399,92,-480,-521,-973,-505,1000,-164,109,-455,1000,-898,-644,400,-1000,522,148,1000,1000,-974,-324,380,-808,-605,-892,380,115,130,-123,-330,-836,-1000,-12,-99,790,938,893,216,981,746,-958,679,1000,-751,1000,-528,-603,1000,1000,678}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00032() {
        org.junit.Assert.assertEquals("STATE:org.jfree.chart.renderer.category.AreaRenderer|getRowCount=22:java.lang.Integer:MA==|getColumnCount=22:java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "clone():java.lang.Object",
            new int[]{-720,-1000,-631,-721,1000,1000,981,1000,1000,-345,60,-1000,-309,762,-1000,-1000,-1000,134,1000,41,-1000,-148,-774,1000,-207,-484,975,574,680,1000,-368,-1000,-433,1000,1000,-982,861,749,1000,110,1000,-1000,295,1000,-1000,379,-954,1000,-1000,-1000,278,126,-1000,-395,-634,-1000,520,859,285,1000,1000,424,205,-226}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00033() {
        org.junit.Assert.assertEquals("STATE:org.jfree.chart.renderer.category.AreaRenderer|getRowCount=22:java.lang.Integer:MA==|getColumnCount=22:java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "clone():java.lang.Object",
            new int[]{280,-193,-82,-692,69,-141,679,1000,1000,130,-846,141,-278,-899,-260,517,-1000,-692,994,-103,-272,-584,79,426,1000,156,-975,-563,-139,681,141,-1000,-49,367,584,799,-419,349,557,253,593,599,-1000,515,174,280,1000,1000,418,1000,-706,-166,1000,1000,-524,-1000,47,-39,-113,780,493,731,-830,-834}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00034() {
        org.junit.Assert.assertEquals("STATE:org.jfree.chart.renderer.category.BoxAndWhiskerRenderer|getRowCount=22:java.lang.Integer:MA==|getColumnCount=22:java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "clone():java.lang.Object",
            new int[]{803,138,-706,-608,149,-567,-229,-246,-165,493,-330,-189,795,-704,-205,1000,-419,-127,-264,373,294,512,537,246,-189,614,-1000,462,180,-736,-63,-71,-48,-506,-531,538,-1000,-1000,-402,1000,-675,1000,190,1000,740,-64,87,-1000,968,1000,415,395,971,984,-308,679,899,-415,-856,-869,-1000,-121,189,433}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00035() {
        org.junit.Assert.assertEquals("STATE:org.jfree.chart.renderer.category.BarRenderer|getRowCount=22:java.lang.Integer:MA==|getColumnCount=22:java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "clone():java.lang.Object",
            new int[]{-183,1000,273,1000,-1000,-513,750,-1000,-1000,-617,-569,1000,51,-562,266,796,524,35,-1000,-322,1000,-1000,323,-548,1000,-1000,-644,-404,-537,-67,1000,1000,1000,-335,520,-895,-861,91,-687,-226,-112,135,-1000,51,806,-110,1000,656,812,938,1000,640,-5,749,-1000,-67,900,-72,1000,-762,-236,1000,898,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00036() {
        org.junit.Assert.assertEquals("STATE:org.jfree.chart.renderer.category.AreaRenderer|getRowCount=22:java.lang.Integer:MA==|getColumnCount=22:java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "clone():java.lang.Object",
            new int[]{1000,-589,-227,976,-769,-460,592,692,-88,-733,-1000,-510,-736,-1000,-949,-1000,-144,-642,-774,-347,-329,1000,725,-626,1000,437,1000,149,-1000,1000,-48,891,1000,-1000,397,1000,629,-231,-20,-624,-596,-713,-122,-638,980,-389,1000,1000,367,405,1000,-263,1000,1000,-533,1000,1000,259,229,-1000,1000,1000,1000,389}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00037() {
        org.junit.Assert.assertEquals("STATE:org.jfree.chart.renderer.category.AreaRenderer|getRowCount=22:java.lang.Integer:MA==|getColumnCount=22:java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "clone():java.lang.Object",
            new int[]{1000,198,-264,88,351,-311,383,293,-88,503,-531,887,292,-99,-889,477,-683,-878,-881,-541,1000,897,587,-626,1000,49,-247,510,-383,1000,276,884,1000,-79,-464,786,-253,-419,-1000,-12,-229,-377,-402,661,1000,-766,733,-283,700,1000,593,576,1000,1000,-158,1000,1000,259,689,92,173,1000,454,782}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00038() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawAnnotations(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.axis.CategoryAxis,org.jfree.chart.axis.ValueAxis,org.jfree.chart.util.Layer,org.jfree.chart.plot.PlotRenderingInfo):void",
            new int[]{-361,1000,-476,339,453,-1000,-943,-257,744,253,-1000,-43,-106,1000,-186,-231,-1000,-815,150,-1000,548,1000,315,187,-258,815,818,-119,1000,-30,1000,-1000,1000,-196,-147,-290,1000,-314,-734,327,237,353,-246,1000,-1000,-1000,-654,1000,-514,1000,630,174,-1000,1000,-1000,1000,-42,804,-1000,-340,1000,-1000,894,-144}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00039() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawAnnotations(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.axis.CategoryAxis,org.jfree.chart.axis.ValueAxis,org.jfree.chart.util.Layer,org.jfree.chart.plot.PlotRenderingInfo):void",
            new int[]{849,328,-221,151,921,-1000,480,599,-101,591,-1000,-43,-751,665,1000,-269,-1000,-1000,1000,200,603,860,315,-1000,-258,86,699,523,1000,-39,1000,164,446,-196,-532,-27,22,-314,-339,183,756,-1000,-886,418,-1000,-598,-1000,1000,-628,636,912,-92,-1000,1000,61,359,41,377,-1000,-810,1000,-803,462,-191}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00040() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawAnnotations(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.axis.CategoryAxis,org.jfree.chart.axis.ValueAxis,org.jfree.chart.util.Layer,org.jfree.chart.plot.PlotRenderingInfo):void",
            new int[]{-1000,125,28,145,726,-694,916,-787,324,-270,-1000,960,1000,948,-1000,1000,-316,-874,510,-398,411,886,609,1000,307,870,-267,325,827,-443,180,-656,1000,-579,-206,-9,606,-755,-303,849,440,-109,888,921,919,-1000,-127,134,364,410,961,-197,-1000,655,-147,674,-650,-702,-1000,516,613,-689,261,487}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00041() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawAnnotations(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.axis.CategoryAxis,org.jfree.chart.axis.ValueAxis,org.jfree.chart.util.Layer,org.jfree.chart.plot.PlotRenderingInfo):void",
            new int[]{94,927,257,-322,-654,-961,-631,-838,823,5,-984,-115,-818,842,-111,-295,-1000,1000,-1000,404,903,-310,-643,1000,609,-1000,47,-1000,1000,-964,267,112,-158,-839,1000,-706,1000,1000,146,1000,790,565,1000,-403,-659,-948,-482,1000,-693,1000,-577,1000,-161,826,-1000,1000,691,-1000,-937,124,1000,690,-749,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00042() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawAnnotations(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.axis.CategoryAxis,org.jfree.chart.axis.ValueAxis,org.jfree.chart.util.Layer,org.jfree.chart.plot.PlotRenderingInfo):void",
            new int[]{736,-1000,438,1000,635,427,754,-859,-507,840,1000,-1000,-698,-1000,-1000,1000,-23,-935,870,-1000,-788,164,-119,372,705,1000,661,138,711,-409,-579,199,482,-862,-1000,101,-1000,-1000,48,-115,34,1000,988,355,333,-693,-291,-942,650,-1000,1000,-879,-25,43,69,-652,-957,-617,-978,371,-288,-55,-229,49}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00043() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawAnnotations(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.axis.CategoryAxis,org.jfree.chart.axis.ValueAxis,org.jfree.chart.util.Layer,org.jfree.chart.plot.PlotRenderingInfo):void",
            new int[]{-817,-523,944,-1000,-848,83,686,127,-185,-651,625,77,61,-1000,-859,-870,544,708,32,-398,-1000,-198,489,767,-5,870,-267,-892,446,163,1000,354,-569,-765,453,142,-961,-42,15,-71,-54,-109,-1000,172,956,211,-396,229,-669,338,858,-910,109,-1000,1000,-549,642,-702,712,516,-233,85,1000,-910}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00044() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawAnnotations(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.axis.CategoryAxis,org.jfree.chart.axis.ValueAxis,org.jfree.chart.util.Layer,org.jfree.chart.plot.PlotRenderingInfo):void",
            new int[]{-709,453,-126,341,239,1,913,-1000,-620,1000,-171,441,871,1000,-1000,8,-1000,-918,590,-1000,381,363,810,-719,1000,1000,155,-395,1000,-1000,-168,240,803,24,116,-1000,440,-826,-149,-229,1000,1000,1000,467,1000,-1000,89,237,636,432,1000,516,-665,509,-698,330,-34,381,-1000,647,970,126,1000,-812}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00045() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawAnnotations(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.axis.CategoryAxis,org.jfree.chart.axis.ValueAxis,org.jfree.chart.util.Layer,org.jfree.chart.plot.PlotRenderingInfo):void",
            new int[]{-600,-120,132,-184,-566,637,-71,958,106,392,500,1000,835,-1000,-688,-567,1000,636,108,566,-167,-1000,1000,-573,-521,1000,-610,-642,-462,1000,-283,126,-873,142,-84,-324,-1000,-1000,-170,-1000,-925,-69,-1000,1000,1000,587,145,-321,-172,293,526,-1000,-889,-677,208,308,1000,-1000,914,-66,-1000,554,166,-564}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00046() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawAnnotations(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.axis.CategoryAxis,org.jfree.chart.axis.ValueAxis,org.jfree.chart.util.Layer,org.jfree.chart.plot.PlotRenderingInfo):void",
            new int[]{-988,751,333,-36,-366,-1000,-137,-825,262,-490,-1000,-43,-256,541,-980,-672,-1000,-737,-220,-1000,492,170,-72,1000,-129,-1000,682,-872,896,-276,1000,-891,867,-944,832,165,1000,597,-308,1000,371,-40,1000,1000,-1000,-1000,-613,1000,-921,434,1000,-190,-586,941,-1000,778,15,-596,-1000,181,1000,-359,365,-180}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00047() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawAnnotations(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.axis.CategoryAxis,org.jfree.chart.axis.ValueAxis,org.jfree.chart.util.Layer,org.jfree.chart.plot.PlotRenderingInfo):void",
            new int[]{284,-687,-583,575,201,-131,917,-582,-577,-1000,1000,-763,-715,-1000,-884,50,-23,-1000,1000,-870,-116,-82,66,611,-677,866,1000,-501,1000,205,-579,-52,1000,-297,-521,161,-960,879,116,-101,-148,1000,33,-427,895,-1000,10,-497,-1000,-227,1000,-975,885,176,-562,-169,-753,469,-823,535,-97,1000,36,-214}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00048() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawBackground(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,java.awt.geom.Rectangle2D):void",
            new int[]{89,-1000,733,-59,1000,-697,548,775,-545,1000,683,115,1000,830,-879,242,-810,-455,-826,-537,-1000,-1000,230,160,-481,502,356,574,14,-134,-956,-947,1000,-671,150,749,-277,-99,434,-643,-741,129,-1000,244,-443,286,64,1000,55,815,-1000,545,-743,495,493,576,-951,-872,-286,747,-463,-483,1000,-94}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00049() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawBackground(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,java.awt.geom.Rectangle2D):void",
            new int[]{-1000,744,-491,1000,823,-291,-1000,-670,-315,-588,-751,-337,-180,1000,-785,-243,-300,-1000,-397,-1000,91,293,729,-144,102,1000,-653,-24,882,-356,828,-288,-317,-592,-173,-1000,410,-389,231,1000,-80,-128,172,1000,1000,78,508,-717,667,34,1000,1000,65,-696,-1000,-384,495,612,-334,654,-1000,-817,-384,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00050() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawBackground(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,java.awt.geom.Rectangle2D):void",
            new int[]{-792,866,-31,43,-371,400,-902,-685,-152,-586,474,-10,-493,918,321,-133,-814,-976,244,-661,-534,439,472,960,958,230,8,93,798,-573,308,-225,-739,-361,-672,-211,886,544,507,908,-234,-177,572,301,513,-50,955,-854,826,58,-3,658,531,75,-819,-50,-460,282,142,378,-784,490,376,403}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00051() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawBackground(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,java.awt.geom.Rectangle2D):void",
            new int[]{-988,-5,589,739,-249,37,-32,284,-258,-319,-89,-691,183,941,82,-177,248,-338,116,-1000,-113,400,9,306,919,-410,-83,785,-797,200,-444,453,67,-734,-231,-651,-93,1000,49,-643,182,671,400,505,-448,612,315,404,574,1000,-1000,-15,657,-88,-228,-627,-576,-392,976,-380,-915,18,409,245}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00052() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawBackground(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,java.awt.geom.Rectangle2D):void",
            new int[]{-1000,297,199,364,661,-967,409,-397,715,-289,-60,-34,983,-110,-1000,-55,-876,-536,-621,-1000,-534,-687,533,58,-1000,548,744,487,-99,-540,1000,679,622,200,-635,-241,-1000,656,-445,-608,-1000,-58,-808,699,372,80,-1000,-489,9,-1000,586,64,-1000,-109,-573,-288,598,-433,-1000,375,-559,338,680,-555}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00053() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawBackground(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,java.awt.geom.Rectangle2D):void",
            new int[]{-44,-622,-217,746,-1000,-630,527,799,-948,-137,461,-528,817,-699,-752,-343,68,127,215,-868,-436,580,835,-1000,908,-83,48,277,-1000,-125,-533,391,-281,-133,-337,-459,410,1000,731,-1000,516,772,22,1000,-336,9,-363,235,-305,-371,-1000,648,561,459,224,324,683,280,1000,1000,-191,362,394,172}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00054() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawBackground(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,java.awt.geom.Rectangle2D):void",
            new int[]{-1000,686,284,-1000,-883,546,-445,-394,265,-388,-800,-592,-462,-229,1000,-364,914,-122,147,-523,455,1000,22,906,1000,-180,119,398,-1000,723,235,1000,-748,-305,-838,-1000,214,1000,-439,-328,983,281,1000,235,-198,252,536,-643,823,-50,-298,-665,1000,-557,-1000,-1000,468,-1000,1000,-1000,-576,483,50,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00055() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawBackground(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,java.awt.geom.Rectangle2D):void",
            new int[]{-671,-895,949,1000,-62,586,123,336,234,532,944,14,428,-257,355,-106,518,-824,1000,-661,832,896,-570,516,-123,1000,-56,93,-222,962,-1000,1000,1000,-361,-242,-706,-1000,130,-1000,-1000,-396,-564,-434,565,513,-917,-276,-411,1000,854,-350,107,531,-53,281,-1000,-926,-417,552,-397,235,-603,665,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00056() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawBackground(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,java.awt.geom.Rectangle2D):void",
            new int[]{539,-566,-43,-1000,784,-137,-172,-299,-796,-398,1000,793,174,-423,-372,44,-1000,-199,-794,504,-1000,-1000,-87,791,-1000,-113,1000,-29,1000,-1000,-3,-1000,558,-171,-455,1000,175,-1000,384,-1000,-319,-621,-1000,-923,547,535,243,-149,258,-528,384,106,-1000,-82,30,1000,-385,-376,-853,1000,-301,-458,562,154}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00057() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawBackground(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,java.awt.geom.Rectangle2D):void",
            new int[]{-1000,556,237,920,-14,274,-358,-101,912,-217,-190,-154,-256,1000,256,179,-428,-790,1000,-930,-275,447,637,558,1000,796,-292,-20,310,472,68,361,-475,-327,37,-744,867,554,-250,1000,126,-333,428,917,607,-443,842,-553,1000,289,-166,617,627,265,-661,-727,-204,299,739,-419,-695,730,328,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00058() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawBackground(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,java.awt.geom.Rectangle2D):void",
            new int[]{-1000,-622,103,1000,1000,-337,-602,-259,-169,433,-412,54,817,1000,-934,130,-1000,-1000,795,-868,-275,-348,1000,502,12,1000,-77,277,1000,-125,99,398,379,-629,-337,-920,-27,1000,-646,-54,-1000,433,-215,1000,903,-822,327,-553,1000,508,-166,1000,-332,302,-959,-660,-481,-63,1000,388,-1000,165,381,234}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00059() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawBackground(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,java.awt.geom.Rectangle2D):void",
            new int[]{-597,-297,-578,1000,474,-748,-1000,-477,-737,-249,289,957,470,1000,-1000,372,-813,-1000,398,-374,-1000,1000,1000,-97,-625,-57,155,376,288,-1000,54,-58,565,-679,16,-419,-336,-758,244,1000,-1000,511,-451,1000,1000,535,-298,-913,739,482,302,1000,-556,-227,-1000,134,-671,1000,-913,748,-1000,-348,397,-770}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00060() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawDomainLine(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,java.awt.geom.Rectangle2D,double,java.awt.Paint,java.awt.Stroke):void",
            new int[]{891,213,-432,1000,1000,577,-90,1000,151,-544,43,972,324,20,-1000,273,711,-539,-344,-426,-132,433,487,-323,-1000,390,-466,-20,-725,-704,-256,-796,-33,886,-686,-430,-360,342,-556,20,-96,-353,-404,-625,87,-82,774,-238,-138,413,-231,141,-1000,-1000,934,-48,-1000,195,740,819,370,663,336,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00061() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawDomainLine(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,java.awt.geom.Rectangle2D,double,java.awt.Paint,java.awt.Stroke):void",
            new int[]{480,262,887,417,372,-725,-904,-93,-1000,340,134,-782,-914,935,5,437,-1000,-802,-1000,311,1000,-1000,-1000,139,-1000,512,266,376,1000,1000,906,-56,495,-154,-721,724,235,1000,676,843,-706,-136,219,-410,993,-285,-1000,286,1000,-108,-73,-381,1000,1000,-734,-994,-1000,883,874,-948,18,1000,507,-916}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00062() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawDomainLine(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,java.awt.geom.Rectangle2D,double,java.awt.Paint,java.awt.Stroke):void",
            new int[]{-921,-164,-701,327,130,480,1000,48,884,-827,564,1000,-175,-624,-632,86,619,876,-463,1000,-271,-400,1000,-808,5,581,-666,135,-1000,-1000,632,1000,-525,253,-48,-191,-1000,216,102,-914,166,-594,-415,1000,-1000,284,-2,211,-1000,-400,-510,-174,-504,67,855,318,-1000,1000,926,261,1000,-513,-486,250}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00063() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawDomainLine(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,java.awt.geom.Rectangle2D,double,java.awt.Paint,java.awt.Stroke):void",
            new int[]{-674,1000,507,215,-400,874,-353,-200,356,-460,-198,1000,-203,601,-790,872,327,697,-1000,1000,762,-103,-605,-1000,698,-750,-363,-672,-102,-704,-172,891,379,751,743,203,-336,-126,-217,444,372,-971,-533,773,822,446,284,-262,1000,173,-1000,-1000,-400,-280,901,397,-175,650,1000,655,573,614,-857,217}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00064() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawDomainLine(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,java.awt.geom.Rectangle2D,double,java.awt.Paint,java.awt.Stroke):void",
            new int[]{473,-1000,-417,1000,749,957,-601,-1000,1000,-270,-684,105,1000,568,-633,255,608,-462,648,721,-309,1000,-584,-235,775,-577,-666,-997,-1000,-776,1000,208,-469,-670,1000,-268,-690,-753,-13,257,-342,-753,-184,-494,245,738,917,228,-1000,933,186,-610,-650,1000,856,709,-683,1000,1000,709,484,-1000,-929,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00065() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawDomainLine(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,java.awt.geom.Rectangle2D,double,java.awt.Paint,java.awt.Stroke):void",
            new int[]{-877,213,603,1000,67,577,-484,-992,-839,-544,247,972,-1000,313,-953,-38,500,-86,-322,-592,89,214,-301,-241,-356,-104,579,1000,1000,902,1000,-89,188,347,-509,688,-29,1000,346,-497,-40,-2,18,624,637,-718,-1000,-177,-120,-180,-107,1000,1000,1000,-513,-189,110,593,926,-924,370,391,253,-421}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00066() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawDomainLine(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,java.awt.geom.Rectangle2D,double,java.awt.Paint,java.awt.Stroke):void",
            new int[]{1000,961,-81,715,-1000,498,1000,-564,477,-1000,135,-23,-99,-735,-1000,429,-583,-43,222,456,111,137,38,-324,64,29,727,-596,400,138,27,1000,-468,1000,853,159,-343,-64,6,-1000,1000,-648,-841,-234,1000,1000,-79,625,-506,907,-41,-918,-438,-887,1000,554,-460,943,1000,539,370,961,-802,587}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00067() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawDomainLine(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,java.awt.geom.Rectangle2D,double,java.awt.Paint,java.awt.Stroke):void",
            new int[]{-1000,-1000,-247,-443,-824,1000,46,50,-115,1000,195,193,914,100,-842,677,175,404,-1000,1000,828,-499,856,-761,-170,-34,-272,1000,-367,-24,267,-56,1000,-1000,-976,-923,-884,1000,-37,154,890,-488,-89,-510,-724,453,245,550,1000,-320,619,-498,1000,-37,970,-75,-426,729,1000,-786,1000,1000,-7,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00068() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawDomainLine(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,java.awt.geom.Rectangle2D,double,java.awt.Paint,java.awt.Stroke):void",
            new int[]{-600,-1000,-456,610,-613,344,536,-93,177,340,-46,403,1000,-400,-756,524,585,479,-1000,889,116,433,1000,-1000,277,358,-132,642,-702,-400,1000,753,1000,-1000,-1000,-1000,-1000,1000,-242,-723,413,-239,-203,736,30,-528,1000,-1,1000,227,564,-351,562,-379,905,-151,-827,883,926,-174,1000,1000,-237,-186}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00069() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawDomainLine(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,java.awt.geom.Rectangle2D,double,java.awt.Paint,java.awt.Stroke):void",
            new int[]{62,-1000,719,-394,-546,265,-200,1000,921,178,602,-1000,-145,-471,1000,-534,166,1000,-72,-1000,-1000,-451,102,616,348,-1000,1000,1000,409,93,1000,1000,422,454,-728,542,882,-309,383,237,1000,998,982,508,612,-1000,213,-382,1000,140,284,359,1000,553,-434,282,1000,311,655,-662,575,1000,42,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00070() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawDomainLine(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,java.awt.geom.Rectangle2D,double,java.awt.Paint,java.awt.Stroke):void",
            new int[]{-842,-581,-66,-394,-1000,668,912,1000,1000,-915,293,-352,-500,-1000,-443,-1000,280,-199,327,-1000,-1000,-1000,102,871,-104,-270,1000,285,772,706,1000,298,-399,856,-147,1000,-1000,-113,-1000,-1000,1000,998,-208,569,1000,172,251,-891,588,140,1000,866,154,1000,-966,-1000,-354,-528,-1000,-436,-842,-866,-866,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00071() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawDomainLine(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,java.awt.geom.Rectangle2D,double,java.awt.Paint,java.awt.Stroke):void",
            new int[]{-715,-1000,-663,-753,-613,579,-362,-138,1000,685,111,403,1000,-400,-366,992,504,-36,-957,1000,526,-268,528,-1000,1000,723,-840,642,-894,-662,233,898,1000,-1000,-762,-1000,-1000,1000,168,-37,413,-545,295,231,-57,174,1000,685,1000,377,-411,-953,771,58,951,-50,-749,1000,922,-36,1000,812,-1000,-425}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00072() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawDomainLine(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,java.awt.geom.Rectangle2D,double,java.awt.Paint,java.awt.Stroke):void",
            new int[]{1000,1000,-168,553,1000,775,-37,-112,-230,-1000,1000,105,-1000,-153,240,1000,-413,-473,1000,56,-259,881,1000,-451,-46,84,-1000,-1000,-954,-1000,-510,1000,-1000,1000,1000,421,-640,-1000,26,-180,-1000,-967,-306,-424,466,-213,-1000,624,-1000,1000,-737,-1000,-560,168,856,891,-749,575,1000,1000,1000,-955,-557,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00073() {
        org.junit.Assert.assertEquals("THROW:java.lang.NullPointerException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawDomainMarker(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,org.jfree.chart.axis.CategoryAxis,org.jfree.chart.plot.CategoryMarker,java.awt.geom.Rectangle2D):void",
            new int[]{-275,-910,399,-59,1000,-1000,-972,-353,-915,-1000,575,439,1000,519,321,218,-678,321,462,-289,1000,-1000,184,-277,-14,1000,-1000,1000,-789,64,-1000,1000,38,197,-1000,-137,7,1000,794,-377,-885,-1000,-1000,-534,-659,-568,-1000,-105,-551,925,-1000,998,-899,55,1000,-492,-377,-1000,-681,-768,989,774,-483,-949}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00074() {
        org.junit.Assert.assertEquals("THROW:java.lang.NullPointerException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawDomainMarker(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,org.jfree.chart.axis.CategoryAxis,org.jfree.chart.plot.CategoryMarker,java.awt.geom.Rectangle2D):void",
            new int[]{453,1000,-301,-606,-930,-404,1000,-646,973,1000,-1000,-1000,391,-998,540,532,1000,-495,469,1000,-1000,572,506,847,-471,-1000,1000,608,-506,15,536,569,95,-397,895,-1000,-345,1000,785,-339,-136,-298,1000,-523,135,618,1000,-202,-271,269,146,186,-986,-1000,1000,-289,474,1000,158,-1000,-941,-807,-283,218}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00075() {
        org.junit.Assert.assertEquals("THROW:java.lang.NullPointerException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawDomainMarker(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,org.jfree.chart.axis.CategoryAxis,org.jfree.chart.plot.CategoryMarker,java.awt.geom.Rectangle2D):void",
            new int[]{-321,-507,-221,-103,-838,-648,-1000,-1000,323,-1000,1000,1000,616,98,-949,492,1000,-464,279,-1000,1000,-863,1000,1000,-975,1000,-1000,318,211,1000,826,1000,1000,1000,-1000,-887,159,-488,-318,1000,-1000,-1000,-1000,-593,-1000,-193,-1000,168,-783,909,30,-561,-1000,-449,93,-230,-922,-1000,-1000,-906,152,-241,-465,864}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00076() {
        org.junit.Assert.assertEquals("THROW:java.lang.NullPointerException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawDomainMarker(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,org.jfree.chart.axis.CategoryAxis,org.jfree.chart.plot.CategoryMarker,java.awt.geom.Rectangle2D):void",
            new int[]{624,1000,-352,-151,-1000,468,981,-906,1000,296,-618,-485,-277,-1000,111,850,1000,-165,620,353,-1000,238,11,1000,-1000,-1000,1000,181,451,-213,1000,1000,392,-1,953,-690,-779,-41,222,1000,233,425,1000,16,762,1000,1000,-23,17,156,230,-1000,785,-1000,493,-510,-53,516,-267,-1000,-856,-1000,-434,956}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00077() {
        org.junit.Assert.assertEquals("THROW:java.lang.NullPointerException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawDomainMarker(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,org.jfree.chart.axis.CategoryAxis,org.jfree.chart.plot.CategoryMarker,java.awt.geom.Rectangle2D):void",
            new int[]{697,-993,-807,-485,-626,922,338,-689,-562,633,-253,1000,1000,-960,-404,1000,1000,-1000,670,850,-11,-394,-1000,1000,-429,895,211,908,-1000,1000,60,1000,1000,392,-352,-993,1000,822,1000,194,-1000,-1000,-75,-1000,-1000,492,14,-916,-164,1000,-782,476,-1000,-1000,1000,-1000,279,-1000,-1000,-497,731,684,-493,36}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00078() {
        org.junit.Assert.assertEquals("THROW:java.lang.NullPointerException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawDomainMarker(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,org.jfree.chart.axis.CategoryAxis,org.jfree.chart.plot.CategoryMarker,java.awt.geom.Rectangle2D):void",
            new int[]{1000,853,-147,-250,-532,922,338,-901,657,633,-1000,-752,247,-932,1000,1000,552,-427,961,850,-1000,1000,-1000,843,-860,-1000,1000,188,-1000,-741,1000,1000,49,-659,953,-877,-190,822,565,1000,681,425,1000,-344,1000,940,1000,-179,446,328,707,-875,856,-448,-262,-691,328,676,113,-883,-1000,-971,745,-767}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00079() {
        org.junit.Assert.assertEquals("THROW:java.lang.NullPointerException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawDomainMarker(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,org.jfree.chart.axis.CategoryAxis,org.jfree.chart.plot.CategoryMarker,java.awt.geom.Rectangle2D):void",
            new int[]{1000,-1000,364,-1000,-165,-75,-824,-238,-862,-1000,-246,1000,9,-596,-1000,-822,90,-210,604,261,-356,142,-345,895,452,724,266,373,-686,231,445,1000,654,150,-309,-214,375,213,1000,-426,-155,-532,140,-171,-958,1000,-402,-53,1000,1000,-71,-359,404,-1000,953,-995,486,-489,-509,149,372,966,141,-813}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00080() {
        org.junit.Assert.assertEquals("THROW:java.lang.NullPointerException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawDomainMarker(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,org.jfree.chart.axis.CategoryAxis,org.jfree.chart.plot.CategoryMarker,java.awt.geom.Rectangle2D):void",
            new int[]{-1000,1000,592,387,-1000,989,442,-716,1000,428,-146,-479,427,-115,400,1000,1000,-439,254,-320,252,1000,119,112,-1000,-207,-470,762,-225,-154,1000,801,576,384,-117,416,-1000,1000,-1000,1000,224,-330,-289,781,371,-417,-19,857,-559,-816,1000,-906,-391,239,142,818,-1000,-185,515,-1000,-1000,-1000,620,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00081() {
        org.junit.Assert.assertEquals("THROW:java.lang.NullPointerException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawDomainMarker(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,org.jfree.chart.axis.CategoryAxis,org.jfree.chart.plot.CategoryMarker,java.awt.geom.Rectangle2D):void",
            new int[]{280,242,23,332,1000,-1000,-716,-520,1000,-1000,299,1000,1000,1000,1000,1000,-1000,519,-527,-1000,1000,-174,-1000,641,501,1000,-1000,1000,-448,-1000,-1000,-1000,-1000,-1000,-1000,-93,1000,1000,792,1000,-1000,-1000,-1000,1000,-554,-1000,-1000,-505,-1000,363,-1000,1000,-227,1000,-343,-89,-1000,-419,1000,-1000,59,384,-494,-535}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00082() {
        org.junit.Assert.assertEquals("THROW:java.lang.NullPointerException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawDomainMarker(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,org.jfree.chart.axis.CategoryAxis,org.jfree.chart.plot.CategoryMarker,java.awt.geom.Rectangle2D):void",
            new int[]{-944,470,909,881,146,-315,151,-558,1000,-44,-553,-638,-651,529,-623,-589,67,382,724,-318,-900,544,1000,-108,-1000,-1000,-510,-13,576,326,1000,-34,-108,125,-204,-532,-756,520,-1000,251,744,301,198,-188,-400,717,-347,1000,913,-50,1000,-1000,12,-273,549,892,-514,-309,1000,-753,-932,-779,616,155}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00083() {
        org.junit.Assert.assertEquals("THROW:java.lang.NullPointerException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawDomainMarker(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,org.jfree.chart.axis.CategoryAxis,org.jfree.chart.plot.CategoryMarker,java.awt.geom.Rectangle2D):void",
            new int[]{-375,-492,664,1000,-923,1000,-1000,-361,1000,-982,515,282,-238,835,-949,-373,-363,872,937,-1000,1000,-863,471,1000,-288,1000,-367,379,629,-450,503,-585,-272,237,-1000,-7,635,-488,-1000,1000,-737,-463,-588,1000,-741,330,-633,369,-783,-659,41,-987,-933,200,93,393,-826,-977,-1000,336,350,-311,-1000,171}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00084() {
        org.junit.Assert.assertEquals("THROW:java.lang.NullPointerException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawDomainMarker(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,org.jfree.chart.axis.CategoryAxis,org.jfree.chart.plot.CategoryMarker,java.awt.geom.Rectangle2D):void",
            new int[]{-1000,-874,563,1000,49,201,-1000,-706,157,-1000,972,1000,867,1000,-75,271,1000,114,900,-675,1000,-1000,930,96,-978,1000,-1000,1000,211,883,-1000,1000,-107,1000,-1000,-478,1000,1000,-663,1000,-847,-921,-1000,-621,-636,-485,-1000,136,-1000,739,-1000,-50,-1000,-449,905,152,-896,-1000,-1000,-388,1000,5,-465,864}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00085() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawOutline(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,java.awt.geom.Rectangle2D):void",
            new int[]{-415,274,-6,-715,-298,-364,437,-238,99,1000,1000,-536,1000,541,603,303,-342,-1000,1000,442,-572,835,-1000,1000,-37,-1000,-367,-667,-803,-659,881,886,-215,-817,104,188,657,-713,1000,395,-803,-663,1000,-263,-32,607,4,-1000,446,-105,-974,43,-629,241,-905,-792,1000,-891,-369,-258,1000,-357,904,742}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00086() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawOutline(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,java.awt.geom.Rectangle2D):void",
            new int[]{232,937,159,-196,767,-1000,739,-873,-950,465,388,59,350,629,652,-162,-1000,-614,362,781,-400,160,-840,-4,-750,249,-1000,-902,5,-707,565,-156,36,167,-189,-12,-129,-860,1000,234,-1000,284,517,-1000,1000,41,-1000,-94,-681,657,-236,-1000,-901,641,-586,-264,551,266,-1000,-1000,83,-778,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00087() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawOutline(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,java.awt.geom.Rectangle2D):void",
            new int[]{1000,810,914,1000,-1000,-161,-425,89,-699,-794,793,1000,1000,1000,-1000,921,-916,-399,1000,1000,-1000,1000,249,558,-467,-1000,-613,1000,-946,1000,-1000,209,-1000,1000,1000,528,-1000,-839,429,-664,411,-371,-120,1000,711,-1000,-1000,-1000,850,-61,-1000,-790,1000,467,1000,672,1000,491,-1000,438,-462,-1000,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00088() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawOutline(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,java.awt.geom.Rectangle2D):void",
            new int[]{784,-402,584,759,-1000,-299,-235,-443,-575,656,267,848,806,132,-887,-304,-851,-355,293,467,-1000,492,-364,-333,-993,560,557,314,-908,-113,-368,1000,-271,-809,148,-56,-987,-612,-523,-478,149,-1,758,1000,1000,-517,-1000,-400,-291,257,-214,74,557,-252,1000,-400,714,20,-1000,-590,261,-599,283,814}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00089() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawOutline(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,java.awt.geom.Rectangle2D):void",
            new int[]{871,911,-236,314,-344,-382,452,-463,-6,108,829,129,670,1000,-1000,921,-960,549,1000,1000,-1000,606,-64,773,-490,-1000,13,7,-354,-7,191,-300,-961,1000,919,-545,-1000,-684,1000,998,-676,63,153,337,780,-1000,-1000,-652,-1000,57,-1000,-1000,21,1000,-283,-172,1000,-916,-1000,-342,-1000,-1000,823,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00090() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawOutline(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,java.awt.geom.Rectangle2D):void",
            new int[]{1000,-458,193,47,-1000,610,-321,-115,-57,1000,1000,1000,524,-729,116,-1000,-798,-202,311,467,-1000,798,-512,-472,-1000,1000,1000,150,-1000,-92,-694,1000,135,-1000,-925,94,-987,-1000,-1000,-1000,-1000,-624,806,-1000,1000,339,-1000,-595,1000,502,326,700,-1000,-1000,1000,-404,464,-585,-1000,-242,-1000,-445,1000,557}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00091() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawOutline(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,java.awt.geom.Rectangle2D):void",
            new int[]{938,1000,712,-120,-1000,-401,-1000,1000,622,528,728,886,297,-176,1000,-1000,1000,-1000,134,334,641,1000,1000,-439,-145,-329,1000,-386,-695,620,-1000,175,-575,-246,1000,561,-1000,-457,-1000,-233,1000,1000,-318,1000,844,370,32,456,354,1000,-1000,1000,1000,-1000,508,1000,601,400,-473,1000,-778,-1000,1000,7}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00092() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawOutline(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,java.awt.geom.Rectangle2D):void",
            new int[]{273,-400,-628,109,1000,625,542,-1000,-1000,1000,1000,978,117,699,272,286,-927,1000,719,647,-63,538,-1000,813,-1000,733,1000,-1000,-1000,-1000,1000,804,-258,-1000,-719,-1000,-380,-396,-277,-825,-1000,-1000,95,-171,1000,-1000,-1000,-1000,490,238,590,-1000,865,1000,542,-1000,265,-1000,-507,-1000,1000,-540,457,799}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00093() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawOutline(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,java.awt.geom.Rectangle2D):void",
            new int[]{-772,54,233,-478,644,-294,998,839,622,-528,124,-671,-75,-40,1000,115,760,473,-112,-828,313,-930,1000,92,-145,-329,-716,-714,6,-335,1000,-720,-283,-196,-40,-751,258,91,617,-766,-506,1000,-670,-400,844,414,838,456,543,-1000,58,-293,-337,-420,498,-617,-683,121,477,438,230,-117,-21,-778}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00094() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawOutline(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,java.awt.geom.Rectangle2D):void",
            new int[]{-145,503,18,840,-913,-440,621,88,-419,98,-828,-420,1000,132,-887,791,-813,-355,1000,-20,244,528,-77,1000,-993,-1000,557,1000,-103,707,218,-286,-35,1000,1000,-816,400,-197,-523,1000,-245,1000,497,1000,1000,-1000,117,-379,-1000,-558,-1000,-1000,1000,959,623,57,1000,71,-487,-860,289,-599,283,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00095() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawOutline(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,java.awt.geom.Rectangle2D):void",
            new int[]{910,-1000,488,485,-1000,-977,1000,1000,1000,-400,1000,155,113,-778,-71,-1000,1000,-1000,-957,-1000,-11,-1000,-1000,-934,227,-814,1000,973,688,282,-640,-860,-919,1000,955,1000,-1000,1000,-1000,350,1000,1000,-488,1000,-1000,1000,1000,733,-851,641,297,1000,1000,-1000,-400,1000,-273,400,-94,1000,-1000,-686,1000,-295}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00096() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawRangeMarker(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,org.jfree.chart.axis.ValueAxis,org.jfree.chart.plot.Marker,java.awt.geom.Rectangle2D):void",
            new int[]{511,128,419,-2,1000,432,173,-977,-151,-605,-570,1000,-454,1000,-344,-1000,68,-699,1000,-301,120,-515,1000,-1000,366,407,1000,874,260,-650,1000,1000,1000,-369,-1000,-549,1000,1000,599,770,96,763,153,-453,40,1000,687,-143,1000,46,-489,-773,-1000,705,-600,-782,454,-139,-263,1000,-307,-33,-494,297}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00097() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawRangeMarker(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,org.jfree.chart.axis.ValueAxis,org.jfree.chart.plot.Marker,java.awt.geom.Rectangle2D):void",
            new int[]{128,-118,789,-495,-200,376,400,1000,-1000,-465,-1000,-963,731,-352,956,602,-240,-106,-1000,14,178,-1000,-647,-1000,685,-259,526,1000,-44,382,-39,1000,-227,1000,697,568,-739,-917,-1000,531,-1000,411,200,1000,871,1000,762,-681,-1000,1000,131,1000,514,-373,959,1000,-273,-1000,-1000,354,1000,-905,714,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00098() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawRangeMarker(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,org.jfree.chart.axis.ValueAxis,org.jfree.chart.plot.Marker,java.awt.geom.Rectangle2D):void",
            new int[]{-499,-1000,573,59,-934,546,-320,697,-1000,-185,285,-164,-54,-156,1000,336,-379,-286,-730,-1000,-631,-914,699,-470,362,-1000,-696,509,178,-421,81,866,181,1000,603,235,-564,56,-1000,-494,-1000,-1000,747,1000,1000,930,60,433,-116,-303,-278,222,154,1,-433,361,575,899,-613,-781,1000,-1000,1000,425}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00099() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawRangeMarker(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,org.jfree.chart.axis.ValueAxis,org.jfree.chart.plot.Marker,java.awt.geom.Rectangle2D):void",
            new int[]{152,-405,354,-373,-866,-63,-1000,723,-700,-1000,-233,282,-856,222,394,454,103,-672,-61,-1000,136,31,651,-1000,-1000,-365,712,583,296,233,-214,67,281,480,-1000,380,1000,1000,-71,50,50,-212,1000,681,1000,1000,-514,-412,86,627,-1000,775,87,25,-830,909,332,448,-1000,-185,250,-848,980,719}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00100() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawRangeMarker(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,org.jfree.chart.axis.ValueAxis,org.jfree.chart.plot.Marker,java.awt.geom.Rectangle2D):void",
            new int[]{-171,-841,409,368,-513,469,-694,-223,-970,-802,-113,-164,-391,-156,257,-740,-771,-753,135,-810,-730,-575,895,-677,-26,-798,174,420,23,-781,384,866,614,681,-238,50,305,964,-524,346,-706,-909,750,663,755,986,-35,-283,429,429,-750,449,-286,658,-761,341,193,-314,-700,-212,736,-407,863,116}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00101() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawRangeMarker(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,org.jfree.chart.axis.ValueAxis,org.jfree.chart.plot.Marker,java.awt.geom.Rectangle2D):void",
            new int[]{349,-841,568,-307,1000,743,838,-1000,-191,-342,-602,-164,-829,1000,-654,-1000,495,-842,1000,-410,375,-648,1000,-1000,950,1000,1000,1000,491,-1000,1000,1000,1000,-1000,-1000,-1000,1000,1000,835,346,673,1000,750,663,-83,986,-35,413,1000,171,-639,-642,-286,930,-656,-1000,1000,376,-130,-212,-1000,119,-1000,504}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00102() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawRangeMarker(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,org.jfree.chart.axis.ValueAxis,org.jfree.chart.plot.Marker,java.awt.geom.Rectangle2D):void",
            new int[]{1000,480,-526,238,1000,-621,1000,-1000,-181,1000,559,1000,-765,375,-691,211,1000,1000,75,1000,1000,678,-444,213,1000,1000,-1000,-294,-1000,312,880,238,949,-683,-336,-984,516,4,-785,-1000,307,1000,1000,664,-136,-1000,1000,510,240,-927,-202,222,678,-622,-344,-1000,1000,1000,-154,-118,1000,896,-1000,-600}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00103() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawRangeMarker(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,org.jfree.chart.axis.ValueAxis,org.jfree.chart.plot.Marker,java.awt.geom.Rectangle2D):void",
            new int[]{713,744,-468,124,1000,-1000,1000,-1000,506,483,320,1000,-732,382,-715,-437,1000,-165,1000,250,264,1000,249,-941,768,1000,720,-642,167,80,314,1000,253,-65,-603,-271,803,-1000,779,179,193,1000,-1000,-1000,-51,-181,879,-545,386,-1000,-505,-810,-190,-43,-475,-1000,457,-24,-612,916,159,1000,-1000,-621}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00104() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawRangeMarker(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,org.jfree.chart.axis.ValueAxis,org.jfree.chart.plot.Marker,java.awt.geom.Rectangle2D):void",
            new int[]{999,145,39,-36,702,-332,-385,-96,844,-937,-991,662,-700,988,-422,-242,-331,-81,-355,569,537,264,571,184,430,-265,775,619,-349,392,642,454,529,579,-463,-32,431,693,48,910,-717,666,6,223,-643,890,-171,-796,-444,-632,-681,-122,-398,-128,151,684,-904,-979,-18,-37,732,384,-620,191}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00105() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawRangeMarker(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,org.jfree.chart.axis.ValueAxis,org.jfree.chart.plot.Marker,java.awt.geom.Rectangle2D):void",
            new int[]{742,-680,-311,437,-756,-629,246,25,-888,788,660,114,-219,-891,259,851,789,586,-812,284,219,411,-591,479,-608,68,-651,-980,-721,512,-627,-828,384,601,-427,60,707,12,-787,239,-195,739,658,225,912,-825,-426,-280,-343,-198,-231,-445,979,-487,-828,714,-497,753,-866,-850,879,-203,490,-376}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00106() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawRangeMarker(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,org.jfree.chart.axis.ValueAxis,org.jfree.chart.plot.Marker,java.awt.geom.Rectangle2D):void",
            new int[]{-128,-1,561,-48,1000,769,231,-923,-764,-479,-991,662,-785,1000,-234,-1000,-92,-880,1000,-766,-220,-690,1000,-1000,676,394,578,1000,325,-1000,1000,454,1000,-505,-868,-628,719,1000,49,-493,112,-157,187,-117,418,1000,1000,315,1000,439,-821,213,-1000,897,-769,-568,1000,254,-436,900,732,-143,-210,377}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00107() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawRangeMarker(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,org.jfree.chart.axis.ValueAxis,org.jfree.chart.plot.Marker,java.awt.geom.Rectangle2D):void",
            new int[]{960,-136,704,1000,914,1000,1000,-869,-918,-25,-1000,-48,-262,119,-362,-1000,-295,806,559,-1000,-904,1000,-1000,1000,1000,-1000,1000,421,-1000,-58,72,1000,-200,1000,-568,-1000,234,-39,-379,-627,-37,199,1000,51,40,-1000,1000,-1000,982,-1000,1000,258,520,918,-106,115,170,-1000,1000,-165,1000,1000,-1000,-613}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00108() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "drawRangeMarker(java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,org.jfree.chart.axis.ValueAxis,org.jfree.chart.plot.Marker,java.awt.geom.Rectangle2D):void",
            new int[]{1000,396,188,-842,72,47,-569,927,221,-956,-1000,650,-646,1000,614,1000,571,462,-812,-27,1000,115,351,-301,1,1000,982,1000,-397,1000,220,227,105,348,-624,184,601,785,-87,367,-441,681,304,530,-150,906,-246,-269,-924,67,-776,1000,-27,-765,-25,985,-455,-343,-313,-638,410,-182,-154,909}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00109() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "equals(java.lang.Object):boolean",
            new int[]{-527,314,-586,918,979,269,-852,722,805,400,-677,-297,-95,-959,-573,302,-332,264,-1000,-775,62,131,1000,1000,1000,817,259,-563,-680,329,95,-105,394,204,-707,1000,763,-805,667,-173,1000,-1000,-835,1000,764,530,245,-246,-441,-1000,1000,-623,130,-724,-1000,94,423,-98,911,604,299,-1000,-290,-169}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00110() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "equals(java.lang.Object):boolean",
            new int[]{-613,-717,153,730,678,1000,6,-211,240,-400,-760,-1000,564,-608,-1000,-527,56,-1000,192,545,-748,-1000,458,-305,880,-269,-709,-474,-1000,-130,-247,271,60,-1000,146,1000,542,-1000,-202,-428,738,-245,-449,-177,501,-535,854,-272,-920,-413,713,-895,887,-262,186,642,933,586,1000,-1000,-1000,695,689,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00111() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "equals(java.lang.Object):boolean",
            new int[]{-673,314,-586,17,132,256,-852,1000,-139,1000,827,469,-1000,-892,-546,302,1000,-444,602,1000,62,520,583,-1000,-21,-488,1000,476,1000,1000,1000,-1000,-1000,377,162,1000,-683,-1000,-75,-173,144,-1000,-718,-329,1000,-1000,-840,-1000,-441,299,799,162,-398,-548,-541,-224,51,-189,632,-890,299,-560,-1000,-348}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00112() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "equals(java.lang.Object):boolean",
            new int[]{-1000,546,699,883,-57,-44,-179,610,-350,1000,193,5,-565,-645,-391,351,-1000,806,-705,911,-533,616,1000,208,1000,506,679,-315,1000,899,-292,-578,-545,534,704,913,-565,-1000,777,-1000,1000,-372,-1000,392,1000,-498,-79,-466,1000,-59,1000,-461,-1000,358,-345,-294,176,-1000,873,-24,345,-371,-843,-79}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00113() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "equals(java.lang.Object):boolean",
            new int[]{1000,-614,-692,-622,34,-657,-594,-156,200,1000,321,1000,-1000,-300,1000,-127,-1000,958,712,276,1000,170,1000,-465,-1000,-342,1000,-292,-197,1000,-1000,-1000,-1000,242,1000,617,682,-765,-1000,1000,-1000,-1000,-1000,242,-830,-1000,-1000,-439,-1000,-232,-200,1000,1000,-794,746,-1000,-483,-895,-716,704,-1000,1000,1000,-245}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00114() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "equals(java.lang.Object):boolean",
            new int[]{640,246,-352,-400,571,360,859,117,389,400,-576,651,-400,-721,400,-677,571,1000,-714,-1000,400,-752,-127,698,-45,331,-244,-817,-311,467,7,-171,746,-342,960,482,936,806,398,400,-400,-1000,-953,795,1000,-80,-400,743,-1000,-1000,318,400,1000,-829,-438,-432,-32,112,49,-676,-1000,-779,-400,-447}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00115() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "equals(java.lang.Object):boolean",
            new int[]{219,279,346,-248,842,340,1000,864,1000,-1000,-1000,-19,595,-561,-560,9,558,58,-68,-857,1000,-390,1000,1000,429,973,-1000,-1000,-440,1000,741,129,398,257,-531,617,682,801,-378,-764,144,1000,-317,937,-738,1000,-1000,1000,1000,-1000,373,-413,1000,-563,-1000,351,593,-895,34,-179,-904,-545,609,-495}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00116() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "equals(java.lang.Object):boolean",
            new int[]{331,639,-12,-868,-833,-320,1000,1000,822,1000,296,494,-765,497,-69,-30,-874,1000,-644,-1000,-627,971,557,-877,-1000,167,787,-989,1000,936,-1000,-530,-355,1000,114,-328,-167,112,-704,818,862,861,-917,539,-129,1000,-597,1000,-924,344,618,-265,-669,1000,801,733,-635,-832,-1000,-1000,208,632,-1000,559}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00117() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "equals(java.lang.Object):boolean",
            new int[]{-282,586,98,-425,1000,-669,1000,260,289,1000,-1000,-195,-325,429,440,747,770,251,-628,-677,587,1000,349,-271,400,258,-1000,-472,-890,-400,882,355,1000,98,1000,-530,970,1000,-197,-20,588,-216,-225,291,-80,817,-877,523,197,292,-41,1000,180,212,167,-462,-102,586,-1000,-98,-514,-735,-176,-353}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00118() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "equals(java.lang.Object):boolean",
            new int[]{-106,201,282,790,1000,1000,-76,698,1000,-1000,-375,-460,936,-388,-1000,39,324,-242,825,-473,-1000,-924,1000,990,1000,73,-530,-992,-339,-780,596,482,993,-826,49,978,884,64,700,-1000,915,376,-745,241,-58,609,1000,101,1000,-797,858,-1000,-1000,-1000,-1000,791,1000,-184,544,-77,-929,-545,1000,-762}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00119() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "equals(java.lang.Object):boolean",
            new int[]{-34,213,-598,879,163,-154,587,-584,829,-241,-793,363,-8,-199,-370,-867,164,485,595,146,670,483,-157,-356,-608,-750,418,-898,-31,275,159,-637,968,303,633,-167,920,942,262,-397,-694,-468,707,208,499,-103,-269,859,-485,642,-316,476,1000,-965,527,617,296,198,-107,-537,-323,323,42,-536}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00120() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "equals(java.lang.Object):boolean",
            new int[]{-615,133,-771,1000,423,1000,-54,359,101,-1000,142,-256,421,215,-1000,107,490,-172,145,-536,-948,-1000,4,140,575,-903,-407,-68,141,-1000,740,-613,-326,-791,-142,276,430,-546,439,-1000,1000,-955,-1000,326,22,1000,773,-442,-1000,318,1000,-1000,-500,-140,-1000,1000,1000,-750,-698,432,-517,-1000,1000,-536}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00121() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "equals(java.lang.Object):boolean",
            new int[]{47,-138,-658,140,580,973,-911,583,853,-324,-260,-843,602,-527,-944,905,-528,-548,63,478,-401,-664,981,-445,994,-430,-213,-605,954,-782,204,-93,-690,215,601,816,650,-306,-183,-951,822,475,218,-710,10,-390,462,-198,470,-125,358,-909,-406,-473,-7,747,419,-730,874,-109,-110,414,186,-936}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00122() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "equals(java.lang.Object):boolean",
            new int[]{818,0,-8,-650,-636,-610,-785,1000,-302,-743,-783,-962,1000,103,95,852,-1000,-931,-1000,753,15,-9,1000,598,-207,667,-215,-1000,1000,205,-1000,-80,-1000,1000,549,-82,1000,-655,308,136,326,1000,-485,2,-155,-768,546,-620,342,-971,-450,528,188,1000,1000,-329,-345,92,1000,1000,-283,1000,-740,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00123() {
        org.junit.Assert.assertEquals("TYPE:org.jfree.data.Range", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "findRangeBounds(org.jfree.data.category.CategoryDataset):org.jfree.data.Range",
            new int[]{-455,-723,294,710,105,-179,447,-1000,-607,-585,-613,-487,-1000,-737,674,-929,-590,-1000,976,-279,-587,-165,-217,212,459,-1000,503,-55,78,89,-8,1000,-777,322,-268,-278,597,785,-116,18,-881,-1000,611,557,-1000,1000,-240,-678,212,-429,-940,938,540,837,202,803,570,-56,-1000,-549,-1000,-293,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00124() {
        org.junit.Assert.assertEquals("TYPE:org.jfree.data.Range", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "findRangeBounds(org.jfree.data.category.CategoryDataset):org.jfree.data.Range",
            new int[]{792,-826,-596,-177,648,-1000,186,-616,874,1000,1000,733,-1000,-469,-1000,-929,-699,-662,1000,-279,931,-668,-542,592,696,-1000,1000,733,78,-334,280,1000,400,-1000,-1000,1000,718,803,-89,-53,-881,443,-737,503,10,212,400,699,400,244,881,-335,195,-402,1000,164,-501,1000,-1000,-549,1000,-672,-282,618}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00125() {
        org.junit.Assert.assertEquals("TYPE:org.jfree.data.Range", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "findRangeBounds(org.jfree.data.category.CategoryDataset):org.jfree.data.Range",
            new int[]{-405,-953,289,347,-338,-641,763,-410,-353,-464,1000,-10,116,85,311,49,-974,-1000,863,-580,-207,-604,-1000,430,-423,-1000,972,-55,198,-1000,-8,496,-777,322,-268,-53,252,1000,-123,-120,-575,1000,352,286,-945,1000,-38,-243,215,-429,344,973,-282,5,580,621,108,43,-222,635,-94,-544,589,656}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00126() {
        org.junit.Assert.assertEquals("TYPE:org.jfree.data.Range", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "findRangeBounds(org.jfree.data.category.CategoryDataset):org.jfree.data.Range",
            new int[]{-875,-518,-646,-57,-384,588,-1000,316,-1000,1000,1000,1000,-128,1000,-836,1000,-126,-550,928,1000,-1000,747,-539,548,-784,493,1000,1000,175,604,-1000,-828,-466,-1000,717,1000,-81,1000,791,-118,570,701,-1000,1000,183,1000,357,-863,1000,-632,289,305,-1000,651,86,-1000,-250,1000,713,-934,-1000,-1000,690,842}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00127() {
        org.junit.Assert.assertEquals("TYPE:org.jfree.data.Range", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "findRangeBounds(org.jfree.data.category.CategoryDataset):org.jfree.data.Range",
            new int[]{340,-620,146,-8,173,-545,-155,-920,655,906,781,669,85,-564,-427,278,259,43,855,934,781,769,-732,684,-801,902,667,68,-264,-404,-230,-569,915,-672,-521,994,-731,892,-678,564,484,648,-876,474,851,703,845,889,664,325,781,958,-634,457,-155,480,-350,486,-550,701,466,-423,725,-318}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00128() {
        org.junit.Assert.assertEquals("TYPE:org.jfree.data.Range", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "findRangeBounds(org.jfree.data.category.CategoryDataset):org.jfree.data.Range",
            new int[]{-790,1000,-652,-1000,-66,159,-1000,703,-931,-277,-438,1000,-205,328,182,1000,1000,-625,-59,105,744,91,-1000,707,-1000,-222,247,-1000,-906,-1000,1000,630,1000,-126,540,-1000,-290,1000,-995,600,1000,1000,-978,994,-79,-678,-1000,932,396,-279,1000,-1000,-1000,289,-1000,-1000,327,1000,1000,1000,1000,-367,-1000,-805}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00129() {
        org.junit.Assert.assertEquals("TYPE:org.jfree.data.Range", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "findRangeBounds(org.jfree.data.category.CategoryDataset):org.jfree.data.Range",
            new int[]{-1000,-663,-371,-869,-761,225,798,925,-673,1000,104,628,579,723,-1000,826,-1000,-1000,-729,390,-676,-1000,-248,-463,-17,163,1000,1000,380,-356,1000,-558,468,-1000,220,783,-1000,199,600,-544,-1000,350,-873,1000,-312,-817,-104,-697,215,-609,-339,225,-1000,689,129,859,-312,-454,-1000,-1000,-734,-492,-786,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00130() {
        org.junit.Assert.assertEquals("TYPE:org.jfree.data.Range", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "findRangeBounds(org.jfree.data.category.CategoryDataset):org.jfree.data.Range",
            new int[]{654,73,-175,-412,153,900,-341,-104,-283,-1000,83,-968,-1000,304,1000,121,-590,-234,1000,-300,207,482,942,-20,1000,-944,-720,72,-151,-209,-42,1000,-234,902,-1000,-178,503,238,-989,-714,-25,-1000,582,821,-794,-322,-342,-74,-896,703,-994,306,780,1000,-988,803,-794,22,-807,-358,67,-433,238,-375}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00131() {
        org.junit.Assert.assertEquals("TYPE:org.jfree.data.Range", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "findRangeBounds(org.jfree.data.category.CategoryDataset):org.jfree.data.Range",
            new int[]{-1000,-300,967,651,344,-446,745,-1000,-607,-177,-573,-813,-1000,-358,339,-1000,-1000,-1000,976,-91,-1000,-152,-182,509,1000,-1000,1000,561,457,85,1000,1000,-1000,-386,-257,-326,521,787,-516,-242,-1000,-1000,738,1000,-1000,1000,-419,-762,-552,-626,-1000,1000,-81,1000,571,1000,789,-228,-116,-1000,-1000,-1000,1000,729}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00132() {
        org.junit.Assert.assertEquals("TYPE:org.jfree.data.Range", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "findRangeBounds(org.jfree.data.category.CategoryDataset):org.jfree.data.Range",
            new int[]{-479,-300,967,733,-153,619,29,-165,137,-1000,-1000,-1000,-1000,-358,1000,-729,-186,-1000,-129,1000,-545,-152,-539,-822,1000,-940,-91,-1000,581,604,1000,-828,-848,1000,-795,-1000,1000,-1000,206,428,-342,-1000,-1000,-95,-784,569,-974,679,-823,412,-1000,316,1000,607,-247,884,593,-1000,-116,153,-1000,217,358,14}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00133() {
        org.junit.Assert.assertEquals("TYPE:org.jfree.data.Range", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "findRangeBounds(org.jfree.data.category.CategoryDataset):org.jfree.data.Range",
            new int[]{-1000,-905,-641,1000,-1000,290,1000,192,-422,753,1000,-557,1000,1000,-790,691,1000,59,204,442,-1000,-857,499,361,1000,-869,809,1000,958,-14,1000,-1000,-894,-688,1000,1000,-263,449,-154,-1000,169,-50,-1000,-76,-1000,-92,427,-1000,224,-1000,-1000,1000,546,680,-99,-513,799,-413,678,860,-1000,-320,-647,-125}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00134() {
        org.junit.Assert.assertEquals("TYPE:org.jfree.data.Range", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "findRangeBounds(org.jfree.data.category.CategoryDataset):org.jfree.data.Range",
            new int[]{-820,-664,-652,1000,-467,88,-139,-157,-836,138,-375,304,594,735,-94,551,-410,-625,788,105,-1000,-423,163,649,1000,-271,611,653,25,-1000,1000,280,-1000,61,1000,858,746,850,-995,838,825,640,-198,332,-826,1000,-1000,-1000,552,-1000,-1000,1000,-88,-780,-1000,-1000,327,-1000,448,714,366,-831,1000,508}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00135() {
        org.junit.Assert.assertEquals("TYPE:org.jfree.data.Range", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "findRangeBounds(org.jfree.data.category.CategoryDataset):org.jfree.data.Range",
            new int[]{-855,-858,-201,482,-193,-487,103,-157,-492,-76,755,686,594,551,-281,501,-697,-526,804,-400,-352,-501,-326,607,-260,-271,960,109,253,-1000,1000,280,-1000,370,1000,352,-226,1000,-1000,-599,1000,-573,74,257,-826,1000,-610,-775,-762,-1000,-171,1000,-774,-825,-127,-1000,-644,1000,448,1000,1000,-810,412,508}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00136() {
        org.junit.Assert.assertEquals("TYPE:org.jfree.data.Range", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "findRangeBounds(org.jfree.data.category.CategoryDataset):org.jfree.data.Range",
            new int[]{1000,35,-194,-751,153,594,709,-117,-54,-209,-250,-1000,-413,349,241,121,-1000,72,585,-169,778,982,1000,405,1000,-1000,-655,391,82,-1000,-81,-804,455,-12,-791,768,-426,6,-989,-1000,-939,-758,-117,1000,-631,-1000,-989,-173,-910,349,-632,551,500,1000,-557,1000,-994,-260,-960,-1000,-294,-228,189,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00137() {
        org.junit.Assert.assertEquals("TYPE:org.jfree.data.Range", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "findRangeBounds(org.jfree.data.category.CategoryDataset):org.jfree.data.Range",
            new int[]{-814,123,-1000,-1000,144,307,-284,904,-593,1000,1000,1000,-20,712,-1000,335,-392,-19,-827,1000,-743,-1000,-787,1000,-503,-876,1000,1000,1000,499,-786,-1000,1000,-1000,981,1000,-1000,559,1000,434,-1000,1000,-1000,1000,1000,739,1000,-169,1000,1000,1000,-1000,-1000,1000,1000,-1000,-65,378,658,-843,-1000,-1000,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00138() {
        org.junit.Assert.assertEquals("TYPE:org.jfree.data.Range", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "findRangeBounds(org.jfree.data.category.CategoryDataset):org.jfree.data.Range",
            new int[]{635,-455,238,-1000,960,-487,-574,-702,308,-36,-194,-41,-413,-101,179,-69,-214,-1000,1000,-1000,1000,1000,677,717,-260,-710,896,391,253,-1000,-81,476,349,-12,-329,768,-426,913,-1000,-599,0,-758,1000,613,-782,-698,-701,52,-907,-1000,-114,885,-675,-125,316,717,-1000,74,-1000,-407,1000,-587,-399,-310}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00139() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getBaseItemLabelGenerator():org.jfree.chart.labels.CategoryItemLabelGenerator",
            new int[]{585,-1000,788,788,315,1000,-1000,-33,843,-689,-299,209,388,-341,-124,-1000,-1000,-62,-162,-688,190,500,-1000,-384,1000,750,-709,-983,-896,1000,-1000,-612,-1000,-841,1000,61,-1000,-1000,-1000,-647,476,267,128,1000,-1000,823,411,1000,1000,-445,-215,-685,-1000,924,222,1000,1000,887,435,-768,-7,237,-1000,-126}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00140() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getBaseItemLabelGenerator():org.jfree.chart.labels.CategoryItemLabelGenerator",
            new int[]{-527,932,-148,309,322,175,395,319,200,41,-521,-596,-532,-15,-834,-1000,-953,-1000,-44,-1000,808,-437,-145,10,-1000,195,-529,1000,573,1000,-412,-1000,-441,1000,928,894,323,1000,-106,780,-1000,441,-1000,-1000,1000,365,239,1000,-812,338,1000,36,-77,396,1000,708,-814,1000,1000,-938,-602,-1000,-1000,651}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00141() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getBaseItemLabelGenerator():org.jfree.chart.labels.CategoryItemLabelGenerator",
            new int[]{-1000,-416,-281,-728,-57,852,-781,-1000,1000,-927,179,1000,-1000,-542,-45,257,-370,275,1000,310,-432,-655,450,-646,139,336,333,-256,-374,616,-101,-859,-1000,-726,348,1000,1000,1000,-199,106,1000,589,1000,1000,715,-335,-637,-68,153,952,1000,1000,-923,722,-1000,-999,1000,1000,-1000,-450,-706,-1000,82,-59}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00142() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getBaseItemLabelGenerator():org.jfree.chart.labels.CategoryItemLabelGenerator",
            new int[]{763,508,348,1000,1000,-271,-83,1000,922,-1000,151,1000,-707,-542,-45,978,1000,-731,-1000,-586,1000,0,-1000,1000,247,-587,-978,-626,225,-1000,-101,1000,-683,-1000,-804,-256,512,1000,1000,-734,-1000,441,303,-121,907,79,-653,-890,-830,880,-1000,1000,193,196,-399,-999,124,399,-1000,-309,1000,1000,694,-400}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00143() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getBaseItemLabelGenerator():org.jfree.chart.labels.CategoryItemLabelGenerator",
            new int[]{-95,-888,159,626,112,238,-730,-667,861,540,-1000,-708,748,-1000,-177,-953,451,470,-62,-589,267,498,-377,208,509,1000,699,264,-876,1000,-1000,-635,-516,-841,1000,421,-1000,-561,-1000,-20,-601,806,-478,-761,321,1000,350,-475,978,-1000,303,-205,486,534,454,1000,-199,70,-244,89,-449,34,-855,314}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00144() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getBaseItemLabelGenerator():org.jfree.chart.labels.CategoryItemLabelGenerator",
            new int[]{158,-467,-201,1000,1000,863,-547,188,973,1000,-955,928,1000,-216,1000,0,583,216,1000,-490,-1000,-441,883,-439,1000,919,333,1000,-1000,1000,111,0,632,-743,1000,141,1000,-1000,362,-696,-863,664,19,1000,-1000,972,1000,-921,-57,907,-1000,-282,-697,892,526,513,773,880,-274,23,1000,1000,-1000,812}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00145() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getBaseItemLabelGenerator():org.jfree.chart.labels.CategoryItemLabelGenerator",
            new int[]{-1000,-754,244,1000,1000,-327,86,-397,468,967,-177,-1000,357,-608,-38,-944,-873,395,490,933,-394,-199,357,-954,241,1000,-222,1000,-1000,904,867,-168,955,-1000,970,392,549,-64,821,-479,-1000,153,668,-886,-495,202,1000,-1000,928,-708,-352,571,-702,289,-780,729,254,-290,32,1000,930,1000,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00146() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getBaseItemLabelGenerator():org.jfree.chart.labels.CategoryItemLabelGenerator",
            new int[]{-1000,914,-273,-1000,493,-652,1000,-569,509,51,1000,265,609,-454,-306,1000,1000,-1000,272,1000,-299,-398,1000,-628,889,213,558,-1000,-732,-1000,-918,1000,1000,-509,-1000,1000,1000,-157,1000,-531,952,743,1000,1000,-1000,214,-87,-1000,-128,1000,-352,625,655,-464,-1000,-1000,1000,-369,-1000,-877,1000,1000,128,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00147() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getBaseItemLabelGenerator():org.jfree.chart.labels.CategoryItemLabelGenerator",
            new int[]{-11,41,386,269,-230,-1000,1000,-940,-29,1000,932,-1000,-168,-329,240,321,-494,500,1000,1000,-163,255,402,-1000,-251,1000,-73,-1000,-1000,-208,256,-23,1000,1000,351,588,1000,194,783,17,-929,288,546,-835,-1000,1000,1000,-955,434,-842,724,558,665,-758,104,-1000,49,-900,-440,310,1000,65,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00148() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getBaseItemLabelGenerator():org.jfree.chart.labels.CategoryItemLabelGenerator",
            new int[]{-484,-398,-961,-1000,-4,-61,90,-587,-6,339,319,-193,-1000,-156,1000,-1000,-700,-433,1000,-400,-971,-305,861,-40,-385,895,808,-1000,-812,375,343,482,-867,56,1000,769,142,1000,-880,862,300,162,804,462,-862,960,635,-975,-24,580,914,491,-504,-304,-846,-1000,1000,817,162,1000,-521,208,206,-13}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00149() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getBaseItemLabelGenerator():org.jfree.chart.labels.CategoryItemLabelGenerator",
            new int[]{368,-1000,-138,-186,322,175,-730,-211,991,-366,-1000,91,288,-645,-28,129,1000,-360,-286,-248,-299,939,-145,16,1000,213,539,-694,-339,568,-1000,-308,-1000,-1000,879,469,-812,-777,-512,-67,186,153,903,1000,-590,369,531,-1000,758,22,-1000,87,-265,932,-946,1000,518,621,-774,320,-56,1000,501,3}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00150() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getBaseItemLabelGenerator():org.jfree.chart.labels.CategoryItemLabelGenerator",
            new int[]{682,-294,423,857,22,910,-1000,-250,814,294,-1000,-530,306,-1000,-31,-1000,-747,696,20,-908,106,208,-481,-301,299,661,370,548,-1000,599,-1000,-268,-308,-772,1000,-1000,-1000,-312,-888,-50,-125,845,-845,1000,728,1000,535,857,692,-1000,862,-182,232,431,1000,1000,-506,214,250,-788,-300,-380,-1000,-114}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00151() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getBaseItemLabelGenerator():org.jfree.chart.labels.CategoryItemLabelGenerator",
            new int[]{-561,-172,562,-697,690,257,337,503,1000,-1000,-1000,658,-526,109,-343,-632,-164,-534,-253,-625,204,76,405,1000,455,-469,-265,-507,464,435,-854,1000,-1000,-132,1000,61,-798,1000,866,-600,102,611,983,20,684,-548,376,-213,-640,157,-932,-205,-874,853,-869,770,788,376,-1000,558,-238,696,981,-66}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00152() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getBaseItemLabelGenerator():org.jfree.chart.labels.CategoryItemLabelGenerator",
            new int[]{-38,1000,-299,-59,-525,-199,937,999,177,-175,275,-137,-1000,445,418,-893,-459,-48,-107,-1000,336,432,380,897,-1000,-1000,227,1000,772,25,112,407,-1000,1000,641,-607,1000,1000,1000,405,-1000,36,-607,639,1000,-656,249,582,-1000,1000,1000,434,445,-36,1000,-256,-1000,1000,360,-371,356,34,1000,-130}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00153() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getBaseToolTipGenerator():org.jfree.chart.labels.CategoryToolTipGenerator",
            new int[]{-654,397,705,-115,832,417,-832,-595,-1000,1000,-806,-133,754,1000,1000,-196,1000,285,-1000,-1000,-970,-1000,699,-80,475,-1000,1000,-261,550,1000,-1000,-631,-491,-783,-161,-444,-1000,1000,-255,-1000,-1000,1000,-1000,801,60,33,123,-1000,-1000,-501,58,-690,-1000,-629,249,-757,-1000,-643,-1000,-309,601,-447,507,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00154() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getBaseToolTipGenerator():org.jfree.chart.labels.CategoryToolTipGenerator",
            new int[]{-771,168,-91,-591,730,-1000,-236,268,-61,638,218,-819,-738,772,-953,17,-68,-674,-731,683,1000,-336,293,673,-450,-1000,-1000,392,1000,121,-5,133,662,-1000,1000,372,557,626,855,-1000,749,1000,-1000,1000,-312,-1000,-498,-927,1000,1000,-239,-396,-1000,132,-808,1000,72,34,-189,-400,100,-177,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00155() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getBaseToolTipGenerator():org.jfree.chart.labels.CategoryToolTipGenerator",
            new int[]{-961,-1000,354,-827,-242,-842,932,-8,-370,540,750,529,-953,-694,-1000,82,-704,-590,-151,-228,-277,871,-468,-642,-305,1000,-1000,-77,54,-219,-262,400,-501,-591,406,467,1000,-1000,490,-121,1000,629,-688,1000,-30,343,-167,331,111,-304,266,-273,-873,223,-1000,513,1000,-1000,-147,1000,374,-6,-387,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00156() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getBaseToolTipGenerator():org.jfree.chart.labels.CategoryToolTipGenerator",
            new int[]{-427,-820,959,-662,1000,-40,-581,469,-376,-245,510,829,-233,6,73,241,476,-215,-796,-551,-875,913,1000,-626,-967,1000,-1000,900,307,-510,-169,-239,-1000,584,110,603,1000,626,506,371,551,324,228,1000,-298,-529,288,-599,-447,-1000,447,805,-1000,664,1000,-413,1000,-817,-1000,689,-277,-1000,-887,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00157() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getBaseToolTipGenerator():org.jfree.chart.labels.CategoryToolTipGenerator",
            new int[]{53,-1000,569,760,347,-318,27,-592,97,1000,515,1000,-245,-870,383,220,-1000,-831,-1000,-1000,-614,-341,-1000,-1000,-571,1000,-1000,1000,146,57,727,314,-425,1000,-616,48,-368,-297,-792,1000,1000,-619,-1000,83,513,1000,700,1000,-1000,-733,486,-74,-340,-69,-579,-1000,425,-1000,15,1000,89,400,696,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00158() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getBaseToolTipGenerator():org.jfree.chart.labels.CategoryToolTipGenerator",
            new int[]{911,-152,124,-388,665,940,-489,-13,-208,-144,-806,-544,820,348,248,-48,522,689,990,-504,-779,-10,699,-179,382,-922,412,-261,-262,-923,-981,-334,-948,457,-161,-242,273,257,-286,-564,-666,-587,-715,-285,-886,-304,-454,-240,218,630,58,-690,106,926,249,-757,-125,492,-861,-560,-506,-139,507,305}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00159() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getBaseToolTipGenerator():org.jfree.chart.labels.CategoryToolTipGenerator",
            new int[]{880,-481,-344,-742,-601,53,550,-662,576,170,118,339,-231,909,-352,-382,544,-587,-69,-680,-65,129,58,104,-326,1000,248,-436,-956,416,573,471,-639,-265,-396,-654,419,-661,-1000,-668,-871,431,-476,294,319,392,4,-792,-847,-149,231,-218,-475,-379,-857,-302,1000,-881,-446,423,394,-211,96,353}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00160() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getBaseToolTipGenerator():org.jfree.chart.labels.CategoryToolTipGenerator",
            new int[]{-856,-452,509,-885,652,-48,214,657,-121,-245,596,529,-547,46,-485,150,103,-478,407,-214,-701,865,861,-273,-424,255,-690,-77,219,-510,-303,178,-911,-86,32,467,1000,318,939,-259,61,390,227,937,-711,-529,-301,-622,322,-526,266,535,-1000,210,1000,116,1000,-419,-913,540,501,-1000,-771,-450}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00161() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getBaseToolTipGenerator():org.jfree.chart.labels.CategoryToolTipGenerator",
            new int[]{761,-1000,243,-1000,1000,1000,-854,-245,57,188,663,1000,1000,-1000,937,314,248,989,-1000,-1000,-596,-254,1000,-970,-195,-1000,326,360,-786,348,-1000,723,-1000,1000,-170,-1000,-289,903,-1000,-1000,1000,482,-528,-419,-1000,320,455,-835,1000,-703,1000,-456,-626,1000,1000,-1000,-1000,1000,-754,-901,-1000,851,1000,-275}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00162() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getBaseToolTipGenerator():org.jfree.chart.labels.CategoryToolTipGenerator",
            new int[]{-1000,-1000,214,-437,-204,-934,932,-816,-191,786,750,401,-595,-537,-1000,-203,-934,-722,-513,3,539,-242,-1000,-358,-56,-321,-1000,185,-311,95,134,304,364,-632,265,321,1000,-1000,1000,-495,749,922,-1000,1000,41,-506,-246,473,681,452,96,-570,-873,295,-1000,610,1000,-658,302,1000,-149,594,-419,-15}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00163() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getBaseToolTipGenerator():org.jfree.chart.labels.CategoryToolTipGenerator",
            new int[]{-1000,-1000,594,-97,-14,927,506,-605,-394,476,198,764,-222,-518,-1000,-515,-633,-103,-605,3,631,1000,-1000,-713,509,-925,-1000,185,-1000,1000,-465,114,225,-554,467,148,1000,-1000,1000,-28,-336,339,-1000,569,41,1000,-424,473,1000,805,96,-923,410,520,-744,610,1000,-723,599,983,-702,1000,-192,-286}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00164() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getBaseToolTipGenerator():org.jfree.chart.labels.CategoryToolTipGenerator",
            new int[]{929,426,-167,-720,85,1000,457,699,276,479,1000,30,467,-140,1000,-28,286,-261,-611,-1000,-684,-964,1000,24,-358,-1000,1000,1000,739,1000,-144,1000,-802,890,-1000,-753,-1000,953,-1000,-1000,96,1000,-138,-385,-1000,975,-46,-1000,468,-1000,1000,-230,256,678,199,-1000,-1000,563,-1000,-884,-209,327,676,531}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00165() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getBaseToolTipGenerator():org.jfree.chart.labels.CategoryToolTipGenerator",
            new int[]{138,1000,-632,369,-501,632,268,-177,-361,1000,198,-643,1000,290,1000,-1000,-231,-466,-1000,-1000,-200,-1000,-417,159,302,-1000,1000,170,574,1000,157,148,429,-352,-972,-1000,-1000,313,-1000,-1000,-597,1000,-1000,169,557,1000,53,-497,-447,-217,715,-1000,1000,-85,-1000,381,-1000,-358,-155,-396,-139,1000,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00166() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getBaseToolTipGenerator():org.jfree.chart.labels.CategoryToolTipGenerator",
            new int[]{-1000,-1000,791,575,351,1000,30,-1000,-325,633,599,1000,145,-1000,-514,-530,-749,-107,-724,-298,574,564,-450,-1000,-305,464,-1000,1000,-1000,1000,192,109,-892,622,586,-2,400,-781,400,1000,1000,836,-998,403,260,1000,178,1000,868,-161,567,-560,-54,460,-547,-840,400,-1000,-41,1000,156,811,-1,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00167() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getBaseURLGenerator():org.jfree.chart.urls.CategoryURLGenerator",
            new int[]{124,-321,-221,603,-889,-537,109,-467,730,1000,1000,-318,-848,350,-248,-398,-481,452,-82,77,244,-528,-1000,861,-150,570,-1000,-768,435,995,-312,52,348,-796,1000,-715,798,-12,-968,-10,773,359,1000,219,-1000,-913,-451,-231,-277,470,-325,-902,-1000,712,-1000,-333,-43,314,342,-463,146,1000,119,81}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00168() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getBaseURLGenerator():org.jfree.chart.urls.CategoryURLGenerator",
            new int[]{-771,-1000,924,1000,-895,1000,-1000,-850,-5,341,-421,-1000,-1000,1000,-190,-285,723,467,-1000,1000,595,-1000,-1000,508,912,1000,582,-778,-118,131,672,513,291,572,-281,1000,-1000,-639,1000,634,286,844,154,-1000,1000,897,-1000,-1000,-877,-592,845,-2,360,-513,-975,-75,1000,420,827,-12,1000,1000,-203,-279}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00169() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getBaseURLGenerator():org.jfree.chart.urls.CategoryURLGenerator",
            new int[]{733,-1000,-341,488,512,-314,1000,-95,-753,-580,-1000,114,-1000,-1000,1000,-212,307,737,814,1000,-1000,1000,-1000,560,-1000,-134,1000,183,-390,129,560,-368,-605,736,111,576,1000,1000,1000,780,286,-1000,-1000,-607,-1000,325,-749,-1000,-1000,-1000,1000,1000,1000,-1000,485,1000,-201,-168,1000,774,982,-522,1000,332}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00170() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getBaseURLGenerator():org.jfree.chart.urls.CategoryURLGenerator",
            new int[]{749,-1000,-88,603,-48,-125,109,-850,730,-311,-650,1000,-796,-580,1000,-1000,663,632,661,384,-1000,335,-605,861,-1000,408,1000,216,-219,-56,-703,-376,-128,1000,-106,384,25,568,580,404,45,-1000,1000,669,-790,29,-392,-1000,-1000,-1000,1000,1000,970,-967,362,857,-462,-470,342,292,657,345,1000,644}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00171() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getBaseURLGenerator():org.jfree.chart.urls.CategoryURLGenerator",
            new int[]{1000,-508,434,1000,-892,-318,392,1000,273,972,-143,-113,-1000,-373,690,-1000,-266,-1000,-938,-1000,-686,-412,-1000,-570,885,529,-1000,-1000,-1000,-1000,-1000,-184,1000,-796,-525,-1000,-992,634,396,-1000,773,520,222,-1000,-1000,-349,-143,1000,-438,1000,253,1000,-1000,1000,1000,295,1000,555,980,1000,-83,121,-247,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00172() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getBaseURLGenerator():org.jfree.chart.urls.CategoryURLGenerator",
            new int[]{-586,766,-26,805,-897,1000,-1000,1000,-1000,-779,617,204,-1000,-1000,-1000,913,-638,-1000,-852,-1000,1000,-455,42,-1000,1000,1000,-1000,-1000,-1000,-1000,1000,1000,1000,-1000,8,-1000,-1000,-82,614,-1000,-1000,1000,311,-405,-346,-596,-809,1000,154,1000,-1000,-995,-607,1000,-248,107,1000,521,18,414,-297,28,-972,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00173() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getBaseURLGenerator():org.jfree.chart.urls.CategoryURLGenerator",
            new int[]{-168,-321,-852,678,-180,-213,355,-701,890,1000,1000,-282,-1000,-645,-248,-91,-778,312,-462,1000,166,-582,-961,-141,-25,1000,-525,-1000,-592,398,-93,734,1000,-119,879,-427,1000,-118,-452,-607,48,359,658,406,-1000,-846,777,-637,-277,802,-325,-783,-164,578,-517,-223,819,117,342,126,-299,262,119,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00174() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getBaseURLGenerator():org.jfree.chart.urls.CategoryURLGenerator",
            new int[]{564,-1000,-537,968,-1000,823,-124,-856,716,248,-691,-1000,-1000,1000,608,-655,613,163,-226,-474,-4,298,-1000,560,-497,622,576,804,1000,1000,177,-368,-529,-313,-1000,86,897,179,912,1000,1000,-1000,360,-1000,1000,-1000,1000,-300,-1000,-1000,1000,-481,-283,-379,-915,-22,266,527,1000,-645,1000,804,842,-546}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00175() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getBaseURLGenerator():org.jfree.chart.urls.CategoryURLGenerator",
            new int[]{-862,797,-818,-500,315,343,-786,-782,-112,-461,217,952,632,-1000,-488,1000,-92,323,-324,501,383,81,1000,-15,964,1000,441,1000,-951,-633,1000,1000,1000,582,146,662,-899,-581,303,-730,-812,-4,153,866,-516,591,-1000,26,851,826,-400,-1000,1000,267,586,300,1000,81,-481,-473,-1000,-1000,-673,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00176() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getBaseURLGenerator():org.jfree.chart.urls.CategoryURLGenerator",
            new int[]{-467,-1000,729,1000,-1000,920,-542,-1000,427,1000,-831,-1000,-1000,1000,260,-770,1000,439,-889,1000,404,-361,-1000,1000,-209,1000,680,-245,1000,1000,502,-168,-802,711,-603,1000,890,-508,1000,1000,-376,-154,69,-1000,1000,986,1000,-1000,-1000,-1000,1000,-154,-87,-1000,-1000,-227,682,-665,1000,-493,1000,1000,437,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00177() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getBaseURLGenerator():org.jfree.chart.urls.CategoryURLGenerator",
            new int[]{592,-294,269,66,-292,-622,-170,330,-245,170,-867,-449,-499,400,113,325,-117,882,-149,-400,157,273,-394,-88,49,-400,398,1000,644,737,106,-114,-209,-400,-690,260,165,212,-400,634,886,-574,-138,-374,307,-314,403,358,-1000,-88,532,-514,43,-838,-202,-59,-1,321,757,-258,493,-921,632,-492}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00178() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getBaseURLGenerator():org.jfree.chart.urls.CategoryURLGenerator",
            new int[]{-878,-186,-221,-350,-508,815,-833,-976,-217,361,840,-661,-812,934,-749,677,362,24,-939,977,819,-528,426,861,235,570,-579,-258,435,-343,805,490,454,437,-243,449,798,-743,-309,653,773,197,803,721,594,-18,642,104,-128,421,-376,-902,37,402,-811,-642,271,280,78,-463,598,931,-932,-921}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00179() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getBaseURLGenerator():org.jfree.chart.urls.CategoryURLGenerator",
            new int[]{603,-1000,264,60,-132,-1000,1000,-831,700,814,-1000,-864,413,400,1000,-246,1000,1000,443,-367,-1000,688,-1000,-12,-1000,-1000,866,1000,1000,122,-373,-1000,-1000,861,709,934,1000,16,73,1000,1000,-1000,197,-104,764,-246,-250,-1000,-1000,-850,1000,340,300,-1000,-1000,606,430,-182,1000,-907,1000,400,1000,-925}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00180() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getColumnCount():int",
            new int[]{-303,-111,-66,400,480,-1000,187,351,-386,1000,-1000,-103,336,-28,-600,-1000,-548,1000,-646,1000,-316,1000,830,233,73,318,-1000,247,517,391,608,46,-1000,-335,-959,-1000,654,-397,-256,1000,826,147,-764,47,-1000,-228,-802,-928,-117,-1000,-186,396,-869,-96,-715,730,566,-843,526,-400,-1000,614,1000,751}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00181() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getColumnCount():int",
            new int[]{-1000,-554,334,1000,-1000,-634,179,-899,-680,426,-854,25,-94,407,-1000,-1000,197,-401,-470,551,-575,458,1000,-527,-60,697,-1000,-905,1000,-279,11,-1000,194,434,-428,-114,506,-728,-633,1000,787,-750,843,-82,-660,768,-1000,-1000,379,-645,-845,293,592,-1000,432,-660,-662,-1000,-921,-1000,329,1000,-446,-820}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00182() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getColumnCount():int",
            new int[]{-1000,-960,-882,1000,-444,668,-64,-276,-598,882,-693,-244,-132,822,-1000,-1000,852,361,-329,-521,432,440,-319,862,-1000,-558,-1000,-1000,697,1000,215,10,-741,1000,755,-616,-894,-1000,-899,589,1000,-1000,-300,-735,-1000,211,-1000,-1000,1000,570,-1000,-452,1000,-1000,1000,-120,-1000,-1000,-725,-1000,-340,1000,264,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00183() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getColumnCount():int",
            new int[]{1000,532,544,-459,-552,-1000,-596,-584,-1000,1000,481,-55,121,-734,829,-159,-618,8,-887,289,-967,-1000,653,538,655,-545,1000,382,359,-301,689,-1000,850,705,480,52,-746,-262,-401,1000,-851,1000,877,417,-526,28,28,586,-653,-716,560,-56,-1000,959,-312,-205,1000,-740,1000,-287,106,408,682,874}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00184() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getColumnCount():int",
            new int[]{1000,66,793,-459,-603,-971,229,-887,736,649,239,-90,-415,-857,829,-159,-650,-317,-517,508,-1000,-510,721,-522,321,-347,843,212,537,-1000,-3,-1000,1000,309,624,3,1000,-72,-268,1000,-1000,718,1000,-495,-288,-74,28,-710,-985,-467,-323,-551,-1000,959,-614,-899,1000,-740,400,-287,872,408,-291,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00185() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getColumnCount():int",
            new int[]{316,173,42,-184,-388,1000,-877,191,11,1000,1000,-428,-232,-783,955,-199,427,-279,1000,1000,-391,-1000,-360,-13,-1000,1000,-1000,-902,1000,-279,606,815,1000,-107,-102,759,50,-1000,21,-107,-915,-750,-725,716,1000,301,-1000,338,1000,289,-828,-1000,592,-489,876,-256,-375,-1000,-921,176,329,-6,-551,-847}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00186() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getColumnCount():int",
            new int[]{465,1000,407,1000,-1000,-636,-166,-1000,-1000,402,1000,478,-1000,1000,1000,1000,-73,-441,34,-318,-780,-437,-275,-240,400,-1000,1000,-792,649,211,1000,-1000,209,1000,782,1000,-530,1000,723,-555,1000,713,1000,-913,1000,1000,0,1000,-558,246,-399,-255,-971,-282,-644,-494,385,-1000,1000,-1000,1000,1000,-185,-43}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00187() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getColumnCount():int",
            new int[]{-954,-59,464,561,-994,-717,78,-792,250,299,321,-265,347,236,-924,-554,954,-268,-316,197,-410,-594,999,-408,-335,306,-943,-700,966,-510,429,-800,979,409,-350,836,395,-484,-768,879,-56,-408,739,698,302,642,-853,-36,228,877,289,264,335,-663,570,-877,913,-36,-670,-459,90,593,-743,-827}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00188() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getColumnCount():int",
            new int[]{-262,-99,-1000,370,1000,231,179,-899,-1000,421,-854,-846,-94,448,-1000,-1000,-466,1000,-682,-625,1000,386,-910,582,227,391,-219,19,761,1000,1000,750,194,528,339,-898,-1000,-178,544,-1000,1000,501,843,-824,-294,254,-1000,-280,379,794,-318,293,-1000,-699,-25,-660,-1000,-475,-702,-1000,-716,919,1000,-357}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00189() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getColumnCount():int",
            new int[]{1000,-111,-66,-573,1000,1000,-1000,167,-386,-432,831,-225,336,114,-549,709,-406,903,291,436,1000,1000,-1000,-279,-210,-788,510,628,856,1000,-630,1000,-1000,-795,-959,-177,-1000,1000,1000,-1000,826,1000,-1000,-774,1000,-98,613,1000,-636,465,1000,-1000,-876,716,-86,398,510,300,115,954,-6,-1000,-13,501}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00190() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getColumnCount():int",
            new int[]{-628,-73,49,-629,-424,-671,78,-446,-103,-974,-852,-794,832,-661,210,-289,246,580,531,-193,256,953,989,-757,300,529,725,88,-789,179,-145,0,-697,770,-780,588,445,-333,363,-840,-120,667,785,-383,175,-184,-644,10,-917,-706,303,383,-679,501,-425,921,-655,-188,601,-875,2,85,-547,-221}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00191() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getColumnCount():int",
            new int[]{-23,377,-246,1000,-921,4,-535,-777,-848,402,1000,95,-673,1000,720,1000,675,-441,-77,-268,-29,-437,-538,297,-818,-967,207,-593,297,1000,533,-513,209,1000,1000,1000,-1000,578,-257,635,1000,-90,835,-990,1000,706,-139,950,224,734,-549,81,337,-824,522,-489,-346,-1000,-68,-1000,-116,1000,-185,-880}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00192() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getColumnCount():int",
            new int[]{-883,-837,-767,399,-1000,689,-35,-1000,-1000,636,-1000,-234,-658,241,720,-411,782,-561,-238,-866,-47,-617,-395,334,14,-1000,290,-1000,711,27,-212,-723,659,1000,1000,86,-652,-773,-907,589,-278,-600,935,417,-1000,319,-420,-847,392,943,-1000,-1000,908,-261,1000,-1000,-697,-928,-813,-921,970,855,-640,-825}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00193() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getDrawingSupplier():org.jfree.chart.plot.DrawingSupplier",
            new int[]{-590,911,-499,26,521,-983,-202,18,431,272,-1000,-765,545,-83,-1000,-1000,1000,-33,85,-262,-185,534,678,851,319,-1000,-721,172,763,-858,-1000,212,659,338,-636,-323,193,32,-440,305,334,1000,423,715,1000,-171,-28,1000,-1000,469,162,-545,667,-401,-1000,-62,-250,-1000,273,-847,-320,-1000,-298,45}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00194() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getDrawingSupplier():org.jfree.chart.plot.DrawingSupplier",
            new int[]{-99,61,-162,1000,-43,1000,1000,-954,-1000,-711,731,1000,-1000,762,1000,1000,-163,-194,185,1000,229,951,1000,-133,-1000,1000,-330,-453,-1000,328,1000,66,1000,-742,76,1000,1000,6,-218,1000,-1000,-1000,-934,222,-1000,1000,-235,241,1000,542,-501,945,-1000,882,-773,-1000,-578,1000,-1000,1000,1000,1000,1000,-460}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00195() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getDrawingSupplier():org.jfree.chart.plot.DrawingSupplier",
            new int[]{-434,247,622,381,-911,-64,-956,-690,11,611,1000,499,-437,85,591,-85,-516,-976,-429,768,-1000,263,-374,-926,276,598,118,1,-742,-526,275,-1000,-201,-668,201,-620,-770,690,1000,1000,-1000,-694,404,-1000,-74,1000,404,-91,877,-109,206,630,478,1000,-18,-295,686,293,-338,-633,506,-105,171,-460}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00196() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getDrawingSupplier():org.jfree.chart.plot.DrawingSupplier",
            new int[]{343,285,-671,442,-667,702,15,865,-256,646,-21,548,-197,1000,580,704,955,-248,-242,688,952,460,1000,-716,1000,853,621,-159,-227,-99,120,47,-267,-790,724,-53,138,-581,-1000,264,-567,-388,1000,268,-324,-613,-217,173,-519,-199,-571,321,130,556,450,825,479,144,-665,-723,852,-728,-57,-24}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00197() {
        org.junit.Assert.assertEquals("TYPE:org.jfree.chart.plot.DefaultDrawingSupplier", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getDrawingSupplier():org.jfree.chart.plot.DrawingSupplier",
            new int[]{-541,28,-291,270,110,-584,461,-820,-586,446,-208,377,-1000,510,-524,447,1000,-384,219,1000,229,518,1000,461,493,1000,1000,-55,-265,328,-210,296,-551,-1000,802,-80,502,1000,-817,1000,-472,458,-934,320,-197,-224,137,1000,20,-483,-577,798,1000,647,-868,-578,178,-172,-1000,-69,1000,-960,182,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00198() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getDrawingSupplier():org.jfree.chart.plot.DrawingSupplier",
            new int[]{-710,878,824,184,569,-942,120,55,757,-400,-867,-409,-437,-330,-161,-815,-320,338,-664,-82,-326,334,301,-228,721,-706,707,-53,400,-307,-828,580,3,352,-356,133,-318,-794,6,-166,183,923,-375,-312,844,-170,856,-230,-895,632,-904,-202,856,439,-896,-715,-391,-264,-21,6,-291,-906,-541,-79}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00199() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getDrawingSupplier():org.jfree.chart.plot.DrawingSupplier",
            new int[]{-858,343,243,-319,-255,-162,-686,767,975,-841,-319,-719,-488,1000,884,-1000,-804,-419,-565,-631,-520,152,-975,-860,1000,-1000,-620,537,618,-438,-854,365,719,1000,-682,-200,-624,-1000,900,666,47,-863,727,-1000,1000,331,103,-906,114,541,-26,-745,-344,-57,247,-1000,-959,-16,-133,692,-171,159,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00200() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getDrawingSupplier():org.jfree.chart.plot.DrawingSupplier",
            new int[]{307,1000,356,-420,-1000,582,-134,476,-255,906,1000,-43,-147,-3,699,-95,-1000,-1000,63,-333,-1000,755,-1000,-1000,856,-573,-620,783,-6,782,-3,-1000,-457,-55,-146,-200,-954,-367,1000,581,-819,-1000,727,-1000,814,1000,25,-1000,821,-144,959,430,-17,205,272,-747,-396,31,435,155,621,890,1000,452}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00201() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getDrawingSupplier():org.jfree.chart.plot.DrawingSupplier",
            new int[]{-1000,570,409,973,156,-708,165,-241,757,-797,-1000,-195,28,-229,-298,-783,978,-329,-563,235,19,187,503,-361,496,-88,-1000,268,292,-761,-468,473,874,942,-96,-689,-235,-756,-78,-316,-94,-400,-280,138,680,-145,269,-372,-93,488,-168,-624,303,404,-669,-692,-264,72,37,-261,-131,-558,-505,810}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00202() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getDrawingSupplier():org.jfree.chart.plot.DrawingSupplier",
            new int[]{-951,131,409,867,249,98,-718,-392,757,392,656,150,-437,-240,-161,-779,730,455,-841,591,-70,334,1000,-112,884,-706,-204,-961,-11,-1000,-240,484,593,-795,-96,-461,-235,-1000,233,-453,-295,-58,-280,1000,543,-405,541,299,296,1000,-1000,-624,276,6,-615,-961,196,72,-1000,-968,54,-690,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00203() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getItemLabelGenerator(int,int,boolean):org.jfree.chart.labels.CategoryItemLabelGenerator",
            new int[]{422,740,-656,629,1000,-422,-559,-645,32,1000,1000,1000,1000,475,-862,1000,-293,-191,1000,424,-1000,-1000,-1000,320,-614,549,-1000,-1000,-143,1000,-1000,-680,1000,-1000,971,-773,-74,-134,493,1000,1000,1000,-218,1000,1000,676,189,316,776,-349,218,-1000,-681,-401,-422,-1000,926,-1000,1000,-382,-781,6,996,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00204() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getItemLabelGenerator(int,int,boolean):org.jfree.chart.labels.CategoryItemLabelGenerator",
            new int[]{-154,731,285,-791,1000,-332,-681,-935,-203,-576,-768,-210,-156,-943,-162,-203,-676,339,-644,-381,-488,-251,1000,-257,1000,-377,1000,949,-250,-835,224,-752,-709,888,-291,-366,920,89,-1000,-748,-691,429,865,-1000,459,-368,-952,439,0,-255,251,-58,-670,-607,-404,400,-53,1000,-1000,-1000,-238,-670,-693,968}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00205() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getItemLabelGenerator(int,int,boolean):org.jfree.chart.labels.CategoryItemLabelGenerator",
            new int[]{1000,-1000,164,-467,977,79,691,-742,-276,632,-435,838,797,-1000,-1000,901,178,598,668,521,-237,-957,51,671,989,-171,-1000,323,-790,1000,-1000,-718,-1000,-978,-869,-264,647,-269,-2,-550,667,592,1000,-1000,814,638,-956,313,811,200,-338,-819,-920,-496,-184,1000,-1000,12,782,-17,-344,-268,809,-91}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00206() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getItemLabelGenerator(int,int,boolean):org.jfree.chart.labels.CategoryItemLabelGenerator",
            new int[]{265,385,604,-635,-748,964,1000,688,-762,-1000,-1000,-1000,-397,-379,167,-1000,-523,682,-926,-227,-423,134,1000,-616,971,-1000,1000,1000,-604,-861,461,380,-1000,1000,-1000,12,146,-345,-880,-1000,-1000,116,718,-1000,-235,-1000,-699,-1000,545,-981,731,127,-279,-99,860,-126,-1000,1000,-579,778,1000,295,-1000,426}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00207() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getItemLabelGenerator(int,int,boolean):org.jfree.chart.labels.CategoryItemLabelGenerator",
            new int[]{-333,71,121,266,-264,-30,318,573,-880,706,-1000,240,-407,-161,1000,-1000,-866,392,-72,-1000,926,1000,878,-423,104,-1000,1000,416,1000,-1000,1000,-865,1000,1000,-654,1000,1000,-178,-103,-1000,-1000,-447,-744,-1000,333,-1000,-666,61,-360,-1000,-99,627,943,367,1000,-1000,-222,500,-1000,337,-349,-995,67,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00208() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getItemLabelGenerator(int,int,boolean):org.jfree.chart.labels.CategoryItemLabelGenerator",
            new int[]{22,-1000,513,-145,958,-1000,146,-555,-1000,400,287,-153,62,-700,-973,773,-215,-212,299,847,592,-985,221,1000,-461,-61,-400,1000,-957,43,-781,-23,-1000,943,418,-1,324,1000,-598,-582,-410,1000,1000,-773,471,563,-577,-139,948,438,373,-847,907,817,-295,1000,-1000,34,778,-513,-795,295,-16,-329}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00209() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getItemLabelGenerator(int,int,boolean):org.jfree.chart.labels.CategoryItemLabelGenerator",
            new int[]{543,740,-656,740,784,-304,-114,-645,-817,-1000,1000,2,158,78,719,-190,35,-453,-1000,376,112,-1000,737,-120,1000,549,1000,39,300,-1000,-44,-393,69,319,-445,-504,1000,564,-219,31,-13,-46,-130,-244,687,-1000,-689,463,-11,-815,-118,-856,986,-352,127,-930,-89,881,400,-642,-781,166,470,108}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00210() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getItemLabelGenerator(int,int,boolean):org.jfree.chart.labels.CategoryItemLabelGenerator",
            new int[]{228,-792,-686,-323,-331,38,-705,-534,198,496,-864,-227,-507,-223,-133,520,474,-906,195,-586,-501,-509,-717,318,-586,405,200,-182,-165,-472,727,-41,441,-270,-595,-627,493,608,906,806,-662,557,154,483,215,169,932,-360,-667,-755,189,-922,-106,-282,-296,-347,499,-581,333,-748,-786,728,681,-32}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00211() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getItemLabelGenerator(int,int,boolean):org.jfree.chart.labels.CategoryItemLabelGenerator",
            new int[]{191,366,547,-52,731,27,-592,-572,-1000,706,611,-605,584,-483,-1000,504,1000,-551,-496,938,-911,-338,754,-480,712,647,1000,416,-631,-773,-491,208,-1000,-1000,-770,-798,126,61,-738,228,484,544,899,187,400,-357,-571,-169,559,179,140,-1000,-535,367,1000,-444,-655,500,1000,-1000,1000,659,-109,-270}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00212() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getItemLabelGenerator(int,int,boolean):org.jfree.chart.labels.CategoryItemLabelGenerator",
            new int[]{-975,-281,-476,489,940,-713,-1000,-1000,-365,1000,1000,1000,1000,-911,-1000,1000,558,-709,1000,205,-1000,-978,-1000,386,155,1000,-1000,-1000,-81,-166,-687,-1000,849,-1000,1000,-905,-114,1000,31,1000,1000,1000,420,1000,1000,1000,217,1000,702,608,-605,-983,-1000,123,-994,400,515,-1000,683,-506,-487,-1000,522,-41}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00213() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getItemLabelGenerator(int,int,boolean):org.jfree.chart.labels.CategoryItemLabelGenerator",
            new int[]{876,-364,-62,828,967,-430,246,-529,-280,474,612,768,710,-980,-922,859,52,148,525,-260,-547,-939,-867,205,464,461,-1000,-769,-398,1000,-1000,-277,-976,-969,137,-210,-74,52,-231,160,626,418,742,827,734,159,130,83,507,-301,-92,-741,-567,-231,367,687,-970,-440,688,555,156,10,834,-668}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00214() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getItemLabelGenerator(int,int,boolean):org.jfree.chart.labels.CategoryItemLabelGenerator",
            new int[]{-1000,1000,478,90,-1000,404,318,1000,-884,-393,1000,-766,-75,-500,-141,-1000,52,-1000,-1000,463,-135,786,314,-1000,640,-184,1000,-329,-318,-899,922,527,753,-5,-1000,-97,-97,-355,64,382,125,-162,-352,-850,-1000,-432,619,-915,-11,-1000,187,436,290,43,927,-1000,-152,1000,-427,755,681,-600,25,-43}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00215() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getItemLabelGenerator(int,int,boolean):org.jfree.chart.labels.CategoryItemLabelGenerator",
            new int[]{-1000,1000,726,551,1000,709,-139,400,-1000,-1000,-1000,-953,1000,224,1000,-277,-1000,-754,-578,1000,195,312,-38,298,405,-1000,1000,582,-673,-1000,-491,-1000,124,-332,-869,-159,1000,-388,-471,270,404,837,-1000,-721,1000,-1000,-390,-933,412,-1000,789,-894,392,-944,-1000,-1000,-962,1000,116,-1000,-1000,-400,106,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00216() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getItemLabelGenerator(int,int,boolean):org.jfree.chart.labels.CategoryItemLabelGenerator",
            new int[]{60,116,-251,-137,7,-573,-165,221,-878,545,-172,-637,530,-1000,-233,3,-353,-257,1000,1000,-123,-1000,754,-690,732,-116,1000,-394,750,-870,617,-117,-110,-1000,-1000,321,675,-649,-404,106,105,-8,974,149,454,-431,-1000,476,147,380,-256,-128,360,-563,-736,-667,-1000,500,452,156,1000,-321,421,348}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00217() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getItemLabelGenerator(int,int,boolean):org.jfree.chart.labels.CategoryItemLabelGenerator",
            new int[]{310,723,-345,638,945,825,-102,-306,-556,18,468,-807,-88,125,-279,397,691,-206,-926,366,204,-973,641,-39,-1000,254,1000,1000,-419,859,-849,198,184,-362,-347,-1000,-244,1000,65,-68,-410,468,179,-773,471,-895,647,-39,1000,-795,304,-1000,-279,433,106,-1000,1000,1000,600,-920,-489,1000,-34,-638}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00218() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getItemLabelGenerator(int,int,boolean):org.jfree.chart.labels.CategoryItemLabelGenerator",
            new int[]{-12,1000,209,-591,229,946,992,540,-758,-1000,-1000,-597,302,401,295,-646,-570,785,-719,1000,-491,-98,764,-71,855,-1000,1000,1000,-759,-819,-232,-239,-863,840,-752,-536,146,-461,-1000,-742,-410,435,86,-936,331,-1000,-1000,-1000,161,-1000,996,-525,907,-214,-297,-126,-540,1000,-313,-622,89,-23,-223,526}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00219() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getItemMiddle(java.lang.Comparable,java.lang.Comparable,org.jfree.data.category.CategoryDataset,org.jfree.chart.axis.CategoryAxis,java.awt.geom.Rectangle2D,org.jfree.chart.util.RectangleEdge):double",
            new int[]{737,-983,-306,-290,464,-307,135,1000,-650,715,-1000,-104,-472,1000,-1000,715,-896,-487,-540,969,608,-733,1000,-742,-137,1000,366,1000,-243,820,-1000,-421,-1000,-1000,840,-1000,-581,-335,-466,797,6,-1000,-935,196,-115,539,-1000,-1000,-196,-758,796,79,1000,-1000,1000,-1000,-36,1000,-713,109,258,309,1000,-51}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00220() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getItemMiddle(java.lang.Comparable,java.lang.Comparable,org.jfree.data.category.CategoryDataset,org.jfree.chart.axis.CategoryAxis,java.awt.geom.Rectangle2D,org.jfree.chart.util.RectangleEdge):double",
            new int[]{-260,-1000,649,747,437,1000,1000,550,488,1000,-819,-440,900,680,295,340,692,-1000,-751,1000,319,-536,263,-17,452,1000,1000,-918,-1000,1000,1000,-126,-395,-585,-642,16,805,-190,66,-1000,-1000,1000,89,144,-1000,-316,-181,-1000,-1000,346,498,-705,1000,-82,1000,-922,1000,-369,1000,162,1000,91,399,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00221() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getItemMiddle(java.lang.Comparable,java.lang.Comparable,org.jfree.data.category.CategoryDataset,org.jfree.chart.axis.CategoryAxis,java.awt.geom.Rectangle2D,org.jfree.chart.util.RectangleEdge):double",
            new int[]{605,-988,-418,180,848,522,-778,1000,-611,950,-739,-253,289,1000,-451,517,907,-849,-868,477,514,-375,-529,-1000,292,890,274,52,156,706,-306,-1000,-339,-1000,10,-517,981,905,-286,-501,-467,-1000,-693,952,-1000,1000,-833,-396,702,-10,966,420,-623,-1000,1000,-1000,1000,-543,-9,114,822,296,127,462}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00222() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getItemMiddle(java.lang.Comparable,java.lang.Comparable,org.jfree.data.category.CategoryDataset,org.jfree.chart.axis.CategoryAxis,java.awt.geom.Rectangle2D,org.jfree.chart.util.RectangleEdge):double",
            new int[]{465,510,-831,212,-539,-839,930,443,-637,-528,709,110,-333,189,681,-444,-383,-460,210,209,66,-520,-808,885,-87,207,752,179,-811,-357,809,-37,671,791,-132,574,230,-825,-239,-199,-970,960,979,-521,180,-276,783,-844,450,395,303,89,288,367,482,667,501,460,-81,214,-299,24,393,121}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00223() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getItemMiddle(java.lang.Comparable,java.lang.Comparable,org.jfree.data.category.CategoryDataset,org.jfree.chart.axis.CategoryAxis,java.awt.geom.Rectangle2D,org.jfree.chart.util.RectangleEdge):double",
            new int[]{606,57,-947,-1000,-77,-633,-247,-117,-890,-800,275,377,-654,-136,528,-331,-642,155,206,-16,118,361,-771,54,339,-416,-665,1000,-586,1000,383,274,543,217,-952,573,-34,-201,-267,-92,-764,372,183,-85,666,-243,248,-901,722,325,632,214,163,144,637,767,-211,557,-306,766,-237,350,66,294}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00224() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getItemMiddle(java.lang.Comparable,java.lang.Comparable,org.jfree.data.category.CategoryDataset,org.jfree.chart.axis.CategoryAxis,java.awt.geom.Rectangle2D,org.jfree.chart.util.RectangleEdge):double",
            new int[]{1000,-976,-847,-106,1000,145,-247,720,224,-201,-670,472,-573,510,-88,-33,153,-1000,373,133,859,-703,754,-241,339,1000,1000,1000,-376,-187,-902,-17,-1000,71,-106,-294,-129,-273,675,-109,-305,24,-733,148,-142,-36,-1000,-901,240,-903,375,699,574,-610,1000,-391,1000,595,-1000,310,-88,-141,1000,-213}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00225() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getItemMiddle(java.lang.Comparable,java.lang.Comparable,org.jfree.data.category.CategoryDataset,org.jfree.chart.axis.CategoryAxis,java.awt.geom.Rectangle2D,org.jfree.chart.util.RectangleEdge):double",
            new int[]{-488,652,-573,-690,-376,-78,-394,152,-1000,-178,178,382,625,-349,-238,1000,115,29,756,-382,233,-671,-31,196,-861,310,-1000,1000,1000,1000,-78,-466,-1000,-65,1000,-725,181,274,-1000,949,1000,-1000,15,576,1000,1000,-145,315,942,-895,793,-1000,-427,-287,-1000,-1000,-803,695,-949,-888,-396,134,-301,234}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00226() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getItemMiddle(java.lang.Comparable,java.lang.Comparable,org.jfree.data.category.CategoryDataset,org.jfree.chart.axis.CategoryAxis,java.awt.geom.Rectangle2D,org.jfree.chart.util.RectangleEdge):double",
            new int[]{-269,-369,64,-436,-81,848,1000,538,474,992,-670,16,676,502,-211,578,275,-918,-83,1000,385,-629,942,199,-620,1000,824,-400,-1000,930,338,248,-1000,-78,74,-352,-325,-683,-588,184,-417,565,-317,-153,-72,56,221,-1000,-641,39,353,-656,1000,417,480,-1000,567,710,-49,-269,492,-260,534,953}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00227() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getItemMiddle(java.lang.Comparable,java.lang.Comparable,org.jfree.data.category.CategoryDataset,org.jfree.chart.axis.CategoryAxis,java.awt.geom.Rectangle2D,org.jfree.chart.util.RectangleEdge):double",
            new int[]{-673,-674,-246,-870,602,-876,-500,-831,743,345,-287,702,-201,-705,487,494,-721,92,437,83,-48,703,-823,-837,-649,223,53,-940,-847,655,-251,885,335,655,-842,486,406,28,-685,-87,-124,113,-899,721,637,613,-47,171,925,-69,866,-862,162,-406,605,378,100,-9,-772,-318,449,293,-209,422}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00228() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getItemMiddle(java.lang.Comparable,java.lang.Comparable,org.jfree.data.category.CategoryDataset,org.jfree.chart.axis.CategoryAxis,java.awt.geom.Rectangle2D,org.jfree.chart.util.RectangleEdge):double",
            new int[]{-311,-369,59,896,-223,537,1000,1000,1000,1000,-453,-690,1000,1000,-140,379,52,-1000,-92,1000,534,-1000,789,1000,380,1000,1000,316,-10,-386,48,-285,-1000,368,111,-117,-16,-1000,-126,-260,-445,1000,561,-306,-344,-203,-502,-1000,-1000,-661,-11,-235,1000,894,133,-1000,-521,540,-85,-611,477,-238,1000,923}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00229() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getItemMiddle(java.lang.Comparable,java.lang.Comparable,org.jfree.data.category.CategoryDataset,org.jfree.chart.axis.CategoryAxis,java.awt.geom.Rectangle2D,org.jfree.chart.util.RectangleEdge):double",
            new int[]{255,13,-418,-868,314,-567,-778,415,-446,-381,152,251,951,-477,219,989,210,-736,873,-827,405,-947,384,-526,-773,682,-235,439,831,426,-651,-238,-949,-570,761,-704,108,-60,-578,590,832,-865,637,394,900,682,-149,270,619,-307,705,-776,-623,-755,-865,-908,56,287,-9,-689,-599,-603,351,674}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00230() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getItemMiddle(java.lang.Comparable,java.lang.Comparable,org.jfree.data.category.CategoryDataset,org.jfree.chart.axis.CategoryAxis,java.awt.geom.Rectangle2D,org.jfree.chart.util.RectangleEdge):double",
            new int[]{917,-731,184,-756,570,-354,-817,603,474,31,-799,550,-541,315,-69,-214,-242,-939,-473,-142,385,-121,942,-867,-581,325,824,585,-714,-736,-967,248,-49,-78,-351,-352,260,91,740,149,-417,373,62,-234,383,-273,-605,-285,-641,-905,-726,741,431,417,500,66,956,-35,-998,748,-678,-391,377,131}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00231() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getItemMiddle(java.lang.Comparable,java.lang.Comparable,org.jfree.data.category.CategoryDataset,org.jfree.chart.axis.CategoryAxis,java.awt.geom.Rectangle2D,org.jfree.chart.util.RectangleEdge):double",
            new int[]{-392,397,-436,-1000,-271,-527,-1000,-529,2,751,-799,1000,-1000,315,-753,-214,-238,413,536,407,-85,370,343,-867,-993,-323,-263,861,178,611,-989,-308,-1000,-621,1000,-687,-104,-690,-1000,1000,977,-1000,-1000,1000,746,-273,-1000,763,-159,-223,1000,-576,-267,-584,500,-517,-752,309,-281,748,-5,1000,-869,111}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00232() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getItemMiddle(java.lang.Comparable,java.lang.Comparable,org.jfree.data.category.CategoryDataset,org.jfree.chart.axis.CategoryAxis,java.awt.geom.Rectangle2D,org.jfree.chart.util.RectangleEdge):double",
            new int[]{112,-983,-341,-28,579,954,547,657,486,1000,-1000,-104,690,923,-363,476,557,-1000,-971,1000,608,-449,-891,-742,-11,-91,1000,-686,516,1000,340,-305,-611,-1000,-489,-305,528,-215,-837,-376,-789,568,-602,144,-1000,239,-420,-1000,-196,414,528,143,1000,-1000,1000,-1000,1000,0,1000,109,988,-116,556,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00233() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getItemMiddle(java.lang.Comparable,java.lang.Comparable,org.jfree.data.category.CategoryDataset,org.jfree.chart.axis.CategoryAxis,java.awt.geom.Rectangle2D,org.jfree.chart.util.RectangleEdge):double",
            new int[]{242,7,-695,899,-513,884,459,1000,436,-195,-225,112,1000,653,-718,242,940,-1000,-383,503,668,-640,-1000,1000,6,1000,712,-123,-818,1000,433,-108,-1000,-485,267,-847,798,-723,1000,312,-383,1000,504,-1000,-528,-266,1000,-1000,-469,-555,-1000,-403,469,548,-137,-985,1000,1000,5,-766,290,-1000,-43,-578}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00234() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItem(int,int):org.jfree.chart.LegendItem",
            new int[]{-387,-728,-896,-368,442,481,1000,508,695,407,211,580,299,-62,115,520,-201,1000,1000,276,494,1000,102,301,296,201,246,952,-626,-791,520,-825,120,-1000,-292,-289,-471,601,-299,1000,382,1000,1000,-1000,-900,-792,-610,-30,418,349,-850,-66,-1000,-96,-410,1000,-919,171,1000,815,256,796,220,81}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00235() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItem(int,int):org.jfree.chart.LegendItem",
            new int[]{1000,412,-927,250,-458,493,789,369,787,-885,-560,562,-692,221,-963,1000,-646,330,300,-622,-668,1000,-565,638,1000,229,-926,883,-1000,-359,408,-894,-1000,-1000,-297,-113,-768,76,119,1000,-429,506,-420,144,-655,485,1000,-400,92,-777,-1000,-668,-686,908,-1000,1000,780,-482,-544,1000,461,-331,1000,555}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00236() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItem(int,int):org.jfree.chart.LegendItem",
            new int[]{-1000,292,-291,17,-652,922,-661,349,-167,-498,-1000,262,-1000,763,-426,776,46,713,979,-336,246,248,-325,1000,679,274,-838,592,-201,-37,-42,-810,-1000,-903,1000,-472,-673,1000,-29,706,220,524,-366,-208,-279,321,447,463,25,-1000,-499,-492,-1000,487,-371,1000,-380,-870,-673,597,1000,-40,742,355}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00237() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItem(int,int):org.jfree.chart.LegendItem",
            new int[]{-119,24,-212,644,-796,303,719,-187,-7,-795,-281,174,-1000,626,246,552,-269,-874,861,-639,-1000,1000,-330,273,1000,-245,-1000,583,-703,17,-415,-801,-711,-1000,69,-554,-398,-479,119,57,-358,200,-590,584,-758,56,400,-11,-493,-654,-470,-375,-551,348,13,525,-482,-132,-553,1000,382,-827,274,-282}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00238() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItem(int,int):org.jfree.chart.LegendItem",
            new int[]{-1000,262,879,-142,-820,937,-1000,67,661,-499,100,1000,-1000,1000,-834,-493,-417,323,224,-501,-1000,1000,-526,668,1000,591,-1000,372,-151,111,424,-741,-1000,-1000,1000,804,-1000,1000,525,490,-3,96,226,-353,-330,463,401,-337,395,-989,-1000,-229,-1000,1000,-473,1000,-639,-907,-596,573,-898,354,801,955}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00239() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItem(int,int):org.jfree.chart.LegendItem",
            new int[]{-1000,-628,-313,467,-826,1000,1000,522,269,-1000,-1000,-936,-510,819,-1000,285,-181,1000,1000,-153,-1000,465,-353,1000,830,-364,-438,309,780,-103,-191,-904,44,-1000,-490,-812,-421,349,-781,1000,136,638,135,-786,285,-66,938,503,-972,-590,-460,-1000,-948,-252,-663,876,-702,586,-612,77,602,-780,-883,-733}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00240() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItem(int,int):org.jfree.chart.LegendItem",
            new int[]{-619,983,13,473,-585,1000,817,469,51,-728,-1000,-998,-349,905,-797,90,52,1000,1000,24,-614,-262,-286,983,795,-332,-389,625,49,340,5,-643,222,-991,-580,-899,-14,305,-894,1000,280,355,165,-1000,409,-318,1000,585,-1000,-517,-53,-1000,-814,-295,-747,725,-407,-140,-1000,332,682,-932,520,-779}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00241() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItem(int,int):org.jfree.chart.LegendItem",
            new int[]{-776,373,208,644,-349,668,-583,702,-40,-808,-611,266,-1000,346,246,552,-49,337,861,-967,-39,1000,-77,1000,360,893,-519,407,110,-1000,1000,-869,-1000,-1000,1000,418,-1000,1000,-790,596,-158,1000,-666,400,-447,563,601,1000,733,-1000,-414,-242,-1000,542,71,525,-227,785,-933,1000,1000,474,1000,367}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00242() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItem(int,int):org.jfree.chart.LegendItem",
            new int[]{102,-639,330,-564,950,-293,817,-149,457,-208,-693,-998,-17,-226,-604,960,-595,684,480,323,-456,-653,892,-581,306,-980,-420,625,-674,417,5,-614,508,550,-580,-629,742,305,-493,915,280,78,473,-587,-187,-84,123,-368,-913,632,180,-932,84,-894,183,396,227,629,655,-149,-131,-464,-77,913}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00243() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItem(int,int):org.jfree.chart.LegendItem",
            new int[]{1000,-628,-313,94,182,298,1000,304,-992,196,-910,-1000,1000,350,420,-314,417,-88,855,263,-202,-1000,-39,-81,-259,-312,120,309,780,184,-303,334,922,299,38,-1000,-53,275,-1000,46,601,412,106,-905,-948,-111,-445,1000,-1000,750,1000,-364,-897,-835,-486,439,115,318,196,77,-1000,-262,-883,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00244() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItem(int,int):org.jfree.chart.LegendItem",
            new int[]{856,-635,878,-569,-623,826,-597,-522,-400,-898,794,-343,443,46,-769,789,-687,-803,452,-714,640,136,-75,488,376,-197,982,-588,342,281,-820,819,-106,316,-351,-604,300,349,0,-458,-610,213,478,752,625,797,-520,939,-487,-25,302,136,-511,876,33,984,813,-823,-109,187,-155,-485,-36,651}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00245() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItem(int,int):org.jfree.chart.LegendItem",
            new int[]{634,75,903,145,929,-354,652,100,-790,791,1000,340,417,-1000,1000,-87,-1000,-1000,-1000,-777,255,1000,1000,1000,1000,-697,-242,-1000,614,-306,1000,-58,-232,956,-1000,889,657,-992,-417,-1000,-658,744,496,970,567,570,-463,-111,405,-1000,925,413,396,1000,1000,-1000,-342,-1000,-1000,1000,-1000,-1000,46,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00246() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItem(int,int):org.jfree.chart.LegendItem",
            new int[]{107,145,556,385,-801,667,239,373,-129,-976,-15,911,-868,806,-1000,-355,-139,-373,171,-341,-910,364,-649,378,837,178,-766,429,-455,32,76,-827,-526,157,-981,113,-892,465,-400,566,-793,379,-856,-611,-758,56,430,400,-335,-624,-419,-468,-865,206,-563,850,-217,-769,-575,673,-74,-195,250,782}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00247() {
        org.junit.Assert.assertEquals("TYPE:org.jfree.chart.labels.StandardCategorySeriesLabelGenerator", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItemLabelGenerator():org.jfree.chart.labels.CategorySeriesLabelGenerator",
            new int[]{901,763,-851,2,1000,625,257,1000,1000,-943,1000,-1000,-955,-2,754,1000,1000,-875,413,-612,953,751,-211,1000,-1000,756,1000,747,1000,-715,-1000,694,53,84,1000,-861,817,-122,-577,1000,555,-984,1000,-673,-354,1000,-708,-1000,1000,-1000,887,-138,-91,565,1000,684,-694,-578,630,-223,708,-1000,831,860}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00248() {
        org.junit.Assert.assertEquals("TYPE:org.jfree.chart.labels.StandardCategorySeriesLabelGenerator", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItemLabelGenerator():org.jfree.chart.labels.CategorySeriesLabelGenerator",
            new int[]{1000,272,78,16,317,73,257,981,-597,-1000,-443,367,1000,-463,587,1000,763,129,-1000,456,619,911,-803,1000,63,718,645,503,-505,-715,861,132,802,984,-274,-1000,935,690,-138,1000,815,643,-1000,-635,-414,703,-1000,495,47,-1000,1000,-240,-401,-415,-754,473,-387,-1000,-1000,-634,100,-134,-938,-696}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00249() {
        org.junit.Assert.assertEquals("TYPE:org.jfree.chart.labels.StandardCategorySeriesLabelGenerator", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItemLabelGenerator():org.jfree.chart.labels.CategorySeriesLabelGenerator",
            new int[]{-769,-532,769,-202,1000,-725,98,-402,1000,-156,1000,-908,-1000,-665,583,-458,1000,795,476,82,-159,-1000,325,308,-130,-1000,615,525,1000,-715,-1000,548,-342,-505,1000,392,817,473,354,1000,513,-1000,1000,888,-1000,97,433,-1000,297,198,-1000,1000,626,-1000,1000,-867,628,1000,1000,1000,-317,122,1000,-49}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00250() {
        org.junit.Assert.assertEquals("TYPE:org.jfree.chart.labels.StandardCategorySeriesLabelGenerator", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItemLabelGenerator():org.jfree.chart.labels.CategorySeriesLabelGenerator",
            new int[]{-607,-1000,-324,-669,-1000,295,168,-1000,-176,888,-196,-481,-899,-92,-725,-612,-276,-264,635,-688,943,-380,-92,-1000,185,-434,1000,52,-914,165,-317,-553,-1000,359,-637,526,-234,-247,552,-760,178,-724,545,-36,901,-437,401,447,-404,659,-565,-188,728,1000,231,-393,1000,549,767,85,-534,409,310,336}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00251() {
        org.junit.Assert.assertEquals("TYPE:org.jfree.chart.labels.StandardCategorySeriesLabelGenerator", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItemLabelGenerator():org.jfree.chart.labels.CategorySeriesLabelGenerator",
            new int[]{125,1000,-73,293,317,-216,329,1000,549,-1000,345,743,-298,-695,318,1000,763,35,-1000,456,-565,881,-750,850,-172,1000,-466,368,1000,-499,861,1000,400,984,-1000,-68,-149,437,-352,829,-649,40,-1000,322,-374,98,-45,-13,47,-922,1000,-288,-214,-1000,-754,-1000,-608,-341,1000,502,1000,-134,-1000,-380}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00252() {
        org.junit.Assert.assertEquals("TYPE:org.jfree.chart.labels.StandardCategorySeriesLabelGenerator", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItemLabelGenerator():org.jfree.chart.labels.CategorySeriesLabelGenerator",
            new int[]{-759,-375,431,-527,-1000,-249,492,137,-857,327,-1000,476,501,-771,-183,-493,-1000,-355,171,62,677,230,-845,-1000,145,769,752,-296,-1000,365,980,679,-874,1000,-900,-203,-248,251,867,-760,737,325,-855,671,862,-428,-261,1000,-1000,659,-2,16,370,1000,-997,-993,29,12,-88,-800,-224,1000,-1000,-851}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00253() {
        org.junit.Assert.assertEquals("TYPE:org.jfree.chart.labels.StandardCategorySeriesLabelGenerator", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItemLabelGenerator():org.jfree.chart.labels.CategorySeriesLabelGenerator",
            new int[]{-113,543,-851,-43,998,386,-61,1000,35,-1000,770,-699,-854,498,-1000,938,1000,-875,608,-233,1000,860,25,550,-1000,1000,1000,689,1000,-465,-490,-258,-353,299,1000,-1000,1000,-429,439,-400,1000,-297,-294,-470,493,1000,-824,-237,857,-1000,1000,275,-1000,-609,596,587,-819,309,-199,-465,1000,-929,-400,360}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00254() {
        org.junit.Assert.assertEquals("TYPE:org.jfree.chart.labels.StandardCategorySeriesLabelGenerator", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItemLabelGenerator():org.jfree.chart.labels.CategorySeriesLabelGenerator",
            new int[]{36,-788,943,796,-490,-593,-608,-1000,-1000,-170,-1000,-43,1000,-685,1000,-797,-459,646,64,964,-522,50,-768,-1000,-245,190,-47,118,-1000,588,1000,-375,-966,693,-1000,-443,396,1000,714,-495,1000,1000,-1000,51,-138,-724,-1000,1000,-1000,1000,148,134,197,1000,-1000,-838,-880,297,-655,-1000,-745,1000,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00255() {
        org.junit.Assert.assertEquals("TYPE:org.jfree.chart.labels.StandardCategorySeriesLabelGenerator", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItemLabelGenerator():org.jfree.chart.labels.CategorySeriesLabelGenerator",
            new int[]{-367,-106,-341,623,950,-751,61,1000,425,-712,-376,965,176,-1000,1000,-734,-318,767,968,-111,-522,-1000,-166,-657,-553,-698,-912,348,-838,588,-291,395,400,-153,-81,1000,1000,595,255,1000,-311,264,1000,260,-605,-1000,237,-551,-584,1000,-372,-274,556,-599,-596,-817,669,-187,419,515,-984,929,400,-15}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00256() {
        org.junit.Assert.assertEquals("TYPE:org.jfree.chart.labels.StandardCategorySeriesLabelGenerator", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItemLabelGenerator():org.jfree.chart.labels.CategorySeriesLabelGenerator",
            new int[]{-256,-201,787,-428,257,150,1,400,-330,191,-163,-656,27,-279,-499,-75,88,-167,423,-415,516,-316,-533,-288,-105,-179,637,342,1000,-132,-744,-462,353,792,762,-980,-238,-138,271,232,959,-646,993,109,-127,-119,879,-13,-290,-161,-173,-411,490,-1000,322,-548,464,89,1000,44,-244,-474,494,328}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00257() {
        org.junit.Assert.assertEquals("TYPE:org.jfree.chart.labels.StandardCategorySeriesLabelGenerator", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItemLabelGenerator():org.jfree.chart.labels.CategorySeriesLabelGenerator",
            new int[]{824,985,419,-452,334,947,-149,743,-470,-213,-881,-937,320,-238,1000,414,1000,917,-390,-645,415,818,-1000,653,-332,1000,808,349,434,-647,1000,337,1000,1000,616,-1000,1000,141,-309,352,1000,202,-1000,-286,101,-217,-691,261,-149,-580,1000,-492,-452,400,226,1000,-892,-773,-1000,-435,639,-580,1000,200}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00258() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItemToolTipGenerator():org.jfree.chart.labels.CategorySeriesLabelGenerator",
            new int[]{1000,456,-413,-728,-308,526,769,583,-801,662,-559,343,-1000,1000,645,899,207,1000,-137,922,1000,-404,-21,457,375,-1000,-283,-1000,1000,729,791,14,-630,69,-81,-812,-1000,-1000,1000,286,-195,300,-530,-1000,703,-591,853,623,206,141,-256,-771,-1000,563,-869,653,-71,-542,-500,504,-66,218,-369,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00259() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItemToolTipGenerator():org.jfree.chart.labels.CategorySeriesLabelGenerator",
            new int[]{295,1000,-926,1000,-26,798,-321,-527,689,-20,152,300,-250,975,1000,436,-309,449,1000,1000,-1000,-423,146,231,-756,-334,-624,567,624,1000,-121,379,-1000,-704,-634,-1000,672,-1000,481,-324,-557,411,663,-543,-11,530,-182,270,743,662,-662,1000,565,-1000,1000,-847,310,-442,-306,-1000,296,-1000,-369,819}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00260() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItemToolTipGenerator():org.jfree.chart.labels.CategorySeriesLabelGenerator",
            new int[]{506,715,-478,530,40,553,348,744,-726,228,-509,271,-273,812,-119,-109,35,1000,351,1000,-233,-74,343,765,365,-708,-272,261,486,668,-274,-1000,-349,951,-258,-259,215,-1000,1000,-706,224,-9,1000,-1000,-1000,510,696,345,766,1000,-372,504,91,-118,698,-584,-525,-769,-201,-844,400,-229,-854,394}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00261() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItemToolTipGenerator():org.jfree.chart.labels.CategorySeriesLabelGenerator",
            new int[]{-155,652,-866,213,-359,624,166,207,-316,652,342,290,-1000,329,-638,348,-222,1000,276,909,-365,4,868,1000,-620,-673,54,1000,1000,347,-1000,-582,-772,-507,-206,-1000,711,-460,1000,-1000,-48,89,837,-967,853,301,286,-465,458,1000,58,592,-1000,-1000,507,-694,1000,-746,-301,-938,229,429,-839,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00262() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItemToolTipGenerator():org.jfree.chart.labels.CategorySeriesLabelGenerator",
            new int[]{-837,34,-612,-302,910,72,376,163,879,160,-77,-210,255,-701,671,-243,30,24,1000,-400,-1000,682,-523,257,-711,-44,1000,737,1000,298,906,-234,82,-333,-731,793,-747,-432,375,-562,-154,818,-144,1000,-282,236,610,-107,250,320,-157,569,-250,954,-1000,-899,-508,138,602,484,-431,650,-128,214}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00263() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItemToolTipGenerator():org.jfree.chart.labels.CategorySeriesLabelGenerator",
            new int[]{-473,1000,-391,-232,549,1000,232,957,1000,218,718,-166,-595,-855,-27,-1000,-631,1000,72,1000,-314,-1000,402,1000,-919,-1000,44,-938,-168,1000,248,-343,-1000,-440,-685,-175,-1000,-1000,-397,-1000,-475,-1000,685,-238,-895,633,286,835,603,904,-1000,695,-173,825,-550,12,838,1000,265,1000,-290,-1000,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00264() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItemToolTipGenerator():org.jfree.chart.labels.CategorySeriesLabelGenerator",
            new int[]{1000,399,-189,-191,-1000,331,70,-280,119,-267,100,298,-379,1000,-260,1000,-66,567,-88,1000,-685,-244,-394,109,-84,621,-1000,208,1000,716,-816,200,-525,-820,-2,-1000,1000,-12,781,-104,-238,587,-91,-358,279,357,136,-550,1000,-268,-361,16,-144,-1000,1000,-305,92,-106,-1000,387,598,-1000,521,930}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00265() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItemToolTipGenerator():org.jfree.chart.labels.CategorySeriesLabelGenerator",
            new int[]{-355,449,-881,1000,-191,307,-249,-701,329,570,-1000,1000,346,1000,260,373,362,943,703,834,134,427,-896,-727,-234,-26,1000,208,-383,1000,594,518,-416,-693,-183,-108,-141,-298,308,632,-773,-143,-156,-609,313,-66,634,1000,-869,-162,-361,54,-514,887,-1000,795,496,858,529,955,759,11,-382,566}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00266() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItemToolTipGenerator():org.jfree.chart.labels.CategorySeriesLabelGenerator",
            new int[]{507,1000,-182,-535,588,1000,322,1000,-1000,-83,785,-464,-889,-518,-1000,-830,-398,1000,-382,559,-838,-1000,682,1000,-681,-1000,-846,-1000,873,-584,-131,-290,-1000,-420,-442,-1000,-640,263,254,-1000,-182,541,-1000,-627,-1000,984,482,929,1000,1000,-1000,348,-544,42,235,247,835,698,-259,1000,-260,-1000,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00267() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItemToolTipGenerator():org.jfree.chart.labels.CategorySeriesLabelGenerator",
            new int[]{762,-261,277,-738,-975,-258,776,475,-677,306,-679,692,-38,700,-994,767,50,738,-554,310,965,635,-830,560,985,843,-225,954,391,-246,-725,-151,514,757,297,686,931,805,498,-105,262,413,-78,-180,-82,-239,868,-961,505,-519,286,-405,-391,-396,733,-146,-833,143,-527,988,788,-174,426,380}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00268() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItemToolTipGenerator():org.jfree.chart.labels.CategorySeriesLabelGenerator",
            new int[]{-92,1000,-567,686,-313,-98,254,-156,679,1000,-867,617,383,383,1000,338,21,1000,482,1000,-540,131,-305,-81,-1000,-388,389,76,-1000,816,593,565,-794,-619,-402,335,-171,-1000,-257,-21,-1000,912,-551,-57,95,-132,1000,1000,-760,2,-370,57,-151,1000,-1000,-372,393,351,626,1000,994,-1000,-393,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00269() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItemToolTipGenerator():org.jfree.chart.labels.CategorySeriesLabelGenerator",
            new int[]{150,562,-428,-475,-981,937,879,373,1000,671,1000,-279,-366,383,1000,155,-373,1000,-290,1000,-1000,-802,-117,1000,-994,67,-1000,733,1000,813,-970,-1000,106,-1000,-13,18,970,-602,705,-1000,-108,912,-663,-718,-611,255,1000,-1000,713,294,-507,560,337,-354,1000,-599,491,-1000,487,-150,1000,-595,519,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00270() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItemURLGenerator():org.jfree.chart.labels.CategorySeriesLabelGenerator",
            new int[]{623,440,512,703,634,-956,430,657,-1000,836,-1000,-1000,588,-64,-896,756,-540,-1000,229,551,1000,617,-23,-425,1000,-584,78,269,-1000,-1000,-1000,-197,-1000,-1000,-337,1000,215,-1000,1000,712,128,-267,-1000,-195,357,-253,794,928,-334,-1000,-1000,-603,-1000,158,501,819,-1000,1000,1000,325,1000,-809,154,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00271() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItemURLGenerator():org.jfree.chart.labels.CategorySeriesLabelGenerator",
            new int[]{157,495,809,-1000,-1000,316,-823,-1000,130,351,-1000,-35,-627,-5,-1000,414,16,-402,1000,321,453,94,1000,-1000,-82,714,-110,574,-1000,666,506,-1000,612,233,-969,400,580,-781,1000,-580,-561,664,-478,900,-2,-258,-731,1000,599,99,-1000,1000,-1000,1000,-486,1000,44,-1000,942,-449,658,-211,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00272() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItemURLGenerator():org.jfree.chart.labels.CategorySeriesLabelGenerator",
            new int[]{-1000,-439,299,-1000,-378,483,46,-1000,130,-73,-154,-339,-915,579,-607,136,766,529,1000,-339,450,94,742,-801,334,1000,1000,1000,-1000,1000,1000,-1000,1000,1000,-1000,-1000,-94,-656,1000,-1000,-667,1000,199,1000,-980,-433,-1000,145,-334,824,40,186,-972,1000,30,1000,416,-1000,682,-410,-742,1000,-1000,-91}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00273() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItemURLGenerator():org.jfree.chart.labels.CategorySeriesLabelGenerator",
            new int[]{816,282,983,467,730,1000,-647,643,-389,1000,-600,-362,-1000,331,1000,136,-531,568,367,-780,1000,635,952,990,-19,833,1000,652,-1000,1000,442,958,132,874,-198,-46,-251,-777,1000,-1000,-1000,-441,-10,-959,-465,-686,297,516,196,355,-610,-335,-761,-866,-831,978,667,914,1000,343,984,1000,514,-676}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00274() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItemURLGenerator():org.jfree.chart.labels.CategorySeriesLabelGenerator",
            new int[]{-976,-328,8,-287,54,-186,221,-75,-366,965,596,-306,-625,725,-921,920,-482,467,278,-866,880,-896,420,444,410,48,344,644,223,425,758,650,988,218,865,-793,-122,536,-229,479,976,478,-424,559,-61,-846,-17,-785,-954,-634,390,-764,-684,168,964,-348,-702,-952,963,780,-668,864,735,576}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00275() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItemURLGenerator():org.jfree.chart.labels.CategorySeriesLabelGenerator",
            new int[]{61,316,627,109,1000,-1000,471,1000,-1000,518,-1000,-564,226,634,-1000,339,-78,-298,-370,-370,16,-199,-158,-181,1000,269,877,1000,-1000,-439,-1000,387,-735,-173,157,-782,658,-951,1000,489,-147,161,-750,471,376,-183,453,782,316,-344,-1000,201,-1000,228,999,155,-1000,301,-781,-251,582,-421,-227,-314}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00276() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItemURLGenerator():org.jfree.chart.labels.CategorySeriesLabelGenerator",
            new int[]{793,862,-306,1000,796,-324,-66,672,-842,694,-1000,-906,-816,510,-818,1000,-91,-905,741,282,641,509,482,1000,997,-906,-24,131,112,-560,-12,149,-661,-487,575,37,-511,-851,102,721,315,-102,-166,-1000,776,-140,1000,-550,361,-412,53,1000,-554,295,-1000,469,-544,400,787,-149,786,-869,814,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00277() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItemURLGenerator():org.jfree.chart.labels.CategorySeriesLabelGenerator",
            new int[]{13,1000,-617,693,-987,749,590,488,932,27,1000,-535,193,99,1000,673,643,-320,-806,1000,-590,31,684,-35,190,995,-347,-1000,-153,8,-294,1000,-588,-455,-226,-819,-1000,-195,-604,1000,-26,-1000,-153,-704,-778,1000,558,-1000,246,191,1000,-157,1000,-334,201,-472,752,1000,240,1000,-326,-715,340,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00278() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItemURLGenerator():org.jfree.chart.labels.CategorySeriesLabelGenerator",
            new int[]{757,932,668,94,-955,670,59,92,-350,737,-895,159,-369,913,50,653,576,778,522,-265,273,983,457,464,-111,663,275,802,149,640,146,-698,-997,741,-911,54,643,-962,920,-861,-649,-894,-388,-773,-363,493,-511,-716,402,-470,-138,362,-559,305,-766,378,-490,-797,959,460,385,744,406,958}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00279() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItemURLGenerator():org.jfree.chart.labels.CategorySeriesLabelGenerator",
            new int[]{-282,-376,269,275,-196,-251,766,-256,-63,451,46,-1000,523,623,-434,995,-69,-638,569,1000,1000,470,200,-1000,635,-1000,-354,-304,-1000,8,-400,55,276,-850,-55,517,-956,-333,415,1000,680,361,-618,516,-592,-608,-114,257,-892,-245,308,-1000,-944,195,840,1000,-75,1000,1000,817,-748,-798,233,-900}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00280() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItemURLGenerator():org.jfree.chart.labels.CategorySeriesLabelGenerator",
            new int[]{-510,-404,583,-701,369,87,-520,96,-815,-783,147,-252,-1000,-334,-371,381,833,1000,261,-1000,-1000,820,1000,635,766,1000,1000,949,-196,1000,926,-100,-579,1000,-837,227,1000,-1000,1000,-1000,-1000,277,250,-817,-1000,-479,-1000,21,1000,516,-336,-524,-633,243,-152,325,-814,-684,770,-352,178,1000,-833,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00281() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItemURLGenerator():org.jfree.chart.labels.CategorySeriesLabelGenerator",
            new int[]{-86,-200,934,768,77,458,483,887,-1000,562,-1000,-699,-871,396,-151,461,-262,79,-291,-198,257,262,174,-3,1000,-228,465,-309,-820,-339,-447,-197,-1000,335,-3,1000,-124,-981,318,331,-127,1000,-180,-660,-715,17,329,449,769,-1000,-440,1000,-536,53,-614,476,-283,61,565,446,-706,507,-1000,-738}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00282() {
        org.junit.Assert.assertEquals("STATE:org.jfree.chart.LegendItemCollection|getItemCount=22:java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItems():org.jfree.chart.LegendItemCollection",
            new int[]{-732,1000,464,999,488,552,599,694,156,669,908,-647,655,1000,505,157,-249,-600,696,389,-492,1000,-1000,-1000,-885,1000,0,-463,-471,105,-228,-614,-1000,492,1000,369,-85,0,-541,-1000,-119,-444,-395,-1000,789,-26,227,384,-1000,-1000,-807,-553,372,101,-527,-1000,-707,-467,700,1000,-565,-756,-476,87}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00283() {
        org.junit.Assert.assertEquals("STATE:org.jfree.chart.LegendItemCollection|getItemCount=22:java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItems():org.jfree.chart.LegendItemCollection",
            new int[]{-151,930,464,259,-1000,-1000,-881,-771,156,-856,128,-568,7,1000,-529,-750,-1000,932,318,-727,1000,-581,-1000,-1000,1000,244,-979,-1000,743,-826,1000,-1000,-1000,-628,903,-172,983,0,253,974,897,-169,27,-1000,789,1000,232,1000,-761,782,1000,-280,-761,-149,993,-727,-639,-540,1000,-67,655,826,1000,627}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00284() {
        org.junit.Assert.assertEquals("STATE:org.jfree.chart.LegendItemCollection|getItemCount=22:java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItems():org.jfree.chart.LegendItemCollection",
            new int[]{1000,-828,499,1000,951,-407,857,1000,610,-542,1000,-929,779,926,1000,-917,-1000,1000,1000,881,-978,1000,-1000,568,-1000,671,-1000,-549,-440,827,1000,-1000,201,1000,1000,-1000,-839,73,-1000,-586,-1000,-117,-876,-1000,1000,-1000,-9,-6,1000,-216,-666,508,-1000,-921,1000,-1000,1000,-1000,945,1000,-615,-1000,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00285() {
        org.junit.Assert.assertEquals("STATE:org.jfree.chart.LegendItemCollection|getItemCount=22:java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItems():org.jfree.chart.LegendItemCollection",
            new int[]{-379,400,123,-109,370,1000,1000,709,63,253,332,272,617,1000,-12,811,209,15,-1000,226,31,-565,41,331,-981,1000,-335,-400,-1000,362,-1000,-78,828,10,51,-386,64,-45,74,-1000,301,-285,400,-543,152,-25,1000,-291,-464,-102,-1000,1000,597,-953,-400,-259,-593,-14,640,301,-935,-663,-1000,-622}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00286() {
        org.junit.Assert.assertEquals("STATE:org.jfree.chart.LegendItemCollection|getItemCount=22:java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItems():org.jfree.chart.LegendItemCollection",
            new int[]{1000,-1000,77,-435,-1000,1000,922,824,-204,-61,89,1000,1000,902,-574,218,-1000,1000,-990,-23,1000,-565,1000,1000,-1000,191,-61,1000,-973,1000,-345,986,697,-109,-1000,-600,-1000,1000,1000,-1000,849,-155,-1000,-139,-335,790,-329,-691,-1000,-930,-828,996,1000,366,773,1000,807,-67,-760,-317,125,-705,-813,-974}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00287() {
        org.junit.Assert.assertEquals("STATE:org.jfree.chart.LegendItemCollection|getItemCount=22:java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItems():org.jfree.chart.LegendItemCollection",
            new int[]{-1000,1000,-426,1000,956,1000,1000,595,-294,-83,952,-502,209,1000,-198,575,1000,-555,562,863,1000,1000,-1000,45,281,1000,736,-1000,-1000,1000,-601,1000,-1000,-492,1000,51,933,-585,-323,-1000,217,81,1000,-1000,1000,-1000,1000,838,351,183,-1000,-644,-1000,-885,-1000,-1000,-1000,-584,1000,-611,-793,394,-1000,-498}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00288() {
        org.junit.Assert.assertEquals("STATE:org.jfree.chart.LegendItemCollection|getItemCount=22:java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItems():org.jfree.chart.LegendItemCollection",
            new int[]{1000,-1000,597,-835,-110,1000,1000,593,-1000,-937,747,1000,1000,1000,-574,-509,-227,264,-1000,-250,-55,-49,1000,1000,-1000,587,-708,524,-973,1000,-309,153,697,615,-1000,-382,-556,453,1000,-1000,1000,-794,-1000,-240,-1000,-23,-996,-1000,-748,-1000,-1000,-504,1000,1000,-44,168,1000,620,-1000,-1000,-1000,-1000,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00289() {
        org.junit.Assert.assertEquals("STATE:org.jfree.chart.LegendItemCollection|getItemCount=22:java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItems():org.jfree.chart.LegendItemCollection",
            new int[]{388,629,-146,838,-153,-739,844,-157,-60,795,622,-56,304,898,871,-447,4,191,231,-6,719,1000,62,-1000,-43,733,-789,-596,-347,270,-233,-596,164,-295,1000,1000,354,-143,257,-333,-230,-307,-211,-1000,494,-666,808,-202,82,-413,-322,38,-354,-553,901,-319,-580,-738,444,610,138,-503,-227,191}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00290() {
        org.junit.Assert.assertEquals("STATE:org.jfree.chart.LegendItemCollection|getItemCount=22:java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItems():org.jfree.chart.LegendItemCollection",
            new int[]{-1000,918,-418,708,439,-1000,596,-856,143,-1000,-600,-341,510,899,1000,-125,51,-706,-879,-609,352,-428,747,-1000,258,1000,-962,-1000,-129,-214,132,-1000,-595,-1000,-833,-82,1000,462,483,-37,-290,-691,33,-496,678,249,475,1000,-552,228,790,-858,-455,-955,-288,-1000,-775,394,1000,1000,-728,-153,-396,544}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00291() {
        org.junit.Assert.assertEquals("STATE:org.jfree.chart.LegendItemCollection|getItemCount=22:java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItems():org.jfree.chart.LegendItemCollection",
            new int[]{757,203,152,667,399,164,222,818,-460,-907,632,100,519,899,735,-228,-79,-706,-879,-609,-711,947,204,474,-535,775,-876,144,-471,814,-628,52,-680,134,-833,-193,350,-378,-882,-626,-444,93,973,-503,-230,-851,-617,-992,66,-515,-485,-858,201,945,-931,-600,254,500,-191,-639,-728,551,-942,-65}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00292() {
        org.junit.Assert.assertEquals("STATE:org.jfree.chart.LegendItemCollection|getItemCount=22:java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItems():org.jfree.chart.LegendItemCollection",
            new int[]{1000,-1000,-298,-607,308,-400,199,-102,693,-747,-311,53,-48,591,1000,-9,839,585,-1000,-460,848,-357,1000,1000,-1000,191,-638,1000,-585,302,-433,462,1000,-846,-1000,-728,-1000,1000,1000,-453,-177,-531,-1000,83,-655,-1000,-329,-1000,-1000,-998,-374,1000,1000,-155,1000,1000,613,113,-933,155,1000,-994,-944,-930}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00293() {
        org.junit.Assert.assertEquals("STATE:org.jfree.chart.LegendItemCollection|getItemCount=22:java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItems():org.jfree.chart.LegendItemCollection",
            new int[]{682,-291,-209,459,-779,-1000,-32,-729,281,-432,-180,-702,262,557,871,-447,-416,737,-792,-104,783,-524,1000,-772,98,1000,-789,-518,-195,3,-662,-596,663,-865,-1000,-36,115,-106,817,-218,-466,-443,-211,-683,-686,113,1000,-666,-1000,305,-218,383,-864,-1000,993,159,-1000,-14,753,610,814,31,232,381}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00294() {
        org.junit.Assert.assertEquals("STATE:org.jfree.chart.LegendItemCollection|getItemCount=22:java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItems():org.jfree.chart.LegendItemCollection",
            new int[]{1000,1000,-76,838,-621,-361,-756,1000,203,795,49,-1000,-311,-1000,-1000,356,-268,1000,1000,-295,1000,1000,1000,37,1000,-699,626,835,827,-1000,1000,-130,-1000,-815,497,-1000,1000,1000,199,843,1000,-47,-790,526,326,794,-1000,1000,-535,-672,-322,-924,1000,997,903,-319,-580,-825,553,688,346,-768,652,-627}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00295() {
        org.junit.Assert.assertEquals("STATE:org.jfree.chart.LegendItemCollection|getItemCount=22:java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItems():org.jfree.chart.LegendItemCollection",
            new int[]{581,314,529,1000,112,-627,285,372,427,1000,1000,-77,721,993,1000,-1000,-400,220,976,49,-693,1000,-889,-1000,-1000,389,-1000,-314,-20,264,-271,-1000,286,993,145,911,-658,-303,-457,-93,-664,-388,-1000,-579,1000,-1000,20,-337,1000,-1000,-133,508,-136,-361,868,-523,1000,-521,272,1000,-28,-1000,-424,729}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00296() {
        org.junit.Assert.assertEquals("STATE:org.jfree.chart.LegendItemCollection|getItemCount=22:java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getLegendItems():org.jfree.chart.LegendItemCollection",
            new int[]{50,-1000,52,115,370,-331,1000,402,-641,-193,268,301,1000,1000,1000,-431,263,597,-1000,313,-797,181,1000,530,-981,1000,-1000,-910,-1000,1000,-1000,785,186,-23,-1000,305,327,98,951,-891,-5,-1000,-298,-1000,-1000,-25,1000,-1000,-1000,75,-1000,625,-594,-812,-169,-675,-1000,1000,78,-80,-632,-746,-1000,-317}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00297() {
        org.junit.Assert.assertEquals("java.lang.Integer:MQ==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getPassCount():int",
            new int[]{952,578,-271,-556,-552,367,511,-1000,-227,1000,-248,-742,-1000,978,-894,243,-1000,462,763,-185,-1000,1000,-916,-869,539,1000,383,755,1000,1000,841,555,5,-1000,-428,-1000,867,-128,751,-589,-487,-24,86,-964,118,-1000,-921,-251,-310,-790,329,148,-1000,1000,1000,-500,716,277,-1000,194,64,500,-113,818}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00298() {
        org.junit.Assert.assertEquals("java.lang.Integer:MQ==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getPassCount():int",
            new int[]{455,658,669,-203,-666,247,222,-620,693,813,-471,-1000,591,1000,266,-1000,-666,562,613,1000,-712,-537,-1000,-781,1000,916,1000,-780,1000,347,381,1000,466,-887,-922,259,-366,748,902,-629,-1000,404,-431,1000,-501,-332,-1000,-1000,-397,-818,-4,377,-1000,570,1000,-1000,933,-1000,-226,-1000,1000,922,919,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00299() {
        org.junit.Assert.assertEquals("java.lang.Integer:MQ==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getPassCount():int",
            new int[]{1000,940,394,-929,-352,411,-20,-1000,636,1000,-701,-1000,-436,1000,-1000,-784,-1000,555,1000,1000,-1000,619,-1000,-1000,936,-313,1000,608,558,169,1000,314,493,-1000,-1000,-1000,895,126,1000,-1000,-1000,-229,-1000,42,-1000,-556,-1000,-1000,68,-1000,898,1000,-1000,1000,1000,-1000,1000,-104,-14,950,1000,772,820,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00300() {
        org.junit.Assert.assertEquals("java.lang.Integer:MQ==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getPassCount():int",
            new int[]{-648,1000,-722,295,766,-1000,479,-533,1000,595,187,986,728,464,-270,-1000,1000,416,1000,759,-847,-708,-386,-270,-347,95,1000,1000,1000,-1000,-1000,317,-110,-946,537,-162,-363,339,590,1000,-1000,-403,-1000,-185,310,279,271,-1000,-85,723,-654,533,319,629,-52,-603,-118,-835,647,-765,269,1000,-272,651}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00301() {
        org.junit.Assert.assertEquals("java.lang.Integer:MQ==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getPassCount():int",
            new int[]{498,-1000,-107,-473,-299,204,873,1000,-1000,-72,-11,-47,-125,-734,-518,913,-158,-160,617,-511,5,871,1000,28,-735,-523,-547,-271,-727,1000,1000,-253,529,975,177,912,-393,-1000,-401,-764,1000,490,1000,-674,-358,-455,-524,576,1000,-95,207,-1000,1000,-845,-102,990,705,-132,-322,1000,-1000,-1000,144,133}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00302() {
        org.junit.Assert.assertEquals("java.lang.Integer:MQ==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getPassCount():int",
            new int[]{-1000,1000,-26,138,457,986,92,-902,100,599,-908,413,-693,-257,-517,257,-130,1000,733,-153,113,-421,-1000,-1000,-600,-232,445,1000,1000,569,-1000,759,-235,1000,-703,-390,-1000,979,481,-613,-492,1000,-1000,133,1000,714,376,-533,-1000,914,-561,998,403,1000,-967,-903,146,-1000,380,-870,580,809,-556,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00303() {
        org.junit.Assert.assertEquals("java.lang.Integer:MQ==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getPassCount():int",
            new int[]{-477,780,-157,-1000,365,74,-848,-606,-306,101,683,-629,-112,-341,-204,243,-286,1000,776,-130,302,-609,-1000,-1000,1000,-767,1000,218,-45,-260,-869,515,-224,94,-315,120,-444,485,285,340,-10,-912,-895,-245,1000,280,897,-458,-1000,-621,-1000,-531,-937,828,550,-325,939,-1000,644,-588,-119,523,-159,-513}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00304() {
        org.junit.Assert.assertEquals("java.lang.Integer:MQ==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getPassCount():int",
            new int[]{959,-975,491,-729,389,-790,1000,112,239,780,-110,-203,48,138,-231,168,-504,-1000,97,1000,-1000,1000,12,-660,302,1000,-856,-571,396,1000,841,186,-515,-78,172,431,791,-1000,1000,-998,-133,316,941,969,-745,-288,-1000,-145,1000,-273,1000,-1000,-888,709,1000,647,785,-1000,-1000,1000,-544,-724,506,579}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00305() {
        org.junit.Assert.assertEquals("java.lang.Integer:MQ==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getPassCount():int",
            new int[]{1000,-1000,139,-361,-240,-785,336,502,-377,593,-129,693,229,-683,80,487,-284,-1000,128,74,-719,588,74,113,-1000,1000,740,56,-21,595,486,-544,1000,711,-465,1000,1000,-1000,1000,-638,-847,-1000,1000,-624,-1000,-259,-529,916,1000,-1000,1000,12,-1000,109,1000,1000,952,873,-1000,1000,-318,-1000,969,599}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00306() {
        org.junit.Assert.assertEquals("java.lang.Integer:MQ==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getPassCount():int",
            new int[]{1000,885,183,-29,-1000,360,1000,-216,-155,-327,300,-1000,898,-179,582,512,812,-675,-656,-1000,-229,-884,-500,1000,628,-313,1000,600,558,169,-278,314,976,-267,-443,133,-554,126,-409,2,-607,-966,923,-20,-1000,-548,1000,849,400,-773,-648,1000,-101,-791,-1000,913,-557,-104,-637,950,-271,893,-1000,-946}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00307() {
        org.junit.Assert.assertEquals("java.lang.Integer:MQ==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getPassCount():int",
            new int[]{1000,-246,-291,-410,-1000,358,325,-1000,225,1000,-242,-592,842,57,244,-287,-480,-342,530,1000,-1000,310,-1000,-1000,-62,827,-83,32,1000,400,942,-7,232,-233,-238,437,1000,-339,440,-1000,1000,1000,583,-755,-1000,-1000,-1000,157,726,-421,1000,-31,-536,-291,1000,393,664,-264,-1000,480,-400,1000,935,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00308() {
        org.junit.Assert.assertEquals("java.lang.Integer:MQ==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getPassCount():int",
            new int[]{864,-804,-761,798,-385,542,-436,393,-556,94,-842,687,-253,11,-993,317,-296,-627,-78,55,936,614,-418,392,626,-583,107,495,342,-735,180,382,-345,-958,401,-629,-482,-223,148,583,345,916,-954,-383,-263,-652,-142,-606,879,-182,555,570,780,-652,-826,-23,-258,784,101,60,-322,-273,470,444}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00309() {
        org.junit.Assert.assertEquals("java.lang.Integer:MQ==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getPassCount():int",
            new int[]{-1000,-874,-761,-273,1000,854,213,1000,-716,94,-842,804,-1000,-366,-839,1000,90,839,550,-398,-38,182,-418,-781,-1000,-583,45,-1000,21,894,584,-314,425,1000,-1000,-129,-327,284,51,-1000,414,1000,497,-669,1000,-497,-1000,94,-915,226,-179,-1000,594,1000,-671,79,180,-753,-1000,-63,-72,-638,52,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00310() {
        org.junit.Assert.assertEquals("java.lang.Integer:MQ==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getPassCount():int",
            new int[]{-93,310,63,1000,872,-15,909,-316,406,161,-168,-1000,462,-126,514,287,761,-840,-541,-396,-737,-1000,-971,1000,-183,-172,1000,641,92,269,-1000,387,278,-1000,-674,-1000,346,-561,1000,188,-769,649,827,-847,-585,-314,292,491,-1000,431,-1000,499,314,445,-608,532,-389,439,-1000,932,1000,677,-1000,-170}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00311() {
        org.junit.Assert.assertEquals("java.lang.Integer:MQ==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getPassCount():int",
            new int[]{-39,476,287,-207,-1000,1000,481,14,291,-53,176,-630,715,-260,660,276,832,-292,-679,-846,-299,-1000,-840,244,-403,275,1000,1000,1000,204,-741,-138,783,395,-858,191,629,-56,906,42,-390,450,890,-707,-110,-544,81,784,-78,591,-401,742,-1000,331,-817,604,28,74,-919,929,532,715,-315,-47}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00312() {
        org.junit.Assert.assertEquals("java.lang.Integer:MQ==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getPassCount():int",
            new int[]{-45,465,-271,-687,135,471,-340,-367,1000,1000,-797,-117,1000,978,315,-480,147,-149,-229,1000,-1000,-1000,-1000,-785,-342,1000,1000,851,1000,-55,-451,150,1000,-57,-1000,-241,1000,678,1000,-743,-1000,376,-1000,249,118,-934,-921,-867,708,396,329,1000,-1000,1000,817,-899,429,-660,-120,-870,1000,842,955,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00313() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getPlot():org.jfree.chart.plot.CategoryPlot",
            new int[]{661,353,-91,520,1000,-972,231,-995,1000,-929,-1000,810,-1000,1000,511,1000,-1000,1000,1000,1000,1000,-1000,1000,-1000,835,880,180,-1000,1000,-1000,168,-543,-1000,-1000,1000,1000,667,-923,1000,-1000,-1000,-651,-1000,1000,1000,-867,-833,1000,464,230,546,-818,185,1000,1000,-591,-1000,1000,131,-1000,-1000,-575,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00314() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getPlot():org.jfree.chart.plot.CategoryPlot",
            new int[]{1000,-1000,-263,325,1000,644,576,-145,978,475,304,1000,-327,657,-225,112,-520,105,1000,-697,1000,-609,701,-1000,1000,-118,126,-69,1000,-1000,107,-601,-233,-1000,1000,786,615,-1000,995,384,-1000,-1000,634,-679,1000,523,300,959,-1000,21,-374,951,-1000,599,1000,-1000,-593,-513,-207,-790,51,278,302,-531}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00315() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getPlot():org.jfree.chart.plot.CategoryPlot",
            new int[]{771,-1000,-401,980,311,-1000,231,189,89,1000,1000,-1000,1000,-922,1000,-1000,309,-694,274,-1000,-113,-391,1000,-1000,1000,320,-254,1000,-823,31,1000,-752,1000,-246,-1000,-1000,1000,1000,-891,262,1000,-65,1000,-857,-839,1000,-1000,152,-766,62,690,-592,-448,-868,-895,629,-97,-1000,-580,1000,-158,-725,1000,692}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00316() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getPlot():org.jfree.chart.plot.CategoryPlot",
            new int[]{577,-1000,943,60,1000,730,576,550,-422,1000,1000,582,-590,657,-38,112,-604,-885,-613,-1000,655,-484,-636,-634,565,-826,-759,548,-88,254,107,-405,327,-393,1000,88,1000,-573,485,763,-1000,-1000,1000,-596,127,1000,839,865,-1000,-307,35,-629,-1000,-102,249,-488,251,-513,26,163,-26,-125,323,-946}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00317() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getPlot():org.jfree.chart.plot.CategoryPlot",
            new int[]{536,-740,523,157,1000,865,576,-42,978,767,668,565,-590,657,-225,112,-604,-316,749,-688,-313,-923,32,-1000,1000,-5,-341,239,490,-7,107,-573,156,-1000,1000,802,759,-1000,740,50,-1000,-1000,783,-679,563,486,761,979,-900,118,-365,-1000,-992,354,629,-828,-144,-513,-257,-314,51,173,302,-749}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00318() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getPlot():org.jfree.chart.plot.CategoryPlot",
            new int[]{1000,-838,-792,518,609,404,716,-546,-433,-94,-1000,24,-1000,1000,1000,1000,-1000,1000,-198,1000,-418,176,451,753,-364,409,-612,-1000,-188,31,-1000,-412,-1000,757,1000,-951,216,1000,1000,-748,-1000,165,-1000,1000,-11,-118,-1000,-389,-339,-1000,-1000,-186,-15,671,-20,-59,-532,1000,120,-1000,-1000,-1000,400,-91}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00319() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getPlot():org.jfree.chart.plot.CategoryPlot",
            new int[]{1000,-773,-392,-191,761,744,580,512,-226,747,840,1000,-721,1000,314,129,-604,-498,210,-788,1000,-323,-282,-1000,388,-827,-126,279,154,-87,107,-656,-30,-740,301,-25,802,-839,863,627,-584,-867,1000,882,765,844,312,694,-742,-403,-5,-818,-1000,184,885,-80,-275,-706,-515,-1000,-890,-12,665,-733}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00320() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getPlot():org.jfree.chart.plot.CategoryPlot",
            new int[]{1000,-37,-401,1000,175,1000,259,-127,-397,1000,1000,854,331,-929,-1000,-1000,-184,-1000,562,-1000,701,-236,-820,-837,1000,-263,-35,1000,992,-1000,882,-698,1000,-986,-427,-243,488,-1000,-409,1000,-152,-592,1000,-1000,866,832,738,207,-1000,160,863,-423,-15,-657,-1000,-387,756,304,-70,-37,839,908,1000,-914}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00321() {
        org.junit.Assert.assertEquals("TYPE:org.jfree.chart.plot.CategoryPlot", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getPlot():org.jfree.chart.plot.CategoryPlot",
            new int[]{-1000,1000,454,1000,-495,69,-659,-1000,1000,-52,-1000,458,222,-36,450,-541,662,668,1000,70,754,-308,1000,-830,-852,153,-384,1000,393,-819,810,-240,-563,37,-1000,451,-369,486,364,-174,1000,980,-1000,-991,101,-1000,210,-1000,841,1000,-126,522,1000,-1000,-319,1000,819,385,-123,259,396,-246,-212,-41}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00322() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getPlot():org.jfree.chart.plot.CategoryPlot",
            new int[]{209,-348,-756,1000,423,999,265,-185,23,1000,-1000,463,275,-525,-979,1000,-184,-1000,707,-1000,790,-320,-400,-928,1000,-301,-45,1000,1000,-1000,882,152,860,-996,1,21,607,-1000,11,937,-406,-817,1000,882,906,689,738,424,-1000,248,539,257,-1000,-265,796,-615,16,-1000,-132,-219,771,825,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00323() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getPlot():org.jfree.chart.plot.CategoryPlot",
            new int[]{-1000,771,404,237,-47,983,1000,256,-1000,316,-129,-24,-520,275,836,-79,44,1000,-945,-578,-266,111,1000,-348,-1000,-709,-405,841,-222,-501,-1000,6,44,854,-400,-404,417,341,191,636,400,875,-355,-394,-253,253,452,-871,-991,-6,-1000,-624,216,580,-466,1000,1000,570,282,562,-23,-920,-420,-801}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00324() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getPlot():org.jfree.chart.plot.CategoryPlot",
            new int[]{647,1000,548,-738,1000,672,1000,460,-457,-939,-156,701,-1000,1000,838,1000,-1000,431,-425,1000,600,-1000,1000,-429,40,-872,-91,-1000,144,-976,-1000,45,-828,-290,1000,1000,943,-1000,767,382,-1000,-1000,-808,1000,1000,899,-715,1000,98,-1000,-688,662,-966,1000,1000,-820,-291,1000,570,-1000,-1000,-1000,-1000,-556}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00325() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getPlot():org.jfree.chart.plot.CategoryPlot",
            new int[]{12,-637,909,65,1000,529,973,440,-127,-502,150,900,-1000,1000,617,1000,-1000,1000,0,321,580,-313,-210,-234,824,714,164,-1000,-24,-812,-922,83,-1000,-280,858,998,242,-1000,1000,-115,-972,-103,-422,478,1000,455,-13,915,-1000,-878,-224,38,-1000,221,1000,-335,101,1000,291,-954,-563,-466,-1000,-435}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00326() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getRowCount():int",
            new int[]{-282,1000,-266,856,-118,560,551,-157,-335,-51,848,-379,-5,-168,-1000,808,-785,-64,503,-1000,724,-20,-379,-1000,-216,-215,-504,355,686,-404,359,-200,762,789,619,-4,-63,-375,251,-716,-1000,-580,307,49,-920,1000,-235,267,45,1000,-70,301,-183,-1000,1000,-530,-3,239,993,88,195,-1000,-1000,-834}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00327() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getRowCount():int",
            new int[]{-962,963,-188,1000,356,708,274,904,-1000,901,1000,-442,727,-942,-807,243,-114,328,-339,-1000,202,-830,267,-816,-976,-880,-130,154,-195,-160,-74,-563,349,881,-405,-801,-1000,-607,959,66,-834,-159,-1000,729,-256,784,-471,903,-818,1000,1000,1000,1000,-1000,424,-333,-258,-710,690,-313,757,55,-756,-720}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00328() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getRowCount():int",
            new int[]{-628,74,259,842,-19,560,551,874,-445,1000,339,-104,802,-752,-1000,-1000,872,-141,-1000,-915,-1000,-856,40,1000,-638,-713,-141,90,216,-519,97,-270,-658,1000,-797,-726,-904,-709,251,921,-682,-682,-1000,666,594,468,-57,742,-745,1000,1000,665,827,-1000,-332,-530,-981,-753,912,-789,195,-859,1000,-991}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00329() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getRowCount():int",
            new int[]{456,1000,87,510,-541,-638,-21,-1000,78,-1000,1000,-417,-390,-152,-1000,1000,-1000,552,1000,-1000,1000,1000,283,-1000,1000,1000,-123,824,504,17,679,20,990,261,1000,333,683,259,-1000,-1000,-312,95,1000,-1000,-1000,987,-865,-219,1000,339,-1000,-508,-1000,-608,586,-1000,1000,-1000,1000,1000,-482,149,-1000,150}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00330() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getRowCount():int",
            new int[]{596,836,334,651,354,-430,-25,-301,907,-455,201,86,-496,-494,948,517,-422,980,55,631,596,-428,971,-620,593,856,-838,76,154,239,-806,544,689,533,140,-103,-417,-643,-828,-340,13,918,-10,177,73,-719,86,-433,197,794,728,-187,-168,-35,59,-970,-202,-174,700,431,-156,557,866,-957}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00331() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getRowCount():int",
            new int[]{485,382,-267,1000,44,1000,-949,376,344,-236,230,-770,-1000,-382,1000,48,432,1000,-46,792,-1000,-1000,702,1000,-322,-189,-785,-871,832,11,184,162,-1000,1000,-1000,-827,-891,-1000,-5,291,-34,524,-400,191,1000,-780,-177,196,-309,400,1000,660,642,-723,-102,-428,-257,-658,-364,-6,858,-744,-21,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00332() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getRowCount():int",
            new int[]{357,1000,507,240,-1000,-759,-184,-1000,17,-92,1000,-527,280,-124,590,1000,-1000,343,1000,-1000,607,1000,-379,-420,1000,1000,1000,1000,-960,-11,562,-216,1000,0,1000,730,1000,391,-1000,-1000,706,-87,1000,-1000,-963,1000,-1000,167,1000,-1000,-665,-120,-1000,1000,574,-1000,1000,-659,654,888,-947,1000,-692,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00333() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getRowCount():int",
            new int[]{90,1000,-711,591,-850,931,633,-454,225,-135,-194,-1000,440,308,1000,637,-1000,-907,339,-895,-80,-307,-362,424,-1000,-466,1000,-303,-1000,63,930,171,-55,649,788,776,418,-259,-296,-1000,357,-624,881,-440,-380,649,-1000,560,858,-580,584,118,-162,413,1000,-308,814,-556,455,-765,-856,58,-644,-189}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00334() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getRowCount():int",
            new int[]{299,375,454,1000,-76,1000,-943,904,-820,1000,917,-541,774,-1000,1000,243,1000,194,-347,-400,-1000,-1000,847,1000,-1000,-865,-175,-1000,362,354,17,-654,-1000,1000,-1000,-778,-1000,-1000,1000,1000,-608,-13,-1000,600,1000,248,-905,810,-1000,799,972,1000,1000,-959,-508,-51,-1000,-1000,543,-313,1000,-315,1000,-700}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00335() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getRowCount():int",
            new int[]{918,1000,-662,620,-968,931,-949,-824,861,-1000,415,-1000,-960,232,1000,862,-827,420,1000,359,-720,-470,272,1000,-276,102,243,-621,-67,477,742,832,-1000,649,383,299,184,-511,-1000,-780,1000,137,1000,-741,640,-454,-1000,-3,1000,-1000,805,140,-137,607,1000,-938,1000,-475,-445,-69,-542,-164,11,-189}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00336() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getRowCount():int",
            new int[]{494,902,-571,798,-115,553,-504,-247,1000,-575,590,-581,-1000,-138,1000,903,-584,-1000,283,1000,-380,-1000,490,302,-446,1000,-697,-568,61,291,191,326,-400,654,556,-495,-255,-980,-874,-611,524,660,506,61,731,-652,-456,-336,404,-777,1000,232,217,-291,-29,-957,359,-310,-258,-294,-460,185,203,-594}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00337() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getRowCount():int",
            new int[]{628,349,529,716,1000,-810,-659,-861,532,-453,-305,-308,-949,455,669,-839,894,986,-287,983,-579,307,114,92,-567,900,-1000,261,929,289,873,804,-426,1000,-1000,2,-1000,-123,155,1000,-520,1000,-575,308,595,-609,559,-1000,296,1000,1000,1000,85,1000,983,151,-1000,614,1000,983,1000,-955,-117,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00338() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getRowCount():int",
            new int[]{559,836,334,-107,-495,404,20,780,372,-592,634,-476,-194,-1000,1000,299,-574,176,-164,-276,-611,-426,821,71,527,294,-431,-203,317,49,-947,-78,-542,483,271,-1000,-417,-968,-903,96,-64,286,-420,221,1000,-418,-344,1000,-154,-890,174,-56,275,-73,-1000,-1000,27,-917,273,225,319,-141,217,116}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00339() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getRowCount():int",
            new int[]{801,-472,223,612,22,795,761,851,945,201,-170,654,-585,-536,1000,235,-579,241,-1000,488,562,-949,4,-1000,-46,1000,-755,-114,-16,-672,-1000,175,640,398,432,-711,85,-1000,-592,-541,-650,15,11,874,1000,-808,977,1000,-344,-89,363,-406,-1000,-1000,317,-966,-307,-505,-74,-1000,-436,337,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00340() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getSeriesItemLabelGenerator(int):org.jfree.chart.labels.CategoryItemLabelGenerator",
            new int[]{-45,17,298,-379,-426,998,1000,-669,142,-134,595,229,108,285,177,593,-251,302,-400,1000,1000,-1000,938,476,410,-934,-983,-267,-557,-245,796,554,801,1000,849,405,715,594,116,996,1000,296,2,-806,797,1000,192,282,-378,251,-115,-253,113,406,-299,282,-723,400,437,-400,1000,901,1000,93}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00341() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getSeriesItemLabelGenerator(int):org.jfree.chart.labels.CategoryItemLabelGenerator",
            new int[]{-421,797,-246,-586,-379,711,972,-372,-346,108,-327,18,371,-730,999,333,-964,41,214,618,433,-438,751,79,-474,263,-257,-810,-227,360,590,-22,958,842,-278,137,336,-803,-478,977,926,979,-886,-952,845,-260,-371,761,-272,-212,446,290,502,811,-79,-356,-993,452,159,-121,335,630,473,157}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00342() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getSeriesItemLabelGenerator(int):org.jfree.chart.labels.CategoryItemLabelGenerator",
            new int[]{-571,-158,-196,1000,-1000,752,132,208,851,1000,624,-439,324,-1000,-1000,1000,1000,473,1000,-712,1000,642,856,616,1000,400,-1000,1000,-1000,265,-588,285,-174,749,1000,982,-947,-647,-288,-643,-1000,1000,-733,-1000,-1000,936,855,-227,-714,-400,-605,1000,-1000,-36,422,1000,-878,-1000,-959,334,545,1000,-440,438}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00343() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getSeriesItemLabelGenerator(int):org.jfree.chart.labels.CategoryItemLabelGenerator",
            new int[]{343,1000,68,24,-196,-1000,118,-446,-1000,-563,-467,-594,560,-852,-815,-923,-279,-1000,-773,1000,-1000,623,-464,-30,-786,686,1000,-1000,1000,-251,1000,-1000,1000,49,1000,167,-1000,-1000,-1000,1000,-1000,-224,-1000,-371,200,-1000,-1000,71,212,-560,-1000,857,1000,1000,1000,-1000,-1000,-1000,242,-62,-1000,-948,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00344() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getSeriesItemLabelGenerator(int):org.jfree.chart.labels.CategoryItemLabelGenerator",
            new int[]{-1000,1000,59,808,-1000,714,-80,-64,-809,1000,-1000,1000,-890,345,-68,-60,-1000,943,1000,58,-911,-54,-1000,-799,-1000,-1000,99,-1000,1000,1000,-1000,513,222,-426,1000,812,-283,-1000,1000,-529,-269,580,-1000,-935,-1000,-985,-1000,912,-180,1000,590,-400,323,619,-1000,-579,-978,-1000,832,1000,-1000,-1000,-18,514}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00345() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getSeriesItemLabelGenerator(int):org.jfree.chart.labels.CategoryItemLabelGenerator",
            new int[]{173,-294,-771,-35,-1000,748,741,-664,-372,1000,-235,-669,541,-1000,452,1000,131,268,-16,-136,1000,-263,822,654,466,991,-1000,54,-912,415,940,412,1000,773,538,1000,35,383,-1000,708,-439,1000,-1000,-1000,-13,318,-1000,561,-206,-805,921,426,-878,801,483,155,-1000,-1000,-358,130,542,634,1000,-43}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00346() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getSeriesItemLabelGenerator(int):org.jfree.chart.labels.CategoryItemLabelGenerator",
            new int[]{-1000,193,-367,712,-140,714,-809,132,-111,1000,-791,249,94,22,159,914,-635,1000,1000,-245,46,166,-1000,-631,-733,906,-282,-1000,368,1000,-747,513,242,-440,865,746,-651,-850,262,-685,-655,1000,-914,-214,-1000,-909,-1000,-154,-1000,-780,590,237,-495,438,-900,413,-825,-1000,-153,1000,-1000,-684,-18,-313}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00347() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getSeriesItemLabelGenerator(int):org.jfree.chart.labels.CategoryItemLabelGenerator",
            new int[]{-1000,-1000,-121,1000,-713,592,59,796,381,1000,136,3,345,-38,-682,1000,1000,534,762,-102,788,69,-1000,-658,717,-282,-171,1000,362,105,76,305,-42,-52,91,350,-469,1000,639,-661,-928,1000,409,16,-975,1000,317,-1000,-822,90,414,130,-549,-104,-857,1000,-435,-1000,-1000,210,-430,-1000,-574,-707}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00348() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getSeriesItemLabelGenerator(int):org.jfree.chart.labels.CategoryItemLabelGenerator",
            new int[]{768,1000,74,-134,266,126,1000,-135,-803,-563,-467,769,489,-892,14,593,-825,-800,-1000,1000,-1000,774,-1000,451,-1000,1000,486,-548,1000,759,-352,-199,1000,-166,635,547,715,-1000,-725,362,186,-433,-1000,-915,-543,-585,-991,703,-902,-709,-555,-253,1000,821,-289,-1000,-958,-1000,1000,-102,-1000,-237,167,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00349() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getSeriesItemLabelGenerator(int):org.jfree.chart.labels.CategoryItemLabelGenerator",
            new int[]{248,-831,642,1000,-1000,1000,-807,-673,239,854,-381,527,-1000,-840,949,-60,850,-149,313,-385,197,303,1000,1000,421,-962,-1000,-390,-552,-772,-1000,767,803,483,187,104,331,727,761,-281,505,-306,-236,-1000,-1000,448,1000,759,52,1000,1000,1000,401,-396,-1000,-188,-627,-664,211,-1000,877,1000,130,-757}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00350() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getSeriesItemLabelGenerator(int):org.jfree.chart.labels.CategoryItemLabelGenerator",
            new int[]{304,132,-986,-315,560,711,-23,-457,251,-620,674,853,1000,-1000,1000,333,436,77,-1000,580,433,27,666,696,586,1000,-257,-810,-1000,15,783,75,1000,882,-124,239,-41,-202,-1000,576,326,-6,-952,-1000,327,-361,-1000,535,-426,-1000,-1000,-684,-68,597,101,-110,-1000,1000,-738,-1000,351,1000,525,237}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00351() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getSeriesItemLabelGenerator(int):org.jfree.chart.labels.CategoryItemLabelGenerator",
            new int[]{-692,620,476,830,-616,-947,-981,-859,704,45,-432,160,-217,-927,-659,-596,921,-389,22,229,-970,659,422,802,922,-295,446,-942,131,-535,-981,666,260,531,295,-192,-231,291,-797,877,-839,-651,-817,-905,-413,92,-168,-550,55,5,105,407,599,871,-319,-626,-929,96,-800,-964,-484,55,-882,-613}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00352() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getSeriesToolTipGenerator(int):org.jfree.chart.labels.CategoryToolTipGenerator",
            new int[]{72,34,869,-356,788,679,901,-68,30,117,84,-139,257,-749,-429,-678,-147,-964,279,36,1000,-760,563,-1000,-992,30,650,1000,-494,-100,537,417,137,164,-1000,412,586,-1000,-1000,-1000,-1000,891,-657,1000,731,88,-696,-465,48,-753,740,-605,457,662,-68,-251,-886,-381,756,-245,458,870,-631,-437}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00353() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getSeriesToolTipGenerator(int):org.jfree.chart.labels.CategoryToolTipGenerator",
            new int[]{-789,1000,-526,-977,100,1000,-158,-435,1000,-548,-472,557,522,-987,-1000,808,-1000,-332,940,497,-645,871,-1000,159,389,96,900,935,52,-576,1000,-579,594,1000,1000,689,-121,-878,-1000,812,1000,1000,319,1000,1000,-491,657,941,-393,-716,694,-1000,1000,1000,1000,-117,662,-12,-613,-999,-1000,659,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00354() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getSeriesToolTipGenerator(int):org.jfree.chart.labels.CategoryToolTipGenerator",
            new int[]{1000,81,118,465,306,1000,-488,1000,552,-526,-570,-841,727,-1000,301,-912,-866,-143,-429,394,1000,1000,228,-493,-803,46,1000,-357,702,-202,707,-110,-341,142,-679,800,-1000,-665,-470,675,477,-1000,-46,586,392,-1000,-33,401,-345,1000,-4,-874,221,-98,713,710,-662,111,-996,-446,-291,-22,-392,-859}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00355() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getSeriesToolTipGenerator(int):org.jfree.chart.labels.CategoryToolTipGenerator",
            new int[]{1000,-807,-491,-1000,-671,251,472,1000,1000,680,-196,262,1000,611,-327,-858,162,-559,440,-81,41,1000,-1000,1000,-778,1000,1000,-66,299,-1000,1000,-63,-816,1000,-300,979,-1000,-1000,-1000,956,1000,1000,-1000,641,857,-355,1000,1000,-1000,-980,-741,-1000,1000,-232,618,1000,-1000,580,-1000,443,-843,7,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00356() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getSeriesToolTipGenerator(int):org.jfree.chart.labels.CategoryToolTipGenerator",
            new int[]{384,-725,52,922,640,323,6,731,-456,26,352,431,1000,-1000,772,4,-1000,-724,655,433,971,-1000,579,465,61,1000,-719,1000,819,-426,-379,-31,-1000,-1000,1000,564,1000,-995,390,-328,461,704,576,1000,-1000,1000,-967,940,-663,-752,-1000,-1000,250,-1000,-52,-353,1000,1000,-801,-659,812,-539,271,576}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00357() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getSeriesToolTipGenerator(int):org.jfree.chart.labels.CategoryToolTipGenerator",
            new int[]{-439,459,614,-368,286,1000,-653,987,1000,81,-138,-979,26,-1000,1000,-1000,-255,134,-618,107,-168,1000,1000,-392,-64,11,1000,167,481,6,89,-126,522,788,-577,875,-1000,1000,-1000,301,1000,-133,164,257,1000,-963,1000,116,122,-518,1000,-250,364,-67,821,262,-527,-488,-65,-729,56,-66,223,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00358() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getSeriesToolTipGenerator(int):org.jfree.chart.labels.CategoryToolTipGenerator",
            new int[]{-1000,-1000,-472,-1000,680,1000,43,-292,431,-1000,-328,-715,-374,896,-81,-134,519,-647,-503,-694,585,87,631,895,-323,-1000,409,499,-399,155,-719,470,516,-331,-21,385,859,108,790,147,-1000,-82,1000,786,-588,-923,-1000,110,826,166,380,125,-1000,401,-553,-299,1000,-299,943,-1000,-376,916,559,-539}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00359() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getSeriesToolTipGenerator(int):org.jfree.chart.labels.CategoryToolTipGenerator",
            new int[]{-434,827,49,-721,383,1000,278,1000,1000,369,388,271,413,387,-1000,196,-1000,-592,668,308,1000,200,-1000,-318,-180,69,232,962,-173,-380,824,-169,406,797,299,575,170,553,-1000,66,477,1000,-83,1000,949,-253,100,362,-211,-731,713,-1000,1000,884,747,-172,25,-164,400,-689,-400,746,-1000,-796}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00360() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getSeriesToolTipGenerator(int):org.jfree.chart.labels.CategoryToolTipGenerator",
            new int[]{-25,-1000,-648,-80,705,145,901,-68,-595,546,-4,587,347,1000,936,-1000,-65,-59,757,668,-210,1000,-606,962,-667,98,-198,1000,648,-1000,-496,356,-1000,-1000,724,654,1000,-168,1000,-748,-1000,-13,-657,1000,-1000,-577,-1000,1000,48,155,-844,-458,-108,-933,-668,735,1000,843,756,-687,178,722,122,576}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00361() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getSeriesToolTipGenerator(int):org.jfree.chart.labels.CategoryToolTipGenerator",
            new int[]{292,-974,59,167,640,12,543,-973,-655,-518,644,78,882,617,803,256,-44,-194,142,-182,304,-305,631,517,528,-423,-264,548,651,-240,-395,52,-527,-851,741,376,709,-75,627,652,-564,-114,734,793,-588,-199,-988,543,456,-37,-942,-207,-706,-999,-76,106,1000,974,-224,-913,-523,-204,485,48}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00362() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getSeriesToolTipGenerator(int):org.jfree.chart.labels.CategoryToolTipGenerator",
            new int[]{680,1000,-133,952,680,935,-138,561,522,-1000,673,874,1000,896,-781,1000,519,-586,1000,32,1000,361,-1000,-377,1000,-42,1000,499,702,-737,1000,-1000,-661,495,1000,351,859,108,-1000,1000,795,-82,1000,540,1000,-385,1000,741,826,-874,380,-1000,457,-619,1000,-74,200,1000,-1000,-958,-1000,-1000,-1000,-859}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00363() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getSeriesURLGenerator(int):org.jfree.chart.urls.CategoryURLGenerator",
            new int[]{204,-585,919,790,948,787,901,-1000,637,-833,971,1000,-343,76,229,-1000,115,-1000,-1000,1000,-896,-1000,-167,250,-462,1000,-255,-1000,522,-1000,-1000,1000,-26,1000,321,400,246,-487,-764,-782,-560,-1000,1000,400,-1000,1000,-1000,10,102,-579,767,373,-602,833,244,522,1000,-372,-95,647,-699,839,222,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00364() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getSeriesURLGenerator(int):org.jfree.chart.urls.CategoryURLGenerator",
            new int[]{365,-784,139,-10,240,-133,372,-908,1000,505,-679,480,345,557,125,-1000,-580,580,293,1000,-887,728,-576,-737,1000,-132,1000,-761,-1000,186,59,-594,705,-807,-523,-1000,-244,510,592,-1000,-919,199,-49,400,50,-434,1000,-1000,-926,1000,386,-167,-1000,701,518,1000,214,-441,-408,194,-35,-420,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00365() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getSeriesURLGenerator(int):org.jfree.chart.urls.CategoryURLGenerator",
            new int[]{-692,-511,129,272,-686,373,1000,-372,-613,144,528,337,195,489,1000,977,-303,-400,307,-2,-112,1000,242,-1000,1000,922,-630,-1000,234,-805,17,-336,914,627,285,-163,-263,178,217,1000,-8,-787,-162,-377,189,397,-1000,-10,-208,107,858,-393,-851,57,198,183,1000,-19,-406,223,-235,1000,174,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00366() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getSeriesURLGenerator(int):org.jfree.chart.urls.CategoryURLGenerator",
            new int[]{337,773,919,1000,329,787,-209,-1000,347,-9,836,988,-191,19,-850,-400,1000,274,-1000,1000,-896,-499,-167,-393,54,-36,-296,508,-1000,16,1000,413,1000,-72,-400,-1000,246,469,722,-348,-609,801,216,-1000,967,69,251,-620,102,275,-751,1000,-623,510,153,-364,1000,306,-1000,549,-1000,839,-952,-660}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00367() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getSeriesURLGenerator(int):org.jfree.chart.urls.CategoryURLGenerator",
            new int[]{655,-555,173,786,1000,732,1000,-249,1000,750,1000,1000,596,1000,107,-55,-1000,1000,1000,1000,327,-991,745,-101,1000,32,-192,607,-21,86,-1000,529,984,323,-935,-278,191,-305,-189,-1000,-485,251,-463,336,580,-792,521,-1000,-1000,1000,-901,-1000,-419,-204,1000,227,1000,-1000,686,572,-576,1000,275,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00368() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getSeriesURLGenerator(int):org.jfree.chart.urls.CategoryURLGenerator",
            new int[]{-535,46,108,1000,161,482,45,-869,0,-221,1000,148,576,-722,669,-74,748,-1000,518,-798,307,-3,-576,0,612,586,-832,1000,482,-1000,-54,-1000,1000,0,1000,-1000,-387,0,0,-941,-1000,628,-698,-634,1000,460,-819,-44,633,1000,-295,579,518,-43,92,-424,-2,511,-1000,-1000,-1000,253,-489,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00369() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getSeriesURLGenerator(int):org.jfree.chart.urls.CategoryURLGenerator",
            new int[]{578,-1000,-237,-10,306,66,869,-1000,988,1000,-139,508,422,778,125,-1000,-1000,1000,1000,1000,-887,7,461,-150,1000,-648,1000,-185,-1000,554,404,-405,977,-1000,-1000,-1000,-275,385,680,-1000,-749,199,-233,-229,370,-702,1000,-1000,-1000,1000,386,-719,-964,138,946,753,1000,-418,-31,194,-102,114,469,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00370() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getSeriesURLGenerator(int):org.jfree.chart.urls.CategoryURLGenerator",
            new int[]{-479,-678,-386,-10,1000,-151,1000,-1000,798,762,-139,508,156,1000,906,-1000,-1000,1000,1000,1000,-1000,-79,747,71,184,-481,-65,-1000,-638,484,404,-493,-222,-1000,-64,-1000,-1000,-558,984,-1000,97,-582,-982,-1000,989,-1000,271,-93,-245,822,386,-104,-383,400,383,148,-1000,-483,-84,-45,334,980,274,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00371() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getSeriesURLGenerator(int):org.jfree.chart.urls.CategoryURLGenerator",
            new int[]{194,762,558,689,-809,366,495,-847,923,223,-6,870,781,372,-168,140,-1000,1000,-163,254,734,-991,-322,-722,1000,508,491,807,795,-516,-1000,529,568,1000,-528,-296,191,-251,-933,-596,-42,546,432,336,-467,305,1000,-604,564,185,-1000,-1000,-392,-865,-7,-525,1000,-60,-1000,715,-576,862,-617,-547}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00372() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getSeriesURLGenerator(int):org.jfree.chart.urls.CategoryURLGenerator",
            new int[]{-569,-674,-51,83,1000,345,1000,-1000,885,400,286,1000,-770,-378,1000,-1000,-1000,400,1000,1000,-1000,-818,642,-192,34,973,383,-1000,145,-562,-1000,456,-137,531,-171,-1000,-1000,-1000,625,371,-369,-1000,-1000,-1000,152,-313,-1000,180,-390,5,545,-400,-424,-928,150,676,1000,-448,319,672,233,876,565,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00373() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getSeriesURLGenerator(int):org.jfree.chart.urls.CategoryURLGenerator",
            new int[]{-56,-899,-32,-565,650,-24,889,-1000,1000,-115,-167,1000,-1000,-1000,293,972,-917,-20,-1000,1000,-1000,-1000,687,114,-795,1000,1000,-1000,385,-406,-1000,1000,-681,1000,-551,-857,-865,-898,-67,1000,-458,-341,-451,-643,-1000,171,-998,360,-827,-962,953,1000,-726,-1000,-30,1000,1000,-810,1000,1000,675,311,1000,-20}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00374() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getSeriesURLGenerator(int):org.jfree.chart.urls.CategoryURLGenerator",
            new int[]{-658,-1000,-281,510,918,183,144,-1000,109,-623,907,572,-1000,-560,-117,174,1000,-1000,-186,821,-1000,249,-252,1000,184,92,-1000,-1000,-443,293,1000,-33,-508,-1000,1000,-1000,-388,-247,342,-733,305,-1000,-1000,-1000,1000,87,-988,860,434,-554,-30,1000,-164,757,555,397,-1000,-306,-359,-519,-201,-142,-155,-431}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00375() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getSeriesURLGenerator(int):org.jfree.chart.urls.CategoryURLGenerator",
            new int[]{749,420,919,69,270,787,495,-1000,1000,776,-1000,1000,-343,729,-253,-1000,-1000,1000,-1000,955,113,-1000,208,28,429,1000,1000,807,522,748,-1000,301,-740,-139,-772,-739,-325,-340,-1000,-1000,-323,497,259,436,-704,-673,1000,-939,23,809,-901,-1000,-1,-1000,243,-23,-400,-747,-262,-122,255,588,-38,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00376() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getSeriesURLGenerator(int):org.jfree.chart.urls.CategoryURLGenerator",
            new int[]{599,391,558,1000,1000,646,147,-1000,375,-1000,606,1000,833,-149,-387,-806,-1000,-1000,-1000,254,-380,-991,-1000,889,-808,508,-376,-253,1000,-993,-607,1000,568,1000,321,400,768,-606,-952,-428,-947,-429,1000,260,-1000,1000,-795,-339,736,-863,-621,1000,-435,797,-465,180,92,-874,-571,408,-1000,1000,-806,-380}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00377() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getToolTipGenerator(int,int,boolean):org.jfree.chart.labels.CategoryToolTipGenerator",
            new int[]{-983,-1000,697,1000,958,124,-178,315,-1000,1000,-1000,1000,-988,914,-287,1000,918,653,-521,12,152,-1000,-1000,1000,297,1000,82,-66,1000,-1000,836,-882,713,-1000,-221,-394,440,-1000,-1000,1000,-331,-1000,1000,93,5,-1000,-704,562,-1000,-614,810,583,1000,874,661,1000,-965,-748,-732,574,30,821,-1000,258}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00378() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getToolTipGenerator(int,int,boolean):org.jfree.chart.labels.CategoryToolTipGenerator",
            new int[]{-518,-182,-358,201,-67,-149,859,111,384,-34,-20,-878,-503,1000,-1000,521,1000,484,683,-1000,-669,-1000,-908,323,484,1000,-688,1000,384,1000,-807,-157,-270,-1000,-961,688,-1000,-307,-741,1000,1000,989,-1000,944,-228,1000,-162,618,544,132,-546,574,1000,460,744,1000,-1000,-525,148,-317,516,-891,357,7}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00379() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getToolTipGenerator(int,int,boolean):org.jfree.chart.labels.CategoryToolTipGenerator",
            new int[]{-329,-874,-82,926,-5,-1000,-521,1000,522,-926,-839,-800,869,356,-505,44,1000,1000,1000,378,-1000,-639,-1000,-130,-1000,-116,-1000,-332,1000,992,-1000,-1000,718,908,1000,1000,-975,961,-334,271,879,-278,1000,-1000,1000,157,-913,1000,-767,-1000,1000,684,550,467,189,650,-1000,-910,575,-1000,1000,1000,154,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00380() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getToolTipGenerator(int,int,boolean):org.jfree.chart.labels.CategoryToolTipGenerator",
            new int[]{-311,-1000,334,1000,-191,-218,-870,1000,-275,626,-328,760,-528,23,1000,121,-879,-103,-897,1000,1000,-1000,265,1000,-560,-1000,810,-1000,528,-1000,307,-1000,-1000,-524,-804,35,759,-1000,-1000,47,495,-1000,1000,52,1000,-204,1000,1000,-360,-1000,795,1000,358,1000,657,-354,583,-347,914,-294,586,1000,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00381() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getToolTipGenerator(int,int,boolean):org.jfree.chart.labels.CategoryToolTipGenerator",
            new int[]{-1000,-732,528,1000,-232,-442,-50,304,-606,314,-720,1000,-254,811,933,-425,-390,447,-161,1000,872,-759,1000,580,-391,-848,-716,-345,-632,-1000,978,-1000,-278,-953,-428,247,1000,-271,-1000,569,972,-1000,1000,-106,144,-761,-1000,445,-414,-498,-60,233,1000,332,1000,1000,-397,590,314,888,95,-282,-822,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00382() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getToolTipGenerator(int,int,boolean):org.jfree.chart.labels.CategoryToolTipGenerator",
            new int[]{-1000,-1000,291,808,-146,571,169,-350,-1000,1000,-1000,1000,-691,1000,-1000,459,713,348,39,-211,872,-1000,374,1000,-198,-1000,-68,168,-1000,-1000,337,-1000,893,-1000,-560,126,948,-676,-1000,1000,-356,-806,1000,528,144,-1000,-837,1000,-1000,-297,632,258,1000,643,424,1000,-991,201,-859,1000,499,1000,-1000,-10}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00383() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getToolTipGenerator(int,int,boolean):org.jfree.chart.labels.CategoryToolTipGenerator",
            new int[]{-311,-636,614,1000,390,-1000,615,1000,-493,-345,-238,191,-312,745,139,-413,212,1000,582,-1000,324,-1000,-1000,761,-814,-485,-521,648,1000,732,-968,-1000,-2,-328,-1000,921,-867,-286,-1000,1000,662,-737,-37,86,1000,1000,-660,1000,-215,-1000,635,1000,1000,520,1000,809,-578,-1000,-79,-825,938,-588,-309,920}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00384() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getToolTipGenerator(int,int,boolean):org.jfree.chart.labels.CategoryToolTipGenerator",
            new int[]{-815,253,17,129,-165,832,-50,304,-606,-1000,429,-272,-1000,412,933,1000,1000,-472,-161,-1000,-258,-759,-1000,94,-114,622,1000,-345,-957,-1000,-1000,1000,722,620,781,247,-1000,-809,1000,-263,-1000,1000,-1000,361,-758,-1000,1000,-1000,431,1000,124,137,-659,332,504,-1000,859,604,406,269,569,718,-98,234}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00385() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getToolTipGenerator(int,int,boolean):org.jfree.chart.labels.CategoryToolTipGenerator",
            new int[]{-415,-884,-578,-48,-375,-821,660,280,687,-573,-609,-187,-667,570,-756,-202,820,337,42,247,-326,-856,-992,19,240,229,-911,331,777,459,-390,97,-193,338,612,999,-984,948,-355,-472,799,-474,534,344,718,136,-298,284,-409,-449,986,-923,702,844,584,-591,743,412,-260,-626,430,223,112,534}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00386() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getToolTipGenerator(int,int,boolean):org.jfree.chart.labels.CategoryToolTipGenerator",
            new int[]{34,-1000,738,806,-332,-849,131,1000,-1000,-688,-1000,1000,278,-1000,374,1000,19,1000,-363,1000,1000,-1000,-1000,1000,-1000,-1000,-164,1000,-1000,-1000,-1000,-1000,-395,108,-980,100,612,-981,-1000,-1000,1000,-1000,1000,-1000,-1000,-1000,1000,1000,-1000,-1000,1000,1000,135,938,654,-968,1000,-543,1000,-1000,1000,745,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00387() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getToolTipGenerator(int,int,boolean):org.jfree.chart.labels.CategoryToolTipGenerator",
            new int[]{-1000,-732,537,894,-243,-442,-116,894,-982,1000,-1000,1000,-1000,815,-401,-621,-376,672,-804,-1000,1000,-1000,467,580,173,-1000,-334,1000,-380,-977,600,-1000,-14,-491,-428,-78,927,-829,-1000,1000,-648,-1000,-671,731,-400,-241,-1000,506,-1000,471,-851,1000,1000,1000,1000,978,-397,-408,-1000,818,95,1000,-1000,469}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00388() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getToolTipGenerator(int,int,boolean):org.jfree.chart.labels.CategoryToolTipGenerator",
            new int[]{26,-1000,-1,754,-276,-88,71,1000,-1000,-425,-1000,1000,-25,-676,572,-1000,-66,987,-435,14,1000,-382,-715,1000,-1000,-1000,-234,-1000,1000,-1000,-940,-763,-395,24,-1000,-469,583,-981,-1000,-647,1000,-1000,1000,-1000,1000,-559,414,1000,-1000,-1000,1000,1000,585,938,894,-275,1000,-1000,1000,-956,1000,745,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00389() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getToolTipGenerator(int,int,boolean):org.jfree.chart.labels.CategoryToolTipGenerator",
            new int[]{-1000,-581,686,553,467,-630,-65,965,-224,-502,-1000,1000,-289,62,845,-639,-161,145,-568,13,682,250,-431,621,-1000,-1000,-93,-770,332,-952,-666,-1000,-1000,-218,-599,462,1000,-633,-1000,-282,211,-846,1000,-150,881,-1000,480,1000,-720,-86,258,418,-338,1000,-507,-618,671,176,1000,-105,144,124,-775,978}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00390() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getToolTipGenerator(int,int,boolean):org.jfree.chart.labels.CategoryToolTipGenerator",
            new int[]{-1000,-829,39,1000,-175,-228,-50,-581,-609,1000,-1000,790,-691,1000,110,459,-75,343,-77,-75,438,-1000,374,1000,-12,-602,-621,398,-1000,-1000,533,-864,-290,-1000,-455,-18,807,-336,-1000,1000,-308,-892,706,-106,144,-576,-1000,955,-680,-90,267,-168,1000,753,270,1000,-404,538,-370,999,135,808,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00391() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getToolTipGenerator(int,int,boolean):org.jfree.chart.labels.CategoryToolTipGenerator",
            new int[]{-663,-486,84,501,1000,-630,-665,-1000,267,1000,400,1000,-1000,1000,261,1000,-59,-556,-804,1000,307,-1000,307,825,173,1000,-334,342,-400,-1000,600,-1000,-201,-931,447,-875,1000,-1000,-516,708,-863,400,-400,824,-1000,-324,125,537,400,786,-590,347,-338,1000,573,767,-796,448,-455,1000,-1000,1000,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00392() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getToolTipGenerator(int,int,boolean):org.jfree.chart.labels.CategoryToolTipGenerator",
            new int[]{303,-1000,-62,699,-574,-217,223,879,-710,-666,-800,317,168,526,151,-237,-187,189,400,-850,-65,-747,20,-145,-1000,-1000,-369,614,1000,411,-450,-110,-19,102,-953,621,-677,455,-872,857,1000,-1000,47,45,1000,1000,273,501,-800,-1000,508,885,1000,627,495,-150,287,-1000,-66,743,1000,-704,-192,-795}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00393() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getURLGenerator(int,int,boolean):org.jfree.chart.urls.CategoryURLGenerator",
            new int[]{-471,944,-122,732,1000,672,270,1000,-444,1000,-1000,1000,1000,1000,-218,-865,-1000,-1000,-218,-589,-625,-840,1000,-968,652,-369,500,-686,30,-621,411,213,-696,-491,39,-783,771,-637,-379,-135,126,-864,1000,104,1000,510,-1000,-372,-577,1000,1000,85,-12,350,-921,1000,-339,986,313,147,1000,-899,-644,122}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00394() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getURLGenerator(int,int,boolean):org.jfree.chart.urls.CategoryURLGenerator",
            new int[]{-450,-1000,663,-692,690,-1000,-535,847,1000,-1000,1000,-169,-194,196,1000,1000,1000,1000,1000,-282,575,-2,-956,236,-410,-366,192,395,287,1000,-1000,120,252,-1000,-1000,-55,41,-655,-268,-1000,1000,-888,41,981,-1000,1000,-286,-1000,514,50,660,-1000,889,1000,-780,669,1000,1000,1000,777,-554,1000,-280,-638}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00395() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getURLGenerator(int,int,boolean):org.jfree.chart.urls.CategoryURLGenerator",
            new int[]{-140,-235,-316,229,292,-643,827,1000,657,-173,15,238,-363,10,296,808,-916,-666,-107,202,345,1000,60,114,142,-1,-395,403,-908,-306,135,763,-692,-195,-409,-1000,142,426,-1000,-206,-795,-976,1000,762,859,-1000,-1000,-171,768,9,231,-32,-1000,-197,343,-1000,-561,1000,-103,149,544,-226,623,607}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00396() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getURLGenerator(int,int,boolean):org.jfree.chart.urls.CategoryURLGenerator",
            new int[]{-134,26,143,-78,-496,-768,26,528,279,643,129,94,-424,-840,-52,302,235,-268,1000,-409,-988,-695,950,-1000,-246,173,-930,-215,-431,336,-900,356,-1000,-1000,-11,-826,-132,-674,949,-948,96,-160,582,-374,-432,477,166,-81,-255,438,81,-143,547,993,-661,916,343,-719,-188,472,17,-293,-89,-361}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00397() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getURLGenerator(int,int,boolean):org.jfree.chart.urls.CategoryURLGenerator",
            new int[]{-110,944,282,-355,-934,672,1000,-1000,-1000,130,408,-536,422,1000,-360,448,1000,805,1000,-806,-432,-586,140,253,226,-158,-153,-686,30,1000,-621,-417,60,77,-248,860,771,-72,-379,-135,514,905,-1000,-1000,-1000,510,1000,-947,153,1000,1000,-842,-12,1000,-274,1000,944,-1000,394,1000,-903,-2,-1000,940}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00398() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getURLGenerator(int,int,boolean):org.jfree.chart.urls.CategoryURLGenerator",
            new int[]{588,660,78,-1000,-1000,-388,36,-59,363,-1000,-9,-1000,-478,370,544,-98,-1000,78,1000,-742,-320,770,-251,-611,999,-1000,-414,-131,121,155,667,-1000,-1000,953,1000,-715,-551,-544,1000,352,-47,-612,-362,-362,79,-1000,69,-194,1000,264,472,-864,-715,663,69,1000,742,-615,-1000,44,942,-73,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00399() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getURLGenerator(int,int,boolean):org.jfree.chart.urls.CategoryURLGenerator",
            new int[]{-1000,-502,-127,1000,1000,-463,1000,988,-834,1000,-1000,870,1000,1000,-246,-407,-41,1000,752,725,-1000,-1000,-36,-1000,-1000,-1000,157,443,303,1000,41,827,1000,876,-524,1000,1000,-1000,-537,-1000,315,-452,219,749,263,-488,800,-1000,-18,-6,899,-1000,718,1000,-1000,1000,-241,-550,417,1000,-481,-1000,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00400() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getURLGenerator(int,int,boolean):org.jfree.chart.urls.CategoryURLGenerator",
            new int[]{228,310,388,831,-1000,-816,102,1000,609,1000,1000,56,-461,-70,-93,1000,409,-554,1000,-1000,-213,892,-586,399,1000,891,-1000,-544,-1000,1000,-1000,-593,-1000,-988,-821,-1000,84,252,1000,-1000,-589,663,1000,-1000,-957,-785,-1000,-1000,626,913,758,-729,1000,1000,-100,-101,-289,394,1000,289,-439,-313,522,396}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00401() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getURLGenerator(int,int,boolean):org.jfree.chart.urls.CategoryURLGenerator",
            new int[]{481,-1000,-177,-511,333,-1000,158,773,1000,-208,936,-764,-1000,-756,59,844,1000,399,166,331,927,1000,-193,1000,972,-14,20,256,-900,352,805,561,44,-590,-922,-325,-625,-425,541,77,-1000,-86,1000,614,163,-1000,-30,-508,683,-1000,-485,621,-46,187,466,293,133,74,-653,-257,-426,42,570,-583}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00402() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getURLGenerator(int,int,boolean):org.jfree.chart.urls.CategoryURLGenerator",
            new int[]{357,-1000,-272,-1000,379,-158,565,-297,731,-492,521,-379,-648,-304,-147,491,577,1000,166,467,841,631,114,1000,554,-330,613,-88,-179,352,1000,225,627,-88,-660,624,-296,-544,-223,682,-562,385,22,328,-182,-741,1000,-471,503,-1000,-276,491,-755,193,343,767,655,-562,-904,112,-833,318,-140,-245}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00403() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getURLGenerator(int,int,boolean):org.jfree.chart.urls.CategoryURLGenerator",
            new int[]{113,708,759,260,-497,719,1000,-835,-1000,-773,-431,-619,655,1000,509,192,-400,-545,99,-464,261,438,457,59,227,153,-197,216,-10,1000,-400,384,-502,705,698,773,1000,762,-192,-580,-495,-595,-126,330,377,-1000,1000,-19,315,1000,1000,-226,439,290,603,-384,-1000,400,-29,774,-170,465,-551,-531}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00404() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getURLGenerator(int,int,boolean):org.jfree.chart.urls.CategoryURLGenerator",
            new int[]{-563,1000,193,-751,1000,463,827,-454,731,-320,-1000,-379,1000,724,1000,-491,-1000,-635,-1000,1000,841,631,-655,-1000,554,-330,165,238,1000,-881,680,1000,627,230,539,1000,1000,294,-1000,1000,-562,-1000,-1000,1000,1000,400,556,988,-20,-1000,694,-284,-1000,-699,133,-1000,-271,1000,-575,469,926,-25,181,130}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00405() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getURLGenerator(int,int,boolean):org.jfree.chart.urls.CategoryURLGenerator",
            new int[]{1000,82,-921,290,261,512,-449,910,-182,-62,112,59,70,611,-884,108,-372,345,-1000,201,937,411,675,682,1000,-961,436,-1000,-36,-1000,1000,-868,-44,523,-104,-465,196,270,121,1000,1000,956,632,-856,78,-716,-1000,-102,876,-280,785,643,-853,-687,10,-570,417,-325,-968,-218,-1000,981,159,-81}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00406() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getURLGenerator(int,int,boolean):org.jfree.chart.urls.CategoryURLGenerator",
            new int[]{1000,-1000,-842,-747,81,573,827,-1000,-48,-1000,895,-1000,-1000,-178,357,1000,1000,902,-302,951,1000,1000,-672,1000,-534,-636,299,-1000,9,-151,779,-397,153,1000,-566,-71,-347,459,-1000,400,300,925,-1000,-335,-1000,-1000,-533,-431,1000,-251,553,-71,-871,-600,650,977,1000,-1000,-1000,792,-1000,1000,924,-15}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00407() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getURLGenerator(int,int,boolean):org.jfree.chart.urls.CategoryURLGenerator",
            new int[]{-156,370,104,-528,85,615,1000,246,-1000,-870,-361,-379,569,744,777,427,-179,56,-107,291,239,491,749,-141,26,-629,338,132,535,292,223,136,70,923,227,168,787,945,-404,1000,-98,-370,-669,260,156,-57,1000,-81,635,820,900,-606,-1000,-163,300,276,144,-409,-378,1000,31,305,-481,128}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00408() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "getURLGenerator(int,int,boolean):org.jfree.chart.urls.CategoryURLGenerator",
            new int[]{559,-1000,-528,-28,-773,450,827,-400,416,-1000,1000,-874,-1000,-258,28,1000,347,514,-396,631,1000,1000,-358,1000,266,74,-557,-598,-571,-151,267,316,-743,666,-251,-458,48,1000,-1000,-206,-405,-642,54,242,646,-1000,350,-104,1000,-304,231,231,-1000,-498,1000,-133,459,-59,-800,149,-856,1000,1000,259}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00409() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{21,-764,-332,1000,1000,1000,145,472,311,1000,-624,336,1000,1000,-46,1000,324,-908,210,276,309,1000,631,861,-293,501,-244,963,-1000,114,1000,1000,280,236,892,-182,1000,-1000,-506,-951,-1000,1000,-728,683,174,-1000,51,1000,481,1000,945,-174,-99,1000,793,453,-1000,-740,-318,-1000,-112,457,-177,-204}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00410() {
        org.junit.Assert.assertEquals("TYPE:org.jfree.chart.renderer.category.CategoryItemRendererState", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{1000,-512,-76,-561,755,110,1000,-455,347,-1000,95,-697,-169,-232,417,-1000,521,946,-163,221,-495,-1000,-673,756,393,77,1000,-1000,1000,19,-1000,-855,-1000,1000,-946,-72,1000,238,727,-1000,-158,-528,1000,660,-720,-621,709,-1000,-137,-1000,51,-1000,1000,869,517,-515,1000,774,482,1000,-480,247,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00411() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{883,-721,-806,-535,255,377,1000,-28,347,-288,-1000,-327,-308,-314,1000,-1000,769,924,322,650,-1000,-583,-673,-473,393,-487,1000,-1000,1000,-420,-1000,-467,-1000,412,-318,-72,1000,236,-582,-260,319,-1000,1000,380,-978,-962,997,-400,-238,-1000,394,-901,1000,1000,468,476,-1000,178,1000,446,-480,-340,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00412() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{830,-754,-992,-547,-626,564,34,913,881,-271,-265,305,104,-871,1000,339,-295,-908,1000,439,-1000,-1000,1000,37,-372,-482,1000,963,1000,-1000,-972,-159,-586,283,-1000,837,46,-1000,1000,-958,854,1000,1000,817,-779,-794,1000,-415,-1000,669,-195,198,1000,969,729,453,-603,190,1000,1000,509,457,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00413() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{958,-326,933,-909,215,-420,644,-107,-72,-106,-1000,717,188,171,401,1000,893,565,-836,-610,991,770,1000,828,200,840,-1000,407,955,-744,179,-1000,551,-80,-989,475,18,914,395,346,-288,687,-67,831,297,812,-52,-305,38,-74,232,-106,606,-271,-450,1000,437,-546,1000,469,-186,-392,172,255}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00414() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{523,-581,-322,582,1000,199,-422,-823,893,226,-86,1000,1000,163,-71,1000,1000,-955,375,-315,817,833,1000,1000,-7,987,-928,1000,1000,365,1000,852,856,960,990,153,807,-495,206,-1000,-1000,-1000,-613,1000,669,-665,-1000,113,1000,-13,804,642,313,356,-7,608,-1000,-49,-803,-1000,771,-57,-183,737}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00415() {
        org.junit.Assert.assertEquals("TYPE:org.jfree.chart.renderer.category.CategoryItemRendererState", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{832,-1000,64,-1000,1000,141,1000,-711,-137,616,-1000,-325,-168,888,189,1000,121,1000,-441,-343,-384,317,709,1000,-7,50,400,99,-911,389,-393,-1000,-196,-158,-969,416,670,74,-713,193,-295,-267,47,1000,-118,466,1000,-838,-883,-1000,-502,-1000,424,210,-306,1000,-1000,-252,1000,928,-1000,367,789,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00416() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{-126,-650,-536,1000,781,593,87,869,715,1000,-322,1000,1000,1000,225,981,153,-1000,840,27,381,1000,1000,1000,-781,825,-244,1000,-1000,-338,1000,1000,557,-136,892,179,290,-1000,-315,-1000,-1000,1000,-728,956,631,-976,-487,1000,481,1000,1000,1000,-270,1000,793,1000,-722,-1000,-387,-318,811,-153,-110,484}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00417() {
        org.junit.Assert.assertEquals("TYPE:org.jfree.chart.renderer.category.CategoryItemRendererState", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{856,182,473,-93,42,377,-97,995,881,-829,957,107,173,-24,739,-748,-332,362,322,565,-800,-1000,662,897,-372,373,1000,-37,1000,-420,-400,-299,-224,412,-1000,668,46,1000,1000,-830,369,-670,1000,166,-978,-506,365,-400,-1000,594,102,160,963,771,763,-107,-1000,242,1000,1000,509,-807,400,915}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00418() {
        org.junit.Assert.assertEquals("TYPE:org.jfree.chart.renderer.category.CategoryItemRendererState", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{1000,-512,629,-1000,757,110,1000,-1000,-1000,-1000,1000,-1000,-800,424,-50,-1000,418,1000,-1000,387,203,-1000,-1000,756,1000,1000,-400,-1000,1000,673,-1000,-855,-1000,1000,-833,-1000,1000,-285,869,-860,-537,672,869,320,-18,-512,588,-702,19,229,78,-1000,-169,500,429,-876,1000,1000,-77,1000,-1000,1000,597,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00419() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{591,-413,-61,271,-7,901,552,434,385,996,-593,-281,454,837,810,222,-36,-329,-25,-346,-779,838,422,424,-988,-265,592,419,162,-614,678,860,363,-131,147,494,902,-666,-763,-912,-922,747,-157,692,-353,-384,624,454,470,-16,-83,-71,-322,707,98,743,138,-301,389,-744,-204,188,-183,-585}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00420() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{-481,293,-8,-590,-491,-740,704,-106,-970,540,-49,-408,250,-428,-70,-106,-689,605,-220,-293,412,192,433,-747,-372,-927,751,787,498,-896,-615,-744,961,-393,-795,831,-838,48,-983,-81,-175,-677,374,-218,-556,81,-281,216,-638,-504,-136,-132,976,-298,-170,722,739,-311,481,41,456,-112,-966,644}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00421() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{965,-736,353,-88,825,1000,697,-1000,-197,-1000,1000,-1000,-278,49,-7,961,62,-444,-345,1000,-400,-942,882,901,293,183,400,-1000,-1000,516,-827,299,86,664,-300,-337,920,104,895,-860,-136,-400,1000,-319,-335,-506,-411,-670,-428,-356,1000,642,75,1000,1000,-883,-856,1000,-380,-231,-552,419,-960,-878}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00422() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{451,-430,548,514,-288,429,424,-894,-732,1000,-654,-111,501,1000,-257,-1000,42,-797,-211,-265,400,795,158,-219,-59,461,-400,25,300,389,1000,826,290,-178,1000,-68,290,74,-1000,439,-1000,334,-734,830,-48,-506,197,1000,245,-233,685,-583,-1000,-160,-220,843,663,-70,-66,-235,-1000,668,-798,-86}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00423() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "removeAnnotation(org.jfree.chart.annotations.CategoryAnnotation):boolean",
            new int[]{-3,999,-581,443,-1000,-1000,221,461,-523,1000,-164,454,-1000,782,131,1000,-303,-1000,1000,300,113,-1000,896,-1000,272,-430,153,-355,-620,1000,-1000,-244,1000,533,-676,-845,1000,-1000,-639,491,-662,367,-98,1000,-1000,1000,-100,4,425,359,1000,1000,843,-1000,1000,-340,163,-1000,74,954,-42,-992,75,913}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00424() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "removeAnnotation(org.jfree.chart.annotations.CategoryAnnotation):boolean",
            new int[]{-949,-259,-866,1000,-513,-554,589,795,58,-461,-173,546,-1000,-583,-241,-301,754,-205,-698,-737,-422,-99,155,-228,96,896,-210,15,-320,637,-893,174,584,-117,-205,-1000,-218,-928,259,1000,-798,1000,-480,734,132,-231,16,-71,-579,-1000,923,-508,-1000,-498,-461,-328,-1000,162,-911,-287,-893,-457,484,315}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00425() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "removeAnnotation(org.jfree.chart.annotations.CategoryAnnotation):boolean",
            new int[]{-24,648,304,-435,-1000,-83,790,294,269,-221,-912,521,-419,531,657,-1000,125,460,-272,-1000,-5,-167,510,-76,-320,284,-1000,-29,-660,-1000,-98,-1000,-768,1000,-177,44,544,893,-1000,-594,-418,-152,265,218,-1000,354,-193,-806,-754,152,-332,321,-1000,-733,-1000,184,118,-790,1000,-603,385,-156,189,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00426() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "removeAnnotation(org.jfree.chart.annotations.CategoryAnnotation):boolean",
            new int[]{1000,-412,348,-322,-609,309,250,191,251,-105,1000,117,933,538,-870,157,447,88,1000,711,1000,276,-508,541,429,-1000,1000,428,178,-1000,-367,741,203,-889,124,241,388,-508,1000,674,1000,-82,-233,-400,1000,464,74,980,-320,319,1000,1000,1000,549,1000,-436,-1000,465,1000,111,-1000,342,-881,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00427() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "removeAnnotation(org.jfree.chart.annotations.CategoryAnnotation):boolean",
            new int[]{-488,42,-16,1000,-117,400,-242,-1000,87,355,-342,433,155,-1000,380,-281,536,-310,-149,687,228,417,-415,-38,975,640,922,760,108,469,-395,233,709,-417,-1000,-171,452,114,551,148,52,282,510,345,-227,330,-237,670,-489,-328,1000,-7,644,-793,122,-1000,812,971,-344,-417,-373,-151,-127,67}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00428() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "removeAnnotation(org.jfree.chart.annotations.CategoryAnnotation):boolean",
            new int[]{1000,-480,654,-1000,-530,1000,-1000,-1000,941,-1000,82,-368,611,136,999,-852,541,1000,608,-616,1000,1000,-851,1000,585,-1000,1000,1000,67,-1000,383,653,-561,307,-424,907,-673,1000,560,-973,1000,-792,365,-473,1000,-1000,-1000,1000,-473,997,-1000,1000,1000,430,-383,1000,634,1000,1000,-801,1000,240,-299,-970}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00429() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "removeAnnotation(org.jfree.chart.annotations.CategoryAnnotation):boolean",
            new int[]{1000,72,687,-1000,-167,835,1000,-364,1000,1000,-1000,1000,933,-173,1000,-866,-1000,908,453,188,1000,220,400,-1000,1000,-1000,502,1000,-1000,-689,561,-872,193,-1000,-541,1000,1000,-410,1000,-971,1000,-1000,-642,698,-1000,-163,1000,57,-1000,1000,-1000,1000,1000,275,1000,-541,-101,-243,1000,1000,536,-1000,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00430() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "removeAnnotation(org.jfree.chart.annotations.CategoryAnnotation):boolean",
            new int[]{393,582,549,-41,-480,-936,607,1000,-314,1000,-876,546,727,25,-38,668,-581,-400,1000,410,-215,-511,1000,-1000,834,-324,-210,298,-1000,29,-1000,-64,1000,-812,-977,55,-677,-519,1000,505,-63,-301,294,132,-1000,-69,1000,150,-495,506,-109,-508,1000,-117,1000,-885,-494,-63,88,-287,272,-536,-627,-66}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00431() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "removeAnnotation(org.jfree.chart.annotations.CategoryAnnotation):boolean",
            new int[]{1000,-54,-866,1000,-424,-481,668,98,187,-391,351,-1000,1000,1000,1000,-1000,-714,480,1000,-737,1000,412,-902,698,911,-1000,1000,1000,266,170,-204,858,584,-468,-488,681,-1000,610,1000,289,1000,-1000,844,-591,1000,-431,213,1000,-579,-1000,-66,1000,1000,523,-185,1000,-290,162,1000,-200,577,290,-427,-840}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00432() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "removeAnnotation(org.jfree.chart.annotations.CategoryAnnotation):boolean",
            new int[]{629,-79,654,498,-517,-286,297,478,509,-418,175,-489,611,136,585,-852,-579,511,410,-911,977,404,-863,540,659,-815,905,546,67,154,-798,653,368,-325,-122,286,-673,-216,906,560,686,-809,16,-116,872,-927,-263,703,-895,997,-356,972,894,430,-290,565,-361,847,497,-291,609,190,-325,-244}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00433() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "removeAnnotation(org.jfree.chart.annotations.CategoryAnnotation):boolean",
            new int[]{73,632,654,443,-1000,400,-748,-472,223,-1000,-51,912,-738,1000,835,-255,-303,-310,765,-453,1000,400,-82,-8,859,-1000,558,-30,-277,102,-395,-396,578,307,-780,-81,1000,-702,560,-361,461,-258,-440,517,-760,151,-1000,740,-267,1000,1000,1000,843,-935,625,1000,901,-754,1000,-801,584,-1000,-502,-20}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00434() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "removeAnnotation(org.jfree.chart.annotations.CategoryAnnotation):boolean",
            new int[]{698,231,765,-1000,-531,464,-381,497,242,1000,-1000,715,1000,202,628,-365,-935,1000,1000,-372,576,889,367,-597,871,-1000,1000,1000,-1000,-441,-234,-99,576,-801,-872,708,-677,-71,1000,-110,1000,-1000,447,-889,-1000,-705,500,886,-998,1000,-566,1000,1000,836,1000,342,-178,389,1000,1000,794,-424,-1000,-953}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00435() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "removeAnnotation(org.jfree.chart.annotations.CategoryAnnotation):boolean",
            new int[]{556,677,23,865,597,152,-470,451,-699,-760,-382,145,971,-439,-591,845,157,-945,964,464,-449,-584,336,15,-555,166,770,565,48,-900,-702,38,-164,425,996,-113,-257,844,-3,953,520,96,977,-478,835,20,-709,542,830,-941,180,-795,-259,-680,-435,745,928,809,803,-849,-804,226,-502,733}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00436() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "removeAnnotation(org.jfree.chart.annotations.CategoryAnnotation):boolean",
            new int[]{1000,-1000,-17,-1000,774,383,-204,795,769,-580,-355,-152,1000,-39,233,-287,754,-205,900,-737,-422,553,-887,-303,1000,-1000,1000,1000,-364,-596,726,865,-1000,-909,512,1000,-218,-8,1000,-274,1000,-1000,-365,-1000,132,-632,-230,1000,63,1000,923,551,1000,495,1000,824,248,1000,1000,736,857,70,-1000,-221}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00437() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "removeAnnotation(org.jfree.chart.annotations.CategoryAnnotation):boolean",
            new int[]{146,-666,158,-354,-1000,731,-272,-385,1000,-195,333,717,616,666,743,-577,821,855,-576,-1000,108,1000,-502,451,853,-725,1000,1000,160,257,-144,761,77,353,-909,453,301,423,91,-564,-17,-2,14,-27,800,-695,-1000,1000,-1000,1000,-1000,1000,626,267,-290,208,-766,920,497,-801,611,-750,158,-491}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00438() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "removeAnnotation(org.jfree.chart.annotations.CategoryAnnotation):boolean",
            new int[]{-35,-340,-952,521,-719,-965,475,940,764,-377,-339,246,-239,403,-777,7,-122,497,645,-835,279,-669,1000,-599,800,-189,502,745,-759,-440,-516,944,-459,52,-539,-343,-989,-1000,467,790,575,-152,-1000,397,-153,350,-431,794,-795,-45,996,-1000,-721,-528,375,547,-815,562,-295,123,15,14,-812,801}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00439() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "removeAnnotations():void",
            new int[]{598,478,779,689,-962,-1,896,156,745,-441,501,445,408,-267,-81,-368,506,358,538,878,-77,-679,104,-675,436,-440,-711,-237,-979,-56,-166,538,395,-679,-125,-21,972,-587,777,171,505,-517,-218,-714,-909,-254,89,-119,926,-667,595,600,216,284,-524,511,999,-452,999,965,-727,224,-450,-702}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00440() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "removeAnnotations():void",
            new int[]{-1000,1000,604,929,-1000,-949,-298,-283,53,94,-1000,481,417,818,1000,609,993,-704,845,1000,433,-294,451,-752,780,760,817,-1000,-812,-981,-1000,-265,969,-192,-1000,-1000,491,-31,-102,461,-1000,-551,1000,-420,1000,367,1000,-4,-1000,1000,1000,-1000,-85,-1000,-887,441,1000,-95,-1000,167,-909,-1000,176,215}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00441() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "removeAnnotations():void",
            new int[]{-1000,781,374,-600,716,1000,-1000,364,881,127,-1000,1000,-399,-522,-337,-672,-1000,-1000,117,-1000,-1000,267,-810,177,-863,-537,46,1000,-358,-937,-233,716,-352,-701,1000,252,-491,-890,-431,-1000,1000,-763,-1000,520,42,747,553,-641,-1000,-776,-1000,-559,-1000,624,1000,527,-951,18,-887,-1000,-1000,-848,393,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00442() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "removeAnnotations():void",
            new int[]{-848,533,677,901,25,492,89,-1000,514,-763,-378,1000,-1000,-142,-490,116,-303,-285,1000,-914,-755,-1000,1000,-728,-549,-1000,-1000,937,-350,-1000,-349,-615,331,-1000,887,368,1000,-1000,-1000,1000,1000,-883,-1000,-242,-1000,1000,-252,-419,-358,666,-435,-340,-1000,1,925,1000,-513,-1000,-519,1000,-1000,-1000,267,-583}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00443() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "removeAnnotations():void",
            new int[]{986,-25,-373,-682,1000,-56,-417,952,670,619,-591,918,1000,1000,1000,-801,-482,495,-1000,632,1000,1000,-628,1000,1000,1000,1000,515,81,1000,-1000,509,-289,-154,-1000,-427,-989,1000,1000,-606,-489,217,499,-314,613,-1000,-140,-350,480,-416,-333,-559,1000,-200,-874,321,22,421,1000,-1000,1000,155,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00444() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "removeAnnotations():void",
            new int[]{-249,363,-891,60,-982,-684,-639,374,904,-14,256,528,-183,464,937,-633,-830,783,-591,655,742,421,-888,-954,-416,712,-604,-768,-169,776,626,-298,-724,-813,-28,-697,-679,7,638,-610,33,-948,-715,692,-609,269,-311,270,-434,-988,-683,-97,-925,603,-588,-894,2,-901,455,-415,110,441,-612,-605}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00445() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "removeAnnotations():void",
            new int[]{-495,218,-326,5,191,-308,-628,-303,469,71,152,138,-788,251,603,-179,-845,101,538,-93,1000,330,-501,-663,-545,719,143,-237,-339,870,-94,-254,395,-1000,29,-793,-76,56,221,-299,315,-419,-660,-22,-467,29,-377,258,-481,-75,-806,30,-329,-16,-168,-327,164,-796,-756,107,-52,433,-703,-234}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00446() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "removeAnnotations():void",
            new int[]{535,-619,996,-44,682,677,307,934,839,-189,82,365,941,-342,-267,-14,-432,-25,-767,877,207,977,-689,-446,413,-369,845,-436,-695,535,676,-225,273,-97,-549,360,-468,561,770,-992,-709,80,-75,-696,658,-748,811,416,145,-75,-790,208,652,-98,-414,774,-856,93,767,-34,902,-625,-545,970}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00447() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "removeAnnotations():void",
            new int[]{46,-359,929,-334,-792,1000,-413,0,875,977,-1000,398,-1000,-1000,-1000,8,-866,-163,1000,-565,-448,-1000,-209,-1000,-1000,36,-663,1000,-129,41,-954,764,-613,-1000,921,-536,416,-1000,-378,-1000,-1000,-1000,-623,1000,1000,654,-140,-122,-1000,-1000,-1000,1000,-1000,142,988,1000,-140,-398,350,-86,-1000,-1000,-1000,305}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00448() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "removeAnnotations():void",
            new int[]{160,-251,-634,243,-752,274,-14,178,940,-999,423,761,-415,-337,649,189,-159,242,525,-92,-649,-320,466,866,-490,-995,308,910,675,-94,-966,201,570,-571,-642,274,-522,-165,-151,957,838,-54,-697,-262,-683,294,-676,363,111,-722,-252,-536,-745,-824,-566,-153,-923,-640,223,677,-440,-676,388,277}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00449() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "removeAnnotations():void",
            new int[]{685,-299,-16,181,-276,732,-553,663,594,822,1000,-446,426,-800,533,-1000,-128,386,338,-841,1000,-483,198,737,161,1000,-50,-408,88,542,588,946,-102,842,-1000,-1000,-468,260,678,861,-272,242,63,456,658,-673,-182,-312,562,-248,429,905,71,-533,-414,-1000,1000,-684,-297,-34,879,1000,-545,975}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00450() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "removeAnnotations():void",
            new int[]{-725,130,-312,-126,1000,-13,693,-124,542,-40,648,952,653,860,970,-579,-444,111,-1000,692,-134,1000,772,1000,774,582,-401,471,735,419,146,-210,286,-559,-841,1000,-59,1000,385,1000,1000,-65,-1000,-1000,-1000,-174,-317,-355,856,431,388,-418,80,1000,-280,1000,-1000,154,770,-1000,611,544,71,-21}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00451() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "removeAnnotations():void",
            new int[]{396,1000,913,-296,-356,379,-980,306,646,-465,-156,413,1000,1000,539,-267,-622,271,391,1000,50,713,-668,148,152,-1000,1000,505,-1000,161,-1000,639,1000,-248,-272,-1000,-562,-1000,589,-1000,-1000,-763,333,-51,1000,-170,-650,629,1000,-332,-84,239,417,-805,128,1000,94,411,-360,-558,-1000,-450,-593,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00452() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseItemLabelGenerator(org.jfree.chart.labels.CategoryItemLabelGenerator):void",
            new int[]{-887,1000,-522,-906,376,-733,1000,1000,-230,260,-1000,-978,-690,184,963,1000,1000,-926,-200,447,-16,-1000,-66,-688,1000,-1000,-627,-1000,-332,-660,-519,-402,656,-4,196,1000,-1000,1000,603,422,1000,-568,-1000,-439,946,-519,-1000,1000,-770,-872,1000,710,291,-978,-1000,-1000,1000,763,-55,-1000,1000,-933,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00453() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseItemLabelGenerator(org.jfree.chart.labels.CategoryItemLabelGenerator):void",
            new int[]{1000,-348,194,-412,-365,-354,-910,73,-194,1000,-433,1000,511,-750,-1000,-476,310,-659,-1000,669,-240,-887,1000,-941,897,924,373,5,-426,626,-274,1000,1000,27,-1000,-999,487,-821,468,-1000,-1000,1000,452,1000,419,-368,-693,270,127,-1000,25,-228,996,372,-811,1000,58,-625,-996,-771,-1000,-783,678,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00454() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseItemLabelGenerator(org.jfree.chart.labels.CategoryItemLabelGenerator):void",
            new int[]{-613,-89,448,199,-741,90,-618,560,126,348,-152,-806,-201,-1000,-989,-432,-78,-1000,-813,1000,-683,1000,1000,-447,79,334,683,-197,163,487,-623,1000,859,-731,-8,303,297,-294,982,-666,416,339,141,1000,272,-1000,-1000,-130,816,-589,20,223,330,-431,-78,-20,317,-65,-551,375,361,470,-223,125}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00455() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseItemLabelGenerator(org.jfree.chart.labels.CategoryItemLabelGenerator):void",
            new int[]{573,-999,998,1000,97,-226,-113,-477,-235,415,1000,486,-278,-997,381,-420,-1000,-926,-511,-134,-16,1000,-799,676,1000,775,-132,717,-332,891,-897,-402,-414,210,104,-422,422,-1000,-206,-1000,414,33,670,646,569,-45,1000,-1000,513,952,-1000,-856,-474,617,1000,1000,-1000,885,-588,1000,99,1000,-827,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00456() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseItemLabelGenerator(org.jfree.chart.labels.CategoryItemLabelGenerator):void",
            new int[]{-428,-312,-31,610,-92,966,-651,-72,641,400,-139,136,-313,-977,-352,-743,-898,-785,-1000,-503,-34,-1000,1000,-284,-559,952,344,146,944,395,-532,555,1000,-792,-480,-477,1000,-441,442,-52,-683,673,1000,694,375,-882,769,-1000,685,-726,-31,-1000,509,-110,-884,117,404,-432,278,-177,-745,35,887,366}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00457() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseItemLabelGenerator(org.jfree.chart.labels.CategoryItemLabelGenerator):void",
            new int[]{-1000,203,23,-42,-434,-1000,47,1000,-780,540,-1000,-1000,-507,-602,-1000,-50,1000,-752,-1000,1000,-1000,-144,1000,-654,926,-433,1000,308,1000,6,-291,1000,1000,-1000,-319,338,-335,22,595,-551,297,1000,-308,1000,1000,-1000,-1000,1000,-905,-482,1000,500,276,-544,-1000,-314,1000,-810,-1000,-897,553,-331,-8,-18}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00458() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseItemLabelGenerator(org.jfree.chart.labels.CategoryItemLabelGenerator):void",
            new int[]{-561,38,-206,-174,-40,207,700,1000,-204,545,-459,-422,-309,-1000,-660,756,62,1000,288,-700,-684,394,286,-1000,-847,317,50,656,46,-853,-112,-236,-31,33,348,509,413,-264,-797,801,-862,586,-207,-39,-625,-166,1000,-506,493,-695,369,437,256,-1000,0,1000,-2,1000,-583,-524,172,333,60,874}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00459() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseItemLabelGenerator(org.jfree.chart.labels.CategoryItemLabelGenerator):void",
            new int[]{392,-1000,151,787,-1000,-434,-107,371,-203,-590,-1000,1000,-1000,-403,-1000,360,-1000,-1000,-1000,835,-1000,1000,-520,-1000,593,246,1000,-741,1000,922,-58,1000,1000,1000,-1000,130,1000,337,429,-1000,1000,481,1000,1000,1000,-1000,-1000,-750,-451,242,-1000,-1000,1000,637,317,1000,-1000,1000,-767,781,-858,1000,-484,-339}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00460() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseItemLabelGenerator(org.jfree.chart.labels.CategoryItemLabelGenerator):void",
            new int[]{292,49,151,696,1000,-121,826,144,-178,1000,525,343,96,-437,336,178,-110,474,-1000,-409,910,1000,-1000,824,1000,-196,-710,864,483,-312,-1000,1000,-1000,724,574,-405,-975,-34,-268,17,206,-257,-396,-546,594,524,182,-193,224,724,223,389,-1000,9,-50,505,328,1000,10,-329,1000,120,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00461() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseItemLabelGenerator(org.jfree.chart.labels.CategoryItemLabelGenerator):void",
            new int[]{506,82,19,-546,45,-301,-1000,173,473,-348,124,-282,-16,-86,656,526,380,845,620,-355,300,546,-1000,-677,443,577,-780,-81,-981,161,-773,-275,-594,252,1000,719,-904,979,-175,258,250,-1000,-719,-449,130,-7,-583,606,247,-332,810,831,162,-66,-347,-1000,448,-1000,444,23,1000,9,-874,-347}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00462() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseItemLabelGenerator(org.jfree.chart.labels.CategoryItemLabelGenerator):void",
            new int[]{40,-1000,769,1000,-1000,-432,-519,538,76,795,-111,1000,-825,-820,-1000,251,-1000,-462,-981,-65,-516,891,-403,-621,143,1000,778,-306,1000,547,-155,742,466,824,-381,130,685,-831,938,-1000,1000,140,1000,1000,886,-921,66,-705,-157,1000,-1000,-1000,447,545,1000,11,-1000,1000,-345,1000,32,1000,-366,578}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00463() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseItemLabelGenerator(org.jfree.chart.labels.CategoryItemLabelGenerator):void",
            new int[]{-440,-89,-72,761,-741,1000,-910,44,804,357,521,200,195,-703,-480,-1000,-1000,-1000,-822,-747,1000,-1000,1000,-65,98,334,848,677,508,-682,-692,-702,1000,272,-1000,-999,297,-294,81,684,-683,550,874,176,-332,-262,707,-1000,456,-1000,20,-1000,-121,-209,-78,1000,-269,-336,-1000,-1000,-1000,-820,281,179}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00464() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseItemLabelGenerator(org.jfree.chart.labels.CategoryItemLabelGenerator,boolean):void",
            new int[]{1000,-102,393,44,-1000,57,990,96,-516,75,-1000,-172,117,-428,-1000,1000,1000,1000,793,86,-11,505,-930,-738,-1000,501,89,1000,102,521,-1000,1000,581,113,-1000,1000,711,-1000,1000,539,0,121,-272,-1000,-1000,-1000,306,-1000,-154,42,122,862,-1000,656,-119,819,-1000,-223,568,-771,-1000,1000,-465,-955}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00465() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseItemLabelGenerator(org.jfree.chart.labels.CategoryItemLabelGenerator,boolean):void",
            new int[]{476,-102,333,-284,-830,-737,529,-308,72,-769,-1000,-402,117,-380,-1000,1000,662,644,793,470,1000,-621,-969,-79,62,1000,360,890,39,-157,160,925,1000,-123,-349,1000,537,-267,1000,69,101,-116,1000,-182,-1000,548,369,-367,4,1000,463,862,645,-876,414,544,-1000,72,1000,-771,-78,1000,-429,-352}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00466() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseItemLabelGenerator(org.jfree.chart.labels.CategoryItemLabelGenerator,boolean):void",
            new int[]{-611,-1000,93,683,-1000,-1000,1000,-1000,509,397,890,-194,806,-473,1000,514,-1000,628,1000,24,1,1000,390,281,-1000,364,-173,1000,-1000,-1000,559,777,-271,-1000,1000,-236,416,1000,-96,-237,527,-546,795,561,200,-848,-1000,687,209,-491,-1000,222,126,842,433,562,-162,-1000,1000,485,1000,-1000,-1000,-82}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00467() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseItemLabelGenerator(org.jfree.chart.labels.CategoryItemLabelGenerator,boolean):void",
            new int[]{543,-1000,923,-97,-1000,-925,1000,-1000,-105,-435,-280,1000,-337,-1000,440,247,-1000,1000,583,894,845,811,-870,277,-514,426,-1000,655,-378,-1000,1000,1000,402,-807,857,1000,1000,709,918,884,561,-1000,-1000,332,145,1000,-37,616,-203,414,-592,1000,1000,958,88,1000,-446,-1000,409,-203,629,-634,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00468() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseItemLabelGenerator(org.jfree.chart.labels.CategoryItemLabelGenerator,boolean):void",
            new int[]{-621,692,564,-936,-829,-1000,990,-570,1000,1000,-94,631,367,-38,337,3,-873,612,1000,155,365,86,742,26,545,180,-184,792,-1000,-928,884,580,146,-919,1000,-85,12,-60,307,-242,162,-497,-956,752,325,1000,591,1000,482,-100,-552,-1000,933,-550,216,472,-208,-1000,156,139,394,-761,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00469() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseItemLabelGenerator(org.jfree.chart.labels.CategoryItemLabelGenerator,boolean):void",
            new int[]{683,-1000,298,1000,-1000,-136,671,-650,-155,-1000,-588,588,106,-1000,-496,782,-241,1000,-110,86,748,51,-1000,-369,-1000,1000,-1000,191,941,-442,713,778,1000,-2,-339,860,1000,-796,1000,582,627,-1000,-639,39,-782,1000,708,-291,-540,1000,494,1000,719,695,151,872,-1000,299,1000,-1000,762,598,26,-48}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00470() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseItemLabelGenerator(org.jfree.chart.labels.CategoryItemLabelGenerator,boolean):void",
            new int[]{400,-1000,-526,638,869,1000,-926,898,-759,699,-370,-561,1000,927,-1000,1000,1000,958,99,98,-733,1000,-201,-830,-729,-789,-8,-250,328,-442,-1000,-431,-150,1000,-542,-259,894,-445,-515,-1000,377,378,709,-1000,-1000,-1000,-1000,-1000,1000,107,1000,1000,-936,239,-940,410,-816,1000,-121,-400,-201,-28,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00471() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseItemLabelGenerator(org.jfree.chart.labels.CategoryItemLabelGenerator,boolean):void",
            new int[]{-1,-634,113,-193,-44,660,152,-313,-1000,683,-1000,-1000,-673,805,-1000,1000,671,-152,464,-854,-493,700,-120,-483,50,439,543,1000,-464,-125,-1000,1000,618,-310,-573,-260,-942,-609,811,463,-613,799,684,-134,-1000,-1000,-128,-353,-108,54,599,1000,-1000,-49,11,897,-134,-1000,-81,-1000,20,1000,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00472() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseItemLabelGenerator(org.jfree.chart.labels.CategoryItemLabelGenerator,boolean):void",
            new int[]{-1000,79,483,155,-827,809,837,453,-1000,-1000,-1000,1000,-1000,-247,-1000,251,233,612,-610,325,221,1000,-1000,-663,-981,850,-114,-233,1000,869,-463,685,150,1000,-1000,385,-1000,-1000,998,978,750,-1000,1000,-772,-55,-417,672,-899,-1000,378,948,22,1000,1000,-386,1000,-124,-809,-932,534,-718,1000,1000,369}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00473() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseItemLabelGenerator(org.jfree.chart.labels.CategoryItemLabelGenerator,boolean):void",
            new int[]{201,-72,198,1000,-964,-129,395,-258,-186,458,54,77,1000,-25,-1000,665,1000,399,841,-925,216,-572,689,-1000,-139,1000,-295,947,480,-231,-778,1000,974,-94,-719,-127,1000,709,1000,315,172,-593,170,474,-1000,-713,186,-400,384,1000,1000,1000,-1000,685,424,156,-592,144,419,-496,-400,282,172,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00474() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseItemLabelGenerator(org.jfree.chart.labels.CategoryItemLabelGenerator,boolean):void",
            new int[]{-1000,-788,-364,-679,974,871,-711,1000,-208,432,219,-1000,500,799,-251,751,682,62,-210,627,-695,451,909,-151,325,-1000,633,-1000,833,1000,-1000,-813,-1000,1000,770,-1000,-277,-79,-1000,-944,598,342,664,-1000,-494,-1000,-1000,-997,710,-1000,833,-74,242,-428,467,-856,77,1000,-829,1000,598,-1000,811,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00475() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseItemLabelGenerator(org.jfree.chart.labels.CategoryItemLabelGenerator,boolean):void",
            new int[]{-1000,-1000,-136,469,-140,580,70,393,41,1000,1000,-1000,1000,983,271,946,533,-154,341,-768,-601,558,1000,-381,157,-1000,1000,-356,-96,1000,-1000,-357,-1000,-135,550,-549,587,388,-1000,-1000,487,567,-244,-444,-837,-509,-1000,458,320,-1000,360,-764,-969,-1000,641,-1000,-52,612,527,-872,1000,-1000,570,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00476() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseToolTipGenerator(org.jfree.chart.labels.CategoryToolTipGenerator):void",
            new int[]{189,662,534,-752,1000,-912,684,1000,-432,-250,47,535,-17,769,-612,-650,42,608,-461,1000,646,-1000,-260,115,1000,-1000,379,717,1000,-1000,-378,-532,428,-368,862,-298,439,855,-951,-1000,-1000,322,366,-502,-316,-251,60,489,339,927,1000,616,712,-31,444,1000,782,4,760,-1000,78,595,435,280}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00477() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseToolTipGenerator(org.jfree.chart.labels.CategoryToolTipGenerator):void",
            new int[]{526,-400,-596,-212,-9,-820,408,-809,-731,-607,454,-564,340,312,-1000,-1000,-962,273,-585,-516,699,-1000,-1000,1000,891,207,270,-316,613,222,-493,-556,1000,960,23,687,624,83,1000,-1000,-641,220,-1000,-1000,-1000,1000,321,-38,-1000,-827,1000,137,566,-434,-400,-339,-190,51,811,-655,-574,-51,398,254}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00478() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseToolTipGenerator(org.jfree.chart.labels.CategoryToolTipGenerator):void",
            new int[]{9,951,-177,-9,1000,906,-893,362,124,-225,-881,139,-894,-440,476,96,-806,723,-500,-736,428,166,900,-741,-360,-296,349,707,-660,-853,-168,818,-169,-175,-462,-229,933,383,-299,-463,-522,-948,301,-45,398,-774,-195,-500,682,139,248,-11,713,-265,853,-300,583,375,140,-162,-122,-49,987,-881}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00479() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseToolTipGenerator(org.jfree.chart.labels.CategoryToolTipGenerator):void",
            new int[]{-531,924,738,-571,399,-194,-574,481,-852,-315,274,917,861,79,817,-552,973,-11,-684,996,-48,899,-404,-424,25,-865,-396,484,741,-110,288,32,390,921,241,-322,350,-44,-791,-639,-794,183,53,59,-832,854,47,172,725,981,476,185,755,-613,455,-736,367,-19,564,-91,-345,980,496,618}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00480() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseToolTipGenerator(org.jfree.chart.labels.CategoryToolTipGenerator):void",
            new int[]{620,951,-246,-965,1000,-897,1000,-4,-735,1000,-47,139,-509,-414,865,-724,190,723,-278,-630,1000,166,-1000,902,1000,-296,967,-23,242,121,965,-1000,925,-229,-268,512,28,128,-381,-478,54,-63,-1000,-260,-932,188,315,837,-234,139,1000,707,-845,-397,-1000,1000,-399,-784,969,-339,1000,255,881,26}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00481() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseToolTipGenerator(org.jfree.chart.labels.CategoryToolTipGenerator):void",
            new int[]{-95,1000,-363,1000,-247,213,-380,375,-31,-1000,1000,-1000,1000,605,-1000,-572,-1000,460,-874,-537,-319,293,-545,366,-425,897,-430,-1000,123,1000,-1000,547,378,-931,-421,301,368,-422,1000,-297,-866,89,-1000,-378,-995,836,-81,-936,-970,-916,664,-1000,1000,-1000,1000,-1000,1000,1000,385,224,-174,-932,367,340}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00482() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseToolTipGenerator(org.jfree.chart.labels.CategoryToolTipGenerator):void",
            new int[]{884,-35,-897,96,336,-548,172,15,-1000,-1000,-79,-296,-420,695,-1000,-968,-1000,1000,-703,83,1000,-1000,666,938,192,-269,-179,471,590,-382,-1000,594,944,642,94,618,1000,959,958,-914,-838,-634,-756,-1000,-435,-20,-215,111,-339,-731,1000,793,1000,-209,309,-1000,1000,183,494,-1000,-979,599,413,-371}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00483() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseToolTipGenerator(org.jfree.chart.labels.CategoryToolTipGenerator):void",
            new int[]{-502,429,253,-449,506,517,-556,-816,768,609,-119,-243,193,-987,903,50,812,-387,-332,169,-339,282,-329,-652,-989,385,-734,-416,-627,9,877,-825,-89,280,-563,-130,-88,-867,-752,253,-241,273,-47,268,528,682,571,-713,-262,2,-301,-949,-939,-587,-160,965,-118,186,593,715,457,-978,965,12}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00484() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseToolTipGenerator(org.jfree.chart.labels.CategoryToolTipGenerator):void",
            new int[]{-833,1000,952,348,507,-223,-944,1000,-690,-915,333,1000,956,163,884,-151,1000,834,-741,1000,-130,1000,519,-667,17,-1000,-581,729,614,-900,-133,1000,93,1000,330,-673,317,96,-376,-893,-1000,208,691,484,-502,621,-55,-29,940,1000,108,149,1000,-427,1000,-1000,1000,180,142,-76,-895,964,490,303}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00485() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseToolTipGenerator(org.jfree.chart.labels.CategoryToolTipGenerator):void",
            new int[]{250,-612,-523,-584,834,43,-576,-1000,-876,-716,179,-460,330,332,60,162,-954,-159,-518,-944,784,-1000,463,1000,315,114,0,-675,562,-91,403,-430,626,-341,522,251,-708,27,-212,-538,-461,-987,-16,639,-1000,644,796,-481,-78,-1000,921,-404,-369,-536,-1000,1000,716,1000,910,-134,-809,-998,1000,989}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00486() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseToolTipGenerator(org.jfree.chart.labels.CategoryToolTipGenerator):void",
            new int[]{9,1000,591,-542,1000,619,-1000,887,557,-225,-1000,-390,-762,-1000,1000,175,-1000,611,-1000,-178,-94,809,702,-1000,-689,70,-251,1000,-44,-1000,538,611,-873,-1000,-1000,-523,861,105,-987,-392,-253,-635,867,-793,1000,-189,304,-877,475,103,-265,-1000,1000,-436,853,-300,1000,375,604,205,-44,116,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00487() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseToolTipGenerator(org.jfree.chart.labels.CategoryToolTipGenerator):void",
            new int[]{-312,1000,314,664,-543,226,-1000,591,809,-437,-294,139,885,-313,-439,-137,-279,570,-453,349,-612,166,491,-568,-772,559,349,-882,-706,-47,-168,836,-169,-175,-462,-592,-511,-328,-991,183,-522,119,-102,767,450,-939,391,-500,-775,-176,-288,-1000,235,-705,1000,-447,1000,1000,858,245,-104,-1000,1000,-132}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00488() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseToolTipGenerator(org.jfree.chart.labels.CategoryToolTipGenerator):void",
            new int[]{87,-400,-537,802,-9,477,279,339,-731,1000,-968,-564,-1000,-714,553,223,-453,-464,-164,-1000,51,-400,-63,167,-835,877,107,-431,-1000,42,852,-288,-272,-543,-1000,181,343,-666,-590,554,93,-536,-320,-1000,904,-294,473,-38,-443,-601,-202,-643,-1000,-474,-400,1000,-410,323,592,655,998,-1000,1000,-817}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00489() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseToolTipGenerator(org.jfree.chart.labels.CategoryToolTipGenerator,boolean):void",
            new int[]{715,-1000,82,-766,1000,92,-1000,0,-906,-1000,851,-694,-29,815,527,-253,14,-241,-952,-447,1000,1000,1000,-1000,877,-1000,-497,-511,-218,437,1000,-660,722,942,-1000,1000,-192,-16,-308,-524,994,1000,-1000,-1000,472,-1000,938,320,-547,-1000,470,321,-374,1000,-1000,559,-1000,-486,44,-787,-9,-682,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00490() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseToolTipGenerator(org.jfree.chart.labels.CategoryToolTipGenerator,boolean):void",
            new int[]{-859,-485,-177,604,-43,611,-175,-906,-547,692,251,-387,459,-1000,993,549,125,-629,146,-434,-586,-1000,172,580,249,-914,-222,718,-1000,711,19,1000,-343,722,-886,-402,-632,-225,446,-195,730,1000,-712,-435,1000,-395,-790,-961,612,-512,280,-836,152,137,-75,119,1000,-125,-426,831,-122,-762,244,624}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00491() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseToolTipGenerator(org.jfree.chart.labels.CategoryToolTipGenerator,boolean):void",
            new int[]{534,-232,763,1000,682,180,82,-72,668,-375,508,669,260,1000,1000,727,104,461,579,-190,849,901,171,-1000,-622,423,-1000,1000,721,237,323,-1000,-1000,24,-214,-253,-1000,-404,-1000,-233,551,-1000,358,-24,-296,296,175,-1000,-407,-625,-650,-978,-225,544,114,-33,-1000,401,-840,1000,-253,-702,771,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00492() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseToolTipGenerator(org.jfree.chart.labels.CategoryToolTipGenerator,boolean):void",
            new int[]{-745,-482,302,588,545,499,68,-701,1000,-107,482,1000,-1000,-1000,933,-1000,-455,-345,26,567,655,406,1000,157,-1000,-1000,-532,1000,40,1000,675,-1000,-918,547,-1000,815,-192,-1000,577,814,744,-773,-506,971,1000,158,63,-865,-1000,-565,641,-863,547,1000,463,525,-1000,-1000,-134,150,-749,-105,-827,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00493() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseToolTipGenerator(org.jfree.chart.labels.CategoryToolTipGenerator,boolean):void",
            new int[]{-81,-817,-257,-415,1000,-61,-469,-542,-816,-1000,723,-556,-29,11,90,-444,-324,-390,-1000,-328,870,547,1000,-318,150,-510,-672,-193,-218,580,988,-512,1000,441,-1000,750,150,-759,85,365,515,1000,-285,-1000,1000,-604,730,324,-1000,-471,-61,-89,99,1000,-250,-63,-605,-478,230,4,201,-409,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00494() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseToolTipGenerator(org.jfree.chart.labels.CategoryToolTipGenerator,boolean):void",
            new int[]{-710,-1000,-362,-522,1000,174,-868,164,839,-1000,1000,182,-340,-1000,1000,-1000,-288,-814,-1000,475,1000,1000,-24,-128,-211,-1000,-634,-83,823,559,-338,-1000,-1000,993,-318,1000,391,-118,104,226,494,-241,-689,-304,50,-1000,896,138,-1000,-265,387,39,-250,1000,24,651,-385,-1000,1000,-1000,-339,-151,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00495() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseToolTipGenerator(org.jfree.chart.labels.CategoryToolTipGenerator,boolean):void",
            new int[]{846,-1000,-692,-593,634,-425,-358,1000,-705,-94,1000,489,-1000,20,306,-1000,462,349,-1000,1000,110,6,720,-569,-325,1000,-316,-1000,1000,-1000,614,-1000,-133,249,-787,884,467,69,215,1000,-1000,-1000,1000,651,179,1000,1000,114,-639,175,-1000,760,463,369,-1000,-375,115,-895,419,555,1000,279,-613,-248}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00496() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseToolTipGenerator(org.jfree.chart.labels.CategoryToolTipGenerator,boolean):void",
            new int[]{1000,-513,139,-184,764,-1000,95,-896,-1000,-1000,-1000,-484,946,1000,624,1000,740,566,389,289,900,786,184,-1000,769,162,-809,-1000,-1000,-529,854,1000,-1000,366,-607,615,-47,-526,-1000,-297,706,1000,-78,-767,-1000,-702,946,-1000,-1000,-241,-1000,-474,-1000,1000,-1000,-2,-1000,1000,497,-148,509,-210,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00497() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseToolTipGenerator(org.jfree.chart.labels.CategoryToolTipGenerator,boolean):void",
            new int[]{-773,772,499,-299,-28,184,-583,-759,-275,-53,-142,-436,-937,-57,641,344,-606,-585,-185,870,313,-670,569,582,66,739,514,43,138,-212,565,349,-519,936,-462,-476,-301,600,825,-223,-376,7,-25,-301,157,294,928,430,-15,-914,-292,629,-150,-294,-63,-326,-603,-83,219,-45,336,698,-396,-679}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00498() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseToolTipGenerator(org.jfree.chart.labels.CategoryToolTipGenerator,boolean):void",
            new int[]{1000,-1000,-13,-284,1000,-497,-1000,336,-1000,-1000,-1000,-1000,-303,666,510,1000,452,69,-703,-1000,1000,778,716,-720,1000,491,-711,-1000,-1000,-674,995,-240,400,607,-214,433,-1000,454,-313,-1000,927,1000,-616,-1000,-755,-834,712,-1000,-90,-1000,-334,810,-1000,844,-1000,287,-819,1000,-745,464,838,-442,-1000,539}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00499() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseToolTipGenerator(org.jfree.chart.labels.CategoryToolTipGenerator,boolean):void",
            new int[]{84,-154,-263,202,1000,-523,82,-1000,283,-863,1000,447,66,315,1000,389,-154,479,217,12,-222,-143,-401,956,-513,-798,-712,411,-1000,337,-170,1000,1000,106,-1000,-535,-804,-1000,405,549,350,-382,-1000,329,1000,-253,883,-78,-385,-286,-273,-1000,148,549,86,176,-1000,493,-1000,647,-122,-805,-317,504}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00500() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseToolTipGenerator(org.jfree.chart.labels.CategoryToolTipGenerator,boolean):void",
            new int[]{920,604,-714,-100,270,421,49,-1000,1000,477,871,1000,-1000,-1000,538,-336,-293,-86,-547,-522,1000,-674,3,716,-1000,-413,-810,1000,-727,715,-447,400,1000,279,-1000,-804,-178,-1000,755,467,1000,-1000,-292,971,1000,1000,-503,316,-19,-190,248,-815,522,-564,1000,99,-224,-400,327,855,-549,-655,-129,-318}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00501() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseToolTipGenerator(org.jfree.chart.labels.CategoryToolTipGenerator,boolean):void",
            new int[]{1000,-738,359,572,1000,-1000,439,-717,-1000,-1000,1000,-1000,1000,1000,-477,1000,1000,376,575,537,-222,702,-205,518,1000,-915,170,-329,-1000,-647,187,1000,-264,176,-523,-148,-1000,579,-815,-637,-185,1000,-1000,-1000,-859,-379,1000,-812,-19,-271,-1000,-856,-992,1000,-1000,-15,-1000,1000,-757,323,1000,-1000,-317,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00502() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseToolTipGenerator(org.jfree.chart.labels.CategoryToolTipGenerator,boolean):void",
            new int[]{1000,-591,-573,-493,1000,-911,-359,-756,-481,-708,-509,660,-1000,524,468,1000,593,505,-12,-55,655,151,863,-462,-594,844,-797,-608,-1000,-325,750,-1000,1000,549,-941,729,411,-1000,-147,93,502,882,340,398,-259,158,-134,-230,-985,-593,-1000,-111,-633,684,-720,-315,-742,923,-134,-282,1000,-38,-934,-5}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00503() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseToolTipGenerator(org.jfree.chart.labels.CategoryToolTipGenerator,boolean):void",
            new int[]{260,115,536,601,-531,-301,587,-366,-1000,180,-142,-1000,638,-507,189,1000,93,-286,-185,-300,-952,-470,-427,-137,1000,-146,725,642,-690,430,-82,1000,-514,-86,-462,-395,-941,608,-201,-711,-376,1000,-231,-900,226,153,-537,-943,370,406,663,-135,-178,404,-389,-261,276,883,352,856,-214,-183,936,-679}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00504() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseURLGenerator(org.jfree.chart.urls.CategoryURLGenerator):void",
            new int[]{-907,1000,703,1000,1000,-17,1000,-359,605,-1000,600,196,-1000,-13,1000,442,-1000,1000,-400,-468,-100,-327,8,135,364,1000,-1000,-511,-593,-867,1000,-442,-999,1000,1000,377,1000,-1000,1000,852,-643,1000,-443,-689,-1000,1000,1000,1000,-1000,-1000,492,-973,1000,-98,-1000,1000,1000,-243,-168,-1000,-1000,1000,10,-425}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00505() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseURLGenerator(org.jfree.chart.urls.CategoryURLGenerator):void",
            new int[]{645,777,-383,-542,1000,658,-318,603,-503,-596,-1000,-903,894,-328,86,-1000,-35,-1000,-540,270,-439,-309,-669,845,-164,-231,1000,-1000,400,-992,-928,-100,-8,-976,1000,1000,-390,253,-222,-1000,424,-1000,-1000,-1000,-400,385,-1000,235,595,563,1000,935,1000,-267,1000,-1000,-418,1000,1000,886,396,-809,-239,-714}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00506() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseURLGenerator(org.jfree.chart.urls.CategoryURLGenerator):void",
            new int[]{-474,457,-772,203,-400,210,697,3,486,-1000,-440,-577,-810,327,-219,45,-1000,338,-726,1000,177,985,-417,379,-113,330,273,-759,-379,-117,601,-336,890,-1000,334,694,125,1000,703,84,-532,117,-1000,-1000,400,1000,40,663,650,-331,1000,385,-295,-626,1000,100,-400,-69,1000,86,-186,1,-99,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00507() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseURLGenerator(org.jfree.chart.urls.CategoryURLGenerator):void",
            new int[]{1000,1000,-646,-1000,1000,356,-1000,527,-1000,1000,-1000,-1000,1000,-853,459,-1000,378,-1000,-1000,-249,-1000,130,374,1000,194,-642,1000,-1000,1000,-1000,-1000,-497,-488,-966,51,1000,-551,-1000,191,-1000,-1000,-1000,-810,-509,-1000,122,-1000,158,-931,1000,1000,439,1000,46,1000,-838,-169,1000,-171,880,485,-1000,-578,-780}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00508() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseURLGenerator(org.jfree.chart.urls.CategoryURLGenerator):void",
            new int[]{-1000,-606,596,-307,-975,588,-378,156,1000,706,885,755,1000,1000,626,213,340,-100,1000,-15,-1000,-1000,483,-789,-769,1000,424,1000,427,-711,-461,-711,1000,601,789,-384,-72,-1000,-382,841,-361,1000,1000,1000,-763,-423,-487,27,-622,-466,281,-558,1000,-478,-960,-51,-314,-786,-1000,958,158,-618,422,-286}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00509() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseURLGenerator(org.jfree.chart.urls.CategoryURLGenerator):void",
            new int[]{-1000,1000,351,-277,-1000,459,400,1000,1000,89,962,1000,-176,452,1000,899,-224,1000,1000,113,-66,-908,244,-1000,-764,-729,-1000,1000,-961,-852,711,1000,311,258,988,17,15,-1000,1000,1000,799,1000,-253,319,367,1000,1000,92,-1000,461,-1000,-259,1000,-802,-1000,435,-77,-398,105,634,-852,300,-249,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00510() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseURLGenerator(org.jfree.chart.urls.CategoryURLGenerator):void",
            new int[]{1000,-182,612,-120,1000,593,-568,-271,-1000,516,-816,-709,767,-1000,-693,-597,593,-610,-862,74,-425,-49,-375,492,-264,15,803,129,969,-1000,-870,-199,-2,420,-8,973,-26,617,-1000,80,-785,-1000,-247,-405,-880,-818,-972,-156,1000,245,735,287,-20,-130,601,-856,533,-20,255,-581,191,-730,602,-415}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00511() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseURLGenerator(org.jfree.chart.urls.CategoryURLGenerator):void",
            new int[]{287,-780,-572,-1000,188,86,-1000,-612,-495,1000,-302,-903,1000,-986,-534,-206,811,-533,-862,-381,-225,428,-93,574,560,-952,1000,-1000,1000,-1000,-1000,-835,748,-468,-1000,-273,257,609,-1000,-1000,-405,-1000,786,486,-724,-1000,-1000,-1000,1000,-303,66,-220,-119,295,640,-1000,147,166,-648,1000,1000,-1000,236,-214}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00512() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseURLGenerator(org.jfree.chart.urls.CategoryURLGenerator):void",
            new int[]{-1000,189,-461,-355,-1000,974,567,934,897,-1000,-320,-534,-60,896,464,-531,-1000,-9,860,208,343,300,-231,189,-1000,43,1000,-656,-1000,327,-243,771,397,-1000,-135,562,-423,534,156,-1000,541,-261,-132,-1000,1000,1000,-371,-93,1000,-837,445,1000,-1000,-1000,943,175,-1000,595,1000,970,162,-427,323,-868}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00513() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseURLGenerator(org.jfree.chart.urls.CategoryURLGenerator):void",
            new int[]{859,375,-716,-1000,409,666,-1000,435,-1000,828,-1000,-1000,1000,-57,188,-1000,108,-1000,-1000,-452,-776,86,-1000,1000,194,-658,1000,-1000,1000,-1000,-1000,-818,387,-1000,-706,1000,257,359,-1000,-1000,-777,-1000,252,-509,-498,-423,-1000,-191,1000,-466,908,439,668,-478,1000,-51,-354,1000,-171,859,1000,-1000,-305,-448}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00514() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseURLGenerator(org.jfree.chart.urls.CategoryURLGenerator):void",
            new int[]{10,1000,-412,-1000,184,59,-286,189,-1000,-1000,-670,-436,-824,735,246,74,-758,811,209,110,163,-1000,55,1000,794,-567,72,-1000,843,-239,-85,-641,-409,-318,-1000,-499,1000,1000,877,1000,42,810,-737,-1000,-28,1000,-490,-250,533,-902,518,874,-1000,-1000,37,633,-32,-114,435,-15,316,-23,-346,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00515() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseURLGenerator(org.jfree.chart.urls.CategoryURLGenerator):void",
            new int[]{203,1000,494,596,920,356,814,29,-469,-1000,-672,-1000,-757,-168,773,442,-892,889,1000,23,-352,-987,-800,135,-177,652,-849,-602,301,411,556,-92,-761,1000,637,890,595,-989,392,303,-492,1000,-677,-273,-973,1000,1000,942,-87,-707,306,-276,1000,-586,-580,571,1000,-192,291,-866,-703,546,39,-635}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00516() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseURLGenerator(org.jfree.chart.urls.CategoryURLGenerator):void",
            new int[]{57,231,982,-894,104,-369,-1000,-837,1000,-1000,730,808,-310,475,147,1000,-1000,125,-183,-166,-51,-527,486,-53,460,436,537,194,-421,12,-371,-1000,145,-1000,-60,-545,1000,725,1000,300,-35,1000,-823,-895,-660,225,102,-733,71,-1000,218,1000,-843,-451,395,156,1000,160,-552,-67,112,931,892,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00517() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseURLGenerator(org.jfree.chart.urls.CategoryURLGenerator):void",
            new int[]{568,1000,799,-470,-400,20,263,-258,-1000,-1000,-258,-534,-775,-563,1000,67,-785,-58,1000,1000,343,-1000,-961,503,10,686,-1,-853,1000,-148,-716,-54,397,354,859,369,862,-271,156,696,781,-261,400,636,-1000,1000,328,718,444,-837,1000,415,798,579,-758,175,-1000,-652,-557,819,-485,847,170,-874}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00518() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseURLGenerator(org.jfree.chart.urls.CategoryURLGenerator):void",
            new int[]{-680,-1000,991,-698,105,511,-580,-497,1000,238,-1000,-1000,355,34,-622,34,-15,1000,1000,774,-345,256,99,443,-1000,959,954,114,921,1000,65,588,4,-143,-1000,289,-472,855,0,-526,376,-542,377,-914,456,1000,-1000,-649,1000,-154,1000,98,-45,-1000,332,-1000,-365,-577,-1000,-68,1000,-307,840,-290}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00519() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseURLGenerator(org.jfree.chart.urls.CategoryURLGenerator,boolean):void",
            new int[]{-271,-539,684,692,-1000,-946,-1000,-778,792,-821,-527,-1000,-574,-631,1000,-634,1000,-176,-1000,-705,-1000,-860,520,-1000,68,-322,-1000,1000,-172,350,1000,-455,-379,-426,-609,849,586,1000,971,562,360,1000,375,1000,-380,-573,-592,1000,436,-894,-1000,941,-401,-153,449,-1000,-832,-264,-1000,-137,1000,807,496,981}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00520() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseURLGenerator(org.jfree.chart.urls.CategoryURLGenerator,boolean):void",
            new int[]{-936,268,-608,-400,-500,234,688,202,309,793,-1000,587,523,125,-571,-400,-369,868,-383,-565,1000,200,-1000,-117,-155,-1000,171,-334,2,592,-1,-147,108,490,11,1000,662,188,-156,-651,-298,-110,-400,64,-362,336,-332,-1000,965,-1000,-792,608,-1000,263,8,-584,236,1,536,496,-9,1000,-944,381}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00521() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseURLGenerator(org.jfree.chart.urls.CategoryURLGenerator,boolean):void",
            new int[]{-651,-851,-186,-1000,1000,968,1000,895,1000,501,-1000,1000,1000,0,-1000,639,-120,439,-244,30,1000,-375,-995,838,-1000,-1000,-865,1000,-465,1000,223,645,673,1000,-486,-1000,1000,-1000,-382,51,256,323,-531,760,-1000,895,-1000,-1000,-59,-736,-1000,398,-481,1000,-18,-941,706,-405,-104,1000,-473,956,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00522() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseURLGenerator(org.jfree.chart.urls.CategoryURLGenerator,boolean):void",
            new int[]{-89,-1000,-934,-400,-500,234,1000,202,1000,989,-1000,1000,1000,556,-662,67,-37,972,-580,-429,1000,-799,-705,1000,-1000,-1000,-865,1000,-613,1000,195,380,1000,1000,-1000,-1000,1000,-1000,-1000,-68,660,502,-614,1000,-1000,336,-1000,-1000,-340,-1000,-1000,613,-46,1000,1000,-405,710,-1000,-947,724,-224,1000,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00523() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseURLGenerator(org.jfree.chart.urls.CategoryURLGenerator,boolean):void",
            new int[]{100,-424,739,-463,626,-333,846,-441,-656,-102,432,-362,351,854,804,-542,-118,-871,-937,80,-933,-615,20,-181,276,639,570,-1000,-1000,-751,1000,-952,93,230,777,1000,-16,651,75,979,-672,-391,1000,406,967,-466,1000,-189,634,418,621,888,1000,-545,-754,-868,-373,361,-708,247,-348,-629,329,350}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00524() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseURLGenerator(org.jfree.chart.urls.CategoryURLGenerator,boolean):void",
            new int[]{-1000,-378,289,995,192,1000,-90,639,-439,64,391,-1000,504,56,-414,279,-739,-439,104,191,-866,-295,-869,-14,548,656,186,-799,-451,-1000,920,-206,-218,315,593,1000,-443,312,823,291,-605,-802,1000,210,1000,-64,391,975,572,592,450,-875,356,-454,-785,-428,206,463,-122,576,-1000,-398,1000,227}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00525() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseURLGenerator(org.jfree.chart.urls.CategoryURLGenerator,boolean):void",
            new int[]{-1000,-1000,677,-486,-484,891,-719,-239,-1000,-1000,982,-1000,-104,-1000,330,1000,-826,-837,1000,-1000,-1000,842,-351,-1000,182,1000,-1000,-258,-878,511,-797,1000,-1000,-739,1000,-1000,-1000,649,653,1000,-117,1000,-895,-191,-398,-531,-1000,1000,1000,1000,-153,-180,1000,551,-585,-1000,188,-197,332,1000,606,-1000,393,-184}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00526() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseURLGenerator(org.jfree.chart.urls.CategoryURLGenerator,boolean):void",
            new int[]{-879,-475,-677,415,458,689,399,-402,-1000,-578,1000,-215,-1000,1000,-1000,1000,-1000,-1000,831,-360,-628,1000,554,244,502,608,1000,-567,451,1000,-72,962,414,1000,1000,849,-1000,-1000,-380,-333,-1000,-1000,949,-740,210,1000,47,-385,628,1000,691,64,1000,64,-705,31,867,942,1000,1000,-1000,-1000,-63,-48}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00527() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseURLGenerator(org.jfree.chart.urls.CategoryURLGenerator,boolean):void",
            new int[]{-165,-660,-41,605,-965,-362,-908,-679,-97,-514,7,-264,-469,286,589,405,116,-527,-995,-820,-696,384,896,-200,-135,59,-906,910,-209,-333,-210,229,-537,-440,-388,1000,-8,776,715,712,-377,663,-675,-812,-553,-655,-762,502,1000,-20,-400,-553,134,193,76,-722,-91,520,176,166,658,-57,-207,-123}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00528() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseURLGenerator(org.jfree.chart.urls.CategoryURLGenerator,boolean):void",
            new int[]{-890,-142,269,687,-375,121,812,374,-385,848,7,1000,-469,558,-1000,523,-1000,184,61,-820,1000,1000,-990,368,0,-650,1000,-806,-49,-333,83,229,422,437,590,1000,-354,-963,1000,-1000,-880,-1000,257,-812,-553,-677,-222,-1000,1000,-304,-357,1000,-1000,193,-441,-722,686,520,856,1000,-1000,-57,-671,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00529() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseURLGenerator(org.jfree.chart.urls.CategoryURLGenerator,boolean):void",
            new int[]{-952,-352,-31,-89,-181,1000,618,1000,922,-301,-731,1000,1000,-202,-1000,615,439,240,-307,646,1000,539,-731,-563,-1000,-1000,-1000,1000,-452,567,457,972,-197,669,-936,-658,1000,-745,749,141,-100,177,-125,-480,-997,258,-858,-257,-2,-1000,-1000,-113,-1000,562,-871,-1000,631,416,131,1000,-201,740,-146,697}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00530() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseURLGenerator(org.jfree.chart.urls.CategoryURLGenerator,boolean):void",
            new int[]{-192,-937,-389,-400,-500,-257,113,-917,-751,-234,460,-42,-1000,379,-44,936,-818,-753,423,-565,232,1000,-182,-675,753,551,31,-253,-545,-536,-674,-147,-496,-618,933,330,-756,528,-90,-651,-298,304,-764,64,-362,336,-523,-400,589,778,-792,707,1000,966,293,-102,-82,-185,1000,1000,155,-373,-581,766}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00531() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setBaseURLGenerator(org.jfree.chart.urls.CategoryURLGenerator,boolean):void",
            new int[]{-611,695,698,-1000,-271,-398,1000,131,1000,1000,-1000,683,610,-1000,1000,-1000,1000,-169,-954,-1000,-186,-1000,301,764,-593,-1000,-674,346,-1000,1000,769,-784,40,784,-536,-1000,1000,-497,-913,725,1000,962,-1000,-553,-1000,-775,257,-1000,-1000,-1000,-1000,1000,-1000,1000,708,514,-973,-1000,-1000,-1000,1000,1000,-1000,-476}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00532() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setLegendItemLabelGenerator(org.jfree.chart.labels.CategorySeriesLabelGenerator):void",
            new int[]{-570,263,898,-1000,-370,-1000,-166,-488,-173,94,-360,-400,250,-1000,477,-557,-381,198,-165,-894,-319,-493,555,1000,-1000,1000,-450,-1000,742,453,239,-1000,-158,-374,437,-728,799,288,-797,-376,818,-779,760,1000,-86,-887,-538,18,1000,325,408,-576,137,298,-25,-58,-708,274,-357,-683,-1000,-358,235,-505}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00533() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setLegendItemLabelGenerator(org.jfree.chart.labels.CategorySeriesLabelGenerator):void",
            new int[]{-367,-236,-612,-249,143,482,-1000,-608,-395,1000,209,96,-961,913,459,-1000,615,925,-49,596,-301,1000,598,779,-890,1000,-1000,-739,1000,1000,828,189,-1000,1000,1000,340,1000,328,-1000,-160,1000,195,956,-259,-847,-1000,-317,36,494,-948,-843,605,-228,400,481,996,-148,-653,324,-1000,-580,354,508,-98}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00534() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setLegendItemLabelGenerator(org.jfree.chart.labels.CategorySeriesLabelGenerator):void",
            new int[]{-32,259,-861,141,-866,-167,-758,307,-256,948,234,-169,355,760,855,139,911,-182,-878,11,-241,-34,807,-140,-442,716,115,178,570,540,164,-664,-147,377,686,-232,940,40,-758,-950,744,211,139,-654,611,-792,250,-714,758,838,961,454,-407,-719,615,368,-116,-809,-45,-946,131,-34,346,-825}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00535() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setLegendItemLabelGenerator(org.jfree.chart.labels.CategorySeriesLabelGenerator):void",
            new int[]{97,-159,-261,-669,-540,211,926,-209,-642,-25,567,760,-961,-1000,42,-947,-426,-524,479,185,-612,945,523,483,-813,120,95,-150,114,-990,600,952,-3,767,850,-541,-387,-982,-182,441,63,-537,285,-19,-487,30,-606,678,883,-22,-796,793,-665,999,443,-474,-148,596,-194,-884,628,-222,-566,323}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00536() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setLegendItemLabelGenerator(org.jfree.chart.labels.CategorySeriesLabelGenerator):void",
            new int[]{-1000,91,634,-1000,-759,-324,376,-961,-1000,95,-61,660,245,-487,1000,382,1000,181,-1000,33,-472,555,-371,533,163,615,-980,-456,629,812,646,-1000,-253,-1000,1000,-449,1000,1000,-743,-1000,932,-1000,478,166,-41,-856,-643,360,820,-780,888,-85,273,-1000,1000,163,-1000,-271,191,-643,-1000,-222,1000,-706}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00537() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setLegendItemLabelGenerator(org.jfree.chart.labels.CategorySeriesLabelGenerator):void",
            new int[]{584,27,-861,141,242,516,-32,307,587,-549,732,-169,-256,827,855,769,911,468,-252,-589,230,-859,-792,-426,-442,-476,638,411,847,1000,595,-753,418,-730,598,1000,544,558,95,-950,732,32,-279,289,1000,111,1000,-714,102,188,-313,513,-377,-561,615,-642,-116,-933,755,262,95,-34,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00538() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setLegendItemLabelGenerator(org.jfree.chart.labels.CategorySeriesLabelGenerator):void",
            new int[]{-1000,-1000,614,279,1000,-583,-1000,-14,1000,1000,-1000,-411,1000,682,138,-510,18,-322,372,-167,-2,-420,-1000,1000,1000,533,-451,875,417,808,-182,-857,-204,-657,1000,-87,1000,1000,-503,-299,-382,-971,-778,-552,202,-1000,-1000,-1000,1000,655,1000,-1000,-174,-683,89,488,-437,-412,-659,-409,-804,-1000,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00539() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setLegendItemLabelGenerator(org.jfree.chart.labels.CategorySeriesLabelGenerator):void",
            new int[]{265,1000,-566,-965,109,744,135,-1000,-732,-1000,306,-396,-842,759,958,270,1000,1000,-934,-55,-377,648,834,-808,-443,-35,-984,-379,640,167,1000,379,-194,-347,125,729,-388,27,-592,-1000,1000,1000,609,74,-556,-747,550,196,-329,-1000,-1000,359,7,683,-10,1000,-759,896,1000,-640,-936,390,-7,763}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00540() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setLegendItemLabelGenerator(org.jfree.chart.labels.CategorySeriesLabelGenerator):void",
            new int[]{75,861,542,936,331,947,-175,-575,-142,-630,139,-124,490,755,-220,-343,-242,798,394,805,-733,789,-32,-511,969,-795,-61,674,689,687,921,-964,295,-443,-657,-961,-22,477,147,565,252,756,631,-571,-519,-584,-504,738,-979,-827,-785,-868,384,-834,943,-335,-769,495,-626,320,-550,-609,172,-30}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00541() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setLegendItemLabelGenerator(org.jfree.chart.labels.CategorySeriesLabelGenerator):void",
            new int[]{927,-259,914,66,129,649,18,-34,493,-414,721,-458,-188,889,-445,73,-724,482,379,-631,405,-188,-299,294,-636,-46,228,-44,739,412,816,-216,828,-48,801,616,619,240,-436,343,731,-983,78,665,839,60,204,71,338,320,-467,301,-651,220,676,-794,-443,-613,108,209,834,814,866,-647}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00542() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setLegendItemLabelGenerator(org.jfree.chart.labels.CategorySeriesLabelGenerator):void",
            new int[]{-255,-25,-332,908,546,-299,857,159,776,2,-962,-110,526,-180,726,911,-625,-19,-945,-567,553,632,-522,-345,-498,-562,-369,46,-251,939,404,-591,-935,279,-919,745,906,-42,265,313,334,201,227,336,-217,95,-696,336,307,-275,-967,221,301,-805,-210,-71,44,670,915,-307,898,317,501,-192}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00543() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setLegendItemLabelGenerator(org.jfree.chart.labels.CategorySeriesLabelGenerator):void",
            new int[]{488,391,359,-862,-199,-364,-992,-427,751,595,-28,-889,-526,-487,158,-656,-593,63,-385,-285,994,318,-371,-872,-220,-906,726,-755,-375,-925,-57,-905,732,-10,-508,-473,-665,-505,820,463,974,409,985,-98,523,474,256,-797,-601,898,901,309,-297,619,-788,-769,440,427,38,401,420,876,-719,302}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00544() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setLegendItemLabelGenerator(org.jfree.chart.labels.CategorySeriesLabelGenerator):void",
            new int[]{-1000,-365,-507,1000,-928,-596,280,637,-597,-269,436,58,683,1000,-3,976,373,-352,-1000,3,282,-532,-1000,-713,771,-538,-751,342,116,1000,-35,-1000,-861,-131,-1000,974,1000,792,-307,-423,-390,214,-673,15,-3,-626,-69,562,264,-764,-1000,-217,1000,-1000,-35,961,-144,417,1000,76,-118,-142,827,-905}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00545() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setLegendItemLabelGenerator(org.jfree.chart.labels.CategorySeriesLabelGenerator):void",
            new int[]{613,-331,-753,277,231,-335,-1000,313,-173,579,-342,-924,-471,-182,477,-557,-331,-753,443,-196,607,-493,304,-612,-228,1000,489,-14,-548,-1000,-541,595,46,-374,-400,-728,-441,-1000,568,489,26,685,-466,-290,-86,-6,299,-1000,-107,1000,-889,16,-720,769,-1000,374,590,901,405,-683,857,-228,-1000,-505}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00546() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setLegendItemToolTipGenerator(org.jfree.chart.labels.CategorySeriesLabelGenerator):void",
            new int[]{-26,-260,429,-276,96,-577,72,-67,-367,-817,-254,-381,-704,436,-1000,123,72,-116,-1000,496,-637,-666,20,-127,368,1000,163,-1000,-157,159,917,477,-1000,-1000,78,663,-874,268,-987,104,-935,611,903,564,17,1000,191,-450,-1000,-74,312,-872,855,185,771,227,-601,-483,-589,943,-26,992,1000,282}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00547() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setLegendItemToolTipGenerator(org.jfree.chart.labels.CategorySeriesLabelGenerator):void",
            new int[]{326,892,304,379,155,100,-310,-713,703,537,450,-824,-755,529,558,495,819,683,-59,-352,-298,901,20,-323,1000,-10,-417,-331,-299,159,-18,34,312,-1000,567,-154,124,503,309,41,-22,409,-56,-241,-691,-117,508,1000,96,-563,882,-159,-550,-797,-486,19,372,412,-274,-243,-166,-920,252,-258}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00548() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setLegendItemToolTipGenerator(org.jfree.chart.labels.CategorySeriesLabelGenerator):void",
            new int[]{-45,-891,134,-241,-91,-1000,410,969,-12,-222,12,143,744,568,-1000,-154,-1000,-888,-1000,1000,-1000,-1000,-388,-912,429,1000,1000,-1000,1000,-20,1000,1000,144,1000,454,1000,-1000,231,1000,271,-1000,-1000,-1000,1000,1000,1000,869,253,-521,433,-536,-1000,425,538,-429,414,-340,1000,-478,1000,-1000,32,612,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00549() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setLegendItemToolTipGenerator(org.jfree.chart.labels.CategorySeriesLabelGenerator):void",
            new int[]{-79,-1000,-306,-112,612,-284,797,1000,865,-315,-235,-53,479,35,-686,-1000,-280,-49,-1000,554,-2,-1000,-328,-262,1000,694,-211,-1000,1000,1000,1000,-551,540,363,1000,1000,-54,97,797,559,-379,-260,-1000,-274,839,196,1000,-404,-475,319,-235,-1000,-44,1000,-908,-428,-394,-291,-451,104,-668,-570,868,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00550() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setLegendItemToolTipGenerator(org.jfree.chart.labels.CategorySeriesLabelGenerator):void",
            new int[]{-92,-1000,182,-659,227,-997,420,603,-553,-760,-616,-544,-1000,-118,-1000,-374,-1000,-285,-372,786,-735,-789,-400,-1000,497,1000,157,-203,842,-20,580,675,-284,428,652,1000,131,208,716,-190,-317,-1000,167,672,1000,1000,799,-404,-93,-100,9,-1000,425,205,376,1000,-193,-358,17,522,-424,59,513,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00551() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setLegendItemToolTipGenerator(org.jfree.chart.labels.CategorySeriesLabelGenerator):void",
            new int[]{23,683,274,952,227,-690,172,-331,596,-224,-484,-1000,-1000,-1000,1000,-136,974,803,1000,-1000,-735,-990,517,-729,1000,-542,-1000,1000,-1000,-1000,-1000,-526,-284,-425,823,114,131,940,-1000,463,102,296,167,-1000,860,-1000,223,362,1000,-100,688,-339,-662,87,-1000,-1000,-471,-1000,-229,-774,895,-16,673,-446}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00552() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setLegendItemToolTipGenerator(org.jfree.chart.labels.CategorySeriesLabelGenerator):void",
            new int[]{433,-1000,-177,-1000,1000,-186,1000,-67,-979,266,-13,143,1000,1000,-1000,777,-1000,-87,-1000,1000,1000,192,64,-923,1000,1000,157,-1000,1000,579,1000,344,379,-1000,361,605,-1000,268,1000,942,-628,-1000,-1000,1000,203,1000,1000,-1000,-397,1000,-839,-1000,736,586,979,-1000,682,-430,148,1000,-757,-451,422,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00553() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setLegendItemToolTipGenerator(org.jfree.chart.labels.CategorySeriesLabelGenerator):void",
            new int[]{153,279,29,52,213,632,992,-44,9,-50,-211,-413,-183,-569,21,-279,396,718,1000,-54,-1000,-367,400,-938,1000,-550,-1000,1000,45,-656,-882,-1000,1000,-1000,1000,-209,528,914,-1000,-484,327,-155,-205,-1000,30,-991,1000,-595,900,457,605,-719,-543,-325,-1000,-514,647,-747,741,-56,225,-1000,-63,553}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00554() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setLegendItemToolTipGenerator(org.jfree.chart.labels.CategorySeriesLabelGenerator):void",
            new int[]{368,856,304,732,227,1000,1000,-697,-553,537,-129,-846,664,-1000,1000,-267,728,-285,1000,-960,770,-300,1000,-1000,1000,-978,-1000,1000,324,-20,580,-1000,988,-598,1000,-595,-309,1000,716,-190,-317,-487,-1000,-241,825,-852,1000,-225,1000,1000,1000,-484,-1000,-797,-1000,-934,788,-1000,698,-741,879,-1000,-63,263}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00555() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setLegendItemToolTipGenerator(org.jfree.chart.labels.CategorySeriesLabelGenerator):void",
            new int[]{349,-1000,-101,-1000,986,-174,1000,1000,-244,-214,-347,-53,1000,801,-1000,-279,-1000,718,-1000,1000,491,-227,-284,-938,497,851,-211,-996,1000,1000,794,-882,1000,-40,680,1000,-143,914,1000,-454,1,-1000,-1000,284,30,1000,1000,-595,-497,1000,-823,-1000,200,254,-232,586,585,-291,606,828,-868,-1000,264,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00556() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setLegendItemToolTipGenerator(org.jfree.chart.labels.CategorySeriesLabelGenerator):void",
            new int[]{-17,-854,429,-887,1000,-264,833,-122,-367,-404,-227,4,405,135,-1000,3,-388,316,-1000,786,-637,-166,-83,-127,1000,1000,-434,-730,-157,820,1000,216,-58,-972,935,693,-1000,234,780,624,-387,-1000,-1000,439,56,965,891,-1000,-1000,1000,-177,-1000,525,691,895,-873,346,-1000,-50,522,-491,-255,566,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00557() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setLegendItemToolTipGenerator(org.jfree.chart.labels.CategorySeriesLabelGenerator):void",
            new int[]{952,-508,684,-824,-35,796,-45,228,904,-279,-211,1000,225,224,-825,-513,411,-1000,-1000,-54,374,-1000,400,-96,1000,924,1000,248,131,996,500,-1000,-715,504,535,-209,-1000,-408,1000,-137,-124,-191,-576,1000,505,649,-608,775,-1000,792,-30,-719,-117,736,1000,508,-468,1000,567,278,-1000,-237,153,-353}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00558() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setLegendItemToolTipGenerator(org.jfree.chart.labels.CategorySeriesLabelGenerator):void",
            new int[]{-406,282,-107,476,-535,-84,-189,474,1000,683,-648,962,-560,1000,412,-817,329,-810,-1000,-434,-1000,-1000,-872,124,-593,-792,1000,589,-246,1000,260,1000,1000,423,1000,231,1000,-318,283,688,-318,-1000,71,178,-166,-872,-400,1000,-214,-1000,479,-286,-1000,729,-571,-1000,273,1000,295,-1000,-871,-958,-811,-721}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00559() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setLegendItemURLGenerator(org.jfree.chart.labels.CategorySeriesLabelGenerator):void",
            new int[]{1000,841,748,-184,930,325,797,228,-479,703,-625,623,810,838,-650,-1000,-814,1000,-512,346,1000,887,-634,653,-1000,991,1000,168,1000,389,1000,-383,102,163,184,889,-1,-918,-1000,268,309,-270,821,-380,322,1000,-410,199,-535,-314,789,-118,-1000,1000,-134,-740,345,-395,-175,77,503,-1000,-723,414}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00560() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setLegendItemURLGenerator(org.jfree.chart.labels.CategorySeriesLabelGenerator):void",
            new int[]{14,679,1000,572,1000,1000,-222,47,-318,1000,-802,1000,84,1000,-1000,-533,-56,757,-800,880,1000,-201,-988,-904,-995,984,1000,1000,1000,-396,-1000,-53,195,-344,1000,1000,336,-1000,-55,753,1000,186,1000,-539,936,1000,-1000,364,-717,-19,1000,-826,-662,1000,341,-1000,1000,-1000,-1000,-162,1000,-457,-673,947}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00561() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setLegendItemURLGenerator(org.jfree.chart.labels.CategorySeriesLabelGenerator):void",
            new int[]{77,-327,199,-188,1000,158,-579,334,1000,1000,-686,1000,-128,-28,-1000,-1000,-1000,76,-689,525,1000,1000,-1000,306,-278,1000,1000,891,1000,742,-1000,-1000,-432,203,1000,1000,930,-440,-1000,338,1000,-277,1000,35,819,761,-1000,-1000,-1000,-353,1000,-657,-667,-168,-375,47,1000,795,-1000,1000,1000,-1000,-437,-317}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00562() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setLegendItemURLGenerator(org.jfree.chart.labels.CategorySeriesLabelGenerator):void",
            new int[]{-131,343,-709,-300,-194,-902,-222,378,329,-301,-134,-692,392,-513,378,-679,-101,-162,1000,-235,332,679,715,-251,-185,548,-77,-515,-553,509,477,237,362,176,-1000,-656,-177,1000,-958,-344,-489,-1000,55,-429,-1000,-407,706,364,-7,-717,-449,778,-471,-153,-486,599,-688,-1000,626,-140,-404,78,-148,914}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00563() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setLegendItemURLGenerator(org.jfree.chart.labels.CategorySeriesLabelGenerator):void",
            new int[]{18,1000,374,335,883,-880,-222,-34,160,486,249,-193,-1000,1000,-578,-533,1000,1000,1000,354,-1000,-1000,-921,-904,-199,-49,-1000,627,-913,509,-21,1000,-1000,290,-1000,-656,1000,-315,-847,625,-489,1000,-94,-513,-690,348,706,364,-7,1000,-449,-1000,184,-153,-486,-1000,1000,356,362,-400,565,670,131,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00564() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setLegendItemURLGenerator(org.jfree.chart.labels.CategorySeriesLabelGenerator):void",
            new int[]{1000,-214,-66,1000,-14,175,-188,5,1000,1000,-304,517,-98,-760,-891,-1000,-683,-1000,407,739,539,23,-710,739,-182,130,400,-147,585,-193,553,-1000,-1000,-908,1000,1000,-735,-564,-811,383,431,-134,1000,-212,1000,472,-23,-666,-394,108,816,-102,96,-22,96,210,497,761,-766,721,641,-1000,-922,-572}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00565() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setLegendItemURLGenerator(org.jfree.chart.labels.CategorySeriesLabelGenerator):void",
            new int[]{-549,-103,-656,-84,-895,-187,7,651,189,-301,-515,-559,1000,-1000,140,777,-920,-1000,-291,-163,1000,1000,-315,640,-185,523,-77,-640,89,995,-54,-926,-1000,-176,-1000,260,-1000,773,17,-82,-1000,-1000,670,-392,-291,-5,1000,802,559,-1000,250,1000,-466,605,-373,1000,697,579,810,-140,-404,-376,-687,-486}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00566() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setLegendItemURLGenerator(org.jfree.chart.labels.CategorySeriesLabelGenerator):void",
            new int[]{-652,-186,-356,549,-530,-42,113,756,-320,89,-942,168,1000,-911,45,833,-344,-1000,-917,186,1000,400,-297,1000,-621,634,-301,-224,216,45,-364,-1000,-979,-559,195,560,-847,387,1000,-708,-767,-200,1000,-574,234,34,-673,708,-80,-1000,604,1000,-449,714,185,1000,1000,-47,215,388,-100,-960,-1000,-65}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00567() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setLegendItemURLGenerator(org.jfree.chart.labels.CategorySeriesLabelGenerator):void",
            new int[]{220,224,122,553,-453,-900,-365,324,452,1000,-1000,1000,334,448,-1000,-673,-1000,-94,-1000,1000,1000,1000,-992,253,-275,989,1000,1000,1000,531,1000,-337,-480,-407,1000,1000,1000,-440,-592,321,1000,-599,263,-488,774,793,-1000,1000,-998,-22,1000,-1000,-430,-168,-1000,-873,1000,-605,-1000,1000,1000,-1000,-751,437}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00568() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setLegendItemURLGenerator(org.jfree.chart.labels.CategorySeriesLabelGenerator):void",
            new int[]{50,9,-375,-1000,-450,476,-516,1000,859,703,606,-630,-1000,-384,239,752,795,513,1000,-1000,452,-1000,-40,358,-1000,-990,380,-1000,484,1000,-762,-1000,984,946,1000,1000,-1000,-1000,-810,374,1000,1000,1000,172,-297,-625,379,-1000,142,1000,394,-1000,-571,203,-734,109,-928,695,-631,-1000,-1000,-314,1000,-384}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00569() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setLegendItemURLGenerator(org.jfree.chart.labels.CategorySeriesLabelGenerator):void",
            new int[]{-1000,1000,24,-889,-823,-701,382,-197,-1000,-1000,-473,-1000,593,-28,493,651,-220,-175,-323,96,-516,-978,-302,716,-1000,969,306,-278,-744,620,-114,-421,-1000,194,869,-619,992,12,1000,-728,-666,25,478,72,40,292,478,889,1000,-358,272,381,-1000,-360,-1000,-549,769,-418,463,-1000,-995,883,-87,63}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00570() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setLegendItemURLGenerator(org.jfree.chart.labels.CategorySeriesLabelGenerator):void",
            new int[]{-192,1000,773,-54,186,-43,1000,526,-36,266,-1000,-434,400,391,-1000,958,344,-854,550,225,1000,-688,1000,1000,-712,307,712,1000,-481,484,-1000,805,-353,0,812,-959,-936,-863,-137,913,384,-551,96,775,523,-381,-1000,-766,106,-706,414,-419,-156,-586,-1000,369,1,-1000,-560,-249,-259,-836,-332,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00571() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setLegendItemURLGenerator(org.jfree.chart.labels.CategorySeriesLabelGenerator):void",
            new int[]{-963,1000,-112,626,-1000,165,-875,-358,737,1000,-797,-193,583,1000,1000,-367,-372,-1000,120,-1000,494,239,816,1000,-1000,1000,1000,-856,1000,1000,362,-830,-1000,-1000,1000,-656,-1000,-1000,649,-21,1000,-529,1000,506,428,-41,-1000,-969,175,-127,1000,823,-676,-983,-1000,-1000,-1000,832,-1000,576,-1000,-1000,-616,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00572() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setPlot(org.jfree.chart.plot.CategoryPlot):void",
            new int[]{-606,295,829,57,-1000,-732,-913,903,-140,1000,-950,1000,1000,1000,-1000,-987,919,1000,-441,1000,65,-197,-903,-253,201,-1000,-15,11,557,-259,333,-1000,1000,1000,-749,-777,780,1000,129,-260,888,276,-926,50,1000,90,219,-759,294,-349,-553,1000,631,1000,-95,117,1000,-718,603,782,-1000,684,1000,-944}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00573() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setPlot(org.jfree.chart.plot.CategoryPlot):void",
            new int[]{-139,-1000,784,36,1000,-756,-1000,946,96,1000,-782,1000,798,-654,-1000,-344,-567,1000,1000,-787,539,-149,1000,1000,224,-1000,175,-1000,270,672,-32,-124,-104,-1000,-359,1000,-58,-1000,1000,-471,412,844,-1000,-694,671,1000,63,517,-43,-1000,-725,1000,747,664,-1000,-910,1000,-428,329,694,-486,-1000,-179,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00574() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setPlot(org.jfree.chart.plot.CategoryPlot):void",
            new int[]{-1000,-370,-818,-320,-649,-1000,530,834,-1000,986,-494,334,942,225,-238,420,1000,393,-1000,1000,-778,-509,-975,1000,-216,-506,1000,1000,-1000,-1000,1000,436,-3,1000,-1000,833,-141,-487,-640,1000,-1000,-159,-197,1000,506,989,-22,-108,-776,167,1000,999,246,584,1000,-1000,-1000,-1000,-919,170,666,542,1000,663}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00575() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setPlot(org.jfree.chart.plot.CategoryPlot):void",
            new int[]{257,-214,-273,-300,430,-540,-150,-192,1000,-532,-148,1000,-943,-1000,-203,994,190,298,620,893,99,616,-92,943,93,-22,-1000,-425,1000,708,-894,1000,964,-839,-1000,-1000,860,-721,1000,-923,-1000,-258,1000,-179,-79,591,526,179,3,-992,-451,-207,-163,-1000,-1000,391,800,240,1000,1000,157,-842,-1000,-697}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00576() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setPlot(org.jfree.chart.plot.CategoryPlot):void",
            new int[]{-59,-690,-208,-580,472,-651,352,-231,-417,-75,-189,-1000,167,-1000,1000,836,1000,-1000,-1000,192,-849,1000,154,1000,546,1000,509,-1000,-1000,-1000,-227,1000,1000,-1000,-612,1000,324,-1000,-640,1000,-913,-862,741,1000,-1000,849,240,581,-306,167,1000,-834,-1000,-1000,1000,-1000,-891,-771,114,388,666,-1000,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00577() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setPlot(org.jfree.chart.plot.CategoryPlot):void",
            new int[]{5,902,391,201,-1000,-606,976,313,-923,901,-1000,617,1000,418,-1000,-414,-612,1000,323,319,-425,-75,-1000,-25,1000,-865,760,1000,-869,-889,-835,-342,-1000,-188,-882,-114,-53,499,-368,-141,-520,-302,453,346,494,100,-186,-49,-466,971,1000,626,1000,839,655,-515,864,-183,-593,-752,-531,-131,333,51}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00578() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setPlot(org.jfree.chart.plot.CategoryPlot):void",
            new int[]{-507,-406,-778,-40,-533,-353,937,3,318,353,1000,-595,-794,-502,1000,301,1000,-1000,-1000,-236,153,-15,-172,-980,-686,1000,-715,75,-10,-296,259,130,403,1000,1000,-1000,-297,7,370,1000,1000,-577,-406,620,-1000,38,127,287,-1000,177,145,-1000,41,-369,-63,664,-1000,-518,-124,848,808,747,271,399}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00579() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setPlot(org.jfree.chart.plot.CategoryPlot):void",
            new int[]{-831,-1000,829,57,424,915,-1000,475,238,441,-1000,-544,122,-1000,130,-95,919,-1000,-441,-860,-766,1000,1000,97,422,1000,-248,-1000,192,-372,-497,1000,1000,359,39,1000,780,-1000,-483,947,49,-517,242,708,-1000,874,461,-152,280,-464,684,-1000,-1000,-1000,334,-357,-230,-1000,462,641,-133,-1000,-273,-31}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00580() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setPlot(org.jfree.chart.plot.CategoryPlot):void",
            new int[]{273,843,-452,-790,-12,-1000,-4,-728,447,-883,721,535,-225,-51,-944,550,-1000,70,1000,663,-1000,-480,-549,-289,398,1000,160,335,-138,869,519,-416,-505,-1000,-809,425,363,-532,-818,-861,-466,-537,1000,-957,528,399,-420,390,-175,233,190,457,-585,-438,18,-106,1000,337,37,439,-490,375,-315,127}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00581() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setPlot(org.jfree.chart.plot.CategoryPlot):void",
            new int[]{225,-199,-921,-1000,686,59,-295,-1000,441,-220,1000,269,971,-875,633,1000,-459,-164,-621,78,352,-410,209,578,1000,-106,-894,416,-27,529,-943,1000,-43,-402,-1000,-1000,312,-1000,-264,698,-776,-105,941,-375,-780,848,626,993,-1000,-1000,338,490,-670,-35,-2,-495,27,-917,-355,746,-224,-1000,-1000,339}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00582() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setPlot(org.jfree.chart.plot.CategoryPlot):void",
            new int[]{-1000,-1000,296,136,-48,-1000,-1000,853,-1000,1000,-1000,864,1000,223,-949,-411,-59,1000,-655,347,-274,613,-234,539,-168,-1000,1000,294,-373,-1000,400,411,-251,391,-778,1000,15,617,915,748,-220,6,-437,1000,332,1000,195,-287,181,-254,1000,777,1000,1000,480,-753,576,-1000,-631,579,-961,-339,448,-107}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00583() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setPlot(org.jfree.chart.plot.CategoryPlot):void",
            new int[]{22,902,-951,-730,-139,-415,561,-521,122,1000,124,449,1000,-244,-1000,-414,-548,-121,-13,-88,982,-629,327,555,1000,-377,-574,-255,764,716,-1000,374,-67,52,-882,630,166,-218,691,-155,216,-1000,1000,-548,60,100,-655,911,365,-1000,73,626,1000,-66,37,1000,954,-1000,283,735,-1000,-612,-576,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00584() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setPlot(org.jfree.chart.plot.CategoryPlot):void",
            new int[]{-351,856,99,-668,-1000,-162,-419,-459,101,146,298,488,14,845,143,-46,996,185,-1000,1000,-66,-774,-1000,-549,745,-374,-764,1000,349,-359,-304,-213,1000,1000,-1000,-1000,1000,1000,-755,-984,57,-389,432,-345,-16,-16,613,-426,-376,-349,191,643,-769,511,603,407,319,-1000,124,818,372,684,425,-6}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00585() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesItemLabelGenerator(int,org.jfree.chart.labels.CategoryItemLabelGenerator):void",
            new int[]{1000,644,-913,-328,-301,643,820,299,-1000,-720,1000,-1000,1000,-355,1000,-1000,1000,-427,1000,807,278,1000,-124,-770,-203,-1000,1000,-359,-140,827,333,-764,934,1000,1000,1000,1000,-300,-842,877,-1000,-438,749,401,-1000,1000,-507,185,-1000,-879,317,-390,-1000,990,-977,-37,1000,1000,89,-501,-1000,-1000,1000,-927}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00586() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesItemLabelGenerator(int,org.jfree.chart.labels.CategoryItemLabelGenerator):void",
            new int[]{270,132,-231,582,58,482,-78,32,-803,-795,1000,-630,-406,52,349,626,895,284,284,294,91,302,201,99,256,-911,378,-43,-66,1,127,517,-191,530,149,546,111,648,52,401,-600,-222,-103,265,18,-418,263,143,-1000,-567,-475,771,-953,-725,-1000,519,201,-1000,21,32,46,113,1000,-876}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00587() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesItemLabelGenerator(int,org.jfree.chart.labels.CategoryItemLabelGenerator):void",
            new int[]{1000,-10,994,389,1000,-121,-606,-449,806,-277,-283,1000,-373,-1000,60,1000,-707,1000,-1000,726,-1000,-163,993,176,-1000,1000,-1000,539,1000,-28,1000,1000,-1000,-1000,-76,-423,704,1000,-580,-1000,1000,1000,-964,374,-772,-519,801,1000,90,-1000,-326,704,-250,779,940,-1000,231,-814,-113,861,1000,63,-284,-291}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00588() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesItemLabelGenerator(int,org.jfree.chart.labels.CategoryItemLabelGenerator):void",
            new int[]{-211,-704,-106,-106,309,-1000,-872,346,-626,-527,1000,-510,-221,163,-36,1000,108,-837,-684,-24,-139,-1000,626,-440,439,-130,413,1000,1000,340,1000,-18,-824,682,642,-683,-218,-170,-1000,188,-631,-654,813,-1000,-349,-1000,250,802,462,-669,139,1000,384,1000,-683,912,-810,537,-585,433,-815,-55,-1000,-387}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00589() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesItemLabelGenerator(int,org.jfree.chart.labels.CategoryItemLabelGenerator):void",
            new int[]{271,-1000,-601,-37,485,-701,-1000,-263,131,282,-626,778,-305,-393,-370,1000,576,1000,-291,-521,-104,1000,-97,-469,-419,18,-1000,367,-539,-156,-67,916,-369,-1000,-1000,-1000,376,1000,1000,-411,1000,132,20,-986,447,-4,-94,-1,-1000,-784,-877,469,145,-186,-146,-912,-665,-805,-1000,1000,559,414,-367,-757}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00590() {
        org.junit.Assert.assertEquals("THROW:java.lang.NegativeArraySizeException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesItemLabelGenerator(int,org.jfree.chart.labels.CategoryItemLabelGenerator):void",
            new int[]{-691,1000,414,1000,392,1000,-760,-1000,968,713,-401,321,-1000,202,-73,1000,313,418,269,40,-1000,928,-56,-84,-1000,386,-539,45,-202,-159,942,1000,713,-1000,-427,1000,-688,1000,733,282,1000,-63,-1000,850,1000,-1000,867,432,-274,-431,-1000,-172,-715,1000,-977,-383,614,-309,664,1000,1000,-91,730,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00591() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesItemLabelGenerator(int,org.jfree.chart.labels.CategoryItemLabelGenerator):void",
            new int[]{1000,-257,-877,251,-427,114,-95,1000,-1000,-809,1000,-1000,854,-355,1000,-774,1000,-148,1000,1000,497,302,-661,-594,1000,-1000,711,410,-803,457,-364,-730,69,851,1000,260,833,-300,-249,1000,-698,385,990,-235,-1000,982,-601,-319,-846,-1000,621,-10,-930,-1000,-994,1000,322,-254,-645,-455,-1000,-461,722,-655}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00592() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesItemLabelGenerator(int,org.jfree.chart.labels.CategoryItemLabelGenerator):void",
            new int[]{-204,-733,-6,944,171,-790,-1000,190,400,103,-400,202,-147,-382,-400,626,666,48,102,1000,516,302,-215,1000,442,201,378,385,-741,-224,10,504,-637,-92,-400,-383,449,158,1000,-314,275,829,-234,-411,13,90,317,-103,-638,-524,-189,787,-404,-993,140,326,-226,-1000,-687,595,396,353,1000,-489}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00593() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesItemLabelGenerator(int,org.jfree.chart.labels.CategoryItemLabelGenerator):void",
            new int[]{419,3,-727,322,-582,-452,-896,-40,-490,-32,893,-978,-562,899,208,-186,720,-837,660,129,205,-656,-578,-84,439,-534,683,506,-311,204,942,-18,402,739,762,-7,-212,-313,-689,691,-727,-654,834,-726,629,-52,50,109,-274,-468,395,401,73,623,-977,912,-438,989,-481,401,-815,381,-603,-884}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00594() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesItemLabelGenerator(int,org.jfree.chart.labels.CategoryItemLabelGenerator):void",
            new int[]{-1000,510,-318,1000,-576,146,10,-237,43,-109,954,-243,-320,970,-59,1000,359,1000,1000,62,-121,-544,-592,359,714,-326,-396,-392,101,4,64,83,377,-760,81,903,-151,-230,1000,-669,-954,158,220,237,1000,-216,1000,-216,-108,-118,-1000,220,-161,-501,311,-206,-510,108,415,672,151,831,154,-426}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00595() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesItemLabelGenerator(int,org.jfree.chart.labels.CategoryItemLabelGenerator):void",
            new int[]{-1000,-36,-186,13,-42,-557,-71,-68,64,65,-309,432,392,-393,-787,276,848,-222,-283,267,361,1000,890,-307,1000,370,1000,-934,413,871,755,626,-450,1000,1000,520,-277,256,448,-914,-3,-112,-962,149,-533,496,598,628,-630,-129,230,-496,-1000,-1000,-1000,-495,784,-1000,542,334,-32,-128,957,-489}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00596() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesItemLabelGenerator(int,org.jfree.chart.labels.CategoryItemLabelGenerator):void",
            new int[]{-780,302,-536,379,-1000,-7,-872,-47,-805,-76,1000,-922,601,1000,621,-2,750,-1000,742,429,914,-1000,-849,463,1000,-130,517,433,-518,-217,336,-524,637,1000,1000,-30,-779,-1000,-636,-233,-631,-332,276,-1000,-355,-81,-328,289,1000,77,-271,1000,-441,716,-877,1000,-411,-85,181,451,-1000,-55,-49,-408}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00597() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesItemLabelGenerator(int,org.jfree.chart.labels.CategoryItemLabelGenerator):void",
            new int[]{329,190,-191,632,-169,1000,-230,157,-1000,-1000,1000,-557,-813,6,359,1000,1000,1000,-491,1000,133,97,359,-950,-577,-286,317,-89,91,-233,585,1000,-656,598,690,159,-232,1000,-197,225,-232,1000,-186,-273,-140,-755,38,291,-880,-86,-1000,1000,-1000,-1000,-1000,504,6,-1000,-71,-887,-595,682,1000,-885}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00598() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesItemLabelGenerator(int,org.jfree.chart.labels.CategoryItemLabelGenerator):void",
            new int[]{-720,-209,774,565,-967,-485,-353,156,-265,211,-102,-419,429,58,-342,-242,1000,-951,1000,56,1000,1000,-645,392,400,-684,1000,-486,-1000,193,-88,-211,673,1000,-247,560,-40,-555,1000,649,-798,-234,368,-276,287,776,-177,-429,-1000,-199,-177,453,-725,-245,-711,400,281,-367,-344,78,-406,209,338,-966}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00599() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesItemLabelGenerator(int,org.jfree.chart.labels.CategoryItemLabelGenerator,boolean):void",
            new int[]{430,-1000,829,-721,-177,866,233,-692,-106,-105,-10,-373,385,-43,-518,564,-620,1000,1000,607,-435,-1000,471,659,586,-813,119,-1000,-1000,-55,592,-894,-951,-511,-361,-172,-242,-494,-578,352,106,-496,-18,18,-1000,842,868,-36,-577,90,35,945,851,497,110,601,-526,-482,-739,-647,178,-491,-86,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00600() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesItemLabelGenerator(int,org.jfree.chart.labels.CategoryItemLabelGenerator,boolean):void",
            new int[]{-955,-524,-311,-270,940,-726,-384,-733,6,-127,631,267,660,-382,1000,904,-1000,202,-1000,-572,254,568,-637,221,-239,-5,1000,-725,1000,0,395,400,914,679,-469,1000,882,165,1000,331,-640,-60,-132,-656,-150,698,-1000,-398,323,-500,1000,-208,873,-822,-88,219,1000,-580,-269,-654,-474,248,-468,584}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00601() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesItemLabelGenerator(int,org.jfree.chart.labels.CategoryItemLabelGenerator,boolean):void",
            new int[]{-332,-733,-136,771,316,260,-131,-350,152,525,-77,169,-140,-403,653,532,-432,1000,-54,241,0,-561,-801,-221,-699,-1000,483,-597,778,-95,-701,-465,379,-256,-655,-371,-1000,-368,-1000,-68,-691,-61,201,71,228,280,-1000,152,-449,-27,1000,272,554,638,-881,-1000,485,-599,-16,-615,228,-779,-272,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00602() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesItemLabelGenerator(int,org.jfree.chart.labels.CategoryItemLabelGenerator,boolean):void",
            new int[]{-673,-374,516,384,799,-678,38,-470,-326,868,-30,-184,430,-136,-183,415,7,-974,-787,312,192,184,-561,-670,556,-121,418,-591,81,-506,-913,-195,605,-606,-746,915,-740,721,-550,-858,190,133,-384,-594,10,55,-38,709,709,-186,-173,-524,-17,-577,967,-646,360,-314,327,567,903,-169,60,993}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00603() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesItemLabelGenerator(int,org.jfree.chart.labels.CategoryItemLabelGenerator,boolean):void",
            new int[]{-974,-273,-226,1000,-231,-995,-987,-410,-532,1000,-851,159,-99,-272,939,-67,-1000,-832,-1000,237,151,577,-1000,-1000,-269,1000,962,-615,1000,355,-987,545,447,-840,-1,504,-462,237,-685,-1000,-1000,516,1000,-1000,1000,-968,-1000,1000,319,-941,1000,-1000,818,-397,375,-1000,155,-1000,1000,1000,1000,-1000,349,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00604() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesItemLabelGenerator(int,org.jfree.chart.labels.CategoryItemLabelGenerator,boolean):void",
            new int[]{-200,-158,88,1000,-792,-990,-987,-410,-789,1000,-340,-657,-967,475,401,415,-582,-719,272,1000,151,763,-422,-1000,272,1000,184,-493,741,355,-1000,545,1000,-840,-1,545,-1000,16,-952,-222,-191,-535,-183,-1000,303,-968,-1000,972,601,311,69,-1000,1000,1000,375,-1000,315,-159,135,1000,1000,-529,349,-407}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00605() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesItemLabelGenerator(int,org.jfree.chart.labels.CategoryItemLabelGenerator,boolean):void",
            new int[]{-219,197,-133,58,130,640,1000,1000,932,-581,-486,-627,690,-852,-710,-1000,-1000,1000,-799,-780,822,-1000,1000,1000,-267,1000,824,276,-1000,-1000,-932,-448,-1000,809,-1000,-159,1000,354,-935,736,-1000,-251,917,226,478,621,566,963,-1000,123,1000,534,81,1000,64,808,-1000,-1000,-733,917,-1000,-474,4,311}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00606() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesItemLabelGenerator(int,org.jfree.chart.labels.CategoryItemLabelGenerator,boolean):void",
            new int[]{250,-726,723,56,-495,203,589,569,214,-755,-415,-471,748,-516,-852,-857,-917,993,-775,-244,951,-862,937,57,717,712,344,370,-736,-744,-143,-431,-817,446,-916,261,595,-424,243,-451,-956,-134,680,-128,78,543,438,249,-611,-511,406,571,637,613,102,486,-510,-960,-188,-73,-184,-273,-488,325}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00607() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesItemLabelGenerator(int,org.jfree.chart.labels.CategoryItemLabelGenerator,boolean):void",
            new int[]{1000,915,528,-971,-1000,1000,-999,358,-619,903,-934,-508,303,807,-1000,-582,58,0,1000,312,532,-378,1000,-386,67,-325,-1000,400,-1000,-506,946,255,-615,-315,996,-1000,-383,-49,1000,-89,-157,-793,357,-1000,-633,-798,1000,709,179,-20,-1000,-524,-983,79,1000,-646,-1000,166,-107,-313,1000,653,570,-387}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00608() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesItemLabelGenerator(int,org.jfree.chart.labels.CategoryItemLabelGenerator,boolean):void",
            new int[]{-631,-562,-257,-571,1000,-716,-500,372,626,442,291,858,-420,-384,1000,971,-895,936,-482,-482,-452,720,471,718,-267,-877,670,-1000,321,-417,-932,-448,1000,-953,-53,941,555,-206,-935,736,217,683,-759,263,-135,203,-693,-803,374,428,1000,612,81,-623,-790,236,648,-1000,-916,-688,-521,138,4,757}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00609() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesItemLabelGenerator(int,org.jfree.chart.labels.CategoryItemLabelGenerator,boolean):void",
            new int[]{-485,-359,-338,-249,585,295,-126,19,791,-508,358,398,-1,-604,993,1000,-366,1000,-114,-345,-837,-509,-447,1000,-786,-1000,821,-1000,327,-102,1000,-776,-357,-561,-701,71,122,-533,-741,911,-226,179,-472,1000,-174,768,43,-1000,-694,316,1000,1000,1000,1000,-1000,752,793,-636,-1000,-1000,-1000,-858,-408,415}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00610() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesItemLabelGenerator(int,org.jfree.chart.labels.CategoryItemLabelGenerator,boolean):void",
            new int[]{-1000,102,-4,-329,887,-839,1000,102,1000,-698,719,-80,1000,-1000,365,-428,-1000,336,-1000,-1000,211,960,344,1000,61,1000,1000,-689,-1000,-1000,811,1000,-858,1000,-432,391,1000,1000,573,1000,363,1000,263,509,-388,670,1000,630,-953,-690,1000,825,1000,676,-188,1000,-529,-1000,-176,-155,-1000,1000,-852,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00611() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesItemLabelGenerator(int,org.jfree.chart.labels.CategoryItemLabelGenerator,boolean):void",
            new int[]{-868,-158,476,-420,521,606,870,-392,-789,-875,-340,-41,1000,-853,459,874,-432,-719,272,95,-940,-1000,-1000,704,-55,-879,947,-493,-421,-703,286,-974,127,-331,-111,239,20,553,45,-51,512,328,-758,1000,-641,210,79,-676,-534,114,824,-1000,1000,1000,-881,400,746,-159,-559,-946,-866,198,349,704}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00612() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesItemLabelGenerator(int,org.jfree.chart.labels.CategoryItemLabelGenerator,boolean):void",
            new int[]{1000,-297,733,-504,-37,847,186,22,264,-1000,112,-221,221,329,-694,157,50,154,1000,504,-1000,-631,957,1000,618,-1000,-564,-1000,-1000,685,1000,-57,255,-87,624,-113,-379,-720,507,1000,674,-633,-449,350,-1000,841,-1000,-1000,-760,155,-544,1000,163,200,-699,912,-1000,438,-1000,755,-910,-132,-37,295}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00613() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesItemLabelGenerator(int,org.jfree.chart.labels.CategoryItemLabelGenerator,boolean):void",
            new int[]{-271,-255,-319,-329,1000,-839,-693,102,665,331,110,1000,-1000,-57,609,980,115,955,-1000,-545,1000,1000,721,803,-185,-1000,377,-902,1000,-592,-1000,134,168,-1000,-1000,1000,-154,-159,-1000,1000,-168,-266,-831,484,-182,773,-356,-862,-953,1000,1000,728,-538,-906,-853,248,389,-948,-176,-633,-1000,190,-806,702}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00614() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesToolTipGenerator(int,org.jfree.chart.labels.CategoryToolTipGenerator):void",
            new int[]{125,-1000,318,-105,-604,1000,-819,-114,851,-202,-733,-509,-5,-744,-705,-515,338,1000,-1000,886,1000,-1000,-271,824,1000,-1000,434,438,143,-192,-555,-654,518,-9,127,172,-694,920,-572,938,165,421,-229,1000,361,-72,473,994,1000,587,-570,31,499,836,-60,791,1000,-296,-1000,-441,772,775,-147,727}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00615() {
        org.junit.Assert.assertEquals("THROW:java.lang.NegativeArraySizeException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesToolTipGenerator(int,org.jfree.chart.labels.CategoryToolTipGenerator):void",
            new int[]{-319,458,-131,751,-257,343,223,-760,470,1000,-454,-802,-1000,-522,-1000,19,-541,-271,1000,-544,422,-749,630,684,-649,-1000,225,-7,1000,274,-331,-505,322,-614,643,-280,-554,-182,-848,1000,749,97,228,-157,429,-532,371,931,1000,267,-292,778,-312,47,-2,-10,-310,-308,-577,-1000,-443,-432,-878,138}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00616() {
        org.junit.Assert.assertEquals("THROW:java.lang.NegativeArraySizeException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesToolTipGenerator(int,org.jfree.chart.labels.CategoryToolTipGenerator):void",
            new int[]{-1000,-58,854,626,-602,418,-1000,-701,1000,-861,417,-809,-809,-556,70,-477,948,-1000,-856,111,612,-400,149,862,1000,-76,1000,723,891,572,-1000,-1000,259,815,621,-143,864,1000,-1000,-1000,1000,466,337,-511,-956,99,877,1000,-574,1000,35,973,768,161,1000,211,-84,308,178,337,1000,257,1000,406}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00617() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesToolTipGenerator(int,org.jfree.chart.labels.CategoryToolTipGenerator):void",
            new int[]{-98,236,-53,417,-349,-677,-1000,-1000,18,289,711,1000,904,196,733,277,1000,-640,-102,-931,-494,-895,-1000,595,343,-800,794,-224,-2,-287,-227,810,-137,1000,800,-22,898,118,-944,-931,654,-952,-223,-859,-596,-42,533,330,-1000,-4,-697,-1000,948,-701,648,358,1000,301,1000,1000,865,885,1000,415}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00618() {
        org.junit.Assert.assertEquals("THROW:java.lang.NegativeArraySizeException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesToolTipGenerator(int,org.jfree.chart.labels.CategoryToolTipGenerator):void",
            new int[]{772,226,49,1000,-326,-576,-398,-162,1000,-241,-772,-981,-723,-302,-518,-1000,-299,-1000,901,1000,-865,-1000,-1000,-851,1000,786,-1000,1000,1000,585,-747,-24,1000,995,603,326,-663,762,377,49,-414,209,1000,-1000,11,107,434,1000,352,-253,-265,1000,422,120,651,717,1000,200,-816,732,-346,783,283,-703}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00619() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesToolTipGenerator(int,org.jfree.chart.labels.CategoryToolTipGenerator):void",
            new int[]{-1000,449,-71,464,115,-1000,-645,-1000,51,332,-145,1000,770,-164,481,825,963,-1000,105,-1000,-467,-749,-663,1000,-409,-1000,593,-242,-28,-83,-552,451,-92,733,1000,-352,912,-182,-1000,-829,1000,-1000,-631,-921,-148,-332,737,617,-328,377,-926,-1000,602,-1000,1000,-347,841,-45,998,895,1000,403,671,907}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00620() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesToolTipGenerator(int,org.jfree.chart.labels.CategoryToolTipGenerator):void",
            new int[]{1000,-503,344,388,-1000,682,-994,-807,688,1000,-1000,-1000,-1000,-588,-1000,-1000,-1000,1000,1000,1000,491,-1000,242,927,-25,-1000,-657,1000,473,362,589,-1000,1000,293,-183,1000,-830,578,32,1000,508,378,734,1000,32,-1000,1000,1000,1000,-689,168,1000,1000,1000,678,1000,198,-2,-877,-1000,-264,877,-899,93}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00621() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesToolTipGenerator(int,org.jfree.chart.labels.CategoryToolTipGenerator):void",
            new int[]{-579,304,-236,533,570,-289,-1000,104,1000,199,118,1000,-83,-245,13,-1,258,-1000,939,-417,-1000,1000,-1000,-63,508,265,-897,-142,1000,-628,-1000,-915,1000,1000,481,25,-338,-182,-97,-313,1000,-636,480,-1000,298,400,206,1000,-550,393,-964,-1000,253,-1000,202,-141,1000,-874,-745,213,1000,644,1000,933}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00622() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesToolTipGenerator(int,org.jfree.chart.labels.CategoryToolTipGenerator):void",
            new int[]{567,-503,73,-220,460,-881,-1000,173,1000,-259,-500,1000,-240,-719,-432,480,-295,-179,302,331,-559,1000,-1000,217,-194,-449,-657,-511,1000,-1000,-564,-82,667,1000,-856,-490,-830,578,-195,678,826,-836,-364,1000,1000,-151,277,1000,961,407,-766,-1000,-576,-957,285,-325,1000,-1000,-877,-263,395,-1000,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00623() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesToolTipGenerator(int,org.jfree.chart.labels.CategoryToolTipGenerator):void",
            new int[]{1000,960,524,1000,-925,1000,252,-1000,565,772,150,-33,-780,-402,-283,-1000,602,-33,295,598,-536,-1000,68,-44,1000,296,1000,466,925,-48,443,-939,420,37,534,245,522,1000,-816,-388,394,610,237,-1000,-1000,120,47,516,-1000,269,-195,1000,1000,354,375,1000,543,912,233,-850,-1000,896,-60,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00624() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesToolTipGenerator(int,org.jfree.chart.labels.CategoryToolTipGenerator):void",
            new int[]{-523,-221,-602,223,-832,472,-270,-875,705,945,425,1000,188,-499,-68,-318,385,-283,-162,238,528,-1000,430,981,1000,-1000,1000,-742,291,-637,24,652,-688,-114,837,-5,372,-1000,-1000,156,864,-218,-845,-489,745,-1000,271,528,59,34,-266,92,393,-267,299,-340,174,-36,-86,-212,62,939,-54,-945}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00625() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesToolTipGenerator(int,org.jfree.chart.labels.CategoryToolTipGenerator):void",
            new int[]{-55,-116,-386,1000,459,286,527,-324,-135,142,58,-1000,988,-975,1000,325,1000,-730,-858,199,-439,-1000,-1000,-1000,-788,1000,-826,591,409,1000,392,-287,-436,626,179,1000,-664,-505,1000,-27,-1000,-360,-142,-141,-1000,758,-317,366,266,-389,-289,577,38,-254,-1000,-963,1000,-270,-803,781,-944,-271,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00626() {
        org.junit.Assert.assertEquals("THROW:java.lang.NegativeArraySizeException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesToolTipGenerator(int,org.jfree.chart.labels.CategoryToolTipGenerator):void",
            new int[]{-1000,359,-441,-220,-315,-243,-827,733,621,-258,1000,1000,425,-224,365,748,925,-53,-1000,-103,-559,1000,7,1000,232,-400,255,-1000,56,-544,-564,-309,-280,618,1000,-1000,739,511,-1000,-1000,1000,-904,-560,-1000,-314,-1000,-189,53,400,787,-246,-851,-195,-1000,167,-623,374,-111,-505,1000,520,-133,1000,884}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00627() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesToolTipGenerator(int,org.jfree.chart.labels.CategoryToolTipGenerator,boolean):void",
            new int[]{-202,-1000,469,849,-16,-1000,95,-684,1000,-595,211,-1000,496,-179,-192,-313,6,-484,-171,-534,371,-587,-127,58,184,69,1000,-641,-228,-453,275,-222,-962,-466,-107,21,538,-65,211,-513,-15,350,140,1000,1000,-233,924,930,350,320,-79,-968,-6,60,-941,593,283,19,352,872,-23,-485,-260,756}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00628() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesToolTipGenerator(int,org.jfree.chart.labels.CategoryToolTipGenerator,boolean):void",
            new int[]{822,728,538,421,-834,-857,-391,418,-919,-671,75,-51,71,336,214,2,-1000,1000,-561,-215,-1000,-737,-67,-1000,-609,698,166,988,1000,-1000,-1000,1000,-511,-1000,1000,1000,-84,-381,-1000,-29,-1000,-412,-1000,-1000,1000,-1000,-419,-271,1000,423,-1000,1000,-728,342,1000,-65,387,1000,-1000,-440,26,-587,-1000,-728}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00629() {
        org.junit.Assert.assertEquals("THROW:java.lang.NegativeArraySizeException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesToolTipGenerator(int,org.jfree.chart.labels.CategoryToolTipGenerator,boolean):void",
            new int[]{-435,-1000,843,532,1000,-1000,-251,-1000,1000,691,-244,-1000,1000,-484,-837,-160,812,-1000,240,-100,386,-607,-1000,301,241,-190,1000,-1000,-1000,-1000,1000,1000,-160,-523,225,-947,-84,-437,1000,-1000,694,1000,703,1000,252,1000,1000,1000,-96,-370,501,-1000,1000,342,-1000,1000,-245,-269,0,-440,-662,-527,593,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00630() {
        org.junit.Assert.assertEquals("THROW:java.lang.NegativeArraySizeException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesToolTipGenerator(int,org.jfree.chart.labels.CategoryToolTipGenerator,boolean):void",
            new int[]{-344,-1000,-513,558,-834,-1000,-4,-670,1000,844,291,-748,479,-412,136,-158,489,1000,279,-631,875,-492,-221,722,573,176,1000,-892,1000,-1000,347,-32,-674,764,-19,374,580,-381,635,-553,462,-412,787,1000,990,-806,837,892,-105,161,460,-248,293,26,-1000,1000,522,-462,1000,-440,-1000,-793,223,879}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00631() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesToolTipGenerator(int,org.jfree.chart.labels.CategoryToolTipGenerator,boolean):void",
            new int[]{-633,-1000,522,1000,52,-909,-421,-1000,311,871,798,-1000,965,-1000,298,83,-156,-787,93,-980,1000,-936,-657,455,-641,-113,580,-1000,574,-1000,-1000,-523,355,897,-995,1000,1000,-386,393,-1000,-194,309,229,804,1000,-17,1000,1000,714,124,-264,-431,976,221,483,736,-650,-1000,603,1000,-429,-882,-301,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00632() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesToolTipGenerator(int,org.jfree.chart.labels.CategoryToolTipGenerator,boolean):void",
            new int[]{450,148,614,-783,-995,-17,-754,32,-888,139,675,225,710,-769,371,-940,749,-391,-257,-357,103,-371,-634,5,1000,-764,-245,-205,-10,346,196,622,257,-599,1000,-1000,370,766,797,815,-306,-892,1000,305,289,-95,51,-984,360,-703,626,447,-748,-164,-669,957,192,-759,352,1000,244,945,-158,199}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00633() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesToolTipGenerator(int,org.jfree.chart.labels.CategoryToolTipGenerator,boolean):void",
            new int[]{-249,-976,-346,-104,-1000,-738,-105,-1000,-1000,-983,576,-844,89,-794,125,-459,6,-584,-1000,-675,796,-987,379,-45,323,-1000,-374,-1000,1000,-1000,-1000,20,1000,1000,580,125,429,1000,-969,-178,-991,-1000,-637,20,967,440,1000,179,647,286,-395,1000,115,889,-255,1000,1000,-139,60,748,-1000,534,-216,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00634() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesToolTipGenerator(int,org.jfree.chart.labels.CategoryToolTipGenerator,boolean):void",
            new int[]{-387,-444,388,375,-9,-311,668,-721,-133,-758,277,-648,379,-56,-733,-805,-753,-11,479,603,296,984,-671,-227,-893,135,-707,996,260,-83,679,-380,460,-793,-491,-623,-36,-662,821,365,126,-129,592,-69,-338,2,578,-476,261,495,866,143,-436,-239,-298,-528,176,288,-770,986,-570,24,-791,-636}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00635() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesToolTipGenerator(int,org.jfree.chart.labels.CategoryToolTipGenerator,boolean):void",
            new int[]{1000,-112,707,763,-554,-1000,-57,-850,-133,75,1000,-1000,801,349,906,240,-1000,48,-967,-671,-640,-1000,-153,-1000,-456,233,573,-342,750,-1000,-151,706,-282,1000,1000,1000,-57,-775,135,-909,-918,-201,-861,-1000,300,-411,765,243,1000,292,-1000,109,-236,319,629,956,-41,318,-341,321,-932,-821,-1000,802}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00636() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesToolTipGenerator(int,org.jfree.chart.labels.CategoryToolTipGenerator,boolean):void",
            new int[]{1000,167,469,-109,-933,-950,319,-377,-1000,-1000,616,257,611,410,-316,1000,-1000,-484,-171,-614,-397,-301,-127,-1000,-349,69,1000,281,-485,-464,275,511,-149,1000,382,833,-1000,-705,-974,8,-506,-635,-1000,-871,1000,-1000,-220,-409,917,1000,-1000,-968,-762,1000,886,-354,-326,1000,-1000,-1000,-20,-524,86,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00637() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesToolTipGenerator(int,org.jfree.chart.labels.CategoryToolTipGenerator,boolean):void",
            new int[]{1000,-506,-852,-532,-1000,-1000,400,-636,-212,-1000,501,-194,1000,-665,-55,610,-1000,1000,-583,-702,-900,-1,439,-1000,644,510,619,671,-541,-364,-573,-925,-758,1000,-1000,1000,-170,-1000,-1000,13,-322,48,-1000,-705,1000,-1000,-647,-287,935,1000,-1000,1000,-766,645,-352,582,852,1000,294,-205,628,-401,-982,609}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00638() {
        org.junit.Assert.assertEquals("THROW:java.lang.NegativeArraySizeException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesToolTipGenerator(int,org.jfree.chart.labels.CategoryToolTipGenerator,boolean):void",
            new int[]{-259,-1000,471,-167,-676,-1000,-247,-745,-322,550,75,-436,615,-843,-167,-800,744,-946,-349,-701,1000,-448,25,713,498,-832,273,-857,1000,225,60,-793,157,-429,-120,1000,775,423,57,-169,-69,-30,503,1000,522,904,743,57,267,423,610,-228,130,342,-546,628,542,1000,652,-440,-468,560,-206,726}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00639() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesToolTipGenerator(int,org.jfree.chart.labels.CategoryToolTipGenerator,boolean):void",
            new int[]{384,465,469,547,-300,231,-384,430,-166,-7,-32,-103,9,545,552,230,-513,698,-329,-534,-494,-300,52,-278,103,522,437,597,300,-291,-619,1000,408,-466,1000,688,42,-317,-149,-12,-300,-409,-525,-790,341,51,-276,-391,300,30,-565,315,-102,60,485,603,-304,110,-169,141,-559,-572,-204,-136}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00640() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesURLGenerator(int,org.jfree.chart.urls.CategoryURLGenerator):void",
            new int[]{-575,11,-428,866,1000,-242,-44,955,496,-1000,1000,252,-509,564,640,116,-1000,1000,379,-1000,298,1000,-70,961,-814,243,167,-666,450,-587,-1000,-850,706,1000,-766,-636,-433,60,-1000,-335,-1000,686,623,189,-394,261,-268,-1000,-1000,-383,1000,267,-499,-956,-612,-1000,168,1000,480,-1000,217,1000,-148,-771}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00641() {
        org.junit.Assert.assertEquals("THROW:java.lang.NegativeArraySizeException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesURLGenerator(int,org.jfree.chart.urls.CategoryURLGenerator):void",
            new int[]{-1000,293,-86,808,1000,918,-448,1000,883,1000,1000,-360,-604,590,475,368,-1000,908,-116,-1000,-617,956,-400,1000,-734,-54,-112,-357,186,-1000,-1000,1000,858,833,-506,117,241,-90,-1000,825,-836,575,358,299,-992,1000,-635,-1000,-1000,-382,1000,477,-448,-212,-511,-128,671,648,1000,-1000,-131,1000,375,-674}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00642() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesURLGenerator(int,org.jfree.chart.urls.CategoryURLGenerator):void",
            new int[]{-962,88,119,645,-157,946,-148,875,274,221,-312,584,-151,262,139,811,-139,-428,-384,-192,-617,218,-949,571,-407,-50,-12,259,-238,400,400,-131,805,-415,859,407,1000,668,400,1000,449,-8,424,333,-662,1000,-11,576,95,-648,-400,350,566,372,-981,648,474,-305,584,400,-739,-400,-415,477}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00643() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesURLGenerator(int,org.jfree.chart.urls.CategoryURLGenerator):void",
            new int[]{-618,-162,-391,693,1000,240,-77,-133,304,379,912,-1000,49,426,-3,-432,-230,1000,907,-1000,400,1000,572,1000,-85,-324,-834,-356,-214,-1000,-1000,681,-26,782,-1000,291,-1000,-83,-1000,-1000,-847,103,191,-937,492,-1000,-131,-1000,-858,-531,1000,212,-1000,-811,182,-1000,163,446,504,-1000,1000,1000,593,371}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00644() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesURLGenerator(int,org.jfree.chart.urls.CategoryURLGenerator):void",
            new int[]{669,-76,-46,108,471,831,32,433,588,963,420,800,668,642,-552,-674,-285,-879,188,261,-243,-591,295,57,280,748,253,371,425,-904,-482,-965,-336,-826,439,164,-826,-846,974,-32,-554,918,-786,-385,818,946,-489,538,541,-608,-384,930,769,-380,644,873,431,-356,904,-458,322,226,697,-787}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00645() {
        org.junit.Assert.assertEquals("THROW:java.lang.NegativeArraySizeException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesURLGenerator(int,org.jfree.chart.urls.CategoryURLGenerator):void",
            new int[]{-991,0,878,-966,-1000,894,-1000,-1000,-552,-703,408,-1000,982,504,-1000,-1000,-1000,1000,170,-79,342,-695,489,275,539,-1000,-1000,451,918,-351,-1000,-185,-903,144,1000,1000,1000,1000,-1000,707,-1000,-1000,-717,-941,880,-1000,-415,-353,1000,-471,1000,-1000,-1000,-971,9,507,-49,1000,643,-188,1000,-1000,344,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00646() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesURLGenerator(int,org.jfree.chart.urls.CategoryURLGenerator):void",
            new int[]{-1000,-1000,214,-326,-833,881,-594,-1000,-414,-657,-26,-1000,-305,-29,-1000,-607,-1000,1000,359,-515,557,-156,-1000,1000,526,-1000,-1000,-1000,991,35,-1000,-354,-177,574,780,1000,-852,1000,-1000,617,-1000,407,-151,-1000,-711,-1000,99,-345,1000,-622,1000,-1000,-1000,-958,-448,-1000,17,828,352,-277,1000,-561,-17,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00647() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesURLGenerator(int,org.jfree.chart.urls.CategoryURLGenerator):void",
            new int[]{-63,959,672,-186,1000,162,-817,743,973,1000,755,-1000,-78,942,-329,547,-1000,1000,-408,-1000,20,197,350,105,-529,-810,-743,11,-667,-1000,-707,826,202,659,-1000,-320,-1000,-1000,-1000,-394,-1000,-50,1000,-548,-449,-724,-1000,-1000,-241,-448,417,111,-1000,821,433,-267,242,1000,-391,-585,284,416,679,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00648() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesURLGenerator(int,org.jfree.chart.urls.CategoryURLGenerator):void",
            new int[]{-335,293,153,627,652,961,-260,1000,189,1000,1000,-360,336,-4,-96,368,-230,908,-116,-1000,-1000,848,1000,1000,-1000,-441,-112,-357,207,-1000,-1000,832,254,782,-951,-396,-734,-83,-1000,-290,-836,-166,327,-1000,408,-948,-691,-1000,-564,-323,1000,477,-448,-212,457,-128,480,648,-17,-1000,-131,1000,128,-894}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00649() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesURLGenerator(int,org.jfree.chart.urls.CategoryURLGenerator):void",
            new int[]{-476,-981,-691,522,1000,546,-579,-539,419,-437,-497,-542,-305,-653,311,-729,-108,238,1000,797,557,-299,-448,458,475,1000,8,-980,-197,496,-1000,-474,305,574,780,575,-443,106,301,-85,-1000,-185,-151,-704,333,690,2,-345,162,-1000,871,156,-202,-724,-741,124,93,-171,601,-277,921,280,-193,-98}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00650() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesURLGenerator(int,org.jfree.chart.urls.CategoryURLGenerator):void",
            new int[]{899,291,-992,560,567,332,909,332,164,-518,760,-217,877,39,576,97,401,-920,-239,623,-789,303,-698,-193,-558,125,530,114,-709,551,382,643,556,-474,411,237,-558,3,1000,338,-920,-190,-821,571,339,-457,259,-884,-531,-825,82,262,852,-154,125,-749,739,-609,-103,-495,-796,559,135,-377}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00651() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesURLGenerator(int,org.jfree.chart.urls.CategoryURLGenerator):void",
            new int[]{-1000,-1000,-409,203,281,488,501,-749,233,-764,437,-1000,134,631,-846,250,-1000,1000,-51,-629,1000,445,-1000,1000,258,-1000,-1000,-1000,228,33,-1000,974,405,1000,-1000,1000,-1000,-229,-1000,-91,-1000,-1000,-342,-1000,-711,-1000,-107,-1000,139,-949,1000,-580,-1000,-1000,-689,-1000,818,828,-300,-927,1000,-33,918,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00652() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesURLGenerator(int,org.jfree.chart.urls.CategoryURLGenerator):void",
            new int[]{-700,-1000,-602,458,-214,-504,379,-769,42,-1000,256,-124,-484,521,706,-495,-255,1000,1000,-115,1000,240,-989,81,364,601,-293,-522,-151,737,-697,-1000,-13,400,-180,-145,-503,360,752,22,39,180,157,-168,24,276,220,-720,223,-593,836,-591,-554,-1000,-1000,-501,-836,142,900,88,1000,-155,-344,333}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00653() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesURLGenerator(int,org.jfree.chart.urls.CategoryURLGenerator,boolean):void",
            new int[]{-191,-366,-887,1000,312,-772,270,937,-1000,1000,499,-132,548,251,-419,-729,-944,-425,325,-417,387,38,856,-182,-1000,773,717,-878,780,-60,-106,428,283,1000,-701,26,-824,330,-565,-1,-845,537,724,174,-260,1000,1000,1000,-1000,-1000,1000,306,-948,-108,-277,-377,-757,355,-191,-756,969,645,489,-493}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00654() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesURLGenerator(int,org.jfree.chart.urls.CategoryURLGenerator,boolean):void",
            new int[]{267,735,668,410,695,135,1000,746,340,1000,-174,498,191,-703,1000,-28,644,280,-400,-947,-260,1000,400,-512,-457,426,238,-368,449,284,120,510,326,-66,-588,-911,-676,742,689,-400,697,-470,33,1000,-632,1000,-609,-144,-540,-400,612,-670,-800,400,1000,144,1000,-616,-331,1000,-1000,702,-240,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00655() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesURLGenerator(int,org.jfree.chart.urls.CategoryURLGenerator,boolean):void",
            new int[]{453,-1000,-97,214,848,118,701,643,1000,1000,1000,1000,1000,-835,657,166,-890,-201,1000,-1000,561,1000,1000,-77,1000,1000,-765,515,787,684,-16,1000,841,-1000,325,637,-1000,1000,1000,-1000,-205,-320,-792,234,-292,1000,-309,-1000,599,808,-1000,-1000,1000,1000,668,432,1000,1000,395,1000,-1000,1000,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00656() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesURLGenerator(int,org.jfree.chart.urls.CategoryURLGenerator,boolean):void",
            new int[]{707,-557,63,410,695,135,1000,746,-400,1000,-264,498,191,-703,1000,-28,644,280,-280,-947,-260,1000,-96,-512,-457,1000,1000,-368,690,284,-706,510,617,-66,-383,-1000,-676,742,1000,-1000,697,-849,36,1000,-128,1000,-609,-144,-540,400,-227,-670,-800,-400,1000,144,1000,-616,-331,1000,-1000,1000,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00657() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesURLGenerator(int,org.jfree.chart.urls.CategoryURLGenerator,boolean):void",
            new int[]{398,-1000,-546,-232,917,1000,-782,976,1000,465,180,1000,547,-311,1000,967,432,-59,-1000,-1000,-412,1000,1000,-236,624,-478,-1000,-1000,-381,987,913,-314,-274,-198,864,246,-1000,280,426,-116,768,-1000,-1000,-522,-114,887,604,-960,1000,-406,-1000,-1000,495,1000,-1000,194,177,-1000,1000,662,141,1000,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00658() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesURLGenerator(int,org.jfree.chart.urls.CategoryURLGenerator,boolean):void",
            new int[]{-48,-747,-321,904,269,1000,97,525,1000,349,180,1000,625,-50,509,31,-16,217,-1000,-446,-1000,868,1000,-410,-606,441,-89,-439,213,313,665,-314,-426,-165,273,-454,-1000,1000,-193,-116,667,-213,-381,951,163,1000,304,-287,434,-1000,-521,-591,-525,1000,1000,36,143,-1000,312,231,-602,311,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00659() {
        org.junit.Assert.assertEquals("THROW:java.lang.NegativeArraySizeException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesURLGenerator(int,org.jfree.chart.urls.CategoryURLGenerator,boolean):void",
            new int[]{1000,83,-463,840,-720,527,-190,-358,-1000,-208,-1000,230,692,1000,-595,-79,-955,297,379,280,-126,382,-568,-142,-1000,998,42,1000,-62,193,502,-638,-1000,154,627,634,507,-351,-123,1000,-1000,0,858,-2,-774,-424,588,841,198,-77,260,-199,-683,-1000,83,-15,-282,-111,-470,217,1000,-1000,-735,-225}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00660() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesURLGenerator(int,org.jfree.chart.urls.CategoryURLGenerator,boolean):void",
            new int[]{242,788,-76,379,-628,-749,148,-191,-1000,-462,49,368,175,598,-91,-355,148,400,528,491,973,69,-917,446,-406,574,982,-148,-221,258,-1000,-263,537,794,345,-852,546,285,153,1000,-1000,64,1000,-288,-886,925,372,-169,-422,631,791,1000,794,-910,-722,-147,-362,1000,-627,-533,401,809,1000,207}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00661() {
        org.junit.Assert.assertEquals("THROW:java.lang.NegativeArraySizeException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesURLGenerator(int,org.jfree.chart.urls.CategoryURLGenerator,boolean):void",
            new int[]{899,8,-472,446,-835,-504,557,217,-738,-544,-777,-425,348,1000,-547,285,0,-95,1000,1000,-29,-429,-519,-1000,-246,547,1000,693,176,178,-214,-481,82,1000,318,278,1000,-1000,-664,1000,-720,589,1000,-1000,183,-575,1000,732,-4,-1000,505,295,201,-1000,-1000,711,-1000,985,-36,-1000,379,-503,706,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00662() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesURLGenerator(int,org.jfree.chart.urls.CategoryURLGenerator,boolean):void",
            new int[]{742,210,-136,79,1000,-450,-1000,-71,-821,327,539,1000,-265,-84,465,547,1000,237,-1000,264,1000,-1000,489,1000,-836,-127,-1000,227,-1000,272,1000,1000,324,508,155,-163,-63,-730,1000,1000,-334,262,-469,229,757,143,677,847,-239,-21,273,877,179,-1000,-789,137,-1000,-229,-915,-1000,422,-13,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00663() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesURLGenerator(int,org.jfree.chart.urls.CategoryURLGenerator,boolean):void",
            new int[]{0,1000,783,1000,-923,-1000,-453,-1000,-315,-718,-738,21,337,517,-316,-1,0,1000,263,1000,0,-702,-462,-1000,-509,-7,108,189,472,40,1000,-528,-489,843,650,109,0,-305,-731,1000,289,-97,-169,57,670,-124,588,-88,712,-1000,580,684,201,-1000,-526,1000,-1000,-137,-40,-1000,0,-1000,-126,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00664() {
        org.junit.Assert.assertEquals("VOID|getRowCount=java.lang.Integer:MA==|getColumnCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesURLGenerator(int,org.jfree.chart.urls.CategoryURLGenerator,boolean):void",
            new int[]{152,-486,-349,-47,-121,304,-746,243,158,-416,141,1000,499,-319,-688,589,865,-73,325,-963,-15,-186,-227,2,202,-373,-279,-628,-1000,593,339,-854,-355,705,1000,-285,-854,999,63,709,237,-124,-400,-528,-265,1000,331,1000,978,-353,-609,-400,1000,490,-1000,-656,69,-400,615,630,-7,809,-400,-462}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00665() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.AbstractCategoryItemRenderer", "org.jfree.chart.renderer.category.AreaRenderer,org.jfree.chart.renderer.category.BarRenderer,org.jfree.chart.renderer.category.BarRenderer3D,org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "setSeriesURLGenerator(int,org.jfree.chart.urls.CategoryURLGenerator,boolean):void",
            new int[]{273,24,-156,491,838,1000,608,392,1000,349,-291,393,375,-718,1000,521,1000,711,-1000,-817,-1000,1000,680,-641,-226,198,-513,-82,-18,1000,823,-256,-516,-911,353,-1000,-896,1000,685,-396,1000,-918,-865,1000,-97,1000,-822,-1000,756,-580,-792,-1000,-421,1000,1000,401,1000,-1000,770,1000,-43,352,-952,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00666() {
        org.junit.Assert.assertEquals("TYPE:org.jfree.data.Range", DEReplay.run(
            "org.jfree.chart.renderer.category.BarRenderer", "org.jfree.chart.renderer.category.BarRenderer", "findRangeBounds(org.jfree.data.category.CategoryDataset,boolean):org.jfree.data.Range",
            new int[]{873,-570,-516,548,-2,514,486,1000,293,850,-365,-1000,157,1000,1000,-1000,-52,-1000,275,-1000,-918,-1000,554,-333,296,-1000,-495,-198,-1000,-161,-1000,-1000,-388,-62,-200,-1000,389,408,-444,541,1000,1000,-486,-1000,1000,-309,187,-438,1000,1000,-1000,463,505,-477,-1000,456,-114,-293,-904,-664,856,529,-1000,-931}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00667() {
        org.junit.Assert.assertEquals("TYPE:org.jfree.data.Range", DEReplay.run(
            "org.jfree.chart.renderer.category.BarRenderer", "org.jfree.chart.renderer.category.BarRenderer", "findRangeBounds(org.jfree.data.category.CategoryDataset,boolean):org.jfree.data.Range",
            new int[]{-312,383,169,1000,1000,143,-468,-589,1000,1000,-482,-160,1000,-1000,-997,-1000,1000,610,-1000,235,-1000,-100,927,-911,1000,246,-903,-591,1000,-1000,-1000,-392,-938,-1000,907,-1000,-40,1000,-1000,1000,1000,309,74,-589,-330,-343,-497,-155,1000,-353,-922,84,1000,821,657,1000,-599,-204,-1000,-709,270,746,-553,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00668() {
        org.junit.Assert.assertEquals("TYPE:org.jfree.data.Range", DEReplay.run(
            "org.jfree.chart.renderer.category.BarRenderer", "org.jfree.chart.renderer.category.BarRenderer", "findRangeBounds(org.jfree.data.category.CategoryDataset,boolean):org.jfree.data.Range",
            new int[]{175,-629,-696,996,-82,413,-379,171,151,586,-9,-84,-821,614,-463,-508,-325,390,704,-1000,-745,189,745,-665,515,-107,598,373,625,-290,165,-56,-1000,-276,481,136,12,452,-998,336,387,260,140,-249,-745,-294,-761,-435,-627,203,-1000,-15,-32,186,159,-73,-1000,-217,-1000,321,-48,433,-894,-987}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00669() {
        org.junit.Assert.assertEquals("TYPE:org.jfree.data.Range", DEReplay.run(
            "org.jfree.chart.renderer.category.BarRenderer", "org.jfree.chart.renderer.category.BarRenderer", "findRangeBounds(org.jfree.data.category.CategoryDataset,boolean):org.jfree.data.Range",
            new int[]{873,-707,-516,588,375,1000,-1000,-181,560,211,-25,54,417,1000,721,201,-73,308,381,-1000,-1000,-1000,365,-592,296,-344,-360,1000,56,656,690,1000,-690,796,-501,617,-625,408,-440,411,1000,-62,-310,-473,143,-309,187,-622,130,328,-93,494,289,645,-286,-19,-312,-293,648,-1000,1000,-970,-446,-722}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00670() {
        org.junit.Assert.assertEquals("TYPE:org.jfree.data.Range", DEReplay.run(
            "org.jfree.chart.renderer.category.BarRenderer", "org.jfree.chart.renderer.category.BarRenderer", "findRangeBounds(org.jfree.data.category.CategoryDataset,boolean):org.jfree.data.Range",
            new int[]{762,-465,-846,-229,107,553,353,-221,-89,-286,118,-775,-1000,823,1000,1000,-1000,-805,-25,-1000,-886,-1000,187,266,16,-1000,179,1000,-353,800,-894,452,-298,625,-1000,-335,439,225,1000,561,1000,662,171,-565,7,-206,93,-197,-608,518,-800,121,-1000,-1000,-415,353,-225,-563,-546,-1000,1000,348,-543,-400}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00671() {
        org.junit.Assert.assertEquals("TYPE:org.jfree.data.Range", DEReplay.run(
            "org.jfree.chart.renderer.category.BarRenderer", "org.jfree.chart.renderer.category.BarRenderer", "findRangeBounds(org.jfree.data.category.CategoryDataset,boolean):org.jfree.data.Range",
            new int[]{546,-976,-447,1000,-758,1000,-1000,-11,856,-167,876,1000,933,1000,920,-372,-416,1000,-1000,649,-658,1000,-1000,342,-455,590,728,-195,-1000,-520,-208,-151,-1000,-1000,936,87,-483,45,81,-862,-1000,-1000,-1000,-553,333,-581,-854,-1000,530,-209,954,716,1000,57,-5,-399,-196,-1000,270,293,-577,-1000,899,583}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00672() {
        org.junit.Assert.assertEquals("TYPE:org.jfree.data.Range", DEReplay.run(
            "org.jfree.chart.renderer.category.BarRenderer", "org.jfree.chart.renderer.category.BarRenderer", "findRangeBounds(org.jfree.data.category.CategoryDataset,boolean):org.jfree.data.Range",
            new int[]{1000,-460,-757,533,428,-387,-861,-500,87,-397,130,-952,-1000,935,64,-889,-571,-1000,-305,-1000,-1000,-433,725,26,-1000,-338,890,707,574,1000,-289,1000,-1000,955,-763,-42,261,-518,31,1000,1000,-418,201,-343,432,485,-146,452,-448,1000,-981,-295,-856,-40,-873,-255,-610,-1000,-144,-595,35,-417,-840,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00673() {
        org.junit.Assert.assertEquals("TYPE:org.jfree.data.Range", DEReplay.run(
            "org.jfree.chart.renderer.category.BarRenderer", "org.jfree.chart.renderer.category.BarRenderer", "findRangeBounds(org.jfree.data.category.CategoryDataset,boolean):org.jfree.data.Range",
            new int[]{959,-962,278,743,623,1000,-24,2,274,1000,-488,-1000,442,629,1000,-1000,-68,-800,-378,-1000,-918,221,-535,-773,-91,-966,-1000,-43,-1000,114,-1000,-848,-514,232,-184,-239,-136,-622,-60,-89,611,886,-111,-1000,1000,375,-339,-1000,458,1000,-433,1000,448,-318,-1000,653,-703,-815,-24,-820,1000,-415,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00674() {
        org.junit.Assert.assertEquals("TYPE:org.jfree.data.Range", DEReplay.run(
            "org.jfree.chart.renderer.category.BarRenderer", "org.jfree.chart.renderer.category.BarRenderer", "findRangeBounds(org.jfree.data.category.CategoryDataset,boolean):org.jfree.data.Range",
            new int[]{-471,-691,-696,385,1000,985,-124,-379,550,574,-294,1000,99,587,-11,421,-381,1000,-272,-1000,-662,-874,-561,-59,-19,1000,-827,457,337,345,656,161,338,335,618,1000,12,571,1000,-465,714,-961,114,734,-745,-631,-130,-1000,-515,-102,-331,716,-301,372,1000,-394,-901,32,588,-907,1000,-1000,413,75}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00675() {
        org.junit.Assert.assertEquals("TYPE:org.jfree.data.Range", DEReplay.run(
            "org.jfree.chart.renderer.category.BarRenderer", "org.jfree.chart.renderer.category.BarRenderer", "findRangeBounds(org.jfree.data.category.CategoryDataset,boolean):org.jfree.data.Range",
            new int[]{334,-1000,-993,579,509,414,451,35,1000,41,-958,-262,-463,-521,601,952,-392,-158,-44,-1000,-1000,-1000,-92,-1000,929,-63,-1000,632,298,830,-762,-172,1000,1000,-613,966,1000,1000,1000,1000,1000,606,858,-785,-206,296,-73,-1000,293,813,52,1000,333,-901,-363,473,-886,14,633,-1000,1000,-444,324,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00676() {
        org.junit.Assert.assertEquals("TYPE:org.jfree.data.Range", DEReplay.run(
            "org.jfree.chart.renderer.category.BarRenderer", "org.jfree.chart.renderer.category.BarRenderer", "findRangeBounds(org.jfree.data.category.CategoryDataset,boolean):org.jfree.data.Range",
            new int[]{-14,-662,-542,595,246,1000,-727,230,393,302,242,661,831,976,717,-624,-202,491,-1000,-331,-685,1000,-982,-177,325,360,-364,-462,-860,-542,-636,-999,-577,-796,1000,-333,-413,921,262,-789,-1000,-281,-970,-435,135,-532,-428,-502,241,-230,77,811,918,559,-88,25,28,-447,68,339,461,-112,-347,130}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00677() {
        org.junit.Assert.assertEquals("TYPE:org.jfree.data.Range", DEReplay.run(
            "org.jfree.chart.renderer.category.BarRenderer", "org.jfree.chart.renderer.category.BarRenderer", "findRangeBounds(org.jfree.data.category.CategoryDataset,boolean):org.jfree.data.Range",
            new int[]{-187,-516,124,-491,504,1000,-820,142,1000,-295,-333,97,-588,555,-434,938,-566,891,-582,11,-489,-403,-83,-704,325,926,-612,1000,-860,196,-194,-269,443,259,610,189,987,1000,719,-17,-941,-750,-439,396,-1000,106,555,108,-1000,-230,-1000,-162,-370,-918,922,-151,-1000,398,-259,-1000,1000,350,298,-176}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00678() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.BarRenderer", "org.jfree.chart.renderer.category.BarRenderer", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{1000,-909,-226,1000,-276,-801,1000,178,109,-1000,709,-22,-535,268,-317,787,160,-197,630,452,-566,227,175,1000,190,162,-1000,-1000,714,397,-317,-1000,-691,673,-1000,-856,282,-52,253,93,502,-1000,981,1000,-1000,-597,1000,1000,642,-255,913,131,653,930,-400,-474,187,-1000,52,-400,-806,-1000,1000,-442}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00679() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.BarRenderer", "org.jfree.chart.renderer.category.BarRenderer", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{400,-467,-176,815,-276,120,309,600,408,1000,-11,-736,-228,-139,712,302,1000,1000,477,957,413,76,1000,1000,404,698,107,-616,-701,286,-279,-966,-875,747,-1000,-1000,-377,-350,-632,-372,-186,102,1000,324,-1000,367,1000,1000,1000,-641,517,419,1000,332,-400,173,216,-875,120,1000,-354,-1000,1000,-568}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00680() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.BarRenderer", "org.jfree.chart.renderer.category.BarRenderer", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{1000,-1000,-176,-48,336,-168,44,-36,-305,-94,259,444,-352,49,415,-116,317,1000,-895,401,-996,-961,-1000,436,404,129,-1000,-616,714,528,750,-892,-298,-129,-1000,-11,-377,-41,-632,212,979,248,512,1000,-59,18,-311,1000,-149,325,517,-968,1000,-50,400,-671,-89,-160,-1000,-80,-1000,-228,684,-171}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00681() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.BarRenderer", "org.jfree.chart.renderer.category.BarRenderer", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{915,687,844,1000,1000,-456,-1000,358,-154,-966,771,623,-1000,-683,559,-473,403,-1000,-1000,962,-1000,321,-1000,-1000,-797,-132,-135,879,-147,20,827,248,97,-638,-457,-1000,-468,117,870,277,986,-587,535,534,197,316,-588,-1000,-72,-106,882,-333,1000,-1000,1000,75,742,263,257,-953,-1000,-503,1000,843}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00682() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.BarRenderer", "org.jfree.chart.renderer.category.BarRenderer", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{272,-841,-821,212,-273,179,-782,167,-497,277,-568,489,725,579,672,-1000,-481,-309,1000,336,405,-1000,176,-978,-281,-1000,-317,332,-876,367,-1000,-64,1000,-466,-713,-93,-1000,-25,870,1000,190,-1000,368,-350,62,133,-1000,-412,134,591,-444,-344,-292,-279,-1000,-991,613,1000,-630,-975,1000,-84,576,230}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00683() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.BarRenderer", "org.jfree.chart.renderer.category.BarRenderer", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{1000,369,-507,1000,1000,-1000,243,-522,65,-502,29,1000,-1000,-930,-1000,291,-316,-1000,-229,278,-1000,741,-1000,-3,64,-233,-722,206,1000,-773,-46,-104,250,-829,-745,-132,151,-218,1000,1000,994,-467,791,369,-674,-561,-585,400,-1000,470,-434,-138,504,-146,1000,-113,638,-303,563,-1000,-1000,-614,-285,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00684() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.BarRenderer", "org.jfree.chart.renderer.category.BarRenderer", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{-582,-467,133,905,593,-804,-355,1000,485,-309,976,-1000,-624,-669,1000,-596,584,-77,-1000,1000,413,741,631,-192,404,825,989,1000,-958,941,271,-966,-1000,623,-1000,-910,-857,606,-309,-1000,-186,789,1000,-574,-1000,295,1000,1000,578,-646,517,662,800,-752,400,613,-970,-140,978,1000,-472,-912,345,-176}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00685() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.BarRenderer", "org.jfree.chart.renderer.category.BarRenderer", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{106,-1000,-307,1000,530,-911,-650,-156,-190,27,-733,500,389,-76,979,669,1000,-118,1000,855,-574,342,498,542,439,379,-742,645,123,-1000,5,965,-201,13,-1000,-1000,532,-138,-1000,206,1000,-758,1000,1000,-745,476,623,1000,79,67,-1000,47,308,534,-43,-286,1000,-1000,-275,43,102,-1000,1000,30}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00686() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.BarRenderer", "org.jfree.chart.renderer.category.BarRenderer", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{-446,71,-476,-364,1000,458,-1000,74,-585,-631,-976,815,204,-416,205,-441,-566,-995,-74,930,-164,-353,-723,-871,-437,-588,436,1000,-1000,786,-643,1000,189,-1000,-426,1000,-690,387,742,1000,591,-1000,664,-682,-138,857,-1000,-1000,-1000,1000,-870,-593,1000,-761,-20,-421,-27,1000,-384,-340,-530,-57,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00687() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.BarRenderer", "org.jfree.chart.renderer.category.BarRenderer", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{-202,-576,-296,1000,-194,143,197,687,1000,1000,87,-1000,-401,590,-1000,257,-419,158,647,352,1000,789,-118,818,484,-462,-640,85,453,1000,1000,-800,-1000,434,-266,-1000,1000,-786,-653,1000,-196,1000,-288,527,-128,-82,152,1000,1000,-1000,734,468,161,1000,997,453,-376,-1000,1000,1000,-984,1000,-685,-491}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00688() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.BarRenderer3D", "org.jfree.chart.renderer.category.BarRenderer3D", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{-1000,-406,439,505,203,150,-320,767,858,-641,-742,1000,835,-131,-307,916,-357,535,646,-534,-282,-54,-292,-1000,948,387,452,-209,852,-460,212,484,670,-1000,416,121,360,-1000,-901,799,-410,564,449,105,1000,103,326,-162,1000,-650,780,399,1000,-1000,578,-6,-579,-303,-608,-169,-819,1000,-46,153}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00689() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.BarRenderer3D", "org.jfree.chart.renderer.category.BarRenderer3D", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{-913,886,413,-1000,30,36,-969,473,-236,-222,1000,197,475,655,1000,-1000,248,-227,-951,1000,1000,536,-143,837,377,1000,412,172,-1000,-592,-111,-506,-32,520,962,681,935,676,830,-552,-1000,-390,144,-1000,-849,-220,-1000,-587,541,128,384,-1000,-1000,599,-1000,-1000,-32,-182,1000,192,97,1000,1000,-93}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00690() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.BarRenderer3D", "org.jfree.chart.renderer.category.BarRenderer3D", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{-1000,953,269,-990,-93,-955,-51,-202,-143,-744,493,688,233,914,793,-252,-341,-826,449,733,1000,152,756,243,400,1000,-543,-318,-897,-1000,244,-804,-252,316,1000,88,699,259,-393,-154,-1000,1000,-318,-373,551,-463,-227,545,1000,-733,1000,-443,-1000,425,-1000,-733,-84,-507,-133,236,-508,857,895,121}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00691() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.BarRenderer3D", "org.jfree.chart.renderer.category.BarRenderer3D", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{289,-572,14,786,1000,201,892,378,249,-22,637,132,-547,159,-830,-395,-643,-790,354,447,-660,-587,788,-592,130,-1000,-336,-1000,-13,-517,81,387,-1000,-68,1000,1000,-1000,1000,-607,1000,264,93,357,-169,1000,-289,1000,1000,-1000,-1000,-134,51,598,383,262,425,1000,-1000,-525,710,-1000,-828,-1000,818}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00692() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.BarRenderer3D", "org.jfree.chart.renderer.category.BarRenderer3D", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{-938,1000,-748,-1000,275,245,-1000,138,595,-1000,501,79,946,313,170,509,-930,-1000,-397,-520,940,-238,54,-150,697,664,-998,-441,203,-1000,-277,-1000,789,-469,383,853,348,-1000,21,73,-170,1000,-473,88,-931,776,-529,1000,874,57,1000,-681,-454,-1000,-1000,-493,-620,-190,1000,-9,-861,680,965,977}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00693() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.BarRenderer3D", "org.jfree.chart.renderer.category.BarRenderer3D", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{-938,292,-646,-47,-389,-877,-846,161,649,-12,113,-439,371,-913,-848,-131,-543,-955,308,-1000,-338,-515,391,-923,209,664,-1000,-343,1000,-1000,-212,-1000,754,-339,1000,-3,627,-1000,-1000,-617,869,1000,-561,151,134,834,-619,109,874,60,580,-1000,-231,-736,-905,526,-1000,206,563,228,-1000,751,670,596}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00694() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.BarRenderer3D", "org.jfree.chart.renderer.category.BarRenderer3D", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{738,-547,680,-1000,612,-105,876,473,761,-217,287,-163,-94,641,-25,-1000,-503,-1000,-123,1000,193,1000,145,1000,528,-244,416,-12,-1000,-148,-44,917,327,792,579,1000,-547,771,769,265,-40,-1000,-611,-531,-1000,-729,-101,-16,-27,-1000,634,912,-508,1000,-750,-733,797,-541,1000,-992,319,-1000,529,-223}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00695() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.BarRenderer3D", "org.jfree.chart.renderer.category.BarRenderer3D", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{-1000,953,158,884,-1000,-1000,-641,189,-143,801,493,744,1000,1000,265,645,-533,-461,668,69,728,674,1000,1000,938,1000,-1000,-318,53,-1000,-380,-1000,855,58,1000,-1000,1000,-1000,-707,-153,-1000,1000,-1000,-1000,429,-792,-58,-700,820,-890,211,15,-916,1000,-443,-1000,492,-736,-274,-1000,-323,658,895,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00696() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.BarRenderer3D", "org.jfree.chart.renderer.category.BarRenderer3D", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{-826,1000,-901,-217,368,176,-693,213,626,-996,711,147,923,-411,281,-380,-958,-183,-933,-631,914,-379,211,-643,674,400,-1000,-609,382,-673,-256,-1000,698,-393,957,959,-192,-1000,-490,459,3,1000,-247,-335,565,1000,-89,30,400,-689,734,-838,-239,-1000,-672,-276,-342,-918,795,353,73,-30,949,616}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00697() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.BarRenderer3D", "org.jfree.chart.renderer.category.BarRenderer3D", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{400,-1000,14,1000,-385,1000,892,378,249,-22,40,132,171,-737,813,-395,1000,-865,-488,-1000,-660,-587,-735,-445,-218,413,823,-1000,402,-737,1000,846,-1000,-1000,-522,-376,-874,1000,-607,258,-1000,-836,1000,-585,316,1000,-200,5,-1000,324,963,-1000,1000,361,572,1000,305,479,-202,541,-1000,-400,-624,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00698() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.BarRenderer3D", "org.jfree.chart.renderer.category.BarRenderer3D", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{-482,-1000,271,-487,67,-12,695,925,1000,391,369,-291,259,-411,-450,-689,-515,-433,172,49,20,1000,938,-352,-373,59,-811,195,-987,801,-660,-110,1000,-36,1000,992,-331,803,-414,-611,284,447,-903,-1000,-340,163,225,-981,-406,-8,-61,-129,-1000,180,77,-969,836,-288,1000,-840,46,-612,1000,229}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00699() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.BarRenderer3D", "org.jfree.chart.renderer.category.BarRenderer3D", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{1000,-1000,869,-30,1000,1000,397,844,641,324,-101,-1000,1000,-271,-810,-508,241,-554,-1000,700,1000,-402,-1000,810,274,141,1000,-513,-69,-1000,-785,1000,-1000,-491,-1000,1000,-1000,714,1000,655,1000,-1000,110,-1000,-1000,298,-1000,713,-1000,-91,-413,-1000,1000,1000,1000,684,1000,916,219,-731,1000,-1000,-1000,145}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00700() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.BarRenderer3D", "org.jfree.chart.renderer.category.BarRenderer3D", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{-1000,1000,-936,-926,-74,74,-1000,-245,569,-58,111,-481,1000,540,519,1000,-960,-886,-334,69,1000,437,514,1000,746,1000,-998,-266,82,-306,-641,-55,1000,-518,-987,194,966,-910,478,-110,-78,623,-1000,-378,12,534,-876,-720,1000,353,1000,-354,-986,-102,-819,-1000,-630,-781,944,-956,-249,959,1000,585}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00701() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.BarRenderer3D", "org.jfree.chart.renderer.category.BarRenderer3D", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{-957,-673,677,201,-93,337,-157,846,1000,-12,-451,1000,436,-967,-848,-131,-170,535,301,-246,-338,-243,96,-1000,762,691,16,-236,1000,1000,1000,400,579,-1000,-400,238,46,-1000,-802,425,1000,-1000,14,-227,1000,1000,-619,-927,580,-32,-100,297,1000,-1000,1000,526,-1000,-229,458,-325,254,115,-312,596}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00702() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{-1000,210,-112,-292,828,-1000,81,940,1000,1000,87,1000,-988,136,147,-1000,-187,1000,-987,971,825,-1000,-215,896,1000,1000,-1000,481,-405,214,-17,176,-282,-526,-687,1000,-842,-136,-407,-619,-17,-666,1000,972,-62,-375,221,-714,1000,-35,1000,-26,-1000,-108,98,1000,1000,-180,147,1000,-1000,101,610,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00703() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{-616,-606,759,-391,359,337,-1000,-528,400,-220,116,1000,-1000,-772,-400,692,123,-836,-637,1000,-983,-310,-468,296,-393,479,955,-359,-1000,400,217,424,572,331,462,-522,293,1000,-400,727,-1000,1000,108,-416,-1000,97,-406,-1000,-1000,107,400,1000,312,622,-1000,-1000,-736,459,-136,639,370,-1000,-639,-73}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00704() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{212,1000,-211,-326,-1000,502,213,-230,-177,-576,885,897,992,-379,-1000,-1000,-703,837,-713,87,44,-410,-228,-106,-1000,364,-434,722,1000,175,201,473,-139,918,-1000,-165,662,-822,1000,1000,-48,-636,-1000,-117,1000,1000,-325,689,-780,1000,-51,-1000,-483,1000,911,-633,1000,-1000,-236,-371,198,1000,1000,730}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00705() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{241,1000,494,-292,277,287,-35,-606,983,-400,-48,691,614,-93,-1000,-404,725,975,64,-268,-1000,374,-194,-326,-400,-326,1000,820,-400,732,-862,685,-4,228,316,-330,-142,-400,400,400,155,-214,1000,-924,-1000,-320,-1000,-284,1000,272,-744,-936,905,-115,98,51,319,781,300,-441,1000,101,232,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00706() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{-1000,724,734,177,1000,-748,-1000,-101,1000,778,-1000,1000,-598,1000,1000,-167,559,1000,-738,1000,-736,101,-409,1000,507,574,67,1000,-1000,859,289,80,899,-458,-318,1000,-1000,566,-1000,-466,-221,731,1000,-117,-1000,-1000,-151,-466,686,-276,1000,554,21,-690,-755,731,613,1000,-818,1000,146,-620,-343,-60}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00707() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{226,1000,624,-177,-1000,-467,1000,-1000,-527,157,-82,1000,13,1000,647,774,712,171,-542,724,-626,-1000,886,-341,-1000,217,-1000,1000,251,1000,-902,207,-671,6,-1000,1000,-582,409,-102,-282,1000,-742,213,-46,-150,-20,-1000,1000,226,387,1000,-768,983,1000,1000,755,1000,433,1000,1000,467,-532,-326,634}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00708() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{-622,552,573,-1000,-630,-748,-1000,-1000,699,778,-1000,930,-1000,905,1000,413,854,607,-1000,1000,-476,101,203,-106,507,538,152,1000,-1000,1000,-69,80,798,-820,-546,987,-1000,-540,892,-466,217,1000,1000,446,-1000,-1000,-189,-466,992,-581,376,377,145,-1000,239,1000,570,1000,26,489,-37,-293,-710,-237}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00709() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{-1000,942,-681,436,1000,-548,-586,-308,-724,486,-482,520,-498,250,1000,-351,320,257,-957,721,-333,-297,-409,1000,289,-1000,-427,806,-164,859,579,433,349,-277,-723,396,-1000,-149,-1000,11,-571,1000,844,-345,51,-893,-76,-573,-493,-257,852,650,-597,77,-633,211,326,426,-1000,789,1000,-510,19,153}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00710() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{-900,-1000,-211,689,741,-8,-1000,-1000,-177,-458,1000,-1000,-323,-926,399,681,69,837,822,-497,-633,694,-1000,374,518,-49,-238,722,-1000,7,1000,-1000,509,348,-101,64,-396,-658,-318,-789,-452,632,949,-1000,325,-985,-1000,89,310,481,-1000,-766,1000,864,-467,148,361,-715,-622,-1000,494,-985,-634,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00711() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{59,62,-806,367,133,426,-345,-669,-419,118,99,-293,788,339,943,-851,-677,705,-196,27,-79,-1000,-575,903,285,114,-134,1000,-502,-121,42,-158,-251,171,-885,194,-293,-812,943,-794,68,531,-281,-262,-1000,1000,-1000,191,-875,766,299,-641,279,288,698,-824,-57,-47,-281,-83,165,366,-248,-96}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00712() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{803,-172,-991,-101,-297,-759,-379,-544,998,835,-872,-283,-100,-114,1000,-3,370,63,-106,703,-115,-1000,34,226,711,739,-957,-1000,-1000,-1000,-436,518,-1000,677,-498,368,-1000,501,848,-1000,-905,624,639,1000,626,589,-1000,-719,-1000,912,156,275,-149,-569,759,49,369,626,1000,-767,1000,926,-697,195}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00713() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{-44,724,504,-593,-1000,-467,-565,-409,1000,662,-911,966,-1000,902,1000,-143,712,833,-417,792,-675,101,-424,458,305,392,-1000,1000,-1000,859,326,-257,798,-368,-1000,971,-1000,217,-298,-466,-155,1000,747,702,-405,-324,-277,-269,305,-100,942,-768,-231,-757,-232,965,743,738,26,1000,146,684,-577,634}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00714() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{832,889,789,-626,-1000,630,514,-837,-995,-1000,1000,-473,1000,-1000,775,-59,158,-1000,-1000,-179,-321,-988,-179,-376,-1000,282,-914,-306,630,-464,-395,80,-1000,601,-1000,-1000,-1000,330,1000,-393,-89,-1000,-714,-723,1000,1000,-925,-393,-1000,1000,-788,498,311,158,968,-887,385,-218,612,777,817,119,475,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00715() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "org.jfree.chart.renderer.category.BoxAndWhiskerRenderer", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{1000,382,-681,290,-435,883,-121,-1000,-724,-622,-233,-1000,1000,177,197,-221,-132,177,1000,-380,-1000,-292,-607,111,-689,-1000,1000,535,-485,-1000,-1000,230,42,924,213,-245,544,-149,1000,133,-801,1000,-812,-1000,-355,719,-1000,-893,197,1000,-859,487,1000,207,523,-1000,-75,426,1000,-1000,1000,160,158,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00716() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.LevelRenderer", "org.jfree.chart.renderer.category.LevelRenderer", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{-474,-994,-136,558,696,-421,766,-307,-996,966,-737,-1000,879,1000,-414,-466,513,920,-636,1000,653,821,279,-706,1000,340,1000,86,1000,1000,725,839,-281,244,-179,1000,-1000,-1000,843,995,894,688,588,-962,532,-161,112,-688,233,-795,1000,837,1000,-905,829,103,-102,-508,100,1000,527,1000,1000,-103}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00717() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.LevelRenderer", "org.jfree.chart.renderer.category.LevelRenderer", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{-342,-365,8,704,1000,-1000,936,-758,204,-1000,-348,637,-258,-667,-216,976,754,-781,594,-797,227,-676,-333,-3,-1000,-1000,1000,-1000,-567,243,672,516,330,-714,460,-1000,315,-1000,93,-616,-1000,-349,1000,863,-1,-499,436,-445,-249,909,229,-310,-1000,670,37,617,-228,682,-126,329,-476,-392,-691,690}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00718() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.LevelRenderer", "org.jfree.chart.renderer.category.LevelRenderer", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{177,-815,72,472,369,162,-626,531,1000,-983,-568,-1000,237,-175,267,862,-752,819,-1000,207,864,-431,269,-506,56,701,566,-1000,-350,372,1000,464,-1000,-630,31,741,888,626,-417,40,-1000,19,494,1000,-414,-653,-4,-1000,-1000,720,504,-24,329,-101,77,369,24,-18,188,-1000,24,211,-250,-165}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00719() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.LevelRenderer", "org.jfree.chart.renderer.category.LevelRenderer", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{986,-1000,-152,752,-561,-178,-418,104,-1000,-983,570,571,237,-504,375,-361,-1000,-362,506,-1000,-340,1000,1000,1000,-789,-200,-731,1000,-350,-439,-1000,2,-1000,1000,-1000,661,-379,398,368,-1000,-86,-1000,-469,76,-235,-884,378,1000,806,403,23,209,-1000,460,-1000,1000,903,-885,152,-878,24,-9,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00720() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.LevelRenderer", "org.jfree.chart.renderer.category.LevelRenderer", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{-428,398,-197,-311,245,187,-200,-1000,55,579,-1000,444,152,-523,-705,-53,613,-811,-1000,-45,-500,431,-242,1000,-65,-676,-412,218,291,33,-609,297,30,1000,63,-1000,78,-651,429,-154,404,-687,-543,-337,437,-666,385,1000,-1000,-1000,-1000,-882,-707,-91,-611,269,-450,-234,-705,-52,-135,-793,190,872}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00721() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.LevelRenderer", "org.jfree.chart.renderer.category.LevelRenderer", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{209,-530,-353,615,279,-440,300,-647,-356,-400,725,500,-658,1000,898,37,375,1000,547,-574,1000,1000,-605,308,-986,863,1000,-529,-929,-735,694,282,-1000,-201,-1000,-220,-592,914,-327,-390,-645,-1000,976,1000,-682,-635,-1000,426,599,-211,1000,734,-917,137,-510,-4,1000,883,195,438,342,-371,-164,-563}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00722() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.LevelRenderer", "org.jfree.chart.renderer.category.LevelRenderer", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{-41,-1000,-531,706,997,-279,-399,-792,-257,-258,-795,1000,-275,604,1000,1000,-196,-38,156,1000,543,-94,310,-425,-697,-798,49,1000,-273,-129,222,-1000,1000,-280,556,-694,458,-1000,-385,-361,-1000,-260,-131,625,1000,-45,1000,-238,-784,1000,1000,1000,-265,767,374,-1000,974,335,-1000,52,-1000,1000,-1000,-686}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00723() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.LevelRenderer", "org.jfree.chart.renderer.category.LevelRenderer", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{-1000,-661,-131,617,559,888,239,-867,964,-236,1000,-1000,1000,763,-947,394,751,892,-1000,638,1000,357,615,-1000,1000,809,1000,-1000,1000,1000,8,1000,-539,487,-448,1000,-4,330,1000,1000,233,914,1000,140,238,-56,-255,-1000,-25,-1000,1000,63,1000,-1000,1000,-1000,835,-60,88,183,300,698,1000,-425}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00724() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.LevelRenderer", "org.jfree.chart.renderer.category.LevelRenderer", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{-249,-397,-131,42,782,88,419,242,-400,7,-795,-1000,828,-462,-512,316,304,178,-660,682,351,-334,237,-580,981,-484,488,-64,595,1000,210,614,627,-989,916,1000,137,-1000,366,655,-274,554,220,-298,503,-45,760,-777,-205,-137,875,41,1000,-186,738,837,-885,-232,-266,437,-202,371,756,-23}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00725() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.LevelRenderer", "org.jfree.chart.renderer.category.LevelRenderer", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{965,98,-201,-425,283,-822,490,947,-723,479,-925,880,-274,-812,390,-51,364,375,742,-523,859,-532,-346,290,-509,-873,479,-14,-470,-244,718,-671,120,-547,217,737,-133,-273,-664,-884,-750,10,-352,-195,-496,641,771,-207,645,818,503,997,-8,798,-376,-55,665,560,-570,913,-652,61,-656,-715}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00726() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.LevelRenderer", "org.jfree.chart.renderer.category.LevelRenderer", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{864,562,-136,-498,999,-421,7,328,-904,-170,-737,1000,844,347,-414,959,-641,-339,80,-942,1000,344,443,-971,-1000,494,-654,-499,329,686,725,-481,-281,-241,-179,308,359,-745,501,484,-658,930,-213,-560,400,-359,-115,-211,450,-312,-23,237,1000,836,1000,122,-400,-750,-507,700,95,-148,256,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00727() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.LevelRenderer", "org.jfree.chart.renderer.category.LevelRenderer", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{-1000,-526,64,-669,699,-440,273,-570,544,-351,661,448,-282,-1000,-548,942,-340,-171,-319,-494,-71,-956,310,156,-814,-409,-514,-1000,1000,656,152,1000,-454,-988,128,-694,305,-420,-203,-753,-616,-411,-916,77,-552,-1000,-280,-238,-1000,712,85,-1000,-490,-36,359,1000,-121,498,110,50,660,-745,66,845}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00728() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.LevelRenderer", "org.jfree.chart.renderer.category.LevelRenderer", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{-61,1000,184,234,409,-287,48,-76,194,-858,-1000,-1000,-936,-342,465,-559,859,-407,-123,1000,615,-827,-1000,-835,1000,-1000,69,-1000,48,631,743,565,569,-558,1000,1000,-718,-459,-4,721,-893,-5,981,-526,-977,143,714,-923,-842,-220,875,1000,1000,1000,660,605,-418,1000,-1000,179,-846,371,-1000,-467}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00729() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.chart.renderer.category.LevelRenderer", "org.jfree.chart.renderer.category.LevelRenderer", "initialise(java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.data.category.CategoryDataset,org.jfree.chart.plot.PlotRenderingInfo):org.jfree.chart.renderer.category.CategoryItemRendererState",
            new int[]{-748,704,-51,-25,1000,-242,406,-50,661,641,-494,-1000,1000,-320,-104,183,-1000,1000,624,1000,1000,31,-1000,-1000,1000,547,1000,-842,1000,1000,1000,314,628,-1000,-1000,742,575,-542,186,1000,-605,1000,1000,156,-265,680,239,-1000,-132,-753,875,-846,1000,-368,-1000,-13,-1000,1000,-662,507,-414,369,-424,-1000}));
    }
}
