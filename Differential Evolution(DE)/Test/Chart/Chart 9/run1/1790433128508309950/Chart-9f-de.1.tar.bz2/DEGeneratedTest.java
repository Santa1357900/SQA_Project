import java.lang.reflect.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Deterministic test-program decoder. Used unchanged during search and JUnit replay. */
final class DEReplay {
    public static final int DIMENSIONS = 64;
    /** Local generic bean used to create stable reflection Type and Field values. */
    public static final class GenericInput {
        public String text;
        public java.util.List<String> names;
        public java.util.Map<String, Integer> counts;
        public java.util.List<java.util.Map<String, Long>> nested;
        public int[] numbers;
        public String[] words;
    }
    static final class Genes {
        final int[] values; int at; Field lastField;
        Object jacksonBean, jacksonProvider, jacksonGenerator;
        StringWriter jacksonOutput;
        Genes(int[] values) { this.values = values; }
        int next() { return values[(at++) % values.length]; }
        int pick(int n) { return Math.floorMod(next(), n); }
    }
    public static final class Observation {
        public String token, error, generatedSource;
        public boolean reachedTarget;
        public int setupCalls, setupFailures, nullFallbacks;
    }
    public static String signature(Method m) {
        StringJoiner params = new StringJoiner(",");
        for (Class<?> t : m.getParameterTypes()) params.add(t.getTypeName());
        return m.getName() + "(" + params + "):" + m.getReturnType().getTypeName();
    }
    static Class<?> load(String name) throws ClassNotFoundException {
        return Class.forName(name, true, Thread.currentThread().getContextClassLoader());
    }
    static Method method(String target, String signature) throws Exception {
        for (Method m : load(target).getDeclaredMethods())
            if (signature(m).equals(signature)) {
                // Public methods on package-private Defects4J classes (for
                // example Gson's TypeInfoFactory) are not reflectively
                // accessible until opened on the unnamed application module.
                if (!m.isAccessible()) m.setAccessible(true);
                return m;
            }
        throw new NoSuchMethodException(signature);
    }
    static List<Constructor<?>> constructors(Class<?> type) {
        List<Constructor<?>> out = new ArrayList();
        if (!Modifier.isAbstract(type.getModifiers()) && Modifier.isPublic(type.getModifiers()))
            for (Constructor<?> c : type.getConstructors())
                if (c.getParameterTypes().length <= 6) out.add(c);
        Collections.sort(out, new Comparator<Constructor<?>>() {
            public int compare(Constructor<?> a, Constructor<?> b) {
                int byArity = a.getParameterTypes().length - b.getParameterTypes().length;
                return byArity != 0 ? byArity : a.toString().compareTo(b.toString());
            }
        });
        return out;
    }
    private static Object[] arguments(Class<?>[] types, Genes g, int depth,
                                      Observation report) throws Exception {
        Object[] args = new Object[types.length];
        for (int i = 0; i < types.length; i++) args[i] = value(types[i], g, depth, report);
        return args;
    }
    private static Object[] arguments(Method method, Genes g, int depth,
                                      Observation report) throws Exception {
        Class<?>[] types = method.getParameterTypes();
        Object[] args = new Object[types.length];
        boolean closureCompile = method.getDeclaringClass().getName().equals("com.google.javascript.jscomp.Compiler")
            && method.getName().equals("compile");
        Type[] generic = method.getGenericParameterTypes();
        boolean jacksonSerialization = method.getDeclaringClass().getName().equals(
            "com.fasterxml.jackson.databind.ser.BeanPropertyWriter")
            && method.getName().startsWith("serializeAs")
            && types.length == 3 && types[0] == Object.class;
        for (int i = 0; i < types.length; i++) {
            if (jacksonSerialization && g.jacksonBean != null) {
                if (i == 0) args[i] = g.jacksonBean;
                else if (i == 1) args[i] = g.jacksonGenerator;
                else args[i] = g.jacksonProvider;
                continue;
            }
            if (closureCompile && (List.class.isAssignableFrom(types[i])
                    || (types[i].isArray() && load("com.google.javascript.jscomp.SourceFile")
                        .isAssignableFrom(types[i].getComponentType())))) {
                // Compiler.compile takes externs and inputs in either Lists or
                // arrays depending on Closure version. Keep externs empty and
                // supply a nonempty, gene-selected input program.
                if (i == 0) args[i] = types[i].isArray()
                    ? Array.newInstance(types[i].getComponentType(), 0) : new ArrayList();
                else {
                    Object sourceFile = value(load("com.google.javascript.jscomp.SourceFile"),
                        g, depth + 1, report);
                    if (types[i].isArray()) {
                        Object files = Array.newInstance(types[i].getComponentType(), 1);
                        Array.set(files, 0, sourceFile); args[i] = files;
                    } else args[i] = new ArrayList(Collections.singletonList(sourceFile));
                }
            } else args[i] = value(types[i], g, depth, report);
        }
        return args;
    }
    private static Number number(Genes g) {
        int n = g.next();
        switch (g.pick(12)) {
            case 0: return 0; case 1: return 1; case 2: return -1;
            case 3: return Integer.MAX_VALUE; case 4: return Integer.MIN_VALUE;
            case 5: return Long.MAX_VALUE; case 6: return Long.MIN_VALUE;
            case 7: return Double.NaN; case 8: return Double.POSITIVE_INFINITY;
            case 9: return Double.NEGATIVE_INFINITY; case 10: return n / 10.0;
            default: return n;
        }
    }
    private static String string(Genes g) {
        int mode = g.pick(16), n = g.next();
        String digits = Long.toString(Math.abs((long)n));
        String sign = new String[]{"", "-", "+", "--"}[g.pick(4)];
        switch (mode) {
            case 0: return null; case 1: return ""; case 2: return " ";
            case 3: return Integer.toString(n);
            case 4: return sign + digits;
            case 5: return sign + digits + "." + g.pick(1000);
            case 6: return sign + digits + "e" + g.next();
            case 7: return sign + "0x" + Long.toHexString(Math.abs((long)n));
            case 8: return sign + "0x8" + "0".repeat(g.pick(20));
            case 9: return sign + digits + "fFdDlL".charAt(g.pick(6));
            case 10: return " " + sign + digits + " ";
            case 11: return new String[]{"true", "false", "null", "NaN", "Infinity"}[g.pick(5)];
            case 12: return "a".repeat(g.pick(25));
            default:
                String alphabet = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ+-._ /\\\t\n";
                StringBuilder s = new StringBuilder();
                int length = g.pick(25);
                for (int i = 0; i < length; i++) s.append(alphabet.charAt(g.pick(alphabet.length())));
                return s.toString();
        }
    }
    private static Object value(Class<?> t, Genes g, int depth, Observation report) throws Exception {
        if (t == String.class || t == CharSequence.class) return string(g);
        if (t == Comparable.class) return "key" + g.pick(5);
        if (t == boolean.class || t == Boolean.class) return g.pick(2) == 0;
        if (t == char.class || t == Character.class) return (char)g.pick(128);
        if (t == byte.class || t == Byte.class) return number(g).byteValue();
        if (t == short.class || t == Short.class) return number(g).shortValue();
        if (t == int.class || t == Integer.class) return number(g).intValue();
        if (t == long.class || t == Long.class) return number(g).longValue();
        if (t == float.class || t == Float.class) return number(g).floatValue();
        if (t == double.class || t == Double.class || t == Number.class) return number(g).doubleValue();
        if (t.isEnum()) {
            Object[] constants = t.getEnumConstants();
            return constants.length == 0 ? null : constants[g.pick(constants.length)];
        }
        if (t == Object.class) return g.pick(3) == 0 ? null : "object" + g.pick(5);
        if (depth >= 3) { report.nullFallbacks++; return null; }
        if (t.isArray()) {
            int length = g.pick(6);
            Object array = Array.newInstance(t.getComponentType(), length);
            for (int i = 0; i < length; i++) Array.set(array, i, value(t.getComponentType(), g, depth + 1, report));
            return array;
        }
        if (t == List.class || t == Collection.class || t == Iterable.class || t == Set.class) {
            Collection<Object> items = t == Set.class ? new LinkedHashSet() : new ArrayList();
            int size = g.pick(5);
            for (int i = 0; i < size; i++) items.add("item" + g.pick(5));
            return items;
        }
        if (t == Map.class) {
            Map<Object, Object> items = new LinkedHashMap();
            int size = g.pick(5);
            for (int i = 0; i < size; i++) items.put("key" + g.pick(5), number(g));
            return items;
        }
        if (t == java.util.Date.class) return new java.util.Date(g.next() * 86400000L);
        if (t == Class.class) return String.class;
        if (t == java.lang.reflect.Field.class) {
            Field[] fields = GenericInput.class.getFields();
            g.lastField = fields[g.pick(fields.length)];
            return g.lastField;
        }
        if (t == java.lang.reflect.Type.class) {
            if (g.lastField != null && g.pick(3) == 0)
                return g.lastField.getDeclaringClass();
            Field[] fields = GenericInput.class.getFields();
            return fields[g.pick(fields.length)].getGenericType();
        }
        if (t == java.io.Reader.class || t == java.io.BufferedReader.class
                || t == java.io.StringReader.class) {
            String content = "header,value\n" + string(g) + "," + number(g) + "\n"
                + "alpha,beta\n";
            StringReader reader = new StringReader(content);
            return t == java.io.BufferedReader.class ? new BufferedReader(reader) : reader;
        }
        if (t.getName().equals("org.apache.commons.csv.CSVFormat")) {
            Class<?> format = load("org.apache.commons.csv.CSVFormat");
            for (String fieldName : new String[]{"DEFAULT", "RFC4180", "EXCEL"}) try {
                Object result = format.getField(fieldName).get(null);
                if (t.isInstance(result)) return result;
            } catch (ReflectiveOperationException ignored) { }
            for (Method factory : format.getMethods())
                if (Modifier.isStatic(factory.getModifiers()) && factory.getParameterTypes().length == 0
                        && t.isAssignableFrom(factory.getReturnType())) try {
                    return factory.invoke(null);
                } catch (ReflectiveOperationException ignored) { }
        }
        if (t.getName().equals("com.google.javascript.jscomp.SourceFile")) {
            Class<?> source = load("com.google.javascript.jscomp.SourceFile");
            for (Method factory : source.getMethods())
                if (Modifier.isStatic(factory.getModifiers()) && factory.getName().equals("fromCode")
                        && factory.getParameterTypes().length == 2 && factory.getParameterTypes()[0] == String.class
                        && factory.getParameterTypes()[1] == String.class) {
                    String replaySource = System.getProperty("de.generated.source");
                    if (replaySource != null) {
                        try {
                            report.generatedSource = replaySource;
                            return factory.invoke(null, "de-input.js", replaySource);
                        } catch (ReflectiveOperationException ignored) { }
                    }
                    String[] unusedParameterScripts = {
                        "window.f = function(a) {};",
                        "window.f = function(a, b) { return b; };",
                        "window.f = function(a, b) { var used = b; return used; };",
                        "window['f'] = function(unused) {};",
                        "window.f = function(unused, value) { return value; };",
                        "window['f'] = function(unused, value) { return value; };",
                        "window.f = function(first, unused, last) { return last; };",
                        "window.f = function(unused) { var local = 1; return local; };",
                        "window.f = function(unused, value) { var alias = value; return alias; };",
                        "window.f = function(unused, value) { if (value) { return 1; } return 2; };",
                        "window.f = function(unused, value) { value = value + 1; return value; };",
                        "window.f = function(unused, value) { return function() { return value; }; };",
                        "window.f = function(unused) { function inner() { return 1; } return inner(); };",
                        "window.f = function(a, b, unused) { return a + b; };",
                        "window.f = function(a, unused, b, c) { return a + c; };"
                    };
                    String[] catchDependencyScripts = {
                        "window.f = function() { var saved; try { throw Error('x'); } catch (caught) { saved = caught; } return saved.stack; };",
                        "window.f = function(flag) { var saved; try { if (flag) throw Error('x'); } catch (caught) { saved = caught; } return saved.message; };",
                        "window.f = function() { var saved; try { throw Error('x'); } catch (caught) { saved = caught; } return saved.name; };",
                        "window.f = function() { var saved; try { throw Error('x'); } catch (caught) { saved = caught; } return String(saved); };",
                        "window.f = function(flag) { var saved; try { if (flag) throw Error('x'); } catch (problem) { saved = problem; } return saved.stack; };",
                        "window.f = function() { var saved; try { throw Error('x'); } catch (problem) { saved = problem; } return saved.message; };"
                    };
                    String[] genericScripts = {
                        "function f(unused, used) { var local = 1; return used; } f(1, 2);",
                        "function f() { var unused = 1; var used = 2; return used; } f();",
                        "function f(x) { var first = x; first = 3; return x; } f(2);",
                        "function f() { var unused = 1; } f();",
                        "function keep() { var dead = 1; return 7; } keep();"
                    };
                    String modified = System.getProperty("de.modified.classes", "");
                    String[] scripts;
                    if (modified.contains("RemoveUnusedVars") && modified.contains("FlowSensitiveInlineVariables")) {
                        scripts = new String[unusedParameterScripts.length + catchDependencyScripts.length];
                        System.arraycopy(unusedParameterScripts, 0, scripts, 0, unusedParameterScripts.length);
                        System.arraycopy(catchDependencyScripts, 0, scripts, unusedParameterScripts.length,
                            catchDependencyScripts.length);
                    }
                    else if (modified.contains("FlowSensitiveInlineVariables")) scripts = catchDependencyScripts;
                    else if (modified.contains("RemoveUnusedVars")) scripts = unusedParameterScripts;
                    else scripts = genericScripts;
                    try {
                        String code = scripts[g.pick(scripts.length)];
                        report.generatedSource = code;
                        return factory.invoke(null, "de-input.js", code);
                    }
                    catch (ReflectiveOperationException ignored) { }
                }
        }
        if (t.getName().equals("com.google.javascript.jscomp.CompilerOptions")) {
            try {
                Object options = t.getConstructor().newInstance();
                // In Closure Compiler, unused-variable passes are enabled by
                // CompilationLevel, rather than by a CompilerOptions enum
                // setter. Apply the real public configuration when available.
                try {
                    Class<?> levelType = load("com.google.javascript.jscomp.CompilationLevel");
                    Object advanced = levelType.getField("ADVANCED_OPTIMIZATIONS").get(null);
                    for (Method configure : levelType.getMethods())
                        if (configure.getName().equals("setOptionsForCompilationLevel")
                                && configure.getParameterTypes().length == 1
                                && configure.getParameterTypes()[0].isInstance(options)) {
                            configure.invoke(advanced, options); break;
                        }
                } catch (ReflectiveOperationException ignored) { }
                // Also set the relevant options directly for Closure releases
                // whose compilation-level helper no longer enables this pass.
                for (Class<?> current = t; current != null; current = current.getSuperclass())
                    for (Field field : current.getDeclaredFields()) {
                        String name = field.getName().toLowerCase(Locale.ROOT);
                        if (field.getType() == boolean.class && name.equals("removeglobals")) try {
                            // Closure-1 specifically guards argument removal
                            // when globals are preserved. Keep the optimization
                            // pass enabled while exercising that configuration.
                            field.setAccessible(true); field.setBoolean(options, false);
                        } catch (Exception ignored) { }
                        if (field.getType() == boolean.class
                                && (name.contains("removeunusedvar") || name.contains("removeunusedlocal"))) try {
                            field.setAccessible(true); field.setBoolean(options, true);
                        } catch (Exception ignored) { }
                    }
                for (Method setter : t.getMethods()) {
                    if (!Modifier.isPublic(setter.getModifiers()) || !setter.getName().startsWith("set")
                            || setter.getParameterTypes().length != 1) continue;
                    String name = setter.getName().toLowerCase(Locale.ROOT);
                    if (setter.getParameterTypes()[0] == boolean.class && name.contains("removeglobals")) {
                        try { setter.invoke(options, false); } catch (ReflectiveOperationException ignored) { }
                    } else if (setter.getParameterTypes()[0] == boolean.class
                            && (name.contains("removeunusedvar") || name.contains("removeunusedlocal"))) {
                        try { setter.invoke(options, true); } catch (ReflectiveOperationException ignored) { }
                    } else if (name.contains("optimizationlevel")
                            && setter.getParameterTypes()[0].isEnum()) {
                        Object[] values = setter.getParameterTypes()[0].getEnumConstants();
                        for (Object value : values) if (String.valueOf(value).contains("ADVANCED"))
                            try { setter.invoke(options, value); } catch (ReflectiveOperationException ignored) { }
                    }
                }
                return options;
            } catch (ReflectiveOperationException ignored) { }
        }
        if (t.getName().equals("com.google.javascript.rhino.Node")) {
            try {
                Class<?> ir = load("com.google.javascript.rhino.IR");
                for (String factoryName : new String[]{"script", "root", "name", "string"})
                    for (Method factory : ir.getMethods())
                        if (Modifier.isStatic(factory.getModifiers()) && factory.getName().equals(factoryName)
                                && factory.getParameterTypes().length == 0 && t.isAssignableFrom(factory.getReturnType()))
                            return factory.invoke(null);
            } catch (ReflectiveOperationException ignored) { }
        }
        if (t.getName().equals("com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser")) {
            Object parser = xmlParser(g, report);
            if (parser != null && t.isInstance(parser)) return parser;
        }
        if (t.getName().equals("com.fasterxml.jackson.databind.ser.BeanPropertyWriter")
                || t.getName().equals("com.fasterxml.jackson.databind.ser.impl.UnwrappingBeanPropertyWriter")) {
            Object writer = jacksonWriter(t, g, report);
            if (writer != null && t.isInstance(writer)) return writer;
        }
        if (t == java.awt.Graphics2D.class || t == java.awt.Graphics.class)
            return new java.awt.image.BufferedImage(80, 80, java.awt.image.BufferedImage.TYPE_INT_ARGB).createGraphics();
        if (java.awt.Paint.class.isAssignableFrom(t)) {
            java.awt.Color c = new java.awt.Color(g.pick(256), g.pick(256), g.pick(256));
            if (t.isInstance(c)) return c;
        }
        if (java.awt.Stroke.class.isAssignableFrom(t)) {
            java.awt.BasicStroke s = new java.awt.BasicStroke(g.pick(10) / 2.0f);
            if (t.isInstance(s)) return s;
        }
        if (java.awt.Shape.class.isAssignableFrom(t)) {
            java.awt.Shape s = new java.awt.geom.Rectangle2D.Double(g.next(), g.next(), g.pick(80), g.pick(80));
            if (t.isInstance(s)) return s;
        }
        if (t == java.awt.geom.Point2D.class) return new java.awt.geom.Point2D.Double(g.next(), g.next());
        if (t.getName().equals("org.apache.commons.cli.CommandLine"))
            return commandLine(g, report);
        Object domain = chart(t, g, report);
        if (domain != null) return domain;
        Object language = language(t, g, report);
        if (language != null) return language;
        List<Constructor<?>> ctors = constructors(t);
        // Older Java libraries often use public singleton constants in place of enums.
        if (ctors.isEmpty()) {
            List<Field> constants = new ArrayList();
            for (Field field : t.getFields())
                if (Modifier.isStatic(field.getModifiers()) && Modifier.isFinal(field.getModifiers())
                        && t.isAssignableFrom(field.getType())) constants.add(field);
            Collections.sort(constants, new Comparator<Field>() {
                public int compare(Field a, Field b) { return a.getName().compareTo(b.getName()); }
            });
            if (!constants.isEmpty()) {
                Object constant = constants.get(g.pick(constants.size())).get(null);
                if (constant != null) return constant;
            }
        }
        if (!ctors.isEmpty()) {
            Constructor<?> ctor = ctors.get(g.pick(ctors.size()));
            try { return ctor.newInstance(arguments(ctor.getParameterTypes(), g, depth + 1, report)); }
            catch (Exception ignored) { }
        }
        report.nullFallbacks++;
        return null;
    }
    private static Object language(Class<?> t, Genes g, Observation report) {
        if (!t.getName().equals("org.apache.commons.lang3.time.FastDateFormat")) return null;
        try {
            Method factory = t.getMethod("getInstance", String.class, java.util.TimeZone.class,
                java.util.Locale.class);
            String[] patterns = {"yyyy-MM-dd", "MM/dd/yy HH:mm:ss", "EEE, d MMM yyyy HH:mm:ss Z"};
            return factory.invoke(null, patterns[g.pick(patterns.length)],
                java.util.TimeZone.getTimeZone("UTC"), java.util.Locale.US);
        } catch (ReflectiveOperationException ignored) { }
        try { return t.getMethod("getInstance", String.class).invoke(null, "yyyy-MM-dd"); }
        catch (ReflectiveOperationException ignored) { return null; }
    }
    private static Object xmlParser(Genes g, Observation report) {
        try {
            Class<?> factoryType = load("com.fasterxml.jackson.dataformat.xml.XmlFactory");
            Object factory = factoryType.getConstructor().newInstance();
            String[] docs = {"<root><value>1</value><name>x</name></root>",
                "<root value=\"42\"><item>a</item><item>b</item></root>",
                "<root/>"};
            String xml = docs[g.pick(docs.length)];
            for (Method method : factoryType.getMethods()) {
                if (!method.getName().equals("createParser") || method.getParameterTypes().length != 1) continue;
                Class<?> p = method.getParameterTypes()[0];
                Object input = p == String.class ? xml : p == Reader.class ? new StringReader(xml)
                    : p == InputStream.class ? new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8)) : null;
                if (input == null) continue;
                try {
                    Object parser = method.invoke(factory, input);
                    if (parser != null) {
                        int advance = g.pick(4);
                        Method next = parser.getClass().getMethod("nextToken");
                        for (int i = 0; i < advance; i++) if (next.invoke(parser) == null) break;
                        return parser;
                    }
                } catch (ReflectiveOperationException ignored) { }
            }
        } catch (Throwable ignored) { }
        return null;
    }
    private static Object jacksonWriter(Class<?> requested, Genes g, Observation report) {
        try {
            Class<?> mapperType = load("com.fasterxml.jackson.databind.ObjectMapper");
            Object mapper = mapperType.getConstructor().newInstance();
            Object bean = new GenericInput();
            Class<?> javaTypeType = load("com.fasterxml.jackson.databind.JavaType");
            Object javaType = mapperType.getMethod("constructType", Type.class).invoke(mapper, bean.getClass());
            // Jackson 2.6 (used by this Defects4J project) exposes a provider
            // blueprint from ObjectMapper. Create a configured provider via
            // DefaultSerializerProvider, the supported API used by ObjectMapper.
            Object providerBlueprint = mapperType.getMethod("getSerializerProvider").invoke(mapper);
            Class<?> serializationConfigType = load("com.fasterxml.jackson.databind.SerializationConfig");
            Class<?> serializerFactoryType = load("com.fasterxml.jackson.databind.ser.SerializerFactory");
            Object config = mapperType.getMethod("getSerializationConfig").invoke(mapper);
            Object factory = mapperType.getMethod("getSerializerFactory").invoke(mapper);
            Class<?> defaultProviderType = load("com.fasterxml.jackson.databind.ser.DefaultSerializerProvider");
            Method createProvider = defaultProviderType.getMethod("createInstance",
                serializationConfigType, serializerFactoryType);
            Object provider = createProvider.invoke(providerBlueprint, config, factory);
            g.jacksonBean = bean;
            g.jacksonProvider = provider;
            g.jacksonOutput = new StringWriter();
            Object jsonFactory = mapperType.getMethod("getFactory").invoke(mapper);
            for (String factoryMethod : new String[]{"createGenerator", "createJsonGenerator"}) {
                try {
                    Method createGenerator = jsonFactory.getClass().getMethod(factoryMethod, Writer.class);
                    g.jacksonGenerator = createGenerator.invoke(jsonFactory, g.jacksonOutput);
                    break;
                } catch (NoSuchMethodException ignored) { }
            }
            if (g.jacksonGenerator == null)
                throw new NoSuchMethodException("JsonFactory.createGenerator(Writer) or createJsonGenerator(Writer)");
            Class<?> providerType = load("com.fasterxml.jackson.databind.SerializerProvider");
            Class<?> beanPropertyType = load("com.fasterxml.jackson.databind.BeanProperty");
            Method find = providerType.getMethod("findValueSerializer", javaTypeType, beanPropertyType);
            Object serializer = find.invoke(provider, new Object[]{javaType, null});
            List<Object> writers = new ArrayList();
            try {
                // Available on Jackson 2.6 and newer.
                Class<?> serializerType = load("com.fasterxml.jackson.databind.JsonSerializer");
                Method properties = serializerType.getMethod("properties");
                Iterator<?> it = (Iterator<?>)properties.invoke(serializer);
                while (it.hasNext()) {
                    Object item = it.next();
                    if (item != null && item.getClass().getName().endsWith("BeanPropertyWriter"))
                        writers.add(item);
                }
            } catch (NoSuchMethodException oldJackson) {
                // JacksonDatabind-1 predates JsonSerializer.properties(). Its
                // BeanSerializerBase stores writers in the protected _props
                // array; read that array only for these old releases.
                Class<?> base = load("com.fasterxml.jackson.databind.ser.std.BeanSerializerBase");
                if (!base.isInstance(serializer))
                    throw new IllegalStateException("Expected BeanSerializerBase, got "
                        + serializer.getClass().getName(), oldJackson);
                Field props = base.getDeclaredField("_props");
                props.setAccessible(true);
                Object array = props.get(serializer);
                for (int i = 0; i < Array.getLength(array); i++) {
                    Object item = Array.get(array, i);
                    if (item != null && item.getClass().getName().endsWith("BeanPropertyWriter"))
                        writers.add(item);
                }
            }
            if (writers.isEmpty())
                throw new IllegalStateException("ObjectMapper produced no bean property writers for DEReplay.GenericInput");
            Object writer = writers.get(g.pick(writers.size()));
            boolean requireUnwrapping = requested.getName().equals(
                "com.fasterxml.jackson.databind.ser.impl.UnwrappingBeanPropertyWriter");
            if (!requireUnwrapping && g.pick(2) == 0 && requested.isInstance(writer)) return writer;
            Class<?> transformerType = load("com.fasterxml.jackson.databind.util.NameTransformer");
            Object nop = transformerType.getField("NOP").get(null);
            for (Method m : writer.getClass().getMethods())
                if (m.getName().equals("unwrappingWriter") && m.getParameterTypes().length == 1
                        && m.getParameterTypes()[0].isInstance(nop)) {
                    Object unwrapped = m.invoke(writer, nop);
                    if (requested.isInstance(unwrapped)) return unwrapped;
                }
            if (requested.isInstance(writer)) return writer;
            throw new IllegalStateException("Generated Jackson property writer is not " + requested.getName());
        } catch (Throwable failure) {
            throw new IllegalStateException("Cannot construct Jackson BeanPropertyWriter: " + failure, failure);
        }
    }
    /** Build the non-constructible Commons CLI result through its public Parser API. */
    private static Object commandLine(Genes g, Observation report) throws Exception {
        Class<?> optionsClass = load("org.apache.commons.cli.Options");
        Class<?> optionClass = load("org.apache.commons.cli.Option");
        Class<?> parserClass = load("org.apache.commons.cli.PosixParser");
        Object options = optionsClass.getConstructor().newInstance();
        Method addOption = optionsClass.getMethod("addOption", optionClass);
        int numberOfOptions = 1 + g.pick(3);
        List<String> spellings = new ArrayList();
        for (int i = 0; i < numberOfOptions; i++) {
            String shortName = String.valueOf((char)('a' + i));
            String longName = "de-option-" + i;
            boolean hasArgument = g.pick(2) == 0;
            Object option = null;
            try {
                option = optionClass.getConstructor(String.class, String.class, boolean.class, String.class)
                    .newInstance(shortName, longName, hasArgument, "DE-generated option");
            } catch (NoSuchMethodException ignored) { }
            if (option == null) try {
                option = optionClass.getConstructor(String.class, boolean.class, String.class)
                    .newInstance(shortName, hasArgument, "DE-generated option");
            } catch (NoSuchMethodException ignored) { }
            if (option == null) throw new NoSuchMethodException("No supported Commons CLI Option constructor");
            addOption.invoke(options, option);
            spellings.add("-" + shortName);
            if (hasArgument) spellings.add("value-" + Math.abs((long)g.next()));
        }
        String[] argv = spellings.toArray(new String[0]);
        Object parser = parserClass.getConstructor().newInstance();
        List<Method> parseMethods = new ArrayList();
        for (Method candidate : parserClass.getMethods()) {
            Class<?>[] p = candidate.getParameterTypes();
            if (candidate.getName().equals("parse") && p.length >= 2 && p[0] == optionsClass
                    && p[1] == String[].class && candidate.getReturnType() == load("org.apache.commons.cli.CommandLine"))
                parseMethods.add(candidate);
        }
        Collections.sort(parseMethods, new Comparator<Method>() {
            public int compare(Method a, Method b) {
                return a.getParameterTypes().length - b.getParameterTypes().length;
            }
        });
        for (Method parse : parseMethods) {
            Object[] args = new Object[parse.getParameterTypes().length];
            Class<?>[] p = parse.getParameterTypes();
            args[0] = options; args[1] = argv;
            for (int i = 2; i < p.length; i++) {
                if (p[i] == boolean.class || p[i] == Boolean.class) args[i] = g.pick(2) == 0;
                else if (p[i] == java.util.Properties.class) args[i] = new java.util.Properties();
                else args[i] = value(p[i], g, 1, report);
            }
            try { return parse.invoke(parser, args); }
            catch (InvocationTargetException ignored) { }
        }
        throw new NoSuchMethodException("No successful public PosixParser.parse(Options,String[])");
    }
    /** Optional type recipes, shared across bugs; none contains a bug-specific expected answer. */
    private static Object chart(Class<?> t, Genes g, Observation report) throws Exception {
        String n = t.getName();
        if (!n.startsWith("org.jfree.")) return null;
        if (n.equals("org.jfree.data.Range")) {
            double a = g.next(), b = g.next();
            return t.getConstructor(double.class, double.class).newInstance(Math.min(a, b), Math.max(a, b));
        }
        if (n.equals("org.jfree.data.time.RegularTimePeriod"))
            return load("org.jfree.data.time.Day").getConstructor(int.class, int.class, int.class)
                .newInstance(1 + g.pick(28), 1 + g.pick(12), 1990 + g.pick(40));
        if (n.equals("org.jfree.data.time.TimeSeries")) {
            Object series = t.getConstructor(Comparable.class).newInstance("DE");
            Class<?> period = load("org.jfree.data.time.RegularTimePeriod");
            Constructor<?> day = load("org.jfree.data.time.Day")
                .getConstructor(int.class, int.class, int.class);
            Method add = t.getMethod("add", period, double.class);
            int count = 2 + g.pick(4), year = 1990 + g.pick(40);
            for (int i = 0; i < count; i++)
                add.invoke(series, day.newInstance(i + 1, 1, year), g.next() / 10.0);
            return series;
        }
        if (n.equals("org.jfree.data.category.CategoryDataset")
                || n.equals("org.jfree.data.category.DefaultCategoryDataset")) {
            Class<?> c = load("org.jfree.data.category.DefaultCategoryDataset");
            Object data = c.getConstructor().newInstance();
            Method add = c.getMethod("addValue", Number.class, Comparable.class, Comparable.class);
            int rows = 1 + g.pick(3), columns = 1 + g.pick(3);
            for (int r = 0; r < rows; r++) for (int col = 0; col < columns; col++)
                add.invoke(data, Double.valueOf(g.next() / 10.0), "R" + r, "C" + col);
            return data;
        }
        if (n.equals("org.jfree.data.xy.XYDataset") || n.equals("org.jfree.data.xy.XYSeriesCollection")) {
            Class<?> seriesClass = load("org.jfree.data.xy.XYSeries");
            Object series = seriesClass.getConstructor(Comparable.class).newInstance("DE");
            int count = 1 + g.pick(5);
            for (int i = 0; i < count; i++) seriesClass.getMethod("add", double.class, double.class)
                .invoke(series, (double)i, g.next() / 10.0);
            Class<?> c = load("org.jfree.data.xy.XYSeriesCollection");
            Object data = c.getConstructor().newInstance();
            c.getMethod("addSeries", seriesClass).invoke(data, series);
            return data;
        }
        if (n.equals("org.jfree.data.general.PieDataset") || n.equals("org.jfree.data.general.DefaultPieDataset")) {
            Class<?> c = load("org.jfree.data.general.DefaultPieDataset");
            Object data = c.getConstructor().newInstance();
            int count = 1 + g.pick(5);
            for (int i = 0; i < count; i++) c.getMethod("setValue", Comparable.class, Number.class)
                .invoke(data, "K" + i, Double.valueOf(g.next() / 10.0));
            return data;
        }
        return null;
    }
    static List<Method> setupMethods(Class<?> receiver) {
        List<Method> methods = new ArrayList();
        for (Method m : receiver.getMethods()) {
            String n = m.getName();
            if (!Modifier.isStatic(m.getModifiers()) && !m.isSynthetic()
                    && m.getParameterTypes().length <= 3 && !n.contains("Listener")
                    && (n.startsWith("set") || n.startsWith("add") || n.startsWith("update")
                        || n.startsWith("remove") || n.equals("clear"))) methods.add(m);
        }
        Collections.sort(methods, new Comparator<Method>() {
            public int compare(Method a, Method b) {
                return signature(a).compareTo(signature(b));
            }
        });
        return methods;
    }
    public static Observation execute(String target, String receivers, String signature, int[] genes) {
        Observation out = new Observation();
        try {
            Genes g = new Genes(genes);
            Method m = method(target, signature);
            Object receiver = null;
            if (!Modifier.isStatic(m.getModifiers())) {
                String[] choices = receivers.split(",");
                Class<?> receiverType = load(choices[g.pick(choices.length)]);
                receiver = value(receiverType, g, 0, out);
                if (receiver == null) throw new IllegalArgumentException("Receiver construction failed");
                // Compiler.compile owns a strict initialization sequence.
                // Random calls to its mutators before compilation can corrupt
                // state or spend the search budget on irrelevant setup.
                if (!receiverType.getName().equals("com.google.javascript.jscomp.Compiler")) {
                    List<Method> setup = setupMethods(receiverType);
                    int count = g.pick(5);
                    for (int i = 0; i < count && !setup.isEmpty(); i++) {
                        Method s = setup.get(g.pick(setup.size()));
                        try { s.invoke(receiver, arguments(s.getParameterTypes(), g, 0, out)); out.setupCalls++; }
                        catch (Exception e) { out.setupFailures++; }
                    }
                }
            }
            Object[] args = arguments(m, g, 0, out);
            out.reachedTarget = true;
            try {
                boolean jacksonSerialization = m.getDeclaringClass().getName().equals(
                    "com.fasterxml.jackson.databind.ser.BeanPropertyWriter")
                    && m.getName().startsWith("serializeAs") && g.jacksonGenerator != null;
                boolean arrayShape = m.getName().contains("Column")
                    || m.getName().contains("Element") || m.getName().contains("Placeholder");
                if (jacksonSerialization)
                    g.jacksonGenerator.getClass().getMethod(arrayShape
                        ? "writeStartArray" : "writeStartObject").invoke(g.jacksonGenerator);
                Object result = m.invoke(receiver, args);
                boolean closureCompile = m.getDeclaringClass().getName().equals(
                    "com.google.javascript.jscomp.Compiler") && m.getName().equals("compile");
                if (closureCompile) {
                    // Result is only a status object; the compiled JavaScript is
                    // the behavioral output that reveals whether an argument
                    // was removed from a globally exposed function.
                    Object js = receiver.getClass().getMethod("toSource").invoke(receiver);
                    out.token = "CLOSURE_SOURCE:" + stable(js, 0);
                } else if (jacksonSerialization) {
                    g.jacksonGenerator.getClass().getMethod(arrayShape
                        ? "writeEndArray" : "writeEndObject").invoke(g.jacksonGenerator);
                    g.jacksonGenerator.getClass().getMethod("flush").invoke(g.jacksonGenerator);
                    out.token = "JSON:" + Base64.getEncoder().encodeToString(
                        g.jacksonOutput.toString().getBytes(StandardCharsets.UTF_8));
                } else out.token = m.getReturnType() == void.class
                    ? state(receiver, m.getName()) : stable(result, 0);
            } catch (InvocationTargetException e) {
                if (e.getCause() instanceof VirtualMachineError || e.getCause() instanceof LinkageError
                        || e.getCause() instanceof ThreadDeath) throw e;
                out.token = "THROW:" + e.getCause().getClass().getName();
            }
        } catch (Throwable e) {
            out.token = "HARNESS_ERROR";
            out.error = e.getClass().getName() + ":" + String.valueOf(e.getMessage());
        }
        return out;
    }
    public static String run(String target, String receivers, String signature, int[] genes) {
        Observation o = execute(target, receivers, signature, genes);
        if (!o.reachedTarget || o.token.equals("HARNESS_ERROR"))
            throw new AssertionError("Cannot replay test: " + o.error);
        return o.token;
    }
    private static String state(Object receiver, String method) {
        if (receiver == null) return "VOID";
        List<String> getters = new ArrayList();
        if (method.startsWith("set") && method.length() > 3) {
            getters.add("get" + method.substring(3)); getters.add("is" + method.substring(3));
        }
        getters.addAll(Arrays.asList("getItemCount", "getRowCount", "getColumnCount", "getSeriesCount"));
        StringBuilder s = new StringBuilder("VOID");
        for (String name : getters) {
            try {
                Method getter = receiver.getClass().getMethod(name);
                if (getter.getReturnType().isPrimitive() || getter.getReturnType() == String.class)
                    s.append('|').append(name).append('=').append(stable(getter.invoke(receiver), 0));
            } catch (ReflectiveOperationException ignored) { }
        }
        return s.toString();
    }
    /** Only whitelisted value types are rendered. Never use arbitrary object toString(). */
    static String stable(Object value, int depth) {
        if (value == null) return "NULL";
        Class<?> t = value.getClass();
        if (value instanceof String || value instanceof Boolean || value instanceof Character
                || value instanceof Byte || value instanceof Short || value instanceof Integer
                || value instanceof Long || value instanceof Float || value instanceof Double
                || value instanceof java.math.BigInteger || value instanceof java.math.BigDecimal)
            return t.getName() + ":" + Base64.getEncoder().encodeToString(value.toString().getBytes(StandardCharsets.UTF_8));
        if (value instanceof Enum) return "ENUM:" + t.getName() + ":" + ((Enum<?>)value).name();
        if (t.isArray() && depth < 3) {
            StringBuilder s = new StringBuilder("ARRAY:" + t.getName() + ":" + Array.getLength(value));
            for (int i = 0; i < Math.min(64, Array.getLength(value)); i++) {
                String item = stable(Array.get(value, i), depth + 1);
                s.append(':').append(item.length()).append(':').append(item);
            }
            return s.toString();
        }
        if (value instanceof java.awt.Color) return "COLOR:" + ((java.awt.Color)value).getRGB();
        // Observe safe scalar properties of returned objects. This catches
        // changes to value caches and state while avoiding identity-based toString().
        StringBuilder observed = new StringBuilder("STATE:" + t.getName());
        int properties = 0;
        for (String name : Arrays.asList("getItemCount", "getMinY", "getMaxY",
                "getRowCount", "getColumnCount", "getSeriesCount")) {
            try {
                Method getter = t.getMethod(name);
                Class<?> r = getter.getReturnType();
                if (!r.isPrimitive() && r != String.class && !Number.class.isAssignableFrom(r))
                    continue;
                if (r == void.class) continue;
                Object result = getter.invoke(value);
                String token = stable(result, depth + 1);
                observed.append('|').append(name).append('=').append(token.length())
                    .append(':').append(token);
                properties++;
            } catch (Exception ignored) { }
        }
        return properties == 0 ? "TYPE:" + t.getName() : observed.toString();
    }
    public static void main(String[] args) {
        if (args.length > 4) {
            String source = new String(Base64.getDecoder().decode(args[4]), StandardCharsets.UTF_8);
            System.setProperty("de.generated.source", source);
        }
        String[] encodedGenes = args[3].split(",");
        int[] genes = new int[encodedGenes.length];
        for (int i = 0; i < encodedGenes.length; i++) genes[i] = Integer.parseInt(encodedGenes[i]);
        boolean closureCompile = args[0].equals("com.google.javascript.jscomp.Compiler")
            && args[2].startsWith("compile(");
        // Compiler.compile is an expensive whole-program operation. Fixed-side
        // suites are still executed twice by the runner, so capture its oracle
        // once here instead of launching three compilations just to check the
        // same deterministic source output.
        int repetitions = closureCompile ? 1 : 3;
        for (int i = 0; i < repetitions; i++) {
            Observation out = execute(args[0], args[1], args[2], genes);
            System.out.println("DE_TOKEN:" + Base64.getEncoder().encodeToString(out.token.getBytes(StandardCharsets.UTF_8)));
        }
    }
}

public class DEGeneratedTest {
    @org.junit.Test(timeout=60000L)
    public void testDE00000() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:NQ==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "add(org.jfree.data.time.RegularTimePeriod,double):void",
            new int[]{-911,340,520,1000,1000,-102,-846,340,962,-1000,-1000,-1000,-315,1000,-830,-687,-183,-1000,-610,98,-325,503,-1000,-1000,-7,1000,1000,1000,1000,-47,1000,-1000,1000,1000,1000,-1000,335,-1000,1000,-931,537,-1000,-604,-1000,-1000,1000,1000,285,-1000,1000,-1000,-656,-518,481,369,1000,1000,583,-29,1000,-830,-713,-1000,565}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00001() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:NQ==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "add(org.jfree.data.time.RegularTimePeriod,double):void",
            new int[]{1000,-299,-772,-1000,150,-857,214,314,-1000,-765,-1000,-358,-307,1000,-1000,-495,55,-362,305,392,780,36,570,-1000,1000,1000,-967,501,628,-91,1000,-728,168,-618,-834,715,201,29,1000,-193,365,-1000,746,-1000,-904,1000,1000,666,-570,1000,-267,-36,525,-33,84,-323,878,513,-948,869,9,-179,142,843}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00002() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "add(org.jfree.data.time.RegularTimePeriod,double):void",
            new int[]{-1000,567,309,1000,404,91,96,647,93,583,1000,-305,-392,-576,-1000,234,-1000,-291,9,-423,-384,-290,-117,-1000,820,1000,-552,-790,1000,692,1000,-1000,153,400,258,164,64,996,1000,557,-539,-1000,-1000,434,702,943,532,244,413,149,1000,762,798,-375,-252,140,-1000,-93,-826,1000,-853,327,-1000,840}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00003() {
        org.junit.Assert.assertEquals("THROW:org.jfree.data.general.SeriesException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "add(org.jfree.data.time.RegularTimePeriod,double):void",
            new int[]{-1000,-620,-420,-195,-541,-397,-432,-454,400,400,1000,-424,490,-552,759,523,-1000,1000,-1000,-269,1000,-99,1000,109,-420,-786,-541,-287,159,-293,-1000,-1000,-1000,-471,-78,901,-1000,-728,-400,1000,368,400,323,561,1000,220,-400,-475,76,-750,1000,-1000,568,7,-1000,65,-383,-1000,-170,520,99,-879,306,359}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00004() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:MQ==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "add(org.jfree.data.time.RegularTimePeriod,double):void",
            new int[]{430,43,-206,-1000,-1000,788,470,-714,-861,-804,659,780,100,-597,645,-11,-1000,419,948,557,604,198,1000,-735,957,-1000,-1000,-810,1000,864,1000,-1000,-1000,-1000,-1000,1000,-888,433,1000,1000,-72,-1000,1000,-403,1000,-105,765,-697,-406,-765,1000,-1000,1000,-643,-1000,-992,708,-1000,862,1000,-735,713,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00005() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:Mw==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "add(org.jfree.data.time.RegularTimePeriod,double):void",
            new int[]{465,520,733,-516,-1000,227,-737,-1000,793,1000,1000,-276,403,-423,492,93,643,625,42,-310,632,-905,699,661,-1000,-741,369,-936,-661,1000,825,11,-322,-1000,-206,-241,-651,834,198,1000,-38,1000,212,30,1000,-748,-783,89,1000,-266,400,1000,-647,575,-792,315,-397,-769,837,882,785,-394,1000,368}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00006() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:MQ==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "add(org.jfree.data.time.RegularTimePeriod,double):void",
            new int[]{-357,770,133,212,-480,-705,-857,904,190,-424,-883,174,488,787,-683,184,743,296,-698,431,-623,856,-987,-968,-57,93,-685,-22,608,15,71,-202,593,696,325,-241,-907,-211,198,528,-192,48,801,-977,368,667,574,89,651,914,274,598,-703,269,129,548,-457,79,-458,882,-86,-394,179,824}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00007() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "add(org.jfree.data.time.RegularTimePeriod,double):void",
            new int[]{-878,208,-126,-1000,-849,673,128,-941,-943,-529,925,870,-119,-786,1000,980,-432,921,667,1000,127,52,769,846,812,-553,-890,-287,466,194,517,-611,-1000,-1000,-898,669,-133,-587,945,616,773,-938,296,-326,1000,-661,-41,-962,-47,-766,395,-254,572,270,-411,-793,775,-399,95,1000,311,343,274,327}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00008() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:NA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "add(org.jfree.data.time.RegularTimePeriod,double,boolean):void",
            new int[]{-379,-340,-580,53,-1000,-38,153,-35,-300,-80,222,-1000,-148,1000,-175,-676,843,-766,47,-388,203,967,-118,-1000,-288,-88,-550,131,-183,-470,-715,-420,-1000,-797,-339,-30,999,-335,306,94,-772,-263,930,-636,714,-403,-479,1000,-426,73,1000,1000,607,896,542,-213,270,1000,452,-409,600,-760,-519,936}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00009() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "add(org.jfree.data.time.RegularTimePeriod,double,boolean):void",
            new int[]{-789,1000,-176,478,802,349,-766,1000,-333,-854,32,1000,244,-1000,-67,696,-362,80,24,-84,349,-1000,-459,819,-428,451,-865,-500,1000,-228,131,303,874,-466,352,-163,-1000,-176,-140,737,209,331,90,1000,-155,47,343,-1000,1000,190,-198,-624,176,261,-245,443,-72,-1000,-559,-849,61,121,523,-918}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00010() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:MQ==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "add(org.jfree.data.time.RegularTimePeriod,double,boolean):void",
            new int[]{165,960,-1000,519,-807,-413,729,-642,-588,-612,945,1000,196,1000,9,-362,129,450,-241,125,-345,-589,1000,92,1000,75,185,201,-1000,-1000,-618,-1000,-1000,250,1000,-501,1000,428,-328,-85,-33,-886,1000,-1000,19,424,-127,825,353,68,-97,702,1000,565,1000,-279,-267,-15,291,614,448,-1000,-577,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00011() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:Mg==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "add(org.jfree.data.time.RegularTimePeriod,double,boolean):void",
            new int[]{305,-1000,1000,-333,-377,-36,975,-237,-674,-798,323,203,-141,208,-783,-1000,1000,-605,-856,-88,-736,1000,231,-1000,415,-1000,839,846,1000,47,-811,1000,-680,1000,-640,1000,629,-848,1000,-977,1000,-1000,-1000,1000,1000,-940,-720,1000,-538,1000,1000,1000,-934,652,-937,777,-614,767,-1000,-1000,421,579,-468,481}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00012() {
        org.junit.Assert.assertEquals("THROW:org.jfree.data.general.SeriesException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "add(org.jfree.data.time.RegularTimePeriod,double,boolean):void",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00013() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:NA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "add(org.jfree.data.time.RegularTimePeriod,double,boolean):void",
            new int[]{739,-1000,1000,367,-1000,-698,124,-458,300,-488,16,569,115,1000,-121,-1000,-143,441,-1000,-1000,470,1000,149,-1000,-735,893,1000,673,-628,449,-319,429,-300,-5,-293,-1000,1000,-325,-258,-1000,169,-177,9,1000,852,-947,-471,1000,-203,71,1000,-636,-678,1000,-822,-597,281,283,-751,135,481,719,-1000,713}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00014() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:MQ==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "add(org.jfree.data.time.RegularTimePeriod,double,boolean):void",
            new int[]{1000,-807,-176,1000,-691,495,-766,-635,-739,-768,-1000,1000,-318,87,-901,-981,-362,1000,-1000,-508,-878,-755,33,-336,920,129,435,311,1000,1000,491,-567,874,777,-506,-645,199,1000,-1000,1000,-1000,-1000,25,-1000,-975,47,-1000,-715,-200,-814,-1000,-388,337,-719,-330,-407,425,-1000,666,163,-238,121,-91,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00015() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:NQ==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "add(org.jfree.data.time.RegularTimePeriod,double,boolean):void",
            new int[]{230,972,-531,-214,-191,744,-329,296,-715,-728,1000,1000,919,902,-375,214,141,-55,60,588,356,-1000,367,563,76,849,-974,628,-428,397,-658,-306,-388,-389,-106,-182,300,413,-1000,-245,502,-81,653,-745,-449,749,-529,196,-336,322,-181,928,946,72,-910,-173,327,-15,-68,742,993,9,-810,-549}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00016() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:Nw==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "add(org.jfree.data.time.RegularTimePeriod,java.lang.Number):void",
            new int[]{-620,410,112,1000,-42,232,-208,-772,-681,-417,-913,992,7,1000,527,902,-1000,-1000,765,1000,405,-717,152,-368,-28,-132,1000,-1000,-584,-134,220,1000,-1000,-356,1000,-1000,1000,1000,-659,-104,-1000,937,88,-557,-811,1000,-711,1000,-685,1000,-273,-1000,-31,-894,-917,-444,1000,-1000,1000,-848,1000,-193,380,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00017() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:MQ==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "add(org.jfree.data.time.RegularTimePeriod,java.lang.Number):void",
            new int[]{-606,230,-340,675,679,227,575,772,-703,588,1000,-592,-153,-541,-252,-428,-1000,-426,-1000,822,-1000,901,192,189,-680,599,-83,-103,152,728,1000,-148,184,-703,-744,1000,-273,-306,-916,-121,116,-508,-96,-92,-733,-94,692,-454,109,-90,-437,-571,577,-234,1000,1000,-440,458,-679,-187,-480,715,440,897}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00018() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "add(org.jfree.data.time.RegularTimePeriod,java.lang.Number):void",
            new int[]{-1000,-498,1000,-443,1000,39,330,-846,353,162,-687,1000,-153,-337,1000,-169,787,-251,389,31,1000,373,-1000,804,-1000,928,1000,-1000,-282,-95,-102,99,-36,459,1000,-1000,757,1000,-128,218,-1000,-1000,-257,192,450,-847,744,97,-259,1000,759,209,473,-1000,-1000,101,1000,691,319,-99,-820,-1000,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00019() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:MQ==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "add(org.jfree.data.time.RegularTimePeriod,java.lang.Number):void",
            new int[]{-1000,857,1000,1000,840,770,-542,712,999,-108,685,1000,702,1000,359,-239,-361,-1000,1000,1000,1000,144,-178,519,293,925,300,-1000,-830,-1000,-244,654,-836,1000,1000,-1000,1000,664,-916,-512,-647,1000,406,-1000,-1000,1000,-1000,1000,-1000,-1000,-748,-588,712,-484,-431,-1000,1000,122,-50,570,-480,-1000,696,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00020() {
        org.junit.Assert.assertEquals("THROW:org.jfree.data.general.SeriesException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "add(org.jfree.data.time.RegularTimePeriod,java.lang.Number):void",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00021() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:MQ==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "add(org.jfree.data.time.RegularTimePeriod,java.lang.Number):void",
            new int[]{1000,1000,-465,597,1000,74,-573,-606,768,877,1000,225,177,708,-987,532,-706,1000,-560,-114,-1000,62,-463,-702,484,-1000,-1000,1000,-87,-671,-751,-366,356,-35,535,-60,408,691,-340,-258,474,1000,929,693,-1000,-229,-415,-1000,-139,-183,-1000,-328,941,531,-286,-739,61,1000,-365,509,609,-81,351,490}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00022() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:OA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "add(org.jfree.data.time.RegularTimePeriod,java.lang.Number):void",
            new int[]{154,531,-1000,907,401,332,-1000,-1000,-531,-26,-834,-1000,-181,1000,-310,175,-1000,771,843,265,-854,-378,-1000,-108,1000,774,-964,709,907,-359,-1000,-13,135,-1000,-746,101,-348,-484,712,1000,-690,-273,834,-557,-491,88,-257,-141,-710,-920,-400,551,-871,210,339,-161,-1000,-182,-648,455,260,707,-66,166}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00023() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "add(org.jfree.data.time.RegularTimePeriod,java.lang.Number):void",
            new int[]{-606,449,-1000,448,97,39,-346,772,678,162,69,-699,-153,937,-955,-169,-815,-1000,642,1000,-997,-92,33,-458,-12,-536,-1000,-1000,-624,-191,-430,428,-610,47,578,378,405,57,821,390,-505,-1000,-96,1000,-747,-847,-908,-131,-735,-898,-437,-1000,186,-1000,1000,-811,375,-627,-611,156,1000,366,-108,-234}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00024() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:Ng==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "add(org.jfree.data.time.RegularTimePeriod,java.lang.Number):void",
            new int[]{1000,1000,-267,1000,522,579,-644,48,878,449,884,-216,316,895,-770,175,-876,-1000,-303,-940,-1000,1000,-290,128,945,-900,-1000,1000,-479,-1000,-553,-498,95,716,72,1000,-1000,-83,484,-591,694,307,346,824,-1000,-597,-66,-967,-560,-1000,-1000,27,1000,-749,1000,190,-55,1000,-1000,497,1000,-675,579,513}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00025() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "add(org.jfree.data.time.RegularTimePeriod,java.lang.Number,boolean):void",
            new int[]{563,249,-967,-856,-488,-1000,53,321,-655,-1000,123,83,-243,-698,84,-246,36,530,78,-524,1000,781,-898,706,50,104,-1000,405,48,456,177,666,113,-551,-135,218,-591,1000,131,792,1000,938,-543,-388,536,749,688,-1000,465,-50,-1000,227,244,572,-228,670,660,-935,689,-666,10,-191,-368,-251}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00026() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:MQ==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "add(org.jfree.data.time.RegularTimePeriod,java.lang.Number,boolean):void",
            new int[]{885,-776,-185,-1000,368,-226,750,-1000,823,670,158,1000,1000,391,1000,-1000,-1000,-355,-212,-430,-390,1000,0,903,461,-1000,578,0,-210,1000,2,307,762,-5,-341,0,0,192,0,-557,-1000,-1000,-1000,-244,0,580,1000,-667,770,157,697,720,444,1000,416,-205,224,0,0,-788,-549,0,-1000,683}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00027() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:NQ==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "add(org.jfree.data.time.RegularTimePeriod,java.lang.Number,boolean):void",
            new int[]{140,-751,-1000,-1000,-1000,-1000,173,405,373,-1000,1000,918,667,359,1000,767,-223,-432,-512,-721,-1000,326,-412,-665,-354,1000,-540,154,383,333,632,76,1000,-1000,-490,182,1000,1000,-1000,26,-1000,-451,404,1000,61,-341,914,-1000,1000,48,-1000,-502,1000,1000,-985,1000,-67,-786,-400,-896,1000,-618,469,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00028() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:MQ==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "add(org.jfree.data.time.RegularTimePeriod,java.lang.Number,boolean):void",
            new int[]{921,-631,466,-313,43,316,668,-127,-58,-1000,148,400,1000,700,919,-1000,-877,-973,-293,-789,70,299,218,225,-281,-241,30,-59,403,986,191,1000,829,401,-570,67,44,-1000,-542,679,-675,-1000,-495,1000,167,-148,-175,297,584,307,945,1000,-429,74,722,-359,-448,0,-1000,-863,-894,-191,-1000,-173}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00029() {
        org.junit.Assert.assertEquals("THROW:org.jfree.data.general.SeriesException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "add(org.jfree.data.time.RegularTimePeriod,java.lang.Number,boolean):void",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00030() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:NQ==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "add(org.jfree.data.time.RegularTimePeriod,java.lang.Number,boolean):void",
            new int[]{1000,-926,-53,409,4,94,-223,-107,-864,-1000,574,46,208,457,1000,689,1000,-935,348,-246,-1000,967,1000,-1000,-781,1000,-91,599,1000,660,-915,-441,1000,-222,82,1000,1000,-848,-1000,1000,-1000,-53,1000,1000,-718,879,-1000,-596,1000,-438,-1000,562,1000,-1000,-1000,932,324,-710,-1000,-1000,1000,123,1000,-809}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00031() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:OA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "add(org.jfree.data.time.RegularTimePeriod,java.lang.Number,boolean):void",
            new int[]{-595,-157,-1000,-856,-496,-839,504,507,518,320,411,173,-64,158,1000,-503,465,-1000,-264,-758,236,-741,735,943,513,433,534,620,957,-148,757,464,1000,-1000,-63,83,156,1000,-557,972,-573,-1000,44,673,854,-678,-474,-209,1000,-515,387,-302,1000,1000,343,51,-1000,-510,-999,-870,1000,-632,475,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00032() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:MTE=", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "add(org.jfree.data.time.RegularTimePeriod,java.lang.Number,boolean):void",
            new int[]{-427,-405,-549,-537,-1000,-1000,218,-127,89,-1000,329,400,652,-532,1000,-183,269,-219,-194,-625,-645,299,-50,-563,-1000,1000,120,-59,403,16,422,190,829,-531,-636,-42,1000,321,-936,792,-917,-240,400,1000,764,-964,-35,-1000,1000,-282,1000,227,558,74,221,726,-1000,-935,-740,-942,500,-191,137,-98}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00033() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:MQ==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "add(org.jfree.data.time.RegularTimePeriod,java.lang.Number,boolean):void",
            new int[]{-20,418,-772,-611,-630,-1000,23,-71,472,227,-768,-915,682,-26,530,-338,-772,1000,-192,1000,541,-28,-367,372,-830,1000,-827,-500,-90,-321,1000,629,-124,-1000,-1000,-542,253,571,491,577,280,1000,-499,203,1000,1000,699,-1000,589,-1000,-1000,-1000,-366,330,1000,1000,830,-587,366,-545,865,-1000,-411,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00034() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:Mw==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "add(org.jfree.data.time.TimeSeriesDataItem):void",
            new int[]{1000,-512,1000,-1000,-1000,-166,909,-1000,-1000,527,-1000,1000,1000,-897,-453,-1000,248,1000,-472,752,940,-1000,-475,-215,92,-388,758,-1000,-1000,446,922,654,-397,-1000,1000,-181,-218,-845,54,-719,20,13,1000,-163,831,676,30,-986,185,1000,1000,-1000,34,-1000,-478,-290,-1000,1000,838,445,-1000,243,-151,810}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00035() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "add(org.jfree.data.time.TimeSeriesDataItem):void",
            new int[]{-31,279,-588,468,344,-611,-949,257,394,408,-626,7,-164,811,734,900,518,-89,685,126,-570,996,32,-281,-206,672,-133,-814,517,-161,-339,-467,-294,-424,-96,430,-74,-854,-237,423,-616,304,834,436,360,137,163,-927,-178,-185,-603,658,-589,737,217,-604,761,870,949,-437,-553,309,-287,192}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00036() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:Ng==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "add(org.jfree.data.time.TimeSeriesDataItem):void",
            new int[]{278,-1000,335,-977,-166,-51,-791,552,-201,1000,-564,803,-249,1000,1000,-766,1000,765,-487,-1000,213,-198,248,-77,1000,729,-150,-1000,926,942,728,412,452,-1000,482,1000,-970,-232,-185,1000,-1000,-233,385,1000,-803,13,562,-963,218,225,281,1000,740,-377,-234,-1000,-419,900,1000,1000,-984,1000,-605,624}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00037() {
        org.junit.Assert.assertEquals("THROW:org.jfree.data.general.SeriesException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "add(org.jfree.data.time.TimeSeriesDataItem):void",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00038() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:MQ==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "add(org.jfree.data.time.TimeSeriesDataItem):void",
            new int[]{1000,434,1000,663,-963,-1000,24,-901,-499,-22,-691,-160,1000,-1000,-183,-1000,-237,-939,-983,-318,697,-1000,-590,-548,608,-1000,-925,-548,-1000,791,952,301,1000,-559,934,0,843,469,-196,-996,759,-303,-163,-508,-1000,-9,106,707,1000,851,1000,-501,-726,-411,350,4,-1000,-437,1000,-701,-198,-1000,-1000,543}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00039() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:Ng==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "add(org.jfree.data.time.TimeSeriesDataItem):void",
            new int[]{195,1000,-103,1000,-708,719,358,448,815,-1000,-881,-684,1000,-414,-1000,736,-388,119,670,918,-479,300,-300,-808,336,-230,-149,-359,-1000,-974,-127,-638,-304,773,792,-965,437,-400,3,300,982,-16,-287,152,-391,-304,-505,1000,86,438,225,-467,-1000,736,-558,352,-723,200,70,-1000,-274,-404,-1000,-603}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00040() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:Ng==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "add(org.jfree.data.time.TimeSeriesDataItem):void",
            new int[]{843,-237,1000,-793,-129,930,460,-1000,-861,-489,-1000,1000,1000,-985,-1000,-1000,499,1000,-703,1000,169,436,15,-81,-373,-1000,976,-138,-1000,-64,161,261,90,-1000,1000,-1000,-612,-1000,756,-1000,1000,69,99,-567,1000,-721,-156,-31,-455,1000,1000,779,-1000,335,-176,-743,-1000,730,485,445,-1000,-741,-575,92}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00041() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "add(org.jfree.data.time.TimeSeriesDataItem):void",
            new int[]{420,946,-1000,468,220,-230,1000,923,1000,453,-147,-913,599,-257,250,900,-1000,-653,1000,-688,623,996,-564,-281,1000,477,-628,104,-334,-246,-199,-750,-862,1000,-323,310,676,-503,-1000,739,-616,304,1000,627,-756,-563,-449,-713,-1000,285,-416,1000,-589,1000,-689,609,1000,870,949,-1000,284,418,-596,52}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00042() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:Ng==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "add(org.jfree.data.time.TimeSeriesDataItem):void",
            new int[]{278,-198,-10,996,-242,-350,-1000,293,-64,586,112,-2,770,804,814,330,34,695,-33,-212,-99,12,-355,-691,156,826,972,-739,431,187,175,216,168,-597,-439,601,375,-898,-466,626,-1000,-654,884,731,-800,466,-157,-1000,526,-1000,0,-951,-112,802,-120,-266,-179,-1000,-696,-375,-625,-169,871,-517}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00043() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:MQ==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "add(org.jfree.data.time.TimeSeriesDataItem):void",
            new int[]{501,-1000,608,-1000,-370,-781,578,99,-773,1000,702,-409,-1000,1000,1000,-913,1000,-1000,-241,-943,1000,-964,-204,-422,765,1000,711,-562,1000,1000,648,1000,-884,-1000,-802,1000,-289,258,-1000,1000,-725,-625,1000,1000,-337,-238,843,-918,-574,-363,-32,-501,1000,-407,-1000,-515,-785,777,419,1000,-698,1000,540,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00044() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:MQ==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "add(org.jfree.data.time.TimeSeriesDataItem):void",
            new int[]{953,-1000,703,-721,-611,714,539,-352,-913,1000,-554,204,-264,891,1000,860,1000,-297,-522,-1000,733,-474,-340,-401,409,1000,-362,-587,1000,1000,805,798,-87,-1000,-300,566,-428,-92,-999,373,186,-71,1000,1000,741,-63,824,349,185,593,522,855,947,-282,-1000,-505,-28,-149,1000,791,-898,1000,-444,-400}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00045() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:OQ==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "add(org.jfree.data.time.TimeSeriesDataItem,boolean):void",
            new int[]{-871,-343,-691,-1000,-485,-469,-403,-498,-329,478,-498,681,-1000,-999,-696,867,972,838,-676,-500,-1000,-638,291,1000,1000,-1000,1000,1000,736,-872,1000,-1000,-714,-1000,-1000,-1000,-1000,423,-1000,122,140,-338,234,-1000,205,1000,-166,1000,-435,-1000,808,-624,1000,-1000,-1000,-249,-1000,1000,378,841,-124,1000,-371,77}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00046() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:MQ==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "add(org.jfree.data.time.TimeSeriesDataItem,boolean):void",
            new int[]{296,-717,-938,-1000,-1000,-608,-708,-275,-136,660,-804,325,-166,1000,-897,415,301,1000,662,-815,-22,-269,1000,-877,646,-1000,1000,1000,-269,282,-314,387,871,-96,-1000,-53,-1000,-117,-633,586,958,-437,1000,403,-1000,-541,128,581,632,-262,-766,661,-638,-997,-156,-1000,-470,623,543,-299,-273,797,705,-457}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00047() {
        org.junit.Assert.assertEquals("THROW:org.jfree.data.general.SeriesException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "add(org.jfree.data.time.TimeSeriesDataItem,boolean):void",
            new int[]{-36,-1000,-1000,-963,-550,-326,-35,-178,-258,-540,-804,-241,906,1000,-1000,1000,-32,-945,1000,-376,1000,412,946,-972,-246,-64,1000,-187,-1000,433,-929,1000,1000,1000,-214,-370,613,-1000,-580,668,1000,-1000,1000,1000,-1000,-1000,96,410,762,1000,-686,1000,-556,316,1000,-709,498,-855,762,-841,304,39,333,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00048() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "add(org.jfree.data.time.TimeSeriesDataItem,boolean):void",
            new int[]{-36,-342,534,-353,-851,-690,975,-617,404,376,63,-260,85,1000,-1000,-97,-131,-11,648,-69,1000,-153,1000,-426,1000,-1000,104,856,-917,-989,-1000,1000,1000,1000,-488,-701,-864,-396,-883,60,1000,-1000,127,1000,-1000,-1000,-1000,1000,115,-66,-930,851,-1000,-469,129,-1000,-519,1000,-158,1000,-1000,-450,350,-577}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00049() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:MQ==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "add(org.jfree.data.time.TimeSeriesDataItem,boolean):void",
            new int[]{-630,96,-33,174,-465,-921,204,-547,-408,-921,294,-150,-393,-286,1000,-190,636,-31,-151,1000,739,496,-496,941,1000,664,310,970,-75,53,303,-781,-8,530,1000,1000,511,-643,191,-1000,515,1000,16,401,330,329,-407,-753,-551,-232,530,-666,1000,1000,135,-477,212,377,250,-789,-1000,-1000,-418,105}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00050() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:Ng==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "add(org.jfree.data.time.TimeSeriesDataItem,boolean):void",
            new int[]{-553,-617,-414,31,-335,465,-33,-432,558,-766,-393,673,-972,-801,337,-852,362,-596,-593,-381,-1000,-312,-711,1000,1000,70,1000,1000,407,-1000,-154,-893,-532,-1000,-356,223,-497,-183,979,-502,-589,517,1000,-1000,1000,1000,-1000,1000,-703,-699,772,-945,867,-987,-1000,16,-1000,921,-763,1000,-1000,731,-1000,-50}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00051() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:NA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "add(org.jfree.data.time.TimeSeriesDataItem,boolean):void",
            new int[]{-154,-1000,-1000,-1000,-841,944,-884,-966,162,231,-1000,947,-448,403,679,570,1000,961,418,-364,-295,-146,-369,316,204,983,1000,-1000,-20,131,-20,-156,20,44,-1000,103,-634,-562,-1000,1000,20,774,730,20,-766,-378,482,-906,-411,-666,-89,264,1000,197,-790,184,-523,-1000,973,-13,400,-1000,203,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00052() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "add(org.jfree.data.time.TimeSeriesDataItem,boolean):void",
            new int[]{-62,-1000,167,1000,680,-228,856,684,-330,-1000,1000,-504,-1000,-1000,-35,-1000,-600,-1000,366,355,-295,1000,-1000,407,1000,786,1000,-530,732,563,1000,-786,74,-1000,763,849,-603,-491,1000,-55,592,121,-1000,163,1000,580,-1000,1000,-1000,-786,1000,-1000,215,-302,-932,334,-1000,169,-548,787,267,1000,-1000,987}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00053() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:NQ==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "add(org.jfree.data.time.TimeSeriesDataItem,boolean):void",
            new int[]{-967,-411,2,580,-25,233,-102,-659,-41,-1000,-211,184,918,1000,-1000,-602,-590,-516,679,-905,976,-1000,1000,-340,-209,-569,-166,-197,-510,-708,1000,1000,1000,860,-341,-370,-1000,-1000,38,582,769,-1000,27,1000,-1000,-1000,-250,771,140,-491,-314,1000,-1000,-911,608,14,-796,-227,89,182,1000,-81,1000,-975}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00054() {
        org.junit.Assert.assertEquals("STATE:org.jfree.data.time.TimeSeries|getItemCount=22:java.lang.Integer:Mg==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "addAndOrUpdate(org.jfree.data.time.TimeSeries):org.jfree.data.time.TimeSeries",
            new int[]{-553,219,1000,1000,290,-959,305,834,323,-1000,-717,-1000,744,1000,-131,-661,1000,-408,411,499,369,-865,-1000,-1000,1000,-915,-552,-1000,-590,982,-601,-1000,626,-218,-694,-913,848,433,-313,-1000,-749,-959,219,-363,53,344,-61,949,1000,-566,-578,1000,-1000,-1000,1000,464,-901,317,426,1000,-1000,-67,-266,-257}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00055() {
        org.junit.Assert.assertEquals("STATE:org.jfree.data.time.TimeSeries|getItemCount=22:java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "addAndOrUpdate(org.jfree.data.time.TimeSeries):org.jfree.data.time.TimeSeries",
            new int[]{-1000,-597,-65,162,-336,-147,-1000,-266,-211,464,402,-264,1000,72,383,624,-710,661,-375,687,-1000,415,-890,-585,1000,-674,-1000,331,660,842,1000,-1000,-546,1000,127,883,252,-79,762,-215,-397,-854,569,-1000,78,-1000,1000,275,318,-176,261,634,-55,268,-333,-268,750,806,-1000,-78,-204,-717,-759,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00056() {
        org.junit.Assert.assertEquals("STATE:org.jfree.data.time.TimeSeries|getItemCount=22:java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "addAndOrUpdate(org.jfree.data.time.TimeSeries):org.jfree.data.time.TimeSeries",
            new int[]{597,-1000,341,-873,-711,608,-812,291,574,889,862,538,-68,288,870,1,-1000,-34,-923,-593,-10,0,232,-1000,-412,-1000,-735,422,147,-1000,-1000,1000,1000,-578,208,-272,-93,1000,355,613,361,1000,-1000,-738,-57,10,-493,-866,-840,-383,237,-1000,724,713,-224,-1000,301,142,-588,-922,531,-1000,822,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00057() {
        org.junit.Assert.assertEquals("STATE:org.jfree.data.time.TimeSeries|getItemCount=22:java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "addAndOrUpdate(org.jfree.data.time.TimeSeries):org.jfree.data.time.TimeSeries",
            new int[]{383,771,-552,488,936,-271,1000,-606,-31,-243,-528,48,-225,-1000,-908,595,-391,-877,769,-534,-15,505,-816,248,-147,630,-1000,974,390,-1000,-420,332,1000,504,-845,161,-1000,-1000,1000,-741,-1000,-160,1000,140,-331,98,1000,1000,-601,781,-201,92,185,1000,-464,638,-578,-932,548,298,184,1000,-626,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00058() {
        org.junit.Assert.assertEquals("STATE:org.jfree.data.time.TimeSeries|getItemCount=22:java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "addAndOrUpdate(org.jfree.data.time.TimeSeries):org.jfree.data.time.TimeSeries",
            new int[]{-787,626,461,168,-299,-964,-116,958,-934,1000,1000,-468,1000,1000,1000,-1000,-808,561,257,1000,358,-130,510,487,1000,-428,-1000,-1000,1000,64,1000,550,216,-166,-664,874,-826,1000,206,-455,165,-12,-1000,-1000,351,-993,-608,1000,-135,-176,-29,513,-780,-616,-266,-940,-1000,748,-1000,-1000,-634,-910,1000,-599}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00059() {
        org.junit.Assert.assertEquals("STATE:org.jfree.data.time.TimeSeries|getItemCount=22:java.lang.Integer:Mg==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "addAndOrUpdate(org.jfree.data.time.TimeSeries):org.jfree.data.time.TimeSeries",
            new int[]{191,-1000,1000,671,156,-903,326,579,118,-400,587,-529,92,949,519,102,908,-1000,-141,-260,-338,-797,1000,-239,894,-539,-499,-1000,-434,-418,-439,81,665,-1000,-1000,-129,594,1000,-373,-250,-913,366,-1000,345,-30,149,-1000,94,888,-831,-1000,732,-781,-1000,887,-290,10,-284,103,312,-696,-442,465,398}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00060() {
        org.junit.Assert.assertEquals("STATE:org.jfree.data.time.TimeSeries|getItemCount=22:java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "addAndOrUpdate(org.jfree.data.time.TimeSeries):org.jfree.data.time.TimeSeries",
            new int[]{115,-1000,230,-53,-726,-453,-264,473,-55,1000,1000,90,563,899,812,-1000,-102,-734,213,544,-62,69,1000,-477,527,-1000,-1000,-1000,366,-1000,-244,364,39,-1000,-796,-129,182,1000,-135,-642,-208,423,-1000,-832,-95,-603,-1000,481,12,-107,-691,590,-550,-264,-450,-290,-785,-54,179,-501,-1000,-556,1000,222}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00061() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "addOrUpdate(org.jfree.data.time.RegularTimePeriod,double):org.jfree.data.time.TimeSeriesDataItem",
            new int[]{-303,16,-1000,429,1000,-121,-57,82,-1000,713,-1000,1000,912,305,-584,550,-1000,1000,445,1000,-612,1000,714,350,181,-414,-446,-1000,-230,-742,940,206,-1000,1000,704,-1000,1000,1000,-674,-1000,-149,476,1000,-1000,-96,-184,-122,271,455,-496,-266,-64,-800,-1000,931,874,987,-511,-848,-835,-881,-342,842,893}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00062() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "addOrUpdate(org.jfree.data.time.RegularTimePeriod,double):org.jfree.data.time.TimeSeriesDataItem",
            new int[]{723,23,235,-259,-911,339,-1000,-172,174,211,755,249,688,-836,65,135,1000,-603,1000,-879,939,506,-765,-1000,-830,31,362,792,343,487,-774,800,243,-214,-598,-322,-632,-1000,124,-9,-1000,353,-886,690,-210,-1000,-305,-409,-652,187,604,769,612,735,-398,761,-628,32,-708,-659,161,8,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00063() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "addOrUpdate(org.jfree.data.time.RegularTimePeriod,double):org.jfree.data.time.TimeSeriesDataItem",
            new int[]{55,647,-588,-1000,-53,-182,-401,-407,-321,-887,313,-432,223,-540,898,-692,1000,-142,649,49,9,1000,474,1000,148,515,1000,-576,37,-598,-1000,-483,797,10,-756,1000,-233,822,-434,-542,672,345,503,539,388,197,527,-704,-474,-566,-874,-406,-539,-570,-72,116,866,-95,-562,-562,687,321,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00064() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "addOrUpdate(org.jfree.data.time.RegularTimePeriod,double):org.jfree.data.time.TimeSeriesDataItem",
            new int[]{-88,-995,1000,-913,-565,658,-156,419,619,1000,-1000,985,1000,-892,-1000,-573,451,-432,291,-1000,576,1000,-150,-1000,-1000,411,670,1000,-566,-212,-669,-345,-1000,1000,94,815,502,-1000,-780,-1000,-283,-111,-1000,532,-987,-1000,-375,-701,789,162,759,-206,-567,-1000,-502,116,-1000,-485,-863,-1000,-1000,-112,522,-605}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00065() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "addOrUpdate(org.jfree.data.time.RegularTimePeriod,double):org.jfree.data.time.TimeSeriesDataItem",
            new int[]{964,807,-359,-899,1,-648,-3,63,-491,-897,762,-497,67,-976,596,-162,449,-681,206,502,-843,985,-426,39,650,919,604,-213,-880,-417,-445,317,778,-232,-835,993,-951,315,189,940,-170,-231,247,567,7,-82,317,328,-201,-98,5,-131,183,166,-201,-76,654,-96,-90,-659,-138,-147,-958,512}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00066() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "addOrUpdate(org.jfree.data.time.RegularTimePeriod,double):org.jfree.data.time.TimeSeriesDataItem",
            new int[]{-1000,-25,433,-1000,-288,593,-292,-378,668,-127,564,189,84,-105,-632,-629,1000,-1000,1000,-1000,930,294,817,136,-821,917,195,-5,281,140,-52,443,135,756,-703,1000,-439,-1000,-760,-226,-1000,-763,-36,485,-782,-558,351,-232,-406,-1000,-1000,971,-93,1000,-183,41,-275,-1000,-542,-766,73,-361,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00067() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "addOrUpdate(org.jfree.data.time.RegularTimePeriod,double):org.jfree.data.time.TimeSeriesDataItem",
            new int[]{-907,-872,192,1000,-18,384,515,1000,15,1000,-47,1000,170,605,-1000,-797,-1000,1000,1000,1000,-1000,-30,-610,1000,1000,-451,-55,-1000,189,-514,-448,753,-298,-400,105,456,462,1000,105,-1000,1000,40,-702,111,55,40,-301,-1000,-1000,-199,-1000,-1000,-1000,-553,1000,36,-240,729,-852,400,1000,653,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00068() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "addOrUpdate(org.jfree.data.time.RegularTimePeriod,double):org.jfree.data.time.TimeSeriesDataItem",
            new int[]{1000,426,-248,-1000,-314,-542,-1000,-587,-488,-814,139,-107,1000,-656,272,302,526,-985,948,-413,347,472,-178,-1000,-1000,1000,56,644,-1000,-197,1,1000,-52,1000,-594,971,-15,-1000,-305,-147,-1000,-1000,753,732,-942,-535,475,-198,-236,-649,1000,844,464,332,-549,378,241,-978,-505,-1000,-954,449,476,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00069() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "addOrUpdate(org.jfree.data.time.RegularTimePeriod,double):org.jfree.data.time.TimeSeriesDataItem",
            new int[]{-1000,-11,-978,-114,1000,167,-206,-297,-111,380,-1000,1000,461,1000,-361,333,-810,-71,-291,928,566,-237,113,302,-75,-304,744,-85,-301,-273,240,349,-1000,-645,1000,90,1000,120,-1000,-1000,933,-568,1000,-105,-620,260,-227,-1000,482,224,-77,-389,-1000,-617,575,-76,839,22,-519,-547,915,0,1000,426}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00070() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "addOrUpdate(org.jfree.data.time.RegularTimePeriod,java.lang.Number):org.jfree.data.time.TimeSeriesDataItem",
            new int[]{-1000,-1000,1000,57,1000,648,-178,1000,928,1000,-185,377,-561,-1000,-916,-576,1000,-729,-657,-1000,388,-1000,-104,-1000,-705,-1000,-852,-1000,771,1000,-931,-625,989,-642,-475,-452,-222,-312,679,-229,-548,1000,1000,-1000,-1000,-135,798,-938,885,-831,405,527,897,-776,-840,1000,1000,338,-972,252,1000,-1000,333,580}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00071() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "addOrUpdate(org.jfree.data.time.RegularTimePeriod,java.lang.Number):org.jfree.data.time.TimeSeriesDataItem",
            new int[]{-280,-348,1000,256,-384,688,1000,944,394,676,142,1000,1000,-89,898,972,-33,-50,1000,421,-572,317,-1000,-562,112,-193,950,-189,354,642,57,-1000,-407,172,-876,1000,-921,-70,-1000,-1000,165,-26,568,-1000,225,98,-371,-1000,353,-558,-466,-138,-78,1000,178,707,152,1000,-72,-704,659,1000,-1000,64}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00072() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "addOrUpdate(org.jfree.data.time.RegularTimePeriod,java.lang.Number):org.jfree.data.time.TimeSeriesDataItem",
            new int[]{-794,-972,1000,330,1000,-341,-558,271,193,785,-381,145,-561,-1000,-916,-474,1000,-208,-377,-196,1000,-1000,-415,-857,-487,-815,-775,-261,929,1000,-527,-488,1000,199,-208,-21,597,-172,1000,791,-49,777,560,-1000,-187,-156,309,-259,885,-269,342,527,553,-654,-840,1000,-399,160,-492,767,-1000,-634,333,496}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00073() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "addOrUpdate(org.jfree.data.time.RegularTimePeriod,java.lang.Number):org.jfree.data.time.TimeSeriesDataItem",
            new int[]{46,-1000,-373,649,-963,-197,-762,-269,-900,-486,-1000,883,-624,876,-1000,81,-446,-735,-1000,1000,850,-69,-1000,-1000,1000,244,1000,1000,-1000,618,758,-1000,-947,1000,-871,1000,824,-1000,-1000,776,1000,-1000,-825,-89,1000,85,292,624,-1000,-392,690,-1000,-227,-1000,-823,348,-392,1000,-980,-1000,819,1000,-531,26}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00074() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "addOrUpdate(org.jfree.data.time.RegularTimePeriod,java.lang.Number):org.jfree.data.time.TimeSeriesDataItem",
            new int[]{-809,322,678,844,369,137,190,-156,534,499,194,-426,646,251,-269,589,277,268,515,-572,-150,743,-407,402,-357,71,-730,-247,596,-372,-264,1000,379,645,155,146,-383,445,889,-245,252,288,-88,624,-1000,240,-530,-170,689,-254,-724,675,-393,435,392,234,1000,310,782,827,184,90,564,146}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00075() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "addOrUpdate(org.jfree.data.time.RegularTimePeriod,java.lang.Number):org.jfree.data.time.TimeSeriesDataItem",
            new int[]{343,-602,-906,347,-138,-401,1000,309,956,756,501,902,-505,354,-1000,18,602,-513,-300,-578,-308,-69,-110,714,-373,-1000,-493,-1000,-227,601,-20,181,415,-508,-1000,-991,-130,1000,585,-894,-1000,381,287,-1000,887,264,327,27,-218,-167,421,271,30,-620,-86,406,947,-319,302,-90,-413,1000,-935,-970}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00076() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "addOrUpdate(org.jfree.data.time.RegularTimePeriod,java.lang.Number):org.jfree.data.time.TimeSeriesDataItem",
            new int[]{-280,-592,295,27,-803,654,-780,-799,957,773,906,-161,497,-205,-340,972,-169,-737,-83,-264,-581,-85,858,82,592,-477,298,-899,-330,-239,-474,-737,-564,-989,519,-508,-802,-353,824,-873,-729,-475,-750,575,-614,170,-496,702,-734,450,893,-92,-585,421,-680,-825,-962,-562,-72,-588,-112,-328,950,-91}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00077() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "addOrUpdate(org.jfree.data.time.RegularTimePeriod,java.lang.Number):org.jfree.data.time.TimeSeriesDataItem",
            new int[]{519,-898,21,649,-375,-103,718,-503,856,756,-282,809,-1000,151,-1000,81,-55,-716,-1000,-875,-647,-69,-256,1000,-373,-1000,817,-722,-387,-195,-449,-305,796,465,642,-817,628,820,906,-82,-833,-669,488,-690,-53,848,-162,70,-598,-261,1000,271,698,-1000,-1000,-58,947,-529,782,425,885,540,-531,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00078() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "addOrUpdate(org.jfree.data.time.RegularTimePeriod,java.lang.Number):org.jfree.data.time.TimeSeriesDataItem",
            new int[]{1000,-864,-273,1000,-913,153,741,-648,927,-343,-530,952,-993,1000,-15,501,-570,-276,-854,-1000,-1000,972,821,1000,1,-327,1000,-560,-387,-1000,-850,-363,1000,612,250,-257,391,1000,1000,100,494,-1000,292,1000,-196,1000,-1000,347,-865,-85,565,357,633,-310,-1000,-13,1000,-203,1000,212,1000,62,-913,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00079() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "clear():void",
            new int[]{56,-612,-1000,287,301,-712,-479,1000,1000,-496,116,1000,38,760,-1000,315,-802,-1000,638,307,132,-450,1000,-1000,184,332,15,-465,1000,-775,190,1000,-627,1000,547,-749,-1000,-700,-128,-1000,1000,-754,-648,246,84,699,443,1000,1000,1000,559,1000,850,512,-129,1000,-629,-657,1000,-159,126,722,1000,-37}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00080() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "clear():void",
            new int[]{-329,-943,-1000,1000,877,-827,-896,977,1000,-838,241,359,-1000,-570,-660,662,1000,1000,-18,-876,203,828,-660,662,144,-1000,363,-472,-1000,-276,-156,1000,-479,769,1000,77,-257,-38,-1000,-186,-110,-1000,1000,-844,-82,229,1000,666,746,-881,-1000,-582,-415,-46,477,381,-1000,-64,-497,20,-1000,1000,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00081() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "clear():void",
            new int[]{290,267,-1000,127,-447,-977,564,626,954,-194,171,-41,-770,-386,146,-299,-911,-1000,785,-1000,8,-1000,-225,-319,-97,433,240,-950,143,-1000,-243,-928,-728,1000,-8,-46,-1000,128,775,378,-242,92,-642,400,211,845,271,672,1000,317,-235,-299,-242,-130,684,-594,202,-88,-194,72,683,99,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00082() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "clear():void",
            new int[]{-676,-204,819,-940,-853,489,67,-49,-878,-211,-363,-810,912,-489,-184,-180,-255,-880,-838,-77,189,60,-760,-334,-571,348,-586,-620,849,752,-709,741,-762,866,-994,-616,54,-540,-340,-389,814,561,-109,249,928,926,-150,-840,-955,-213,623,436,361,53,-451,883,210,-485,-178,-952,768,-983,235,730}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00083() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "clear():void",
            new int[]{1000,-1000,1000,-463,-1000,774,-1000,-905,-1000,271,-557,-509,918,-1000,1000,-47,654,1000,508,-689,-97,928,-1000,-1000,136,726,-1000,903,-1000,1000,-1000,-1000,540,-1000,348,1000,1000,1000,-774,1000,461,-1000,90,-1000,-481,-649,972,-716,-1000,384,-244,1000,-291,1000,759,-1000,1000,-840,-301,1000,-737,-162,-66,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00084() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "clear():void",
            new int[]{-1000,864,44,666,1000,249,566,941,373,726,-753,-605,-1000,-400,-350,386,1000,-48,-415,1000,-188,1000,-587,585,-764,-977,1000,-827,-376,-427,-158,-580,-1000,319,101,-727,-1000,-542,-661,-101,-618,-736,1000,718,-1000,537,-922,177,1000,-121,-519,-150,-762,-485,878,353,803,1000,-273,-1000,-478,541,-400,-845}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00085() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "clear():void",
            new int[]{1000,362,-306,282,-1000,-748,-317,-371,-847,-827,334,141,-66,-890,967,-80,176,400,95,-1000,-982,-798,-1000,804,613,-625,-1000,-595,-942,-136,-1000,-1000,1000,-999,-117,-193,-482,331,390,1000,-750,10,-33,-505,-55,729,283,-287,-1000,-1000,-576,-605,-23,134,1000,526,361,-16,-1000,1000,-24,-453,370,351}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00086() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "clear():void",
            new int[]{1000,-293,-559,189,-1000,-980,-819,156,3,-751,476,905,661,212,-133,-184,-728,-341,484,-858,-481,-973,259,804,136,307,-665,-336,458,285,-1000,-630,785,-277,290,-479,-1000,-648,-774,340,628,-349,-991,367,490,737,220,327,-381,940,16,-172,919,5,328,1000,1000,-1000,-348,1000,-370,19,1000,979}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00087() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "clear():void",
            new int[]{1000,-1000,-1000,937,-147,-577,-1000,582,1000,-677,632,792,-803,986,-268,779,-188,400,1000,416,-267,208,950,-1000,807,21,-1000,300,-808,91,148,928,-47,-400,996,-486,-127,-278,245,-249,1000,-1000,-968,-1000,-409,22,365,1000,1000,42,219,1000,1000,1000,436,-209,-380,-1000,1000,1000,-634,1000,925,307}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00088() {
        org.junit.Assert.assertEquals("STATE:org.jfree.data.time.TimeSeries|getItemCount=22:java.lang.Integer:Ng==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "clone():java.lang.Object",
            new int[]{822,-544,439,603,438,444,-204,938,-1000,812,-381,652,-605,-255,287,-1000,493,-628,823,-972,-755,425,-438,696,-636,163,-371,1000,-322,-1000,-474,-134,3,-1000,-305,482,20,-318,-120,183,81,-193,-802,-213,-875,762,-1000,-1000,-649,-1000,-155,-714,-249,1000,-195,398,-348,-811,-762,-340,-299,-1000,-662,852}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00089() {
        org.junit.Assert.assertEquals("STATE:org.jfree.data.time.TimeSeries|getItemCount=22:java.lang.Integer:NQ==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "clone():java.lang.Object",
            new int[]{43,905,-561,-249,979,178,339,221,827,-946,-811,-232,370,639,590,-649,-725,192,-33,-396,-691,-896,407,28,-140,-699,968,-839,-819,961,-324,-386,-185,463,600,212,370,617,60,-160,-11,-637,270,76,676,421,-450,192,-35,-400,608,704,338,-99,332,271,262,937,40,-544,747,-318,188,-342}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00090() {
        org.junit.Assert.assertEquals("STATE:org.jfree.data.time.TimeSeries|getItemCount=22:java.lang.Integer:MQ==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "clone():java.lang.Object",
            new int[]{-591,-105,134,247,1000,661,-619,363,93,646,1000,-239,88,560,120,179,808,991,-13,-279,1000,-1000,115,1000,1000,-186,1000,-1000,-508,-108,-814,-1000,-609,-80,-649,304,-441,668,760,-1000,-850,-848,464,-368,-368,1000,340,346,-516,1000,-1000,-1000,286,-904,169,-287,664,-377,409,-1000,-577,1000,-270,-913}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00091() {
        org.junit.Assert.assertEquals("STATE:org.jfree.data.time.TimeSeries|getItemCount=22:java.lang.Integer:MQ==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "clone():java.lang.Object",
            new int[]{-78,202,-357,-37,1000,643,-20,-121,666,1000,-285,-638,649,283,434,-698,-226,93,311,-497,-15,-1000,-449,-105,288,-521,216,-420,-178,218,-587,-223,-431,183,420,-385,236,277,-317,-760,89,-555,861,720,912,818,-90,554,-260,-127,217,112,951,-699,227,632,635,48,-219,-737,-20,-568,-141,-474}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00092() {
        org.junit.Assert.assertEquals("STATE:org.jfree.data.time.TimeSeries|getItemCount=22:java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "clone():java.lang.Object",
            new int[]{133,-942,231,1000,219,-68,-1000,934,-872,539,481,506,-605,934,-510,-642,493,-1000,516,324,218,-536,-1000,472,372,234,-1000,1000,-8,-1000,-265,279,3,-555,-417,1000,306,-52,290,-592,371,-60,-422,-1000,-946,-481,-1000,-1000,-337,56,-1000,-1000,-477,-288,-1000,593,130,135,-226,-900,-911,-1000,-1000,352}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00093() {
        org.junit.Assert.assertEquals("STATE:org.jfree.data.time.TimeSeries|getItemCount=22:java.lang.Integer:Ng==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "clone():java.lang.Object",
            new int[]{43,-140,-588,-451,1000,178,909,-135,1000,-103,-1000,-1000,-124,1000,996,-1000,-1000,740,16,-396,465,-896,1000,-93,-892,-743,1000,-1000,-819,1000,-410,85,-188,284,1000,-43,490,935,-197,-90,562,26,23,-51,686,421,-467,-143,-142,-462,1000,1000,874,-570,776,-133,488,1000,-584,548,1000,-502,417,-197}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00094() {
        org.junit.Assert.assertEquals("STATE:org.jfree.data.time.TimeSeries|getItemCount=22:java.lang.Integer:Mg==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "clone():java.lang.Object",
            new int[]{-314,-1000,-302,488,979,364,-997,473,-46,-524,311,21,1000,137,119,-438,675,-804,655,218,-1000,-969,-1000,316,1000,601,-405,-839,-918,-574,-737,-464,-753,-712,-440,233,-185,-72,254,-797,-433,-1000,828,150,572,2,-1000,-1000,-317,521,-234,-370,-184,-400,-734,839,-80,270,346,-1000,1000,-107,-88,-890}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00095() {
        org.junit.Assert.assertEquals("STATE:org.jfree.data.time.TimeSeries|getItemCount=22:java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "clone():java.lang.Object",
            new int[]{-1000,431,-24,513,687,-198,-1000,551,-122,-1000,1000,-334,1000,464,-140,-488,1000,-1000,562,1000,390,-339,-449,617,940,-464,-1000,-420,-178,-1000,-702,-410,-1000,183,-1000,1000,-188,151,61,-887,-475,-418,861,-1000,181,-1000,-90,411,-554,1000,-1000,-1000,-418,-1000,-1000,480,1000,373,285,-441,-1000,295,318,-947}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00096() {
        org.junit.Assert.assertEquals("STATE:org.jfree.data.time.TimeSeries|getItemCount=22:java.lang.Integer:MQ==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "clone():java.lang.Object",
            new int[]{828,-1000,-973,645,276,823,15,305,253,574,-1000,-131,-709,-1000,-586,-292,456,336,-288,-1000,-15,12,-1000,711,-612,601,446,1000,-918,-574,119,-4,1000,-712,759,644,1000,866,197,-317,646,303,-781,-227,-731,1000,-1000,-1000,-1,-1000,953,-712,1000,1000,-278,-79,-80,-129,-635,-837,1000,-1000,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00097() {
        org.junit.Assert.assertEquals("STATE:org.jfree.data.time.TimeSeries|getItemCount=22:java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "clone():java.lang.Object",
            new int[]{-892,-737,-695,14,-163,-677,-211,403,744,-320,494,222,-306,-214,-509,244,-776,-806,-338,799,985,890,-405,-430,444,-466,-625,691,-28,952,726,31,517,281,106,839,719,265,15,-657,-439,388,67,-651,412,-244,-851,383,685,-55,-596,-474,220,391,-311,717,992,319,683,-988,769,-293,-150,-953}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00098() {
        org.junit.Assert.assertEquals("STATE:org.jfree.data.time.TimeSeries|getItemCount=22:java.lang.Integer:MQ==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "createCopy(int,int):org.jfree.data.time.TimeSeries",
            new int[]{89,-767,1000,-1000,-390,1000,602,-498,-257,373,-1000,439,523,56,-95,730,660,-155,244,684,1000,102,70,-352,-346,442,961,809,243,287,148,-808,-1000,1000,968,1000,-394,-1000,760,307,-495,-1000,901,-899,-154,-546,-1000,-965,51,-831,-1000,-630,-563,1000,250,-1000,1000,589,940,199,-1000,919,913,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00099() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "createCopy(int,int):org.jfree.data.time.TimeSeries",
            new int[]{-1000,-535,1000,1000,-1000,-165,239,-589,-618,-732,-1000,-312,755,-346,32,1000,1000,-786,1000,-972,1000,1000,996,-751,744,258,-920,-636,646,219,106,-1000,1000,98,1000,-800,-1000,543,-1000,1000,-1000,-1000,70,-1000,1000,-674,1000,1000,-1000,-389,1000,-709,-39,971,595,1000,159,-1000,373,1000,-1000,-896,340,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00100() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "createCopy(int,int):org.jfree.data.time.TimeSeries",
            new int[]{-1000,-1000,1000,153,-1000,864,133,-20,-881,-159,-1000,-1000,-531,160,-384,346,824,-670,446,-899,1000,1000,1000,-235,1000,519,-281,-84,-357,923,-1000,-1000,848,878,981,-772,-1000,51,-1000,1000,-1000,-1000,-423,-1000,589,-319,-247,905,-1000,-274,-463,-366,-346,1000,-1000,5,239,-918,1000,851,-811,-1000,36,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00101() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "createCopy(int,int):org.jfree.data.time.TimeSeries",
            new int[]{-718,65,1000,809,-1000,-386,398,-960,57,-1000,-455,-1000,-312,732,-734,731,429,-641,590,-1000,1000,444,184,190,741,182,-1000,-783,183,-352,1000,-427,1000,-362,1000,-1000,-1000,160,-1000,1000,36,-1000,-150,-276,940,-1000,793,521,-1000,345,796,-1000,-768,496,-526,478,-1000,-1000,-400,1000,-815,-251,-908,239}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00102() {
        org.junit.Assert.assertEquals("THROW:java.lang.IndexOutOfBoundsException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "createCopy(int,int):org.jfree.data.time.TimeSeries",
            new int[]{107,-851,1000,-131,-995,586,-541,-590,-1000,156,-764,-378,1000,982,-589,323,-1000,-745,428,-972,572,410,934,414,278,571,-366,-224,-1000,-398,106,-50,368,548,430,-652,-537,-581,-180,716,-350,-891,-610,-33,-400,498,-661,878,-1000,204,-453,-709,-612,-660,-816,-650,-338,1000,770,716,-559,-21,-490,383}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00103() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "createCopy(int,int):org.jfree.data.time.TimeSeries",
            new int[]{1000,1000,34,-1000,1000,-653,-6,-628,-339,79,1000,1000,-1000,176,-394,-590,-1000,1000,-49,497,-1000,-1000,-1000,1000,-1000,759,-276,-206,498,1000,1000,1000,-872,-750,-528,-75,1000,-1000,1000,-1000,668,-384,-325,1000,-813,12,13,-127,1000,-329,-61,-427,-527,594,1000,123,176,-123,178,-1000,1000,1000,532,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00104() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "createCopy(int,int):org.jfree.data.time.TimeSeries",
            new int[]{-406,-1000,1000,231,-995,699,404,-624,-128,-80,-851,-1000,755,795,-719,134,431,-1000,305,-972,961,863,996,319,744,410,-377,-256,-623,-404,106,-375,368,507,621,-800,-537,-174,-705,1000,-379,-891,-585,-296,256,-257,-447,1000,-1000,158,-341,-709,-449,-420,-924,-614,-366,-1000,878,1000,-701,-896,-877,-16}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00105() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "createCopy(int,int):org.jfree.data.time.TimeSeries",
            new int[]{525,1000,163,-624,-83,-893,751,-921,385,-647,1000,1000,-1000,1000,-813,-1000,-1000,1000,151,-262,-755,-634,-6,782,-755,516,-664,-655,31,480,757,1000,256,139,27,-98,-65,-614,533,-670,715,580,-325,1000,-536,675,940,24,23,1000,326,-1000,-1000,273,1000,457,-822,-839,-90,-1000,-145,1000,-784,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00106() {
        org.junit.Assert.assertEquals("STATE:org.jfree.data.time.TimeSeries|getItemCount=22:java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "createCopy(int,int):org.jfree.data.time.TimeSeries",
            new int[]{-666,-474,746,-137,-480,701,-167,-359,-887,-386,276,-513,-1000,833,-988,-22,71,128,-271,-851,-716,874,349,651,351,376,-521,-313,-447,792,-51,-65,573,-763,868,-1000,-628,-103,944,1000,46,-1000,-709,-10,795,-1000,-469,927,-406,1000,-679,-688,29,1000,746,-561,-89,-475,318,737,42,-968,-318,37}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00107() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "createCopy(int,int):org.jfree.data.time.TimeSeries",
            new int[]{281,-358,727,207,-1000,-936,-295,-347,-789,641,-285,-621,12,-45,801,-1000,-1000,-1000,1000,-1000,-524,-224,324,985,154,976,-1000,839,-90,779,-1000,1000,1000,-970,-496,686,-382,-1000,705,515,-745,-266,924,992,-686,-480,948,-259,-268,822,1000,755,-1000,978,-1000,1000,-1000,36,-144,649,488,-794,220,446}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00108() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "createCopy(int,int):org.jfree.data.time.TimeSeries",
            new int[]{898,180,183,31,160,-436,345,-936,145,-193,369,202,-369,814,-295,-550,-411,-134,-2,-148,-246,-72,-477,403,585,442,-990,13,-894,-447,219,761,780,-205,342,-954,-236,-559,527,-294,714,980,-343,705,614,450,893,541,-960,757,404,-803,-262,480,-753,150,-591,-787,401,-278,-792,983,-422,883}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00109() {
        org.junit.Assert.assertEquals("STATE:org.jfree.data.time.TimeSeries|getItemCount=22:java.lang.Integer:Mg==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "createCopy(org.jfree.data.time.RegularTimePeriod,org.jfree.data.time.RegularTimePeriod):org.jfree.data.time.TimeSeries",
            new int[]{-176,380,-354,-704,-641,138,-288,-651,-955,531,-315,531,-816,666,-136,-195,-454,882,290,-531,929,-626,125,880,-440,-729,-707,828,804,-321,-143,864,301,33,-231,470,-194,957,-677,636,-212,841,967,-834,-852,-682,-69,802,293,921,572,140,-767,341,-718,-765,-608,919,-638,763,370,256,331,-338}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00110() {
        org.junit.Assert.assertEquals("STATE:org.jfree.data.time.TimeSeries|getItemCount=22:java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "createCopy(org.jfree.data.time.RegularTimePeriod,org.jfree.data.time.RegularTimePeriod):org.jfree.data.time.TimeSeries",
            new int[]{458,-184,657,50,272,604,-401,414,-727,154,795,-64,-394,-979,-399,-374,-26,691,-676,276,550,-295,-388,-61,-733,-822,-539,-481,321,-982,-184,-188,-528,233,1000,49,-313,687,119,1000,-478,566,-164,-457,-537,523,-24,-285,-711,-774,-798,-726,590,-308,555,-39,-511,-570,474,-108,-1000,-620,618,891}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00111() {
        org.junit.Assert.assertEquals("STATE:org.jfree.data.time.TimeSeries|getItemCount=22:java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "createCopy(org.jfree.data.time.RegularTimePeriod,org.jfree.data.time.RegularTimePeriod):org.jfree.data.time.TimeSeries",
            new int[]{-566,333,-1000,1000,-1000,1000,794,35,-1000,-131,-930,324,-749,349,-807,-869,-1000,1000,210,1000,804,82,-1000,284,-1000,-394,400,-1000,-397,-948,-848,869,-1000,326,1000,-88,-234,-1000,-562,1000,-116,852,971,-380,-1000,-13,-636,328,-1000,300,-1000,-214,-1000,-245,-1000,-317,-957,-93,854,706,-858,1000,15,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00112() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "createCopy(org.jfree.data.time.RegularTimePeriod,org.jfree.data.time.RegularTimePeriod):org.jfree.data.time.TimeSeries",
            new int[]{997,846,-277,65,-344,-43,-470,-701,-320,-169,158,534,-568,513,-141,-740,-604,-404,1000,1000,1000,-838,1000,-413,-624,-340,-916,1000,684,-296,-666,1000,636,-1000,548,1000,442,375,163,-222,-880,804,-504,-387,-1000,129,276,16,91,808,792,914,-1000,-320,162,-158,-286,1000,-231,-236,417,970,936,-184}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00113() {
        org.junit.Assert.assertEquals("STATE:org.jfree.data.time.TimeSeries|getItemCount=22:java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "createCopy(org.jfree.data.time.RegularTimePeriod,org.jfree.data.time.RegularTimePeriod):org.jfree.data.time.TimeSeries",
            new int[]{-1000,736,-1000,623,-742,167,-172,528,-330,-1000,-1000,590,-1000,-516,375,691,-833,420,303,604,482,207,-423,1000,-268,-1000,-739,-630,-479,-632,-479,1000,212,233,459,181,1000,-1000,-66,13,372,-276,211,567,-60,-532,1000,877,-1000,1000,-956,-435,-1000,-347,-999,-705,-528,839,-55,1000,1000,1000,627,517}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00114() {
        org.junit.Assert.assertEquals("STATE:org.jfree.data.time.TimeSeries|getItemCount=22:java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "createCopy(org.jfree.data.time.RegularTimePeriod,org.jfree.data.time.RegularTimePeriod):org.jfree.data.time.TimeSeries",
            new int[]{51,145,-608,-1000,-269,-407,-71,270,-291,-163,196,626,-833,668,107,48,-364,1000,-154,-40,194,731,-579,615,640,-47,-1000,597,589,-427,-749,644,669,332,490,176,570,-437,-1000,-984,-587,505,16,722,183,-221,-552,120,-647,983,647,-599,651,170,-703,-746,-1000,924,-326,1000,535,173,-126,-653}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00115() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "createCopy(org.jfree.data.time.RegularTimePeriod,org.jfree.data.time.RegularTimePeriod):org.jfree.data.time.TimeSeries",
            new int[]{1000,726,-878,-1000,-160,-1000,-156,488,141,472,-315,1000,-1000,-270,-667,1000,-278,1000,-1000,-557,1000,20,-1000,880,1000,-117,-1000,229,1000,-343,-1000,-212,189,33,1000,285,912,-1000,-805,-617,-1000,1000,-98,314,481,-261,-894,-1000,-887,292,407,-1000,-74,408,-593,-765,-1000,156,-90,1000,-58,-336,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00116() {
        org.junit.Assert.assertEquals("STATE:org.jfree.data.time.TimeSeries|getItemCount=22:java.lang.Integer:MQ==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "createCopy(org.jfree.data.time.RegularTimePeriod,org.jfree.data.time.RegularTimePeriod):org.jfree.data.time.TimeSeries",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00117() {
        org.junit.Assert.assertEquals("STATE:org.jfree.data.time.TimeSeries|getItemCount=22:java.lang.Integer:Ng==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "createCopy(org.jfree.data.time.RegularTimePeriod,org.jfree.data.time.RegularTimePeriod):org.jfree.data.time.TimeSeries",
            new int[]{-953,-254,-463,303,653,663,538,99,28,-670,815,-532,-22,893,1000,-552,366,-955,1000,-26,-1000,1000,317,-623,-464,-389,666,362,1,-39,208,1000,617,-484,-1000,-374,79,209,-435,-591,366,-1000,-441,187,149,639,-11,718,-461,1000,58,599,1000,-268,-474,-276,957,1000,-412,-92,1000,120,867,651}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00118() {
        org.junit.Assert.assertEquals("STATE:org.jfree.data.time.TimeSeries|getItemCount=22:java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "createCopy(org.jfree.data.time.RegularTimePeriod,org.jfree.data.time.RegularTimePeriod):org.jfree.data.time.TimeSeries",
            new int[]{75,293,-752,1000,38,-643,764,-69,196,-491,1000,840,-635,349,1000,211,20,-188,762,1000,-615,1000,-337,298,1000,-394,-1000,-1000,1000,2,-896,1000,1000,-251,-655,-88,1000,188,-929,-1000,-902,237,-551,1000,987,-474,-1000,328,-270,1000,1000,-177,1000,683,-947,-692,99,1000,-1000,1000,1000,99,356,-897}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00119() {
        org.junit.Assert.assertEquals("THROW:java.lang.IndexOutOfBoundsException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "delete(int,int):void",
            new int[]{912,-270,1000,1000,-783,-103,6,39,-853,-928,-422,-295,142,-1000,-414,1000,1000,-376,1000,-881,410,-1000,1000,-830,757,-948,1000,1000,-17,1000,1000,-350,-540,-1000,-1000,-1000,400,354,1000,-255,1000,1000,283,-638,391,1000,1000,-106,1000,1000,-27,1000,-1000,127,1000,1000,-833,-197,-1000,1000,-105,1000,1000,457}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00120() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "delete(int,int):void",
            new int[]{1000,-1000,-987,755,387,749,-124,-416,-1000,-397,-1000,-1000,591,-577,520,210,1000,731,625,-787,452,-983,138,-244,1000,549,1000,303,-965,670,-808,659,-622,-1000,-1000,-622,380,620,-238,223,1000,-547,-1000,172,-1000,-929,-598,-19,422,360,-551,816,-698,-87,-105,1000,-1000,779,-596,903,694,-512,156,104}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00121() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "delete(int,int):void",
            new int[]{425,402,-994,-830,213,852,4,-392,-72,738,-961,-885,288,-58,-989,-299,774,307,140,359,-217,-761,882,-596,946,412,581,795,-314,-583,756,963,-720,-738,-511,398,195,-487,-704,786,263,-430,-931,-160,377,-913,-800,126,845,837,-153,-806,-758,-495,-565,70,-302,-201,-32,-189,-94,-951,-514,-795}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00122() {
        org.junit.Assert.assertEquals("THROW:java.lang.IndexOutOfBoundsException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "delete(int,int):void",
            new int[]{972,-1000,-981,-886,-61,-676,-912,342,-308,-708,-572,529,827,-98,-936,-1000,-444,1000,-920,56,-630,468,1000,1000,753,-1000,-1000,1000,813,-1000,-177,286,586,74,-1000,-1000,1000,-339,1000,-916,-604,124,-379,-217,-98,-475,202,-650,-168,-759,-277,-154,240,-282,-915,-1000,1000,-35,-254,594,404,-80,-319,-301}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00123() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "delete(int,int):void",
            new int[]{0,568,-212,88,169,844,-580,508,-189,1000,776,163,-285,91,-423,878,-1000,-255,-1000,-456,1000,126,-96,918,5,-1000,-1000,1000,-421,-1000,888,-1000,1000,1000,513,360,1000,388,-1000,-339,-1000,-1000,-160,-781,1000,866,427,-1000,41,1000,-93,-1000,1000,-280,35,-559,0,-916,1000,-1000,1000,-1000,738,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00124() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "delete(int,int):void",
            new int[]{921,-1000,173,1000,-264,498,-1000,445,231,-1000,1000,-743,-507,692,-1000,779,397,147,781,-1000,-659,-863,-4,483,298,-987,1000,-35,222,947,370,472,1000,-960,-1000,-655,-1000,1000,-1000,-446,1000,859,1000,213,1000,-31,552,-569,-814,-878,1000,-1000,-845,-1000,-192,1000,-55,1000,665,198,376,493,404,77}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00125() {
        org.junit.Assert.assertEquals("THROW:java.lang.IndexOutOfBoundsException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "delete(int,int):void",
            new int[]{660,-1000,-1000,-605,102,-216,-1000,-46,197,-708,-134,-58,709,279,-936,-1000,-68,1000,-760,-159,-1000,0,557,-139,1000,198,-1000,1000,400,-862,-459,714,306,-400,-263,-46,1000,56,128,334,-18,400,129,151,165,-1000,-319,400,-9,-770,-147,192,-995,-111,-894,-408,1000,114,31,350,75,-160,-182,-188}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00126() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:Mg==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "delete(int,int):void",
            new int[]{865,-1000,54,1000,1000,2,-992,-253,297,482,-407,849,1000,401,-287,-1000,1000,970,598,-615,-1000,-931,625,-436,1000,168,-540,326,-105,-136,-1000,1000,1000,-978,-441,-1000,974,-4,-5,-296,1000,-367,283,876,855,-888,-781,1000,1000,-1000,-331,477,-1000,510,-1000,1000,708,-1000,1000,-1000,672,695,1000,-593}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00127() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:Mg==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "delete(int,int):void",
            new int[]{438,-1000,677,281,-54,-232,-972,555,-44,-926,1000,-523,386,-427,37,284,-1000,-938,-578,-316,-1000,58,-1000,72,24,611,947,779,-310,-1000,1000,-974,888,406,-951,-653,756,1000,764,-570,173,753,1000,528,397,1000,1000,324,-232,-1000,310,13,885,143,-1000,-240,503,-154,983,-304,1000,-403,71,756}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00128() {
        org.junit.Assert.assertEquals("THROW:java.lang.IndexOutOfBoundsException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "delete(int,int):void",
            new int[]{-185,-1000,292,137,-1000,-246,-614,1000,1000,-1000,1000,-251,-1000,963,-1000,-510,1000,504,-881,-989,-153,-1000,609,383,1000,-154,599,-400,749,1000,98,216,1000,35,-319,-682,-1000,1000,-793,850,-549,254,1000,1000,1000,-812,-6,611,-694,323,670,-1000,-1000,-1000,871,1000,-781,119,1000,-308,-97,870,-442,12}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00129() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:Nw==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "delete(org.jfree.data.time.RegularTimePeriod):void",
            new int[]{-511,751,-1000,-1000,-1000,577,-750,143,849,-248,-611,-1000,-1000,-592,1000,-980,611,623,-1000,-228,-507,289,-57,1000,-1000,515,-529,58,-927,-838,393,-1000,-1000,-341,-501,-1000,993,507,92,-582,-923,1000,872,864,-1000,-1000,175,-627,-39,243,255,153,-1000,925,-1000,550,-884,-514,171,-721,1000,374,636,916}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00130() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:Mw==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "delete(org.jfree.data.time.RegularTimePeriod):void",
            new int[]{-1000,980,357,696,-149,-111,637,-302,-1000,229,-627,568,305,-568,-779,469,1000,262,562,230,766,-255,-674,-724,1000,451,1000,718,-532,80,-570,562,151,305,154,-683,-1000,-679,1000,348,1000,-103,41,328,1000,-769,-296,207,16,1000,403,-11,667,-1000,-1000,1000,-170,-672,-121,-1000,-1000,-453,818,-808}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00131() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "delete(org.jfree.data.time.RegularTimePeriod):void",
            new int[]{1000,-772,-870,21,-238,-161,-1000,60,763,-291,292,-471,58,1000,751,-148,-925,-32,-852,-1000,278,-357,64,275,-1000,-651,-1000,504,658,-77,843,274,244,-596,-707,717,741,15,-319,202,-759,503,875,-751,-1000,1000,-162,-522,-158,454,-251,-776,1000,1000,893,-1000,1000,-627,-702,1000,1000,-635,10,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00132() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:Ng==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "delete(org.jfree.data.time.RegularTimePeriod):void",
            new int[]{340,291,-994,-626,-793,-120,617,331,22,-376,169,-828,-434,-263,333,-583,569,-161,-1000,-203,-623,-716,-17,435,197,1000,400,501,-729,-344,167,-648,-746,88,195,-996,89,289,537,336,-665,1000,-174,1000,-805,-430,1000,-709,344,313,389,486,-373,-432,-789,389,891,588,731,-190,687,444,362,812}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00133() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:MQ==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "delete(org.jfree.data.time.RegularTimePeriod):void",
            new int[]{1000,527,705,-938,-26,1000,1000,1000,599,-149,209,-215,-42,-352,372,-606,-1000,513,761,295,1000,935,-124,-369,-237,-536,807,677,338,-175,-618,246,313,978,-1000,-1000,100,1000,-590,-1,-320,109,315,-492,560,-373,138,699,569,249,-520,-130,648,-942,-633,-347,-604,253,-865,-468,652,367,432,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00134() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:MQ==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "delete(org.jfree.data.time.RegularTimePeriod):void",
            new int[]{1000,-916,-903,88,-260,137,-426,948,450,-720,414,-593,-15,700,187,-20,-568,-430,-1000,-953,272,-150,320,99,-711,175,-561,803,-178,-46,724,-20,125,39,-371,205,-868,750,208,548,-496,713,-261,138,-805,527,416,-424,414,613,-102,-427,1000,968,-521,-471,1000,190,-428,1000,687,281,-331,550}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00135() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:MTA=", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "delete(org.jfree.data.time.RegularTimePeriod):void",
            new int[]{610,-243,-736,-509,-567,-264,-311,6,599,-247,317,-491,59,522,605,-250,205,126,-989,-546,-138,-68,86,248,-181,327,-1000,588,-6,97,608,-96,-276,-247,-286,-154,489,-67,118,284,-599,619,462,419,-1000,711,-227,-490,204,189,475,-472,541,202,-21,-317,1000,22,-82,346,861,-292,116,344}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00136() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:Mw==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "delete(org.jfree.data.time.RegularTimePeriod):void",
            new int[]{463,892,-1000,-1000,-1000,344,432,-145,1000,-780,1000,-1000,-1000,-1000,1000,-1000,-328,318,-1000,-317,-806,-9,60,1000,-535,1000,-112,873,-1000,-1000,1000,-1000,-1000,22,-1000,-1000,1000,1000,184,17,680,1000,1000,1000,-1000,-887,175,-1000,1000,870,-130,1000,-373,-948,-1000,1000,354,-514,1000,-821,1000,249,838,572}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00137() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "delete(org.jfree.data.time.RegularTimePeriod):void",
            new int[]{231,-367,-792,968,570,-1000,-688,-740,-1000,774,-937,998,478,1000,-1000,1000,-615,126,-354,2,39,-991,-648,-641,1000,-503,-1000,-72,1000,1000,-347,1000,-237,-300,1000,1000,-1000,-1000,110,284,-599,36,440,419,455,1000,-353,262,-1000,-158,743,-472,-317,700,96,-317,1000,-188,-996,158,861,-1000,744,-519}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00138() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:MQ==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "delete(org.jfree.data.time.RegularTimePeriod):void",
            new int[]{-1000,121,-906,-830,-819,51,113,477,524,300,-982,-847,-564,-39,897,389,651,635,-1000,48,-19,-797,73,263,327,-408,-1000,-5,-881,266,287,-1000,-705,-156,-203,-1000,312,693,328,-759,54,1000,75,501,-1000,-239,660,-801,-497,-144,250,-1000,-695,-517,-544,206,1000,254,-1000,-224,902,245,191,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00139() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "delete(org.jfree.data.time.RegularTimePeriod):void",
            new int[]{144,1000,-1000,-1000,-358,-163,723,-283,1000,924,502,-283,-876,-850,582,-901,644,523,364,-714,-1000,730,-709,-164,-399,1000,1000,1000,-567,-326,982,-1000,-610,472,-101,-1000,-1000,1000,863,-176,-168,1000,-752,-381,1000,-1000,1000,-1000,-1000,875,-884,605,346,-1000,-833,532,213,-848,899,-1000,127,45,1000,985}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00140() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "equals(java.lang.Object):boolean",
            new int[]{163,456,1000,-15,-40,659,788,219,1000,-689,-103,1000,288,287,-282,387,-36,-1000,1000,-528,-1000,-227,-1000,-1000,546,226,-74,399,13,-994,541,632,582,320,966,642,672,-626,464,1000,-541,-879,291,332,827,82,-728,1000,1000,-437,-1000,660,872,689,-508,1000,-1000,275,289,304,72,-847,858,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00141() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "equals(java.lang.Object):boolean",
            new int[]{55,1000,1000,-559,384,573,1000,804,1000,-689,394,1000,378,594,145,-376,150,-1000,1000,-89,-1000,-61,-1000,-1000,155,-395,-611,77,-402,-663,67,727,597,269,1000,642,1000,36,68,1000,-1000,-1000,41,-42,1000,429,59,1000,1000,-974,-1000,659,888,1000,-143,1000,-56,-1000,282,278,218,-1000,642,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00142() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "equals(java.lang.Object):boolean",
            new int[]{1000,-1000,1000,310,161,419,-45,-964,1000,-243,423,204,380,883,-895,679,-1000,-1000,-141,473,467,-1000,-125,-496,1000,1000,-887,-343,1000,-645,473,-454,-676,-37,-54,77,-1000,451,666,1000,-1000,-1000,-504,806,-227,497,178,-483,810,-755,-896,414,-223,-89,-243,-679,-1000,1000,650,-35,575,615,840,-208}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00143() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "equals(java.lang.Object):boolean",
            new int[]{1000,-923,604,1000,1000,150,489,331,-1000,148,99,-99,335,45,405,370,-637,-1000,-803,-522,954,575,-1000,-652,989,-159,-450,800,1000,916,794,-69,-331,-86,-370,1000,489,413,-994,803,-153,5,111,1000,-1000,1000,637,735,-955,1000,-17,-136,529,-587,-1000,-1000,1000,402,224,169,207,-582,877,-692}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00144() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "equals(java.lang.Object):boolean",
            new int[]{-402,1000,-1000,-70,1000,-221,223,620,-1000,-323,-316,-653,-9,-230,1000,130,743,708,-735,-566,-27,1000,-732,312,370,821,-727,540,-1000,1000,-121,510,999,-1000,-51,313,1000,111,-147,-267,387,-145,-387,164,-163,-119,960,1000,-580,280,1000,12,1000,70,-1000,-159,673,15,-979,746,600,-1000,898,-716}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00145() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "equals(java.lang.Object):boolean",
            new int[]{62,-547,-872,388,867,-341,-321,167,-1000,323,-41,-1000,419,157,714,429,7,702,-1000,-594,1000,967,-119,745,582,1000,-629,-15,-465,1000,209,201,371,-1000,-814,204,321,571,-606,-267,567,113,-92,278,-417,-70,1000,80,-445,375,1000,135,848,-695,-680,-1000,581,1000,-677,68,405,-975,947,-38}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00146() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "equals(java.lang.Object):boolean",
            new int[]{1000,-923,1000,735,-261,222,-91,-699,1000,-1000,-68,1000,-121,1000,-1000,588,-1000,-1000,-141,21,-652,-134,-1000,-701,251,1000,-777,320,945,-875,794,-78,-808,-741,-32,907,-1000,542,-3,1000,-1000,-1000,-1000,477,-736,491,-1000,30,1000,-794,-1000,1000,269,959,-811,-74,-1000,523,1000,-486,506,-160,761,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00147() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "equals(java.lang.Object):boolean",
            new int[]{-324,456,-122,1000,-955,854,-579,219,-9,-834,1000,200,288,-120,-1000,-1000,362,-79,-1000,608,1000,-12,-299,559,1000,-810,477,836,347,1000,1000,909,105,320,-999,642,672,6,-1000,1000,-219,1000,-685,271,-1000,-309,-422,652,-1000,825,597,-784,1000,-1000,454,-547,-836,1000,-366,-963,-850,-527,858,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00148() {
        org.junit.Assert.assertEquals("TYPE:org.jfree.data.time.TimeSeriesDataItem", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getDataItem(int):org.jfree.data.time.TimeSeriesDataItem",
            new int[]{281,-532,267,675,-146,267,-215,-863,50,-645,-345,-413,1000,-318,137,288,-525,-61,-288,367,-721,-596,476,-1000,283,259,-838,-512,1000,-54,197,1000,-1000,63,601,-120,855,-172,1000,178,-83,913,-1000,568,-500,-359,-256,-745,1000,15,-240,696,-818,1000,124,-199,-1000,-136,-513,674,1000,466,172,-239}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00149() {
        org.junit.Assert.assertEquals("THROW:java.lang.IndexOutOfBoundsException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getDataItem(int):org.jfree.data.time.TimeSeriesDataItem",
            new int[]{1000,-699,505,-343,592,439,-291,1000,996,359,-510,-168,-322,-758,-110,-615,1000,74,-691,-417,1000,450,200,1000,-59,-655,-347,-830,-980,1000,292,-823,362,-794,-297,446,-616,56,-1000,-710,-952,-1000,883,-895,1000,-21,830,845,-1000,-28,514,-343,-596,-1000,-2,71,551,1000,194,-480,-326,-10,-36,784}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00150() {
        org.junit.Assert.assertEquals("THROW:java.lang.IndexOutOfBoundsException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getDataItem(int):org.jfree.data.time.TimeSeriesDataItem",
            new int[]{390,-622,1000,8,317,10,-656,-906,-234,-1000,-57,754,876,205,19,732,-1000,-486,-127,801,450,-499,-74,-1000,-632,-143,-282,-784,1000,-850,-44,1000,-40,123,252,-632,-133,-71,1000,677,-21,939,-1000,346,319,467,-1000,-196,1000,-1000,-389,123,-452,1000,6,539,642,-763,-790,-522,-329,1000,673,-362}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00151() {
        org.junit.Assert.assertEquals("THROW:java.lang.IndexOutOfBoundsException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getDataItem(int):org.jfree.data.time.TimeSeriesDataItem",
            new int[]{-655,-196,-743,723,-477,529,-279,-773,-125,-273,-392,-1000,1000,130,616,444,-525,712,71,367,-1000,-1000,868,-1000,423,180,-1000,210,1000,412,546,943,-1000,408,411,143,1000,284,1000,145,-378,722,-327,1000,-1000,-505,-130,-858,1000,-223,322,1000,-1000,905,739,-199,-1000,128,-802,1000,1000,-353,-188,-354}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00152() {
        org.junit.Assert.assertEquals("THROW:java.lang.IndexOutOfBoundsException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getDataItem(int):org.jfree.data.time.TimeSeriesDataItem",
            new int[]{-488,-832,1000,-685,893,43,100,-241,-192,-944,638,1000,577,342,1000,834,-295,278,511,544,993,-188,-845,-1000,-704,-1000,-199,-815,659,-734,-573,501,194,1000,-179,-718,-433,618,580,464,-160,314,-380,86,-802,771,-807,109,607,-1000,-97,-648,-429,867,488,-22,947,-948,50,-340,-648,689,-354,216}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00153() {
        org.junit.Assert.assertEquals("TYPE:org.jfree.data.time.TimeSeriesDataItem", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getDataItem(int):org.jfree.data.time.TimeSeriesDataItem",
            new int[]{-895,-1000,-818,-798,1000,494,-113,-535,-631,937,954,1000,-89,646,1000,817,-587,307,589,-111,-580,824,-994,1000,-1000,194,53,162,-460,509,-1000,-1000,1000,723,876,466,-1000,1000,-400,-234,-1000,-534,1000,259,1000,633,-166,1000,-297,-1000,-14,-747,277,-644,1000,1000,1000,-627,-718,-1000,-1000,971,882,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00154() {
        org.junit.Assert.assertEquals("TYPE:org.jfree.data.time.TimeSeriesDataItem", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getDataItem(int):org.jfree.data.time.TimeSeriesDataItem",
            new int[]{623,-1000,1000,-626,1000,959,111,311,487,1000,305,-735,-256,-1000,1000,1000,-97,694,-154,120,1000,558,84,1000,755,-806,13,125,-1000,223,-210,-1000,1000,234,1000,527,-1000,507,-1000,-1000,-1000,-154,855,-806,1000,-1000,-642,615,-975,1000,-430,-1000,176,-1000,256,-1000,501,1000,1000,-708,-308,-1000,-676,781}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00155() {
        org.junit.Assert.assertEquals("THROW:java.lang.IndexOutOfBoundsException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getDataItem(int):org.jfree.data.time.TimeSeriesDataItem",
            new int[]{1000,-1000,1000,-660,494,459,-208,-666,-162,158,145,611,95,-1000,1000,1000,-648,855,862,218,1000,-11,-231,189,-540,-254,-613,552,184,-112,-1000,-924,310,1000,-740,-974,-485,1000,-400,-147,-975,-745,1000,619,-193,18,75,478,-182,540,265,-555,13,-443,1000,-89,523,13,-35,184,-1000,-386,-508,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00156() {
        org.junit.Assert.assertEquals("THROW:java.lang.IndexOutOfBoundsException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getDataItem(int):org.jfree.data.time.TimeSeriesDataItem",
            new int[]{1000,-850,-393,-566,494,114,-228,959,-162,330,-431,-19,-87,-218,-673,-740,366,71,298,-490,-338,138,-1000,730,50,51,-108,-894,-1000,966,-876,-511,219,-132,-740,802,-788,-72,-418,248,-529,457,785,-308,730,413,625,130,-291,-1,258,-512,311,-641,-255,541,523,86,570,-377,-178,-492,470,178}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00157() {
        org.junit.Assert.assertEquals("THROW:java.lang.IndexOutOfBoundsException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getDataItem(int):org.jfree.data.time.TimeSeriesDataItem",
            new int[]{-1000,-406,-1000,384,-723,-1000,623,218,-12,-808,-166,-589,560,-69,-1000,-628,-345,182,1000,-390,-1000,-198,-1000,-616,-354,1000,-1000,-274,877,1000,-491,1000,-622,203,-1000,-199,410,-123,1000,962,-527,696,-547,806,130,-356,-853,-1000,1000,-19,712,725,-156,843,-16,22,81,-394,1000,-621,517,-683,-639,142}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00158() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getDataItem(org.jfree.data.time.RegularTimePeriod):org.jfree.data.time.TimeSeriesDataItem",
            new int[]{198,1000,1000,310,-1000,948,1000,-1000,-473,-427,1000,-1000,-1000,50,1000,-369,1000,-225,13,1000,696,652,-1000,-1000,-169,446,345,151,-702,-42,844,-1000,-3,-684,222,1000,-823,862,-1000,1000,-291,1000,-1000,-46,709,1000,-33,1000,-234,-1000,859,-1000,698,-451,-749,336,0,-479,583,1000,749,-737,1000,-17}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00159() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getDataItem(org.jfree.data.time.RegularTimePeriod):org.jfree.data.time.TimeSeriesDataItem",
            new int[]{-709,-454,333,7,640,159,1000,-441,456,78,104,-787,142,13,-531,214,494,-1000,389,914,291,-646,862,-448,1000,298,321,249,-274,-334,-13,-800,-350,-307,166,703,-517,-137,457,-971,560,48,1000,-503,87,-839,110,315,655,638,-14,-785,94,944,-1000,-113,-193,-156,541,326,549,399,368,-116}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00160() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getDataItem(org.jfree.data.time.RegularTimePeriod):org.jfree.data.time.TimeSeriesDataItem",
            new int[]{-505,1000,179,310,-380,523,898,-1000,-473,-131,1000,425,-475,28,343,1000,936,972,-534,-1000,-458,1000,-702,-1000,370,1000,345,496,1000,-42,124,1000,-399,-684,1000,196,1000,862,-194,196,200,1000,393,1000,-1000,1000,-319,258,-1000,-586,945,248,586,-386,-268,-275,-731,-575,-22,-1000,-1000,-58,1000,462}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00161() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getDataItem(org.jfree.data.time.RegularTimePeriod):org.jfree.data.time.TimeSeriesDataItem",
            new int[]{-442,-318,-556,-743,-158,636,919,-446,254,740,521,-656,751,144,-685,834,912,-476,-56,-958,807,-708,-298,-192,961,-23,792,66,-556,-713,-372,-789,-401,-25,-612,179,-329,45,-250,399,-275,-937,703,180,-405,-617,-362,-699,373,939,556,-447,910,945,-851,-165,205,-711,-245,-979,147,730,-240,271}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00162() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getDataItem(org.jfree.data.time.RegularTimePeriod):org.jfree.data.time.TimeSeriesDataItem",
            new int[]{329,-222,668,525,-812,-473,998,-462,708,-134,73,83,-825,-1000,-33,401,689,-793,-1000,-955,1000,483,146,-1000,220,403,-153,1000,208,-266,643,-141,-108,-798,321,578,899,118,-368,-294,-239,687,202,402,-723,740,-1000,624,-1000,-429,603,1000,-164,1000,-1000,19,-1000,-371,-588,-453,-205,762,-1000,360}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00163() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getDataItem(org.jfree.data.time.RegularTimePeriod):org.jfree.data.time.TimeSeriesDataItem",
            new int[]{428,-167,-356,179,-911,-10,253,-938,894,-772,-68,492,-1000,-65,1000,-449,-414,221,-678,-166,-933,1000,-448,-472,-193,-619,-763,793,-1000,-672,-1000,-350,283,-1000,636,241,-258,-340,-1000,1000,729,192,-544,1000,975,535,-161,803,-637,-516,-238,252,-1000,-573,-320,-228,-998,-6,-153,-709,677,717,1000,252}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00164() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getDataItem(org.jfree.data.time.RegularTimePeriod):org.jfree.data.time.TimeSeriesDataItem",
            new int[]{124,-77,639,1000,-605,-540,890,-266,389,-401,-6,41,-1000,-1000,186,1000,-9,-448,-1000,-594,-1000,1000,509,-1000,188,-131,122,1000,1000,102,625,-527,457,-1000,1000,190,1000,-1000,192,-80,1000,1000,576,1000,-639,-901,-1000,1000,-1000,-1000,619,1000,-813,-201,-268,-81,-1000,-456,-726,-1000,-393,492,-630,-262}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00165() {
        org.junit.Assert.assertEquals("TYPE:org.jfree.data.time.TimeSeriesDataItem", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getDataItem(org.jfree.data.time.RegularTimePeriod):org.jfree.data.time.TimeSeriesDataItem",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00166() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getDataItem(org.jfree.data.time.RegularTimePeriod):org.jfree.data.time.TimeSeriesDataItem",
            new int[]{150,476,388,-270,51,904,-478,-1000,1000,1000,627,-1000,566,-205,678,504,1000,-1000,181,542,1000,-882,-1000,-1000,647,-887,-191,-101,-546,-1000,-1000,-1000,369,279,1000,1000,-1000,1000,-368,618,43,-171,-376,-21,325,-607,-1000,-59,704,1000,578,-1000,477,-76,-315,855,868,129,1000,778,742,-17,923,-454}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00167() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getDataItem(org.jfree.data.time.RegularTimePeriod):org.jfree.data.time.TimeSeriesDataItem",
            new int[]{-331,1000,457,49,-823,904,-479,-1000,-143,1,1000,-1000,157,499,348,-40,1000,-261,629,20,1000,-1000,-536,917,15,-419,1000,-1000,-659,-927,-778,-542,369,105,-356,930,-1000,835,74,367,88,230,-806,348,934,-129,4,592,734,874,864,-1000,960,859,-889,-945,552,-936,1000,1000,135,224,1000,-78}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00168() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getDataItem(org.jfree.data.time.RegularTimePeriod):org.jfree.data.time.TimeSeriesDataItem",
            new int[]{33,-524,-918,716,1000,408,-180,117,-302,-322,-737,450,-339,-1000,442,781,-901,1000,-109,-1000,-1000,346,-445,357,-58,-792,807,572,695,79,-780,1000,67,82,1000,-780,880,-1000,-659,-869,1000,943,-845,936,-113,-668,-100,-1000,11,-1000,58,1000,-480,-999,11,-1000,174,-1000,140,-1000,-304,409,-818,459}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00169() {
        org.junit.Assert.assertEquals("java.lang.String:VGltZQ==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getDomainDescription():java.lang.String",
            new int[]{807,-38,1000,644,-358,-904,-144,-881,441,-1000,676,1000,-519,-637,426,-61,1000,48,-253,25,-941,344,492,-221,750,-622,476,-1000,887,505,-796,1000,-652,-1000,548,95,-220,1000,-290,-525,382,715,-187,33,305,226,-263,-826,-1000,472,-552,952,-389,-288,-153,627,-181,1000,-585,-105,-1000,-595,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00170() {
        org.junit.Assert.assertEquals("java.lang.String:KzB4ODAw", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getDomainDescription():java.lang.String",
            new int[]{-696,-972,-870,361,1000,589,-598,939,-553,-869,-749,231,-967,989,497,-202,480,238,875,-376,731,-1000,-600,-454,-382,771,554,1000,1000,-683,522,-898,-39,-596,645,340,-1000,-758,1000,155,-613,-60,848,177,380,874,109,-456,911,300,-282,1000,-1,-490,-571,286,-962,-281,-208,506,-584,1000,-71,-625}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00171() {
        org.junit.Assert.assertEquals("java.lang.String:VGltZQ==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getDomainDescription():java.lang.String",
            new int[]{334,-357,-659,1000,236,-1000,785,607,179,-278,-1000,265,-120,206,-835,-739,-295,172,1000,-881,-1000,2,653,-1000,172,-390,-629,-1000,716,-952,647,-407,-469,-1000,-473,-320,-31,-1000,83,848,-592,269,-573,1000,1000,956,71,929,192,-1000,-274,846,-609,-388,-1000,-643,826,-24,-607,742,326,-213,-250,651}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00172() {
        org.junit.Assert.assertEquals("java.lang.String:VGltZQ==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getDomainDescription():java.lang.String",
            new int[]{-511,516,1000,790,275,-406,-15,308,-823,-314,-1000,-673,602,-661,905,-1000,-227,687,227,-167,731,-633,651,-142,727,1000,1000,111,1000,999,269,-1000,-762,-221,-583,405,-443,-343,584,-1000,671,918,1000,-410,-491,87,1000,-1000,216,-37,506,1000,994,-533,459,-157,-572,-694,-636,1000,1000,976,-1000,-975}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00173() {
        org.junit.Assert.assertEquals("java.lang.String:VGltZQ==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getDomainDescription():java.lang.String",
            new int[]{58,-1000,-519,756,1000,784,985,438,-301,-185,200,582,-503,870,-208,1000,-23,-1000,-133,1000,-1000,143,1000,29,640,-1000,-733,978,-1000,-499,271,1000,366,-264,274,55,-320,1000,198,1000,593,266,-718,741,774,-641,-1000,-368,-206,90,-1000,27,-927,368,-50,156,1000,518,241,-1000,-811,-478,303,487}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00174() {
        org.junit.Assert.assertEquals("java.lang.String:VGltZQ==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getDomainDescription():java.lang.String",
            new int[]{25,248,-1000,878,-871,784,-13,572,-1000,499,-1000,-591,-821,193,546,-1000,-241,345,368,689,278,566,735,620,640,1000,-1000,-252,1000,247,1000,-392,-225,727,-370,-677,-525,-9,1000,1000,-233,317,505,640,-532,48,21,-368,-206,-751,-885,-247,580,-384,-50,-1000,1000,-625,-48,-129,396,-458,-162,512}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00175() {
        org.junit.Assert.assertEquals("java.lang.String:VGltZQ==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getDomainDescription():java.lang.String",
            new int[]{-632,-1000,-899,644,1000,59,-5,1000,-154,-717,-1000,328,101,-299,-265,-656,-3,-324,1000,-1000,-941,-809,-35,0,-939,346,-820,-580,887,-1000,434,1000,1000,-46,-275,299,1000,-1000,-516,1000,382,-342,-52,728,1000,226,546,762,1000,-442,722,227,-1000,1000,-857,-1000,1000,-1000,-150,-529,1000,1000,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00176() {
        org.junit.Assert.assertEquals("java.lang.String:VGltZQ==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getDomainDescription():java.lang.String",
            new int[]{-1000,564,-1000,796,1000,462,-446,498,-1000,657,-885,-1000,-273,-370,-557,629,-227,687,1000,502,708,972,604,-50,855,413,329,1000,1000,-1000,130,204,134,379,-583,-478,1000,-1000,-557,54,-736,-351,403,-267,-491,-590,-92,352,1000,329,-481,-261,661,1000,310,-689,-714,-1000,-776,475,1000,1000,645,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00177() {
        org.junit.Assert.assertEquals("java.lang.String:VGltZQ==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getDomainDescription():java.lang.String",
            new int[]{33,-127,-1000,863,-483,394,358,540,-833,499,-1000,-591,-1000,-73,898,-1000,-171,484,920,411,-64,566,1000,-972,770,1000,-996,-532,1000,-170,1000,-229,-225,406,-737,-725,-564,-827,803,994,859,69,726,955,-48,48,258,-208,-252,-751,-1000,-128,908,-784,-510,-1000,677,-597,-348,291,-400,-578,-250,850}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00178() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTQ=", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getIndex(org.jfree.data.time.RegularTimePeriod):int",
            new int[]{178,-299,1000,-1000,-426,-960,329,-8,-131,-609,372,657,-1000,-631,-788,-231,784,793,1000,977,-1000,186,1000,363,-1000,-1000,648,-368,-216,-266,-147,697,1000,416,-296,-327,-557,-730,-859,451,-550,625,-656,-1000,1000,-1000,987,949,-746,-397,887,1000,1000,1000,-506,210,1000,1000,-582,54,1000,666,-917,476}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00179() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getIndex(org.jfree.data.time.RegularTimePeriod):int",
            new int[]{-565,416,56,-297,-391,144,91,70,1000,-548,-1000,-948,228,1000,226,-1000,28,-390,-955,215,1000,-1000,50,1000,62,1000,818,163,511,-962,543,526,-798,938,695,-1000,-27,900,-1000,1000,538,-1000,-1000,-177,395,-780,406,601,25,731,-201,138,227,1000,-110,-633,-933,582,1000,-413,-1000,550,-148,-590}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00180() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getIndex(org.jfree.data.time.RegularTimePeriod):int",
            new int[]{226,221,-1000,-318,401,601,-236,-257,681,-35,-79,-490,20,185,739,-158,-519,-388,-688,-967,-647,81,-102,1000,319,-564,297,544,-571,-104,414,348,-60,-341,-295,-707,-395,-758,-361,-498,541,87,37,1000,-312,-412,-70,465,488,706,331,355,-694,580,-186,-609,-300,-782,180,-534,-401,-701,366,-725}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00181() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getIndex(org.jfree.data.time.RegularTimePeriod):int",
            new int[]{-304,632,424,432,-452,969,-48,-636,-24,-475,-350,-421,961,-452,220,-549,346,-867,-465,-211,479,-202,-621,957,-547,-734,-420,129,960,420,-882,583,-84,-678,102,-789,893,-676,533,987,-852,-161,-306,59,-429,-904,-314,337,-782,367,135,-34,287,559,429,-71,343,815,980,-852,-593,832,-60,941}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00182() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getIndex(org.jfree.data.time.RegularTimePeriod):int",
            new int[]{204,367,536,439,-583,343,-309,-534,-676,63,1000,797,529,-1000,1000,-464,75,-258,683,-26,-1000,232,-721,90,-519,-1000,-288,259,699,630,-1000,373,78,-619,-133,785,804,-978,964,782,-1000,335,339,93,-398,-805,-415,558,635,337,803,584,1000,-1000,1000,151,947,868,62,-734,615,437,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00183() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTM=", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getIndex(org.jfree.data.time.RegularTimePeriod):int",
            new int[]{378,-492,-949,-19,897,-717,-892,-279,-209,937,-844,-923,-341,750,-752,677,-383,-1,825,509,892,-802,347,103,219,447,-310,463,419,260,288,20,705,115,273,-855,-888,149,-79,360,230,920,609,280,921,955,172,521,-916,-67,-921,362,-326,778,-853,-248,173,677,-336,-562,506,-889,726,-585}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00184() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getIndex(org.jfree.data.time.RegularTimePeriod):int",
            new int[]{1000,-1000,4,-859,1000,999,-624,-1000,-737,1000,553,184,-1000,583,-790,1000,-169,1000,249,-152,-280,1000,1000,-1000,123,-248,855,-98,-1000,930,-899,117,1000,-844,509,-747,-1000,594,-577,-1000,72,1000,776,-169,95,-274,-6,1000,-433,-823,-838,1000,-450,-1000,0,-352,1000,-625,-1000,334,916,-1000,-54,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00185() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getIndex(org.jfree.data.time.RegularTimePeriod):int",
            new int[]{-457,-189,-966,886,180,999,-517,321,-707,442,65,-405,186,734,385,-449,-603,-404,-601,-967,947,-194,-935,788,743,746,486,650,-446,235,-899,-938,-885,-844,651,-747,821,594,811,-14,183,-323,180,693,788,129,-908,-977,844,665,-838,-649,-450,773,832,-353,-481,-802,330,-767,-718,-522,-645,-558}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00186() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTEw", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getIndex(org.jfree.data.time.RegularTimePeriod):int",
            new int[]{-550,-178,-1000,1000,846,601,-707,634,-876,352,446,-418,923,444,811,294,-1000,-1000,-688,-967,947,81,-606,1000,1000,-634,297,1000,-747,731,-878,-1000,-924,-1000,-19,-540,652,-731,137,-1000,183,-512,1000,1000,-312,757,-1000,-1000,1000,733,108,-1000,-997,1000,430,-1000,-1000,-1000,-240,-475,-1000,-1000,366,-607}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00187() {
        org.junit.Assert.assertEquals("java.lang.Integer:NQ==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getItemCount():int",
            new int[]{-400,1000,-1000,1000,278,-441,-556,-327,400,-844,-876,726,1000,1000,-1000,281,-1000,653,117,483,117,1000,-166,942,-184,-869,-447,-30,1000,834,932,-1000,1000,346,-1000,108,599,-382,1000,106,1000,84,-1000,1000,139,-373,1000,630,1000,554,-1000,-1000,-836,-220,447,-848,-1000,1000,818,-78,-1000,1000,-4,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00188() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getItemCount():int",
            new int[]{1000,823,-1000,286,119,1000,-1000,-541,-452,499,-876,318,372,-19,-1000,281,445,55,-594,-278,937,-900,-138,1000,-861,-275,1000,-633,-1000,533,932,-775,229,-491,-1000,-1000,-294,469,749,-434,-437,-58,-1000,-936,-931,-1000,889,967,1000,554,-439,-552,-911,371,-395,-207,-671,448,-5,875,-865,571,-1000,-183}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00189() {
        org.junit.Assert.assertEquals("java.lang.Integer:MQ==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getItemCount():int",
            new int[]{-856,428,600,1000,136,-32,-468,832,871,-715,198,-375,864,461,-896,-1000,-703,1000,1000,452,535,-388,-264,1000,66,-1000,-100,837,-44,957,-70,-556,1000,117,-1000,-591,617,-1000,65,-779,1000,1000,712,-152,-427,-790,1000,-418,1000,722,-1000,-427,-1000,1000,1000,-330,-799,1000,427,-1000,-113,1000,100,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00190() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getItemCount():int",
            new int[]{-301,-323,-1000,1000,674,-104,-556,1000,1000,174,-270,-113,366,-325,504,670,387,-825,1000,-367,33,178,-523,308,523,-185,741,199,-644,691,932,71,-226,702,-287,-463,-594,-382,677,-1000,1000,-678,-1000,-966,139,-373,-1000,969,280,554,11,678,367,981,-797,947,844,-460,818,-1000,1000,528,224,621}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00191() {
        org.junit.Assert.assertEquals("java.lang.Integer:NA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getItemCount():int",
            new int[]{474,428,-667,-1000,1000,279,-468,181,116,162,-688,-375,-1000,1000,724,331,-59,259,150,-1000,-122,-388,-264,230,-53,1000,-265,-854,-1000,-299,98,926,610,507,-252,685,-1000,568,328,1000,-711,845,-400,-558,-1000,-143,-1000,400,288,-57,311,208,-658,-282,587,530,1000,-125,-1000,-1000,429,365,262,400}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00192() {
        org.junit.Assert.assertEquals("java.lang.Integer:Mw==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getItemCount():int",
            new int[]{-1000,524,491,1000,-220,49,-1000,792,1000,-690,-341,537,1000,533,-120,-600,166,751,1000,-1000,-23,1000,-804,95,206,-373,1000,-317,-644,1000,-1000,-1000,1000,65,-1000,1000,371,-568,508,557,839,-1000,-1000,-805,-817,-1000,410,1000,1000,-646,-472,-1000,-1000,1000,-319,-256,331,248,-50,-1000,939,1000,346,-134}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00193() {
        org.junit.Assert.assertEquals("java.lang.Integer:NA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getItemCount():int",
            new int[]{1000,216,-239,1000,80,-142,-5,466,-879,-854,1000,-225,1000,1000,-49,-1000,-1000,754,-633,-1000,765,780,127,-608,-92,893,206,-1000,-100,970,443,-1000,-176,396,-1000,-1000,-934,-920,940,941,21,477,332,137,-635,-1000,-934,667,118,382,792,-717,-49,-381,-642,651,-371,-187,-121,809,463,313,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00194() {
        org.junit.Assert.assertEquals("java.lang.Integer:MQ==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getItemCount():int",
            new int[]{-541,-990,1000,-118,563,-1000,-1000,249,429,-600,697,-1000,195,1000,1000,753,679,312,-1000,68,-1000,100,341,364,1000,317,-1000,-936,735,-708,-1000,470,-394,-1000,-381,100,-1000,97,-452,-465,269,1000,691,-655,163,-1000,-223,-298,1000,-581,1000,-387,-109,-127,318,582,-58,-1000,-1000,660,1000,-113,-855,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00195() {
        org.junit.Assert.assertEquals("TYPE:java.util.Collections$UnmodifiableRandomAccessList", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getItems():java.util.List",
            new int[]{1000,-1000,-1000,-908,1000,759,168,1,-1000,864,628,-770,658,1000,-34,100,85,-667,-778,1000,-664,-687,-197,65,-582,1000,1000,881,19,845,1000,-1000,508,966,-1000,-897,1000,-735,945,427,325,1000,458,639,-102,641,822,440,657,727,975,-560,-1000,1000,-126,-1000,1000,106,-1000,1000,-544,1000,135,768}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00196() {
        org.junit.Assert.assertEquals("TYPE:java.util.Collections$UnmodifiableRandomAccessList", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getItems():java.util.List",
            new int[]{-386,983,-1000,-315,-1000,291,358,-1000,-258,788,702,600,46,-635,1000,216,825,869,-354,12,-167,1000,252,-794,320,-966,-778,-1000,1000,881,255,-399,-626,911,484,87,619,512,-1000,-702,-721,149,924,-1000,-1000,737,-233,533,-841,893,505,594,-382,-1000,-451,354,-48,-495,-693,92,70,-594,-1000,-844}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00197() {
        org.junit.Assert.assertEquals("TYPE:java.util.Collections$UnmodifiableRandomAccessList", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getItems():java.util.List",
            new int[]{374,1000,336,518,-1000,-831,99,-1000,1000,-1000,-989,517,-697,-351,197,2,322,774,1000,-469,1000,-69,-154,-108,638,-1000,-1000,-317,-579,-116,-1000,1000,-55,-894,699,1000,-1000,1000,-1000,16,-988,-256,20,-861,-110,-612,-24,-734,-1000,412,-342,-110,992,480,495,1000,-62,603,1000,-1000,-358,-1000,-798,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00198() {
        org.junit.Assert.assertEquals("TYPE:java.util.Collections$UnmodifiableRandomAccessList", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getItems():java.util.List",
            new int[]{258,-1000,6,-878,-1000,618,1000,920,-506,-306,388,-432,599,1000,-541,-106,-971,-858,-536,883,-948,6,1000,-284,781,1000,1000,-167,-437,560,552,234,-951,282,990,-769,204,849,-226,205,1000,-220,639,-78,1000,177,602,123,629,610,539,473,229,1000,-508,-185,1000,368,-497,1000,-425,418,-509,-400}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00199() {
        org.junit.Assert.assertEquals("TYPE:java.util.Collections$UnmodifiableRandomAccessList", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getItems():java.util.List",
            new int[]{548,28,-303,244,-856,-846,-152,-273,412,-108,-968,601,-364,360,334,-59,1000,915,574,321,565,907,-90,-54,-64,-856,57,465,-680,780,152,393,369,77,-185,91,-543,1000,-621,333,-108,617,106,-548,321,-348,834,-450,-175,-103,604,-767,849,730,-952,1000,1000,589,57,-365,-386,-906,-912,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00200() {
        org.junit.Assert.assertEquals("TYPE:java.util.Collections$UnmodifiableRandomAccessList", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getItems():java.util.List",
            new int[]{-276,-586,-72,-817,-253,868,1000,803,-612,330,708,-87,-1000,947,759,-806,1000,158,-2,727,-659,1000,1000,-933,666,-338,232,-763,1000,1000,-72,-257,-1000,284,1000,-555,-125,448,-761,-733,1000,304,644,-251,867,229,257,982,625,533,228,432,452,751,-730,64,1000,49,-232,588,-501,14,557,-844}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00201() {
        org.junit.Assert.assertEquals("TYPE:java.util.Collections$UnmodifiableRandomAccessList", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getItems():java.util.List",
            new int[]{-180,215,144,-1000,-216,1000,-255,614,-662,-972,146,-889,402,-1000,-321,172,-461,121,-847,698,-1000,-538,841,-919,1000,-20,-374,-1000,893,-547,-229,505,-1000,-221,1000,252,701,609,-174,-805,715,-1000,1000,-100,569,741,-95,991,-570,121,-1000,1000,730,-171,620,-466,864,-284,70,718,-361,679,711,-400}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00202() {
        org.junit.Assert.assertEquals("TYPE:java.util.Collections$UnmodifiableRandomAccessList", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getItems():java.util.List",
            new int[]{-253,974,-172,324,-740,-886,558,-921,689,182,-782,847,-497,358,837,-98,546,514,936,-674,527,-965,-357,722,-545,-799,20,352,-302,531,-56,665,-406,196,-762,245,-583,422,-424,-739,891,672,165,-348,-577,-710,-799,-509,755,319,-371,-770,842,-789,-77,-141,-601,298,224,-578,-193,-970,-507,750}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00203() {
        org.junit.Assert.assertEquals("TYPE:java.util.Collections$UnmodifiableRandomAccessList", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getItems():java.util.List",
            new int[]{479,-1000,-515,-589,96,204,331,1000,-1000,-435,-62,-1000,457,940,-1000,344,-173,869,-1000,968,-311,14,576,-342,-380,492,1000,-1000,255,-139,1000,-427,268,911,-38,-83,1000,512,483,62,745,956,924,734,1000,1000,102,-1000,417,658,1000,-759,-245,356,299,-1000,1000,-30,-1000,1000,70,468,-616,123}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00204() {
        org.junit.Assert.assertEquals("java.lang.Long:OTIyMzM3MjAzNjg1NDc3NTgwNw==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getMaximumItemAge():long",
            new int[]{506,-1000,-1000,821,1000,499,5,1000,305,67,-583,367,-1000,1000,336,-140,1000,-140,180,1000,-267,273,-1000,-1000,935,-1000,44,1000,45,-114,243,-730,219,1000,-465,747,1000,468,1000,1000,1000,-503,-660,-1000,-941,-1000,-173,-122,801,-354,-551,-1000,510,-339,1000,655,-528,629,-1000,383,-224,-594,804,698}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00205() {
        org.junit.Assert.assertEquals("java.lang.Long:OTIyMzM3MjAzNjg1NDc3NTgwNw==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getMaximumItemAge():long",
            new int[]{597,1000,941,-87,-1000,578,53,-237,-625,1000,-236,168,-371,340,-1000,-861,-1000,-1000,243,308,170,-1000,892,1000,675,265,-1000,-854,-80,-1000,-912,-331,-236,14,811,-506,412,1000,-597,82,-193,-483,1000,-438,220,1000,-818,-121,-616,-225,-29,55,-468,1000,178,328,317,41,729,147,496,-1000,157,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00206() {
        org.junit.Assert.assertEquals("java.lang.Long:OTIyMzM3MjAzNjg1NDc3NTgwNw==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getMaximumItemAge():long",
            new int[]{353,-451,-1000,1000,1000,82,159,987,954,204,1000,789,-1000,536,257,225,422,1000,1000,-920,-975,1000,-43,-437,1000,-8,1000,1000,-1000,-1000,1000,-1000,146,1000,-64,943,214,-397,241,591,649,-578,-1000,-1000,-392,-955,-803,61,1000,850,-466,-713,-439,133,1000,501,-1000,495,-1000,1000,-988,-453,938,-752}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00207() {
        org.junit.Assert.assertEquals("java.lang.Long:MQ==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getMaximumItemAge():long",
            new int[]{-416,717,-1000,1000,424,-753,464,-832,801,-700,458,986,12,-342,-730,421,-373,1000,-826,-1000,-1000,400,-632,900,-320,1000,1000,1000,-1000,-1000,1000,-1000,-724,334,440,323,-141,-574,-753,-634,12,-511,-1000,-101,-489,-1000,-960,820,1000,870,500,567,-400,789,-250,351,-1000,-655,-875,200,-1000,-196,-30,-466}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00208() {
        org.junit.Assert.assertEquals("java.lang.Long:OTIyMzM3MjAzNjg1NDc3NTgwNw==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getMaximumItemAge():long",
            new int[]{1000,593,243,-467,1000,-106,-77,-432,-363,437,1000,-376,-576,-523,801,362,633,-1000,1000,282,-653,4,229,390,-1000,1000,-581,569,-88,-1000,500,-990,-1000,316,244,529,116,604,-526,-1000,6,-1000,776,-1000,-1000,-535,544,470,-679,473,-973,-105,-330,941,1000,725,-222,-913,759,200,1000,-1000,-97,-573}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00209() {
        org.junit.Assert.assertEquals("java.lang.Long:OTIyMzM3MjAzNjg1NDc3NTgwNw==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getMaximumItemAge():long",
            new int[]{-681,656,151,-1000,-220,834,270,113,-263,472,1000,956,351,-894,-517,-1000,-257,970,-140,-1000,455,418,-1000,300,-123,1000,328,-123,-463,-1000,521,-338,-813,613,286,-404,-95,63,-918,-677,-729,-956,-863,-95,707,161,-1000,489,-697,1000,860,967,-382,1000,-510,1000,113,-1000,741,-160,-162,-939,556,-302}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00210() {
        org.junit.Assert.assertEquals("java.lang.Long:OTIyMzM3MjAzNjg1NDc3NTgwNw==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getMaximumItemAge():long",
            new int[]{-1000,-456,-77,-768,112,-386,-665,659,-1000,714,1000,998,-89,451,-266,-481,-923,-721,622,1000,413,621,-113,-20,-315,-285,-575,396,-256,-1000,-827,13,-1000,238,903,-1000,-362,805,-649,-1000,-1000,-1000,-861,-397,492,-235,-318,1000,-1000,584,-250,16,-861,-347,-950,357,506,-101,212,-1000,-15,-744,156,-763}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00211() {
        org.junit.Assert.assertEquals("java.lang.Long:OTIyMzM3MjAzNjg1NDc3NTgwNw==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getMaximumItemAge():long",
            new int[]{234,656,-119,-25,598,599,339,376,603,472,809,628,-469,-372,-251,143,-104,1000,227,-840,-408,418,-456,300,773,1000,249,448,-940,-1000,521,-1000,-465,-17,286,319,266,63,-464,246,108,-525,-994,-401,-14,161,-1000,-55,405,551,482,196,-152,1000,413,975,-1000,-692,375,500,-519,-615,858,-191}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00212() {
        org.junit.Assert.assertEquals("java.lang.Integer:MjE0NzQ4MzY0Nw==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getMaximumItemCount():int",
            new int[]{-444,-966,-1000,-418,-806,-19,1000,582,-687,-1000,-1000,1000,-1000,641,-1000,1000,576,913,332,707,-668,69,-260,-550,-229,570,638,-683,-86,-1000,277,63,-1000,-94,-152,-422,-228,-140,116,677,362,397,-594,-516,1000,-1000,758,436,1000,-1000,-505,687,-1000,-607,1000,793,-1000,-397,-1000,-799,298,156,-676,-776}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00213() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getMaximumItemCount():int",
            new int[]{76,-655,-713,-1000,-971,717,139,586,684,-773,-446,1000,-713,734,-223,1000,1000,1000,-1000,-854,1000,310,-191,466,511,352,939,-204,-647,-1000,-178,-821,-1000,-520,-431,-1000,-1000,782,943,1000,1000,1000,608,215,-238,-1000,271,1000,170,-1000,-172,-66,-739,-706,-340,-178,-268,-703,-25,-537,61,-206,-1000,156}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00214() {
        org.junit.Assert.assertEquals("java.lang.Integer:MjE0NzQ4MzY0Nw==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getMaximumItemCount():int",
            new int[]{641,-902,-1000,-978,-880,422,709,674,106,-987,-153,267,569,359,-715,675,432,628,-752,1000,743,-37,57,216,-449,196,247,-400,-325,-924,-302,-901,-1000,220,-124,-1000,-626,848,473,461,-187,1000,-830,-293,-923,-633,235,-437,138,-1000,-186,-332,-549,58,-232,-397,-660,341,-41,-317,-57,58,-98,335}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00215() {
        org.junit.Assert.assertEquals("java.lang.Integer:MjE0NzQ4MzY0Nw==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getMaximumItemCount():int",
            new int[]{-100,-833,1000,576,270,-307,1000,-180,-487,-1000,-1000,1000,-360,-604,728,-503,-1000,700,1000,-1000,-156,-233,-989,191,-1000,-382,638,-344,-674,-813,-388,197,-177,-94,-841,100,997,-1000,9,-137,-996,-168,-1000,-516,-905,-1000,271,-102,-1000,-191,353,1000,547,-72,1000,952,-992,-1000,-409,-458,-739,-154,988,975}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00216() {
        org.junit.Assert.assertEquals("java.lang.Integer:MjE0NzQ4MzY0Nw==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getMaximumItemCount():int",
            new int[]{641,-921,-392,-473,-599,1000,695,1000,94,-955,-446,80,41,300,-385,675,946,403,-1000,328,1000,314,57,389,110,353,709,-327,-967,-1000,-399,-1000,-538,-809,-415,-572,-796,782,943,1000,958,1000,489,95,784,-656,21,138,138,-1000,-186,222,-586,-352,-340,-905,-462,-808,283,41,-87,91,-704,335}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00217() {
        org.junit.Assert.assertEquals("java.lang.Integer:MjE0NzQ4MzY0Nw==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getMaximumItemCount():int",
            new int[]{102,420,411,285,839,794,-488,161,668,1000,745,-938,510,164,-153,-660,-219,-818,-1000,741,497,901,-963,-737,772,1000,-668,-400,1000,849,-78,1000,-415,298,-530,648,-820,-981,541,-353,516,-113,-637,-237,-454,1000,686,608,635,-1000,-27,151,187,568,-154,-1000,1000,136,274,720,553,174,684,-888}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00218() {
        org.junit.Assert.assertEquals("java.lang.Integer:MjE0NzQ4MzY0Nw==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getMaximumItemCount():int",
            new int[]{-1000,-813,831,97,26,339,1000,35,369,-1000,-1000,1000,-454,788,-1000,-129,244,121,1000,-187,-768,-726,606,-690,-445,-93,874,-1000,-411,-1000,-553,643,-493,-1000,-836,361,904,-51,619,863,-273,25,-1000,-38,1000,-473,1000,288,1000,-1000,-1000,1000,215,-942,-186,439,-1000,7,-216,-1000,-1000,-239,-41,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00219() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getMaximumItemCount():int",
            new int[]{-16,-778,660,-61,-539,957,833,884,279,-1000,-1000,1000,-64,-593,548,156,-1000,1000,190,-854,9,55,-555,1000,-371,-564,-210,-575,-1000,-1000,-751,-1000,-38,693,-431,-1000,-248,-1000,1000,1000,155,1000,-305,-103,-238,-553,-3,90,-804,-191,797,881,381,-261,-1000,11,-624,-908,299,-143,-100,62,-205,624}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00220() {
        org.junit.Assert.assertEquals("java.lang.Integer:MjE0NzQ4MzY0Nw==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getMaximumItemCount():int",
            new int[]{1000,-813,-182,-86,-538,805,768,920,283,-929,-654,1000,-64,-406,151,156,-1000,1000,-645,-128,9,-57,-381,1000,-608,-564,238,174,-730,-1000,-779,-698,-38,1000,276,-942,-124,-1000,599,577,700,1000,-305,-165,-238,-330,58,564,-804,-872,480,351,381,-221,-924,-80,-499,-1000,98,-19,-76,293,-49,624}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00221() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getMaximumItemCount():int",
            new int[]{-818,-201,1000,1000,-748,994,1000,283,-557,-26,-1000,42,277,489,-1000,304,84,699,-298,-890,-117,503,-310,49,665,439,-1000,-487,704,-1000,-312,709,-436,659,-109,40,-726,502,1000,1000,-697,650,-1000,-1000,-1000,74,256,-360,-215,-644,-191,-649,1000,703,-1000,-779,-1000,-773,197,36,-1000,-846,601,-703}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00222() {
        org.junit.Assert.assertEquals("java.lang.Integer:MjE0NzQ4MzY0Nw==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getMaximumItemCount():int",
            new int[]{-1000,178,-1000,-1000,482,337,-1000,457,261,219,-375,953,-1000,1000,-1000,234,-932,117,-1000,1000,-1000,-552,1000,-311,1000,1000,-399,-953,1000,-639,336,842,-1000,798,-557,-721,-1000,-1000,462,726,312,430,-823,26,1000,-892,1000,1000,1000,-1000,-421,-1000,-383,-1000,1000,-405,642,-371,-733,-711,426,-337,-1000,990}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00223() {
        org.junit.Assert.assertEquals("TYPE:org.jfree.data.time.Day", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getNextTimePeriod():org.jfree.data.time.RegularTimePeriod",
            new int[]{-933,1000,-834,968,-1000,494,32,-1000,783,-1000,1000,-522,979,-1000,947,-210,-1000,-45,1000,-1000,-162,90,1000,-47,-1000,-1000,447,585,1000,-983,-264,-1000,-1000,1000,-910,1000,-1000,-25,-1000,820,1000,1000,-1000,-768,-1000,-554,-296,1000,-425,-1000,-1000,519,1000,-1000,-400,541,-66,676,1000,-433,422,1000,-1000,-504}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00224() {
        org.junit.Assert.assertEquals("TYPE:org.jfree.data.time.Day", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getNextTimePeriod():org.jfree.data.time.RegularTimePeriod",
            new int[]{-930,501,1000,-587,32,303,-266,1000,1000,1000,-1000,-3,-1000,0,-912,1000,904,-1000,-540,-1000,1000,706,-1000,24,-222,593,-825,1000,-254,777,-1000,-705,432,-1000,-88,814,433,-371,547,1000,-1000,814,1000,-1000,-429,170,-1000,-1000,1000,-630,1000,-1000,-1000,421,-1000,-923,1000,610,334,484,-1000,745,-634,-553}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00225() {
        org.junit.Assert.assertEquals("THROW:java.lang.IndexOutOfBoundsException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getNextTimePeriod():org.jfree.data.time.RegularTimePeriod",
            new int[]{262,-244,547,-181,870,153,587,520,88,98,-464,709,-278,36,-780,344,661,460,-978,-142,307,-352,439,-9,-289,397,-707,571,-323,-107,-341,78,889,-1000,145,-834,-555,39,-212,465,-670,-210,1000,-236,477,11,-703,-278,-123,-361,257,-728,-280,763,588,-106,-274,-564,612,-503,277,488,-9,946}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00226() {
        org.junit.Assert.assertEquals("TYPE:org.jfree.data.time.Day", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getNextTimePeriod():org.jfree.data.time.RegularTimePeriod",
            new int[]{665,-335,-1000,1000,-836,-968,-776,-98,-1000,-612,-344,-194,486,141,537,1000,834,625,409,728,1000,-761,-496,-1000,149,471,682,-1000,-935,-1000,1000,536,1000,1000,584,-1000,-105,-137,-1000,-638,489,-204,-1000,888,-66,601,585,1000,-9,-1000,448,-336,699,319,-1000,984,-1000,-1000,-304,127,1000,-862,-459,-353}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00227() {
        org.junit.Assert.assertEquals("THROW:java.lang.IndexOutOfBoundsException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getNextTimePeriod():org.jfree.data.time.RegularTimePeriod",
            new int[]{-514,-1000,-1000,315,400,-971,-795,306,-349,-1000,81,-436,640,-570,-269,1000,945,898,655,-585,-621,-1000,-345,-186,426,49,449,-1000,-476,-1000,893,120,965,-715,-152,-833,227,-637,-1000,-1000,730,157,-1000,1000,-261,721,925,940,-36,99,14,1000,902,-433,-1000,1000,-1000,-1000,-957,89,660,-1000,714,-352}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00228() {
        org.junit.Assert.assertEquals("TYPE:org.jfree.data.time.Day", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getNextTimePeriod():org.jfree.data.time.RegularTimePeriod",
            new int[]{-511,1000,-770,968,-1000,894,-485,-1000,-179,-939,-560,-997,973,-1000,1000,-328,-1000,-25,1000,-1000,-8,545,1000,337,-1000,-1000,447,986,1000,-580,-264,-1000,-1000,1000,-1000,1000,-1000,-91,-952,820,1000,1000,-1000,-895,-1000,-1000,41,-91,-338,-1000,-1000,-313,1000,-1000,-927,145,340,1000,1000,-432,779,1000,-1000,-829}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00229() {
        org.junit.Assert.assertEquals("TYPE:org.jfree.data.time.Day", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getNextTimePeriod():org.jfree.data.time.RegularTimePeriod",
            new int[]{-850,501,1000,-1000,32,155,-266,814,955,1000,-666,-384,-266,-554,-1000,-798,720,-703,-163,-1000,-223,627,-1000,262,-161,95,-738,1000,330,777,-1000,-633,432,-1000,260,685,579,-898,367,1000,-269,719,997,-1000,-154,-1000,-395,-1000,1000,-21,448,-732,-1000,0,1000,-583,1000,610,334,286,-1000,621,-444,-952}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00230() {
        org.junit.Assert.assertEquals("TYPE:org.jfree.data.time.Day", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getNextTimePeriod():org.jfree.data.time.RegularTimePeriod",
            new int[]{-114,-1000,198,-209,-21,-476,-705,1000,159,98,-975,374,1000,-199,-755,114,482,613,-851,-449,752,-352,439,256,443,753,-227,-829,-554,-684,-25,-29,368,-733,369,-1000,704,-639,-948,-286,-670,-167,1000,-558,-361,500,-14,-450,705,-277,-235,-341,-280,1000,-75,216,-485,-1000,308,410,-97,-898,-56,638}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00231() {
        org.junit.Assert.assertEquals("TYPE:org.jfree.data.time.Day", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getNextTimePeriod():org.jfree.data.time.RegularTimePeriod",
            new int[]{732,1000,-1000,846,-379,284,895,-1000,-1000,-1000,1000,1000,469,-534,-132,324,-720,-25,739,699,557,-447,1000,-436,31,-31,1000,622,1000,-942,1000,871,585,1000,659,1000,-1000,951,-39,-734,676,181,-1000,1000,-889,787,-204,1000,-956,1000,-1000,806,352,-396,552,828,-854,-132,175,-1000,1000,511,549,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00232() {
        org.junit.Assert.assertEquals("THROW:java.lang.IndexOutOfBoundsException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getNextTimePeriod():org.jfree.data.time.RegularTimePeriod",
            new int[]{1000,-208,-417,1000,-371,-976,-525,711,-1000,-362,-296,-1000,219,137,190,846,886,-201,-561,1000,1000,-1000,-308,-979,178,1000,-363,-832,-1000,-1000,1000,-608,1000,623,1000,-759,159,-1000,-1000,-1000,42,-1000,-1000,1000,-40,983,896,985,197,-7,307,272,715,1000,273,1000,165,-1000,-1000,103,1000,-895,941,281}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00233() {
        org.junit.Assert.assertEquals("java.lang.String:VmFsdWU=", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getRangeDescription():java.lang.String",
            new int[]{357,56,1000,5,1000,769,-31,-35,365,-433,-707,-960,-226,346,-237,-156,-404,-90,1000,-456,234,-1000,407,-380,268,1000,-313,-1000,-1000,-1000,547,-649,1000,-669,10,-1000,426,-324,-374,-295,-400,1000,-539,960,-496,-1000,1000,-1000,1000,116,-506,-380,1000,1000,-23,610,-1000,130,-406,-391,-355,1000,-673,-892}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00234() {
        org.junit.Assert.assertEquals("java.lang.String:VmFsdWU=", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getRangeDescription():java.lang.String",
            new int[]{269,-158,895,-782,1000,556,-709,584,-71,375,190,539,-131,-469,-779,402,-1000,-542,373,-1,652,-466,-733,-444,-43,643,-117,-224,-154,311,130,-146,238,-873,232,-2,391,-160,-234,-395,-362,3,449,697,335,-725,-437,-26,295,-907,-293,-1000,731,-554,-1000,68,-438,450,-100,151,-639,1000,762,-168}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00235() {
        org.junit.Assert.assertEquals("java.lang.String:VmFsdWU=", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getRangeDescription():java.lang.String",
            new int[]{1000,-911,1000,-779,536,-413,-932,351,-689,673,181,-612,-1000,-228,-1000,95,-957,-641,929,-479,1000,1000,-1000,-644,445,-283,-1000,473,330,-289,73,230,-1000,-924,-1000,452,-85,-667,-119,1000,-127,239,1000,-368,263,338,300,47,-47,1000,634,-1000,-555,-986,-254,1000,170,-662,478,-216,435,43,1000,-8}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00236() {
        org.junit.Assert.assertEquals("java.lang.String:VmFsdWU=", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getRangeDescription():java.lang.String",
            new int[]{1000,-638,319,72,1000,760,-161,924,400,620,429,585,-417,-1000,-1000,-244,-145,-1000,941,-929,604,272,-868,107,-1000,660,-1000,828,-1000,-760,865,1000,-838,-491,-288,352,-478,-1000,-1000,1000,-1000,1000,1000,-1000,-100,-500,1000,-822,645,15,-36,1000,-263,1000,-974,1000,496,-919,942,-250,413,1000,-395,-401}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00237() {
        org.junit.Assert.assertEquals("java.lang.String:VmFsdWU=", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getRangeDescription():java.lang.String",
            new int[]{209,226,588,-7,218,-483,483,-23,-615,-5,4,-716,-1000,-114,-291,-1000,-1000,-633,-713,-681,587,373,-51,-318,-98,-426,400,-358,318,-728,-839,-14,238,978,691,34,-334,-654,-3,1000,-476,-722,-300,822,-22,400,-493,-214,689,38,532,-1000,-206,-688,-314,214,907,410,214,-678,60,-160,929,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00238() {
        org.junit.Assert.assertEquals("java.lang.String:NDg=", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getRangeDescription():java.lang.String",
            new int[]{814,-1000,1000,-837,321,159,323,944,-1000,976,-163,-566,-815,-30,-19,-163,-80,-71,558,-528,931,48,-216,-375,-552,806,-74,269,-720,123,779,236,-186,-472,-582,-448,280,-797,-341,-83,-652,627,-752,38,231,-104,245,7,-26,238,-523,-1000,616,185,-78,660,-879,-52,120,-56,385,637,1000,104}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00239() {
        org.junit.Assert.assertEquals("java.lang.String:VmFsdWU=", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getRangeDescription():java.lang.String",
            new int[]{2,1000,710,-155,818,714,1000,1000,-223,-167,-163,-566,-393,-373,1000,-156,-776,-1000,-320,808,931,48,1000,-271,-1000,857,1000,-238,-1000,123,-1000,-568,1000,1000,1,-1000,-1000,-797,-65,-83,-1000,312,-796,1000,418,-104,-56,-1000,-745,-1000,15,-1000,616,1000,-399,-54,-523,765,-426,-934,-103,797,1000,718}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00240() {
        org.junit.Assert.assertEquals("java.lang.String:VmFsdWU=", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getRangeDescription():java.lang.String",
            new int[]{418,226,663,-256,138,-1000,-277,-351,-615,-37,-47,-1000,-443,351,-13,-316,-778,-344,840,415,321,417,-813,-383,773,-590,-427,-594,777,-1000,-48,278,-133,126,-339,260,-901,-188,-311,139,-41,-374,20,393,13,488,339,-8,-257,-335,590,-1000,39,-1000,-477,840,499,-290,653,-187,-592,-655,761,572}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00241() {
        org.junit.Assert.assertEquals("java.lang.String:VmFsdWU=", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getRangeDescription():java.lang.String",
            new int[]{1000,-452,744,1000,-442,-956,58,-306,-1000,-246,367,250,-1000,-170,-42,99,-1000,258,-471,-1000,507,1000,-440,-372,507,-1000,-1000,1000,658,480,-384,880,-1000,476,-1000,1000,-808,-921,-430,1000,-127,-1000,1000,-368,-755,1000,-695,525,-776,943,567,131,-1000,-497,24,253,1000,-492,891,64,785,-885,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00242() {
        org.junit.Assert.assertEquals("TYPE:org.jfree.data.time.Day", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getTimePeriod(int):org.jfree.data.time.RegularTimePeriod",
            new int[]{-1000,1000,1000,876,369,-76,-78,-1000,-1000,1000,478,-463,254,735,1000,983,-126,-976,379,-562,578,-85,419,-50,327,522,-2,-649,181,566,-1000,-997,605,850,-1000,-1000,-992,-796,291,-1000,251,-202,-841,-916,-120,1000,-160,-338,1000,1000,467,1000,-815,1000,-950,230,-1000,-447,457,77,-1000,949,-269,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00243() {
        org.junit.Assert.assertEquals("THROW:java.lang.IndexOutOfBoundsException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getTimePeriod(int):org.jfree.data.time.RegularTimePeriod",
            new int[]{429,242,464,-459,92,418,553,278,-5,-520,-761,181,359,-619,191,49,424,-461,39,769,-939,-80,525,-345,833,825,29,794,-415,-881,-169,-449,-995,-138,-326,-373,-911,87,-584,905,928,-199,868,-328,-160,221,257,-249,498,700,-801,-419,-587,-160,538,360,-97,903,968,-46,508,751,943,521}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00244() {
        org.junit.Assert.assertEquals("THROW:java.lang.IndexOutOfBoundsException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getTimePeriod(int):org.jfree.data.time.RegularTimePeriod",
            new int[]{-526,581,393,705,243,672,-266,-471,-592,-205,-164,-354,-52,642,1000,-389,215,674,-162,-320,354,18,541,-111,1000,803,8,920,1000,352,-485,-573,382,636,-190,-599,-1000,-1000,-551,-242,56,-870,-611,-856,600,946,-740,-378,1000,882,1000,-306,797,614,-308,-217,-575,-289,-302,-147,-273,554,-569,492}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00245() {
        org.junit.Assert.assertEquals("THROW:java.lang.IndexOutOfBoundsException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getTimePeriod(int):org.jfree.data.time.RegularTimePeriod",
            new int[]{379,725,-597,292,-488,-244,-731,471,351,-816,669,-376,-54,425,744,-87,330,215,225,-10,647,1000,1000,326,348,101,-566,632,720,731,-254,201,366,-281,-746,-279,-502,-700,-887,675,-82,326,-1000,-540,-570,-66,-1000,-1000,183,911,1000,1000,662,236,-277,709,868,-380,-745,-303,-454,680,-1000,331}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00246() {
        org.junit.Assert.assertEquals("THROW:java.lang.IndexOutOfBoundsException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getTimePeriod(int):org.jfree.data.time.RegularTimePeriod",
            new int[]{-68,1000,437,238,82,904,-194,151,9,-315,-259,-1000,615,384,702,688,-694,937,299,-812,166,40,888,190,931,749,237,-94,-25,-119,-687,-654,-295,968,273,-123,-946,-400,-634,881,259,-448,486,-1000,385,909,-58,26,238,1000,328,278,-84,74,554,-101,-109,527,450,-307,319,1000,364,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00247() {
        org.junit.Assert.assertEquals("THROW:java.lang.IndexOutOfBoundsException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getTimePeriod(int):org.jfree.data.time.RegularTimePeriod",
            new int[]{931,-83,-178,-147,-424,-123,-37,-393,-695,-1000,-583,192,-4,-254,842,78,237,297,-63,1000,-611,-73,225,485,501,-265,-1,393,-332,-343,-235,-735,-1000,-562,-691,-72,-922,-849,-498,414,311,-337,369,-214,28,818,102,-148,1000,287,-734,312,-632,-492,564,531,-475,360,-296,247,-567,935,1000,114}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00248() {
        org.junit.Assert.assertEquals("THROW:java.lang.IndexOutOfBoundsException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getTimePeriod(int):org.jfree.data.time.RegularTimePeriod",
            new int[]{-309,1000,1000,1000,496,388,-971,278,83,900,529,181,1000,265,1000,1000,-878,-114,938,-448,556,-80,1000,1000,1000,470,449,-135,-204,918,-169,-449,-995,1000,-269,-629,-1000,-1000,465,-377,-65,-1000,-110,-587,539,818,-1000,11,1000,1000,-400,1000,-982,819,400,-1000,-1000,400,1000,-664,-1000,1000,418,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00249() {
        org.junit.Assert.assertEquals("THROW:java.lang.IndexOutOfBoundsException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getTimePeriod(int):org.jfree.data.time.RegularTimePeriod",
            new int[]{429,502,103,323,535,-239,-1000,-147,-447,720,919,-787,359,1000,569,-1000,1000,758,-552,1000,293,-935,-172,171,-744,798,29,-548,198,902,-424,-541,1000,1000,516,-21,685,-741,1000,-1000,30,-199,-1000,-154,64,221,-555,-240,654,376,-801,860,1000,635,-811,1000,113,-1000,968,405,-618,-249,-1000,239}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00250() {
        org.junit.Assert.assertEquals("THROW:java.lang.IndexOutOfBoundsException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getTimePeriod(int):org.jfree.data.time.RegularTimePeriod",
            new int[]{-601,1000,918,140,1000,-727,-495,-682,-356,718,836,302,-765,361,420,562,-116,-1000,877,-635,1000,-350,-108,-698,1000,1000,469,-544,-1000,397,-474,-297,976,495,-96,-920,-779,219,524,-576,70,-612,-582,-354,-204,-5,-1000,-375,48,430,933,837,418,82,-940,-1000,-1000,-741,1000,145,400,474,-890,724}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00251() {
        org.junit.Assert.assertEquals("THROW:java.lang.IndexOutOfBoundsException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getTimePeriod(int):org.jfree.data.time.RegularTimePeriod",
            new int[]{506,-481,-365,967,-334,376,-67,-921,429,732,33,575,793,660,-910,-535,240,483,908,-484,-782,603,174,-202,-234,-986,390,463,859,-997,891,204,482,-218,553,63,878,-415,-1000,-892,-74,84,450,-155,195,909,651,-822,-133,-477,-149,252,417,718,164,-453,702,-374,291,235,-38,274,139,-989}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00252() {
        org.junit.Assert.assertEquals("TYPE:java.lang.Class", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getTimePeriodClass():java.lang.Class",
            new int[]{-77,-131,1000,640,-656,-37,4,384,-745,-1000,-1000,359,-812,35,-522,1000,-120,759,-920,-1000,-25,-487,1000,170,270,-24,1000,-440,-408,-233,86,-1000,845,132,-859,296,-548,281,-58,-254,1000,-16,780,-52,-1000,-944,25,-445,966,-592,-1000,898,-966,95,-244,191,798,-138,1000,632,1000,1000,400,-301}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00253() {
        org.junit.Assert.assertEquals("TYPE:java.lang.Class", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getTimePeriodClass():java.lang.Class",
            new int[]{424,-399,820,-585,-532,749,844,163,-984,-636,-367,-174,238,274,-310,127,-385,-190,-586,-122,809,548,535,152,56,-474,839,-113,602,-651,980,279,500,-13,791,923,-844,328,547,-939,-568,563,-95,-541,-185,-656,-108,455,-819,-665,-768,-427,-965,-780,-469,-322,760,-433,440,146,335,16,-266,749}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00254() {
        org.junit.Assert.assertEquals("TYPE:java.lang.Class", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getTimePeriodClass():java.lang.Class",
            new int[]{-1000,176,1000,160,239,-597,359,69,-467,-959,1000,-625,288,543,720,-696,224,29,855,122,1000,146,-800,300,-1000,805,1000,495,811,1000,1000,-1000,-670,1000,-248,-727,-1000,-799,-1000,1000,1000,128,-709,476,-740,463,476,192,216,1000,557,538,673,-700,373,155,16,-697,462,360,663,-13,-270,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00255() {
        org.junit.Assert.assertEquals("TYPE:java.lang.Class", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getTimePeriodClass():java.lang.Class",
            new int[]{-727,-544,461,167,1000,209,-1000,377,-62,-13,1000,-570,293,48,-315,142,-57,-583,-283,307,487,766,-989,-759,-503,422,609,81,521,1000,490,-402,-37,1000,-1000,-1000,-642,-976,-1000,1000,1000,-951,-379,-37,-16,322,1000,810,-925,1000,-865,-139,-185,764,1000,567,-551,80,-104,-379,-271,-13,7,-858}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00256() {
        org.junit.Assert.assertEquals("TYPE:java.lang.Class", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getTimePeriodClass():java.lang.Class",
            new int[]{938,-801,-409,604,-462,277,-172,1000,-381,194,1000,180,58,-476,-279,552,1000,-117,701,-1000,-1000,-229,-789,557,761,-706,-314,-770,-192,770,-307,699,-305,242,619,789,-1000,414,-341,-144,1000,-436,442,-853,555,-1000,-208,-13,-213,-543,-1000,393,-254,-1000,-152,-138,-445,-347,1000,-521,-411,242,672,700}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00257() {
        org.junit.Assert.assertEquals("TYPE:java.lang.Class", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getTimePeriodClass():java.lang.Class",
            new int[]{348,-127,-1000,-85,127,442,939,-488,1000,-1000,57,619,1000,-530,-92,36,820,-529,1000,1000,-28,911,-197,529,644,-477,-1000,-1000,586,463,51,1000,-931,1000,1000,-118,533,117,-783,651,-1000,-78,790,-775,-116,952,1000,-394,513,147,-68,-167,-265,-764,744,-434,1000,-793,-1000,-669,-1000,-1000,1000,-466}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00258() {
        org.junit.Assert.assertEquals("TYPE:java.lang.Class", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getTimePeriodClass():java.lang.Class",
            new int[]{1000,-398,-1000,406,-620,-549,1000,-632,205,1000,105,805,1000,-108,452,-308,1000,1000,1000,-1000,-1000,-652,-51,1000,-860,-807,609,-1000,-992,-126,-334,1000,-1000,753,988,-60,189,-74,-1000,1000,-1000,538,-15,-1000,1000,-834,-366,252,873,-114,238,-15,868,-1000,-999,-423,-1000,-1000,-1000,-854,-1000,-69,1000,317}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00259() {
        org.junit.Assert.assertEquals("TYPE:java.lang.Class", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getTimePeriodClass():java.lang.Class",
            new int[]{-41,207,871,-49,963,-1000,-1000,-621,-381,519,1000,-647,-785,-389,-293,1000,-1000,-295,-1000,-698,1000,478,-356,-1000,-1000,1000,1000,832,1000,1000,796,-1000,-305,231,-111,789,-1000,-974,-663,254,1000,45,-1000,664,-846,71,979,-13,1000,197,-1000,-303,511,-427,1000,-24,-671,796,1000,253,1000,-13,-112,-701}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00260() {
        org.junit.Assert.assertEquals("TYPE:java.util.ArrayList", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getTimePeriods():java.util.Collection",
            new int[]{81,-195,215,-115,403,259,394,531,-1000,515,-293,-24,-113,704,-606,-429,-325,-363,193,-68,525,-718,-313,695,127,350,478,-31,2,248,-122,278,500,1000,288,549,784,735,763,101,497,-99,329,340,359,643,-97,19,-441,826,436,-972,-290,-466,674,37,-401,50,158,623,49,-593,-49,471}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00261() {
        org.junit.Assert.assertEquals("TYPE:java.util.ArrayList", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getTimePeriods():java.util.Collection",
            new int[]{741,-818,683,949,-296,569,-790,-911,416,-914,-761,-497,-695,-375,225,-408,144,670,-507,432,-286,267,401,139,704,96,-64,-899,-872,787,-258,658,-8,-906,-697,-198,408,636,723,108,-89,528,-565,-773,-660,403,6,15,338,101,-792,-352,-781,-404,-481,924,-194,-376,-719,350,-344,-101,940,592}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00262() {
        org.junit.Assert.assertEquals("TYPE:java.util.ArrayList", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getTimePeriods():java.util.Collection",
            new int[]{1000,1000,-1000,-865,1000,939,831,486,-1000,250,-738,-225,359,1000,-292,1000,-802,58,1000,1000,1000,-224,1000,1000,1000,-829,256,1000,-558,-569,-1000,-1000,236,-234,1000,364,-699,-1000,-870,-1000,-697,-1000,1000,809,754,1000,-1000,-851,375,169,-436,-537,94,-1000,1000,-106,111,-1,51,-209,-381,19,1000,440}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00263() {
        org.junit.Assert.assertEquals("TYPE:java.util.ArrayList", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getTimePeriods():java.util.Collection",
            new int[]{-214,273,2,267,292,-1000,-657,-846,-595,181,-875,-760,-1000,943,127,-1000,-841,-8,-445,532,151,-363,-1000,1000,-648,-200,1000,-1000,904,594,874,-1000,-286,1000,16,135,1000,1000,1000,647,1000,718,618,-1000,585,-1000,32,818,-555,-704,-153,-542,-668,-1000,-1000,356,-731,617,335,1000,252,-470,-356,-577}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00264() {
        org.junit.Assert.assertEquals("TYPE:java.util.ArrayList", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getTimePeriods():java.util.Collection",
            new int[]{81,414,-1000,-240,600,1000,-534,-462,-1000,1000,-1000,-1000,-1000,-643,-108,359,-1000,-1000,635,493,-148,812,-1000,1000,879,-1000,1000,1000,4,-1000,-342,-400,131,1000,42,-88,1000,256,-328,1000,951,-1000,-608,-700,269,299,163,68,-153,96,1000,10,-652,-804,57,1000,-1000,-1000,1000,880,1000,154,-306,-206}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00265() {
        org.junit.Assert.assertEquals("TYPE:java.util.ArrayList", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getTimePeriods():java.util.Collection",
            new int[]{1000,488,-193,-1000,496,459,-26,-1000,-609,133,-1000,-1000,-1000,4,74,177,-719,610,165,1000,-305,1000,-382,286,-24,-518,630,94,-644,978,-976,1000,493,-1000,365,380,331,123,-677,109,1000,-545,-95,-1000,-227,475,-725,-802,-701,360,153,1000,-20,-1000,703,1000,-339,-211,-412,1000,1000,30,-477,897}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00266() {
        org.junit.Assert.assertEquals("TYPE:java.util.ArrayList", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getTimePeriods():java.util.Collection",
            new int[]{104,-96,1000,-60,425,-301,691,1000,-486,-621,1000,191,1000,798,-1000,-1000,1000,11,42,-1000,881,-1000,1000,-1000,1000,1000,-1000,1000,-530,924,-66,-1000,-1000,250,363,292,-990,18,1000,-780,-231,1000,-534,1000,161,243,-1000,-628,-1000,1000,642,-289,176,225,317,-1000,1000,984,-1000,-1000,-1000,-962,-316,425}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00267() {
        org.junit.Assert.assertEquals("TYPE:java.util.ArrayList", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getTimePeriods():java.util.Collection",
            new int[]{-197,1000,121,-1000,-1000,489,-468,-986,762,133,886,130,152,-1000,-218,-945,668,-971,143,-279,622,16,-1000,-534,-17,566,-144,-1000,-592,1000,517,-240,-816,-332,-507,-12,1000,867,575,307,734,422,-178,180,731,-82,213,499,-1000,-425,299,932,-694,-197,-796,56,-518,-946,-111,-119,340,404,-1000,75}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00268() {
        org.junit.Assert.assertEquals("TYPE:java.util.ArrayList", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getTimePeriods():java.util.Collection",
            new int[]{-249,1000,-470,268,-767,-372,-793,-1000,-413,361,-1000,-776,-1000,-239,405,-437,-1000,62,220,1000,584,602,-1000,1000,-1000,-706,1000,-1000,450,-45,447,1000,1000,1000,886,-75,1000,1000,-140,1000,1000,184,698,-1000,852,-759,308,-313,-255,-600,678,367,-1000,-1000,-734,509,-822,-37,1000,895,603,41,-1000,-599}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00269() {
        org.junit.Assert.assertEquals("TYPE:java.util.ArrayList", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getTimePeriods():java.util.Collection",
            new int[]{-1000,-1000,541,490,-1000,84,534,-325,1000,-10,835,-342,-344,-1000,-793,-1000,947,-1000,-328,-1000,117,-114,-1000,-1000,667,865,-523,-1000,498,291,1000,-241,-369,-281,-1000,-749,1000,1000,1000,689,538,982,-750,638,0,-221,1000,1000,-1000,-63,1000,116,-1000,-1000,-1000,-54,-231,-282,131,314,1000,-595,-1000,-395}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00270() {
        org.junit.Assert.assertEquals("TYPE:java.util.ArrayList", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getTimePeriods():java.util.Collection",
            new int[]{-678,41,1000,-640,-980,-516,-507,889,343,-552,-220,-79,581,-684,-999,-966,-207,-44,-309,-1000,129,-981,-1000,404,416,968,-255,-449,978,228,1000,-1000,296,528,-1000,157,1000,1000,150,-39,1000,938,-584,188,-333,418,964,275,-1000,827,1000,-54,-868,895,-370,-527,166,446,561,-338,1000,191,-358,441}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00271() {
        org.junit.Assert.assertEquals("TYPE:java.util.ArrayList", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getTimePeriodsUniqueToOtherSeries(org.jfree.data.time.TimeSeries):java.util.Collection",
            new int[]{-374,-1000,802,1000,403,753,158,-310,487,574,384,887,12,-935,-307,1000,-683,44,-565,785,175,8,123,243,-661,1000,-422,1000,-349,52,-621,-509,-26,-589,-289,865,302,-493,1000,-512,1000,293,1000,1000,112,1000,-18,-1000,-619,468,-175,-137,-153,-213,-652,-340,144,-1000,-54,729,-1000,-667,706,-115}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00272() {
        org.junit.Assert.assertEquals("TYPE:java.util.ArrayList", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getTimePeriodsUniqueToOtherSeries(org.jfree.data.time.TimeSeries):java.util.Collection",
            new int[]{-723,-543,1000,1000,742,-27,244,-162,-1000,-1000,553,-109,1000,-1000,612,429,-819,-317,-572,911,1000,-1000,-758,-57,300,1000,403,-600,-1000,1000,-1000,-1000,1000,-1000,77,1000,1000,-1000,212,-1000,-1000,1000,1000,1000,-1000,-559,-487,719,-1000,1000,615,460,546,-202,548,-854,-1000,-1000,-246,-104,-983,-1000,1000,-631}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00273() {
        org.junit.Assert.assertEquals("TYPE:java.util.ArrayList", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getTimePeriodsUniqueToOtherSeries(org.jfree.data.time.TimeSeries):java.util.Collection",
            new int[]{1000,-820,-12,1000,1000,514,-110,-740,-210,30,-696,-219,-8,-102,315,757,188,-26,968,1000,136,-1000,313,479,-217,85,-517,164,172,-829,-177,-215,828,570,223,362,-138,-836,-640,132,-729,-769,436,-264,-1000,-284,-522,-274,-316,-501,-509,359,-685,-105,274,820,-531,623,-47,540,-349,-762,-188,128}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00274() {
        org.junit.Assert.assertEquals("TYPE:java.util.ArrayList", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getTimePeriodsUniqueToOtherSeries(org.jfree.data.time.TimeSeries):java.util.Collection",
            new int[]{250,-1000,-1000,555,-999,579,-1000,1000,1000,1000,-748,1000,781,-62,1000,1000,-1000,-368,-764,-769,-80,1000,414,-1000,-1000,-1000,-870,-121,-313,-572,-619,725,-1000,613,-394,-1000,1000,1000,1000,-583,1000,-1000,621,67,-197,-489,1000,-1000,1000,-1000,641,-1000,-15,30,-810,-216,1000,-1000,-729,861,-1000,-389,214,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00275() {
        org.junit.Assert.assertEquals("TYPE:java.util.ArrayList", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getTimePeriodsUniqueToOtherSeries(org.jfree.data.time.TimeSeries):java.util.Collection",
            new int[]{-124,-271,257,-1000,-112,1000,-197,69,-727,-475,-401,1000,1000,202,534,427,-1000,-478,-930,279,-197,256,-196,-929,475,-519,-506,-284,-599,776,31,-889,917,412,178,1000,1000,-1000,402,-879,450,-636,-30,1000,-515,-1000,-493,-337,1000,1000,1000,-459,624,220,-862,-1000,-1000,-79,151,495,-631,-166,305,-460}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00276() {
        org.junit.Assert.assertEquals("TYPE:java.util.ArrayList", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getTimePeriodsUniqueToOtherSeries(org.jfree.data.time.TimeSeries):java.util.Collection",
            new int[]{636,-1000,-996,-1000,281,-287,414,-162,777,-264,-687,1000,112,978,651,764,-192,-49,363,-124,-108,1000,476,-874,-1000,-850,-848,-1000,921,926,411,-1000,1000,556,-167,95,445,-1000,-49,-40,-818,-928,755,1000,-325,-1000,-866,826,946,66,824,560,-1000,9,-518,-845,-456,-136,-935,357,-369,127,-126,-709}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00277() {
        org.junit.Assert.assertEquals("TYPE:java.util.ArrayList", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getTimePeriodsUniqueToOtherSeries(org.jfree.data.time.TimeSeries):java.util.Collection",
            new int[]{-1000,-212,257,-429,-522,999,393,926,-738,-400,404,501,1000,344,980,-289,-330,-1000,-1000,-242,-870,551,-1000,-518,107,352,-506,-199,-603,-1,444,297,917,927,-466,413,112,-205,-579,-1000,542,-271,-440,975,691,-907,382,-1000,532,371,1000,-1000,1000,350,-1000,-452,-861,234,-366,-366,406,-436,-63,225}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00278() {
        org.junit.Assert.assertEquals("TYPE:java.util.ArrayList", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getTimePeriodsUniqueToOtherSeries(org.jfree.data.time.TimeSeries):java.util.Collection",
            new int[]{1000,-658,-349,-1000,824,613,136,-926,935,1000,-887,679,12,368,714,1000,65,44,1000,983,96,842,730,744,-363,1000,-962,1000,1000,91,821,-379,-26,-328,570,-639,-54,455,245,573,1000,-1000,269,-379,228,1000,-505,-1000,-409,578,-723,957,-904,-320,6,323,224,-185,35,624,-675,-762,-111,-142}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00279() {
        org.junit.Assert.assertEquals("TYPE:java.util.ArrayList", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getTimePeriodsUniqueToOtherSeries(org.jfree.data.time.TimeSeries):java.util.Collection",
            new int[]{1000,-1000,-129,604,1000,-683,22,50,377,1000,-1000,895,-505,-456,-36,1000,-126,-875,-294,710,-278,573,212,1000,-246,407,-343,1000,587,618,1000,-1000,265,-316,-497,583,8,156,1000,482,1000,-1000,1000,793,334,776,163,-359,560,456,1000,70,485,114,-1000,-901,-422,22,968,831,-1000,-1000,-831,240}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00280() {
        org.junit.Assert.assertEquals("TYPE:java.util.ArrayList", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getTimePeriodsUniqueToOtherSeries(org.jfree.data.time.TimeSeries):java.util.Collection",
            new int[]{-1000,1000,1000,-638,702,-622,352,-872,-1000,-1000,1000,-1000,33,-341,787,-1000,997,-342,619,991,-1000,-1000,-651,-1000,1000,944,-798,-233,-626,-1000,54,-1000,1000,-140,1000,-836,506,-211,-453,-1000,-1000,1000,-1000,-1000,-1000,-1000,-966,782,-1000,-409,120,289,-683,894,769,1000,-969,120,-1000,-1000,1000,-89,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00281() {
        org.junit.Assert.assertEquals("TYPE:java.util.ArrayList", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getTimePeriodsUniqueToOtherSeries(org.jfree.data.time.TimeSeries):java.util.Collection",
            new int[]{-1000,-1000,471,256,-5,579,198,305,286,-515,-105,-356,-655,-720,-78,206,-321,-1000,-317,1000,-475,100,-94,-912,435,1000,-271,-171,-23,-39,-891,-575,1000,867,-205,750,-142,677,-61,-918,63,-340,336,1000,526,-606,-951,-102,363,1000,1000,546,377,601,-1000,-170,-552,1000,174,-38,-200,-1000,-563,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00282() {
        org.junit.Assert.assertEquals("THROW:java.lang.IndexOutOfBoundsException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getValue(int):java.lang.Number",
            new int[]{-1000,-267,296,415,-746,1000,-351,-1000,764,626,434,-720,322,447,-590,-64,-1000,616,-377,1000,-117,-413,-562,1000,-1000,1000,358,-72,157,-86,-1000,1000,-605,1000,-283,1000,-1000,1000,-1000,-568,226,354,-663,-1000,415,611,-409,741,1000,-672,-1000,-644,-844,-1000,1000,594,1000,-988,-1000,-436,381,-1000,-1000,400}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00283() {
        org.junit.Assert.assertEquals("THROW:java.lang.IndexOutOfBoundsException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getValue(int):java.lang.Number",
            new int[]{1000,-362,-620,1000,-180,-355,379,-322,-69,-776,1000,-619,-630,444,-640,-711,741,-470,292,-911,-45,901,933,994,-1000,1000,-846,-971,507,-1000,-190,193,-360,-275,326,-886,504,-226,-247,713,-321,-190,39,1000,180,-277,831,120,438,-551,928,184,815,-839,-80,22,370,321,680,-686,378,603,755,-700}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00284() {
        org.junit.Assert.assertEquals("THROW:java.lang.IndexOutOfBoundsException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getValue(int):java.lang.Number",
            new int[]{922,-412,-831,1000,1000,-691,-215,204,654,-991,-1000,-1000,138,1000,-257,273,872,219,1000,-1000,-458,-396,1000,-1000,-1000,-140,49,737,359,-1000,640,45,-463,-1000,1000,-1000,96,-642,-367,-39,-292,-567,-851,1000,-104,-658,1000,-914,-167,1000,238,-1000,177,-1000,-287,-1000,-766,1000,-97,-1000,1000,1000,-736,-721}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00285() {
        org.junit.Assert.assertEquals("java.lang.Double:LTIuMTQ3NDgzNjQ4RTk=", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getValue(int):java.lang.Number",
            new int[]{767,-316,-84,1000,1000,619,532,-524,-503,-565,663,22,1000,1000,-1000,412,-1000,414,889,151,-1000,439,500,478,-1000,-140,384,-516,-1000,-1000,54,838,-1000,-515,-156,-597,-561,-862,-1000,-553,-630,-914,-386,967,-733,-603,736,-1000,-37,1000,500,-901,300,86,728,-536,-721,634,-27,-317,-146,841,-591,-349}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00286() {
        org.junit.Assert.assertEquals("THROW:java.lang.IndexOutOfBoundsException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getValue(int):java.lang.Number",
            new int[]{62,776,530,512,1000,274,690,-862,825,-362,387,478,938,128,-719,-496,-121,-381,485,775,-1000,1000,326,876,-348,-1000,-679,-475,-988,-212,16,838,1000,1000,1000,191,-1000,112,-899,248,138,-369,-760,97,259,-256,1000,253,418,243,256,516,767,22,286,100,971,-329,-279,-279,776,-486,-592,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00287() {
        org.junit.Assert.assertEquals("THROW:java.lang.IndexOutOfBoundsException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getValue(int):java.lang.Number",
            new int[]{-1000,-143,137,-1000,-533,1000,214,-842,119,-65,-100,142,-406,21,353,1000,-1000,1000,-1000,1000,-1000,-879,897,1000,-179,-294,1000,-196,-313,-943,-624,-757,-1000,729,-904,894,151,1000,-399,-1000,436,-1000,484,-1000,-1000,557,-1000,464,343,166,553,-745,-1000,280,1000,349,-111,-826,-930,492,-830,-539,-265,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00288() {
        org.junit.Assert.assertEquals("THROW:java.lang.IndexOutOfBoundsException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getValue(int):java.lang.Number",
            new int[]{1000,-485,-349,357,364,405,-1000,-419,527,-565,-541,-964,-1000,858,-310,629,1000,655,-997,-170,1000,-889,694,-182,33,998,898,-555,1000,-1000,-124,-1000,-1000,-761,-1000,-801,882,437,634,-773,1000,-95,565,-434,-760,1000,-676,55,236,-397,400,1000,-949,-352,873,34,-515,297,1000,-36,40,682,864,928}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00289() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getValue(org.jfree.data.time.RegularTimePeriod):java.lang.Number",
            new int[]{-907,1000,1000,-37,854,189,246,725,227,-645,-394,-1000,-972,27,-147,76,583,-513,615,120,-798,-104,-1000,736,371,694,1000,-264,-450,18,1000,1000,630,-812,5,736,1000,-192,-1000,-1000,925,-9,262,368,-28,-1000,431,593,-210,-1000,-221,-213,-793,420,1000,438,-367,-1000,-1000,1000,901,-468,-28,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00290() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getValue(org.jfree.data.time.RegularTimePeriod):java.lang.Number",
            new int[]{-366,121,82,1000,568,-526,-326,-775,110,-873,75,-22,791,963,-542,768,779,-923,1000,321,-868,-69,-20,829,809,-123,-260,1000,405,157,415,888,-180,-553,-93,422,270,-563,-27,-383,142,90,924,522,-203,-836,-1000,487,-544,-413,-379,-815,-146,1000,-430,-146,-531,324,177,273,488,-1000,-893,-166}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00291() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getValue(org.jfree.data.time.RegularTimePeriod):java.lang.Number",
            new int[]{-544,774,-689,-439,-1000,684,-378,233,-875,-644,-37,800,1000,-168,-299,-1000,72,965,1000,790,-141,1000,945,222,-356,-193,-400,-224,-990,241,-1000,-185,-931,-847,-958,-81,-1000,-316,126,-360,872,-968,-1000,-1000,220,656,-1000,712,-129,-56,-760,-64,1000,-669,1000,953,403,400,990,459,391,-1000,-211,-399}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00292() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getValue(org.jfree.data.time.RegularTimePeriod):java.lang.Number",
            new int[]{-854,1000,524,705,589,-687,19,-1,-341,-982,-176,-1000,93,1000,-640,708,84,-678,1000,336,-800,-69,-1000,1000,788,-156,222,1000,405,297,660,881,826,-851,76,796,270,-862,-27,-1000,142,481,924,466,-203,-836,-209,390,-486,-972,-379,-850,14,456,-430,13,-1000,185,382,1000,488,-606,-645,-231}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00293() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getValue(org.jfree.data.time.RegularTimePeriod):java.lang.Number",
            new int[]{-1000,852,202,1000,276,-241,114,1000,-286,-950,-133,-556,996,1000,-483,-103,1000,228,1000,-577,408,1000,-266,-183,-59,523,-702,1000,-771,-308,-520,738,433,-1000,-401,405,-371,-648,587,-1000,334,1000,109,505,601,661,-715,517,158,68,-959,396,742,-1000,-1000,1000,-328,740,1000,738,-542,-150,-1000,-263}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00294() {
        org.junit.Assert.assertEquals("java.lang.Double:NTYuNw==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getValue(org.jfree.data.time.RegularTimePeriod):java.lang.Number",
            new int[]{290,996,1000,0,567,-747,-1000,-295,-507,-175,543,-284,-518,-856,1000,-591,827,-221,707,0,-391,0,-1000,-163,0,0,343,0,641,742,377,596,-72,0,-867,-438,-1000,41,-1000,-785,648,361,-1000,-711,168,0,520,-896,-866,-811,-574,-314,484,-1000,-30,538,-70,213,7,190,-720,-1000,171,-400}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00295() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getValue(org.jfree.data.time.RegularTimePeriod):java.lang.Number",
            new int[]{-68,340,254,413,1000,-597,-1000,1000,58,-933,464,452,-446,1000,-659,546,-652,194,1000,72,-139,-894,-295,1000,299,-1000,-813,815,1000,1000,932,-15,124,-58,235,499,882,-161,537,74,1000,-628,-820,-483,-428,-699,-727,866,-807,-261,-129,-542,-591,925,961,-146,-1000,794,-771,115,662,-1000,188,-226}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00296() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getValue(org.jfree.data.time.RegularTimePeriod):java.lang.Number",
            new int[]{-865,1000,389,415,1000,-162,-400,1000,-591,-1000,874,-1000,-435,1000,-1000,-1000,-714,-341,380,1000,-197,129,-1000,722,132,-63,-400,-326,-123,1000,500,428,1000,-968,-237,1000,378,-951,-60,-664,1000,-358,262,-1000,-1000,493,-104,298,428,-1000,307,-895,548,-493,-23,444,-948,-1000,-216,882,1000,-479,-373,-705}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00297() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "getValue(org.jfree.data.time.RegularTimePeriod):java.lang.Number",
            new int[]{-995,1000,1000,-217,1000,429,246,725,358,-645,-306,-1000,-1000,-72,-92,-211,63,-625,514,152,-1000,-520,-1000,736,618,823,1000,-759,1000,313,1000,1000,1000,-701,-103,1000,1000,-25,-1000,-1000,925,-450,262,368,-493,-1000,633,167,30,-1000,19,-119,-1000,943,1000,193,-292,-1000,-1000,1000,772,-208,168,-579}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00298() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:Ng==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "removeAgedItems(boolean):void",
            new int[]{-212,37,-737,-537,-292,-630,284,158,-540,-44,-436,254,-626,674,-282,-16,206,669,-587,-153,-121,386,510,360,29,929,756,-651,842,858,846,47,-574,301,108,-265,-704,-89,324,-366,100,660,360,-218,-497,-285,768,-380,48,458,866,-852,10,-279,899,-1000,-395,130,-619,-161,-766,53,-35,-621}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00299() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:NA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "removeAgedItems(boolean):void",
            new int[]{1000,-883,450,-599,-762,-1000,-877,907,19,-353,-1000,1000,-432,528,348,-1000,40,-15,364,-98,-353,-1000,1000,219,1000,-497,414,1000,726,873,872,-507,1000,756,-1000,1000,-730,674,-88,1000,821,1000,-193,-521,-933,19,1000,-1000,-1000,1000,506,-1000,331,210,-103,-1000,-823,1000,-1000,145,-1000,-1000,826,-802}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00300() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:MQ==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "removeAgedItems(boolean):void",
            new int[]{-221,194,-1000,-1000,-174,322,-1000,348,-131,-327,157,567,-433,182,588,448,-218,792,114,211,304,736,-282,-157,-789,676,-140,-632,751,798,-858,318,1000,423,202,-247,-1000,-365,728,-1000,334,29,539,120,35,389,1000,-1000,-41,-638,925,-648,-967,-1000,904,-889,-89,823,237,-252,-756,-564,97,-224}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00301() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "removeAgedItems(boolean):void",
            new int[]{-275,-46,369,-238,-706,-424,548,974,-789,286,547,-42,-445,855,-619,-915,-472,364,-46,-998,258,554,224,-858,-342,-604,-111,-177,606,12,269,131,-398,359,339,645,243,131,-562,-168,312,254,-884,-533,-855,-985,738,-231,-995,-617,59,-858,652,433,753,369,-968,-143,82,887,73,565,-677,-584}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00302() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:Mg==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "removeAgedItems(boolean):void",
            new int[]{39,-543,-19,-690,-275,42,57,-632,-246,139,-1000,531,-636,140,337,-576,-9,514,-1,510,240,128,450,-175,-301,395,363,7,578,431,-369,-280,-645,173,39,492,-209,51,556,-618,272,466,743,220,-184,-21,467,18,-218,-413,582,-592,-646,-85,393,-616,-89,767,103,-702,-355,-335,75,21}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00303() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:Mw==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "removeAgedItems(boolean):void",
            new int[]{-468,1000,-830,-43,1000,-557,-1000,-851,1000,-1000,-54,1000,146,-875,-1000,-16,1000,-951,793,128,1000,-1000,706,1000,409,-1000,779,-390,-259,-164,-1000,572,93,-198,-40,479,-280,249,-687,-449,907,-1000,676,621,-187,530,741,849,21,497,1000,-568,-1000,151,890,1000,-443,1000,-619,-936,525,-1000,431,-588}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00304() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:MTA=", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "removeAgedItems(boolean):void",
            new int[]{-665,322,-867,-1000,-96,-154,751,784,463,-166,721,477,-621,-35,101,-855,-289,347,455,-1000,-674,317,-227,646,176,-866,-850,262,1000,917,-1000,202,421,206,693,382,-1000,-8,591,-90,1000,-217,9,-1000,993,-335,-156,35,195,677,893,32,201,151,1000,68,1000,159,-808,-223,-937,208,609,-465}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00305() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:Mw==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "removeAgedItems(boolean):void",
            new int[]{-1000,1000,-1000,-1000,138,511,279,193,1000,-647,1000,1000,-912,-1000,-1000,-1000,473,-331,757,-886,-759,-753,-17,1000,423,-1000,-1000,-42,758,554,-1000,-229,1000,-329,-335,731,-653,231,475,1000,1000,-874,-133,-1000,1000,-1000,-230,1000,593,886,916,732,327,873,1000,1000,1000,332,-1000,-263,-431,-219,1000,-690}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00306() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:MQ==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "removeAgedItems(boolean):void",
            new int[]{-1000,1000,148,1000,879,-91,-142,1000,-62,-674,-189,-129,214,660,708,-305,-221,-1000,-244,39,573,-941,955,244,1000,-515,-10,1000,370,627,296,1000,-590,-738,-385,610,1000,780,-1000,-488,183,-889,-580,783,-676,-136,618,484,-287,1000,222,-868,662,-1000,288,829,-219,-516,-533,1000,-323,818,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00307() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:NQ==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "removeAgedItems(long,boolean):void",
            new int[]{-119,1000,1000,-1000,-1000,-942,-1000,-211,-765,-158,559,-1000,1000,-650,-663,-266,994,-603,882,-1000,-978,1000,-279,-787,-95,-238,798,-1000,-407,134,-624,-1000,-220,989,-716,1000,-995,1000,-597,433,-415,845,-563,1000,24,-924,436,776,175,-149,-659,1000,-984,146,1000,1000,-127,-212,-706,8,694,-1000,1000,192}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00308() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "removeAgedItems(long,boolean):void",
            new int[]{-416,1000,464,-1000,77,-251,37,-943,-629,684,-61,-1000,471,-643,-1000,-950,-483,-1000,729,440,152,-60,189,-299,-1000,-1000,-980,1000,81,-497,258,-983,-151,513,804,845,150,740,-762,543,438,-57,-487,-694,1000,-1000,385,1000,-384,1000,964,-1000,-43,1000,826,-876,1000,1000,-1000,1000,-282,-838,-418,-135}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00309() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:MQ==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "removeAgedItems(long,boolean):void",
            new int[]{333,126,-405,-47,-1000,37,766,224,-783,-51,904,-48,-853,-305,979,-468,95,-865,-507,-417,-516,788,636,524,459,-927,946,1000,-419,-141,930,55,1000,-569,246,36,813,-1000,386,1000,-243,985,-455,-262,-798,-1000,-1000,387,-80,-1000,218,312,944,1000,16,1000,-625,449,531,-647,260,-886,642,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00310() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "removeAgedItems(long,boolean):void",
            new int[]{-1000,834,1000,-1000,-992,-327,-576,354,-561,1000,30,-417,1000,85,-18,1000,-191,1000,1000,-1000,-633,1000,-1000,668,1000,450,1000,-314,509,-1000,-1000,-1000,-1000,811,-1000,1000,-490,1000,-675,-171,355,404,378,1000,81,-1000,1000,332,-344,-644,-1000,-1000,-668,-1000,1000,245,797,590,-1000,-595,377,-1000,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00311() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:Mg==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "removeAgedItems(long,boolean):void",
            new int[]{-559,-1000,-668,433,231,-218,-341,815,-321,61,439,505,924,174,692,-609,-534,-611,-1000,-349,455,766,434,875,953,-169,99,837,-918,342,1000,222,-328,-98,-186,-713,-261,-945,227,-164,-472,-215,130,784,-291,-593,-333,-1000,-495,-278,1000,762,474,1000,-747,-328,-463,782,121,-350,-714,326,244,-252}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00312() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:Ng==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "removeAgedItems(long,boolean):void",
            new int[]{256,-154,-15,-300,591,295,1000,-751,-236,-16,190,-216,-293,-1000,-1000,-1000,-882,-1000,-351,1000,595,-760,1000,-1000,636,-1000,-1000,1000,-593,552,872,-788,811,-786,998,-55,1000,-1000,-116,891,77,-631,-1000,-694,700,-414,-520,805,-418,751,1000,89,731,1000,701,-1000,-258,1000,-154,804,-11,377,-418,-255}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00313() {
        org.junit.Assert.assertEquals("THROW:java.lang.NullPointerException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "removeAgedItems(long,boolean):void",
            new int[]{-23,178,-1000,92,-752,-398,-885,669,-1000,855,813,599,-1000,-1000,-1000,-471,300,327,-1000,234,-162,688,451,696,738,86,-918,942,365,1000,733,893,464,-140,-775,655,615,-1000,-248,754,-421,-746,-267,-38,-96,770,622,-195,-685,643,885,1000,1000,848,24,-582,100,1000,-538,-956,823,562,692,-961}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00314() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "removeAgedItems(long,boolean):void",
            new int[]{-374,1000,1000,-1000,-1000,-863,-915,-411,-1000,1000,883,-1000,1000,70,-553,-310,587,-722,1000,-551,-262,1000,-91,702,-373,395,-489,-250,-481,-685,982,-1000,27,1000,-916,1000,-1000,1000,-718,379,400,1000,339,-127,317,-1000,1000,730,362,-81,81,-130,-1000,-198,700,1000,430,352,-774,533,-156,-1000,382,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00315() {
        org.junit.Assert.assertEquals("VOID|getDomainDescription=java.lang.String:MHg4MDAwMDAwMDAwMDAwMDAwMDA=|getItemCount=java.lang.Integer:NQ==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "setDomainDescription(java.lang.String):void",
            new int[]{-1000,1000,1000,1000,1000,-206,1000,-565,529,-1000,-1000,-359,-1000,641,-319,1000,762,862,1000,-717,1000,1000,1000,778,1000,169,-1000,-981,44,62,-1000,221,-1000,-223,-1000,1,476,1000,-223,-594,916,-486,-1000,563,-891,413,-1000,1000,-752,-252,-314,1000,1000,-669,-1000,-1000,-47,608,100,-1000,-18,674,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00316() {
        org.junit.Assert.assertEquals("VOID|getDomainDescription=java.lang.String:ZmFsc2U=|getItemCount=java.lang.Integer:MQ==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "setDomainDescription(java.lang.String):void",
            new int[]{358,-613,274,-489,-742,811,-786,872,44,171,-9,106,359,213,-354,543,-934,540,-616,527,-426,-337,-503,312,886,605,377,-887,59,-509,470,216,741,730,560,-966,-960,704,880,-993,86,172,-818,-588,347,14,136,-718,14,-616,-797,869,579,-146,-514,425,-901,-268,-60,-617,607,-643,-158,-521}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00317() {
        org.junit.Assert.assertEquals("VOID|getDomainDescription=java.lang.String:|getItemCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "setDomainDescription(java.lang.String):void",
            new int[]{82,408,-1000,1000,-82,713,345,-1000,-478,441,744,251,230,16,-505,19,289,-7,1000,-1000,1000,536,824,-283,633,451,-255,-1000,-814,845,220,549,-1000,780,-1000,247,-3,-394,-348,1000,1000,-411,472,111,-588,-586,161,1000,-1000,978,-321,879,-105,253,-517,382,-28,86,-876,132,-1000,928,-1000,-297}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00318() {
        org.junit.Assert.assertEquals("VOID|getDomainDescription=java.lang.String:MHg4MDAwMDAwMDAwMDAwMDAw|getItemCount=java.lang.Integer:Mw==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "setDomainDescription(java.lang.String):void",
            new int[]{165,-184,484,1000,316,-227,562,-477,1000,74,-973,634,1000,697,150,1000,1000,591,1000,-1,1000,-1000,1000,795,-187,-415,-1000,-478,239,1000,292,646,-760,397,-1000,148,0,278,1000,134,695,-958,-35,172,111,-702,419,1000,-1000,-345,709,891,1000,432,-1000,-526,65,-120,-393,713,73,-153,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00319() {
        org.junit.Assert.assertEquals("VOID|getDomainDescription=java.lang.String:NjkwbA==|getItemCount=java.lang.Integer:Mw==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "setDomainDescription(java.lang.String):void",
            new int[]{1000,-292,-346,454,-643,739,-1000,-1000,265,1000,-588,1000,691,350,505,370,737,587,96,292,617,940,53,-402,-373,454,-348,-1000,-759,690,1000,394,-1000,-273,-890,835,-1000,-473,-541,391,72,240,-1000,-113,47,-1000,1000,1000,-1000,-193,722,-1000,666,1000,-374,442,-1000,-671,-984,1000,540,-915,-256,908}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00320() {
        org.junit.Assert.assertEquals("VOID|getDomainDescription=java.lang.String:LTk4MQ==|getItemCount=java.lang.Integer:Mg==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "setDomainDescription(java.lang.String):void",
            new int[]{-900,431,-196,-1000,152,529,592,709,-491,-516,-27,-59,441,-685,-729,55,-728,1000,1000,4,1000,713,716,1000,1000,523,899,-981,-11,-1000,-627,-38,-1000,-401,798,-1000,299,1000,1000,-1000,673,747,-1000,-234,-840,803,-981,1000,-752,443,-910,1000,104,-1000,-48,221,395,536,377,-1000,-558,514,-1000,-347}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00321() {
        org.junit.Assert.assertEquals("VOID|getDomainDescription=java.lang.String:MHgzZTg=|getItemCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "setDomainDescription(java.lang.String):void",
            new int[]{-559,1000,277,-36,641,354,182,-966,-26,-634,498,-279,201,-427,-1000,340,374,809,1000,-500,23,1000,-584,-177,1000,505,685,-981,-788,-372,-313,406,-760,199,-7,-736,594,644,1000,37,1000,164,-610,-327,-865,245,-1000,1000,-364,755,-1000,102,997,-196,30,-113,-113,-308,100,-670,-587,1000,-354,449}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00322() {
        org.junit.Assert.assertEquals("VOID|getDomainDescription=java.lang.String:KzB4ODAwMDAwMDAwMDAwMDAwMDA=|getItemCount=java.lang.Integer:NA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "setDomainDescription(java.lang.String):void",
            new int[]{-1000,1000,1000,1000,1000,924,574,-643,1000,-634,-789,-64,-1000,1000,-1000,1000,-65,1000,1000,-1000,1000,1000,1000,-47,1000,250,-1000,-1000,-606,436,-1000,583,-86,-67,-1000,-1000,594,1000,-559,-391,138,-1000,-1000,1000,-404,167,-1000,648,-1000,-519,-1000,1000,1000,-492,-433,-1000,640,870,100,-1000,1000,742,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00323() {
        org.junit.Assert.assertEquals("VOID|getDomainDescription=java.lang.String:LS01MDllLTY0Ng==|getItemCount=java.lang.Integer:MQ==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "setDomainDescription(java.lang.String):void",
            new int[]{-613,-527,568,-155,-365,116,-126,1000,117,-1000,676,-1000,-174,-310,223,417,-1000,-501,-1000,754,-1000,-1000,-69,128,755,-159,-474,509,631,-646,874,-800,569,950,453,-747,907,278,1000,-1000,-875,520,254,-366,-152,945,-1000,-1000,-79,76,-1000,915,-863,-1000,55,599,1000,-833,1000,-348,727,185,-1000,396}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00324() {
        org.junit.Assert.assertEquals("VOID|getDomainDescription=java.lang.String:NnFcNl91NnoKNl9fdA==|getItemCount=java.lang.Integer:Nw==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "setDomainDescription(java.lang.String):void",
            new int[]{-900,82,171,-1000,1000,-1000,251,774,-853,-658,746,-1000,31,-842,-1000,-691,1000,-683,-764,1000,-1000,-462,-754,-1000,-1000,-1000,737,1000,1000,-631,1000,-1000,703,-20,601,-762,1000,-684,778,1000,-1000,-467,1000,-817,-782,1000,-1000,-1000,-752,113,788,-1000,-1000,-575,1000,462,319,565,1000,-160,1000,335,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00325() {
        org.junit.Assert.assertEquals("VOID|getDomainDescription=java.lang.String:LTY5OA==|getItemCount=java.lang.Integer:MQ==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "setDomainDescription(java.lang.String):void",
            new int[]{1000,-1000,-633,-1000,-1000,144,-180,-829,-819,327,-261,504,1000,-1000,387,-289,-975,686,-1000,387,-698,-1000,-912,1000,121,396,1000,-560,697,980,117,1000,-1000,133,1000,-978,-1000,-717,-41,-1000,1000,-743,-72,-1000,329,-747,1000,1000,-1000,302,-966,-871,-39,346,312,1000,-1000,-1000,-1000,858,625,324,-537,-379}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00326() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "setMaximumItemAge(long):void",
            new int[]{1000,944,-1000,-962,1000,-402,-372,944,-1000,-1000,-1000,489,707,-243,-551,1000,406,-322,400,-438,481,-732,-604,-964,-155,-1000,-1000,1000,1000,-333,1000,-582,801,-387,1000,1000,1000,1000,848,-1000,503,635,1000,319,135,-729,105,466,1000,400,-858,-202,794,209,-603,-835,-1000,-815,1000,816,754,-1000,93,651}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00327() {
        org.junit.Assert.assertEquals("VOID|getMaximumItemAge=java.lang.Long:MA==|getItemCount=java.lang.Integer:MQ==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "setMaximumItemAge(long):void",
            new int[]{913,-1000,951,-1000,-1000,-611,-233,-815,270,-302,1000,-766,20,-967,-111,-402,749,1000,-1000,-1000,1000,-113,-995,-411,-719,-759,604,876,1000,1000,-770,-179,-749,-386,1000,-781,1000,924,185,-950,-66,941,-1000,11,-1000,425,-1000,1000,1000,-1000,-198,385,635,-699,-88,1000,-973,-949,-1000,983,-745,334,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00328() {
        org.junit.Assert.assertEquals("VOID|getMaximumItemAge=java.lang.Long:MjE0NzQ4MzY0Nw==|getItemCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "setMaximumItemAge(long):void",
            new int[]{-661,-310,-324,-274,208,-606,-121,-132,-400,-825,-184,109,-58,-229,79,321,307,-55,-492,-322,587,-912,52,400,-309,250,-206,693,419,201,909,-460,-312,-1000,275,679,1000,98,759,393,407,429,999,305,-210,-369,-63,323,1000,-195,-253,468,257,-171,325,1000,-945,-563,-292,-69,435,-97,-697,-5}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00329() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "setMaximumItemAge(long):void",
            new int[]{-1000,67,-1000,-613,1000,-324,153,333,-771,-94,-804,733,702,-350,-425,259,-400,-1000,400,-428,259,-732,156,-369,21,-210,-337,1000,288,-143,568,-582,62,-299,933,1000,193,1000,848,-1000,56,-46,703,79,268,-1000,-12,33,-838,400,-638,-48,612,-405,324,-1000,-264,-13,412,-596,754,-781,-448,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00330() {
        org.junit.Assert.assertEquals("VOID|getMaximumItemAge=java.lang.Long:MA==|getItemCount=java.lang.Integer:MQ==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "setMaximumItemAge(long):void",
            new int[]{-382,-110,-820,58,1000,-111,609,-842,-497,-130,-1000,-448,-573,-596,478,-557,525,-308,421,-447,679,-499,668,302,-348,-16,296,711,-734,49,222,-28,-331,-163,605,1000,534,445,868,-835,-236,-550,1000,-357,389,354,-324,892,215,-519,-867,-539,301,-827,239,-545,593,545,-57,108,1000,-944,-20,231}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00331() {
        org.junit.Assert.assertEquals("VOID|getMaximumItemAge=java.lang.Long:OTIyMzM3MjAzNjg1NDc3NTgwNw==|getItemCount=java.lang.Integer:MQ==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "setMaximumItemAge(long):void",
            new int[]{1000,-624,-1000,-868,1000,-217,-372,157,-99,-1000,-280,-18,162,-320,-551,-142,406,-1000,1,-415,481,-1000,1000,1000,-220,488,731,361,134,1000,-102,-1000,-1000,-1000,1000,596,1000,1000,1000,-208,1000,-797,-644,215,-739,-1000,-1000,-584,1000,-29,-1000,-242,1000,-738,1000,1000,1000,489,-301,816,793,-1000,-1000,241}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00332() {
        org.junit.Assert.assertEquals("VOID|getMaximumItemAge=java.lang.Long:MA==|getItemCount=java.lang.Integer:MQ==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "setMaximumItemAge(long):void",
            new int[]{-379,-150,30,-289,689,17,-607,-236,620,-53,-1000,-46,-984,972,-73,-359,1000,-957,360,-1000,-39,-838,1000,1000,699,803,1000,-687,-1000,-583,665,559,-455,-940,-324,826,-984,18,91,-692,-257,-1000,-26,-446,720,-252,657,362,-833,21,-388,-503,-141,-670,1000,-527,1000,1000,484,-221,982,-170,641,548}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00333() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "setMaximumItemAge(long):void",
            new int[]{860,-688,-861,-1000,1000,-711,453,1000,-1000,-1000,-981,-661,-220,230,-1000,163,141,-1000,-1000,-18,1000,-1000,1000,486,-1000,-550,564,66,1000,1000,1000,-587,-1000,-611,1000,1000,1000,1000,297,-128,1000,-789,-1000,564,-149,-623,960,-1000,927,565,-1000,-507,328,-857,1000,1000,1000,-173,-574,-501,-395,-1000,-1000,-202}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00334() {
        org.junit.Assert.assertEquals("VOID|getMaximumItemAge=java.lang.Long:MA==|getItemCount=java.lang.Integer:MQ==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "setMaximumItemAge(long):void",
            new int[]{1000,579,946,-1000,1000,-82,-538,1000,42,-1000,-245,794,1000,-732,654,-439,-71,-1000,-1000,-794,-514,-542,-348,120,-412,839,252,869,623,-65,117,-711,-194,-918,-62,1000,214,1000,508,-871,150,-786,462,1000,578,-1000,-284,376,-96,-302,-633,-511,667,-1000,448,-209,179,170,13,-1000,419,580,-215,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00335() {
        org.junit.Assert.assertEquals("VOID|getMaximumItemAge=java.lang.Long:MA==|getItemCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "setMaximumItemAge(long):void",
            new int[]{1000,-1000,724,703,-1000,-716,-759,-1000,989,-1000,1000,-656,-1000,276,-134,-1000,1000,1000,387,-75,659,871,589,411,-286,1000,1000,297,-728,1000,-702,912,-1000,-150,418,-1000,573,-838,-451,479,-555,253,-1000,-764,-352,791,-1000,27,1000,-795,230,-432,-164,-1000,1000,1000,488,319,-1000,1000,-1000,817,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00336() {
        org.junit.Assert.assertEquals("VOID|getMaximumItemCount=java.lang.Integer:MA==|getItemCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "setMaximumItemCount(int):void",
            new int[]{862,1000,1000,1000,-16,542,258,-785,-1000,1000,-168,-1000,1000,234,-1000,-139,-555,-526,-588,197,-1000,-600,-1000,-402,-1000,168,593,-57,1000,863,-560,1000,1000,1000,630,-690,-460,1000,259,442,1000,1000,178,374,-1000,523,-241,-1000,1,-1000,1000,1000,-645,236,1000,971,-707,708,249,635,169,295,-406,479}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00337() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "setMaximumItemCount(int):void",
            new int[]{-1000,-1000,614,-847,-1000,594,-52,1000,-620,-408,-167,-1000,-1000,1000,-116,1000,-985,-1000,-1000,-135,-417,-583,1000,-705,-729,1000,-257,-168,639,-232,1000,531,163,784,459,-477,1000,556,-906,715,-1000,231,476,-275,388,-207,-107,-260,908,-84,-208,-1000,-1000,-510,96,521,1000,-126,1000,530,1000,-735,-1000,-265}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00338() {
        org.junit.Assert.assertEquals("VOID|getMaximumItemCount=java.lang.Integer:MjE0NzQ4MzY0Nw==|getItemCount=java.lang.Integer:MQ==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "setMaximumItemCount(int):void",
            new int[]{720,-587,-458,-763,292,1000,-757,-909,375,-401,-82,767,1000,-556,457,-467,690,1000,600,501,0,-456,-1000,-358,894,-1000,987,146,897,794,466,1000,-427,1000,-149,-876,-1000,-71,978,1000,12,-214,-598,-305,-431,370,903,-755,344,-29,597,1000,801,-763,1000,1000,-1000,234,-1000,1000,-310,1000,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00339() {
        org.junit.Assert.assertEquals("VOID|getMaximumItemCount=java.lang.Integer:MQ==|getItemCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "setMaximumItemCount(int):void",
            new int[]{924,-210,-185,-451,337,596,600,64,830,-324,-680,754,1000,-839,457,466,991,814,1000,372,741,260,-795,-286,-528,-384,109,-432,620,1000,-772,668,156,-347,290,53,-263,343,-703,1000,-327,297,676,-454,-1000,-27,796,-898,117,-747,307,97,842,846,533,-159,-370,1000,-1000,-310,71,373,1000,386}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00340() {
        org.junit.Assert.assertEquals("VOID|getMaximumItemCount=java.lang.Integer:MA==|getItemCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "setMaximumItemCount(int):void",
            new int[]{1000,-210,962,-265,337,-345,134,-641,-40,-324,96,-213,1000,993,457,466,-125,-316,-529,1000,-880,-1000,-670,212,112,91,109,-432,23,1000,-413,-56,421,1000,417,-381,-1000,2,-703,-108,805,788,-23,530,-590,605,736,-763,-563,-679,-470,1000,-757,-335,387,684,-312,-165,-326,480,214,1000,656,-879}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00341() {
        org.junit.Assert.assertEquals("VOID|getMaximumItemCount=java.lang.Integer:MjE0NzQ4MzY0Nw==|getItemCount=java.lang.Integer:Nw==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "setMaximumItemCount(int):void",
            new int[]{-524,-341,-723,-1000,-1000,667,552,248,844,-605,-730,1000,-1000,-1000,346,1000,810,1000,161,363,1000,-23,1000,-690,-1000,1000,-1000,-1000,196,591,-998,-860,-901,-1000,165,1000,666,-568,-1000,1000,-1000,1000,1000,-437,-808,-255,845,-820,574,-1000,-992,-1000,868,1000,-1000,-130,-796,1000,-1000,410,489,125,1000,-220}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00342() {
        org.junit.Assert.assertEquals("VOID|getMaximumItemCount=java.lang.Integer:MjE0NzQ4MzY0Nw==|getItemCount=java.lang.Integer:Mw==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "setMaximumItemCount(int):void",
            new int[]{46,884,24,1000,-28,-201,-959,720,-447,-159,146,-101,-4,961,-381,-583,441,217,-1000,-153,-344,-740,-302,20,330,-899,947,825,1000,-96,754,1000,1000,623,-1000,-814,373,-322,1000,-429,366,-256,-966,-616,154,1000,-405,123,1000,1000,-831,1000,-561,-1000,-503,-18,385,-769,904,1000,-146,1000,-191,108}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00343() {
        org.junit.Assert.assertEquals("VOID|getRangeDescription=java.lang.String:MHg4|getItemCount=java.lang.Integer:Ng==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "setRangeDescription(java.lang.String):void",
            new int[]{66,-499,-1000,-941,75,-746,109,103,500,-546,467,-130,-1000,10,522,-577,1000,-817,-1000,691,756,648,-1000,48,552,-222,1000,-1000,-1000,-1000,-1000,1000,226,1000,1000,-462,1000,1000,-769,541,-1000,66,-1000,-1000,-1000,136,-529,816,225,-253,-601,1000,-674,-1000,455,1000,822,1000,342,-790,289,485,916,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00344() {
        org.junit.Assert.assertEquals("VOID|getRangeDescription=java.lang.String:LS0weDNlOA==|getItemCount=java.lang.Integer:NA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "setRangeDescription(java.lang.String):void",
            new int[]{462,-567,545,-1000,-119,-251,454,1000,126,640,-261,239,30,-1000,-464,912,254,199,-158,-724,918,-557,608,709,62,-472,95,491,-406,172,142,240,-1000,45,652,752,404,-52,-74,240,935,1000,435,-1000,865,-347,670,-1,199,25,-1000,-331,722,123,-217,-847,400,-219,-1000,203,25,-490,-83,625}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00345() {
        org.junit.Assert.assertEquals("VOID|getRangeDescription=NULL|getItemCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "setRangeDescription(java.lang.String):void",
            new int[]{-629,-740,350,-1000,-198,-441,814,1000,474,486,-180,188,37,-347,-760,874,-252,421,613,-334,-73,-556,-404,1000,-339,-96,179,420,572,674,161,-914,510,-469,212,-224,434,-62,194,-79,640,673,773,-374,987,-34,-58,-569,-470,115,-455,-101,677,1000,-443,-1000,1000,-302,-957,-305,-254,789,-359,579}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00346() {
        org.junit.Assert.assertEquals("VOID|getRangeDescription=java.lang.String:|getItemCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "setRangeDescription(java.lang.String):void",
            new int[]{980,-754,253,-1000,21,-598,798,898,330,1000,408,-138,-128,-1000,-97,267,254,-287,-158,-557,1000,946,312,900,1000,-744,-1000,328,-1000,938,-283,240,-1000,1000,-140,814,552,379,-288,-89,935,855,-496,-1000,448,129,426,472,151,-393,-1000,-202,894,1000,-767,-924,589,-145,-1000,903,483,-1000,-601,-486}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00347() {
        org.junit.Assert.assertEquals("VOID|getRangeDescription=java.lang.String:MHg4MDAwMDAw|getItemCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "setRangeDescription(java.lang.String):void",
            new int[]{-499,-1000,-1000,-1000,904,-566,-993,-49,-385,230,690,1000,-856,1000,182,-1000,1000,-834,-165,1000,647,597,-376,-611,1000,-654,520,-1000,-1000,284,-1000,690,-1000,1000,599,-374,1000,1000,-577,284,-1000,279,-1000,-1000,-1000,279,1000,612,-1000,-819,-213,820,-964,-1000,916,304,591,1000,-1000,-1000,710,-56,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00348() {
        org.junit.Assert.assertEquals("VOID|getRangeDescription=NULL|getItemCount=java.lang.Integer:OA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "setRangeDescription(java.lang.String):void",
            new int[]{-1000,-426,1000,-280,-810,123,-391,124,301,634,-1000,-503,40,1000,-1000,882,-1000,-123,861,50,-1000,-201,378,-906,1000,987,65,-394,1000,-852,-482,-125,-384,-214,431,-540,-33,-366,-558,1000,124,-868,-574,1000,-56,568,1000,-582,-389,-246,1000,-1000,-1000,539,140,19,-113,1000,157,-1000,294,894,1000,-724}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00349() {
        org.junit.Assert.assertEquals("VOID|getRangeDescription=java.lang.String:UGRFX2k=|getItemCount=java.lang.Integer:OA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "setRangeDescription(java.lang.String):void",
            new int[]{-1000,-209,1000,-853,348,-729,533,-422,-783,-981,216,-975,-1000,-1000,-230,308,-25,-581,-467,1000,-809,-658,1000,-413,180,619,-555,-670,-1000,728,-512,-660,1000,-339,1000,-780,736,569,230,-120,-795,-152,-873,299,-334,932,389,573,-939,981,1000,-1000,902,-75,77,430,514,-128,-194,43,-1000,1000,237,394}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00350() {
        org.junit.Assert.assertEquals("VOID|getRangeDescription=java.lang.String:|getItemCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "setRangeDescription(java.lang.String):void",
            new int[]{-745,1000,1000,1000,-1000,732,576,74,1000,602,-1000,78,-1000,121,-1000,1000,-1000,1000,1000,-1000,-1000,-1000,-521,-267,906,-125,-400,-75,1000,-1000,-908,-1000,380,-1000,878,-46,-1000,1000,-818,1000,757,-905,327,-1000,763,1000,1000,-1000,-365,-677,-721,-969,-846,1000,-122,-22,591,905,1000,-682,424,912,710,300}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00351() {
        org.junit.Assert.assertEquals("VOID|getRangeDescription=java.lang.String:MHg4MDAwMDAwMDAwMDAwMDAwMDAw|getItemCount=java.lang.Integer:MA==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "setRangeDescription(java.lang.String):void",
            new int[]{-196,6,1000,-939,313,-328,-308,-586,311,-108,450,-234,-1000,-1000,171,533,282,-712,-868,384,-182,314,59,-911,625,-479,-914,-769,-1000,209,-937,-162,876,440,-44,-275,691,699,-139,751,-865,316,-911,356,-314,617,-647,701,232,-86,939,-1000,267,-353,354,-445,547,377,-194,537,195,-325,428,-315}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00352() {
        org.junit.Assert.assertEquals("THROW:java.lang.IndexOutOfBoundsException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "update(int,java.lang.Number):void",
            new int[]{-1000,855,77,198,-245,465,-364,-479,-437,-1000,-1000,1000,-473,64,-94,6,87,-683,-458,7,995,-559,-453,562,-715,-109,-834,-727,634,177,-887,-366,421,791,490,-1000,-851,-1000,-18,26,130,-419,-993,628,1000,306,-1000,67,1000,388,20,95,-345,1000,-912,27,-1000,-226,587,-1000,886,730,-522,807}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00353() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:Nw==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "update(int,java.lang.Number):void",
            new int[]{-790,155,-639,256,735,667,-345,-977,-577,-434,-133,-400,235,-580,-775,347,-327,-205,-203,-630,1000,127,589,379,-214,-2,-581,-683,669,-434,-483,257,-388,-306,457,445,400,-1000,506,-745,155,494,-231,286,-469,-532,-132,-649,-383,-332,-743,-773,-771,168,-527,410,-1000,17,1000,-465,122,-488,54,164}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00354() {
        org.junit.Assert.assertEquals("THROW:java.lang.IndexOutOfBoundsException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "update(int,java.lang.Number):void",
            new int[]{6,726,-470,31,1000,763,664,177,-775,208,-849,585,-296,-387,-404,-305,96,579,-842,-1000,1000,-181,690,63,-860,1000,-318,-78,1000,6,-13,-636,1000,-490,519,509,-1000,210,-278,-456,646,-1000,575,25,-1000,1000,-966,1000,-433,503,-1000,418,595,897,-669,620,1000,-626,-864,-1000,-284,83,-619,391}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00355() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:NQ==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "update(int,java.lang.Number):void",
            new int[]{267,-621,-81,617,30,333,528,-38,-423,504,255,-624,-241,261,129,-570,615,-615,-393,412,319,-511,41,332,743,1000,-514,-833,38,-258,-222,-514,-176,641,1000,663,-659,-53,-500,-231,-1000,-541,-363,533,105,-395,446,1000,-132,648,1000,1000,314,193,1000,-190,946,468,-1000,-570,-228,133,-463,580}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00356() {
        org.junit.Assert.assertEquals("THROW:java.lang.IndexOutOfBoundsException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "update(int,java.lang.Number):void",
            new int[]{385,587,-893,593,455,284,-888,5,-821,818,-254,165,297,379,-134,681,675,179,7,511,1000,527,1000,981,449,908,1000,459,49,-1000,1000,257,94,-21,159,770,863,-57,54,-499,96,461,1000,286,-1000,-872,1000,1000,-1000,-347,-284,-660,-232,-391,685,-30,476,370,-1000,81,-432,-645,-143,-731}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00357() {
        org.junit.Assert.assertEquals("THROW:java.lang.IndexOutOfBoundsException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "update(int,java.lang.Number):void",
            new int[]{-700,89,-741,178,1000,911,-672,-909,-730,271,386,-1000,-833,-1000,-960,210,409,217,138,-676,1000,413,826,469,229,754,-401,-915,527,-453,-423,795,-161,-568,224,-1000,1000,-1000,641,-958,-82,1000,88,-20,-271,-895,240,-527,-976,-28,-1000,-942,-1000,-188,-450,869,-1000,640,102,-235,-254,-1000,959,-194}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00358() {
        org.junit.Assert.assertEquals("THROW:java.lang.IndexOutOfBoundsException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "update(int,java.lang.Number):void",
            new int[]{-1000,297,-281,56,367,1000,893,509,-574,-672,-1000,788,-1000,-358,-691,1000,1000,-193,-535,-1000,489,-714,937,728,-238,321,-1000,-85,1000,-33,-1000,-514,963,158,620,-1000,-342,-152,-99,399,-979,1000,-1000,1000,1000,-118,-1000,-1000,1000,143,20,736,-54,1000,-1000,1000,-737,-420,-586,-455,770,287,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00359() {
        org.junit.Assert.assertEquals("THROW:java.lang.IndexOutOfBoundsException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "update(int,java.lang.Number):void",
            new int[]{508,426,-1000,715,247,284,543,-356,-531,620,225,487,-263,362,-155,-80,735,92,-575,130,523,-489,95,1000,675,716,834,1000,1000,-1000,90,-1000,123,690,760,712,-596,482,-550,563,-358,59,-207,673,-279,-400,1000,526,-617,-57,1000,801,409,99,1000,-145,522,397,-1000,-504,140,-56,722,400}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00360() {
        org.junit.Assert.assertEquals("THROW:java.lang.IndexOutOfBoundsException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "update(int,java.lang.Number):void",
            new int[]{340,251,-141,832,404,253,1000,497,-626,816,518,14,235,-104,-312,-567,180,-236,-775,718,244,-580,-383,379,814,679,-552,-950,99,-158,306,-542,-388,541,589,445,-180,-190,-116,88,-905,-742,143,607,-469,-736,573,1000,270,66,-18,1000,759,58,416,699,294,-453,-1000,-62,77,-291,-1000,704}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00361() {
        org.junit.Assert.assertEquals("THROW:java.lang.IndexOutOfBoundsException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "update(int,java.lang.Number):void",
            new int[]{-586,598,-69,1000,1000,458,1000,582,-96,-136,-582,1000,-524,582,-610,47,-664,158,-393,-12,325,-1000,408,-279,302,-248,-1000,-546,561,-1000,-893,-1000,736,349,1000,-343,-1000,-1000,-515,866,-1000,-368,-827,533,1000,-246,-1000,-144,1000,225,1000,1000,1000,770,-38,229,-107,-1000,-72,-837,-66,461,49,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00362() {
        org.junit.Assert.assertEquals("THROW:java.lang.IndexOutOfBoundsException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "update(int,java.lang.Number):void",
            new int[]{627,398,78,1000,-155,-267,953,234,-915,1000,983,884,578,1000,-60,-1000,-181,954,-1000,1000,319,-927,-1000,146,1000,683,-631,-1000,38,-302,186,-514,-778,1000,1000,1000,-1000,-704,-498,1000,-427,-1000,295,1000,-1000,-149,492,898,840,236,1000,766,1000,407,1000,-1000,608,-584,-202,-1000,611,-79,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00363() {
        org.junit.Assert.assertEquals("THROW:org.jfree.data.general.SeriesException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "update(org.jfree.data.time.RegularTimePeriod,java.lang.Number):void",
            new int[]{-349,1000,-1000,-384,-638,4,948,-527,486,1000,398,1000,-181,1000,1000,382,-1000,103,211,391,815,347,-254,-25,-889,111,-676,-1000,923,-904,-527,1000,-1000,401,-1000,-162,-911,-1000,934,-659,-53,-979,-1000,-268,96,723,1000,304,-58,-984,560,-485,352,1000,-243,421,65,-1000,428,109,772,224,-994,-854}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00364() {
        org.junit.Assert.assertEquals("THROW:org.jfree.data.general.SeriesException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "update(org.jfree.data.time.RegularTimePeriod,java.lang.Number):void",
            new int[]{804,-691,-43,72,-907,379,549,42,-441,-22,1000,-917,-1000,394,-1000,450,-327,830,543,-645,618,-8,-46,-574,196,-386,-396,927,-832,766,-995,738,-524,1000,326,-913,139,-1000,-537,668,-1000,-425,427,-1000,659,-891,1000,-1000,-246,-1000,352,15,1000,489,-503,393,470,26,734,-484,708,639,164,-752}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00365() {
        org.junit.Assert.assertEquals("THROW:org.jfree.data.general.SeriesException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "update(org.jfree.data.time.RegularTimePeriod,java.lang.Number):void",
            new int[]{-349,-551,-226,-200,440,402,399,-216,1000,-108,-811,15,-566,450,342,382,603,-459,-682,19,154,435,-106,-288,-889,-466,-873,920,-327,-455,124,491,-881,514,-1000,-66,-1000,616,-40,1000,-680,-701,-1000,642,-713,-581,-716,220,1000,-349,427,-991,-799,-1000,-1000,647,65,-1000,-1000,1000,772,-91,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00366() {
        org.junit.Assert.assertEquals("THROW:org.jfree.data.general.SeriesException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "update(org.jfree.data.time.RegularTimePeriod,java.lang.Number):void",
            new int[]{-1000,688,-957,120,142,154,-302,-1000,129,878,539,912,485,1000,1000,-5,-479,448,-2,198,-726,-1000,-153,-109,-604,60,-610,-1000,302,-579,888,488,-816,462,-69,798,237,-662,923,-260,174,-668,-1000,300,-776,1000,1000,-309,-135,-105,-228,-61,-377,-830,-471,110,-385,-948,746,-363,-293,464,-400,191}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00367() {
        org.junit.Assert.assertEquals("THROW:org.jfree.data.general.SeriesException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "update(org.jfree.data.time.RegularTimePeriod,java.lang.Number):void",
            new int[]{-203,-27,-224,383,-555,632,-191,-976,863,304,620,-885,-292,-361,749,373,-35,972,-754,-274,-78,24,10,-959,-454,-141,-903,806,543,652,55,-669,-26,416,181,133,859,-949,502,-62,923,831,201,-21,-662,740,266,138,-854,-43,-801,879,-130,-758,-233,-106,789,-56,-25,910,301,958,-261,-789}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00368() {
        org.junit.Assert.assertEquals("VOID|getItemCount=java.lang.Integer:Mg==", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "update(org.jfree.data.time.RegularTimePeriod,java.lang.Number):void",
            new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00369() {
        org.junit.Assert.assertEquals("THROW:org.jfree.data.general.SeriesException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "update(org.jfree.data.time.RegularTimePeriod,java.lang.Number):void",
            new int[]{-30,-13,-281,1000,-652,-22,-1000,-1000,878,-351,1000,-197,-325,237,919,-1000,384,-36,1000,-1000,116,560,-656,-626,1000,-586,-1000,295,-901,1000,-24,92,-1000,1000,689,-836,1000,-1000,-1000,1000,66,277,-303,-690,563,-978,1000,-1000,-658,925,-129,-997,194,-1000,-514,393,30,-245,1000,-1000,1000,1000,164,225}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00370() {
        org.junit.Assert.assertEquals("THROW:org.jfree.data.general.SeriesException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "update(org.jfree.data.time.RegularTimePeriod,java.lang.Number):void",
            new int[]{188,-1000,23,1000,-1000,459,-838,-78,-1000,-1000,1000,-1000,-1000,466,-1000,-1000,1000,-97,-866,-1000,170,1000,-339,-1000,1000,387,-668,722,-1000,1000,-1000,-513,-938,535,974,-1000,1000,-884,-1000,1000,-1000,838,1000,-1000,1000,-1000,730,-1000,-1000,257,1000,-952,1000,336,93,1000,938,1000,891,-1000,1000,1000,-551,-348}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00371() {
        org.junit.Assert.assertEquals("THROW:org.jfree.data.general.SeriesException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "update(org.jfree.data.time.RegularTimePeriod,java.lang.Number):void",
            new int[]{1000,-27,208,1000,-910,-716,64,47,863,-1000,1000,-867,-1000,-361,-410,373,1000,397,-754,-1000,-78,311,-42,-1000,545,806,-903,1000,-1000,1000,101,-669,-1000,361,66,-1000,483,51,-802,-62,968,-1000,-56,-21,1000,-193,1000,379,-891,49,-570,-1000,-251,-240,-740,1000,-179,1000,344,910,1000,196,-261,-244}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00372() {
        org.junit.Assert.assertEquals("THROW:org.jfree.data.general.SeriesException", DEReplay.run(
            "org.jfree.data.time.TimeSeries", "org.jfree.data.time.TimeSeries", "update(org.jfree.data.time.RegularTimePeriod,java.lang.Number):void",
            new int[]{-320,-755,-67,-500,91,1000,-412,-598,1000,-130,-331,-719,-324,-1000,-160,-311,642,462,-1000,-628,-727,-45,-164,-445,-1000,-1000,-614,820,930,87,-345,491,127,1000,-165,548,-154,526,-375,787,-538,285,255,90,-1000,-1000,-1000,-405,669,719,-448,72,-331,-1000,-767,-1000,809,-686,-741,623,311,-738,1000,832}));
    }
}
