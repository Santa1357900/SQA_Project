import java.lang.reflect.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Deterministic test-program decoder. Used unchanged during search and JUnit replay. */
final class DEReplay {
    public static final int DIMENSIONS = 64;
    /** Local generic bean used to create stable reflection Type and Field values. */
    public static final class GenericInput {
        public String text;
        public java.util.List<String> names;
        public java.util.Map<String, Integer> counts;
        public java.util.List<java.util.Map<String, Long>> nested;
        public int[] numbers;
        public String[] words;
    }
    static final class Genes {
        final int[] values; int at; Field lastField;
        Object jacksonBean, jacksonProvider, jacksonGenerator;
        StringWriter jacksonOutput;
        Genes(int[] values) { this.values = values; }
        int next() { return values[(at++) % values.length]; }
        int pick(int n) { return Math.floorMod(next(), n); }
    }
    public static final class Observation {
        public String token, error, generatedSource;
        public boolean reachedTarget;
        public int setupCalls, setupFailures, nullFallbacks;
    }
    public static String signature(Method m) {
        StringJoiner params = new StringJoiner(",");
        for (Class<?> t : m.getParameterTypes()) params.add(t.getTypeName());
        return m.getName() + "(" + params + "):" + m.getReturnType().getTypeName();
    }
    static Class<?> load(String name) throws ClassNotFoundException {
        return Class.forName(name, true, Thread.currentThread().getContextClassLoader());
    }
    static Method method(String target, String signature) throws Exception {
        for (Method m : load(target).getDeclaredMethods())
            if (signature(m).equals(signature)) {
                // Public methods on package-private Defects4J classes (for
                // example Gson's TypeInfoFactory) are not reflectively
                // accessible until opened on the unnamed application module.
                if (!m.isAccessible()) m.setAccessible(true);
                return m;
            }
        throw new NoSuchMethodException(signature);
    }
    static List<Constructor<?>> constructors(Class<?> type) {
        List<Constructor<?>> out = new ArrayList();
        if (!Modifier.isAbstract(type.getModifiers()) && Modifier.isPublic(type.getModifiers()))
            for (Constructor<?> c : type.getConstructors())
                if (c.getParameterTypes().length <= 6) out.add(c);
        Collections.sort(out, new Comparator<Constructor<?>>() {
            public int compare(Constructor<?> a, Constructor<?> b) {
                int byArity = a.getParameterTypes().length - b.getParameterTypes().length;
                return byArity != 0 ? byArity : a.toString().compareTo(b.toString());
            }
        });
        return out;
    }
    private static Object[] arguments(Class<?>[] types, Genes g, int depth,
                                      Observation report) throws Exception {
        Object[] args = new Object[types.length];
        for (int i = 0; i < types.length; i++) args[i] = value(types[i], g, depth, report);
        return args;
    }
    private static Object[] arguments(Method method, Genes g, int depth,
                                      Observation report) throws Exception {
        Class<?>[] types = method.getParameterTypes();
        Object[] args = new Object[types.length];
        boolean closureCompile = method.getDeclaringClass().getName().equals("com.google.javascript.jscomp.Compiler")
            && method.getName().equals("compile");
        Type[] generic = method.getGenericParameterTypes();
        boolean jacksonSerialization = method.getDeclaringClass().getName().equals(
            "com.fasterxml.jackson.databind.ser.BeanPropertyWriter")
            && method.getName().startsWith("serializeAs")
            && types.length == 3 && types[0] == Object.class;
        for (int i = 0; i < types.length; i++) {
            if (jacksonSerialization && g.jacksonBean != null) {
                if (i == 0) args[i] = g.jacksonBean;
                else if (i == 1) args[i] = g.jacksonGenerator;
                else args[i] = g.jacksonProvider;
                continue;
            }
            if (closureCompile && (List.class.isAssignableFrom(types[i])
                    || (types[i].isArray() && load("com.google.javascript.jscomp.SourceFile")
                        .isAssignableFrom(types[i].getComponentType())))) {
                // Compiler.compile takes externs and inputs in either Lists or
                // arrays depending on Closure version. Keep externs empty and
                // supply a nonempty, gene-selected input program.
                if (i == 0) args[i] = types[i].isArray()
                    ? Array.newInstance(types[i].getComponentType(), 0) : new ArrayList();
                else {
                    Object sourceFile = value(load("com.google.javascript.jscomp.SourceFile"),
                        g, depth + 1, report);
                    if (types[i].isArray()) {
                        Object files = Array.newInstance(types[i].getComponentType(), 1);
                        Array.set(files, 0, sourceFile); args[i] = files;
                    } else args[i] = new ArrayList(Collections.singletonList(sourceFile));
                }
            } else args[i] = value(types[i], g, depth, report);
        }
        return args;
    }
    private static Number number(Genes g) {
        int n = g.next();
        switch (g.pick(12)) {
            case 0: return 0; case 1: return 1; case 2: return -1;
            case 3: return Integer.MAX_VALUE; case 4: return Integer.MIN_VALUE;
            case 5: return Long.MAX_VALUE; case 6: return Long.MIN_VALUE;
            case 7: return Double.NaN; case 8: return Double.POSITIVE_INFINITY;
            case 9: return Double.NEGATIVE_INFINITY; case 10: return n / 10.0;
            default: return n;
        }
    }
    private static String string(Genes g) {
        int mode = g.pick(16), n = g.next();
        String digits = Long.toString(Math.abs((long)n));
        String sign = new String[]{"", "-", "+", "--"}[g.pick(4)];
        switch (mode) {
            case 0: return null; case 1: return ""; case 2: return " ";
            case 3: return Integer.toString(n);
            case 4: return sign + digits;
            case 5: return sign + digits + "." + g.pick(1000);
            case 6: return sign + digits + "e" + g.next();
            case 7: return sign + "0x" + Long.toHexString(Math.abs((long)n));
            case 8: return sign + "0x8" + "0".repeat(g.pick(20));
            case 9: return sign + digits + "fFdDlL".charAt(g.pick(6));
            case 10: return " " + sign + digits + " ";
            case 11: return new String[]{"true", "false", "null", "NaN", "Infinity"}[g.pick(5)];
            case 12: return "a".repeat(g.pick(25));
            default:
                String alphabet = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ+-._ /\\\t\n";
                StringBuilder s = new StringBuilder();
                int length = g.pick(25);
                for (int i = 0; i < length; i++) s.append(alphabet.charAt(g.pick(alphabet.length())));
                return s.toString();
        }
    }
    private static Object value(Class<?> t, Genes g, int depth, Observation report) throws Exception {
        if (t == String.class || t == CharSequence.class) return string(g);
        if (t == Comparable.class) return "key" + g.pick(5);
        if (t == boolean.class || t == Boolean.class) return g.pick(2) == 0;
        if (t == char.class || t == Character.class) return (char)g.pick(128);
        if (t == byte.class || t == Byte.class) return number(g).byteValue();
        if (t == short.class || t == Short.class) return number(g).shortValue();
        if (t == int.class || t == Integer.class) return number(g).intValue();
        if (t == long.class || t == Long.class) return number(g).longValue();
        if (t == float.class || t == Float.class) return number(g).floatValue();
        if (t == double.class || t == Double.class || t == Number.class) return number(g).doubleValue();
        if (t.isEnum()) {
            Object[] constants = t.getEnumConstants();
            return constants.length == 0 ? null : constants[g.pick(constants.length)];
        }
        if (t == Object.class) return g.pick(3) == 0 ? null : "object" + g.pick(5);
        if (depth >= 3) { report.nullFallbacks++; return null; }
        if (t.isArray()) {
            int length = g.pick(6);
            Object array = Array.newInstance(t.getComponentType(), length);
            for (int i = 0; i < length; i++) Array.set(array, i, value(t.getComponentType(), g, depth + 1, report));
            return array;
        }
        if (t == List.class || t == Collection.class || t == Iterable.class || t == Set.class) {
            Collection<Object> items = t == Set.class ? new LinkedHashSet() : new ArrayList();
            int size = g.pick(5);
            for (int i = 0; i < size; i++) items.add("item" + g.pick(5));
            return items;
        }
        if (t == Map.class) {
            Map<Object, Object> items = new LinkedHashMap();
            int size = g.pick(5);
            for (int i = 0; i < size; i++) items.put("key" + g.pick(5), number(g));
            return items;
        }
        if (t == java.util.Date.class) return new java.util.Date(g.next() * 86400000L);
        if (t == Class.class) return String.class;
        if (t == java.lang.reflect.Field.class) {
            Field[] fields = GenericInput.class.getFields();
            g.lastField = fields[g.pick(fields.length)];
            return g.lastField;
        }
        if (t == java.lang.reflect.Type.class) {
            if (g.lastField != null && g.pick(3) == 0)
                return g.lastField.getDeclaringClass();
            Field[] fields = GenericInput.class.getFields();
            return fields[g.pick(fields.length)].getGenericType();
        }
        if (t == java.io.Reader.class || t == java.io.BufferedReader.class
                || t == java.io.StringReader.class) {
            String content = "header,value\n" + string(g) + "," + number(g) + "\n"
                + "alpha,beta\n";
            StringReader reader = new StringReader(content);
            return t == java.io.BufferedReader.class ? new BufferedReader(reader) : reader;
        }
        if (t.getName().equals("org.apache.commons.csv.CSVFormat")) {
            Class<?> format = load("org.apache.commons.csv.CSVFormat");
            for (String fieldName : new String[]{"DEFAULT", "RFC4180", "EXCEL"}) try {
                Object result = format.getField(fieldName).get(null);
                if (t.isInstance(result)) return result;
            } catch (ReflectiveOperationException ignored) { }
            for (Method factory : format.getMethods())
                if (Modifier.isStatic(factory.getModifiers()) && factory.getParameterTypes().length == 0
                        && t.isAssignableFrom(factory.getReturnType())) try {
                    return factory.invoke(null);
                } catch (ReflectiveOperationException ignored) { }
        }
        if (t.getName().equals("com.google.javascript.jscomp.SourceFile")) {
            Class<?> source = load("com.google.javascript.jscomp.SourceFile");
            for (Method factory : source.getMethods())
                if (Modifier.isStatic(factory.getModifiers()) && factory.getName().equals("fromCode")
                        && factory.getParameterTypes().length == 2 && factory.getParameterTypes()[0] == String.class
                        && factory.getParameterTypes()[1] == String.class) {
                    String replaySource = System.getProperty("de.generated.source");
                    if (replaySource != null) {
                        try {
                            report.generatedSource = replaySource;
                            return factory.invoke(null, "de-input.js", replaySource);
                        } catch (ReflectiveOperationException ignored) { }
                    }
                    String[] unusedParameterScripts = {
                        "window.f = function(a) {};",
                        "window.f = function(a, b) { return b; };",
                        "window.f = function(a, b) { var used = b; return used; };",
                        "window['f'] = function(unused) {};",
                        "window.f = function(unused, value) { return value; };",
                        "window['f'] = function(unused, value) { return value; };",
                        "window.f = function(first, unused, last) { return last; };",
                        "window.f = function(unused) { var local = 1; return local; };",
                        "window.f = function(unused, value) { var alias = value; return alias; };",
                        "window.f = function(unused, value) { if (value) { return 1; } return 2; };",
                        "window.f = function(unused, value) { value = value + 1; return value; };",
                        "window.f = function(unused, value) { return function() { return value; }; };",
                        "window.f = function(unused) { function inner() { return 1; } return inner(); };",
                        "window.f = function(a, b, unused) { return a + b; };",
                        "window.f = function(a, unused, b, c) { return a + c; };"
                    };
                    String[] catchDependencyScripts = {
                        "window.f = function() { var saved; try { throw Error('x'); } catch (caught) { saved = caught; } return saved.stack; };",
                        "window.f = function(flag) { var saved; try { if (flag) throw Error('x'); } catch (caught) { saved = caught; } return saved.message; };",
                        "window.f = function() { var saved; try { throw Error('x'); } catch (caught) { saved = caught; } return saved.name; };",
                        "window.f = function() { var saved; try { throw Error('x'); } catch (caught) { saved = caught; } return String(saved); };",
                        "window.f = function(flag) { var saved; try { if (flag) throw Error('x'); } catch (problem) { saved = problem; } return saved.stack; };",
                        "window.f = function() { var saved; try { throw Error('x'); } catch (problem) { saved = problem; } return saved.message; };"
                    };
                    String[] genericScripts = {
                        "function f(unused, used) { var local = 1; return used; } f(1, 2);",
                        "function f() { var unused = 1; var used = 2; return used; } f();",
                        "function f(x) { var first = x; first = 3; return x; } f(2);",
                        "function f() { var unused = 1; } f();",
                        "function keep() { var dead = 1; return 7; } keep();"
                    };
                    String modified = System.getProperty("de.modified.classes", "");
                    String[] scripts;
                    if (modified.contains("RemoveUnusedVars") && modified.contains("FlowSensitiveInlineVariables")) {
                        scripts = new String[unusedParameterScripts.length + catchDependencyScripts.length];
                        System.arraycopy(unusedParameterScripts, 0, scripts, 0, unusedParameterScripts.length);
                        System.arraycopy(catchDependencyScripts, 0, scripts, unusedParameterScripts.length,
                            catchDependencyScripts.length);
                    }
                    else if (modified.contains("FlowSensitiveInlineVariables")) scripts = catchDependencyScripts;
                    else if (modified.contains("RemoveUnusedVars")) scripts = unusedParameterScripts;
                    else scripts = genericScripts;
                    try {
                        String code = scripts[g.pick(scripts.length)];
                        report.generatedSource = code;
                        return factory.invoke(null, "de-input.js", code);
                    }
                    catch (ReflectiveOperationException ignored) { }
                }
        }
        if (t.getName().equals("com.google.javascript.jscomp.CompilerOptions")) {
            try {
                Object options = t.getConstructor().newInstance();
                // In Closure Compiler, unused-variable passes are enabled by
                // CompilationLevel, rather than by a CompilerOptions enum
                // setter. Apply the real public configuration when available.
                try {
                    Class<?> levelType = load("com.google.javascript.jscomp.CompilationLevel");
                    Object advanced = levelType.getField("ADVANCED_OPTIMIZATIONS").get(null);
                    for (Method configure : levelType.getMethods())
                        if (configure.getName().equals("setOptionsForCompilationLevel")
                                && configure.getParameterTypes().length == 1
                                && configure.getParameterTypes()[0].isInstance(options)) {
                            configure.invoke(advanced, options); break;
                        }
                } catch (ReflectiveOperationException ignored) { }
                // Also set the relevant options directly for Closure releases
                // whose compilation-level helper no longer enables this pass.
                for (Class<?> current = t; current != null; current = current.getSuperclass())
                    for (Field field : current.getDeclaredFields()) {
                        String name = field.getName().toLowerCase(Locale.ROOT);
                        if (field.getType() == boolean.class && name.equals("removeglobals")) try {
                            // Closure-1 specifically guards argument removal
                            // when globals are preserved. Keep the optimization
                            // pass enabled while exercising that configuration.
                            field.setAccessible(true); field.setBoolean(options, false);
                        } catch (Exception ignored) { }
                        if (field.getType() == boolean.class
                                && (name.contains("removeunusedvar") || name.contains("removeunusedlocal"))) try {
                            field.setAccessible(true); field.setBoolean(options, true);
                        } catch (Exception ignored) { }
                    }
                for (Method setter : t.getMethods()) {
                    if (!Modifier.isPublic(setter.getModifiers()) || !setter.getName().startsWith("set")
                            || setter.getParameterTypes().length != 1) continue;
                    String name = setter.getName().toLowerCase(Locale.ROOT);
                    if (setter.getParameterTypes()[0] == boolean.class && name.contains("removeglobals")) {
                        try { setter.invoke(options, false); } catch (ReflectiveOperationException ignored) { }
                    } else if (setter.getParameterTypes()[0] == boolean.class
                            && (name.contains("removeunusedvar") || name.contains("removeunusedlocal"))) {
                        try { setter.invoke(options, true); } catch (ReflectiveOperationException ignored) { }
                    } else if (name.contains("optimizationlevel")
                            && setter.getParameterTypes()[0].isEnum()) {
                        Object[] values = setter.getParameterTypes()[0].getEnumConstants();
                        for (Object value : values) if (String.valueOf(value).contains("ADVANCED"))
                            try { setter.invoke(options, value); } catch (ReflectiveOperationException ignored) { }
                    }
                }
                return options;
            } catch (ReflectiveOperationException ignored) { }
        }
        if (t.getName().equals("com.google.javascript.rhino.Node")) {
            try {
                Class<?> ir = load("com.google.javascript.rhino.IR");
                for (String factoryName : new String[]{"script", "root", "name", "string"})
                    for (Method factory : ir.getMethods())
                        if (Modifier.isStatic(factory.getModifiers()) && factory.getName().equals(factoryName)
                                && factory.getParameterTypes().length == 0 && t.isAssignableFrom(factory.getReturnType()))
                            return factory.invoke(null);
            } catch (ReflectiveOperationException ignored) { }
        }
        if (t.getName().equals("com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser")) {
            Object parser = xmlParser(g, report);
            if (parser != null && t.isInstance(parser)) return parser;
        }
        if (t.getName().equals("com.fasterxml.jackson.databind.ser.BeanPropertyWriter")
                || t.getName().equals("com.fasterxml.jackson.databind.ser.impl.UnwrappingBeanPropertyWriter")) {
            Object writer = jacksonWriter(t, g, report);
            if (writer != null && t.isInstance(writer)) return writer;
        }
        if (t == java.awt.Graphics2D.class || t == java.awt.Graphics.class)
            return new java.awt.image.BufferedImage(80, 80, java.awt.image.BufferedImage.TYPE_INT_ARGB).createGraphics();
        if (java.awt.Paint.class.isAssignableFrom(t)) {
            java.awt.Color c = new java.awt.Color(g.pick(256), g.pick(256), g.pick(256));
            if (t.isInstance(c)) return c;
        }
        if (java.awt.Stroke.class.isAssignableFrom(t)) {
            java.awt.BasicStroke s = new java.awt.BasicStroke(g.pick(10) / 2.0f);
            if (t.isInstance(s)) return s;
        }
        if (java.awt.Shape.class.isAssignableFrom(t)) {
            java.awt.Shape s = new java.awt.geom.Rectangle2D.Double(g.next(), g.next(), g.pick(80), g.pick(80));
            if (t.isInstance(s)) return s;
        }
        if (t == java.awt.geom.Point2D.class) return new java.awt.geom.Point2D.Double(g.next(), g.next());
        if (t.getName().equals("org.apache.commons.cli.CommandLine"))
            return commandLine(g, report);
        Object domain = chart(t, g, report);
        if (domain != null) return domain;
        Object language = language(t, g, report);
        if (language != null) return language;
        List<Constructor<?>> ctors = constructors(t);
        // Older Java libraries often use public singleton constants in place of enums.
        if (ctors.isEmpty()) {
            List<Field> constants = new ArrayList();
            for (Field field : t.getFields())
                if (Modifier.isStatic(field.getModifiers()) && Modifier.isFinal(field.getModifiers())
                        && t.isAssignableFrom(field.getType())) constants.add(field);
            Collections.sort(constants, new Comparator<Field>() {
                public int compare(Field a, Field b) { return a.getName().compareTo(b.getName()); }
            });
            if (!constants.isEmpty()) {
                Object constant = constants.get(g.pick(constants.size())).get(null);
                if (constant != null) return constant;
            }
        }
        if (!ctors.isEmpty()) {
            Constructor<?> ctor = ctors.get(g.pick(ctors.size()));
            try { return ctor.newInstance(arguments(ctor.getParameterTypes(), g, depth + 1, report)); }
            catch (Exception ignored) { }
        }
        report.nullFallbacks++;
        return null;
    }
    private static Object language(Class<?> t, Genes g, Observation report) {
        if (!t.getName().equals("org.apache.commons.lang3.time.FastDateFormat")) return null;
        try {
            Method factory = t.getMethod("getInstance", String.class, java.util.TimeZone.class,
                java.util.Locale.class);
            String[] patterns = {"yyyy-MM-dd", "MM/dd/yy HH:mm:ss", "EEE, d MMM yyyy HH:mm:ss Z"};
            return factory.invoke(null, patterns[g.pick(patterns.length)],
                java.util.TimeZone.getTimeZone("UTC"), java.util.Locale.US);
        } catch (ReflectiveOperationException ignored) { }
        try { return t.getMethod("getInstance", String.class).invoke(null, "yyyy-MM-dd"); }
        catch (ReflectiveOperationException ignored) { return null; }
    }
    private static Object xmlParser(Genes g, Observation report) {
        try {
            Class<?> factoryType = load("com.fasterxml.jackson.dataformat.xml.XmlFactory");
            Object factory = factoryType.getConstructor().newInstance();
            String[] docs = {"<root><value>1</value><name>x</name></root>",
                "<root value=\"42\"><item>a</item><item>b</item></root>",
                "<root/>"};
            String xml = docs[g.pick(docs.length)];
            for (Method method : factoryType.getMethods()) {
                if (!method.getName().equals("createParser") || method.getParameterTypes().length != 1) continue;
                Class<?> p = method.getParameterTypes()[0];
                Object input = p == String.class ? xml : p == Reader.class ? new StringReader(xml)
                    : p == InputStream.class ? new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8)) : null;
                if (input == null) continue;
                try {
                    Object parser = method.invoke(factory, input);
                    if (parser != null) {
                        int advance = g.pick(4);
                        Method next = parser.getClass().getMethod("nextToken");
                        for (int i = 0; i < advance; i++) if (next.invoke(parser) == null) break;
                        return parser;
                    }
                } catch (ReflectiveOperationException ignored) { }
            }
        } catch (Throwable ignored) { }
        return null;
    }
    private static Object jacksonWriter(Class<?> requested, Genes g, Observation report) {
        try {
            Class<?> mapperType = load("com.fasterxml.jackson.databind.ObjectMapper");
            Object mapper = mapperType.getConstructor().newInstance();
            Object bean = new GenericInput();
            Class<?> javaTypeType = load("com.fasterxml.jackson.databind.JavaType");
            Object javaType = mapperType.getMethod("constructType", Type.class).invoke(mapper, bean.getClass());
            // Jackson 2.6 (used by this Defects4J project) exposes a provider
            // blueprint from ObjectMapper. Create a configured provider via
            // DefaultSerializerProvider, the supported API used by ObjectMapper.
            Object providerBlueprint = mapperType.getMethod("getSerializerProvider").invoke(mapper);
            Class<?> serializationConfigType = load("com.fasterxml.jackson.databind.SerializationConfig");
            Class<?> serializerFactoryType = load("com.fasterxml.jackson.databind.ser.SerializerFactory");
            Object config = mapperType.getMethod("getSerializationConfig").invoke(mapper);
            Object factory = mapperType.getMethod("getSerializerFactory").invoke(mapper);
            Class<?> defaultProviderType = load("com.fasterxml.jackson.databind.ser.DefaultSerializerProvider");
            Method createProvider = defaultProviderType.getMethod("createInstance",
                serializationConfigType, serializerFactoryType);
            Object provider = createProvider.invoke(providerBlueprint, config, factory);
            g.jacksonBean = bean;
            g.jacksonProvider = provider;
            g.jacksonOutput = new StringWriter();
            Object jsonFactory = mapperType.getMethod("getFactory").invoke(mapper);
            for (String factoryMethod : new String[]{"createGenerator", "createJsonGenerator"}) {
                try {
                    Method createGenerator = jsonFactory.getClass().getMethod(factoryMethod, Writer.class);
                    g.jacksonGenerator = createGenerator.invoke(jsonFactory, g.jacksonOutput);
                    break;
                } catch (NoSuchMethodException ignored) { }
            }
            if (g.jacksonGenerator == null)
                throw new NoSuchMethodException("JsonFactory.createGenerator(Writer) or createJsonGenerator(Writer)");
            Class<?> providerType = load("com.fasterxml.jackson.databind.SerializerProvider");
            Class<?> beanPropertyType = load("com.fasterxml.jackson.databind.BeanProperty");
            Method find = providerType.getMethod("findValueSerializer", javaTypeType, beanPropertyType);
            Object serializer = find.invoke(provider, new Object[]{javaType, null});
            List<Object> writers = new ArrayList();
            try {
                // Available on Jackson 2.6 and newer.
                Class<?> serializerType = load("com.fasterxml.jackson.databind.JsonSerializer");
                Method properties = serializerType.getMethod("properties");
                Iterator<?> it = (Iterator<?>)properties.invoke(serializer);
                while (it.hasNext()) {
                    Object item = it.next();
                    if (item != null && item.getClass().getName().endsWith("BeanPropertyWriter"))
                        writers.add(item);
                }
            } catch (NoSuchMethodException oldJackson) {
                // JacksonDatabind-1 predates JsonSerializer.properties(). Its
                // BeanSerializerBase stores writers in the protected _props
                // array; read that array only for these old releases.
                Class<?> base = load("com.fasterxml.jackson.databind.ser.std.BeanSerializerBase");
                if (!base.isInstance(serializer))
                    throw new IllegalStateException("Expected BeanSerializerBase, got "
                        + serializer.getClass().getName(), oldJackson);
                Field props = base.getDeclaredField("_props");
                props.setAccessible(true);
                Object array = props.get(serializer);
                for (int i = 0; i < Array.getLength(array); i++) {
                    Object item = Array.get(array, i);
                    if (item != null && item.getClass().getName().endsWith("BeanPropertyWriter"))
                        writers.add(item);
                }
            }
            if (writers.isEmpty())
                throw new IllegalStateException("ObjectMapper produced no bean property writers for DEReplay.GenericInput");
            Object writer = writers.get(g.pick(writers.size()));
            boolean requireUnwrapping = requested.getName().equals(
                "com.fasterxml.jackson.databind.ser.impl.UnwrappingBeanPropertyWriter");
            if (!requireUnwrapping && g.pick(2) == 0 && requested.isInstance(writer)) return writer;
            Class<?> transformerType = load("com.fasterxml.jackson.databind.util.NameTransformer");
            Object nop = transformerType.getField("NOP").get(null);
            for (Method m : writer.getClass().getMethods())
                if (m.getName().equals("unwrappingWriter") && m.getParameterTypes().length == 1
                        && m.getParameterTypes()[0].isInstance(nop)) {
                    Object unwrapped = m.invoke(writer, nop);
                    if (requested.isInstance(unwrapped)) return unwrapped;
                }
            if (requested.isInstance(writer)) return writer;
            throw new IllegalStateException("Generated Jackson property writer is not " + requested.getName());
        } catch (Throwable failure) {
            throw new IllegalStateException("Cannot construct Jackson BeanPropertyWriter: " + failure, failure);
        }
    }
    /** Build the non-constructible Commons CLI result through its public Parser API. */
    private static Object commandLine(Genes g, Observation report) throws Exception {
        Class<?> optionsClass = load("org.apache.commons.cli.Options");
        Class<?> optionClass = load("org.apache.commons.cli.Option");
        Class<?> parserClass = load("org.apache.commons.cli.PosixParser");
        Object options = optionsClass.getConstructor().newInstance();
        Method addOption = optionsClass.getMethod("addOption", optionClass);
        int numberOfOptions = 1 + g.pick(3);
        List<String> spellings = new ArrayList();
        for (int i = 0; i < numberOfOptions; i++) {
            String shortName = String.valueOf((char)('a' + i));
            String longName = "de-option-" + i;
            boolean hasArgument = g.pick(2) == 0;
            Object option = null;
            try {
                option = optionClass.getConstructor(String.class, String.class, boolean.class, String.class)
                    .newInstance(shortName, longName, hasArgument, "DE-generated option");
            } catch (NoSuchMethodException ignored) { }
            if (option == null) try {
                option = optionClass.getConstructor(String.class, boolean.class, String.class)
                    .newInstance(shortName, hasArgument, "DE-generated option");
            } catch (NoSuchMethodException ignored) { }
            if (option == null) throw new NoSuchMethodException("No supported Commons CLI Option constructor");
            addOption.invoke(options, option);
            spellings.add("-" + shortName);
            if (hasArgument) spellings.add("value-" + Math.abs((long)g.next()));
        }
        String[] argv = spellings.toArray(new String[0]);
        Object parser = parserClass.getConstructor().newInstance();
        List<Method> parseMethods = new ArrayList();
        for (Method candidate : parserClass.getMethods()) {
            Class<?>[] p = candidate.getParameterTypes();
            if (candidate.getName().equals("parse") && p.length >= 2 && p[0] == optionsClass
                    && p[1] == String[].class && candidate.getReturnType() == load("org.apache.commons.cli.CommandLine"))
                parseMethods.add(candidate);
        }
        Collections.sort(parseMethods, new Comparator<Method>() {
            public int compare(Method a, Method b) {
                return a.getParameterTypes().length - b.getParameterTypes().length;
            }
        });
        for (Method parse : parseMethods) {
            Object[] args = new Object[parse.getParameterTypes().length];
            Class<?>[] p = parse.getParameterTypes();
            args[0] = options; args[1] = argv;
            for (int i = 2; i < p.length; i++) {
                if (p[i] == boolean.class || p[i] == Boolean.class) args[i] = g.pick(2) == 0;
                else if (p[i] == java.util.Properties.class) args[i] = new java.util.Properties();
                else args[i] = value(p[i], g, 1, report);
            }
            try { return parse.invoke(parser, args); }
            catch (InvocationTargetException ignored) { }
        }
        throw new NoSuchMethodException("No successful public PosixParser.parse(Options,String[])");
    }
    /** Optional type recipes, shared across bugs; none contains a bug-specific expected answer. */
    private static Object chart(Class<?> t, Genes g, Observation report) throws Exception {
        String n = t.getName();
        if (!n.startsWith("org.jfree.")) return null;
        if (n.equals("org.jfree.data.Range")) {
            double a = g.next(), b = g.next();
            return t.getConstructor(double.class, double.class).newInstance(Math.min(a, b), Math.max(a, b));
        }
        if (n.equals("org.jfree.data.time.RegularTimePeriod"))
            return load("org.jfree.data.time.Day").getConstructor(int.class, int.class, int.class)
                .newInstance(1 + g.pick(28), 1 + g.pick(12), 1990 + g.pick(40));
        if (n.equals("org.jfree.data.time.TimeSeries")) {
            Object series = t.getConstructor(Comparable.class).newInstance("DE");
            Class<?> period = load("org.jfree.data.time.RegularTimePeriod");
            Constructor<?> day = load("org.jfree.data.time.Day")
                .getConstructor(int.class, int.class, int.class);
            Method add = t.getMethod("add", period, double.class);
            int count = 2 + g.pick(4), year = 1990 + g.pick(40);
            for (int i = 0; i < count; i++)
                add.invoke(series, day.newInstance(i + 1, 1, year), g.next() / 10.0);
            return series;
        }
        if (n.equals("org.jfree.data.category.CategoryDataset")
                || n.equals("org.jfree.data.category.DefaultCategoryDataset")) {
            Class<?> c = load("org.jfree.data.category.DefaultCategoryDataset");
            Object data = c.getConstructor().newInstance();
            Method add = c.getMethod("addValue", Number.class, Comparable.class, Comparable.class);
            int rows = 1 + g.pick(3), columns = 1 + g.pick(3);
            for (int r = 0; r < rows; r++) for (int col = 0; col < columns; col++)
                add.invoke(data, Double.valueOf(g.next() / 10.0), "R" + r, "C" + col);
            return data;
        }
        if (n.equals("org.jfree.data.xy.XYDataset") || n.equals("org.jfree.data.xy.XYSeriesCollection")) {
            Class<?> seriesClass = load("org.jfree.data.xy.XYSeries");
            Object series = seriesClass.getConstructor(Comparable.class).newInstance("DE");
            int count = 1 + g.pick(5);
            for (int i = 0; i < count; i++) seriesClass.getMethod("add", double.class, double.class)
                .invoke(series, (double)i, g.next() / 10.0);
            Class<?> c = load("org.jfree.data.xy.XYSeriesCollection");
            Object data = c.getConstructor().newInstance();
            c.getMethod("addSeries", seriesClass).invoke(data, series);
            return data;
        }
        if (n.equals("org.jfree.data.general.PieDataset") || n.equals("org.jfree.data.general.DefaultPieDataset")) {
            Class<?> c = load("org.jfree.data.general.DefaultPieDataset");
            Object data = c.getConstructor().newInstance();
            int count = 1 + g.pick(5);
            for (int i = 0; i < count; i++) c.getMethod("setValue", Comparable.class, Number.class)
                .invoke(data, "K" + i, Double.valueOf(g.next() / 10.0));
            return data;
        }
        return null;
    }
    static List<Method> setupMethods(Class<?> receiver) {
        List<Method> methods = new ArrayList();
        for (Method m : receiver.getMethods()) {
            String n = m.getName();
            if (!Modifier.isStatic(m.getModifiers()) && !m.isSynthetic()
                    && m.getParameterTypes().length <= 3 && !n.contains("Listener")
                    && (n.startsWith("set") || n.startsWith("add") || n.startsWith("update")
                        || n.startsWith("remove") || n.equals("clear"))) methods.add(m);
        }
        Collections.sort(methods, new Comparator<Method>() {
            public int compare(Method a, Method b) {
                return signature(a).compareTo(signature(b));
            }
        });
        return methods;
    }
    public static Observation execute(String target, String receivers, String signature, int[] genes) {
        Observation out = new Observation();
        try {
            Genes g = new Genes(genes);
            Method m = method(target, signature);
            Object receiver = null;
            if (!Modifier.isStatic(m.getModifiers())) {
                String[] choices = receivers.split(",");
                Class<?> receiverType = load(choices[g.pick(choices.length)]);
                receiver = value(receiverType, g, 0, out);
                if (receiver == null) throw new IllegalArgumentException("Receiver construction failed");
                // Compiler.compile owns a strict initialization sequence.
                // Random calls to its mutators before compilation can corrupt
                // state or spend the search budget on irrelevant setup.
                if (!receiverType.getName().equals("com.google.javascript.jscomp.Compiler")) {
                    List<Method> setup = setupMethods(receiverType);
                    int count = g.pick(5);
                    for (int i = 0; i < count && !setup.isEmpty(); i++) {
                        Method s = setup.get(g.pick(setup.size()));
                        try { s.invoke(receiver, arguments(s.getParameterTypes(), g, 0, out)); out.setupCalls++; }
                        catch (Exception e) { out.setupFailures++; }
                    }
                }
            }
            Object[] args = arguments(m, g, 0, out);
            out.reachedTarget = true;
            try {
                boolean jacksonSerialization = m.getDeclaringClass().getName().equals(
                    "com.fasterxml.jackson.databind.ser.BeanPropertyWriter")
                    && m.getName().startsWith("serializeAs") && g.jacksonGenerator != null;
                boolean arrayShape = m.getName().contains("Column")
                    || m.getName().contains("Element") || m.getName().contains("Placeholder");
                if (jacksonSerialization)
                    g.jacksonGenerator.getClass().getMethod(arrayShape
                        ? "writeStartArray" : "writeStartObject").invoke(g.jacksonGenerator);
                Object result = m.invoke(receiver, args);
                boolean closureCompile = m.getDeclaringClass().getName().equals(
                    "com.google.javascript.jscomp.Compiler") && m.getName().equals("compile");
                if (closureCompile) {
                    // Result is only a status object; the compiled JavaScript is
                    // the behavioral output that reveals whether an argument
                    // was removed from a globally exposed function.
                    Object js = receiver.getClass().getMethod("toSource").invoke(receiver);
                    out.token = "CLOSURE_SOURCE:" + stable(js, 0);
                } else if (jacksonSerialization) {
                    g.jacksonGenerator.getClass().getMethod(arrayShape
                        ? "writeEndArray" : "writeEndObject").invoke(g.jacksonGenerator);
                    g.jacksonGenerator.getClass().getMethod("flush").invoke(g.jacksonGenerator);
                    out.token = "JSON:" + Base64.getEncoder().encodeToString(
                        g.jacksonOutput.toString().getBytes(StandardCharsets.UTF_8));
                } else out.token = m.getReturnType() == void.class
                    ? state(receiver, m.getName()) : stable(result, 0);
            } catch (InvocationTargetException e) {
                if (e.getCause() instanceof VirtualMachineError || e.getCause() instanceof LinkageError
                        || e.getCause() instanceof ThreadDeath) throw e;
                out.token = "THROW:" + e.getCause().getClass().getName();
            }
        } catch (Throwable e) {
            out.token = "HARNESS_ERROR";
            out.error = e.getClass().getName() + ":" + String.valueOf(e.getMessage());
        }
        return out;
    }
    public static String run(String target, String receivers, String signature, int[] genes) {
        Observation o = execute(target, receivers, signature, genes);
        if (!o.reachedTarget || o.token.equals("HARNESS_ERROR"))
            throw new AssertionError("Cannot replay test: " + o.error);
        return o.token;
    }
    private static String state(Object receiver, String method) {
        if (receiver == null) return "VOID";
        List<String> getters = new ArrayList();
        if (method.startsWith("set") && method.length() > 3) {
            getters.add("get" + method.substring(3)); getters.add("is" + method.substring(3));
        }
        getters.addAll(Arrays.asList("getItemCount", "getRowCount", "getColumnCount", "getSeriesCount"));
        StringBuilder s = new StringBuilder("VOID");
        for (String name : getters) {
            try {
                Method getter = receiver.getClass().getMethod(name);
                if (getter.getReturnType().isPrimitive() || getter.getReturnType() == String.class)
                    s.append('|').append(name).append('=').append(stable(getter.invoke(receiver), 0));
            } catch (ReflectiveOperationException ignored) { }
        }
        return s.toString();
    }
    /** Only whitelisted value types are rendered. Never use arbitrary object toString(). */
    static String stable(Object value, int depth) {
        if (value == null) return "NULL";
        Class<?> t = value.getClass();
        if (value instanceof String || value instanceof Boolean || value instanceof Character
                || value instanceof Byte || value instanceof Short || value instanceof Integer
                || value instanceof Long || value instanceof Float || value instanceof Double
                || value instanceof java.math.BigInteger || value instanceof java.math.BigDecimal)
            return t.getName() + ":" + Base64.getEncoder().encodeToString(value.toString().getBytes(StandardCharsets.UTF_8));
        if (value instanceof Enum) return "ENUM:" + t.getName() + ":" + ((Enum<?>)value).name();
        if (t.isArray() && depth < 3) {
            StringBuilder s = new StringBuilder("ARRAY:" + t.getName() + ":" + Array.getLength(value));
            for (int i = 0; i < Math.min(64, Array.getLength(value)); i++) {
                String item = stable(Array.get(value, i), depth + 1);
                s.append(':').append(item.length()).append(':').append(item);
            }
            return s.toString();
        }
        if (value instanceof java.awt.Color) return "COLOR:" + ((java.awt.Color)value).getRGB();
        // Observe safe scalar properties of returned objects. This catches
        // changes to value caches and state while avoiding identity-based toString().
        StringBuilder observed = new StringBuilder("STATE:" + t.getName());
        int properties = 0;
        for (String name : Arrays.asList("getItemCount", "getMinY", "getMaxY",
                "getRowCount", "getColumnCount", "getSeriesCount")) {
            try {
                Method getter = t.getMethod(name);
                Class<?> r = getter.getReturnType();
                if (!r.isPrimitive() && r != String.class && !Number.class.isAssignableFrom(r))
                    continue;
                if (r == void.class) continue;
                Object result = getter.invoke(value);
                String token = stable(result, depth + 1);
                observed.append('|').append(name).append('=').append(token.length())
                    .append(':').append(token);
                properties++;
            } catch (Exception ignored) { }
        }
        return properties == 0 ? "TYPE:" + t.getName() : observed.toString();
    }
    public static void main(String[] args) {
        if (args.length > 4) {
            String source = new String(Base64.getDecoder().decode(args[4]), StandardCharsets.UTF_8);
            System.setProperty("de.generated.source", source);
        }
        String[] encodedGenes = args[3].split(",");
        int[] genes = new int[encodedGenes.length];
        for (int i = 0; i < encodedGenes.length; i++) genes[i] = Integer.parseInt(encodedGenes[i]);
        boolean closureCompile = args[0].equals("com.google.javascript.jscomp.Compiler")
            && args[2].startsWith("compile(");
        // Compiler.compile is an expensive whole-program operation. Fixed-side
        // suites are still executed twice by the runner, so capture its oracle
        // once here instead of launching three compilations just to check the
        // same deterministic source output.
        int repetitions = closureCompile ? 1 : 3;
        for (int i = 0; i < repetitions; i++) {
            Observation out = execute(args[0], args[1], args[2], genes);
            System.out.println("DE_TOKEN:" + Base64.getEncoder().encodeToString(out.token.getBytes(StandardCharsets.UTF_8)));
        }
    }
}

public class DEGeneratedTest {
    @org.junit.Test(timeout=60000L)
    public void testDE00000() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "equals(java.lang.Object):boolean",
            new int[]{1000,575,1000,-1000,18,870,1000,-40,-493,-756,-1000,1000,-1000,-53,-620,543,1000,40,181,-1000,621,5,-1000,-1000,-1000,-380,182,-402,-1000,-655,-1000,1000,-791,-1000,1000,-1000,1000,635,1000,-1000,1000,865,-1000,1000,479,1000,-722,1000,-1000,-1000,-1000,-1000,1000,919,-1000,-1000,1000,377,1000,-1000,-696,-1000,-674,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00001() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "equals(java.lang.Object):boolean",
            new int[]{64,508,787,-372,-246,507,1000,-914,-773,846,-1000,57,460,-126,-1000,624,-899,28,-1000,-683,434,-254,-48,-121,-213,291,-1000,291,485,115,715,941,514,-230,479,-715,247,172,298,-874,-948,-950,-112,1000,-1000,1000,-1000,259,854,1000,-351,-703,-837,464,-217,-356,961,1000,882,331,206,-1000,1000,322}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00002() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "equals(java.lang.Object):boolean",
            new int[]{11,479,-255,741,-495,656,248,310,-176,476,917,6,751,-288,-164,-779,-783,686,-788,-184,-330,-946,172,674,10,819,-1000,907,-635,-24,623,-72,35,505,35,-1000,-315,1000,642,-333,-44,12,-60,-214,-229,27,-27,-185,804,-30,-595,-402,-21,556,913,1000,-629,1000,414,-48,-670,59,988,22}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00003() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "equals(java.lang.Object):boolean",
            new int[]{-1000,313,112,1000,-299,639,9,408,-545,-489,1000,-1000,853,799,464,-1000,-744,-880,-647,1000,-281,-733,1000,-835,536,750,640,976,1000,-1000,1000,-1000,1000,1000,-921,354,-657,-242,47,971,-539,1000,1000,-1000,906,-1000,578,-1000,-188,1000,1000,1000,-1000,-583,948,-976,-629,419,-901,1000,-727,1000,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00004() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "equals(java.lang.Object):boolean",
            new int[]{-379,778,486,1000,-964,-540,643,9,594,189,1000,1000,881,-598,722,-508,-13,333,27,319,-438,-1000,-1000,1000,-1000,1000,-253,274,188,568,219,1000,-964,-1000,508,-1000,-1000,390,-1000,-114,224,-1000,-1000,-645,140,1000,-351,1000,1000,806,-805,-477,580,404,145,-888,1000,262,244,-41,356,521,-314,-622}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00005() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "equals(java.lang.Object):boolean",
            new int[]{1000,854,1000,-1000,893,494,1000,-436,-176,-569,-544,1000,-1000,-674,-343,-321,1000,-347,149,-549,967,120,-1000,-1000,-354,1000,-1000,157,-1000,-111,-1000,562,-198,-846,1000,-1000,1000,1000,346,-1000,150,-1000,-956,1000,770,1000,-900,1000,-185,-675,-392,320,1000,301,-1000,-1000,1000,-232,1000,-1000,1000,-795,29,445}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00006() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "equals(java.lang.Object):boolean",
            new int[]{107,413,228,24,918,149,358,-448,329,-386,-12,-582,-81,892,604,-839,115,238,-265,-331,-1000,477,562,-406,1000,347,227,197,-551,-1000,184,-1000,155,1000,-420,334,153,300,-335,-278,-1000,156,924,-244,-434,-302,16,-1000,598,192,864,1000,-62,-559,-477,966,-493,385,-276,-584,295,1000,1000,-549}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00007() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "equals(java.lang.Object):boolean",
            new int[]{-152,486,-802,-1000,750,666,-308,-420,-1000,-1000,-528,-679,291,657,-403,984,1000,-949,-429,-207,355,-54,984,-166,-552,-447,762,716,466,199,1000,-678,1000,27,-528,867,806,744,892,1000,548,1000,1000,-498,707,-812,60,-926,-827,1000,444,693,-917,562,87,-692,1000,-898,-1000,1000,1000,400,61,929}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00008() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "equals(org.apache.commons.compress.archivers.tar.TarArchiveEntry):boolean",
            new int[]{-211,377,52,-72,139,772,-77,-271,-505,-1000,909,295,-139,-661,-99,-1000,-742,306,623,-29,523,-748,-511,-1000,751,-273,-749,345,618,-492,-85,-375,-411,-908,-377,-1000,-16,-36,-230,161,1000,894,729,775,914,-464,139,-357,21,386,1000,493,-811,-281,742,941,369,79,819,719,1000,413,455,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00009() {
        org.junit.Assert.assertEquals("THROW:java.lang.NullPointerException", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "equals(org.apache.commons.compress.archivers.tar.TarArchiveEntry):boolean",
            new int[]{40,297,-534,494,-671,-898,-302,-47,-640,-428,-291,-337,440,-950,425,-1000,1000,501,-327,-856,-832,-717,-149,-720,70,785,62,701,907,1000,-1000,-442,-1000,-637,-409,368,-139,-1000,-744,1000,-158,224,113,69,1000,299,1000,-391,195,-55,-16,1000,-856,-74,275,-1000,-1000,-1000,63,1000,440,-407,-662,-774}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00010() {
        org.junit.Assert.assertEquals("THROW:java.lang.NullPointerException", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "equals(org.apache.commons.compress.archivers.tar.TarArchiveEntry):boolean",
            new int[]{132,293,637,295,-578,-326,-275,236,-450,-607,680,-446,-438,-207,-570,-463,-415,-344,498,201,-10,635,-530,441,-495,298,-997,576,-833,-127,-768,-976,625,877,-346,-196,653,-802,602,-101,943,-59,291,-886,-734,-666,63,11,883,-638,-43,-277,-230,439,-991,-966,-392,-630,-206,965,810,171,633,-724}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00011() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "equals(org.apache.commons.compress.archivers.tar.TarArchiveEntry):boolean",
            new int[]{-44,-612,438,445,-636,738,599,977,-650,828,748,-979,-766,646,-281,694,-992,-500,417,742,452,-434,166,972,-137,588,-784,409,-113,-853,317,750,557,43,-456,673,-14,698,595,-136,-616,-782,-391,249,-922,783,-747,-157,15,-642,-717,-111,892,373,71,484,486,995,-275,-205,9,-135,303,-873}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00012() {
        org.junit.Assert.assertEquals("THROW:java.lang.NullPointerException", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "equals(org.apache.commons.compress.archivers.tar.TarArchiveEntry):boolean",
            new int[]{-409,300,-1000,-73,-1000,-368,79,505,-672,364,938,1000,1000,1000,-142,-294,1000,-111,-140,-597,1000,-660,20,202,-191,-295,984,182,-820,-69,-1000,-826,-437,111,-1000,-437,82,-1000,-216,1000,349,1000,-502,1000,1000,450,517,457,387,527,-700,745,-271,-356,524,-573,-935,-1000,221,1000,-104,-414,-445,583}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00013() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "equals(org.apache.commons.compress.archivers.tar.TarArchiveEntry):boolean",
            new int[]{-505,252,-656,-74,-678,267,456,-38,-876,130,829,-581,337,-400,-454,-148,313,-873,603,-664,463,112,87,-119,336,-558,-641,50,-710,-472,215,-721,303,-68,-290,-809,858,-735,640,-1000,-281,-763,608,606,675,-347,-787,-354,111,-293,-489,-885,-972,-78,-335,873,90,42,-49,429,509,-101,0,-999}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00014() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "equals(org.apache.commons.compress.archivers.tar.TarArchiveEntry):boolean",
            new int[]{-653,457,-1000,-53,-626,51,275,72,65,682,391,-1000,1000,-1000,-11,190,1000,-1000,567,-1000,744,-295,1000,295,-41,-1000,593,-584,-1000,373,670,-1000,1000,691,-758,-1000,1000,-1000,1000,-487,399,-1000,553,913,1000,-692,-1000,38,418,258,-1000,-1000,-1000,375,-865,-451,845,-259,80,392,1000,375,-427,136}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00015() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "equals(org.apache.commons.compress.archivers.tar.TarArchiveEntry):boolean",
            new int[]{-1000,564,-597,721,836,-1000,-383,930,624,-1000,908,-365,400,891,744,-552,-486,-596,552,-811,-1000,-1000,385,-561,-555,144,-294,238,27,31,-1000,-806,328,-1000,1000,-1000,1000,-310,-400,1000,-21,-1000,199,241,1000,-76,-728,931,-471,895,-1000,-1000,-1000,-692,-438,74,964,-1000,-1000,-649,-1000,412,1000,-782}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00016() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getDevMajor():int",
            new int[]{-847,894,-617,539,328,301,1000,294,-92,-278,-410,-661,-69,250,-1000,213,1000,427,367,-419,-293,877,-981,677,-207,-571,-621,-577,51,-629,-696,-57,145,-613,837,-941,-278,-666,55,979,-964,-297,-1000,1000,-136,55,-596,-331,783,831,621,78,973,932,1000,882,993,77,-356,370,365,-700,-985,-702}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00017() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getDevMajor():int",
            new int[]{-83,97,-53,-337,-1000,-614,-200,833,165,-23,-1000,584,186,1000,-456,-629,-938,221,657,-146,725,-358,368,852,474,872,-170,-173,1000,-603,-508,895,179,774,-905,-868,457,-592,-706,-296,-364,349,613,-529,-1000,916,-398,1000,881,353,-373,-14,1000,567,-713,818,17,347,-1000,8,-345,-50,-89,-202}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00018() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getDevMajor():int",
            new int[]{-179,-18,-348,-1000,984,301,23,264,657,-1000,689,908,-338,515,929,773,786,694,-642,-1000,-689,-1000,-1000,-1000,-689,-258,-621,-1000,51,-544,-1000,280,-837,1000,1000,-765,-1000,-1000,823,-907,-604,-622,916,986,-783,816,-49,-331,-278,879,-306,-16,720,1000,248,-776,993,96,1000,580,354,840,1000,-702}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00019() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getDevMajor():int",
            new int[]{694,-127,-804,-844,-416,-489,-551,986,167,-497,-88,441,-30,1000,805,778,-439,427,-33,-1000,-1000,-462,-116,160,470,306,254,-585,449,-869,-935,983,-498,1000,-355,-1000,-160,-666,128,1000,-1000,-726,1000,205,-1000,-81,-485,574,-720,580,-155,102,169,-74,788,272,611,-176,65,70,479,868,153,494}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00020() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getDevMajor():int",
            new int[]{-992,831,-623,141,-113,159,659,402,-551,160,-1000,1000,-735,341,-553,-637,672,-352,976,657,137,-183,-1000,175,-569,1000,214,-1000,977,-767,9,166,153,-1000,-264,-1000,482,389,-765,-208,-1000,492,-202,360,-47,-46,-1000,-306,321,502,1000,-29,547,1000,-290,1000,627,517,-1000,966,61,-574,-1000,426}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00021() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getDevMajor():int",
            new int[]{546,-438,-1000,-342,-1000,-618,-606,901,-400,398,-1000,31,-211,1000,-5,967,-1000,457,684,-1000,-811,115,258,624,1000,994,1000,-549,1000,-1000,400,741,400,1000,-904,-601,-441,-897,-466,494,-767,-93,616,-794,-392,153,-1000,906,-200,337,109,-394,-5,-221,-513,1000,167,-662,-1000,-333,-1000,-219,-11,356}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00022() {
        org.junit.Assert.assertEquals("java.lang.Integer:MjE0NzQ4MzY0Nw==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getDevMajor():int",
            new int[]{842,964,-9,-364,-647,-895,-754,-496,11,100,-319,-400,590,-306,352,32,464,508,-21,113,526,-180,208,310,98,347,-450,400,-412,1000,-359,-59,-590,-1000,-782,-218,120,141,-454,1000,-227,-331,1000,776,-1000,-1000,-1000,1000,-525,-209,-825,-318,-308,-400,723,112,-439,-549,1000,290,685,442,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00023() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getDevMinor():int",
            new int[]{-320,-222,-200,391,-234,826,-951,44,-281,1000,533,-1000,946,-1000,1000,-901,912,742,1000,-12,1000,-1000,1000,-887,1000,1000,-1000,1000,1000,650,1000,594,-1000,-1000,-687,-227,378,89,388,1000,-969,898,599,809,-1000,913,-32,1000,194,-494,65,-296,1000,-505,1000,1000,1000,-1000,-81,266,-698,-1000,-1000,196}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00024() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getDevMinor():int",
            new int[]{67,-359,-1000,1000,173,1000,-343,14,1000,1000,-1000,-1000,960,289,-160,-1000,912,96,-324,-530,1000,-581,1000,-828,993,-494,-798,600,1000,-721,-739,1000,-1000,995,-1000,-807,-771,122,659,-71,987,-915,-407,-45,-1000,913,-1000,688,206,-1000,-904,-296,982,-1000,1000,-1000,1000,-1000,-299,463,-761,-1000,-645,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00025() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getDevMinor():int",
            new int[]{-598,31,713,15,286,-208,509,-52,830,769,-484,1000,-1000,537,-408,472,-438,-1000,1000,499,-1000,1000,-155,1000,-1000,591,624,-111,-1000,-684,-432,549,162,-543,-617,684,-960,1000,-1000,455,-178,-693,-691,-345,569,343,-1000,9,-72,-9,-1000,-376,1000,871,-1000,806,-668,129,-512,473,358,206,-192,485}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00026() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getDevMinor():int",
            new int[]{-815,-788,1000,-99,309,444,-149,-575,841,47,-245,698,-1000,506,354,618,1000,-400,-100,121,1000,341,-374,-634,-400,391,105,592,-332,678,-1000,-969,953,-286,-134,-21,-1000,1000,-36,148,528,-1000,-616,102,16,-188,950,-635,-295,-554,-1000,-869,81,930,800,46,277,109,-368,-160,-901,-23,-119,-914}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00027() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getDevMinor():int",
            new int[]{-554,862,-441,-560,155,291,-24,519,190,-361,-149,-504,115,10,945,-538,737,840,-389,38,797,-872,-711,-201,870,870,619,694,619,-480,46,-546,-229,652,-136,548,721,-833,119,521,498,-639,-495,712,-37,966,450,293,601,-110,979,307,22,761,596,-1,382,-335,-581,-928,-660,-544,-846,-277}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00028() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getDevMinor():int",
            new int[]{-214,-401,-611,-381,767,1000,-658,727,434,454,129,-1000,444,-986,1000,1000,574,582,732,1000,741,-1000,127,-214,-106,1000,61,890,-674,-687,455,-420,-770,56,-119,471,534,-64,-429,1000,13,273,-497,1000,-752,1000,928,742,88,948,75,755,-600,250,1000,427,1000,-405,-984,-1000,-1000,-1000,-1000,-431}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00029() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getDevMinor():int",
            new int[]{661,-15,-33,257,268,1000,-1000,428,-363,734,330,-1000,854,-1000,1000,-908,378,714,1000,188,1000,-833,584,-881,826,1000,-920,1000,813,355,461,-969,-1000,-463,-43,-164,1000,-41,121,1000,-820,763,-476,1000,-557,1000,480,811,208,-278,360,1000,828,-155,808,735,1000,-1000,28,-873,-1000,-1000,-1000,555}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00030() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getDevMinor():int",
            new int[]{-735,202,-451,1000,-969,402,-365,-800,584,-361,-337,64,326,241,-69,-667,1000,25,-40,-1000,372,-42,1000,-674,352,-5,-840,499,1000,512,-108,947,-415,-461,-904,-825,-934,558,334,84,-201,-99,-454,-249,-692,316,-1000,185,458,-963,-578,220,1000,900,-258,-662,-1000,-975,544,897,618,-836,-362,937}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00031() {
        org.junit.Assert.assertEquals("ARRAY:[Lorg.apache.commons.compress.archivers.tar.TarArchiveEntry;:0", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getDirectoryEntries():org.apache.commons.compress.archivers.tar.TarArchiveEntry[]",
            new int[]{1000,582,-722,-1000,-470,469,76,14,289,-1000,743,-642,211,-109,-879,683,-297,508,571,-428,-13,1000,-429,290,1000,430,-24,-121,-1000,-902,983,133,457,-323,492,-656,924,724,1000,-967,-1000,-394,715,-199,895,640,-77,-562,857,-564,831,1000,724,-793,-1000,-408,-936,217,-1000,-892,520,950,-220,-376}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00032() {
        org.junit.Assert.assertEquals("ARRAY:[Lorg.apache.commons.compress.archivers.tar.TarArchiveEntry;:25:62:TYPE:org.apache.commons.compress.archivers.tar.TarArchiveEntry:62:TYPE:org.apache.commons.compress.archivers.tar.TarArchiveEntry:62:TYPE:org.apache.commons.compress.archivers.tar.TarArchiveEntry:62:TYPE:org.apache.commons.compress.archivers.tar.TarArchiveEntry:62:TYPE:org.apache.commons.compress.archivers.tar.TarArchiveEntry:62:TYPE:org.apache.commons.compress.archivers.tar.TarArchiveEntry:62:TYPE:org.apache.commons.compress.archivers.tar.TarArchiveEntry:62:TYPE:org.apache.commons.compress.archivers.tar.TarArchiveEntry:62:TYPE:org.apache.commons.compress.archivers.tar.TarArchiveEntry:62:TYPE:org.apache.commons.compress.archivers.tar.TarArchiveEntry:62:TYPE:org.apache.commons.compress.archivers.tar.TarArchiveEntry:62:TYPE:org.apache.commons.compress.archivers.tar.TarArchiveEntry:62:TYPE:org.apache.commons.compress.archivers.tar.TarArchiveEntry:62:TYPE:org.apache.commons.compress.archivers.tar.TarArchiveEntry:62:TYPE:org.apache.commons.compress.archivers.tar.TarArchiveEntry:62:TYPE:org.apache.commons.compress.archivers.tar.TarArchiveEntry:62:TYPE:org.apache.commons.compress.archivers.tar.TarArchiveEntry:62:TYPE:org.apache.commons.compress.archivers.tar.TarArchiveEntry:62:TYPE:org.apache.commons.compress.archivers.tar.TarArchiveEntry:62:TYPE:org.apache.commons.compress.archivers.tar.TarArchiveEntry:62:TYPE:org.apache.commons.compress.archivers.tar.TarArchiveEntry:62:TYPE:org.apache.commons.compress.archivers.tar.TarArchiveEntry:62:TYPE:org.apache.commons.compress.archivers.tar.TarArchiveEntry:62:TYPE:org.apache.commons.compress.archivers.tar.TarArchiveEntry:62:TYPE:org.apache.commons.compress.archivers.tar.TarArchiveEntry", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getDirectoryEntries():org.apache.commons.compress.archivers.tar.TarArchiveEntry[]",
            new int[]{335,665,-622,-520,-447,-601,-835,317,939,904,1000,-616,381,971,-625,530,-666,561,-126,379,83,696,675,290,668,430,-885,365,-251,-107,-121,-688,-124,-554,-533,-24,353,241,989,-161,-901,-1000,1000,348,1000,-363,-211,-160,939,152,980,177,183,-264,-1000,455,-732,-728,-338,-1000,-487,759,-2,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00033() {
        org.junit.Assert.assertEquals("ARRAY:[Lorg.apache.commons.compress.archivers.tar.TarArchiveEntry;:0", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getDirectoryEntries():org.apache.commons.compress.archivers.tar.TarArchiveEntry[]",
            new int[]{-317,-286,765,28,-1000,274,1000,-81,582,911,-31,1000,1000,26,1000,1000,-473,-1000,-350,-419,703,67,566,1000,1000,-1000,16,502,1000,847,-611,-103,-1000,895,391,-1000,-192,-994,-1000,-693,-171,873,673,248,-1000,496,1000,-810,926,548,602,1000,1000,1000,400,-1000,-1000,886,-632,-591,757,-1000,344,-501}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00034() {
        org.junit.Assert.assertEquals("ARRAY:[Lorg.apache.commons.compress.archivers.tar.TarArchiveEntry;:0", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getDirectoryEntries():org.apache.commons.compress.archivers.tar.TarArchiveEntry[]",
            new int[]{-61,-209,17,-200,-1000,1000,138,330,-316,-727,-75,334,374,89,1000,-46,-400,-784,-583,1000,-319,350,1000,1000,746,16,-943,-643,960,1000,-66,44,-1000,635,231,-62,-718,-981,-1000,779,-1000,1000,-563,-180,-1000,623,1000,121,1000,871,127,-730,-162,1000,562,-534,-1000,1000,994,-639,313,-396,273,-422}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00035() {
        org.junit.Assert.assertEquals("ARRAY:[Lorg.apache.commons.compress.archivers.tar.TarArchiveEntry;:0", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getDirectoryEntries():org.apache.commons.compress.archivers.tar.TarArchiveEntry[]",
            new int[]{-322,564,268,-99,-802,-184,-529,-503,705,-282,464,192,656,-64,852,59,-953,-263,242,167,505,-172,723,790,-235,-337,-708,365,973,507,-169,-44,-855,196,-579,342,154,-925,-646,5,-901,-99,990,273,-358,-363,796,681,939,15,-653,-828,183,496,-159,247,-551,-161,795,-678,-487,860,944,-343}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00036() {
        org.junit.Assert.assertEquals("ARRAY:[Lorg.apache.commons.compress.archivers.tar.TarArchiveEntry;:0", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getDirectoryEntries():org.apache.commons.compress.archivers.tar.TarArchiveEntry[]",
            new int[]{1000,191,-466,-1000,-678,-50,739,318,402,-217,46,858,-165,155,1000,550,-612,-1000,812,300,-508,1000,460,851,701,1,-94,105,17,-206,722,233,-664,-1000,1000,-1000,138,-446,-303,-572,-978,709,34,750,1000,639,-256,-851,858,189,1000,1000,22,297,-200,-1000,-1000,-196,-1000,-681,1000,446,-53,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00037() {
        org.junit.Assert.assertEquals("ARRAY:[Lorg.apache.commons.compress.archivers.tar.TarArchiveEntry;:0", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getDirectoryEntries():org.apache.commons.compress.archivers.tar.TarArchiveEntry[]",
            new int[]{547,310,-741,1000,135,-331,-97,-601,-468,-401,-86,-349,183,401,-920,-924,321,368,1000,517,459,-250,-793,-838,-537,978,197,261,-836,-734,230,874,-140,-862,-103,1000,256,494,607,544,-1000,-80,-295,-369,468,676,-238,697,-77,-617,-515,-1000,-584,-1000,-308,356,688,180,835,595,331,1000,815,354}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00038() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getFile():java.io.File",
            new int[]{814,-641,1000,-337,72,-1000,-79,294,552,-796,517,190,558,108,-178,-43,422,-179,-96,-980,-1000,-522,-360,107,260,-1000,-310,-526,-60,-755,1000,-739,-328,1000,921,-918,204,-905,-353,150,276,-835,308,308,1000,-1000,-37,-1000,-5,-586,-658,101,312,65,-175,516,-1000,-910,-587,637,266,483,-147,-400}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00039() {
        org.junit.Assert.assertEquals("TYPE:java.io.File", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getFile():java.io.File",
            new int[]{-586,257,-217,321,-1000,-674,383,196,-1000,-1000,476,390,-549,1000,-592,-842,990,570,-564,564,-9,-1000,-450,-1000,532,1000,-827,-275,473,-1000,-1000,-694,1000,1000,785,825,1000,-598,-44,-858,1000,1000,-1000,-1000,869,-785,1000,723,-736,472,1000,-48,-375,-294,1000,-734,-409,1000,-711,769,632,710,285,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00040() {
        org.junit.Assert.assertEquals("TYPE:java.io.File", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getFile():java.io.File",
            new int[]{1000,-39,-1000,886,423,940,282,304,587,-931,1000,1000,798,-199,-1000,1000,1000,-31,-1000,-854,1000,-1000,629,-1000,1000,1000,1000,-214,-294,-568,-935,-1000,-1000,849,1000,639,-1000,-1000,-73,-1000,849,-1000,-835,-199,1000,-753,1000,1000,-1000,523,1000,822,-1000,1000,250,-1000,1000,1000,-1000,-118,1000,-528,816,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00041() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getFile():java.io.File",
            new int[]{726,-274,575,453,141,-134,650,1000,1000,269,-49,401,705,638,495,-230,-722,601,383,-1000,-1000,-930,35,1000,304,-580,-1000,-1000,-1000,-649,-236,140,-1000,-63,-605,1000,1000,-831,547,25,249,-1000,-1000,716,226,-1000,549,-236,364,1000,-1000,-1000,-599,-1000,478,-1000,-841,-423,1000,-479,-1000,-1000,-142,-939}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00042() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getFile():java.io.File",
            new int[]{-507,-478,477,-152,-905,-467,-350,1000,361,-390,535,-879,-433,889,-331,-11,179,644,-665,-993,236,-850,-797,-96,-133,-278,110,-1000,-95,-519,356,-914,-388,1000,62,977,464,160,1000,-820,389,-1000,226,-725,422,-1000,-469,-713,1000,583,-683,560,-648,-776,518,-910,-759,-91,67,910,577,-511,78,-668}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00043() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getFile():java.io.File",
            new int[]{590,-353,-984,172,-255,199,-435,1000,1000,-352,656,-12,-1000,1000,-151,1000,586,911,-1000,698,852,-1000,-1000,-599,927,1000,975,-1000,-931,-779,519,-1000,-148,1000,1000,1000,137,-1000,1000,-1000,396,-510,265,-385,1000,-1000,614,420,-1000,1000,110,1000,-1000,293,98,-1000,389,550,-1000,191,-1000,-1000,696,373}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00044() {
        org.junit.Assert.assertEquals("NULL", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getFile():java.io.File",
            new int[]{296,170,27,165,-389,-490,169,791,-154,-396,656,-260,-456,97,-1000,308,-113,457,-679,125,-248,-925,-33,-361,526,-446,173,-320,-224,-685,783,-880,943,796,212,588,1000,-357,-38,-379,527,633,209,40,704,-784,194,256,-964,6,131,618,42,-541,1000,-56,251,-310,-85,687,898,-412,309,354}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00045() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getGroupId():int",
            new int[]{706,-250,-1000,-1000,581,-183,86,-735,-81,-512,-675,-290,-925,-1000,596,745,1000,-661,-885,-326,-1000,-622,-824,632,1000,-711,-1000,1000,18,60,-812,1000,453,485,1000,-903,363,490,-288,-20,362,792,-160,-1000,-18,1000,585,1000,-166,-1000,-722,1000,247,-443,495,-534,-446,-1000,-261,-1000,-866,101,-330,-844}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00046() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTIxNDc0ODM2NDg=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getGroupId():int",
            new int[]{-363,825,1000,-585,-412,-577,-31,1000,-842,304,629,-369,700,-230,1000,685,-275,958,1000,-514,288,355,-753,-380,-1000,-158,-878,-1000,788,-877,424,-1000,-1000,-695,-1000,-285,-152,-1000,-455,-186,-611,-483,675,274,-73,-1000,-267,-1000,1000,1000,-497,222,364,-25,146,402,1000,1000,-947,834,694,-25,617,92}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00047() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getGroupId():int",
            new int[]{215,306,-955,-164,787,875,769,91,-579,-651,-449,290,664,944,417,523,-1000,-666,1000,-195,442,-435,-115,-664,1000,315,-1000,323,1000,175,-580,-6,-61,-400,265,-1000,-842,173,-1000,216,-876,481,-313,-1000,-417,982,397,986,217,514,-42,1000,-233,-400,920,49,571,-978,139,-1000,-1000,92,-493,-218}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00048() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getGroupId():int",
            new int[]{-425,405,-50,-41,-812,1000,132,849,942,-592,404,231,611,-319,1000,1000,1000,1000,1000,790,-1000,-534,-783,-601,-1000,-3,-284,-204,-1000,453,-271,912,1000,-1000,-1000,83,393,616,1000,-1000,-1000,1000,-869,1000,-698,-286,-1000,-1000,1000,-614,-1000,399,-695,-402,-259,430,286,-269,1000,75,835,-81,-1000,959}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00049() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getGroupId():int",
            new int[]{409,281,351,-867,109,274,-1000,-538,-300,-503,-333,357,-52,149,869,1000,909,-1000,-1000,-145,-1000,-625,-1000,395,820,-674,724,-52,-400,1000,-503,496,421,-126,1000,414,-142,1000,746,-92,486,-163,810,65,-469,1000,-582,1000,1000,-751,-1000,-777,300,204,420,-664,-812,-1000,1000,-1000,10,-584,-1000,848}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00050() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getGroupId():int",
            new int[]{-101,-481,-468,-581,156,-470,444,-1000,1000,323,537,357,-1000,-335,385,428,666,184,-1000,101,-1000,-1000,-71,815,1000,362,-584,1000,426,1000,-503,1000,-504,916,1000,342,-492,1000,588,768,479,591,810,-1000,-1000,917,1000,1000,-659,-1000,-893,635,581,134,798,-111,-1000,-1000,215,-1000,-1000,-806,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00051() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getGroupName():java.lang.String",
            new int[]{775,14,-1000,-675,-256,1000,-1000,1000,699,-321,-882,1000,-1000,-614,-1000,-483,738,-1000,-853,-620,1000,-452,-1000,87,92,-891,892,-1000,899,-719,-1000,635,598,-711,525,1000,-829,-322,-1000,-310,643,658,-520,1000,231,-432,-1000,-1000,78,1000,300,154,1000,-355,829,195,-501,-475,698,948,1000,-599,568,230}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00052() {
        org.junit.Assert.assertEquals("java.lang.String:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getGroupName():java.lang.String",
            new int[]{1000,97,76,-494,-719,274,343,923,-52,81,-388,-38,-245,651,-336,641,615,-1000,-240,870,340,-421,341,1000,1000,5,-56,1000,325,-838,56,1000,174,251,330,-709,-382,226,1000,799,715,-655,-360,-1000,550,1000,243,-456,-635,28,-204,565,-468,1000,70,-104,90,-1000,850,11,-640,402,1000,-625}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00053() {
        org.junit.Assert.assertEquals("java.lang.String:NDIz", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getGroupName():java.lang.String",
            new int[]{400,922,-1000,-1000,400,1000,68,161,1000,-104,-245,1000,41,406,42,-876,423,-1000,-484,-1000,1000,-1000,690,-334,782,-1000,111,708,304,-1000,-662,-796,1000,-211,1000,1000,-607,-799,246,-1000,1000,1000,-468,762,1000,-69,-1000,-1000,144,1000,784,1000,-830,1000,-653,257,-1000,-833,1000,190,774,-1000,1000,62}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00054() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getGroupName():java.lang.String",
            new int[]{-564,-132,-221,-399,-577,456,881,1000,-509,-915,354,1000,-332,-438,-1000,-515,442,93,-1000,-343,-691,-945,-1000,26,-608,103,1000,-419,22,-1000,-1000,-704,510,-846,952,911,-558,-134,-1000,196,-66,871,411,1000,-454,-734,131,-1000,-168,138,897,-1000,67,-1000,585,1000,86,208,619,1000,987,912,1000,-129}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00055() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getGroupName():java.lang.String",
            new int[]{36,938,653,-1000,496,1000,-296,841,115,-163,400,694,-45,-75,-1000,271,1000,-624,-244,-1000,-827,-980,1000,-223,-262,421,-521,-273,498,-1000,230,-412,612,-422,595,872,-826,465,1000,-1000,1000,447,-394,-444,-392,-321,81,-1000,-39,-197,661,-234,-333,2,-511,1000,-162,907,934,95,-673,-332,-194,-210}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00056() {
        org.junit.Assert.assertEquals("java.lang.String:ZDJpd1VB", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getGroupName():java.lang.String",
            new int[]{-123,-882,-43,-460,1000,-835,-499,-27,259,-1000,-157,-189,100,-562,-612,-70,-344,-697,-282,870,813,-86,-674,273,-586,-432,474,-1000,988,365,56,80,267,-1000,-1000,1000,-901,1000,-1000,484,-145,251,-851,377,-1000,-213,-1000,-293,1000,388,-542,-1000,409,-186,735,797,751,-471,-100,870,300,-959,-765,-952}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00057() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getGroupName():java.lang.String",
            new int[]{-125,-307,780,280,690,666,-228,778,-270,358,-122,-888,211,-859,-250,364,1000,-153,-400,-787,1000,853,-318,-954,-714,-904,997,583,-559,-1000,493,1000,-412,-209,-374,-157,-259,459,-1000,-755,-1000,-679,-461,-820,170,41,-795,-1000,-823,-906,-1000,-1000,-250,-765,830,-344,677,1000,-35,587,-369,-368,238,850}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00058() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getGroupName():java.lang.String",
            new int[]{775,-647,-766,-1000,65,802,-629,519,462,-1000,-738,415,-460,-1000,-825,-73,1000,-1000,-1000,-265,1000,-1000,-949,290,533,-301,1000,-1000,631,-1000,-1000,167,980,-1000,1000,1000,-1000,-960,-883,470,-657,1000,-1000,588,537,-196,-1000,-1000,-256,1000,-255,-316,1000,92,597,-133,-1000,-745,765,1000,771,-720,-345,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00059() {
        org.junit.Assert.assertEquals("TYPE:java.util.Date", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getLastModifiedDate():java.util.Date",
            new int[]{229,375,1000,1000,1000,1000,-38,-1000,-469,-826,-223,1000,-89,-459,-1000,-440,1000,-650,-1000,12,-1000,-148,-998,311,934,406,-962,378,1000,-405,-64,-731,4,-371,962,1000,-923,295,1000,1000,-1000,-443,1000,-398,-1000,1000,-673,1000,225,-693,1000,-1000,1000,1000,1000,-408,-1000,-989,-517,772,113,-361,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00060() {
        org.junit.Assert.assertEquals("TYPE:java.util.Date", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getLastModifiedDate():java.util.Date",
            new int[]{-428,-887,959,271,1000,1000,1000,-1000,-663,-240,97,192,-253,91,352,-320,-581,-43,-1000,438,-1000,353,493,25,557,-221,633,-238,-1000,1000,421,31,250,208,53,377,-757,-88,842,1000,-1000,-5,586,179,-1000,648,75,1000,-961,-837,812,18,-191,905,-708,22,-1000,-548,-555,285,1000,1000,-1000,525}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00061() {
        org.junit.Assert.assertEquals("TYPE:java.util.Date", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getLastModifiedDate():java.util.Date",
            new int[]{-1000,302,-250,1000,-379,-982,336,587,672,763,-684,-1000,-438,568,1000,1000,-195,385,107,1000,920,-217,1000,451,-698,301,162,-725,-1000,112,1000,991,34,1000,-922,-1000,445,132,-822,-1000,-137,987,-1000,-1000,161,-626,378,-160,-910,719,611,777,252,-820,-950,1000,528,450,-282,-455,-244,1000,486,-290}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00062() {
        org.junit.Assert.assertEquals("TYPE:java.util.Date", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getLastModifiedDate():java.util.Date",
            new int[]{-651,474,-403,-414,464,464,918,-67,631,729,640,-219,-343,964,103,-349,-959,-927,499,-782,138,860,-471,-875,297,208,-517,-358,-586,575,295,-680,262,-898,716,141,737,-630,-810,365,728,-26,-791,244,695,-545,7,-900,-750,-153,257,880,-964,-868,163,-775,19,-778,-257,339,957,749,471,496}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00063() {
        org.junit.Assert.assertEquals("TYPE:java.util.Date", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getLastModifiedDate():java.util.Date",
            new int[]{-700,-226,418,822,714,-232,290,-686,-986,-677,-481,192,-771,705,987,892,-105,365,-591,735,-680,47,963,633,-655,751,-351,-956,-906,910,983,840,150,651,-767,-809,-654,737,842,-806,-48,-71,-117,7,399,-145,-542,-469,-101,219,-214,328,314,-798,-597,-643,-540,235,375,-609,671,987,-291,525}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00064() {
        org.junit.Assert.assertEquals("TYPE:java.util.Date", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getLastModifiedDate():java.util.Date",
            new int[]{229,935,1000,568,1000,1000,370,-1000,-1000,-396,320,1000,-449,-1000,-1000,-1000,1000,-679,-565,-544,-1000,1000,-1000,311,1000,970,-464,378,1000,160,-1000,-1000,-394,-1000,1000,1000,-817,-680,1000,1000,-1000,-1000,1000,-398,-972,1000,-1000,820,419,-1000,-8,-1000,730,1000,1000,-1000,-1000,-981,-872,625,1000,-1000,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00065() {
        org.junit.Assert.assertEquals("TYPE:java.util.Date", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getLastModifiedDate():java.util.Date",
            new int[]{-1000,646,430,1000,731,-809,1000,90,-235,-96,-1000,89,-537,-1000,27,124,-1000,1000,855,-667,466,351,-687,480,601,195,238,-653,-974,-438,1000,-322,381,1000,-366,28,981,-712,381,-778,735,1000,801,-283,656,-76,60,371,-1000,191,613,-517,866,-702,-107,1000,-456,1000,-751,452,1000,-129,-1000,-63}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00066() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getLinkName():java.lang.String",
            new int[]{1000,-802,509,-348,149,-262,957,-391,-118,481,-390,-162,475,-237,-365,-429,-1000,-1000,299,727,222,-746,43,-872,-776,-1000,-985,-248,-1000,552,-612,-843,-1000,-128,-603,943,-107,-979,114,608,-985,1000,634,-914,-480,-26,1000,1000,-512,1000,-671,-831,320,643,-1000,444,825,-232,1000,896,603,269,-55,227}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00067() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getLinkName():java.lang.String",
            new int[]{598,-615,544,691,1000,1000,-851,143,-192,-1000,-651,97,187,98,-727,35,-734,741,-501,-469,-8,-1000,-334,-425,-1000,268,-448,-1000,484,931,1000,1000,915,227,-930,-616,-330,183,595,1000,517,-531,427,437,-1000,266,-105,784,-738,376,616,-702,318,-373,110,-411,530,-1000,588,155,92,951,-219,464}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00068() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getLinkName():java.lang.String",
            new int[]{-47,-766,546,-323,-761,-136,-340,978,-726,-960,1000,393,-150,-157,1000,670,-1000,-523,406,-98,-650,571,-400,267,721,-608,-122,-330,-1000,-673,333,1000,-558,-154,1000,249,-8,-784,-6,572,-716,1000,976,-1000,-200,-535,-101,-37,115,-45,84,52,-1000,-1000,401,915,236,-976,-765,1000,988,-1000,-1000,-369}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00069() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getLinkName():java.lang.String",
            new int[]{88,-545,298,-12,-473,336,161,250,-721,-751,917,365,992,-25,920,508,-603,-648,-303,-582,-804,89,1000,85,721,227,-659,-311,-179,-673,241,189,219,-159,596,807,39,-237,-1000,503,-287,1000,576,-97,1000,252,412,765,160,-1000,-977,-376,-641,-909,330,143,1000,25,124,-136,826,-849,111,-539}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00070() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getLinkName():java.lang.String",
            new int[]{-400,-71,727,-447,-816,-1000,852,481,111,209,527,1000,1000,159,712,-473,-1000,423,637,-61,49,-292,785,294,-4,396,-1000,723,-1000,-1000,-684,567,-400,-14,347,1000,-626,-528,888,207,-522,1000,1000,-1000,-32,-932,-1000,-112,-24,556,-984,-196,-1000,-1000,400,23,-71,-439,391,1000,179,-1000,75,-662}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00071() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getLinkName():java.lang.String",
            new int[]{121,-787,-258,100,437,386,-505,1000,-107,-809,-795,-813,905,890,-992,418,-501,948,-1000,761,359,-855,992,-443,-713,360,851,100,799,898,1000,567,604,1000,27,-829,400,-624,-817,1000,-790,-1000,-786,399,8,1000,799,421,213,-798,-1000,-78,122,-12,-618,718,981,263,-1000,-896,258,8,-402,-9}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00072() {
        org.junit.Assert.assertEquals("java.lang.String:Sm1CYnZnNlc0ZmJUV181czY3XGE=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getLinkName():java.lang.String",
            new int[]{-210,-994,625,411,-659,-271,51,423,-127,-196,-352,950,989,332,880,-5,-594,-617,463,650,-253,-410,1000,200,-209,-340,-273,-158,484,-1000,5,-114,-65,-277,423,-61,-372,-236,321,1000,-478,1000,341,-207,344,-261,-449,509,162,139,-1000,141,-1000,-653,590,369,-43,93,-97,-1000,751,-566,1000,-246}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00073() {
        org.junit.Assert.assertEquals("java.lang.Long:LTIxNDc0ODM2NDg=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getLongGroupId():long",
            new int[]{1000,446,220,400,-179,-706,369,-1000,889,-1000,405,683,501,1000,-729,-551,-627,-640,581,274,395,-53,-449,-198,481,-325,127,137,-324,794,824,-1000,239,-231,114,-177,-1000,134,952,-293,432,589,-441,-729,764,749,144,-814,-114,45,-227,-857,406,-1000,601,100,449,-740,-580,338,-424,423,-281,436}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00074() {
        org.junit.Assert.assertEquals("java.lang.Long:MA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getLongGroupId():long",
            new int[]{981,-423,190,-977,76,475,263,-470,-946,334,-177,-686,-26,196,-404,-363,950,424,-630,253,83,-505,751,-319,-427,-623,-219,137,-996,728,-241,-799,-703,761,-32,-981,-447,-982,662,454,142,-443,702,-52,758,57,-474,-918,-100,-768,-281,814,249,-405,452,198,747,-903,-772,-963,852,452,-13,-651}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00075() {
        org.junit.Assert.assertEquals("java.lang.Long:MA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getLongGroupId():long",
            new int[]{27,170,1000,1000,1000,-521,399,423,-1000,320,290,632,97,172,888,-868,-1000,-876,-205,13,864,-556,-519,-635,1000,1000,1000,-354,386,1000,340,-1000,-660,620,-663,-94,572,-842,-1000,1000,-1000,-710,87,-1000,1000,1000,689,-1000,427,1000,1000,-95,273,-1000,1000,1000,230,1000,1000,-1000,840,1000,-281,405}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00076() {
        org.junit.Assert.assertEquals("java.lang.Long:MA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getLongGroupId():long",
            new int[]{-265,295,395,-559,-642,23,1000,427,676,-337,476,-518,346,-17,-187,-393,-566,-248,953,-584,869,-59,-657,-441,67,169,-480,-951,-228,-934,877,340,-1000,696,194,-73,-345,-17,-937,133,-856,-932,-995,1000,-382,268,-49,-167,-468,-621,-473,890,1000,-127,432,-254,623,-91,948,1000,302,676,-337,-373}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00077() {
        org.junit.Assert.assertEquals("java.lang.Long:MA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getLongGroupId():long",
            new int[]{195,-183,251,-703,-898,-112,-69,1000,359,1000,477,-934,-400,433,915,-803,-652,7,942,1000,-248,-142,-1000,264,-897,-254,-684,-1000,48,-51,169,369,-178,350,409,-1000,439,-945,-217,473,-1000,1000,172,-398,489,727,308,488,914,-921,-412,304,-420,-342,791,-504,538,321,1000,1000,755,-355,758,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00078() {
        org.junit.Assert.assertEquals("java.lang.Long:MA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getLongGroupId():long",
            new int[]{1000,574,583,1000,41,53,324,-386,107,763,-1000,261,277,544,-157,-1000,-1000,-295,1000,317,71,-243,-826,-1000,-322,1000,548,-912,460,1000,-203,560,-667,-641,-160,-499,759,-453,-240,-451,-237,935,259,-931,-32,489,851,-1000,1000,682,35,-61,290,-1000,1000,816,1000,-146,1000,144,840,534,-1000,245}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00079() {
        org.junit.Assert.assertEquals("java.lang.Long:MA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getLongUserId():long",
            new int[]{-424,318,-430,-1000,1000,-114,1000,589,-725,-24,119,658,469,-788,881,-1000,458,74,323,-275,-1000,-427,-1000,360,697,-974,480,-39,664,-1000,-645,-398,-528,1000,-846,-649,1000,-73,225,-654,-1000,959,897,695,-1000,-730,-1000,-460,-385,-798,-1000,1000,-1000,-606,-55,-1000,440,69,-68,-486,1000,-1000,-298,93}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00080() {
        org.junit.Assert.assertEquals("java.lang.Long:LTE=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getLongUserId():long",
            new int[]{-216,-263,1000,-34,-1000,-1000,-881,-614,283,97,742,359,209,-261,-361,955,45,-106,1000,-197,-196,580,1000,-142,1000,-873,-752,-276,-11,-110,-907,494,-487,-1000,554,-849,-458,-733,-1000,1000,-36,-264,-1000,1000,916,352,-580,701,1000,-322,196,-91,-939,367,-362,319,1000,142,1000,78,891,-1000,-347,-763}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00081() {
        org.junit.Assert.assertEquals("java.lang.Long:MA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getLongUserId():long",
            new int[]{-1000,826,-1000,-48,507,-430,-232,-799,-383,-975,86,1000,380,1000,-328,-1000,-312,114,-635,-473,-937,-1000,540,-125,-774,948,304,-87,583,-1000,-514,-591,-528,165,-1000,-649,1000,60,225,-1000,516,-818,941,-1000,-941,-619,-1000,-229,-12,-598,-448,561,-1000,-606,-990,-441,-977,1000,101,-112,-89,121,-1000,93}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00082() {
        org.junit.Assert.assertEquals("java.lang.Long:MA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getLongUserId():long",
            new int[]{-697,950,-534,-1000,78,-1000,1000,469,-740,774,-14,758,623,-150,-619,-1000,254,39,348,-927,-1000,-101,252,-166,1000,-382,799,-145,686,-1000,-1000,-656,-1000,615,531,-580,607,-574,1000,-804,-985,264,478,1000,173,-1000,-714,-55,-1000,-646,-150,1000,-933,-652,-361,-686,1000,366,785,947,-258,-1000,36,-650}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00083() {
        org.junit.Assert.assertEquals("java.lang.Long:MA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getLongUserId():long",
            new int[]{557,-970,-1000,-905,847,1000,99,-9,-427,-256,-66,-196,-714,-598,1000,-1000,679,1000,52,-176,-110,-524,-583,233,-602,792,684,-559,144,11,103,-847,174,1000,-217,203,84,1000,816,-371,-650,338,1000,-695,-1000,-1000,-1000,-99,-1000,-877,-1000,1000,273,-465,369,-303,-96,-3,-68,-1000,80,570,-505,507}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00084() {
        org.junit.Assert.assertEquals("java.lang.Long:MA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getLongUserId():long",
            new int[]{-776,949,595,-410,-315,162,213,-135,-178,375,-376,814,101,-417,164,-160,252,466,-955,-579,-985,613,298,-12,640,246,-776,256,400,-938,-412,-167,-595,-57,-824,670,151,958,-294,56,367,358,-474,699,-5,44,76,758,421,-593,-349,601,446,-655,655,-460,-113,-228,-764,822,-781,-980,960,748}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00085() {
        org.junit.Assert.assertEquals("java.lang.Long:MA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getLongUserId():long",
            new int[]{431,-95,-446,819,401,-225,117,-42,-114,317,1000,853,998,955,-245,530,-365,-1000,-400,191,1000,804,-1000,502,1000,-362,-1000,706,428,-1000,139,-676,-1000,1000,-628,1000,886,-1000,-1000,744,-536,-692,571,1000,859,-1000,59,-130,95,-1000,1000,-710,-1000,1000,-1000,-1000,67,82,412,75,1000,-937,-307,46}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00086() {
        org.junit.Assert.assertEquals("TYPE:java.util.Date", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getModTime():java.util.Date",
            new int[]{-235,358,487,639,390,372,133,-27,-423,965,780,325,-53,370,-288,-23,112,958,993,636,-559,-372,-918,420,-96,610,-387,-903,-445,755,170,158,792,-10,736,432,148,-144,393,696,991,736,-214,-2,329,-246,-90,276,-371,156,813,237,-510,-547,-978,462,883,-400,-387,-788,-307,32,212,519}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00087() {
        org.junit.Assert.assertEquals("TYPE:java.util.Date", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getModTime():java.util.Date",
            new int[]{-143,561,704,497,458,1000,463,-437,-1000,620,825,-271,64,374,-272,488,85,1000,732,619,-651,-585,-866,-148,316,758,-309,-792,-780,1000,-168,273,498,-549,291,797,-428,-764,665,766,1000,1000,-317,244,143,-325,115,243,-41,978,468,507,-893,331,-644,509,1000,-713,-305,-887,58,-71,-366,307}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00088() {
        org.junit.Assert.assertEquals("TYPE:java.util.Date", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getModTime():java.util.Date",
            new int[]{-529,-814,-612,-1000,244,-1000,-236,342,-140,913,258,-255,-329,1000,-1000,-24,517,-665,-103,979,122,301,-1000,878,-766,-671,-1000,1000,273,518,-239,-1000,1000,368,-950,-351,879,72,-692,399,397,-1000,-1000,1000,-417,963,94,232,-99,-960,348,-259,523,-1000,488,-769,-802,867,368,329,669,545,-1000,-666}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00089() {
        org.junit.Assert.assertEquals("TYPE:java.util.Date", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getModTime():java.util.Date",
            new int[]{332,-451,-553,798,286,-336,-151,-564,682,365,597,606,133,960,-956,-112,476,151,-464,196,-658,330,-313,973,-67,-338,-45,663,875,-447,162,-962,547,714,408,-841,917,267,-263,413,-425,-962,-157,420,-607,544,-833,378,-947,-981,761,-121,515,-715,-517,-822,-533,279,271,-584,-266,591,-499,418}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00090() {
        org.junit.Assert.assertEquals("TYPE:java.util.Date", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getModTime():java.util.Date",
            new int[]{-35,214,711,-990,-121,-536,150,63,625,254,-1000,-1000,15,1000,426,-99,190,-1000,936,-1000,157,-133,685,-1000,755,1000,-911,957,-629,-737,432,1000,-1000,-1000,-1000,419,-910,306,-362,-41,199,824,-767,984,-982,-846,522,-1000,570,-231,-552,16,44,47,1000,1000,374,161,816,950,238,-79,-1000,-152}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00091() {
        org.junit.Assert.assertEquals("TYPE:java.util.Date", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getModTime():java.util.Date",
            new int[]{1000,-881,-786,1000,984,-636,-300,-1000,1000,902,493,1000,-646,63,-1000,249,536,514,-403,919,-202,-1000,-638,1000,-968,-25,-5,85,564,-1000,652,-1000,886,442,906,-736,1000,-349,221,630,179,-962,-1000,-53,258,544,-893,378,-1000,-1000,870,-1000,492,-1000,-914,-1000,-1000,645,119,-1000,242,704,-499,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00092() {
        org.junit.Assert.assertEquals("TYPE:java.util.Date", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getModTime():java.util.Date",
            new int[]{402,-599,-210,90,465,1000,726,-651,-305,412,-899,340,-1000,-551,-1000,891,-743,291,-334,1000,1000,-442,-1000,721,-185,422,-744,-60,-361,1000,-4,293,178,286,-767,-329,832,-1000,531,-617,1000,-1000,183,466,-21,-365,515,-140,-372,-111,666,150,-487,781,257,-1000,-294,133,65,428,672,-406,-194,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00093() {
        org.junit.Assert.assertEquals("TYPE:java.util.Date", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getModTime():java.util.Date",
            new int[]{356,-625,-348,-782,778,762,526,-437,-377,-168,-450,682,-746,-721,-849,488,-287,98,-189,771,517,40,-441,-176,-118,200,-937,899,-375,978,-153,-787,571,-702,11,442,893,-826,690,319,473,-567,-508,244,143,-257,115,-317,-571,975,479,507,293,331,801,-578,-692,-275,292,148,665,-578,387,-872}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00094() {
        org.junit.Assert.assertEquals("java.lang.Integer:MzMxODg=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getMode():int",
            new int[]{871,-946,1000,230,-1000,-614,-1000,-159,104,-1000,-15,-993,-326,-79,1000,1000,133,-1000,-51,1000,-890,-705,-695,-1000,-1000,-183,400,-1000,-518,-1000,-375,989,-657,170,1000,684,-1000,541,-569,32,1000,92,-6,-40,1000,155,1000,-334,-94,354,-415,292,966,-1000,-1000,234,-1000,255,852,896,-986,-1000,-356,-483}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00095() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getMode():int",
            new int[]{909,-479,-1000,-483,-412,1000,840,-374,349,696,295,565,345,-264,863,515,1000,-806,-390,-304,-32,-620,-112,-127,-514,-757,-903,-525,-667,-277,-113,-464,-500,-16,174,904,249,591,-832,-340,-92,281,-1000,1000,588,-284,782,816,-676,354,-375,-1000,-286,-159,-57,-517,-1000,458,-238,-58,-619,-537,-21,579}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00096() {
        org.junit.Assert.assertEquals("java.lang.Integer:MzMxODg=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getMode():int",
            new int[]{-326,-318,-367,1000,-148,-556,832,-1000,254,365,-663,1000,-329,-196,-269,442,388,79,-1000,-522,26,332,422,-1000,-926,318,-1000,-1000,724,-1000,-568,-1000,-1000,1000,1000,597,-178,1000,254,1000,-423,1000,-911,-303,466,-674,468,80,972,1000,-627,111,445,372,-105,-1000,-67,-29,-1000,73,644,-1000,-1000,428}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00097() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTIxNDc0ODM2NDg=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getMode():int",
            new int[]{264,-689,-75,477,-744,1000,759,-622,380,-66,-402,1000,112,-439,358,1000,-426,-641,-848,214,1000,-484,-970,-1000,-792,654,-1000,-1000,3,-1000,496,-634,-1000,382,1000,1000,495,521,1000,618,232,807,-683,-374,647,-719,1000,418,337,1000,294,351,805,201,-275,-1000,-586,1000,-343,-29,188,-954,-665,249}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00098() {
        org.junit.Assert.assertEquals("java.lang.Integer:MzMxODg=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getMode():int",
            new int[]{-994,-471,422,1000,-1000,533,-813,-86,-63,-454,1,-76,-943,-1000,-101,-804,-74,-558,-179,564,-643,-130,-680,-1000,-331,-90,12,-377,1000,-488,-617,-810,-803,169,1000,882,-650,327,1000,-551,207,-100,-1000,421,-172,-338,293,-608,1000,191,925,652,1000,-385,-1000,-912,570,-481,-111,188,358,-529,-1000,-166}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00099() {
        org.junit.Assert.assertEquals("java.lang.Integer:MzMxODg=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getMode():int",
            new int[]{-810,-479,-810,-653,221,1000,-1000,1000,-657,1000,-1000,-343,649,-609,-681,-852,-1000,386,520,-1000,1000,-130,-680,-1000,205,227,-15,1000,-784,-1000,998,-810,-907,198,-113,369,526,-35,105,1000,-1000,834,-195,-1000,50,509,727,-344,-969,-1000,-458,-1000,928,1000,-883,752,1000,-1000,-210,-1000,-181,507,313,539}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00100() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getMode():int",
            new int[]{531,2,-1000,-483,-615,517,429,-206,1000,-101,-208,-66,-76,-117,804,1000,1000,-293,-1000,-560,-1000,-631,476,-552,-750,-267,-336,-815,-1000,-277,2,-638,-369,576,389,856,-1000,970,270,337,806,158,-658,654,1000,-739,586,206,-253,1000,-1000,-1000,-208,-1000,-391,-510,-1000,-345,-338,681,-789,-1000,-1000,-49}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00101() {
        org.junit.Assert.assertEquals("java.lang.String:LTE1Mw==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getName():java.lang.String",
            new int[]{-777,-145,87,-56,364,-217,1000,382,-506,437,834,-786,357,508,-724,212,1000,442,-125,-153,289,251,1000,-837,265,-379,-1000,-543,659,-715,985,-297,-498,-8,344,-957,-645,-589,971,-1000,758,275,927,-224,1000,-124,140,-1000,-330,-1000,-731,334,-308,-474,785,-167,699,49,-244,-377,-424,724,-104,-75}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00102() {
        org.junit.Assert.assertEquals("java.lang.String:akE=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getName():java.lang.String",
            new int[]{565,73,-741,-451,830,587,1000,862,-455,752,-48,-549,675,124,-1000,1000,989,-18,-35,-153,-400,559,610,-494,1000,539,25,-791,626,683,865,-205,367,-608,312,-466,197,-1000,590,-755,515,399,351,-876,977,47,606,-938,15,-549,-731,688,-815,-127,-561,402,313,-587,-287,-1000,-622,1000,-104,-905}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00103() {
        org.junit.Assert.assertEquals("java.lang.String:MHgzMTE=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getName():java.lang.String",
            new int[]{-674,-362,-185,-785,364,-303,586,807,528,-1000,-987,-367,1000,1000,558,-846,-1000,442,748,1000,607,-1000,1000,-45,-928,1000,196,260,-1000,-715,1000,-297,-1000,1000,-774,-356,417,-9,1000,931,-966,528,-941,1000,809,256,140,-988,-73,-349,81,265,571,229,-1000,-629,699,1000,-891,1000,1000,628,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00104() {
        org.junit.Assert.assertEquals("java.lang.String:LTMxOA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getName():java.lang.String",
            new int[]{-1000,270,-1000,-1000,1000,1000,1000,232,-351,-86,-893,-318,439,-823,855,343,679,516,737,311,-1000,1000,-293,1000,874,457,59,-1000,-242,-474,3,-1000,1000,-603,-161,1000,1000,-1000,-766,1000,495,-74,-91,-218,813,996,21,198,1000,-295,236,-843,246,1000,277,385,1000,-15,236,-1000,-1000,1000,222,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00105() {
        org.junit.Assert.assertEquals("java.lang.String:Njc=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getName():java.lang.String",
            new int[]{-777,-398,180,-67,1000,9,1000,-329,-1000,722,1000,-783,-530,-892,-941,940,1000,327,-125,-539,101,1000,522,-154,1000,-1000,-1000,-424,1000,-715,186,-1000,357,-23,1000,43,-858,-628,244,-1000,1000,-809,1000,-364,1000,260,-1000,396,213,-588,-117,-112,-132,-907,1000,-86,930,-296,934,251,-1000,773,825,-907}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00106() {
        org.junit.Assert.assertEquals("java.lang.String:RnpZVCBfXw==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getName():java.lang.String",
            new int[]{160,-410,-546,481,-221,982,893,-604,-11,-87,776,-1000,-1000,-1000,-612,-787,379,1000,-69,29,580,500,1000,-1000,-459,-617,-1000,-347,1000,-378,990,212,-964,760,-922,-1000,-979,-715,1000,-695,644,-340,966,143,809,1000,504,-642,240,-1000,-652,314,549,-449,433,-288,338,418,241,182,292,-529,227,952}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00107() {
        org.junit.Assert.assertEquals("java.lang.Long:MA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getRealSize():long",
            new int[]{-19,-442,574,-566,1000,641,-63,-961,-1,-1000,-247,465,-112,-902,-503,1000,720,327,769,1000,-99,137,-881,1000,249,223,800,175,-471,-183,1000,-1000,-351,182,1000,-187,1000,484,39,-547,-669,1000,959,-232,-130,-1000,15,451,-1000,-1000,663,82,-1000,-1000,726,679,-311,1000,1000,735,-976,438,-1000,-73}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00108() {
        org.junit.Assert.assertEquals("java.lang.Long:MA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getRealSize():long",
            new int[]{831,-319,-402,-993,-578,-1000,1000,-1000,927,-370,-738,-1000,1000,594,-555,1000,283,426,1000,391,-1000,-156,199,-1000,-202,862,1000,1000,414,-643,-199,-728,-759,219,-790,-363,-1000,-388,-397,342,1000,534,-1000,1000,-1000,-204,-1,-456,665,55,1000,-837,768,1000,-1000,-850,237,-1000,-797,749,502,-855,-1000,241}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00109() {
        org.junit.Assert.assertEquals("java.lang.Long:MA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getRealSize():long",
            new int[]{73,-70,-585,-1000,-600,-637,-116,-1000,1000,-277,-449,-867,1000,1000,-1000,1000,1000,26,-386,1000,50,400,-1000,161,1000,1000,-1000,204,707,-975,-571,-1000,-1000,189,-436,429,-237,-788,831,389,81,-368,1000,-439,-860,-1000,-474,463,-970,965,998,622,-1000,-193,-32,1000,-601,-464,-25,1000,-945,-346,-1000,-482}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00110() {
        org.junit.Assert.assertEquals("java.lang.Long:MA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getRealSize():long",
            new int[]{1000,740,-233,337,-947,-23,-724,-219,-250,1000,1000,128,-368,-884,1000,-287,-54,779,-1000,-1000,-1000,-197,-294,515,-1000,-995,-907,369,550,768,-507,956,351,1000,423,166,270,577,846,-775,-260,-1000,-239,-1000,464,437,-530,-299,482,-360,-1000,-674,-323,-623,-326,-383,-891,126,466,-735,-784,620,671,454}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00111() {
        org.junit.Assert.assertEquals("java.lang.Long:MA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getRealSize():long",
            new int[]{-219,-241,1000,-144,1000,1000,-352,-745,-1000,-326,304,1000,-843,225,-404,711,638,229,-104,303,-235,-1000,-518,1000,249,-351,291,-728,-1000,-202,1000,-1000,837,1000,-1000,1000,1000,484,795,-547,-1000,578,1000,-728,692,-18,-137,1000,-840,-1000,-154,-261,-1000,-1000,-1000,1000,-943,1000,1000,-436,-1000,1000,-1000,-138}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00112() {
        org.junit.Assert.assertEquals("java.lang.Long:MA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getRealSize():long",
            new int[]{567,-730,-361,-444,1000,-142,-372,214,1000,181,307,768,-353,-893,674,52,-769,1000,156,72,-401,-1000,-584,1000,-1000,-964,1000,1000,-1000,12,-451,-301,1000,567,294,-105,1000,109,673,157,-1000,-283,-744,-1000,399,923,-796,-852,459,27,-128,-1000,-226,-363,-66,335,-860,599,475,528,166,531,176,-13}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00113() {
        org.junit.Assert.assertEquals("java.lang.Long:MA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getRealSize():long",
            new int[]{1000,-730,249,-1000,597,328,-650,-962,364,460,13,191,-266,-1000,205,-134,663,796,-443,435,-1000,-1000,-517,817,-975,815,-14,476,-587,-894,38,-301,-64,567,641,1000,868,697,609,-660,-1000,-10,-183,-1000,318,-1000,-346,604,292,-968,150,-507,-1000,-1000,-480,584,-709,608,292,528,-1000,476,-1000,-412}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00114() {
        org.junit.Assert.assertEquals("java.lang.Long:MA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getSize():long",
            new int[]{-1000,454,1000,-467,-809,-170,-116,-116,554,-320,707,-316,-769,31,-395,-606,-1000,294,730,1000,718,901,609,71,-108,663,-885,-1000,-239,326,75,-1000,-102,-59,823,-299,436,1000,-155,-421,-276,400,791,-704,189,-440,526,1000,-559,247,-137,40,681,566,-227,526,-847,-336,879,-859,-973,-878,729,340}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00115() {
        org.junit.Assert.assertEquals("java.lang.Long:MA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getSize():long",
            new int[]{-1000,-823,1000,673,908,740,-627,-455,-900,400,-1000,-503,-799,635,435,-180,120,-714,1000,-400,-183,-1000,1000,351,-668,-234,577,53,120,657,-571,51,-1000,1000,-311,674,-734,-537,-113,-97,337,-493,-254,509,-978,-274,-1000,425,371,-553,-78,196,426,846,-278,124,1000,381,-1000,71,-888,-948,822,66}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00116() {
        org.junit.Assert.assertEquals("java.lang.Long:MA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getSize():long",
            new int[]{50,-902,344,-413,113,270,-247,-400,-699,-14,-239,406,-823,-927,-59,-752,-731,-250,-557,-802,-459,997,-35,99,348,801,-564,329,-286,412,-196,-845,-366,-553,4,242,-890,988,-85,-833,-402,644,901,-322,655,965,-583,873,-297,563,58,483,40,-166,-567,-14,-515,267,301,-553,384,-23,476,-386}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00117() {
        org.junit.Assert.assertEquals("java.lang.Long:MA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getSize():long",
            new int[]{-896,-649,1000,-403,-525,-717,-124,-502,302,409,89,225,-1000,674,-966,-467,-228,-807,406,446,620,-446,-1000,543,-752,258,-1000,77,373,911,-426,-1000,-506,685,1000,-195,301,642,2,-779,-8,400,-21,-351,-63,-1000,344,481,-504,-1000,-765,-870,1000,837,-843,777,94,-381,-24,-291,-283,-1000,349,606}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00118() {
        org.junit.Assert.assertEquals("java.lang.Long:MA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getSize():long",
            new int[]{-129,561,-950,-1000,-401,1000,-692,1000,328,648,-922,1000,-823,-1000,288,-800,-262,-153,802,-479,-319,-40,-867,-1000,-418,-473,549,1000,-1000,412,-162,-845,-1000,-1000,-1000,-323,-1000,-409,567,1000,-96,-1000,428,1000,-582,295,-1000,-881,651,915,874,-191,-318,-166,643,-1000,875,1000,-1000,1000,-311,916,1000,-439}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00119() {
        org.junit.Assert.assertEquals("java.lang.Long:MA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getSize():long",
            new int[]{-165,44,812,75,-44,1000,-161,266,-441,-616,-726,1000,55,-275,-1000,-730,405,-121,-1000,-692,-134,-432,-937,13,53,165,217,139,-849,-592,177,-1000,-785,-330,-847,956,-1000,45,-1000,746,287,228,952,880,105,395,-1000,-132,831,643,149,690,-537,276,323,-452,-321,68,-664,-438,-536,-560,1000,-576}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00120() {
        org.junit.Assert.assertEquals("java.lang.Long:MA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getSize():long",
            new int[]{357,786,-1000,-104,-129,-590,119,513,265,-1000,566,-655,-14,-413,-1000,-276,-1000,661,-713,1000,307,600,1000,-1000,-655,76,170,-476,-1000,-578,-1000,356,-1000,224,899,-431,1000,408,165,-779,1000,-1000,915,-349,-843,887,320,357,-343,780,-134,-290,1000,693,906,-115,155,-973,693,561,749,733,1000,-845}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00121() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getUserId():int",
            new int[]{131,750,198,527,347,-1000,1000,1000,79,-405,-517,618,1000,57,1000,818,436,-197,-592,670,-1000,-1000,722,1000,128,-802,953,1000,1000,1000,519,924,-326,-1000,-908,-975,959,116,-602,1000,280,-683,887,-88,1000,534,-329,1000,-1000,1000,-1000,585,342,-661,1000,-858,1000,-425,1000,725,-1000,-1000,954,-682}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00122() {
        org.junit.Assert.assertEquals("java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getUserId():int",
            new int[]{-890,81,-561,1000,-204,1000,1000,782,1000,-820,511,-1000,212,-948,-350,-706,888,-16,-837,1000,648,-991,-321,504,34,-1000,-821,1000,-505,-1000,1000,794,-700,-1000,1000,972,-1000,725,-406,53,256,-132,-479,-546,-22,361,-969,307,-166,94,-1000,1000,-172,-142,224,-1000,1000,-165,-727,393,638,870,-310,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00123() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getUserId():int",
            new int[]{1000,14,1000,781,-900,-1000,693,1000,-301,401,-517,734,-191,1000,708,946,-1000,-569,-682,1000,134,1000,-1000,1000,967,843,162,-322,316,-1000,-1000,924,-42,-1000,-364,-891,298,1000,1000,-500,423,292,376,553,-873,810,498,1000,-1000,-4,130,1000,-106,689,1000,-58,-1000,1000,963,-1000,-609,1000,120,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00124() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getUserId():int",
            new int[]{337,-249,343,783,-326,-1000,1000,612,224,-180,-1000,1000,473,907,1000,1000,3,-123,-135,1000,-172,-529,282,1000,1000,-400,850,1000,729,-2,400,1000,436,-829,-864,-753,994,910,1000,-841,-1000,-1000,1000,-133,8,-1000,1000,1000,-1000,933,-7,468,-102,-416,872,-800,-1000,1000,1000,-488,-947,75,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00125() {
        org.junit.Assert.assertEquals("java.lang.Integer:MQ==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getUserId():int",
            new int[]{-963,-350,-811,838,1000,431,599,325,-61,277,314,-469,1000,-987,598,68,739,960,114,-164,-162,-1000,1000,965,-370,-685,-196,1000,1000,822,881,680,332,-935,926,690,-1000,-656,-1000,1000,1000,-934,428,186,166,1000,391,342,-317,364,-1000,-14,-193,-1000,-664,-555,1000,-1000,330,1000,-5,-1000,104,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00126() {
        org.junit.Assert.assertEquals("java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getUserId():int",
            new int[]{-1000,-706,-380,915,484,1000,678,-686,1000,1000,-624,-1000,-719,1000,359,-1000,538,1000,-1000,1000,-359,299,1000,1000,226,-310,-62,-925,1000,204,444,1000,575,-476,1000,-906,-1000,-400,-918,1000,1000,-1000,-280,-1000,1000,1000,1000,-630,740,-685,-1000,-330,-203,-786,231,1000,1000,1000,-1000,-641,440,-1000,-902,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00127() {
        org.junit.Assert.assertEquals("java.lang.Integer:MTAwMA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getUserId():int",
            new int[]{-362,-767,-465,545,1000,155,1000,-83,188,180,-112,-307,1000,-517,1000,-361,213,1000,303,755,144,-1000,615,296,-129,117,-559,817,794,627,-156,50,760,-692,349,943,-340,1000,-194,1000,1000,81,513,429,-162,1000,-239,60,567,-160,-1000,951,592,-577,-177,-387,984,-630,-806,28,294,-690,-815,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00128() {
        org.junit.Assert.assertEquals("java.lang.String:MHg4", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getUserName():java.lang.String",
            new int[]{-1000,-633,-1000,-490,-1000,1000,168,-234,-897,194,-43,154,256,-1000,-63,-951,102,361,315,-184,205,-1000,1000,983,-615,563,341,140,859,-784,1000,1000,-1000,-1000,-343,561,494,66,1000,-146,-1000,-1000,1000,498,-494,1000,-852,0,-714,-391,-901,-438,-882,1000,406,343,744,766,-712,101,393,539,-442,-853}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00129() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getUserName():java.lang.String",
            new int[]{907,-47,164,1000,621,-293,-507,39,-368,874,1000,369,884,-148,608,769,-424,181,-356,-792,395,7,-1000,-12,26,-1000,760,-527,379,-417,-130,-389,212,-538,1000,-142,168,28,884,9,875,468,-366,-851,-293,-18,-1000,786,681,213,104,299,605,276,149,-182,-458,-209,1,159,154,-1000,-230,7}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00130() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getUserName():java.lang.String",
            new int[]{-1000,525,859,-1000,-814,512,-840,-191,817,-404,604,-1000,234,-665,-89,-352,1000,820,660,-1000,-1000,761,277,1000,72,977,314,-231,-1000,-382,391,-710,-96,364,-1000,79,329,-469,-1000,666,-1000,487,858,1000,700,-197,809,-165,-925,315,946,-390,-997,-865,205,278,866,621,567,-216,27,1000,-562,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00131() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getUserName():java.lang.String",
            new int[]{-241,158,-374,-1000,-94,298,818,-52,-1000,-1000,-1000,-100,-1000,1000,-850,-1000,886,589,-660,-495,1000,-822,1000,252,-718,660,-631,-1000,169,620,54,1000,-1000,-1000,-1000,914,-890,636,486,665,-1000,-1000,1000,-70,776,657,574,232,869,-1000,-1000,-731,710,334,517,768,1000,301,1000,1000,549,1000,759,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00132() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getUserName():java.lang.String",
            new int[]{-387,266,221,-584,400,-547,557,819,213,-441,-767,-1000,409,-123,295,1000,-1000,47,-1000,-747,1000,710,-380,1000,-501,-1000,1000,65,-534,-972,-264,-640,-191,863,32,172,-1000,-94,-1000,1000,400,254,-340,-1000,1000,-1000,-260,24,530,-103,-2,-221,1000,-1000,435,-1000,-184,-1000,124,551,664,429,292,-693}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00133() {
        org.junit.Assert.assertEquals("java.lang.String:MHg4MDAwMDAwMDAwMDAwMDAwMA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getUserName():java.lang.String",
            new int[]{-1000,-633,732,-588,-1000,-346,619,-234,-239,194,570,-813,256,-1000,-321,-1000,102,-296,-604,-487,-36,-280,748,842,-581,214,341,436,859,-784,762,1000,936,819,-873,1000,-480,-394,-282,1000,-314,-294,817,988,238,118,-852,-1000,716,-101,517,95,436,-592,385,-702,744,-994,23,-524,1000,911,1000,-233}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00134() {
        org.junit.Assert.assertEquals("java.lang.String:", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "getUserName():java.lang.String",
            new int[]{971,-711,-570,926,977,-1000,248,744,38,-794,641,-878,-1000,-895,358,-30,332,-988,344,-187,-639,-143,136,243,-574,1000,-1000,190,44,725,235,755,381,199,-333,544,-1000,-86,-875,-772,1000,274,-588,1000,537,-927,1000,39,1000,-1000,377,-121,330,-724,-542,811,-80,940,658,680,986,570,1000,-985}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00135() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isBlockDevice():boolean",
            new int[]{808,302,162,-1000,481,-593,644,669,-607,1000,1000,553,1000,-654,1000,248,590,-955,1000,-403,-840,-1000,364,1000,836,-406,971,324,-872,-113,501,502,-643,1000,-1000,-276,-1000,877,-36,823,-778,-181,305,234,-297,-1000,-804,1000,1000,264,9,-1000,-1000,-332,994,1000,5,-349,808,-350,-1000,-257,-1000,910}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00136() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isBlockDevice():boolean",
            new int[]{-212,401,495,556,110,-137,-1000,-429,-631,1000,472,-341,-44,332,-530,632,-928,665,-367,246,101,248,519,412,26,-164,-194,465,1000,-843,-93,-958,872,-14,190,15,-667,17,514,1000,727,394,-851,-315,-150,-513,-129,517,-596,228,497,802,709,565,-1000,-33,-540,1000,1000,-212,-120,590,363,698}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00137() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isBlockDevice():boolean",
            new int[]{219,-582,1000,1000,-399,1000,299,-804,-803,1000,-1000,-1000,799,-79,1000,-110,647,1000,286,-121,1000,287,-796,821,-301,762,849,555,332,-589,981,-1000,530,66,723,-207,-1000,-692,992,-86,-1000,227,-577,-767,-83,-1000,-610,-501,719,1000,1000,761,565,1000,-328,276,-10,-431,-134,-430,153,292,-1000,773}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00138() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isBlockDevice():boolean",
            new int[]{-400,852,162,538,177,591,-1000,-580,-607,824,-1000,-1000,1000,1000,-262,590,-1000,731,-426,-968,958,-312,1000,1000,-816,-1000,-856,-105,1000,-663,272,-1000,242,1000,27,377,-1000,-23,337,823,-734,574,-1000,94,-332,1000,-804,-1000,-596,-1000,159,-1000,580,97,-318,-846,151,814,587,-1000,-1000,-415,801,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00139() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isBlockDevice():boolean",
            new int[]{-865,-75,-1000,400,69,-376,1000,-31,-139,824,-35,-572,-1000,-310,-1000,-265,-1000,666,-1000,173,-510,-192,373,-91,-180,-55,-1000,-782,311,450,63,1000,1000,-246,228,493,-1000,-31,597,389,50,-48,191,23,412,511,-365,-144,-117,-255,1000,-168,389,213,-1000,-400,-814,-56,952,206,-509,-283,260,43}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00140() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isBlockDevice():boolean",
            new int[]{1000,471,-860,1000,813,299,106,-804,-61,748,-479,-1000,753,332,-500,464,-938,348,-1000,270,-325,154,65,1000,-850,-164,544,635,1000,-898,-194,-524,1000,1000,-355,-1000,-1000,-595,1000,1000,-734,799,-851,-1000,-26,-36,103,-635,-596,-162,508,44,984,1000,-738,-1000,270,1000,740,0,-773,-99,801,-457}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00141() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isCharacterDevice():boolean",
            new int[]{478,-2,-1000,-79,605,-1000,565,249,73,321,576,-30,117,-71,-1000,525,-744,283,-1000,216,-483,740,449,442,-587,180,666,-1000,253,1000,309,-665,-239,-342,-978,-76,-1000,516,596,696,-1000,858,471,-198,230,-693,-845,207,-84,-301,526,860,-1000,447,925,228,71,576,1000,43,-690,-701,-1000,713}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00142() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isCharacterDevice():boolean",
            new int[]{-149,-119,1000,682,-259,-354,-291,-747,-679,-823,344,82,-84,-627,1000,9,827,-438,-8,-35,211,-79,-131,839,91,-667,-768,-305,-233,799,788,-785,1000,-1000,-248,86,99,-54,454,-887,-731,-511,-1000,-484,-1000,621,-412,170,482,316,-1000,423,7,925,1000,-295,298,-392,-961,-1000,606,266,-259,852}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00143() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isCharacterDevice():boolean",
            new int[]{725,562,-951,559,-20,-1000,-498,-592,631,1000,17,-756,935,-882,-1000,760,-1000,714,-1000,226,-467,47,1000,498,645,-351,1000,-574,191,445,987,108,-444,-952,-918,-864,576,390,-257,1000,-425,265,840,831,1000,-1000,-1000,-268,-856,1000,1000,-620,-507,-795,1000,697,748,-510,1000,111,-1000,-1000,-1000,-904}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00144() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isCharacterDevice():boolean",
            new int[]{223,310,-83,-79,-1000,-693,-572,-1000,169,392,205,-727,1000,-1000,-1000,9,-1000,271,-784,-625,-342,-355,1000,218,928,-59,269,-164,-10,445,1000,1000,-239,-1000,-308,-718,1000,338,-596,1000,151,-113,311,1000,1000,-1000,-1000,-1000,-631,579,1000,-881,-51,-716,1000,1000,10,-574,1000,42,-1000,-997,-1000,-963}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00145() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isCharacterDevice():boolean",
            new int[]{-15,-923,151,670,-1000,1000,328,275,322,-1000,438,-1000,418,330,1000,64,100,-852,-481,-1000,-283,-967,552,193,346,964,-1000,245,459,-875,-778,-102,-706,955,443,-541,-31,653,-413,-1000,-84,131,-504,-527,155,205,-1000,242,290,-205,143,-694,423,853,-340,-574,496,-128,-1000,757,315,-11,332,-908}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00146() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isCharacterDevice():boolean",
            new int[]{-767,-670,1000,-1000,-838,1000,704,103,1000,-1000,-226,-1000,-694,-1000,541,-454,764,-599,873,-1000,1000,-1000,-292,-877,281,1000,-1000,-1000,-1000,341,-1000,809,398,823,1000,1000,1000,1000,-1000,-674,-54,-1000,-138,-347,-1000,1000,-1000,717,412,-721,-301,-1000,1000,162,-1000,-52,-1000,-1000,-1000,-900,606,-868,-481,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00147() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isCharacterDevice():boolean",
            new int[]{-1000,634,783,-1000,1000,765,-14,1000,1000,734,169,-895,-1000,-1000,-612,906,1000,270,796,164,67,-913,-412,-86,-1000,1000,-659,-365,-1000,1000,-1000,-1000,316,987,-1000,1000,505,1000,398,-486,-517,-329,39,-791,1000,1000,-935,1000,106,-7,-988,595,-324,1000,1000,240,-413,-1000,-994,-906,-640,-1000,-736,11}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00148() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isCheckSumOK():boolean",
            new int[]{794,670,477,-1000,917,-20,977,541,-380,-643,-283,582,769,779,-470,-623,-1000,134,181,-981,-1000,-291,-355,-371,1000,-398,913,-205,782,-541,16,301,-915,-1000,378,-1000,1000,-1000,1000,393,-581,1000,-381,-641,610,143,-1000,-752,1000,-336,-1000,428,-563,-100,-256,1000,-327,-1000,-436,-896,164,187,74,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00149() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isCheckSumOK():boolean",
            new int[]{-1000,-455,-77,-312,100,-385,361,339,-3,723,323,-277,815,158,-446,75,377,-161,-385,77,-1000,-646,-1000,-330,-1000,1000,-1000,-273,1000,-240,940,502,-472,-1000,842,987,-3,739,78,-334,-579,472,319,-217,-176,878,-577,951,-1000,-882,-1000,-1000,-773,1000,-1000,762,1000,735,414,1000,1000,25,-300,-914}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00150() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isCheckSumOK():boolean",
            new int[]{-1000,-41,-790,-167,363,895,1000,-411,844,-560,1000,417,672,-209,-1000,-772,-1000,610,-486,-384,-481,-297,-1000,291,-707,862,-424,-858,1000,-473,-973,-197,-478,-108,-117,43,524,-184,1000,-205,-496,-947,-1000,577,556,279,-403,1,-436,269,-581,-901,-167,1000,-686,1000,329,-1000,-859,333,90,967,-19,625}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00151() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isCheckSumOK():boolean",
            new int[]{823,-841,-825,430,-1000,993,-869,676,-871,-1000,-33,-202,-84,-13,384,-490,-1000,-571,-840,-150,343,1000,197,425,518,-1000,1000,403,-771,899,1000,-300,-878,-230,-1000,-232,289,26,132,599,-1000,-554,-586,-498,926,-814,-767,-135,1000,1000,-22,1000,295,-123,1000,-884,-1000,-699,-963,-779,-366,-844,1000,301}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00152() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isCheckSumOK():boolean",
            new int[]{-1000,-686,-1000,-1000,696,496,799,-343,309,-1000,-177,46,841,-81,163,-857,-322,-347,-1000,-732,31,893,-1000,-162,-1000,977,-620,832,1000,214,-1000,284,1000,1000,45,1000,-741,247,330,-860,-633,-1000,970,984,584,-200,731,680,106,643,-46,-891,-175,1000,-976,-770,-278,469,-306,621,-179,1000,-136,-57}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00153() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isCheckSumOK():boolean",
            new int[]{1000,-642,569,944,-457,1000,417,469,844,-143,615,-61,392,-209,-949,-912,-1000,1000,315,-561,-554,903,-1000,388,322,179,678,-618,-456,-71,505,-545,-1000,-661,246,-1000,1000,-436,1000,1000,-687,678,-1000,-865,584,189,-1000,-588,288,-116,-1000,789,-590,809,934,832,-223,-1000,-1000,-556,90,-59,214,249}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00154() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isDescendent(org.apache.commons.compress.archivers.tar.TarArchiveEntry):boolean",
            new int[]{-480,-626,679,-828,674,-1000,927,-422,215,-536,257,1000,-155,91,425,711,267,85,-164,1000,675,323,-775,-794,-1000,1000,-560,-13,-549,51,-1000,-892,111,-1000,816,-970,100,-329,-976,-346,454,-130,-1000,-963,623,783,-1000,-15,430,840,1000,-347,144,-335,-238,431,1000,162,424,-289,167,-56,-271,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00155() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isDescendent(org.apache.commons.compress.archivers.tar.TarArchiveEntry):boolean",
            new int[]{885,806,434,-1000,1000,-1000,1000,-432,396,-1000,626,1000,506,-1000,693,567,-1000,1000,-882,746,-472,165,-145,491,-1000,-73,357,-1000,308,1000,-607,-730,1000,-1000,73,-1000,67,537,-848,448,-117,-236,-1000,-1000,758,711,-1000,-459,1000,-260,39,1000,-53,103,-652,1000,1000,-198,1000,1000,705,794,-1000,479}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00156() {
        org.junit.Assert.assertEquals("THROW:java.lang.NullPointerException", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isDescendent(org.apache.commons.compress.archivers.tar.TarArchiveEntry):boolean",
            new int[]{1000,-50,-781,836,1000,-128,861,-792,257,1000,-368,-660,1000,-817,425,232,-700,-416,554,1000,546,153,-976,79,-1000,308,-1000,-1000,-1000,-134,-675,-1000,17,-631,-934,300,1000,1000,-984,503,-180,-446,475,-1000,471,-1000,-1000,530,-533,322,1000,-634,-836,-1000,-1000,609,-97,-221,1000,1000,88,-477,98,188}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00157() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isDescendent(org.apache.commons.compress.archivers.tar.TarArchiveEntry):boolean",
            new int[]{-1000,-467,1000,494,-1000,-1000,-728,833,-128,672,1000,-1000,-412,1000,-614,115,471,-706,782,-232,593,-325,-9,-512,1000,-750,792,572,600,-357,-88,1000,558,1000,1000,826,177,-620,1000,1000,705,447,700,381,-200,1000,1000,1000,-1000,1000,582,-1000,213,698,-385,307,-1000,-911,-1000,-1000,-1000,-770,-234,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00158() {
        org.junit.Assert.assertEquals("THROW:java.lang.NullPointerException", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isDescendent(org.apache.commons.compress.archivers.tar.TarArchiveEntry):boolean",
            new int[]{1000,662,-1000,-175,-514,1000,446,-1000,-951,-149,-1000,998,822,-102,-1000,883,-1000,273,797,259,1000,-736,-723,205,-898,-1000,1000,-821,-8,42,-546,11,1000,-1000,-475,-1000,571,1000,887,-1000,470,1000,-1000,45,-558,-1000,-1000,-1000,368,-757,-105,1000,878,-1000,1000,-1000,313,-1000,1000,1000,662,339,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00159() {
        org.junit.Assert.assertEquals("THROW:java.lang.NullPointerException", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isDescendent(org.apache.commons.compress.archivers.tar.TarArchiveEntry):boolean",
            new int[]{-707,857,-530,1000,-463,-1000,253,-567,-2,-377,1000,1000,-120,-1000,335,122,546,-614,-679,-504,774,-12,-118,130,-413,1000,1000,293,917,-238,-801,-186,247,-739,1000,1000,815,-1000,-1000,148,141,-408,810,-1000,-69,1000,-907,837,-1000,-253,129,-889,687,-208,819,-1000,-821,1000,1000,-869,-602,-239,30,-244}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00160() {
        org.junit.Assert.assertEquals("THROW:java.lang.NullPointerException", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isDescendent(org.apache.commons.compress.archivers.tar.TarArchiveEntry):boolean",
            new int[]{-175,-475,351,794,-1000,993,-1000,1000,-1,1000,1000,-1000,1000,1000,-364,55,-259,-548,1000,-1000,573,-1000,1000,635,1000,-1000,1000,-239,1000,95,697,1000,1000,1000,796,1000,472,-636,1000,1000,389,1000,1000,365,-1000,331,1000,1000,-1000,-588,-1000,-173,-117,1000,572,366,-1000,-960,-886,-1000,-1000,-1000,-519,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00161() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isDescendent(org.apache.commons.compress.archivers.tar.TarArchiveEntry):boolean",
            new int[]{-922,-314,361,1000,-1000,542,-1000,480,-294,198,-1000,-847,520,1000,-151,88,879,-1000,-26,-239,677,170,38,-745,747,15,-1000,1000,560,-93,-407,426,-384,1000,873,1000,209,163,706,459,711,-554,1000,1000,-506,809,1000,1000,-1000,536,-714,-785,101,251,-1000,1000,-1000,-564,-1000,-1000,-877,-11,-739,-423}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00162() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isDirectory():boolean",
            new int[]{142,-49,-742,-392,-1000,1000,834,-1000,-546,-354,501,1000,645,-180,831,-548,-1000,-917,-10,-808,587,747,-877,-59,-541,-472,1000,752,1000,-1000,-1000,-471,1000,-261,1000,-652,507,1000,65,476,462,1000,1000,775,-463,-171,578,1000,-1000,-1000,450,-325,-945,1000,-1000,-26,37,-1000,163,593,-790,828,651,989}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00163() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isDirectory():boolean",
            new int[]{-79,-271,-932,-70,937,-1000,-301,1000,351,-105,-985,-1000,444,400,1000,-998,655,-1000,-1000,-1000,-1000,1000,-88,630,-1000,911,-1000,-135,214,960,1000,852,112,1000,855,-107,-81,-1000,-382,1000,157,1000,-1000,-1000,81,-1000,-894,-1000,-1000,950,153,-1000,59,-1000,-1000,-1000,-62,254,970,805,722,-1000,160,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00164() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isDirectory():boolean",
            new int[]{814,210,-471,729,-1000,-721,-321,-484,467,933,-247,-366,-755,-848,372,52,982,239,648,-726,96,103,939,-187,-1000,59,724,-308,970,-721,-285,-386,-87,-230,371,-1000,-62,852,362,-613,-224,491,689,55,-201,-1000,-359,1000,-827,-776,45,-838,312,-717,-670,38,-348,122,996,359,-565,660,1000,265}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00165() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isDirectory():boolean",
            new int[]{399,62,-232,-374,-825,218,862,-507,-511,241,396,-439,-92,265,1000,-1000,-560,-960,-709,-1000,-116,1000,-142,-216,-1000,162,334,928,970,-501,267,-412,1000,755,1000,-523,1000,-919,67,1000,491,1000,726,444,-351,-1000,182,-629,-1000,-1000,-42,-1000,-1000,-82,-898,-188,373,526,616,1000,270,526,790,-143}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00166() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isDirectory():boolean",
            new int[]{869,185,238,-236,-225,184,-405,-550,21,691,-724,-1000,-139,-244,93,-169,797,-992,357,-772,-771,1000,483,381,381,1000,-951,201,1000,135,316,111,-948,919,318,-387,710,-1000,-264,789,45,408,138,-516,-1000,-1000,-798,-1000,-862,-513,207,-856,-459,-208,-262,-554,-332,-141,1000,551,-733,408,550,130}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00167() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isDirectory():boolean",
            new int[]{564,-2,-42,-157,185,-987,-422,519,258,501,-393,-1000,-331,262,668,-817,698,-975,-978,-1000,-1000,1000,666,45,-1000,895,-1000,214,593,899,981,-11,-381,341,689,-278,657,-1000,-190,1000,285,966,-352,-640,-168,-1000,-474,-1000,-1000,178,-305,-1000,-639,-1000,-1000,-352,-561,201,991,1000,-315,-148,584,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00168() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isExtended():boolean",
            new int[]{-1000,399,253,1000,-1000,394,394,467,367,-1000,-625,889,357,1000,-754,150,-1000,310,-971,1000,-664,408,-672,-62,1000,600,966,164,879,-325,229,1000,-891,518,1000,-1000,-973,-1000,773,-52,-14,941,-952,355,355,340,-1000,778,554,483,-346,1000,-154,-58,1000,-1000,32,641,-751,-316,-282,1000,212,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00169() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isExtended():boolean",
            new int[]{-716,-335,-244,-657,-1000,468,297,416,-447,869,284,-833,-728,1000,-498,335,1000,557,1000,-282,880,-356,-22,666,-853,-1000,-789,338,-1000,-412,-544,181,1000,-821,319,145,1000,-676,-84,833,128,-1000,-289,-273,-110,-423,234,-516,-808,-543,376,-1000,205,334,-1000,1000,257,-663,740,-10,-238,-1000,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00170() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isExtended():boolean",
            new int[]{-144,508,-89,689,-1000,-165,849,-267,-292,710,1000,-246,-241,660,-92,-1000,-354,1000,-1000,-1000,-841,-1000,-331,-984,1000,1000,-307,1000,1000,-503,-1000,1000,921,1000,1000,652,-1000,-264,409,164,249,1000,-853,-288,1000,-134,-556,-1000,1000,-171,-892,1000,-205,-1000,1000,349,352,1000,-111,727,407,1000,782,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00171() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isExtended():boolean",
            new int[]{-1000,-370,-1000,529,-1000,571,-41,1000,208,-292,-83,47,-119,1000,-54,173,1000,747,-558,23,-259,-1000,-629,-713,-932,-1000,-823,944,-553,-1000,-1000,865,-139,12,710,-145,1000,-1000,-24,45,-695,-1000,-39,-553,-973,-653,-1000,-914,666,1000,-1000,-942,-485,-1000,-829,-538,1000,509,-398,435,-666,-235,1000,-629}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00172() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isExtended():boolean",
            new int[]{-874,646,-705,794,-752,-770,381,379,-4,93,607,-147,-384,897,-847,-998,597,-234,-295,158,-930,-278,-712,545,-174,780,-652,717,742,2,45,197,-877,476,461,438,-246,-46,726,174,278,634,977,-623,-38,-513,455,-872,856,-597,97,-58,-108,-550,-487,341,559,-417,371,814,-528,-769,918,-318}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00173() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isExtended():boolean",
            new int[]{-144,62,-705,-315,280,442,-710,-267,-889,961,862,-587,847,794,366,726,1000,694,585,-633,1000,-824,970,-183,-263,-56,-230,-120,-1000,-416,-753,-297,921,1000,-879,1000,629,-163,-1000,-825,429,-658,-994,699,972,-134,701,-983,738,-234,37,-682,-672,1000,-896,349,352,-355,130,-39,-26,89,715,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00174() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isExtended():boolean",
            new int[]{1000,282,-865,1000,-480,-1000,689,149,1000,-477,-402,201,-1000,-247,1000,-1000,790,-15,-160,951,-1000,67,-1000,1000,-326,1000,487,1000,1000,1000,1000,816,-1000,11,1000,-1000,-53,655,1000,663,-87,667,1000,-1000,-948,1000,664,15,521,-1000,1000,-58,-730,-648,-487,196,1000,242,634,-418,-859,-1000,-906,-143}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00175() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isExtended():boolean",
            new int[]{1000,449,731,369,-1000,1000,358,1000,1000,127,675,1000,-165,-356,-737,214,-1000,-1000,-1000,-1000,1000,-314,-1000,-676,1000,-575,-424,-1000,-1000,-1000,-1000,453,-751,-363,-339,198,-445,-629,-530,-251,-263,90,-1000,409,152,-881,-1000,-1000,753,1000,-776,1000,886,-362,1000,111,-735,256,-1000,-919,-156,1000,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00176() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isExtended():boolean",
            new int[]{-1000,158,904,-554,1000,-874,778,-292,804,769,-974,-1000,-418,189,-1000,-1000,1000,-1000,1000,319,66,930,-1000,-261,-1000,48,-398,484,-434,834,368,-540,-307,-1000,188,205,167,43,428,644,12,-341,762,-1000,-1000,325,735,204,-1000,-1000,393,-1000,1000,-1000,-1000,1000,-147,-1000,600,906,108,-1000,-91,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00177() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isFIFO():boolean",
            new int[]{636,346,1000,1000,-1000,585,699,-523,1000,122,-200,265,1000,-1000,948,1000,720,-934,75,-31,-86,-1000,-304,-18,5,1000,-1000,95,-1000,-988,404,-46,993,-826,-496,-1000,-365,103,579,378,205,-482,1000,-86,-689,986,-503,894,-310,-1000,1000,1000,-696,1000,605,169,-193,225,1000,-1000,421,482,600,592}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00178() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isFIFO():boolean",
            new int[]{968,129,-541,446,-37,54,285,-784,-254,-524,-122,389,611,-370,-920,-82,-1000,-935,-481,81,-88,934,-717,785,-1000,-196,649,593,204,205,81,218,-143,-62,102,523,-70,-430,712,-360,-142,-141,-538,391,-50,-209,-381,-1000,183,661,276,-17,-274,-134,236,-126,-465,-121,-488,465,-676,316,890,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00179() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isFIFO():boolean",
            new int[]{-196,606,1000,797,195,1000,807,1000,299,-600,-1000,705,193,-587,1000,-673,548,-739,-88,-848,878,-778,-304,1000,1000,-145,157,488,-722,-1000,179,-836,194,-1000,-611,-1000,549,948,1000,1000,674,-969,769,645,400,537,-419,1000,826,-1000,601,201,-1000,1000,190,376,684,1000,512,400,382,1000,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00180() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isFIFO():boolean",
            new int[]{1000,445,599,744,-627,-1000,699,853,1000,243,966,-1000,558,-1000,788,-7,1000,-1000,257,-763,-1000,792,1000,-1000,-1000,1000,-1000,-74,-979,445,814,363,437,97,1000,-913,-571,117,-1000,352,-1000,-130,-674,88,-1000,1000,-1000,678,-284,-1000,629,163,-386,126,949,-202,351,-1000,98,-957,-154,31,-319,485}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00181() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isFIFO():boolean",
            new int[]{-58,-655,202,854,-15,-348,222,569,-237,505,723,-402,578,-490,-260,-501,-949,996,-805,-811,-130,982,700,-25,503,560,-464,-650,678,-893,-78,-5,-232,-405,-315,163,-642,-575,211,666,201,-354,189,88,547,-770,-960,-520,393,-873,194,846,-409,-737,-626,-24,938,306,941,-153,401,-880,-12,-282}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00182() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isFIFO():boolean",
            new int[]{-200,14,-1000,-549,-722,-1000,-394,446,309,112,1000,-136,739,-556,-1000,-970,1000,125,142,-1000,-1000,-1000,1000,-1000,-1000,1000,156,-297,131,45,1000,1000,238,267,1000,-477,-1000,-3,-1000,-1000,-651,734,211,216,-201,1000,753,558,1000,206,-58,-180,874,397,723,575,1000,-1000,370,-605,-283,656,234,-371}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00183() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isFIFO():boolean",
            new int[]{-135,-185,-945,-131,-758,-73,213,-714,-263,207,644,-1000,486,-16,-354,-795,-106,-874,-839,-877,-502,325,-1000,271,142,-222,173,284,-186,-157,-31,205,-1000,7,688,389,-442,-854,511,-614,68,613,-918,-215,-1000,-945,-292,331,524,381,612,-398,-448,-249,658,116,531,-579,-1000,-857,-759,1000,758,-849}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00184() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isFile():boolean",
            new int[]{1000,598,1000,903,-1000,-41,1000,958,-221,937,1000,292,581,1000,32,101,988,424,-1000,1000,-260,687,1000,-760,701,529,34,99,-109,-1000,1000,-833,120,1000,1000,563,402,-927,-41,405,-722,-1000,1000,-1000,-66,944,1000,148,-469,239,1000,-456,351,1000,-1000,-109,261,-613,-270,-958,120,-1000,-1000,374}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00185() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isFile():boolean",
            new int[]{-973,889,3,-719,1000,-668,-463,-44,-209,-485,-782,-796,1000,-891,631,-535,1000,1000,1000,-51,-1000,-1000,1000,1000,-1000,1000,1000,-416,-931,1000,-400,627,762,-628,350,171,1000,-472,1000,-1000,1000,-1000,-745,400,478,165,1000,329,882,1000,-1000,-1000,-283,-398,-1000,-218,-630,-278,1000,-204,268,808,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00186() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isFile():boolean",
            new int[]{-525,-129,458,-118,858,-1000,643,-502,479,-1000,-98,-443,-223,-1000,-116,203,1000,89,400,340,-613,-41,707,428,-840,859,-156,783,-48,496,902,484,-707,27,-1000,-829,-67,-671,1000,-823,-166,-979,984,608,1000,-42,676,-562,193,-798,-370,-844,-610,-1000,-1000,-518,-707,-376,148,98,879,635,-117,-513}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00187() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isFile():boolean",
            new int[]{870,-470,-791,163,-185,243,567,528,290,-262,-318,633,-45,-910,918,133,921,428,-845,833,959,-367,-385,281,887,585,-378,-533,-243,-699,961,-238,-1000,616,788,-119,-585,-312,745,-352,-856,926,-526,182,-896,872,-837,581,21,-316,313,-456,-581,158,-464,758,52,392,-1000,-647,-743,-583,-412,699}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00188() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isFile():boolean",
            new int[]{-1000,457,1000,-772,737,-809,-43,-601,-342,-1000,-162,-629,-482,-811,382,-874,293,809,1000,-845,-1000,710,702,371,-1000,1000,-269,682,-211,857,840,796,-689,471,-365,-118,802,368,1000,-211,446,-841,-404,-6,468,-842,1000,386,-1000,-707,-328,240,-768,-1000,-749,-443,447,531,721,725,636,-1000,-72,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00189() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isFile():boolean",
            new int[]{1000,423,-157,-671,803,-715,-1000,-273,103,48,488,-101,285,1000,987,-553,-1000,-943,899,-794,-62,678,-325,-643,-318,57,733,683,-350,480,-381,404,777,-960,-959,-691,-537,-1000,778,707,274,306,249,700,575,354,96,-73,-595,361,-151,-87,-1000,-358,-203,-692,-141,-658,478,-702,296,562,63,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00190() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isFile():boolean",
            new int[]{-627,742,1000,454,364,-778,-221,-417,-217,28,1000,-1000,171,1000,-37,-45,-157,-1000,1000,-141,-1000,841,-152,-747,-1000,1000,221,1000,-520,-940,-1000,-62,1000,-973,696,-85,803,-1000,984,234,1000,-1000,1000,1000,1000,-1000,-984,-1000,-63,1000,76,-1000,-796,-73,937,-1000,-194,-1000,1000,-541,1000,-587,1000,83}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00191() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isFile():boolean",
            new int[]{-127,-106,1000,163,-185,-507,222,-81,-151,-83,1000,408,369,1000,32,-207,-338,-287,-509,267,-611,1000,-1000,-948,-88,585,-28,1000,457,-710,387,110,-48,528,312,-35,-223,65,-351,977,-337,-967,1000,1000,470,190,-837,-9,-1000,332,1000,-456,-581,322,1000,-1000,80,-448,-270,-374,780,-90,925,-994}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00192() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isGNULongLinkEntry():boolean",
            new int[]{-998,63,-398,-269,-905,-772,-237,412,664,975,747,-181,89,127,-283,-360,-1000,-960,922,347,755,436,1000,-386,980,-232,1000,-23,-292,-1000,-185,723,554,312,679,-569,-1000,235,-63,217,1000,-462,-347,-1000,-798,216,834,-1000,-619,-262,-409,-701,914,854,-1000,-1000,-1000,-952,364,-734,-623,-440,-432,740}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00193() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isGNULongLinkEntry():boolean",
            new int[]{854,657,-1000,615,-624,1000,-466,592,318,-1000,1000,1000,-884,-1000,-1000,-686,-308,-1000,1000,-413,-5,649,1000,632,169,-1000,758,-9,-630,-77,-886,-1000,-754,985,1000,-696,1000,507,-1000,1000,-525,-450,1000,-140,-261,-469,956,-645,-525,-1000,-516,-25,-1000,-1000,-1000,-1000,-1000,-294,64,-1000,-1000,-1000,1000,-328}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00194() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isGNULongLinkEntry():boolean",
            new int[]{-196,470,-212,-166,298,-154,823,1000,117,183,-394,-576,1000,1000,1000,-760,254,1000,-343,-34,-427,343,-945,-1000,807,-332,-824,-558,-5,483,-986,810,-142,-856,-408,539,620,219,157,-426,-1000,-7,-57,-584,710,422,1000,633,-577,332,-279,137,680,-447,399,734,-697,353,503,1000,715,1000,-996,584}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00195() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isGNULongLinkEntry():boolean",
            new int[]{-794,-561,-851,-1000,592,759,1000,356,91,582,135,33,-107,138,264,367,230,416,849,-383,-758,348,-132,-467,423,-374,204,-147,151,634,-1000,1000,-840,1000,196,703,894,577,-994,-79,-408,389,740,-1000,-488,328,593,-296,690,219,-287,-117,-544,149,1000,787,34,50,-331,-251,116,233,-291,-68}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00196() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isGNULongLinkEntry():boolean",
            new int[]{-467,-150,-398,-269,-340,449,853,293,6,975,-325,-497,1,277,565,886,793,851,749,-125,-550,557,-726,-614,354,-32,46,-466,220,37,-999,466,-892,931,-338,-101,528,405,-783,-184,-731,862,951,4,-69,395,387,-341,336,513,-214,82,-75,14,824,-323,83,515,182,905,912,531,-432,-366}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00197() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isGNULongLinkEntry():boolean",
            new int[]{683,567,1000,706,-1000,-1000,37,1000,301,-67,-831,-1000,1000,1000,1000,-737,-1000,134,-1000,884,1000,446,1000,-1000,-781,741,-1000,-429,-635,-455,-647,1000,1000,-1000,-170,1000,-432,-400,1000,338,-367,-1000,-1000,-1000,1000,408,263,-121,350,671,565,-1000,173,-1000,-617,874,-990,-211,-490,964,1000,1000,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00198() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isGNULongLinkEntry():boolean",
            new int[]{-912,-346,-322,124,-117,-16,777,351,679,1000,-481,-407,532,452,418,274,255,680,1000,279,-157,645,1000,-730,1000,-686,647,-55,438,-876,-437,649,-71,690,-531,-85,-295,50,68,-180,653,590,365,-297,-201,854,942,-1000,488,213,-576,-376,395,435,-107,-813,-416,-772,412,-1000,-872,256,300,44}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00199() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isGNULongNameEntry():boolean",
            new int[]{1000,-505,-145,-1000,397,248,180,908,-538,-875,94,-26,-1000,1000,367,19,203,-134,-1000,-552,-89,597,486,-47,619,-1000,882,1000,-1000,921,-385,-991,-511,84,792,-225,-214,-140,256,205,676,197,1000,-8,-881,-917,-129,-1000,1000,517,-1000,1000,-1000,637,1000,14,374,-465,-384,-169,1000,-1000,-651,-94}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00200() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isGNULongNameEntry():boolean",
            new int[]{718,-863,427,-1000,1000,383,-1000,122,307,-1000,-751,585,156,653,360,-380,401,301,-1000,-1000,955,919,924,-872,-355,-828,1000,-981,-216,920,245,-655,42,442,1000,-904,-1000,189,20,328,1000,-1000,750,-536,926,-1000,-1000,-1000,849,668,-959,767,-1000,937,122,-652,589,823,599,-858,1000,182,597,181}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00201() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isGNULongNameEntry():boolean",
            new int[]{335,358,-257,-171,416,1000,619,-1000,-817,-711,491,-400,204,-369,422,-159,256,1000,543,123,271,1000,-422,-1000,821,-847,-493,-966,598,-566,470,1000,-10,-1000,-389,-1000,-621,639,1000,-462,31,62,-172,-679,1000,-1000,761,103,474,1000,672,-695,-857,-853,279,-1000,1000,969,-609,-1000,-276,632,-465,95}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00202() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isGNULongNameEntry():boolean",
            new int[]{-206,-274,-993,-833,1000,55,-1000,-815,624,475,456,207,255,-592,748,297,-103,135,-519,102,393,919,824,218,424,2,744,-1000,-1000,-454,82,85,42,1000,-346,-404,-50,-296,-735,-952,987,-196,-962,424,477,342,-380,-615,-330,-462,-808,767,-523,398,-1000,476,-99,225,-1000,-858,-131,964,-281,274}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00203() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isGNULongNameEntry():boolean",
            new int[]{228,775,152,645,114,-884,1000,91,-782,22,321,150,361,-598,788,901,-305,-359,537,934,468,-878,-464,861,1000,-940,-1000,617,1000,-570,339,772,-1000,127,-1000,106,-755,589,204,278,277,935,-519,-821,-1000,235,457,68,145,0,126,-510,-452,-957,411,-44,491,-296,-1000,-582,-905,-181,-552,885}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00204() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isGNULongNameEntry():boolean",
            new int[]{-126,-574,-310,-597,908,507,560,1000,-455,922,-286,276,-198,1000,-634,-345,-1000,-207,716,768,-104,-666,898,840,556,1000,564,1000,-920,350,35,1000,92,226,-350,111,539,27,-946,-1000,1000,358,-413,-124,-873,490,90,-259,-756,-400,-380,-407,1,-505,101,837,-565,-41,369,265,843,-453,835,-127}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00205() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isGNULongNameEntry():boolean",
            new int[]{863,117,703,629,1000,142,289,1000,-694,-934,-1000,1000,-16,929,813,424,-1000,-698,-104,-156,-362,-1000,919,135,280,-1000,410,1000,-1000,915,656,772,-246,173,1000,-1000,-200,-727,-58,-104,952,-1000,1000,-1000,448,123,-746,-679,506,87,-499,283,-1000,663,1000,-263,-8,289,1000,353,962,-1000,-331,-35}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00206() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isGNUSparse():boolean",
            new int[]{1000,-706,-1000,-466,-31,-217,-521,-203,243,619,700,709,65,1000,-345,325,-430,-569,97,629,1000,260,543,20,-556,-71,-346,-503,-1000,-497,338,465,670,855,590,366,888,-419,232,-1000,5,-502,272,206,-469,-45,-960,640,332,-146,1000,-853,-686,146,-487,-471,-718,-472,155,347,287,397,155,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00207() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isGNUSparse():boolean",
            new int[]{-156,-887,-482,-13,-418,-668,-119,1000,-1000,-401,762,806,-818,-3,-47,-50,374,-1000,611,327,466,-64,-115,-100,-339,1000,702,395,176,72,-625,209,-173,-308,1000,-1000,-212,-834,-575,86,-226,-625,815,-556,521,-91,-1000,-240,-808,178,-43,160,-335,1000,-34,-1000,-538,-677,-61,1000,-134,267,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00208() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isGNUSparse():boolean",
            new int[]{1000,-905,-722,-650,265,605,-495,-19,908,885,1000,776,533,1000,-206,-102,-49,-510,1000,995,1000,241,397,-1000,-435,81,890,342,-649,-400,-723,1000,644,1000,1000,-833,1000,-481,-321,257,257,-786,962,-1000,497,254,-645,501,-281,143,1000,154,-912,1000,-835,423,-900,-919,-406,1000,-1000,467,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00209() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isGNUSparse():boolean",
            new int[]{-507,-906,-1000,555,-594,-523,-1000,625,433,368,549,1000,-63,1000,-601,279,-275,-1000,999,659,1000,135,518,-408,-1000,-922,-301,-330,-693,817,1000,468,78,577,929,994,-374,1000,-364,-981,277,-524,505,-611,469,961,-909,-344,75,-782,848,-605,-280,592,-371,82,-1000,-818,-70,424,-349,-98,696,982}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00210() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isGNUSparse():boolean",
            new int[]{867,127,-858,995,-31,-502,-772,-625,-53,724,989,356,65,-160,-245,325,-468,-120,449,565,935,477,138,20,91,-252,667,56,80,-868,560,-990,-197,974,623,368,-234,9,-293,-342,5,-354,-58,-193,-910,-45,436,633,926,610,885,-635,-242,688,-144,-321,-816,183,600,569,287,-618,156,-417}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00211() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isGNUSparse():boolean",
            new int[]{1000,-726,-1000,211,-113,182,-977,760,-1000,-658,693,1000,-282,-499,-784,489,56,-1000,311,628,534,100,-722,276,-466,968,165,-370,-398,-51,-243,-77,-76,-126,438,879,-380,-530,100,-729,-641,-404,819,-264,497,-91,552,-365,-416,426,7,-514,379,1000,-294,-814,-526,-544,668,1000,424,1000,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00212() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isGNUSparse():boolean",
            new int[]{-514,-202,98,-780,-661,437,-635,-172,598,-962,-77,1000,953,5,-288,425,-164,-1000,358,640,-945,-435,-1000,-221,-983,1000,511,-48,371,887,-1000,337,255,-202,-203,-789,-628,403,-127,1000,-919,-160,1000,-1000,776,1000,-843,-585,305,102,-1000,187,38,674,84,91,-1000,-1000,-413,1000,-737,-109,1000,197}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00213() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isGNUSparse():boolean",
            new int[]{1000,-530,-381,786,-836,844,-817,-1000,635,-883,1000,1000,-144,-1000,-1000,593,-556,-509,507,577,-1000,-360,-1000,536,-546,1000,240,-616,-681,-568,-1000,-581,-201,593,-1000,-525,299,609,1000,838,-361,-201,1000,-1000,-465,350,513,-926,1000,856,-667,71,878,607,893,-557,-1000,-558,-39,1000,966,928,922,666}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00214() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isGlobalPaxHeader():boolean",
            new int[]{-1000,-666,476,-936,-410,-1000,-380,364,-641,-235,-628,-486,105,-400,1000,-195,878,1000,-81,1000,-149,-836,139,112,-602,208,-522,1000,1000,-777,281,-1000,1000,-943,588,676,225,545,692,400,1000,-589,1000,-211,734,-656,-654,277,-911,721,1000,-983,-229,193,-375,758,-1000,-902,1000,1000,-44,-584,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00215() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isGlobalPaxHeader():boolean",
            new int[]{-1000,-839,-793,-1000,-807,1000,1000,-1000,-95,443,940,-712,465,-414,-945,-891,1000,-17,72,-123,636,-978,472,1000,845,1000,849,1000,-149,86,-1000,-1000,620,-1000,1000,409,187,-712,692,-14,502,-1000,75,1000,734,1000,22,-81,-911,293,1000,-983,-458,-5,-1000,1000,-422,243,-1000,1000,-836,-1000,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00216() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isGlobalPaxHeader():boolean",
            new int[]{-1000,-578,-226,-1000,-106,-478,969,-672,-70,532,993,-50,545,134,-673,-364,158,-485,444,961,-146,147,-883,375,-456,576,-448,-643,154,1000,29,-742,-562,-1000,192,-787,-912,564,167,-218,338,-113,-38,-437,-659,-758,1000,-804,-315,222,-1000,-245,880,779,364,320,-654,-610,-974,-773,166,1000,962,927}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00217() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isGlobalPaxHeader():boolean",
            new int[]{-365,535,-500,-178,79,-146,562,-1000,-742,559,785,-161,1000,-238,-949,-721,-203,1000,220,945,212,91,-519,1000,219,863,-550,-989,-318,1000,-130,-965,368,-349,703,-826,-522,1000,1000,-429,566,477,135,-453,-811,-655,1000,-798,-113,-1000,-1000,-1000,445,746,79,132,-898,-664,-1000,-774,337,954,945,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00218() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isGlobalPaxHeader():boolean",
            new int[]{-365,-879,903,-546,79,-1000,-1000,-43,-896,-492,522,116,-138,423,1000,697,850,1000,15,1000,-808,-507,20,-45,-526,208,-608,929,-318,-1000,461,-1000,1000,93,181,813,-201,460,1000,49,891,477,975,-453,-184,-915,-78,633,-540,70,665,-1000,-1000,758,-181,544,-83,-1000,1000,931,337,-428,1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00219() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isGlobalPaxHeader():boolean",
            new int[]{-583,-514,-983,-610,379,1000,1000,236,-577,144,-1000,-558,247,-1000,176,-793,-1000,1000,63,-1000,311,-870,882,1000,1000,931,547,929,-199,-888,-820,-814,499,590,725,-135,1000,-299,58,989,691,-254,621,889,658,1000,-1000,-122,-631,-468,1000,-1000,-443,-134,-1000,1000,-657,840,-541,931,72,-1000,-1000,-965}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00220() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isGlobalPaxHeader():boolean",
            new int[]{15,650,-260,-304,801,1000,178,-708,-554,-158,332,387,591,477,936,248,-900,264,517,-503,-140,-270,-306,1000,561,1000,1000,660,175,-638,-425,-697,53,1000,396,-285,164,-1000,676,-312,150,699,-920,1000,-1000,772,82,-372,-472,-1000,-407,341,-794,997,-1000,367,975,1000,90,432,-412,-961,-157,-306}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00221() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isGlobalPaxHeader():boolean",
            new int[]{506,-650,470,636,-1000,-841,-406,-128,-396,-1000,795,-344,949,1000,532,-563,1000,265,-131,1000,-150,710,-308,-964,-557,-325,-1000,-71,194,-481,1000,400,135,371,-1000,440,-550,340,151,-897,-832,1000,367,-769,-880,-1000,-414,-640,444,-202,-1000,-756,-729,-235,751,47,-587,-987,619,-1000,782,905,1000,871}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00222() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isLink():boolean",
            new int[]{-118,758,-939,-307,226,-206,440,-313,-666,-235,269,955,164,432,-551,-53,441,568,-828,973,-673,891,-471,-42,614,174,-360,842,861,623,438,26,744,839,-722,905,672,156,-533,-644,-768,947,-531,334,-613,-373,78,-795,532,491,-837,-703,453,-701,718,-679,79,-457,-96,738,-529,-277,542,-40}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00223() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isLink():boolean",
            new int[]{-327,305,495,321,-39,-729,213,-964,149,152,-998,554,440,927,-484,-319,-787,-934,356,500,-666,-457,439,291,-405,309,-335,91,-990,-293,362,-349,-323,515,82,-797,592,776,188,-696,369,397,394,-750,-837,607,898,95,-732,798,-897,113,-165,26,-969,741,-65,488,493,-564,-177,-315,-167,738}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00224() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isLink():boolean",
            new int[]{-889,306,719,-651,-280,-402,1000,1,-307,175,-1000,1000,-1000,150,516,1000,459,-413,-1000,696,-1000,1000,-1000,-306,-259,810,1000,861,1000,409,123,-55,-137,1000,-1000,-1000,-177,343,302,585,-1000,52,-522,-509,1000,687,400,-893,629,-457,-345,137,-195,1000,450,1000,971,-172,535,-215,379,-700,911,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00225() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isLink():boolean",
            new int[]{45,630,-375,-45,247,-173,1000,-920,-431,252,223,692,-168,1000,-311,240,763,480,161,1000,-148,1000,-752,266,637,-285,-603,1000,1000,-410,-52,-876,1000,287,256,-451,1000,-567,-983,-722,667,-334,-729,1000,-332,-901,786,1000,1000,1000,-269,-269,-907,207,236,614,745,210,-42,951,-883,277,1000,321}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00226() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isLink():boolean",
            new int[]{97,-410,1000,-8,-673,275,-1000,-754,-431,-537,832,-261,663,-1000,1000,144,-1000,480,588,-367,114,279,59,1000,506,-259,202,841,-134,-223,-965,985,419,662,426,-1000,-1000,-339,1000,-777,484,584,220,-675,-669,25,786,915,-973,-92,-647,1000,-620,598,-167,1000,117,-426,-826,-1000,1000,-883,187,144}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00227() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isLink():boolean",
            new int[]{1000,709,1000,-349,-606,-805,1000,-248,-278,243,175,428,465,492,81,-176,-538,-1000,1000,605,950,-862,85,270,-1000,-309,-492,964,-126,-1000,-336,-985,-1000,-1000,1000,-1000,1000,364,-161,97,1000,636,-1000,451,-421,-1000,-199,1000,367,-117,342,416,-1000,1000,-342,1000,-97,657,-963,-94,935,-1000,1000,491}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00228() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isOldGNUSparse():boolean",
            new int[]{-567,750,701,-1000,182,-1000,-548,-786,849,-267,724,-877,-609,-725,160,-186,912,533,-589,-399,-1000,-1000,-682,879,449,44,602,1000,734,1000,-1000,266,-845,456,11,-1000,108,31,991,-299,355,-1000,-522,406,-1000,-908,393,-314,-369,-944,849,-1000,-907,107,-525,382,-1000,-1000,-347,1000,-126,-258,-1000,-765}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00229() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isOldGNUSparse():boolean",
            new int[]{1000,-959,-600,234,209,802,939,-1000,-679,331,60,-953,1000,731,-44,-52,-1000,543,680,1000,1000,862,496,203,-691,14,-1000,222,-394,-1000,-667,-1000,-935,-162,556,1000,417,-225,-41,548,-727,518,823,614,1000,-20,-57,605,36,-298,-258,962,-34,-355,400,-896,1000,1000,320,402,736,371,807,405}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00230() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isOldGNUSparse():boolean",
            new int[]{-635,-740,-137,225,110,94,750,-1000,1000,-1000,248,-530,-966,-220,-323,-1000,-545,-165,-736,-637,-325,330,723,41,-178,-1000,1000,739,-733,-281,50,381,-1000,1000,-966,297,-770,960,438,-542,361,293,878,942,-130,-897,801,-50,-1000,-525,1000,-1000,-891,967,-1000,1000,-1000,-20,684,40,1000,698,-492,842}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00231() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isOldGNUSparse():boolean",
            new int[]{-457,-662,674,-1000,522,-546,712,-1000,232,-35,153,528,220,107,403,65,-499,970,-281,-60,135,-443,-531,-108,-220,215,402,-643,263,410,824,-589,-203,203,154,-88,519,-423,689,191,-665,-650,878,124,-529,-404,2,627,-47,-1000,697,-6,-384,-356,-177,-784,-283,-1000,-443,712,809,1000,-523,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00232() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isOldGNUSparse():boolean",
            new int[]{1000,669,-559,-749,823,-774,-801,-1000,-226,901,-150,1000,1000,-1000,1000,-613,717,1000,1000,1000,914,-1000,-1000,-191,839,619,-960,-941,-86,1000,-278,-1000,-568,489,660,-1000,1000,427,917,1000,-1000,-857,337,1000,1000,-1000,-441,1000,688,1000,-371,-4,284,-1000,1000,-635,1000,-670,-994,1000,-721,-1000,971,-741}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00233() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isOldGNUSparse():boolean",
            new int[]{1000,262,146,-1000,-412,-884,-410,134,-153,669,489,1000,693,582,823,-255,962,723,1000,645,-81,-1000,-1000,226,777,574,628,-812,249,1000,-1000,-1000,697,-322,-4,-1000,1000,-1000,1000,1000,-1000,395,-715,-81,1000,-740,-141,455,864,1000,-931,-1000,843,-571,1000,-764,1000,-886,-610,1000,-1000,-552,1000,-357}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00234() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isOldGNUSparse():boolean",
            new int[]{1000,710,-578,-281,428,-102,-430,-342,261,216,74,-202,818,-1000,1000,-1000,756,4,-1000,336,-89,-483,-366,923,433,394,468,-196,361,647,-356,-1000,636,-720,-18,-195,886,-578,446,1000,-554,1000,-1000,-518,924,-919,-274,849,565,1000,289,-1000,-19,-490,52,-53,154,-958,262,653,-947,-388,239,-300}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00235() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isPaxGNUSparse():boolean",
            new int[]{-962,223,-1000,-421,-1000,158,1000,727,-853,-1,949,551,555,805,293,-69,291,-19,-435,131,-1000,718,-1000,145,-426,608,-40,-464,-541,832,744,129,939,-418,-1000,-42,-491,803,1000,839,-1000,169,166,-846,646,1000,640,-215,29,-839,562,971,1000,-298,-971,-422,-467,291,-152,-95,203,292,404,-787}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00236() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isPaxGNUSparse():boolean",
            new int[]{661,721,231,-303,1000,541,-70,-548,298,166,-383,171,-310,-664,543,108,644,-221,701,20,400,-509,763,1000,-750,-253,908,402,273,-756,-587,-347,671,-372,-545,-515,554,571,-779,-1000,669,-330,9,1000,-1000,-365,-1000,622,400,293,-19,-662,29,812,1000,-576,141,-136,-906,-168,-84,-757,290,288}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00237() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isPaxGNUSparse():boolean",
            new int[]{-580,182,758,575,-205,-25,-461,57,994,417,443,106,-567,905,-166,80,-74,-88,282,44,1000,607,630,706,-69,-197,1000,-538,871,-793,23,-434,469,454,-350,116,-783,808,195,-263,782,-941,-199,1000,-397,-866,-1000,399,-183,739,25,152,-1000,-152,684,-996,864,-176,-226,-297,-112,171,-611,-198}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00238() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isPaxGNUSparse():boolean",
            new int[]{-1000,-195,565,-533,-454,1000,-275,-482,940,-361,-648,-858,137,979,-709,1000,-404,384,1000,759,-719,-270,1000,471,188,-615,1000,-397,333,-683,-1000,-54,-701,-276,885,12,435,-230,-847,-1000,93,-346,716,695,423,-590,-452,327,-466,1000,-703,-1000,-1000,337,1000,-1000,-1000,261,452,-372,1000,544,-560,752}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00239() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isPaxGNUSparse():boolean",
            new int[]{-940,503,-779,490,-1000,469,766,569,-1000,-116,1000,1000,-124,855,-95,1000,270,-147,198,894,1000,-664,210,195,-846,682,1000,-90,458,595,1000,-1000,240,-383,-470,-561,453,917,1000,-740,-1000,-797,957,-236,1000,-493,-637,922,790,-1000,-484,844,1000,-737,301,-1000,-100,170,182,193,-760,-1000,259,-876}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00240() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isPaxGNUSparse():boolean",
            new int[]{-663,434,-315,186,-520,823,372,284,520,-687,773,60,-32,579,-582,108,706,489,947,883,-1000,254,726,795,141,-1000,-472,124,871,567,-165,-178,447,585,729,-1000,-250,4,1000,11,1000,-176,296,4,-753,202,327,-388,1000,-715,-25,-97,-527,-400,-1000,-341,-6,59,339,266,-493,-1000,-328,221}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00241() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isPaxHeader():boolean",
            new int[]{-1000,-66,-671,1000,534,1000,432,653,-544,180,-875,-699,399,-63,696,1000,-805,-672,-320,-786,-1000,-538,-351,-16,283,266,-326,400,933,124,406,145,278,-1000,488,296,986,-219,924,-1000,877,-929,-438,1000,1000,537,-116,1000,275,-676,321,230,-329,-497,-122,-809,-838,1000,-682,442,157,932,270,62}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00242() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isPaxHeader():boolean",
            new int[]{-469,-623,-213,252,-773,247,450,-1000,362,-652,844,-531,1000,1000,-1000,-1000,1000,-358,730,-1000,753,1000,-440,305,-1000,266,-497,-222,626,-362,765,-539,378,-899,12,-730,-648,-1000,1000,-146,1000,-91,-834,-1000,644,222,-487,429,672,107,622,342,-1000,-800,-412,600,-562,696,-288,237,1000,184,-340,-696}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00243() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isPaxHeader():boolean",
            new int[]{205,-722,-107,1000,604,-1000,369,-916,449,64,-215,-758,140,77,-36,961,2,-111,38,-413,630,-221,-850,1000,-595,-432,-362,-630,507,911,777,488,780,230,5,294,-111,-257,147,126,-1000,257,-504,-844,1000,480,573,1000,-384,-374,997,667,328,-569,166,-781,-491,-948,-1000,964,-263,-329,111,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00244() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isPaxHeader():boolean",
            new int[]{68,-203,-307,1000,48,-263,271,-1000,-4,-475,764,-1000,927,859,-1000,-600,568,692,47,-946,711,265,-440,1000,-589,369,-1000,-309,524,1000,1000,-214,289,-1000,12,-282,-424,-211,1000,-146,1000,-658,-680,-1000,1000,-68,-343,1000,303,-139,1000,342,-615,-1000,289,-167,-600,696,-1000,1000,945,500,67,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00245() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isPaxHeader():boolean",
            new int[]{-1000,106,-980,400,344,-387,-351,441,1000,-273,-1000,-76,-33,-2,597,761,-315,-348,-496,-24,-309,329,407,-231,-181,-1000,-719,470,514,-44,638,-292,-1000,-1000,-598,-55,539,54,37,-1000,486,-690,-1000,1000,530,769,320,196,399,-1000,-298,1000,1000,564,-144,1000,-89,435,-263,319,-525,-543,368,707}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00246() {
        org.junit.Assert.assertEquals("java.lang.Boolean:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isPaxHeader():boolean",
            new int[]{491,527,-269,266,1000,889,-158,-203,1000,-393,733,-974,708,280,-786,103,721,1000,213,-1000,-120,-517,-1000,-1000,-552,710,-781,749,-111,1000,-295,-502,736,-781,617,-800,748,-277,1000,-418,-862,-1000,354,-74,781,-521,507,1000,23,-398,257,840,841,-1000,-130,-1000,-832,-177,-665,1000,-92,-819,127,371}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00247() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isPaxHeader():boolean",
            new int[]{371,127,-1000,198,1000,905,-1000,276,-14,-16,284,-1000,672,341,180,618,-205,419,-702,-983,-1000,-299,-94,-400,-209,-976,-985,1000,267,1000,706,-1000,-460,-679,11,-32,1000,-838,644,-798,-269,-1000,450,188,648,-558,1000,-29,-1000,-1000,-733,10,1000,-1000,478,-1000,-1000,-1000,-1000,1000,422,687,651,805}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00248() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isSparse():boolean",
            new int[]{-653,629,-562,-146,434,374,475,-834,-235,797,-280,121,-1000,27,-562,132,521,-374,590,865,879,175,-1000,-532,-203,817,-767,-877,-1000,487,87,264,747,1000,-1000,-430,101,739,-641,292,-635,443,950,82,-684,-806,-524,-42,-1000,-921,-316,-1000,1000,-958,1000,128,-886,-259,-839,-242,780,116,-420,-239}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00249() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isSparse():boolean",
            new int[]{361,-679,414,-964,-399,-19,330,291,-530,-511,248,-510,779,-358,493,500,143,472,-86,875,-56,774,711,633,952,-99,-337,800,-1000,940,94,-459,-346,-643,210,54,-734,-90,415,147,1000,-872,-76,-434,38,-545,-211,148,-994,-192,-82,-222,-30,-562,-975,-343,522,660,251,807,-827,-306,48,787}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00250() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isSparse():boolean",
            new int[]{684,183,645,-522,-224,-331,1000,182,-490,-696,940,-863,466,298,594,552,631,947,-795,658,81,443,578,-1000,772,-130,5,562,-674,-822,-182,-42,-980,-743,939,649,-233,-1000,1000,692,1000,-389,-644,-421,476,-931,938,594,-27,738,623,632,-718,-839,406,816,1000,999,188,354,-211,-1000,437,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00251() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isSparse():boolean",
            new int[]{104,6,1000,-826,-1000,300,868,602,544,631,74,48,654,1000,606,306,429,809,-659,1000,-1000,1000,-1000,45,-488,-1000,-211,-357,625,-614,-1000,-925,630,-1000,730,602,-19,94,-164,254,1000,856,-606,744,1000,-633,1000,-236,-639,-553,496,1000,-192,-645,1000,714,-34,104,-265,1000,-1000,-353,454,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00252() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isSparse():boolean",
            new int[]{1000,142,19,-1000,-1000,-19,763,638,-683,-800,1000,-1000,785,624,1000,-621,289,874,-609,1000,-62,1000,372,798,379,-1000,410,1000,1000,-698,1000,1000,-1000,1000,627,1000,-1000,-1000,1000,-653,-987,-1000,-868,-1000,1000,-89,741,985,-1000,688,1000,193,484,457,1000,479,1000,1000,-163,1000,-1000,-1000,441,-131}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00253() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isSparse():boolean",
            new int[]{34,7,1000,-752,194,96,830,-870,669,889,-322,472,74,422,424,-332,324,335,171,755,-343,1000,1000,753,-922,-353,-580,803,-649,-797,-788,1000,-1000,-374,178,703,167,170,-452,-86,-887,-683,-463,737,1000,-165,717,-84,-180,206,-683,321,310,102,-1000,-17,-381,-821,-1000,993,-1000,-490,614,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00254() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isSparse():boolean",
            new int[]{-33,394,-701,-471,4,299,-626,-1000,83,-382,-113,-573,-443,319,844,-982,-646,-277,1000,905,935,91,-623,-867,452,-1000,228,303,-1000,539,378,-115,888,1000,-942,-102,-1000,817,337,705,-586,-764,1000,-589,-633,-33,-67,-808,-1000,-1000,-1000,-784,1000,-712,400,-1000,259,-110,-46,131,246,-1000,614,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00255() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isStarSparse():boolean",
            new int[]{60,222,-491,-1000,749,116,668,-22,-426,255,405,311,59,-95,-373,445,-542,-241,-247,104,400,-267,-806,-264,636,-86,-111,-575,-401,-171,20,243,1000,114,-396,129,286,-20,92,-840,-120,-176,-342,-680,133,-1000,-348,857,-181,779,66,194,398,-152,192,22,-520,404,-338,404,971,752,1000,396}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00256() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isStarSparse():boolean",
            new int[]{-123,497,182,460,244,-767,-255,-1000,-714,543,852,-151,856,-578,-37,166,-292,-1000,-809,-414,485,559,435,113,393,1000,191,295,603,-25,-265,768,115,-751,-1000,-92,279,839,-492,-132,278,466,-1000,-984,-917,433,354,-331,864,-46,53,-410,268,-265,-435,199,-715,279,1000,-310,15,-220,759,501}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00257() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isStarSparse():boolean",
            new int[]{-501,970,175,-180,55,891,-583,326,-988,976,63,534,712,426,-915,-361,2,-991,-223,948,-410,691,834,775,362,-599,-644,372,17,-667,628,969,-274,-471,877,-460,-543,779,190,587,25,377,-756,928,31,692,-427,241,372,-898,732,-64,231,-561,900,855,123,752,214,201,-106,-40,450,167}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00258() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isStarSparse():boolean",
            new int[]{420,-169,138,168,-515,-300,133,592,-842,885,608,119,673,869,188,360,-611,-324,410,-606,-870,-700,-188,-859,289,-267,-24,212,964,-552,-726,728,810,-522,-492,-812,146,626,-485,-904,350,712,359,783,-397,-682,755,-401,648,972,-963,-495,362,377,-868,979,704,925,783,100,832,503,571,-303}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00259() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isStarSparse():boolean",
            new int[]{673,-786,-201,1000,655,-1000,411,-746,822,50,-183,-967,1000,-456,128,-784,-446,16,81,-677,-1000,-234,1000,758,-989,-1000,-270,788,175,1000,408,-1000,-278,-81,-171,-196,8,-400,485,1000,59,-600,-701,-824,238,337,519,-460,657,1000,171,-56,542,348,-65,-4,-28,477,55,-148,-876,-306,1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00260() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isStarSparse():boolean",
            new int[]{468,-231,858,-682,-804,1000,-1000,1000,-605,-401,740,695,-1000,678,-43,927,207,-324,-537,1000,996,1000,-188,-1000,289,-719,-631,418,964,503,-176,-27,2,1000,278,-812,146,626,-594,-993,226,1000,631,396,-765,326,-1000,704,-50,966,456,495,666,-523,-818,983,-497,89,-463,1000,9,518,98,-757}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00261() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isStarSparse():boolean",
            new int[]{615,-762,-434,316,548,482,781,-48,916,-168,-226,1000,-794,704,-419,114,716,11,711,155,-294,-223,1000,384,215,-418,411,-709,889,-621,-143,1000,137,32,644,160,-716,-498,241,-323,309,-178,892,-304,952,-983,-574,439,290,-1000,-1000,77,-270,301,-244,-76,-306,443,-104,-615,868,851,-1000,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00262() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isSymbolicLink():boolean",
            new int[]{-434,414,1000,558,-1000,1000,-1000,610,-111,686,40,-300,921,378,-315,-341,-14,870,-72,-1000,1000,-43,285,-427,83,96,-1000,-942,302,312,-1000,591,311,-901,-728,481,-220,1000,108,1000,1000,-734,427,-819,1000,1000,-79,655,-1000,865,89,-569,269,37,862,1000,381,755,1000,-181,-587,-992,-538,-838}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00263() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isSymbolicLink():boolean",
            new int[]{431,-311,558,636,56,1000,209,-619,345,-687,-69,-272,-956,266,-1000,1000,-1000,517,150,-491,-221,72,-269,1000,-558,-1000,860,1000,681,-1000,1000,-602,-1000,180,-44,-757,-581,-44,-1000,270,-3,-841,1000,-610,440,417,1000,1000,-509,520,62,-148,246,-409,1000,-722,-1000,-1000,106,-233,-286,774,733,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00264() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isSymbolicLink():boolean",
            new int[]{-138,-118,369,401,-695,129,81,-265,424,812,283,-937,-517,-403,-1000,1000,-1000,-166,1000,-1000,66,558,-123,1000,-198,-529,-1000,713,474,-1000,47,-1000,-92,-741,-364,-463,-402,1000,-796,645,1000,132,1000,-1000,1000,764,1000,1000,-910,142,-525,-276,400,-395,1000,-67,-1000,-1000,375,-677,-828,-620,480,-628}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00265() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isSymbolicLink():boolean",
            new int[]{-684,274,453,1000,-341,1000,-271,49,1000,-120,-866,608,-612,-44,454,-403,-379,1000,-512,-1000,1000,1000,-1000,1000,7,761,-118,-508,-437,680,-1000,1000,129,-818,-666,777,-1000,878,-270,218,334,-251,865,-445,792,1000,933,512,-1000,-29,734,814,-756,197,354,-880,351,1000,630,-1000,-1000,354,1000,-230}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00266() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isSymbolicLink():boolean",
            new int[]{-486,382,431,-41,-806,1000,-760,383,-21,992,-568,375,663,550,55,-1000,-658,-691,-1000,-522,-907,1000,98,98,-471,995,-841,-779,-889,309,-1000,298,36,-1000,-691,525,-1000,1000,-643,384,358,-94,315,-847,1000,1000,247,368,-899,-674,814,-118,-683,-320,548,204,-54,1000,770,-512,-645,-400,862,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00267() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isSymbolicLink():boolean",
            new int[]{-758,545,782,1000,-787,888,81,-850,808,812,-603,694,-1000,1000,-1000,66,-1000,384,92,-599,-308,1000,-1000,1000,-836,856,225,-336,18,-1000,-798,748,-1000,-1000,-1000,258,-402,1000,-1000,457,-33,-1000,1000,-748,1000,1000,1000,1000,-910,-411,1000,-167,-341,-497,1000,-67,-1000,-112,1000,-1000,-1000,476,1000,-111}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00268() {
        org.junit.Assert.assertEquals("java.lang.Boolean:ZmFsc2U=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "isSymbolicLink():boolean",
            new int[]{187,39,602,327,-22,360,-380,-656,34,-561,-665,646,-130,933,-1000,176,-795,149,465,-157,-903,381,-1000,1000,-749,-121,971,73,-273,-1000,298,307,-1000,-1,-272,-65,-1000,-44,-659,87,-452,-1000,553,-503,440,582,1000,957,-501,-51,1000,-37,-511,-356,1000,-532,-1000,-493,383,-117,-158,929,1000,750}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00269() {
        org.junit.Assert.assertEquals("THROW:java.lang.ArrayIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "parseTarHeader(byte[]):void",
            new int[]{761,654,469,-608,280,268,-241,-239,642,-603,1000,1000,683,1000,-549,1000,616,85,-125,568,345,-596,356,960,-816,145,501,1000,76,-359,-389,652,-731,-910,-1000,117,860,-473,-467,155,-644,-1000,-295,-1000,-362,-1000,-803,857,25,361,-754,-1000,371,-137,-12,-217,288,112,-316,-1000,1000,-170,-1000,428}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00270() {
        org.junit.Assert.assertEquals("THROW:java.lang.ArrayIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "parseTarHeader(byte[]):void",
            new int[]{-714,273,-150,99,72,1000,-542,-465,-103,-566,-400,1000,-37,-198,1000,273,-463,-383,694,41,266,301,-552,-747,-187,-285,-782,1000,-570,-1000,-1000,-214,955,-629,490,919,221,-104,553,-1000,-166,-1000,1000,838,202,246,808,30,-273,125,383,63,1000,548,673,-1000,1000,-1000,155,-1000,10,-652,-632,565}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00271() {
        org.junit.Assert.assertEquals("THROW:java.lang.ArrayIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "parseTarHeader(byte[]):void",
            new int[]{400,938,1000,-1000,44,1000,-191,1000,-152,-904,931,178,-226,-649,434,460,-158,934,105,1000,444,121,-844,552,-181,1000,342,748,110,94,-52,303,1000,-577,100,428,687,59,-189,-882,438,194,169,-271,-368,-337,781,509,458,674,402,785,452,779,831,1000,804,-169,-165,-1000,-1000,815,576,-400}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00272() {
        org.junit.Assert.assertEquals("THROW:java.lang.ArrayIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "parseTarHeader(byte[]):void",
            new int[]{963,972,-297,510,595,-88,1000,461,-736,-373,1000,328,-25,-44,77,-292,30,-174,629,399,602,-123,-897,533,-337,-73,-1000,775,456,-523,-243,227,-856,152,-1000,237,900,-78,90,-486,-451,-840,-754,-1000,170,-1000,365,27,-188,79,-880,-403,766,325,93,-69,115,-221,324,-324,1000,-531,-684,-601}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00273() {
        org.junit.Assert.assertEquals("THROW:java.lang.ArrayIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "parseTarHeader(byte[]):void",
            new int[]{144,374,-327,366,-5,-186,-409,-493,-811,-432,-620,-812,-888,-107,774,-87,-439,-982,913,1000,-703,230,-530,812,-522,-853,-266,614,-96,-973,151,-820,-122,-1000,-706,610,1000,425,1000,-482,406,-465,-782,393,67,-176,972,227,-202,2,-680,-168,1000,797,806,-151,66,190,97,15,-1000,269,-341,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00274() {
        org.junit.Assert.assertEquals("THROW:java.lang.ArrayIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "parseTarHeader(byte[]):void",
            new int[]{516,253,-1000,-299,39,884,1000,557,849,250,755,86,339,86,-1000,-819,1000,1000,-212,33,46,-1000,853,-482,-1,-784,-198,812,-494,909,-170,1000,-1000,-527,-860,-905,-13,-950,-420,1000,-1000,-1000,-603,-639,-1000,-1000,685,-996,91,-105,-319,-257,-1000,-821,235,-501,394,-91,-1000,-287,919,1000,-256,-651}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00275() {
        org.junit.Assert.assertEquals("THROW:java.lang.ArrayIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "parseTarHeader(byte[]):void",
            new int[]{400,-714,-1000,1000,-18,148,1000,15,-728,12,-309,-888,-27,-1000,407,-1000,-409,-1000,527,-596,-635,-22,-689,-1000,-300,-267,218,-210,640,-1000,696,303,263,1000,-397,475,234,-79,472,-400,-1000,-635,-1000,154,1000,-337,-550,-936,182,-1000,-966,343,-994,155,-654,-791,430,54,6,1000,-986,-684,576,372}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00276() {
        org.junit.Assert.assertEquals("THROW:java.lang.ArrayIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "parseTarHeader(byte[]):void",
            new int[]{-1000,-753,-220,609,216,663,1000,1000,-656,1000,-827,-1000,270,-1000,296,901,-448,183,672,770,-64,-1000,-1000,-952,788,1000,-1000,-653,358,-943,507,-742,124,792,1000,194,-131,649,604,1000,578,315,46,1000,402,1000,-860,328,327,22,316,1000,-86,-113,405,311,136,520,722,616,-773,-1000,1000,-439}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00277() {
        org.junit.Assert.assertEquals("THROW:java.lang.ArrayIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "parseTarHeader(byte[],org.apache.commons.compress.archivers.zip.ZipEncoding):void",
            new int[]{-971,23,428,1000,-1000,967,672,-612,-843,-72,-303,-1000,-1000,-885,159,1000,-970,-868,-279,-966,-1000,-1000,1000,-1000,1000,19,205,-601,-747,-123,864,-258,-830,678,-1000,-745,530,797,220,454,386,-400,-1000,-954,371,1000,976,1000,-417,-573,949,1000,-1000,-858,-714,664,873,-574,831,1000,406,474,-886,-352}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00278() {
        org.junit.Assert.assertEquals("THROW:java.lang.ArrayIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "parseTarHeader(byte[],org.apache.commons.compress.archivers.zip.ZipEncoding):void",
            new int[]{-996,817,-29,-671,-863,-935,-207,849,-595,376,344,-553,-257,656,734,-621,1000,36,-819,-114,1000,494,347,608,1000,820,-502,-144,1000,-1000,-170,-1000,541,925,399,1000,-42,751,-73,-90,64,615,55,310,-83,-207,749,997,-507,-592,-1000,-385,178,1000,-256,508,740,130,-181,398,-482,253,-945,-392}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00279() {
        org.junit.Assert.assertEquals("THROW:java.lang.ArrayIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "parseTarHeader(byte[],org.apache.commons.compress.archivers.zip.ZipEncoding):void",
            new int[]{-1000,-361,1000,487,-1000,-51,501,1000,580,609,-336,-1000,-272,380,-353,395,-151,-818,-1000,-163,1000,-85,1000,198,511,152,-317,-837,380,-556,-272,-1000,158,1000,106,1000,-242,713,-19,-277,156,1000,-169,-466,559,-221,758,218,-1000,419,-1000,-93,-548,1000,773,-33,721,-30,-1000,579,874,466,-825,767}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00280() {
        org.junit.Assert.assertEquals("THROW:java.lang.ArrayIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "parseTarHeader(byte[],org.apache.commons.compress.archivers.zip.ZipEncoding):void",
            new int[]{-442,-444,-1000,901,-297,-1000,931,1000,1000,1000,-356,704,-22,-270,-514,-713,-370,-89,-895,305,770,281,-218,-1000,381,-216,1000,723,711,-920,-214,-779,29,-594,307,685,470,-683,-1000,-638,-518,-1000,400,-716,-846,-1000,-1000,99,-1000,610,-616,293,105,1000,1000,-432,84,-1000,-583,56,-145,511,201,-189}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00281() {
        org.junit.Assert.assertEquals("THROW:java.lang.ArrayIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "parseTarHeader(byte[],org.apache.commons.compress.archivers.zip.ZipEncoding):void",
            new int[]{-1000,-774,831,1000,-204,331,981,812,175,12,-1000,-863,-506,-396,458,156,-1000,-400,-400,-311,44,-711,219,-452,-586,-866,945,54,-430,-440,215,-329,-555,855,-198,962,71,283,-113,-357,-703,251,10,-1000,214,-63,618,472,-1000,974,868,218,-701,42,155,-746,400,-322,400,685,94,1000,-1000,400}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00282() {
        org.junit.Assert.assertEquals("THROW:java.lang.ArrayIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "parseTarHeader(byte[],org.apache.commons.compress.archivers.zip.ZipEncoding):void",
            new int[]{304,-250,877,-334,-710,1000,-1000,-600,-66,-179,277,554,-1000,-248,962,-617,-1000,235,-18,1000,844,-1000,-982,1000,-1000,-1000,-1000,-527,687,-439,1000,1000,-292,183,-1000,-282,1000,1000,-596,872,821,1000,-1000,652,72,-1000,1000,1000,21,94,-261,1000,669,-230,1000,808,-1000,907,346,1000,939,257,-151,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00283() {
        org.junit.Assert.assertEquals("THROW:java.lang.ArrayIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "parseTarHeader(byte[],org.apache.commons.compress.archivers.zip.ZipEncoding):void",
            new int[]{704,-59,815,-904,-816,-377,164,106,718,221,762,-1000,80,461,507,341,1000,-190,-750,-1000,321,173,-71,327,-669,942,358,-444,-359,-1000,-791,-666,371,663,1000,1000,-1000,1000,93,-312,981,822,-350,-144,638,231,-30,-741,452,-194,-17,261,-1000,-323,-170,-760,1000,314,1000,-324,44,23,806,867}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00284() {
        org.junit.Assert.assertEquals("VOID|getDevMajor=java.lang.Integer:MjE0NzQ4MzY0Nw==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setDevMajor(int):void",
            new int[]{320,-266,1000,145,1000,206,-571,-36,144,-972,998,809,228,-219,-168,-740,477,-523,430,1000,563,-511,-455,-213,923,-783,-52,1000,189,-38,-522,1000,-757,714,-1000,118,-632,437,-444,-1000,-1000,-1000,821,516,-162,-680,961,-31,-1000,-622,-333,-64,-396,1000,-498,258,357,-709,-1000,670,189,-821,460,-21}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00285() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setDevMajor(int):void",
            new int[]{-35,569,1000,277,644,479,-627,-522,-180,1000,-128,-181,687,239,-1000,-224,1000,1000,406,1000,-440,-1000,90,318,405,1000,746,1000,853,-57,-437,1000,-897,860,-1000,-1000,614,247,647,56,-1000,-898,1000,-1000,-644,-1000,-1000,239,1000,-131,556,-1000,-900,1000,-801,-316,314,-280,-993,1000,-623,-172,-477,44}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00286() {
        org.junit.Assert.assertEquals("VOID|getDevMajor=java.lang.Integer:MjE0NzQ4MzY0Nw==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setDevMajor(int):void",
            new int[]{754,306,657,-293,18,-582,-998,-827,-18,827,-535,188,962,1000,193,1000,-1000,151,-532,1000,-426,-890,137,-295,-133,1000,822,1000,52,-1000,535,1000,-636,129,-653,1000,1000,317,1000,-1000,-1000,-1000,718,492,895,-180,-375,1000,430,1000,529,489,919,855,728,-1000,808,823,-222,95,-204,220,-341,111}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00287() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setDevMajor(int):void",
            new int[]{-260,830,119,-246,1000,-1000,-587,992,1,846,-91,-346,9,1000,1000,-305,-858,-31,-367,1000,263,-1000,-516,-438,-714,1000,1000,1000,-1000,-750,1000,1000,996,1000,-738,1000,1000,836,1000,-1000,-1000,-1000,1000,383,1000,-951,-461,82,-1000,514,-111,699,135,414,1000,80,33,-38,-519,732,95,-654,-258,501}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00288() {
        org.junit.Assert.assertEquals("VOID|getDevMajor=java.lang.Integer:MjE0NzQ4MzY0Nw==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setDevMajor(int):void",
            new int[]{-761,95,-756,989,-630,874,242,-234,-1000,563,-601,-286,-260,31,-63,420,-111,-16,287,366,128,-12,-448,-353,-220,179,-62,850,-271,-561,-324,-1000,-638,-40,1000,-794,230,372,311,-967,-388,200,756,-463,66,-187,-806,-650,964,225,141,662,10,-131,-156,-259,-1000,-392,527,670,-228,695,279,326}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00289() {
        org.junit.Assert.assertEquals("VOID|getDevMajor=java.lang.Integer:MjE0NzQ4MzY0Nw==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setDevMajor(int):void",
            new int[]{-966,737,-877,657,1000,650,-954,491,-261,-1000,1000,-859,915,856,754,1000,-222,-67,-274,407,1000,-1000,-1000,301,-1,1000,-214,1000,-367,-334,-101,642,-1000,1000,423,823,1000,571,-470,-1000,-1000,-954,1000,-172,1000,-459,-1000,852,-899,-962,783,-814,1000,-599,493,-631,190,-835,-45,72,1000,-277,-450,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00290() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setDevMajor(int):void",
            new int[]{-816,390,-491,271,-290,694,-170,103,-577,-389,773,-324,-140,390,425,628,-63,54,-243,702,1000,-980,-831,-640,-736,221,1000,1000,189,-211,216,-729,-1000,332,1000,-274,660,799,-393,-1000,-496,-948,1000,-39,-162,-910,-409,717,395,-960,501,-900,175,-536,172,-663,72,-786,539,400,756,-196,-1,663}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00291() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setDevMinor(int):void",
            new int[]{250,598,-307,953,-666,-105,635,143,512,808,376,277,-129,154,188,1000,-33,-142,398,-536,-79,469,215,-43,-324,294,-480,-1000,254,23,-553,275,742,-98,-85,-336,-391,-178,-526,1000,494,694,1000,594,-438,-421,968,-507,-1000,1000,432,400,1000,34,197,-803,525,-402,-223,67,1000,505,-527,803}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00292() {
        org.junit.Assert.assertEquals("VOID|getDevMinor=java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setDevMinor(int):void",
            new int[]{-120,-599,-904,-457,-961,-902,309,-955,880,-443,259,-987,905,-847,26,-1000,701,1000,-1000,-1000,-1000,1000,-354,-606,-487,1000,333,-15,774,535,-1000,1000,180,-516,1000,1000,1000,223,454,1000,1000,1000,-455,-766,-365,197,1000,-1000,-418,1000,-862,-1000,-93,1000,-1000,-1000,421,312,-833,-1000,-1000,1000,-1000,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00293() {
        org.junit.Assert.assertEquals("VOID|getDevMinor=java.lang.Integer:NTMz", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setDevMinor(int):void",
            new int[]{-469,748,284,520,-233,-428,-593,-59,262,-24,3,214,-116,1000,-729,-772,-3,1000,-688,-794,-1000,-128,-88,-996,533,779,-33,618,678,1000,-614,1000,-492,-84,784,1000,-177,160,-286,272,825,408,-820,-902,-667,788,935,-1000,-460,1000,-168,-1000,286,965,-1000,-1000,567,-963,702,-909,-733,585,-592,704}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00294() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setDevMinor(int):void",
            new int[]{-329,717,291,1000,-1000,-1000,-372,-233,1000,-64,446,-212,282,74,-691,-1000,446,861,424,-252,-947,827,-1000,-248,-261,219,-69,88,-510,908,373,116,-1000,-542,1000,206,-109,-31,-1000,-1000,-197,147,122,900,18,488,-529,-1000,58,428,-966,-235,-131,1000,-1000,103,1000,663,-651,-498,-77,1000,301,-49}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00295() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setDevMinor(int):void",
            new int[]{-1000,282,685,-410,-1000,-1000,419,896,774,216,555,-683,-1000,661,669,608,-292,533,177,-846,-1000,1000,687,-1000,1000,993,-170,1000,350,809,-1000,1000,-443,-375,967,909,-1000,1000,-716,-257,1000,577,142,-1000,-1000,-188,1000,-1000,-1000,1000,-270,-1000,789,804,-1000,-788,510,684,474,-1000,-209,734,-168,994}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00296() {
        org.junit.Assert.assertEquals("VOID|getGroupId=java.lang.Integer:MjE0NzQ4MzY0Nw==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setGroupId(int):void",
            new int[]{2,-650,23,-573,-375,-126,1000,-856,-1000,1000,620,-926,-696,188,-885,1000,-663,235,367,226,-1000,-746,-395,843,842,-1000,1000,1000,-1000,-1000,-399,181,-526,-1000,-1000,-1000,1000,-1000,1000,801,1000,-1000,-207,-1000,1000,-1000,380,776,-557,-248,1000,-407,920,323,1000,-1000,-620,1000,-241,405,516,1000,714,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00297() {
        org.junit.Assert.assertEquals("VOID|getGroupId=java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setGroupId(int):void",
            new int[]{-1000,-47,459,-468,-1000,1000,1000,-1000,-1000,1000,214,109,80,1000,-1000,1000,-1000,-707,-367,-71,-970,36,-675,1000,479,-331,93,1000,-665,438,-1000,1000,-913,601,-1000,-859,987,-1000,-216,448,846,-1000,-274,-1000,1000,-1000,-569,-775,-1000,613,168,-1000,122,513,1000,-1000,1000,1000,-445,768,-133,1000,-1000,575}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00298() {
        org.junit.Assert.assertEquals("VOID|getGroupId=java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setGroupId(int):void",
            new int[]{-1000,-33,78,883,-1000,-807,-438,1000,-3,-921,1000,-852,-505,116,41,514,-821,-1000,-1000,858,-1000,-521,364,-28,-24,-699,1000,64,-1000,1000,-992,906,-577,794,358,11,1000,-15,-740,-177,-299,-197,-103,-1000,13,-107,599,-980,312,289,-192,-477,863,200,-629,-24,1000,397,-1000,-513,58,-685,675,926}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00299() {
        org.junit.Assert.assertEquals("VOID|getGroupId=java.lang.Integer:MjE0NzQ4MzY0Nw==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setGroupId(int):void",
            new int[]{502,188,559,-882,284,487,1000,-946,348,-198,-1000,-337,-1000,19,1000,-300,-183,-1000,-400,786,400,349,-1000,-765,914,-312,-1000,-1000,1000,645,-640,50,92,-447,-555,226,1000,-1000,-1000,1000,-653,1000,-241,587,497,1000,-377,-141,-445,-1000,-61,95,1000,688,-212,-15,-879,-46,74,-503,1000,980,665,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00300() {
        org.junit.Assert.assertEquals("VOID|getGroupId=java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setGroupId(int):void",
            new int[]{444,686,78,191,186,-1000,-438,278,-417,108,458,-852,-505,-677,300,514,606,765,953,-1000,-1000,-521,498,-352,313,-1000,1000,-118,-141,-1000,613,-461,-323,-832,1000,-934,437,-198,178,355,622,-319,-38,-657,244,215,599,345,74,26,-563,-187,473,-69,675,-21,-394,-752,84,-37,-76,-38,957,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00301() {
        org.junit.Assert.assertEquals("VOID|getGroupId=java.lang.Integer:LTIxNDc0ODM2NDg=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setGroupId(int):void",
            new int[]{-503,570,-248,188,-602,22,-541,179,81,-1000,977,-676,43,160,-283,-196,70,-1000,-403,346,71,1000,1000,247,357,-181,93,-263,-128,913,-480,-340,-439,719,407,378,-636,271,-67,791,-73,-756,163,668,-414,-195,-440,-869,697,-344,8,-38,-1000,-198,-546,194,940,400,-317,-580,-379,-1000,204,922}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00302() {
        org.junit.Assert.assertEquals("VOID|getGroupId=java.lang.Integer:MQ==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setGroupId(int):void",
            new int[]{-1000,854,758,262,361,-692,221,-1000,-472,1000,400,-257,329,126,-331,695,-783,-867,565,-201,-1000,977,-475,20,-386,87,-1000,627,-1000,-394,41,55,-865,15,448,-216,-485,140,1000,-440,-29,-1000,715,-1000,-216,-949,1000,-1000,929,678,361,-1000,309,1000,470,338,126,-431,-1000,-662,-1000,1000,-523,700}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00303() {
        org.junit.Assert.assertEquals("VOID|getGroupId=java.lang.Integer:NTgy", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setGroupId(long):void",
            new int[]{745,154,924,85,-353,-310,544,-464,200,1000,32,181,-537,65,-1000,-735,725,-1000,77,1000,-789,582,-73,-497,405,-881,172,1000,-664,-1000,-354,785,-272,657,450,-1000,-1000,883,1000,-462,670,-522,500,-877,797,418,1000,-703,1000,-634,1000,-767,-339,-397,-920,420,1000,222,-1000,867,-182,852,-227,324}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00304() {
        org.junit.Assert.assertEquals("VOID|getGroupId=java.lang.Integer:LTIxNDc0ODM2NDg=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setGroupId(long):void",
            new int[]{-895,569,-645,-819,-627,-372,-1000,24,1000,-1000,-1000,-892,-277,-1000,1000,1000,481,464,734,213,-27,353,-537,711,-177,-549,984,974,980,1000,-1000,-1000,58,-684,1000,1000,241,15,-1000,-620,-1000,1000,1000,180,1000,1000,-1000,1000,232,444,-561,1000,1000,-297,574,-1000,-1000,-1000,-193,-780,-1000,-864,-631,334}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00305() {
        org.junit.Assert.assertEquals("VOID|getGroupId=java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setGroupId(long):void",
            new int[]{1000,318,-242,-1000,-137,-19,-924,-904,892,718,-94,235,1000,587,-841,-68,255,-518,-887,684,-1000,534,-658,-733,359,-689,-809,273,-886,-537,282,304,211,-291,647,1000,398,-664,485,1000,-1000,-831,226,104,263,1000,-1000,-146,808,376,-732,-726,1000,127,-354,-401,757,769,-598,48,-321,20,-71,669}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00306() {
        org.junit.Assert.assertEquals("VOID|getGroupId=java.lang.Integer:OQ==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setGroupId(long):void",
            new int[]{689,44,743,593,-648,356,94,1000,913,1000,-716,-246,349,121,-225,337,-42,-1000,95,934,-263,-605,26,-205,1000,-771,1000,1000,552,-647,-1000,109,1000,574,818,-941,-910,-345,1000,-291,1000,-909,1000,-1000,1000,-22,843,-1000,1000,-867,1000,233,-575,140,-1000,-204,1000,503,-325,226,-690,1000,-1000,-717}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00307() {
        org.junit.Assert.assertEquals("VOID|getGroupId=java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setGroupId(long):void",
            new int[]{-170,535,238,-813,-627,-757,-11,383,876,-1000,-1000,-748,182,-638,1000,1000,-188,-925,796,-165,390,-367,-528,635,568,-672,660,377,625,615,-1000,-171,-1000,-1000,474,975,-83,104,-180,-368,-1000,1000,1000,-153,759,1000,-681,849,543,210,-268,555,96,-464,-407,-702,-401,-801,-108,-281,-1000,-364,-549,584}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00308() {
        org.junit.Assert.assertEquals("VOID|getGroupId=java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setGroupId(long):void",
            new int[]{-826,-513,419,675,-1000,1000,-360,-566,-262,-212,-621,-733,634,-1000,-208,1000,826,45,1000,-1000,203,-655,-109,1000,-435,-866,280,-994,23,1000,-287,-45,707,-642,-1000,1000,813,-1000,1000,-870,-1000,215,1000,1000,-245,-601,-1000,1000,-597,444,-694,391,-839,-283,355,-238,-1000,-363,870,-953,-904,-783,-574,122}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00309() {
        org.junit.Assert.assertEquals("VOID|getGroupId=java.lang.Integer:LTIxNDc0ODM2NDg=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setGroupId(long):void",
            new int[]{-1000,-650,-335,581,-929,1000,-1000,-797,247,-845,28,102,301,-1000,-78,131,746,1000,-344,-1000,856,-1000,948,-785,-765,-311,958,-729,-824,776,-977,-929,1000,-281,-781,474,860,351,-606,-803,-1000,-522,446,-845,1000,-1000,-1000,545,-971,-321,1000,862,-130,1000,944,537,-1000,671,978,-907,-659,-587,-601,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00310() {
        org.junit.Assert.assertEquals("VOID|getGroupName=java.lang.String:dHJ1ZQ==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setGroupName(java.lang.String):void",
            new int[]{-22,-898,-483,-599,-270,-130,531,145,49,430,928,686,-731,839,465,-922,727,357,-362,753,281,238,841,1,-101,32,-630,-856,-861,888,-574,-712,-279,556,-601,821,-132,596,988,-379,586,615,-6,315,-341,-713,990,890,752,-625,-519,-576,746,-3,-317,-194,163,-21,-432,913,-587,-685,-550,921}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00311() {
        org.junit.Assert.assertEquals("VOID|getGroupName=java.lang.String:LTUxZg==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setGroupName(java.lang.String):void",
            new int[]{-309,36,603,-312,-213,-1000,903,443,707,-239,625,-822,-392,-322,-36,9,436,75,257,-466,614,824,1000,-861,923,-86,639,-655,797,-151,-1000,172,531,473,-198,228,-849,99,1000,126,859,-659,-597,1000,305,-143,562,1000,229,213,-607,-236,934,-520,137,51,-487,888,-276,1000,356,108,601,190}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00312() {
        org.junit.Assert.assertEquals("VOID|getGroupName=java.lang.String:IA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setGroupName(java.lang.String):void",
            new int[]{689,-926,-175,151,-185,-26,808,-181,268,364,-349,-465,-320,-556,142,-313,-1000,-430,167,-210,-667,1000,-1000,-25,754,-1000,214,-474,-675,-536,-573,492,-399,383,106,125,-686,-73,-328,-81,-212,334,-949,560,-776,-1000,-909,899,-195,-504,-16,-84,373,478,1000,307,327,77,951,1000,695,-618,924,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00313() {
        org.junit.Assert.assertEquals("VOID|getGroupName=java.lang.String:CVJsdF8tZ19CU3c1K0tFWHNfXw==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setGroupName(java.lang.String):void",
            new int[]{1000,-721,-221,-275,-170,267,390,-566,-323,-42,1000,335,-862,1000,-228,-345,777,303,-756,823,319,-286,124,731,-610,-1000,-860,-552,-1000,818,54,-394,-279,-506,-948,821,343,596,988,-1000,-284,1000,-126,-415,-504,-660,820,615,485,-1000,-611,-344,190,-385,-397,-204,-134,-532,-146,444,-1000,-476,-251,103}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00314() {
        org.junit.Assert.assertEquals("VOID|getGroupName=java.lang.String:LTB4ODAwMDAwMDAwMDAwMDAwMDA=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setGroupName(java.lang.String):void",
            new int[]{-131,689,331,417,-1000,-547,1000,110,-179,-603,1000,-1000,-285,-131,176,-986,-964,-157,-34,-734,-131,414,-73,-446,476,-1000,1000,-265,1000,317,-700,331,258,-161,-612,394,-480,756,852,388,223,572,-1000,74,-196,390,-643,1000,370,344,-641,1000,370,-288,1000,-91,1000,315,-222,1000,415,-1000,594,980}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00315() {
        org.junit.Assert.assertEquals("VOID|getGroupName=java.lang.String:IDQg", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setGroupName(java.lang.String):void",
            new int[]{162,930,1000,-357,-1000,-1000,39,951,28,256,1000,-1000,-943,312,898,-412,-263,819,-1000,1000,170,4,744,1000,336,314,110,581,145,626,730,1000,1000,428,-1000,393,1000,1000,1000,55,568,-1000,-202,-1000,244,-89,723,416,-707,1000,-904,494,-586,1000,-1000,-879,-588,-946,-488,-1000,-1000,1000,22,-826}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00316() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setIds(int,int):void",
            new int[]{-1000,-98,1000,-588,-1000,1000,-377,-729,-36,1000,577,-615,-405,1000,363,-1000,-537,308,-370,-669,-527,937,748,660,-1000,-69,1000,-500,80,667,50,627,-1000,1000,168,-1000,-1000,1000,-220,-1000,-1000,-280,-197,-116,634,764,1000,805,-1000,447,6,603,-1000,-1000,333,-1000,1000,123,-877,1000,1000,948,-43,475}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00317() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setIds(int,int):void",
            new int[]{103,305,610,-135,-632,-35,77,-339,664,609,981,-377,-318,513,-1000,-378,-342,-160,597,-180,-116,400,1000,191,-330,477,363,-224,-173,-307,-120,242,-642,75,-169,-768,-145,808,481,-482,-842,323,-481,-890,588,724,914,435,-188,91,0,393,-619,-634,469,-362,-221,78,-210,-164,672,136,-262,44}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00318() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setIds(int,int):void",
            new int[]{-182,73,-256,1000,-478,-1000,-99,-806,-848,-253,1000,-793,742,634,-468,120,92,454,146,427,486,-1000,-1000,1000,24,-660,-938,867,-1000,-1000,-669,1000,-448,-221,1000,-4,1000,-409,1000,-197,-835,725,-1000,-723,116,-80,655,691,1000,-1000,995,-1000,-94,705,-1000,-966,574,-811,703,-83,890,-760,-1000,-572}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00319() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setIds(int,int):void",
            new int[]{856,-974,-164,1000,-307,154,604,-304,965,603,1000,-562,-937,-39,-874,-112,-159,-346,-247,131,1000,-942,-724,-214,-998,-287,-333,1000,-1000,-1000,-883,780,-67,540,629,-127,927,1000,524,-675,-783,300,-290,-428,142,-2,657,792,-160,-510,1000,-516,91,343,92,-970,412,-574,-1000,-186,1000,651,399,105}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00320() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setIds(int,int):void",
            new int[]{618,265,702,-630,-511,-96,-219,639,766,1000,784,379,-188,9,679,173,-1000,-963,83,-648,-853,444,264,-391,389,-259,290,-1000,712,-160,501,1000,206,-691,-879,-871,-345,825,454,-141,-576,-627,573,1000,-318,685,882,-421,-100,890,-591,127,-522,-569,1000,8,-501,197,491,732,116,503,910,471}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00321() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setIds(int,int):void",
            new int[]{-788,986,158,-345,-1000,-932,-33,-72,655,-463,-610,-23,-506,1000,808,-810,-71,-278,-216,-537,-777,852,445,-643,302,1000,1000,-918,-1000,771,-196,-791,-746,-713,-270,650,430,1000,287,-1000,-544,467,-9,1000,741,687,448,-629,-930,387,-253,10,-1000,-1000,1000,-402,151,-145,-220,-115,854,-6,145,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00322() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setIds(int,int):void",
            new int[]{-1000,-129,1000,-790,-1000,1000,-1000,-1000,-1000,284,577,-100,57,1000,1000,-900,-164,72,-199,-628,-1000,1000,1000,1000,398,138,914,-906,512,764,1000,763,-436,876,3,-985,-1000,363,-1000,-1000,-1000,-118,652,763,-135,1000,1000,52,-474,105,6,855,-639,-1000,-431,-1000,12,814,-1000,915,393,830,-839,663}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00323() {
        org.junit.Assert.assertEquals("VOID|getLinkName=java.lang.String:LTQ2OA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setLinkName(java.lang.String):void",
            new int[]{13,455,-1000,-325,-54,511,-288,752,965,573,-1000,-538,-654,949,1000,108,920,-346,315,-182,635,-50,112,-1000,-206,739,-468,-751,-256,112,-181,1000,-331,489,-1000,501,-478,1000,-862,-521,-412,-1000,-392,-550,-1000,-85,831,401,-369,-1000,643,1000,-458,8,-348,1000,-885,377,-1000,628,-370,62,-339,582}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00324() {
        org.junit.Assert.assertEquals("VOID|getLinkName=java.lang.String:LTB4ODAw", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setLinkName(java.lang.String):void",
            new int[]{-438,-303,-289,-995,-635,458,-1000,1000,278,1000,-1000,293,762,763,349,-1000,1000,-257,-87,1000,140,376,-52,56,86,1000,92,-567,-958,676,-938,4,-848,720,-1000,1000,-505,854,-289,819,-1000,-758,-208,-1000,687,-1000,1000,-79,-1000,772,-566,916,-1000,-1000,-656,1000,-653,-222,-1000,184,987,-1000,-831,-767}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00325() {
        org.junit.Assert.assertEquals("VOID|getLinkName=java.lang.String:TzZtbVgtMVNFNGd0X3gwTEtTazBfcA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setLinkName(java.lang.String):void",
            new int[]{150,-737,652,-749,-548,-506,363,398,-96,344,793,1000,902,532,358,-334,199,-208,160,1000,-159,-191,-1000,554,350,673,859,-203,-731,1000,-759,93,-651,-8,72,54,750,714,-55,455,-1000,246,497,-734,898,-514,-477,-497,-1000,-259,-1000,-352,-34,-362,-757,-676,-377,113,132,-101,799,362,-867,-856}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00326() {
        org.junit.Assert.assertEquals("VOID|getLinkName=NULL", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setLinkName(java.lang.String):void",
            new int[]{514,-479,706,1000,111,-910,-823,-1000,-559,1000,530,1000,-160,48,-1000,341,-338,-537,-385,-906,683,-345,-324,755,722,-1000,210,464,1000,-43,-836,-1000,1000,-117,-36,841,220,-877,300,471,1000,1000,-629,1000,625,1000,-197,263,666,566,1000,-1000,514,922,93,-722,557,-665,1000,581,811,1000,752,280}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00327() {
        org.junit.Assert.assertEquals("VOID|getLinkName=java.lang.String:IC0xNjQg", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setLinkName(java.lang.String):void",
            new int[]{-715,-730,-86,-897,123,676,-401,914,768,-735,-1000,-1000,-534,496,1000,495,520,636,-623,-703,-118,164,441,-1000,755,852,-281,-535,-323,-479,1000,1000,-1000,342,-517,-1000,-264,867,-509,-860,-458,-1000,-196,636,-1000,-778,915,393,-1000,-1000,1000,726,568,-1000,-214,19,-1000,564,-1000,686,-1000,32,1000,-297}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00328() {
        org.junit.Assert.assertEquals("VOID|getLinkName=java.lang.String:", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setLinkName(java.lang.String):void",
            new int[]{-756,-446,-273,-1000,94,674,-329,1000,594,-222,-1000,-821,-348,479,1000,269,1000,635,136,-107,-154,98,902,-1000,781,1000,1000,-521,-340,-263,734,888,-266,205,-1000,-395,-511,871,-426,-655,-585,-1000,17,60,-824,-977,1000,347,-847,-394,378,725,-1000,-889,-361,306,-708,782,-1000,611,-674,-278,533,-438}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00329() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setModTime(java.util.Date):void",
            new int[]{1000,118,-546,275,-711,-1000,-236,21,-182,-135,-1000,477,-416,692,134,-315,-78,0,-1000,307,325,789,-965,-121,-419,1000,779,663,-1000,-983,-1000,1000,-1000,308,-790,-567,-1000,-810,296,-871,-1000,560,-976,322,546,131,286,1000,8,170,56,-207,62,-854,507,1000,-416,453,-575,-183,847,411,-166,522}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00330() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setModTime(java.util.Date):void",
            new int[]{1000,113,-156,542,-1000,-222,-492,-345,-284,-210,-1000,-217,1000,170,62,-481,-791,-64,-417,283,958,-690,-466,537,-694,880,741,770,-1000,-1000,-1000,629,-1000,-1000,-626,-868,-178,-658,789,-561,973,599,-898,-794,-203,537,74,-62,585,937,388,-314,-123,-1000,472,1000,-626,988,-1000,-730,36,19,-502,428}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00331() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setModTime(java.util.Date):void",
            new int[]{1000,629,924,-161,-1000,-684,-622,599,-250,93,560,1000,1000,-160,-198,-173,796,-316,-1000,-750,-725,1000,-326,-1000,-496,634,464,881,-907,-1000,600,1000,-1000,827,-651,221,-1000,-957,-300,-1000,814,705,-425,-1000,762,-863,-265,-582,467,-1000,210,-159,1000,-1000,-880,257,1000,1000,-1000,-780,1000,-130,966,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00332() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setModTime(java.util.Date):void",
            new int[]{1000,687,-59,-115,-843,-1000,274,495,-613,69,-406,555,1000,945,600,-216,-116,-429,-719,-228,1000,1000,-1000,-755,-452,1000,821,1000,-975,-1000,-1000,1000,-1000,567,-988,-381,660,-747,105,-582,669,253,-540,31,42,-521,584,938,439,-181,742,-265,193,-792,-42,1000,250,1000,-1000,-455,572,179,356,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00333() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setModTime(java.util.Date):void",
            new int[]{-540,-406,-437,1000,-185,-1000,199,-293,-191,-248,-406,-25,-1000,-53,-429,-564,213,-111,47,-49,934,-586,-662,865,589,567,654,496,426,378,-429,733,800,-1000,-464,-269,-252,582,1000,154,-1000,371,-1000,1000,608,989,125,938,-578,380,-328,406,-246,-132,336,132,-1000,-752,-278,454,157,-47,-766,-240}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00334() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setModTime(java.util.Date):void",
            new int[]{894,-644,-313,-207,-728,111,-542,-55,615,-915,187,338,-218,-785,-3,-474,-188,1000,-32,462,379,-171,-161,46,387,300,844,-81,162,73,-551,574,325,388,-596,-1000,687,-8,-77,-455,838,335,79,-33,3,254,-813,-264,-1000,786,-894,-165,734,-1000,72,436,-496,-66,720,232,771,295,552,-863}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00335() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setModTime(long):void",
            new int[]{1000,-345,837,-1000,-797,-107,816,-1000,-160,-961,-277,64,-589,-66,1000,23,-1000,185,-331,1000,973,-1000,-355,541,379,426,410,437,-1000,493,753,975,62,-248,-713,-1000,1000,1000,406,1000,-830,190,631,9,584,868,-201,1000,-672,611,1000,181,-1000,-837,-137,-472,1000,1000,224,782,-374,1000,81,974}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00336() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setModTime(long):void",
            new int[]{-418,-311,-869,81,-298,299,1000,-856,298,767,153,-1000,-1000,280,-249,-1000,41,796,-1000,-584,332,59,94,843,157,237,-441,-991,446,-496,-303,-87,169,995,-339,552,1000,-954,-874,-796,541,358,903,626,389,773,-229,76,577,37,543,-1000,471,804,-1000,656,-42,199,417,-967,-1000,-88,-67,-203}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00337() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setModTime(long):void",
            new int[]{1000,-50,258,-284,-859,-630,594,-556,-532,337,326,-207,319,161,-538,493,-414,247,1000,681,621,-824,613,323,259,908,-398,-106,164,174,-542,-531,400,34,-228,307,147,282,-862,-379,78,-341,728,324,90,-362,659,427,400,-1000,790,-206,337,400,71,455,432,667,53,197,443,34,643,29}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00338() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setModTime(long):void",
            new int[]{792,140,670,-556,401,-226,320,-465,49,-544,1000,373,1000,121,566,710,-769,350,973,752,758,-785,90,603,93,833,624,653,-820,740,-159,7,405,-172,-516,-541,345,751,-636,381,31,300,694,-334,539,-1000,248,1000,786,1000,1000,953,-520,-597,79,-119,-210,1000,193,367,506,674,1000,885}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00339() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setModTime(long):void",
            new int[]{272,-342,143,-1000,444,458,-1000,456,1000,-436,-277,-1000,-1000,-418,614,-832,-241,-476,-331,1000,973,541,-58,1000,1000,-356,1000,-967,98,-1000,-88,-918,-273,-280,-454,-1000,1000,91,-974,478,-1000,544,-295,-576,-538,1000,-1000,858,630,1000,702,1000,-929,-874,-1000,180,1000,535,-305,569,-1000,850,-87,442}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00340() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setModTime(long):void",
            new int[]{-1000,39,845,-499,1000,-1000,840,-369,-813,622,720,537,919,977,-753,697,-1000,-500,588,826,900,-944,985,370,-1000,968,-1000,-347,-1000,627,-218,-1000,1000,-581,-345,1000,-843,-1000,460,-1000,1000,-1000,997,-517,512,-1000,1000,631,1000,76,793,772,1000,1000,685,822,600,1000,-317,862,506,-1000,1000,352}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00341() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setModTime(long):void",
            new int[]{-503,-42,127,-68,540,-236,551,-848,188,633,455,-1000,-630,486,645,-210,-224,-374,-155,351,364,-632,356,574,-168,375,-431,178,130,134,-529,-387,1000,582,484,3,1000,-901,-705,-804,519,-225,448,1000,690,-627,475,293,1000,-149,733,-471,-437,1000,-398,932,-126,199,380,-968,-1000,-300,1000,-283}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00342() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setModTime(long):void",
            new int[]{780,-458,837,-889,170,618,-60,-96,494,-255,938,-142,-292,91,431,-83,-534,55,2,973,828,-436,-67,716,150,581,944,-331,-778,467,330,82,41,-251,-156,-869,734,938,469,881,-900,524,-172,-117,9,65,-614,934,438,354,847,520,-655,-952,167,-210,756,883,-535,494,-545,585,-195,299}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00343() {
        org.junit.Assert.assertEquals("VOID|getMode=java.lang.Integer:LTIxNDc0ODM2NDg=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setMode(int):void",
            new int[]{554,-114,437,-118,1000,-630,1000,-163,239,-629,1000,86,-131,722,-510,-105,469,269,-426,161,829,-81,-306,709,-523,520,259,-298,-478,-339,393,-140,456,-486,-661,447,-578,-563,-395,664,76,620,-70,-377,577,-494,-594,-792,-861,-103,-84,-1000,100,-574,-360,831,1000,-490,-446,1000,-829,-50,437,70}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00344() {
        org.junit.Assert.assertEquals("VOID|getMode=java.lang.Integer:LTIxNDc0ODM2NDg=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setMode(int):void",
            new int[]{-184,169,6,-1000,547,-439,-1000,990,-1000,954,863,19,-160,408,-212,-776,659,227,-469,-520,-1000,-408,1000,50,-391,273,473,554,-304,1000,1000,1000,190,503,139,-1000,1000,497,1000,-1000,1000,-594,-1000,-699,1000,-637,212,1000,-1000,-937,1000,-783,383,122,-144,-386,114,543,-998,-211,255,159,55,495}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00345() {
        org.junit.Assert.assertEquals("VOID|getMode=java.lang.Integer:LTIy", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setMode(int):void",
            new int[]{-1000,231,993,921,-551,-730,851,144,862,-527,661,-914,524,764,-610,-220,-50,477,-178,-968,-432,1000,377,105,141,-353,-499,323,-1000,-1000,-955,-39,-1000,-116,-752,56,-635,867,862,416,395,530,-209,126,730,584,652,35,171,-296,-1000,1000,316,-90,-286,-1000,714,455,202,983,104,-511,465,9}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00346() {
        org.junit.Assert.assertEquals("VOID|getMode=java.lang.Integer:LTIxNDc0ODM2NDg=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setMode(int):void",
            new int[]{554,250,383,143,1000,311,1000,324,368,-867,651,-145,550,764,-636,155,56,889,-186,87,-27,515,-121,503,-350,399,-404,-298,-763,-769,351,657,282,-260,-740,65,-1000,-1000,-119,52,249,589,-170,-8,188,-568,-42,-997,-1000,379,-467,-470,783,-1000,-883,27,1000,-761,-327,751,-1000,-78,111,242}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00347() {
        org.junit.Assert.assertEquals("VOID|getMode=java.lang.Integer:MjE0NzQ4MzY0Nw==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setMode(int):void",
            new int[]{547,-586,-641,671,91,-741,-313,-786,855,245,-743,1000,-635,-482,-657,-1000,1000,-497,-1000,-491,1000,-630,-1000,-985,-647,-219,748,-174,788,312,759,-1000,558,1000,-420,-17,580,1000,-1000,1000,-487,273,660,369,-807,1000,-847,563,-1000,540,248,-22,-230,1000,488,938,-697,-5,-249,699,1000,265,-765,-186}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00348() {
        org.junit.Assert.assertEquals("VOID|getMode=java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setMode(int):void",
            new int[]{319,-103,43,-34,-928,-148,1000,123,632,-487,-522,522,-907,-409,-376,-1000,-509,-837,-1000,-645,893,-243,-125,-1000,-131,-399,259,255,254,1000,1000,-323,-287,409,-39,25,-196,256,-1000,1000,-76,474,1000,-651,-837,-134,-433,570,-943,-296,303,-157,-860,321,-765,1000,-302,758,-715,-488,180,1000,79,-720}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00349() {
        org.junit.Assert.assertEquals("VOID|getMode=java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setMode(int):void",
            new int[]{-869,111,606,687,-496,915,408,-977,750,-431,309,263,-776,382,70,-399,722,-96,-44,113,493,92,-392,-967,-1000,-1000,-785,-520,-120,212,-408,-1000,7,-212,936,-648,640,403,175,521,535,1000,-79,704,-697,-683,400,-93,-388,95,772,-5,-230,1000,270,208,255,563,29,-841,1000,145,-434,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00350() {
        org.junit.Assert.assertEquals("VOID|getMode=java.lang.Integer:MjE0NzQ4MzY0Nw==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setMode(int):void",
            new int[]{-232,-522,-929,581,-179,1000,29,-1000,749,-862,-1000,364,-1000,-40,86,-272,750,-755,-700,373,978,-301,-598,-1000,-1000,-1000,388,591,504,1000,1000,-821,352,826,550,-34,1000,-112,-549,1000,-365,604,1000,1000,-975,57,-304,-40,-557,818,408,-173,-1000,1000,263,874,-400,655,-551,-701,1000,763,-1000,-505}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00351() {
        org.junit.Assert.assertEquals("VOID|getName=java.lang.String:", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setName(java.lang.String):void",
            new int[]{1000,678,-1000,229,227,525,1000,190,263,453,997,732,-58,-1000,815,1000,-656,-571,-843,220,119,-303,-546,-361,-745,-1000,1000,-1000,1000,968,1000,288,-1000,-729,905,-1000,936,-1000,-1000,830,335,777,1000,408,1000,-314,-861,-420,-881,1000,-254,-1000,-143,-251,-581,141,-1000,-402,167,-688,-527,1000,-143,182}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00352() {
        org.junit.Assert.assertEquals("VOID|getName=java.lang.String:LTEwMDA=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setName(java.lang.String):void",
            new int[]{-155,649,350,351,1000,151,1000,78,906,1000,589,1000,-658,-674,-92,68,-1000,-1000,-1000,-109,-237,-18,-53,-1000,137,-564,1000,-979,864,1000,1000,979,-1000,335,1000,-1000,1000,-935,-1000,1000,815,1000,1000,1000,-601,640,-389,-1000,-467,1000,844,-1000,-687,-809,-361,980,-191,288,728,-1000,-762,-306,-552,-439}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00353() {
        org.junit.Assert.assertEquals("VOID|getName=java.lang.String:IA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setName(java.lang.String):void",
            new int[]{968,-273,-950,1000,270,157,156,720,-166,28,12,-1000,65,240,944,384,1000,655,-159,20,542,-670,353,-422,-539,-451,186,-336,498,154,32,-1000,58,-219,93,-954,-801,-142,1000,-382,-71,42,541,146,-601,948,-198,601,-803,-400,1000,870,976,-1000,36,145,-1000,282,431,125,-1000,-644,61,-57}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00354() {
        org.junit.Assert.assertEquals("VOID|getName=java.lang.String:MHg4MDAwMDAwMDAwMDAw", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setName(java.lang.String):void",
            new int[]{1000,306,403,-1000,-1000,199,-260,219,1000,-144,222,1000,-394,605,-154,-338,-339,-522,-879,-1000,-605,686,-54,-367,-387,158,-5,334,500,-649,-899,243,-1000,1000,748,832,-94,309,-652,124,-140,-392,954,13,1000,-777,-295,-700,-608,1000,-1000,-248,-486,798,-450,169,-13,-1000,-173,136,1000,-1000,-327,-135}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00355() {
        org.junit.Assert.assertEquals("VOID|getName=java.lang.String:KzB4OA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setName(java.lang.String):void",
            new int[]{720,365,1000,-191,575,-407,443,-581,-604,-131,-1000,-200,-328,1000,688,-1000,-1000,486,-473,-134,-56,619,-422,266,1000,674,-857,-1000,-7,-749,-1000,92,329,65,-33,-983,1000,553,-377,50,-913,-320,-324,-416,1000,-844,6,-920,954,-516,-890,-285,-892,967,-94,-363,747,-53,239,601,97,302,-1000,-50}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00356() {
        org.junit.Assert.assertEquals("VOID|getName=java.lang.String:MHgyNjA=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setName(java.lang.String):void",
            new int[]{-317,950,-867,1000,-795,-1000,-436,719,-778,-560,-1000,-1000,363,1000,1000,-272,1000,1000,43,1000,206,-457,-608,1000,-2,176,-1000,997,613,-1000,-1000,-1000,1000,1000,-155,-1000,-1000,44,1000,-693,688,-382,-754,-1000,746,1000,-1000,1000,-995,-1000,568,1000,693,-1000,663,-999,-240,841,-8,1000,-1000,-385,-140,-321}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00357() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setNames(java.lang.String,java.lang.String):void",
            new int[]{166,-9,1000,1000,-104,1000,567,-754,380,-906,688,-1000,412,549,-1000,1000,212,-1000,1000,1000,-1000,361,1000,1000,517,-170,384,285,560,-348,-870,-1000,-213,-5,-52,-1000,1000,55,-1000,798,199,-1000,-591,-379,182,174,820,1000,-136,55,524,391,-519,-1000,-15,-613,-703,-585,167,947,406,1000,318,-649}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00358() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setNames(java.lang.String,java.lang.String):void",
            new int[]{613,-927,-213,-799,-933,132,271,460,442,-223,1000,324,-81,760,-1000,74,-1000,545,695,113,-707,292,-924,806,289,1000,-312,-967,632,555,-450,732,-43,265,389,288,673,849,-276,96,-517,936,482,-1000,264,-186,-583,1000,76,1000,-1000,1000,-666,-362,1000,-139,208,-405,617,-657,277,-18,539,377}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00359() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setNames(java.lang.String,java.lang.String):void",
            new int[]{-748,-366,-577,159,-1000,-319,898,403,-1000,-149,-989,-453,-102,124,-286,-530,-617,600,-842,-1000,767,-327,-738,1000,716,355,187,-706,-446,615,-416,250,384,-968,1000,158,1000,944,-80,125,-305,887,-837,-576,105,1000,-786,-56,194,-676,-439,-1000,-481,351,338,575,-1000,366,-711,791,-316,686,621,267}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00360() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setNames(java.lang.String,java.lang.String):void",
            new int[]{-1000,534,487,-157,-1000,-229,1000,429,-769,-990,576,-861,1000,18,-1000,97,803,-545,-887,-1000,-191,711,45,-1000,205,-449,836,-246,-929,-289,-720,334,1000,562,-601,1,1000,1000,-568,703,1000,-26,-1000,677,-363,-756,-100,1000,805,-1000,493,48,-141,165,388,-911,155,1000,-638,921,-23,-255,-862,246}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00361() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setNames(java.lang.String,java.lang.String):void",
            new int[]{-380,567,941,708,278,1000,225,-754,-187,-896,-937,-1000,826,-913,-164,874,579,382,945,1000,-776,640,822,980,-37,-440,651,420,448,-465,-548,-787,-154,82,-425,-1000,687,-156,-1000,1000,-140,-1000,-511,107,727,61,1000,1000,96,-219,1000,56,178,-1000,-730,-571,-557,-702,34,906,534,1000,282,-710}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00362() {
        org.junit.Assert.assertEquals("VOID", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setNames(java.lang.String,java.lang.String):void",
            new int[]{-519,518,-525,-569,-100,-1000,-272,727,-948,460,-1000,-435,360,-362,916,-727,843,-669,-1000,-415,1000,252,-969,931,-775,-784,-96,615,-481,579,276,-179,72,-510,420,-140,200,-128,-17,136,-696,550,-702,818,578,950,-143,-719,487,-753,460,-1000,798,248,-594,1000,-307,-252,-468,-51,399,562,-381,206}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00363() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setSize(long):void",
            new int[]{-1000,-99,210,-1000,-1000,109,759,907,182,111,-345,-751,-789,65,-874,-908,-880,-327,-1000,-651,1000,449,-1000,-490,-1000,-1000,417,1000,470,487,-58,555,1000,-393,-1000,23,635,1000,121,-1000,1000,-298,-55,373,363,574,-1000,892,987,-488,-861,-452,-148,-994,-541,552,-486,529,230,-1000,-114,548,-198,1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00364() {
        org.junit.Assert.assertEquals("VOID|getSize=java.lang.Long:MQ==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setSize(long):void",
            new int[]{-745,-239,528,-965,131,-871,-479,724,983,-172,475,858,-567,377,386,302,472,945,-359,86,-442,637,-774,-53,-483,-509,727,-20,625,-231,144,934,-113,428,-864,87,515,745,-871,923,-147,-15,951,-119,-396,-244,-873,367,120,197,-236,867,707,530,115,564,438,660,286,132,806,-518,-650,-435}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00365() {
        org.junit.Assert.assertEquals("VOID|getSize=java.lang.Long:OTIyMzM3MjAzNjg1NDc3NTgwNw==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setSize(long):void",
            new int[]{91,-497,-98,557,-385,931,781,-951,-1000,-661,396,-714,1000,843,788,-987,-503,-943,927,536,379,1000,490,1000,-298,792,-511,-399,-1000,-1000,-228,-424,1000,-572,1000,-659,-1000,-1000,734,-288,701,-1000,-114,-1000,331,-735,698,1000,140,-760,-877,-1000,-531,1000,-1000,400,-662,-1000,-1000,-415,-1000,1000,-274,916}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00366() {
        org.junit.Assert.assertEquals("VOID|getSize=java.lang.Long:OTIyMzM3MjAzNjg1NDc3NTgwNw==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setSize(long):void",
            new int[]{219,774,-1000,665,-126,183,57,1000,988,608,1000,-315,559,878,396,239,811,1000,223,782,-1000,-850,249,106,-686,876,334,616,802,-1000,604,64,-559,-686,-1000,-342,575,-1000,321,1000,261,-1,-835,-746,187,-1000,907,-1000,-972,362,281,1000,-400,269,-380,-772,909,156,444,-54,412,-685,590,136}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00367() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setSize(long):void",
            new int[]{1000,-531,-529,1000,673,685,-501,-726,19,48,129,-944,1000,-11,-74,393,-59,498,1000,821,-666,-1000,796,-751,225,236,-971,-885,822,-75,301,-1000,-1000,-684,-1000,-366,-12,-914,121,424,-66,-1000,-56,278,-599,-1000,1000,659,-1000,597,-177,-1000,-564,1000,-53,57,-577,-1000,-82,991,-441,-358,361,356}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00368() {
        org.junit.Assert.assertEquals("THROW:java.lang.IllegalArgumentException", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setSize(long):void",
            new int[]{-148,242,94,-708,-1000,380,1000,204,-1000,-518,415,-376,336,106,-367,-1000,-896,-1000,-527,227,1000,158,-854,-1000,-741,520,146,1000,-847,105,-1000,1000,842,-487,-1000,-337,-443,-735,28,-1000,1000,-1000,-1000,-266,1000,49,-705,1000,1000,-81,-319,-533,511,-958,-1000,-1000,-646,1000,-822,-883,-1000,1000,-74,434}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00369() {
        org.junit.Assert.assertEquals("VOID|getUserId=java.lang.Integer:OTM=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setUserId(int):void",
            new int[]{588,-890,-879,-340,-1000,736,335,369,-176,-141,-290,122,-372,781,625,646,-507,-292,-171,-105,-1000,1000,81,75,938,-626,-136,-910,735,81,-621,654,864,-649,171,792,106,-293,658,-422,-241,-416,700,1000,-1000,281,-1000,-990,-1000,-281,-967,666,413,570,-221,-366,376,-372,463,162,-662,-537,300,755}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00370() {
        org.junit.Assert.assertEquals("VOID|getUserId=java.lang.Integer:LTg3Mg==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setUserId(int):void",
            new int[]{479,361,328,-516,43,-626,-227,67,811,-847,-7,-1000,232,596,341,741,-607,-30,194,-872,599,-735,-694,-126,108,-1000,-126,-884,-1000,-353,-92,-435,-243,-670,254,-931,-957,-978,332,-572,-1000,-883,20,131,879,-103,-64,-207,-899,-351,575,750,336,240,77,405,30,-112,-28,-227,-621,799,-760,219}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00371() {
        org.junit.Assert.assertEquals("VOID|getUserId=java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setUserId(int):void",
            new int[]{690,-78,-568,-564,-159,-522,-317,956,-83,-409,-489,-880,547,1000,220,1000,630,-427,424,-436,-414,393,-1000,604,352,-1000,-1000,-910,322,-442,-631,448,281,-1000,-750,-53,-935,-896,254,-658,-1000,-984,1000,324,301,-299,477,-578,-366,-137,-1000,1000,140,-213,-113,717,56,-33,594,131,-1000,-24,664,400}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00372() {
        org.junit.Assert.assertEquals("VOID|getUserId=java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setUserId(int):void",
            new int[]{703,750,-1000,403,-238,-172,-1000,-510,-951,617,862,440,-48,79,-209,-102,-626,1000,-1000,-956,1000,-1000,929,-266,-1000,-708,312,-1000,-1000,1000,1000,-356,-564,-400,348,-1000,-1000,-607,-931,-120,632,447,-88,-162,695,-562,-400,-740,1000,1000,425,369,898,470,-561,-949,1000,-858,-8,1000,891,929,-443,-227}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00373() {
        org.junit.Assert.assertEquals("VOID|getUserId=java.lang.Integer:MjE0NzQ4MzY0Nw==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setUserId(int):void",
            new int[]{-968,-721,287,530,-478,289,742,352,-979,-509,-21,-949,-192,-127,-297,-679,949,-823,-777,-24,-323,815,-898,653,824,35,-78,-521,13,-618,-903,326,36,-499,-820,296,-388,-40,612,-245,-454,-111,506,364,-810,-17,731,-631,93,-319,-719,685,-289,206,722,-807,151,-495,384,126,-952,-829,855,400}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00374() {
        org.junit.Assert.assertEquals("VOID|getUserId=java.lang.Integer:MjE0NzQ4MzY0Nw==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setUserId(int):void",
            new int[]{670,6,1000,-1000,-4,-1000,-885,252,214,352,-638,-279,547,1000,1000,1000,-995,-271,961,-1000,-801,-280,-1000,1000,34,-331,-939,-11,205,-547,-104,-549,103,-1000,-157,-512,-167,-224,-235,-261,-467,-380,1000,-197,503,-69,-64,-320,-129,274,-711,1000,-429,-642,-956,1000,682,594,488,394,-1000,-293,44,104}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00375() {
        org.junit.Assert.assertEquals("VOID|getUserId=java.lang.Integer:LTIxNDc0ODM2NDg=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setUserId(int):void",
            new int[]{169,-545,1000,-489,-545,203,-1000,-67,-257,514,-747,248,379,1000,1000,1000,-660,66,844,-246,-1000,933,-884,1000,504,470,-596,-308,1000,-496,-1000,896,505,-1000,-99,861,-166,133,384,-87,82,-566,1000,417,-40,687,-1000,-396,-856,-346,-1000,1000,-312,277,-172,691,509,730,-8,-148,-795,988,-59,-227}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00376() {
        org.junit.Assert.assertEquals("VOID|getUserId=java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setUserId(long):void",
            new int[]{1000,14,-690,-1000,-158,761,583,-613,633,-1000,189,-62,1000,70,23,940,-1000,-1000,-913,279,-1000,-406,883,987,-979,591,-175,-365,296,965,-765,-491,-9,-471,-278,219,-78,788,956,22,-356,759,-647,-685,-8,421,-703,985,-834,1000,1000,775,1000,150,-914,-454,-268,-1000,-1000,328,-1000,-207,-930,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00377() {
        org.junit.Assert.assertEquals("VOID|getUserId=java.lang.Integer:MQ==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setUserId(long):void",
            new int[]{-860,-143,-1000,-948,-1000,-1000,476,499,-48,-832,-704,607,156,-999,153,1000,-1000,1000,-176,-351,-843,1000,-420,-203,983,968,-595,-171,211,-8,632,-781,-545,183,529,389,1000,906,1000,375,1000,857,-67,-555,52,693,-1000,-731,284,164,270,-590,518,-256,-1000,715,-898,-1000,-525,-1000,1000,-1000,-35,-29}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00378() {
        org.junit.Assert.assertEquals("VOID|getUserId=java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setUserId(long):void",
            new int[]{-1000,130,1000,907,89,197,324,998,-312,323,-1000,-76,-470,-1000,797,346,-1000,871,-247,333,352,-560,-305,-1000,756,452,-83,15,-398,-440,1000,-302,-642,-1000,302,-1000,373,4,1000,-148,-1000,465,248,137,1000,-261,47,-174,1000,564,591,69,-1000,-1000,764,-823,293,862,1000,-1000,439,-14,-568,-533}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00379() {
        org.junit.Assert.assertEquals("VOID|getUserId=java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setUserId(long):void",
            new int[]{-170,-641,1000,-111,59,1000,439,768,1000,-398,789,-362,-775,-1000,626,604,167,-310,-876,-280,-1000,-142,237,-151,-94,1000,141,-1000,-1000,-200,-279,-535,-844,-1000,566,-1000,1000,-391,494,-1000,-1000,193,-1000,512,-2,-125,1000,812,1000,1000,-1000,330,-864,381,414,-769,592,714,965,-268,237,270,-891,-368}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00380() {
        org.junit.Assert.assertEquals("VOID|getUserId=java.lang.Integer:LTE=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setUserId(long):void",
            new int[]{395,431,1000,-949,480,1000,-1000,542,411,-102,-645,-289,-409,-1000,49,41,-186,294,276,-292,-80,-1000,-514,-757,74,496,669,-1000,-941,-1000,-838,-165,29,-779,887,514,-1000,832,-166,-1000,-1000,-697,-1000,-523,-184,-158,514,-855,572,-33,-809,-103,-1000,-557,-426,-1000,385,-903,927,-810,-1000,-46,-781,-753}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00381() {
        org.junit.Assert.assertEquals("VOID|getUserId=java.lang.Integer:LTIxNDc0ODM2NDg=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setUserId(long):void",
            new int[]{-331,158,1000,-597,-110,677,-839,1000,369,16,-731,810,-1000,-942,443,624,-186,1000,724,-497,-80,-939,-1000,-1000,1000,760,457,-1000,-1000,-1000,129,-521,-1000,-456,990,-896,-489,696,-135,-860,-604,-657,-1000,-398,-344,54,306,-1000,1000,590,-809,-448,-1000,-732,-226,-685,352,497,939,-604,256,-462,-330,-98}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00382() {
        org.junit.Assert.assertEquals("VOID|getUserId=java.lang.Integer:MA==", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setUserId(long):void",
            new int[]{862,118,-783,-862,-626,-349,-62,474,302,579,-936,984,243,349,-703,37,-1000,347,101,-209,-12,220,-253,4,380,1000,-147,496,362,-130,453,267,622,-29,-297,453,-843,1000,958,1000,189,741,328,173,746,558,-1000,-615,-884,644,1000,-287,1000,-1000,-1000,534,-1000,-1000,-1000,41,-627,-161,-198,217}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00383() {
        org.junit.Assert.assertEquals("VOID|getUserName=java.lang.String:LS03OTU=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setUserName(java.lang.String):void",
            new int[]{903,942,-536,28,-1000,-358,-98,-460,873,-470,771,-309,93,-651,874,-594,473,1000,-37,423,-1000,-579,-663,874,-575,-460,452,795,731,-186,-1000,19,-1000,360,-495,323,-792,-91,1000,-790,262,-810,-1000,-874,-1000,-360,-204,680,-752,-482,608,-55,-689,-800,-776,767,16,-1000,-220,-385,-794,1000,732,-38}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00384() {
        org.junit.Assert.assertEquals("VOID|getUserName=java.lang.String:LS0weDgw", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setUserName(java.lang.String):void",
            new int[]{635,33,-893,321,-330,-544,-284,471,241,-142,832,-580,605,940,958,517,453,787,-800,434,-246,344,-56,-985,-819,-989,4,372,820,121,481,-971,-542,-744,457,-412,-568,95,629,-261,-254,-184,-36,220,978,942,-423,-206,-665,961,-843,237,165,-935,466,-109,-789,890,-287,426,922,-695,-59,116}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00385() {
        org.junit.Assert.assertEquals("VOID|getUserName=java.lang.String:YWFhYWFhYWFhYWE=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setUserName(java.lang.String):void",
            new int[]{-566,-172,563,-223,1000,-66,321,-446,781,-719,-1000,468,-232,-67,-1000,-1000,-471,112,1000,180,-22,807,1000,-4,-102,808,311,247,-269,215,-167,801,1000,-179,1000,-618,345,-1,1000,-782,-837,1000,608,-193,-1000,39,-242,24,-263,-178,164,-804,-981,522,-371,858,545,-966,-954,-90,235,953,-1000,79}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00386() {
        org.junit.Assert.assertEquals("VOID|getUserName=java.lang.String:TSBSNUpWaGlGX3pJU05i", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setUserName(java.lang.String):void",
            new int[]{465,-467,-1000,-664,-1000,91,533,559,-143,-1000,669,-1000,-528,123,-351,175,-683,742,331,935,-26,-134,157,-439,-727,590,-94,-715,550,-918,-26,128,-480,-834,-101,775,-533,186,267,-235,934,-933,-112,24,514,-227,1000,635,-613,-1000,-286,374,-1000,-958,116,557,-728,-1000,1000,-120,-1000,-451,1000,345}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00387() {
        org.junit.Assert.assertEquals("VOID|getUserName=java.lang.String:MHg4MDAwMDAw", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setUserName(java.lang.String):void",
            new int[]{474,370,551,-1000,907,49,579,-595,-899,-281,426,-804,467,1000,-200,874,476,1000,778,1000,226,1000,896,140,-116,5,-710,94,-375,-1000,15,-1000,-702,-394,42,-367,60,23,-644,-164,349,-1000,723,-255,-75,-461,1000,-480,-617,-1000,-207,-311,-675,-1000,-910,1000,-1000,-968,1000,-393,-741,-1000,-1000,-832}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00388() {
        org.junit.Assert.assertEquals("VOID|getUserName=java.lang.String:MTAwMEY=", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "setUserName(java.lang.String):void",
            new int[]{732,237,-349,-1000,808,1000,509,288,259,-1000,-396,-976,-1000,1000,-70,-498,-889,1000,1000,848,1000,554,649,-1000,-1000,-101,611,672,-280,972,-1000,-39,526,-268,1000,-243,-1000,-1000,-336,-1000,691,-242,182,-464,-682,-885,850,-535,-708,-932,-374,-741,-1000,-1000,-637,83,34,-118,-412,411,-695,-173,518,711}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00389() {
        org.junit.Assert.assertEquals("THROW:java.lang.ArrayIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "writeEntryHeader(byte[]):void",
            new int[]{134,638,247,763,1000,-1000,975,369,-158,-644,1000,604,1000,-196,-805,556,256,1000,-1000,344,-638,417,-387,732,62,645,-303,-1000,1000,1000,719,-349,721,-620,-153,-201,-634,-1000,-79,-14,-548,-574,1000,-399,632,46,-541,-619,1000,-101,-654,978,372,1000,620,-599,-951,770,470,10,-149,-579,45,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00390() {
        org.junit.Assert.assertEquals("THROW:java.lang.ArrayIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "writeEntryHeader(byte[]):void",
            new int[]{480,65,-290,307,-703,1000,354,845,-1000,309,730,557,-266,-981,-119,167,338,-662,-352,-509,-607,1000,537,939,-487,308,-37,530,550,1000,1000,325,881,1000,-1000,-80,1000,-29,1000,1000,628,-130,-517,183,-704,1000,-641,-1000,3,-849,-997,463,755,40,137,-1000,1000,1000,-837,-26,967,39,-911,-548}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00391() {
        org.junit.Assert.assertEquals("THROW:java.lang.ArrayIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "writeEntryHeader(byte[]):void",
            new int[]{1000,-41,315,803,-1000,795,-700,-301,662,899,399,819,1000,-329,-235,416,-544,-75,-1000,1000,1000,1000,-167,-450,-621,368,421,-1000,-1000,-1000,240,1000,833,1000,-1000,-1000,1000,703,-253,484,518,947,1000,-119,838,1000,-1000,23,1000,90,349,-400,1000,-1000,-1000,-1000,891,-1000,-604,-1000,-70,-304,1000,-470}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00392() {
        org.junit.Assert.assertEquals("THROW:java.lang.ArrayIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "writeEntryHeader(byte[]):void",
            new int[]{894,196,-1000,808,-1000,-46,-1000,-729,1000,213,-421,-682,529,1000,-309,-64,790,-500,135,1000,1000,424,1000,-1000,-1000,-1000,724,-850,-384,-1000,-172,1000,-818,45,-1000,-380,694,-42,-448,293,-6,1000,772,1000,213,1000,-1000,-184,551,1000,798,-1000,1000,-680,-1000,684,1000,-690,168,941,-379,-576,1000,-820}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00393() {
        org.junit.Assert.assertEquals("THROW:java.lang.ArrayIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "writeEntryHeader(byte[]):void",
            new int[]{855,-266,-1000,718,-60,1000,502,1000,573,-104,-361,901,529,298,-1000,-22,802,-837,-706,1000,904,1000,750,-65,-1000,1000,1000,-536,257,-378,-1000,-77,512,258,-1000,136,704,1000,-375,403,832,250,263,1000,-74,1000,-1000,-1000,1000,-49,-643,-585,1000,148,-495,-540,1000,1000,1000,712,255,-75,-1000,-665}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00394() {
        org.junit.Assert.assertEquals("THROW:java.lang.ArrayIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "writeEntryHeader(byte[]):void",
            new int[]{-528,-35,-689,1000,1000,-528,-444,128,-1000,-560,988,-418,353,-546,748,-161,-1000,407,-367,-1000,265,560,11,9,615,-59,-1000,-146,220,1000,113,-748,434,432,201,139,-1000,-602,323,1000,-588,-1000,-494,-372,-204,-862,-942,-925,-1000,-334,-796,326,-1000,-99,434,-1000,-510,424,-623,264,-176,933,-976,-788}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00395() {
        org.junit.Assert.assertEquals("THROW:java.lang.ArrayIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "writeEntryHeader(byte[]):void",
            new int[]{-725,414,650,439,1000,-1000,669,-257,-709,-1000,646,-178,370,-512,432,491,-16,1000,1,-119,-969,-273,-1000,814,668,-174,-128,489,1000,1000,426,-1000,604,-816,185,-500,-307,-1000,-397,89,-630,-1000,-60,-1000,863,-1000,904,171,-644,-226,233,1000,49,358,1000,-599,-366,8,-817,-91,194,-480,-977,-237}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00396() {
        org.junit.Assert.assertEquals("THROW:java.lang.ArrayIndexOutOfBoundsException", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "writeEntryHeader(byte[]):void",
            new int[]{251,-206,-1000,1000,663,369,-316,494,267,-1000,-137,75,-852,1000,-1000,-133,1000,-22,-101,1000,813,883,116,-722,-1000,194,1000,-564,615,-721,134,-563,259,-656,-1000,5,-412,-70,-1000,-354,315,275,1000,1000,389,1000,-390,-1000,1000,613,262,-239,32,-7,-401,-880,1000,1000,1000,889,140,-108,-46,-642}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00397() {
        org.junit.Assert.assertEquals("THROW:java.lang.NullPointerException", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "writeEntryHeader(byte[],org.apache.commons.compress.archivers.zip.ZipEncoding,boolean):void",
            new int[]{1000,-138,-74,754,-57,1000,1000,-1000,739,902,-935,1000,59,282,-357,907,487,845,-830,-48,-1000,1000,-619,-246,460,-195,-213,174,195,224,724,1000,-601,-858,174,-339,462,-1000,-67,1000,-1000,-1000,660,-1000,591,-556,-1000,30,862,1000,-145,1000,-664,-400,104,358,-421,64,95,-660,-761,130,222,-992}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00398() {
        org.junit.Assert.assertEquals("THROW:java.lang.NullPointerException", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "writeEntryHeader(byte[],org.apache.commons.compress.archivers.zip.ZipEncoding,boolean):void",
            new int[]{-1000,-631,-74,1000,733,4,-1000,-1000,-1000,-901,-297,-1000,-912,-566,-650,-1000,-151,-768,576,103,1000,-667,781,95,617,-1000,253,556,477,-311,-22,-635,725,1000,387,-79,-227,-1000,329,697,-1000,-1000,-493,342,-707,-617,342,-616,695,1000,335,260,1000,755,348,246,-489,64,-772,324,-527,-253,222,248}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00399() {
        org.junit.Assert.assertEquals("THROW:java.lang.NullPointerException", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "writeEntryHeader(byte[],org.apache.commons.compress.archivers.zip.ZipEncoding,boolean):void",
            new int[]{646,-401,187,-648,-473,647,1000,-393,1000,-196,-1000,1000,740,723,-443,1000,-247,710,105,-847,-1000,1000,-442,-1000,465,287,-1000,-537,523,30,682,255,111,-879,883,-614,468,-1000,-1000,-156,480,-1000,940,-469,525,-156,-625,-1000,327,-121,-445,1000,965,142,-1000,1000,-777,-1000,-468,-484,-266,433,-604,-930}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00400() {
        org.junit.Assert.assertEquals("THROW:java.lang.NullPointerException", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "writeEntryHeader(byte[],org.apache.commons.compress.archivers.zip.ZipEncoding,boolean):void",
            new int[]{543,759,297,224,963,742,494,-480,-549,184,156,50,-678,-580,-381,468,-493,633,-784,479,-381,746,-831,-271,-214,1000,-689,-1000,985,-309,255,-1000,-891,-779,-1000,686,-428,-245,-108,456,-1000,-892,152,-591,200,-1000,-506,-806,786,488,282,72,-354,-732,660,-800,-573,-131,1000,320,286,777,-472,-1000}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00401() {
        org.junit.Assert.assertEquals("THROW:java.lang.NullPointerException", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "writeEntryHeader(byte[],org.apache.commons.compress.archivers.zip.ZipEncoding,boolean):void",
            new int[]{1000,642,-462,-681,-946,-557,1000,293,-183,965,669,838,1000,-1000,336,1000,60,1000,-752,-335,-918,649,1000,-494,-856,1000,-510,1000,124,-1000,-133,-241,-245,-1000,-1000,1000,-231,-486,-1000,970,332,-1000,-106,813,608,1000,156,283,681,-1000,479,-325,-143,-898,977,-324,138,-1000,1000,1000,340,1000,-1000,135}));
    }
    @org.junit.Test(timeout=60000L)
    public void testDE00402() {
        org.junit.Assert.assertEquals("THROW:java.lang.NullPointerException", DEReplay.run(
            "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "org.apache.commons.compress.archivers.tar.TarArchiveEntry", "writeEntryHeader(byte[],org.apache.commons.compress.archivers.zip.ZipEncoding,boolean):void",
            new int[]{812,-179,231,882,-1000,-168,-178,-217,-1000,865,-808,-1000,229,1000,-1000,-1000,1000,109,19,468,613,-1000,781,-76,1000,-1000,1000,-893,-1000,1000,-109,1000,-869,-1000,950,-1000,1000,657,505,830,1000,247,335,-1000,905,-1000,-1000,117,-544,798,615,-100,618,1000,-425,1000,654,-375,-845,-898,-1000,-1000,281,1000}));
    }
}
